using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Management;
using System.Net.NetworkInformation;
using System.Net.WebSockets;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows.Automation;

namespace FluxoVideoStudio
{
    public class CdpTargetInfo
    {
        public string TargetId { get; set; }
        public string Type { get; set; }
        public string Title { get; set; }
        public string Url { get; set; }
        public string BrowserContextId { get; set; }
    }

    public class CdpController : IDisposable
    {
        private ClientWebSocket _ws;
        private CancellationTokenSource _rxCts;
        private readonly SemaphoreSlim _sendLock = new SemaphoreSlim(1, 1);
        private readonly SemaphoreSlim _connectLock = new SemaphoreSlim(1, 1);
        private readonly ConcurrentDictionary<int, TaskCompletionSource<Dictionary<string, object>>> _pending =
            new ConcurrentDictionary<int, TaskCompletionSource<Dictionary<string, object>>>();

        private readonly ConcurrentDictionary<string, string> _profileToContextId =
            new ConcurrentDictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        private readonly ConcurrentDictionary<string, string> _profileToLastTargetId =
            new ConcurrentDictionary<string, string>(StringComparer.OrdinalIgnoreCase);

        private readonly ConcurrentDictionary<string, string> _downloadGuidState =
            new ConcurrentDictionary<string, string>(StringComparer.OrdinalIgnoreCase);

        private readonly object _downloadSnapshotLock = new object();
        private Dictionary<string, DateTime> _preDownloadUserDownloadsMap =
            new Dictionary<string, DateTime>(StringComparer.OrdinalIgnoreCase);
        private DateTime _lastSetDownloadUtc = DateTime.MinValue;

        private volatile TaskCompletionSource<Dictionary<string, object>> _fileChooserTcs;
        private volatile string _activeSessionId = "";
        private volatile bool _reloadAndResumeRequested = false;
        private volatile string _reloadRequestReason = "";
        private volatile TaskCompletionSource<bool> _reloadSignalTcs;
        private readonly object _reloadSignalLock = new object();

        private int _nextId = 100;
        private readonly Action<string> _log;
        private readonly PipelineConfig _config;

        public string ActiveSessionId
        {
            get { return _activeSessionId; }
        }

        public bool IsReloadAndResumeRequested
        {
            get { return _reloadAndResumeRequested; }
        }

        public void ClearReloadAndResumeRequest()
        {
            lock (_reloadSignalLock)
            {
                _reloadAndResumeRequested = false;
                _reloadRequestReason = "";
            }
        }

        public void RequestReloadAndResume(string reason)
        {
            TaskCompletionSource<bool> sig;
            lock (_reloadSignalLock)
            {
                _reloadAndResumeRequested = true;
                _reloadRequestReason = string.IsNullOrWhiteSpace(reason)
                    ? "Solicitado manualmente pelo usuário"
                    : reason;
                sig = _reloadSignalTcs;
            }
            if (sig != null)
            {
                sig.TrySetResult(true);
            }
        }

        public bool ConsumeReloadAndResumeRequest(out string reason)
        {
            lock (_reloadSignalLock)
            {
                if (_reloadAndResumeRequested)
                {
                    _reloadAndResumeRequested = false;
                    reason = _reloadRequestReason ?? "Solicitado pelo usuário";
                    _reloadRequestReason = "";
                    return true;
                }
                reason = "";
                return false;
            }
        }

        public async Task<bool> WaitOrWakeOnReloadSignalAsync(int delayMs, CancellationToken ct)
        {
            if (_reloadAndResumeRequested)
                return true;

            TaskCompletionSource<bool> tcs = new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
            lock (_reloadSignalLock)
            {
                if (_reloadAndResumeRequested)
                    return true;
                _reloadSignalTcs = tcs;
            }

            try
            {
                Task completed = await Task.WhenAny(Task.Delay(delayMs, ct), tcs.Task);
                ct.ThrowIfCancellationRequested();
                return completed == tcs.Task || _reloadAndResumeRequested;
            }
            finally
            {
                lock (_reloadSignalLock)
                {
                    if (_reloadSignalTcs == tcs)
                        _reloadSignalTcs = null;
                }
            }
        }

        public bool IsConnected
        {
            get { return _ws != null && _ws.State == WebSocketState.Open; }
        }

        public CdpController(PipelineConfig config, Action<string> logger)
        {
            _config = config;
            _log = logger ?? delegate { };
        }

        private JavaScriptSerializer CreateSerializer()
        {
            JavaScriptSerializer ser = new JavaScriptSerializer();
            ser.MaxJsonLength = int.MaxValue;
            ser.RecursionLimit = 256;
            return ser;
        }

        public static uint LaunchViaWmi(string commandLine)
        {
            using (ManagementClass procClass = new ManagementClass("Win32_Process"))
            {
                ManagementBaseObject inParams = procClass.GetMethodParameters("Create");
                inParams["CommandLine"] = commandLine;
                ManagementBaseObject outParams = procClass.InvokeMethod("Create", inParams, null);
                if (outParams != null && outParams["ReturnValue"] != null)
                {
                    return Convert.ToUInt32(outParams["ReturnValue"]);
                }
            }
            return 0;
        }

        public void LaunchChromeProfileWindow(string profileDir, string url)
        {
            string cmd = string.Format("\"{0}\" --profile-directory=\"{1}\" --new-window \"{2}\"",
                _config.ChromeExePath, profileDir, url);
            LaunchViaWmi(cmd);
        }

        [DllImport("user32.dll")]
        private static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

        [DllImport("user32.dll")]
        private static extern bool SetForegroundWindow(IntPtr hWnd);

        [DllImport("user32.dll")]
        private static extern bool IsIconic(IntPtr hWnd);

        private bool HasVisibleChromeWindow()
        {
            try
            {
                Process[] procs = Process.GetProcessesByName("chrome");
                foreach (Process p in procs)
                {
                    try
                    {
                        if (p.MainWindowHandle != IntPtr.Zero) return true;
                    }
                    catch { }
                }
            }
            catch { }
            return false;
        }

        private bool BringAnyChromeWindowToFront()
        {
            bool activatedAny = false;
            try
            {
                AutomationElement root = AutomationElement.RootElement;
                TreeWalker walker = TreeWalker.ControlViewWalker;
                AutomationElement win = walker.GetFirstChild(root);
                IntPtr bestHwnd = IntPtr.Zero;

                while (win != null)
                {
                    try
                    {
                        string cls = win.Current.ClassName ?? "";
                        string name = win.Current.Name ?? "";
                        if (cls == "Chrome_WidgetWin_1" && name.IndexOf("Google Chrome", StringComparison.OrdinalIgnoreCase) >= 0)
                        {
                            IntPtr hwnd = new IntPtr(win.Current.NativeWindowHandle);
                            if (hwnd != IntPtr.Zero)
                            {
                                bestHwnd = hwnd;
                                if (name.IndexOf("Grok", StringComparison.OrdinalIgnoreCase) >= 0 ||
                                    name.IndexOf("Flow", StringComparison.OrdinalIgnoreCase) >= 0 ||
                                    name.IndexOf("ElevenLabs", StringComparison.OrdinalIgnoreCase) >= 0)
                                {
                                    break;
                                }
                            }
                        }
                    }
                    catch { }
                    win = walker.GetNextSibling(win);
                }

                if (bestHwnd == IntPtr.Zero)
                {
                    Process[] procs = Process.GetProcessesByName("chrome");
                    foreach (Process p in procs)
                    {
                        try
                        {
                            if (p.MainWindowHandle != IntPtr.Zero)
                            {
                                bestHwnd = p.MainWindowHandle;
                                break;
                            }
                        }
                        catch { }
                    }
                }

                if (bestHwnd != IntPtr.Zero)
                {
                    if (IsIconic(bestHwnd))
                        ShowWindow(bestHwnd, 9); // SW_RESTORE
                    else
                        ShowWindow(bestHwnd, 5); // SW_SHOW
                    SetForegroundWindow(bestHwnd);
                    activatedAny = true;
                }
            }
            catch { }
            return activatedAny;
        }

        private bool DismissStaleRemoteDebugPopupIfPresent()
        {
            try
            {
                AutomationElement root = AutomationElement.RootElement;
                TreeWalker walker = TreeWalker.ControlViewWalker;
                AutomationElement win = walker.GetFirstChild(root);
                bool waitedGuard = false;
                while (win != null)
                {
                    try
                    {
                        if (win.Current.ClassName == "Chrome_WidgetWin_1")
                        {
                            if (ClickAllowButtonRecursive(walker, win, 0, ref waitedGuard))
                                return true;
                        }
                    }
                    catch { }
                    win = walker.GetNextSibling(win);
                }
            }
            catch { }
            return false;
        }

        private void KillOrphanChromeDevtoolsMcpProcesses()
        {
            try
            {
                using (ManagementObjectSearcher searcher = new ManagementObjectSearcher(
                    "SELECT ProcessId, CommandLine FROM Win32_Process WHERE Name = 'node.exe'"))
                {
                    foreach (ManagementObject obj in searcher.Get())
                    {
                        string cmd = Convert.ToString(obj["CommandLine"] ?? "");
                        if (cmd.IndexOf("chrome-devtools-mcp", StringComparison.OrdinalIgnoreCase) >= 0)
                        {
                            int pid = Convert.ToInt32(obj["ProcessId"]);
                            try
                            {
                                Process p = Process.GetProcessById(pid);
                                p.Kill();
                                _log(string.Format("[CDP] Encerrado processo órfão chrome-devtools-mcp (PID {0}) que segurava a porta 9222.", pid));
                            }
                            catch { }
                        }
                    }
                }
            }
            catch { }
        }

        private bool TryReadDevToolsPort(out int port, out string wsPath)
        {
            port = 0;
            wsPath = "";
            string portFile = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                @"Google\Chrome\User Data\DevToolsActivePort");

            if (!File.Exists(portFile)) return false;

            try
            {
                string[] lines = File.ReadAllLines(portFile);
                if (lines.Length < 2) return false;
                int parsedPort;
                if (!int.TryParse(lines[0].Trim(), out parsedPort)) return false;
                port = parsedPort;
                wsPath = lines[1].Trim();

                var listeners = IPGlobalProperties.GetIPGlobalProperties().GetActiveTcpListeners();
                bool isListening = listeners.Any(ep => ep.Port == parsedPort);
                return isListening;
            }
            catch
            {
                return false;
            }
        }

        private void TriggerSingleAutoAllow(int maxSeconds)
        {
            // Regra 0.1: Dispara UMA ÚNICA VEZ em background somente quando ConnectAsync aguarda autorização
            Task.Run(() =>
            {
                try
                {
                    DateTime deadline = DateTime.UtcNow.AddSeconds(maxSeconds);
                    bool waitedGuard = false;

                    while (DateTime.UtcNow < deadline)
                    {
                        bool foundAllow = false;
                        try
                        {
                            AutomationElement root = AutomationElement.RootElement;
                            TreeWalker walker = TreeWalker.ControlViewWalker;
                            AutomationElement win = walker.GetFirstChild(root);
                            while (win != null)
                            {
                                try
                                {
                                    if (win.Current.ClassName == "Chrome_WidgetWin_1")
                                    {
                                        if (ClickAllowButtonRecursive(walker, win, 0, ref waitedGuard))
                                        {
                                            foundAllow = true;
                                            break;
                                        }
                                    }
                                }
                                catch { }
                                win = walker.GetNextSibling(win);
                            }
                        }
                        catch { }

                        if (foundAllow)
                        {
                            return; // exit imediatamente após clicar 1 vez (Regra 0.1)
                        }
                        Thread.Sleep(250);
                    }
                }
                catch { }
            });

            // Fallback opcional com o script oficial via WMI caso UIPI exija sessão separada
            string autoAllowScript = Path.Combine(_config.SkillScriptsDir, "auto_allow_chrome.ps1");
            if (File.Exists(autoAllowScript))
            {
                string wmiCmd = string.Format(
                    "powershell.exe -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File \"{0}\" -DurationSeconds {1}",
                    autoAllowScript, Math.Min(20, maxSeconds));
                try { LaunchViaWmi(wmiCmd); } catch { }
            }
        }

        private bool ClickAllowButtonRecursive(TreeWalker walker, AutomationElement el, int depth, ref bool waitedGuard)
        {
            if (el == null || depth > 12) return false;
            try
            {
                ControlType ct = el.Current.ControlType;
                if (ct == ControlType.Document) return false;
                if (ct == ControlType.Button)
                {
                    string name = el.Current.Name ?? "";
                    if (string.Equals(name, "Permitir", StringComparison.OrdinalIgnoreCase) ||
                        string.Equals(name, "Allow", StringComparison.OrdinalIgnoreCase))
                    {
                        if (!waitedGuard)
                        {
                            // Respeita o input-jacking protection de 500ms do Chrome (550ms)
                            Thread.Sleep(550);
                            waitedGuard = true;
                        }
                        object patObj;
                        if (el.TryGetCurrentPattern(InvokePattern.Pattern, out patObj))
                        {
                            ((InvokePattern)patObj).Invoke();
                            return true;
                        }
                    }
                }

                AutomationElement child = walker.GetFirstChild(el);
                while (child != null)
                {
                    if (ClickAllowButtonRecursive(walker, child, depth + 1, ref waitedGuard))
                        return true;
                    child = walker.GetNextSibling(child);
                }
            }
            catch { }
            return false;
        }

        public async Task EnsureConnectedAsync(CancellationToken ct)
        {
            if (IsConnected) return;

            await _connectLock.WaitAsync(ct);
            try
            {
                if (IsConnected) return;

                int port;
                string wsPath;
                if (!TryReadDevToolsPort(out port, out wsPath))
                {
                    _log("[CDP] Abrindo janela visível do Google Chrome via WMI e aguardando DevToolsActivePort (porta 9222)...");
                    LaunchChromeProfileWindow(_config.FlowProfile, "about:blank");

                    for (int i = 0; i < 30; i++)
                    {
                        ct.ThrowIfCancellationRequested();
                        await Task.Delay(500, ct);
                        if (TryReadDevToolsPort(out port, out wsPath))
                            break;
                    }
                }

                if (!TryReadDevToolsPort(out port, out wsPath))
                {
                    throw new InvalidOperationException(
                        "Não foi possível localizar DevToolsActivePort ativo no Chrome. Verifique se 'chrome://inspect/#remote-debugging' (Discover network targets) está ativado.");
                }

                string wsUri = string.Format("ws://127.0.0.1:{0}{1}", port, wsPath);

                // Se houver um popup "Permitir depuração remota?" órfão aberto de tentativa anterior, limpa antes de conectar
                if (DismissStaleRemoteDebugPopupIfPresent())
                {
                    await Task.Delay(500, ct);
                }

                // Garante que uma janela do Chrome esteja ativa/visível em primeiro plano para o Chrome 156+ não rejeitar com 403
                if (!BringAnyChromeWindowToFront())
                {
                    LaunchChromeProfileWindow(_config.FlowProfile, "about:blank");
                    await Task.Delay(2000, ct);
                    BringAnyChromeWindowToFront();
                }
                await Task.Delay(250, ct);

                for (int attempt = 1; attempt <= 3; attempt++)
                {
                    CleanupSocketOnly();
                    _ws = new ClientWebSocket();
                    _rxCts = new CancellationTokenSource();
                    bool retryAfter403 = false;

                    try
                    {
                        Task connectTask = _ws.ConnectAsync(new Uri(wsUri), ct);
                        Task completed = await Task.WhenAny(connectTask, Task.Delay(550, ct));
                        if (completed != connectTask)
                        {
                            _log("[CDP] Autorizando popup 'Permitir depuração remota' silenciosamente (1x)...");
                            TriggerSingleAutoAllow(20);
                        }

                        await connectTask;
                        Task rxTask = Task.Run(() => ReceiveLoopAsync(_rxCts.Token));
                        if (rxTask != null) { }
                        _log(string.Format("[CDP] Conectado com sucesso ao Chrome WebSocket (Porta {0}) — conexão persistente ativa!", port));
                        return;
                    }
                    catch (Exception ex)
                    {
                        string msg = ex.ToString();
                        if (attempt < 3 && (msg.Contains("403") || msg.IndexOf("Forbidden", StringComparison.OrdinalIgnoreCase) >= 0 || msg.IndexOf("Proibido", StringComparison.OrdinalIgnoreCase) >= 0))
                        {
                            retryAfter403 = true;
                        }
                        else
                        {
                            throw;
                        }
                    }

                    if (retryAfter403)
                    {
                        _log(string.Format("[CDP] Recebido 403 Proibido na porta 9222 (tentativa {0}/3). Ativando janela do Chrome e limpando popups pendentes...", attempt));
                        KillOrphanChromeDevtoolsMcpProcesses();
                        DismissStaleRemoteDebugPopupIfPresent();
                        if (!BringAnyChromeWindowToFront())
                        {
                            LaunchChromeProfileWindow(_config.FlowProfile, "about:blank");
                            await Task.Delay(2000, ct);
                            BringAnyChromeWindowToFront();
                        }
                        TriggerSingleAutoAllow(12);
                        await Task.Delay(950, ct);
                        TryReadDevToolsPort(out port, out wsPath);
                        wsUri = string.Format("ws://127.0.0.1:{0}{1}", port, wsPath);
                    }
                }
            }
            finally
            {
                _connectLock.Release();
            }
        }

        private async Task ReceiveLoopAsync(CancellationToken ct)
        {
            byte[] buffer = new byte[65536];
            JavaScriptSerializer ser = CreateSerializer();

            try
            {
                while (!ct.IsCancellationRequested && _ws != null && _ws.State == WebSocketState.Open)
                {
                    using (MemoryStream ms = new MemoryStream())
                    {
                        WebSocketReceiveResult res;
                        do
                        {
                            res = await _ws.ReceiveAsync(new ArraySegment<byte>(buffer), ct);
                            if (res.MessageType == WebSocketMessageType.Close)
                            {
                                FailAllPending(new IOException("Conexão CDP WebSocket encerrada pelo navegador."));
                                return;
                            }
                            ms.Write(buffer, 0, res.Count);
                        } while (!res.EndOfMessage);

                        string json = Encoding.UTF8.GetString(ms.ToArray());
                        Dictionary<string, object> msg = null;
                        try
                        {
                            msg = ser.Deserialize<Dictionary<string, object>>(json);
                        }
                        catch { }

                        if (msg == null) continue;

                        if (msg.ContainsKey("id") && msg["id"] != null)
                        {
                            int id = Convert.ToInt32(msg["id"]);
                            TaskCompletionSource<Dictionary<string, object>> tcs;
                            if (_pending.TryRemove(id, out tcs))
                            {
                                tcs.TrySetResult(msg);
                            }
                        }
                        else if (msg.ContainsKey("method"))
                        {
                            string method = Convert.ToString(msg["method"] ?? "");
                            if (method == "Browser.downloadWillBegin" || method == "Browser.downloadProgress")
                            {
                                Dictionary<string, object> p = msg.ContainsKey("params") ? msg["params"] as Dictionary<string, object> : null;
                                if (p != null && p.ContainsKey("guid"))
                                {
                                    string guid = Convert.ToString(p["guid"] ?? "");
                                    string state = p.ContainsKey("state") ? Convert.ToString(p["state"] ?? "inProgress") : "inProgress";
                                    if (!string.IsNullOrEmpty(guid))
                                    {
                                        _downloadGuidState[guid] = state;
                                    }
                                }
                            }
                            else if (method == "Page.fileChooserOpened")
                            {
                                Dictionary<string, object> p = msg.ContainsKey("params") ? msg["params"] as Dictionary<string, object> : null;
                                TaskCompletionSource<Dictionary<string, object>> fcTcs = _fileChooserTcs;
                                if (fcTcs != null && p != null)
                                {
                                    fcTcs.TrySetResult(p);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                FailAllPending(ex);
            }
        }

        private void FailAllPending(Exception ex)
        {
            foreach (KeyValuePair<int, TaskCompletionSource<Dictionary<string, object>>> kv in _pending)
            {
                TaskCompletionSource<Dictionary<string, object>> tcs;
                if (_pending.TryRemove(kv.Key, out tcs))
                {
                    tcs.TrySetException(ex);
                }
            }
            TaskCompletionSource<Dictionary<string, object>> fc = _fileChooserTcs;
            if (fc != null)
            {
                fc.TrySetException(ex);
            }
        }

        public void CancelCurrentActivity()
        {
            try
            {
                foreach (KeyValuePair<int, TaskCompletionSource<Dictionary<string, object>>> kv in _pending)
                {
                    TaskCompletionSource<Dictionary<string, object>> tcs;
                    if (_pending.TryRemove(kv.Key, out tcs))
                    {
                        tcs.TrySetCanceled();
                    }
                }
                TaskCompletionSource<Dictionary<string, object>> fc = _fileChooserTcs;
                if (fc != null)
                {
                    fc.TrySetCanceled();
                }
                TaskCompletionSource<bool> sig;
                lock (_reloadSignalLock)
                {
                    _reloadAndResumeRequested = false;
                    _reloadRequestReason = "";
                    sig = _reloadSignalTcs;
                }
                if (sig != null)
                {
                    sig.TrySetCanceled();
                }
                if (_ws != null && _ws.State == WebSocketState.Connecting)
                {
                    CleanupSocketOnly();
                }
            }
            catch { }
        }

        public async Task<Dictionary<string, object>> SendCommandAsync(
            string method,
            Dictionary<string, object> parameters = null,
            string sessionId = null,
            int timeoutMs = 25000,
            CancellationToken ct = default(CancellationToken))
        {
            await EnsureConnectedAsync(ct);

            int id = Interlocked.Increment(ref _nextId);
            TaskCompletionSource<Dictionary<string, object>> tcs =
                new TaskCompletionSource<Dictionary<string, object>>(TaskCreationOptions.RunContinuationsAsynchronously);
            _pending[id] = tcs;

            Dictionary<string, object> payload = new Dictionary<string, object>();
            payload["id"] = id;
            payload["method"] = method;
            payload["params"] = parameters ?? new Dictionary<string, object>();
            if (!string.IsNullOrEmpty(sessionId))
            {
                payload["sessionId"] = sessionId;
            }

            string json = CreateSerializer().Serialize(payload);
            byte[] bytes = Encoding.UTF8.GetBytes(json);

            await _sendLock.WaitAsync(ct);
            try
            {
                await _ws.SendAsync(new ArraySegment<byte>(bytes), WebSocketMessageType.Text, true, ct);
            }
            finally
            {
                _sendLock.Release();
            }

            using (CancellationTokenSource timeoutCts = CancellationTokenSource.CreateLinkedTokenSource(ct))
            {
                timeoutCts.CancelAfter(timeoutMs);
                using (timeoutCts.Token.Register(() =>
                {
                    TaskCompletionSource<Dictionary<string, object>> removed;
                    if (_pending.TryRemove(id, out removed))
                    {
                        removed.TrySetCanceled();
                    }
                }))
                {
                    Dictionary<string, object> resp = await tcs.Task;
                    if (resp.ContainsKey("error") && resp["error"] != null)
                    {
                        string errJson = CreateSerializer().Serialize(resp["error"]);
                        throw new InvalidOperationException(string.Format("Erro CDP em '{0}': {1}", method, errJson));
                    }
                    return resp.ContainsKey("result") && resp["result"] is Dictionary<string, object>
                        ? (Dictionary<string, object>)resp["result"]
                        : new Dictionary<string, object>();
                }
            }
        }

        private static string GetUserDownloadsFolderPath()
        {
            return Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),
                "Downloads");
        }

        private static Dictionary<string, DateTime> CaptureDirectoryTimestampMap(string dirPath)
        {
            Dictionary<string, DateTime> map = new Dictionary<string, DateTime>(StringComparer.OrdinalIgnoreCase);
            try
            {
                if (!string.IsNullOrEmpty(dirPath) && Directory.Exists(dirPath))
                {
                    string[] files = Directory.GetFiles(dirPath);
                    for (int i = 0; i < files.Length; i++)
                    {
                        string f = files[i];
                        try
                        {
                            map[f] = File.GetLastWriteTimeUtc(f);
                        }
                        catch { }
                    }
                }
            }
            catch { }
            return map;
        }

        private async Task<List<string>> CollectKnownBrowserContextIdsAsync(CancellationToken ct)
        {
            HashSet<string> ids = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (string ctxId in _profileToContextId.Values)
            {
                if (!string.IsNullOrWhiteSpace(ctxId))
                    ids.Add(ctxId.Trim());
            }

            try
            {
                List<CdpTargetInfo> targets = await GetTargetsAsync(ct);
                for (int i = 0; i < targets.Count; i++)
                {
                    string tCtx = targets[i].BrowserContextId;
                    if (!string.IsNullOrWhiteSpace(tCtx))
                        ids.Add(tCtx.Trim());
                }
            }
            catch { }

            return ids.ToList();
        }

        public async Task SetDownloadBehaviorAsync(string downloadDirectory, CancellationToken ct)
        {
            if (!Directory.Exists(downloadDirectory))
                Directory.CreateDirectory(downloadDirectory);

            string userDownloads = GetUserDownloadsFolderPath();
            Dictionary<string, DateTime> snap = CaptureDirectoryTimestampMap(userDownloads);
            lock (_downloadSnapshotLock)
            {
                _preDownloadUserDownloadsMap = snap;
                _lastSetDownloadUtc = DateTime.UtcNow;
            }

            // 1. Aplica ao contexto padrão (Default profile)
            await SendCommandAsync("Browser.setDownloadBehavior", new Dictionary<string, object>
            {
                { "behavior", "allow" },
                { "downloadPath", downloadDirectory },
                { "eventsEnabled", true }
            }, null, 15000, ct);

            // 2. Aplica também a todos os BrowserContextIds ativos (Profile 1, Profile 2, etc.)
            List<string> contextIds = await CollectKnownBrowserContextIdsAsync(ct);
            for (int i = 0; i < contextIds.Count; i++)
            {
                string ctxId = contextIds[i];
                try
                {
                    await SendCommandAsync("Browser.setDownloadBehavior", new Dictionary<string, object>
                    {
                        { "behavior", "allow" },
                        { "downloadPath", downloadDirectory },
                        { "browserContextId", ctxId },
                        { "eventsEnabled", true }
                    }, null, 6000, ct);
                }
                catch { }
            }

            // 3. Reforço por sessão ativa (Page.setDownloadBehavior) caso suportado pelo alvo atual
            string sessionId = _activeSessionId;
            if (!string.IsNullOrWhiteSpace(sessionId))
            {
                try
                {
                    await SendCommandAsync("Page.setDownloadBehavior", new Dictionary<string, object>
                    {
                        { "behavior", "allow" },
                        { "downloadPath", downloadDirectory }
                    }, sessionId, 5000, ct);
                }
                catch { }
            }
        }

        public async Task ResetDownloadBehaviorToDefaultAsync()
        {
            try
            {
                if (!IsConnected)
                    return;

                string userDownloads = GetUserDownloadsFolderPath();
                if (!Directory.Exists(userDownloads))
                    Directory.CreateDirectory(userDownloads);

                await SendCommandAsync("Browser.setDownloadBehavior", new Dictionary<string, object>
                {
                    { "behavior", "allow" },
                    { "downloadPath", userDownloads },
                    { "eventsEnabled", false }
                }, null, 4000, CancellationToken.None).ConfigureAwait(false);

                await SendCommandAsync("Browser.setDownloadBehavior", new Dictionary<string, object>
                {
                    { "behavior", "default" }
                }, null, 4000, CancellationToken.None).ConfigureAwait(false);

                List<string> contextIds = await CollectKnownBrowserContextIdsAsync(CancellationToken.None).ConfigureAwait(false);
                for (int i = 0; i < contextIds.Count; i++)
                {
                    string ctxId = contextIds[i];
                    try
                    {
                        await SendCommandAsync("Browser.setDownloadBehavior", new Dictionary<string, object>
                        {
                            { "behavior", "allow" },
                            { "downloadPath", userDownloads },
                            { "browserContextId", ctxId },
                            { "eventsEnabled", false }
                        }, null, 3000, CancellationToken.None).ConfigureAwait(false);

                        await SendCommandAsync("Browser.setDownloadBehavior", new Dictionary<string, object>
                        {
                            { "behavior", "default" },
                            { "browserContextId", ctxId }
                        }, null, 3000, CancellationToken.None).ConfigureAwait(false);
                    }
                    catch { }
                }

                string sessionId = _activeSessionId;
                if (!string.IsNullOrWhiteSpace(sessionId))
                {
                    try
                    {
                        await SendCommandAsync("Page.setDownloadBehavior", new Dictionary<string, object>
                        {
                            { "behavior", "default" }
                        }, sessionId, 3000, CancellationToken.None).ConfigureAwait(false);
                    }
                    catch { }
                }
            }
            catch { }
        }

        public async Task<List<CdpTargetInfo>> GetTargetsAsync(CancellationToken ct)
        {
            Dictionary<string, object> res = await SendCommandAsync("Target.getTargets", null, null, 15000, ct);
            List<CdpTargetInfo> list = new List<CdpTargetInfo>();
            if (!res.ContainsKey("targetInfos")) return list;

            IEnumerable rawList = res["targetInfos"] as IEnumerable;
            if (rawList == null) return list;

            foreach (object item in rawList)
            {
                Dictionary<string, object> d = item as Dictionary<string, object>;
                if (d == null) continue;
                list.Add(new CdpTargetInfo
                {
                    TargetId = d.ContainsKey("targetId") ? Convert.ToString(d["targetId"]) : "",
                    Type = d.ContainsKey("type") ? Convert.ToString(d["type"]) : "",
                    Title = d.ContainsKey("title") ? Convert.ToString(d["title"]) : "",
                    Url = d.ContainsKey("url") ? Convert.ToString(d["url"]) : "",
                    BrowserContextId = d.ContainsKey("browserContextId") ? Convert.ToString(d["browserContextId"]) : ""
                });
            }
            return list;
        }

        public async Task<string> OpenOrAttachProfileTabAsync(
            string profileDir,
            string targetUrl,
            string urlDomainMatch,
            bool forceReloadUrl,
            CancellationToken ct)
        {
            await EnsureConnectedAsync(ct);

            List<CdpTargetInfo> beforeTargets = await GetTargetsAsync(ct);
            CdpTargetInfo chosen = null;

            // 1. Se já conhecemos o browserContextId deste perfil nesta sessão, procure aba existente desse perfil
            string knownCtx;
            if (_profileToContextId.TryGetValue(profileDir, out knownCtx) && !string.IsNullOrEmpty(knownCtx))
            {
                chosen = beforeTargets.FirstOrDefault(t =>
                    t.Type == "page" &&
                    t.BrowserContextId == knownCtx &&
                    t.Url.IndexOf(urlDomainMatch, StringComparison.OrdinalIgnoreCase) >= 0);

                if (chosen == null)
                {
                    chosen = beforeTargets.FirstOrDefault(t => t.Type == "page" && t.BrowserContextId == knownCtx && !t.Url.StartsWith("devtools://"));
                }
            }

            // 2. Se já existir uma aba aberta anteriormente com a tag #fvs_<Perfil> (ou window.name / aba única do projeto Flow), reutilize sem abrir nova aba
            if (chosen == null)
            {
                string profKey = "fvs_" + profileDir.Replace(" ", "_");
                string profTagPrefix = "#" + profKey;
                chosen = beforeTargets.FirstOrDefault(t =>
                    t.Type == "page" &&
                    t.Url.IndexOf(profTagPrefix, StringComparison.OrdinalIgnoreCase) >= 0);

                if (chosen == null && urlDomainMatch.IndexOf("flow.google.com", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    chosen = beforeTargets.FirstOrDefault(t =>
                        t.Type == "page" &&
                        t.Url.IndexOf("flow.google.com/project/", StringComparison.OrdinalIgnoreCase) >= 0);
                }

                // Se o roteador SPA removeu o hash da URL (ex: /imagine/post/... ou /imagine/agent), verifica window.name nas abas do domínio
                if (chosen == null)
                {
                    HashSet<string> claimedContexts = new HashSet<string>(_profileToContextId.Values, StringComparer.OrdinalIgnoreCase);
                    List<CdpTargetInfo> domainCandidates = beforeTargets
                        .Where(t => t.Type == "page" &&
                                    t.Url.IndexOf(urlDomainMatch, StringComparison.OrdinalIgnoreCase) >= 0 &&
                                    (string.IsNullOrEmpty(t.BrowserContextId) || !claimedContexts.Contains(t.BrowserContextId)))
                        .ToList();

                    foreach (CdpTargetInfo cand in domainCandidates)
                    {
                        try
                        {
                            Dictionary<string, object> tmpAttach = await SendCommandAsync("Target.attachToTarget", new Dictionary<string, object>
                            {
                                { "targetId", cand.TargetId },
                                { "flatten", true }
                            }, null, 6000, ct);
                            string tmpSess = Convert.ToString(tmpAttach["sessionId"] ?? "");
                            if (!string.IsNullOrEmpty(tmpSess))
                            {
                                string wName = await EvalStringAsync(tmpSess, "window.name || ''", ct);
                                if (wName.StartsWith(profKey, StringComparison.OrdinalIgnoreCase))
                                {
                                    chosen = cand;
                                    break;
                                }
                            }
                        }
                        catch { }
                    }
                }

                if (chosen != null && !string.IsNullOrEmpty(chosen.BrowserContextId))
                {
                    _profileToContextId[profileDir] = chosen.BrowserContextId;
                }
            }

            // 3. Caso contrário, abra uma janela dedicada do perfil via WMI com tag no hash para rastrear 100% o browserContextId do perfil
            // IMPORTANTE: No Google Flow (flow.google.com), NUNCA injetar #fvs_ na URL nem alterar window.name (evita falso-positivo de extensão/BotGuard!)
            bool isFlowDomain = targetUrl.IndexOf("flow.google.com", StringComparison.OrdinalIgnoreCase) >= 0;
            bool openedNewWindow = false;
            if (chosen == null)
            {
                openedNewWindow = true;
                HashSet<string> oldIds = new HashSet<string>(beforeTargets.Select(t => t.TargetId));
                string tag = "fvs_" + profileDir.Replace(" ", "_") + "_" + Guid.NewGuid().ToString("N").Substring(0, 6);
                string launchUrl = (isFlowDomain || targetUrl.Contains("#")) ? targetUrl : (targetUrl + "#" + tag);

                _log(string.Format("[Chrome] Abrindo perfil '{0}' em '{1}' via WMI e aguardando carregamento completo da guia...", profileDir, targetUrl));
                LaunchChromeProfileWindow(profileDir, launchUrl);

                for (int i = 0; i < 50; i++)
                {
                    ct.ThrowIfCancellationRequested();
                    await Task.Delay(550, ct);
                    List<CdpTargetInfo> nowTargets = await GetTargetsAsync(ct);

                    if (!isFlowDomain)
                    {
                        chosen = nowTargets.FirstOrDefault(t =>
                            t.Type == "page" &&
                            t.Url.IndexOf(tag, StringComparison.OrdinalIgnoreCase) >= 0);
                    }

                    if (chosen == null)
                    {
                        chosen = nowTargets.FirstOrDefault(t =>
                            t.Type == "page" &&
                            !oldIds.Contains(t.TargetId) &&
                            t.Url.IndexOf(urlDomainMatch, StringComparison.OrdinalIgnoreCase) >= 0);
                    }

                    if (chosen != null)
                    {
                        if (!string.IsNullOrEmpty(chosen.BrowserContextId))
                            _profileToContextId[profileDir] = chosen.BrowserContextId;
                        break;
                    }
                }
            }

            if (chosen == null)
            {
                throw new InvalidOperationException(string.Format("Não foi possível localizar/abrir aba para '{0}' ({1}).", profileDir, targetUrl));
            }

            _profileToLastTargetId[profileDir] = chosen.TargetId;

            Dictionary<string, object> attachRes = await SendCommandAsync("Target.attachToTarget", new Dictionary<string, object>
            {
                { "targetId", chosen.TargetId },
                { "flatten", true }
            }, null, 15000, ct);

            string sessionId = Convert.ToString(attachRes["sessionId"]);
            await SendCommandAsync("Page.enable", null, sessionId, 10000, ct);
            await SendCommandAsync("Runtime.enable", null, sessionId, 10000, ct);
            await SendCommandAsync("DOM.enable", null, sessionId, 10000, ct);
            await SendCommandAsync("Page.bringToFront", null, sessionId, 10000, ct);

            string navTargetUrl = (isFlowDomain || targetUrl.Contains("#"))
                ? targetUrl
                : (targetUrl + "#fvs_" + profileDir.Replace(" ", "_"));

            bool didNavigate = false;
            if (forceReloadUrl || chosen.Url.IndexOf(urlDomainMatch, StringComparison.OrdinalIgnoreCase) < 0)
            {
                didNavigate = true;
                await SendCommandAsync("Page.navigate", new Dictionary<string, object> { { "url", navTargetUrl } }, sessionId, 25000, ct);
                await Task.Delay(1200, ct);
            }

            await WaitForDocumentReadyAsync(sessionId, 30000, ct);
            if (openedNewWindow || didNavigate)
            {
                await Task.Delay(3200, ct);
            }
            else
            {
                await Task.Delay(1200, ct);
            }

            if (!isFlowDomain)
            {
                try
                {
                    await EvalStringAsync(sessionId, string.Format("window.name = 'fvs_{0}';", profileDir.Replace(" ", "_")), ct);
                }
                catch { }
            }
            _activeSessionId = sessionId;
            return sessionId;
        }

        public async Task ReloadPageAndWaitReadyAsync(string sessionId, int timeoutMs, CancellationToken ct)
        {
            string targetSess = !string.IsNullOrEmpty(sessionId) ? sessionId : _activeSessionId;
            if (string.IsNullOrEmpty(targetSess))
                return;

            try
            {
                await SendCommandAsync("Page.bringToFront", null, targetSess, 8000, ct);
            }
            catch { }

            await SendCommandAsync("Page.reload", new Dictionary<string, object> { { "ignoreCache", false } }, targetSess, 20000, ct);
            await Task.Delay(1600, ct);
            await WaitForDocumentReadyAsync(targetSess, timeoutMs, ct);
            await Task.Delay(1800, ct);
        }

        public async Task WaitForDocumentReadyAsync(string sessionId, int timeoutMs, CancellationToken ct)
        {
            DateTime start = DateTime.UtcNow;
            DateTime deadline = start.AddMilliseconds(timeoutMs);
            while (DateTime.UtcNow < deadline)
            {
                ct.ThrowIfCancellationRequested();
                string st = await EvalStringAsync(sessionId, @"
(function(){
    var rs = document.readyState || '';
    var href = location.href || '';
    if (href === 'about:blank' || href === '') return 'BLANK';
    var hasBody = !!(document.body && document.body.children && document.body.children.length > 0 && (document.body.innerText || '').trim().length > 10);
    if (rs === 'complete' && hasBody) return 'COMPLETE_READY';
    if (rs === 'complete') return 'COMPLETE';
    return rs;
})()", ct);
                double elapsedMs = (DateTime.UtcNow - start).TotalMilliseconds;
                if (st == "COMPLETE_READY" || (st == "COMPLETE" && elapsedMs >= 2500))
                {
                    await Task.Delay(2200, ct);
                    return;
                }
                await Task.Delay(500, ct);
            }
        }

        public async Task<object> EvalObjectAsync(string sessionId, string jsExpression, CancellationToken ct, int timeoutMs = 25000)
        {
            Dictionary<string, object> res = await SendCommandAsync("Runtime.evaluate", new Dictionary<string, object>
            {
                { "expression", jsExpression },
                { "returnByValue", true },
                { "awaitPromise", true }
            }, sessionId, timeoutMs, ct);

            if (res.ContainsKey("exceptionDetails") && res["exceptionDetails"] != null)
            {
                return null;
            }

            if (res.ContainsKey("result") && res["result"] is Dictionary<string, object>)
            {
                Dictionary<string, object> r = (Dictionary<string, object>)res["result"];
                return r.ContainsKey("value") ? r["value"] : null;
            }
            return null;
        }

        public async Task<string> EvalStringAsync(string sessionId, string jsExpression, CancellationToken ct, int timeoutMs = 25000)
        {
            object v = await EvalObjectAsync(sessionId, jsExpression, ct, timeoutMs);
            return v == null ? "" : Convert.ToString(v);
        }

        public async Task<Dictionary<string, object>> EvalJsonAsync(string sessionId, string jsReturningJsonString, CancellationToken ct, int timeoutMs = 25000)
        {
            string raw = await EvalStringAsync(sessionId, jsReturningJsonString, ct, timeoutMs);
            if (string.IsNullOrWhiteSpace(raw)) return null;
            try
            {
                return CreateSerializer().Deserialize<Dictionary<string, object>>(raw);
            }
            catch
            {
                return null;
            }
        }

        public async Task HoverAsync(string sessionId, int x, int y, CancellationToken ct)
        {
            await SendCommandAsync("Input.dispatchMouseEvent", new Dictionary<string, object>
            {
                { "type", "mouseMoved" },
                { "x", x },
                { "y", y },
                { "button", "none" }
            }, sessionId, 10000, ct);
        }

        public async Task ClickAtAsync(string sessionId, int x, int y, CancellationToken ct)
        {
            await HoverAsync(sessionId, x, y, ct);
            await Task.Delay(50, ct);
            await SendCommandAsync("Input.dispatchMouseEvent", new Dictionary<string, object>
            {
                { "type", "mousePressed" },
                { "x", x },
                { "y", y },
                { "button", "left" },
                { "clickCount", 1 }
            }, sessionId, 10000, ct);
            await Task.Delay(65, ct);
            await SendCommandAsync("Input.dispatchMouseEvent", new Dictionary<string, object>
            {
                { "type", "mouseReleased" },
                { "x", x },
                { "y", y },
                { "button", "left" },
                { "clickCount", 1 }
            }, sessionId, 10000, ct);
        }

        public async Task PressEnterAsync(string sessionId, CancellationToken ct)
        {
            await SendCommandAsync("Input.dispatchKeyEvent", new Dictionary<string, object>
            {
                { "type", "keyDown" },
                { "key", "Enter" },
                { "code", "Enter" },
                { "windowsVirtualKeyCode", 13 },
                { "nativeVirtualKeyCode", 13 }
            }, sessionId, 10000, ct);
            await Task.Delay(50, ct);
            await SendCommandAsync("Input.dispatchKeyEvent", new Dictionary<string, object>
            {
                { "type", "keyUp" },
                { "key", "Enter" },
                { "code", "Enter" },
                { "windowsVirtualKeyCode", 13 },
                { "nativeVirtualKeyCode", 13 }
            }, sessionId, 10000, ct);
        }

        public async Task PressEscapeAsync(string sessionId, CancellationToken ct)
        {
            await SendCommandAsync("Input.dispatchKeyEvent", new Dictionary<string, object>
            {
                { "type", "keyDown" },
                { "key", "Escape" },
                { "code", "Escape" },
                { "windowsVirtualKeyCode", 27 },
                { "nativeVirtualKeyCode", 27 }
            }, sessionId, 10000, ct);
            await Task.Delay(50, ct);
            await SendCommandAsync("Input.dispatchKeyEvent", new Dictionary<string, object>
            {
                { "type", "keyUp" },
                { "key", "Escape" },
                { "code", "Escape" },
                { "windowsVirtualKeyCode", 27 },
                { "nativeVirtualKeyCode", 27 }
            }, sessionId, 10000, ct);
        }

        public async Task InsertTextAsync(string sessionId, string text, CancellationToken ct)
        {
            if (string.IsNullOrEmpty(text))
                return;

            await SendCommandAsync("Input.insertText", new Dictionary<string, object>
            {
                { "text", text }
            }, sessionId, 15000, ct);
        }

        public async Task SelectAllAndBackspaceAsync(string sessionId, CancellationToken ct)
        {
            await SendCommandAsync("Input.dispatchKeyEvent", new Dictionary<string, object>
            {
                { "type", "keyDown" },
                { "modifiers", 2 },
                { "key", "a" },
                { "code", "KeyA" },
                { "windowsVirtualKeyCode", 65 },
                { "nativeVirtualKeyCode", 65 }
            }, sessionId, 10000, ct);
            await Task.Delay(35, ct);
            await SendCommandAsync("Input.dispatchKeyEvent", new Dictionary<string, object>
            {
                { "type", "keyUp" },
                { "modifiers", 2 },
                { "key", "a" },
                { "code", "KeyA" },
                { "windowsVirtualKeyCode", 65 },
                { "nativeVirtualKeyCode", 65 }
            }, sessionId, 10000, ct);
            await Task.Delay(45, ct);
            await SendCommandAsync("Input.dispatchKeyEvent", new Dictionary<string, object>
            {
                { "type", "keyDown" },
                { "key", "Backspace" },
                { "code", "Backspace" },
                { "windowsVirtualKeyCode", 8 },
                { "nativeVirtualKeyCode", 8 }
            }, sessionId, 10000, ct);
            await Task.Delay(35, ct);
            await SendCommandAsync("Input.dispatchKeyEvent", new Dictionary<string, object>
            {
                { "type", "keyUp" },
                { "key", "Backspace" },
                { "code", "Backspace" },
                { "windowsVirtualKeyCode", 8 },
                { "nativeVirtualKeyCode", 8 }
            }, sessionId, 10000, ct);
        }

        public async Task<bool> SetFileInputFilesAsync(string sessionId, string cssSelector, IEnumerable<string> filePaths, CancellationToken ct)
        {
            Dictionary<string, object> docRes = await SendCommandAsync("DOM.getDocument", new Dictionary<string, object> { { "depth", 1 } }, sessionId, 15000, ct);
            Dictionary<string, object> root = docRes.ContainsKey("root") ? docRes["root"] as Dictionary<string, object> : null;
            if (root == null || !root.ContainsKey("nodeId")) return false;

            int rootNodeId = Convert.ToInt32(root["nodeId"]);
            Dictionary<string, object> qRes = await SendCommandAsync("DOM.querySelector", new Dictionary<string, object>
            {
                { "nodeId", rootNodeId },
                { "selector", cssSelector }
            }, sessionId, 15000, ct);

            int inputNodeId = qRes.ContainsKey("nodeId") ? Convert.ToInt32(qRes["nodeId"]) : 0;
            if (inputNodeId <= 0) return false;

            await SendCommandAsync("DOM.setFileInputFiles", new Dictionary<string, object>
            {
                { "nodeId", inputNodeId },
                { "files", filePaths.ToArray() }
            }, sessionId, 25000, ct);
            return true;
        }

        public async Task<bool> SetFileInputFilesByObjectIdAsync(
            string sessionId,
            string jsInputExpression,
            IEnumerable<string> filePaths,
            CancellationToken ct)
        {
            string[] files = filePaths.Where(f => !string.IsNullOrEmpty(f) && File.Exists(f)).ToArray();
            if (files.Length == 0) return true;

            Dictionary<string, object> evalRes = await SendCommandAsync("Runtime.evaluate", new Dictionary<string, object>
            {
                { "expression", jsInputExpression },
                { "returnByValue", false }
            }, sessionId, 12000, ct);

            Dictionary<string, object> resObj = evalRes.ContainsKey("result") ? evalRes["result"] as Dictionary<string, object> : null;
            string objId = (resObj != null && resObj.ContainsKey("objectId")) ? Convert.ToString(resObj["objectId"] ?? "") : "";
            if (string.IsNullOrEmpty(objId))
                return false;

            await SendCommandAsync("DOM.setFileInputFiles", new Dictionary<string, object>
            {
                { "objectId", objId },
                { "files", files }
            }, sessionId, 25000, ct);
            return true;
        }

        public async Task<bool> UploadFilesViaFileChooserAsync(
            string sessionId,
            Func<Task> triggerClickAction,
            IEnumerable<string> filePaths,
            CancellationToken ct)
        {
            string[] files = filePaths.Where(f => !string.IsNullOrEmpty(f) && File.Exists(f)).ToArray();
            if (files.Length == 0) return true;

            TaskCompletionSource<Dictionary<string, object>> tcs =
                new TaskCompletionSource<Dictionary<string, object>>(TaskCreationOptions.RunContinuationsAsynchronously);
            _fileChooserTcs = tcs;

            await SendCommandAsync("Page.setInterceptFileChooserDialog", new Dictionary<string, object>
            {
                { "enabled", true }
            }, sessionId, 10000, ct);

            bool success = false;
            Exception capturedError = null;

            try
            {
                await triggerClickAction();
                Task winner = await Task.WhenAny(tcs.Task, Task.Delay(8000, ct));
                if (winner == tcs.Task)
                {
                    Dictionary<string, object> fcParams = await tcs.Task;
                    if (fcParams != null && fcParams.ContainsKey("backendNodeId"))
                    {
                        int backendNodeId = Convert.ToInt32(fcParams["backendNodeId"]);
                        string mode = fcParams.ContainsKey("mode") ? Convert.ToString(fcParams["mode"] ?? "") : "selectMultiple";

                        if (string.Equals(mode, "selectSingle", StringComparison.OrdinalIgnoreCase) && files.Length > 1)
                        {
                            await SendCommandAsync("DOM.setFileInputFiles", new Dictionary<string, object>
                            {
                                { "backendNodeId", backendNodeId },
                                { "files", new string[] { files[0] } }
                            }, sessionId, 25000, ct);

                            for (int i = 1; i < files.Length; i++)
                            {
                                await Task.Delay(700, ct);
                                TaskCompletionSource<Dictionary<string, object>> nextTcs =
                                    new TaskCompletionSource<Dictionary<string, object>>(TaskCreationOptions.RunContinuationsAsynchronously);
                                _fileChooserTcs = nextTcs;
                                await triggerClickAction();
                                Task w2 = await Task.WhenAny(nextTcs.Task, Task.Delay(8000, ct));
                                if (w2 != nextTcs.Task) break;
                                Dictionary<string, object> p2 = await nextTcs.Task;
                                if (p2 != null && p2.ContainsKey("backendNodeId"))
                                {
                                    await SendCommandAsync("DOM.setFileInputFiles", new Dictionary<string, object>
                                    {
                                        { "backendNodeId", Convert.ToInt32(p2["backendNodeId"]) },
                                        { "files", new string[] { files[i] } }
                                    }, sessionId, 25000, ct);
                                }
                            }
                            success = true;
                        }
                        else
                        {
                            await SendCommandAsync("DOM.setFileInputFiles", new Dictionary<string, object>
                            {
                                { "backendNodeId", backendNodeId },
                                { "files", files }
                            }, sessionId, 30000, ct);
                            success = true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                capturedError = ex;
            }

            _fileChooserTcs = null;
            try
            {
                await SendCommandAsync("Page.setInterceptFileChooserDialog", new Dictionary<string, object>
                {
                    { "enabled", false }
                }, sessionId, 8000, ct);
            }
            catch { }

            if (capturedError != null)
            {
                OperationCanceledException oce = capturedError as OperationCanceledException;
                if (oce != null) throw oce;
                throw capturedError;
            }

            return success;
        }

        private static bool IsExpectedFallbackExtension(string filePath, string downloadDir)
        {
            string ext = (Path.GetExtension(filePath) ?? "").ToLowerInvariant();
            if (string.IsNullOrEmpty(ext))
                return false;

            string dirLeaf = (Path.GetFileName(downloadDir.TrimEnd('\\', '/')) ?? "").ToLowerInvariant();
            if (dirLeaf.Contains("_grok_vid") || dirLeaf.Contains("_flow_dl") || dirLeaf.Contains("_flow_salvage"))
            {
                return ext == ".mp4" || ext == ".webm" || ext == ".mov";
            }

            if (dirLeaf.Contains("_eleven_dl"))
            {
                return ext == ".mp3" || ext == ".wav" || ext == ".m4a" || ext == ".aac" || ext == ".ogg" || ext == ".mpeg";
            }

            if (dirLeaf.Contains("_grok_staging") || dirLeaf.Contains("_grok_var") || dirLeaf.Contains("_grok_outfit") ||
                dirLeaf.Contains("fluxo_img_dl") || dirLeaf.Contains("fluxo_dl_rem"))
            {
                return ext == ".jpg" || ext == ".jpeg" || ext == ".png" || ext == ".webp";
            }

            return ext == ".mp4" || ext == ".webm" || ext == ".mov" ||
                   ext == ".jpg" || ext == ".jpeg" || ext == ".png" || ext == ".webp" ||
                   ext == ".mp3" || ext == ".wav" || ext == ".m4a" || ext == ".aac" || ext == ".ogg" || ext == ".mpeg";
        }

        public async Task<string> WaitForSingleDownloadAsync(
            string downloadDir,
            HashSet<string> existingFilesSnapshot,
            long minFileSizeBytes,
            int timeoutMs,
            CancellationToken ct)
        {
            DateTime entryUtc = DateTime.UtcNow;
            DateTime deadline = entryUtc.AddMilliseconds(timeoutMs);
            string userDownloads = GetUserDownloadsFolderPath();
            Dictionary<string, DateTime> entryUserDownloadsMap = CaptureDirectoryTimestampMap(userDownloads);

            bool canFallbackToUserDownloads = false;
            try
            {
                if (!string.IsNullOrWhiteSpace(userDownloads) && !string.IsNullOrWhiteSpace(downloadDir))
                {
                    string normTarget = Path.GetFullPath(downloadDir).TrimEnd('\\', '/');
                    string normUserDl = Path.GetFullPath(userDownloads).TrimEnd('\\', '/');
                    canFallbackToUserDownloads = !string.Equals(normTarget, normUserDl, StringComparison.OrdinalIgnoreCase);
                }
            }
            catch { }

            while (DateTime.UtcNow < deadline)
            {
                ct.ThrowIfCancellationRequested();
                await Task.Delay(550, ct);

                if (Directory.Exists(downloadDir))
                {
                    string[] allFiles = Directory.GetFiles(downloadDir);
                    bool hasCrDownload = allFiles.Any(f =>
                        f.EndsWith(".crdownload", StringComparison.OrdinalIgnoreCase) ||
                        f.EndsWith(".tmp", StringComparison.OrdinalIgnoreCase));

                    if (!hasCrDownload)
                    {
                        foreach (string f in allFiles.OrderByDescending(x => File.GetLastWriteTimeUtc(x)))
                        {
                            if (existingFilesSnapshot != null && existingFilesSnapshot.Contains(f)) continue;
                            try
                            {
                                FileInfo fi = new FileInfo(f);
                                if (fi.Exists && fi.Length >= minFileSizeBytes)
                                {
                                    // Garante que o Chrome soltou o handle de escrita
                                    using (FileStream fs = new FileStream(f, FileMode.Open, FileAccess.Read, FileShare.Read))
                                    {
                                        if (fs.Length >= minFileSizeBytes)
                                            return f;
                                    }
                                }
                            }
                            catch { }
                        }
                    }
                }

                // Rede de segurança: se um perfil secundário do Chrome ignorou o stagingDir e salvou em Downloads,
                // resgatamos apenas arquivos novos gerados após o início deste fluxo de download.
                if (canFallbackToUserDownloads && Directory.Exists(userDownloads))
                {
                    try
                    {
                        Dictionary<string, DateTime> baselineMap;
                        DateTime cutoffUtc;
                        lock (_downloadSnapshotLock)
                        {
                            if (_lastSetDownloadUtc != DateTime.MinValue &&
                                (entryUtc - _lastSetDownloadUtc).TotalMinutes <= 15)
                            {
                                baselineMap = new Dictionary<string, DateTime>(_preDownloadUserDownloadsMap, StringComparer.OrdinalIgnoreCase);
                                cutoffUtc = _lastSetDownloadUtc.AddSeconds(-2);
                            }
                            else
                            {
                                baselineMap = entryUserDownloadsMap;
                                cutoffUtc = entryUtc.AddSeconds(-2);
                            }
                        }

                        string[] dlFiles = Directory.GetFiles(userDownloads);
                        bool hasRecentCrDownload = false;
                        for (int i = 0; i < dlFiles.Length; i++)
                        {
                            string cand = dlFiles[i];
                            if (cand.EndsWith(".crdownload", StringComparison.OrdinalIgnoreCase) ||
                                cand.EndsWith(".tmp", StringComparison.OrdinalIgnoreCase))
                            {
                                try
                                {
                                    if (File.GetLastWriteTimeUtc(cand) >= cutoffUtc)
                                    {
                                        hasRecentCrDownload = true;
                                        break;
                                    }
                                }
                                catch { }
                            }
                        }

                        if (!hasRecentCrDownload)
                        {
                            foreach (string f in dlFiles.OrderByDescending(x => File.GetLastWriteTimeUtc(x)))
                            {
                                if (!IsExpectedFallbackExtension(f, downloadDir))
                                    continue;

                                try
                                {
                                    FileInfo fi = new FileInfo(f);
                                    if (!fi.Exists || fi.Length < minFileSizeBytes)
                                        continue;

                                    DateTime writeUtc = fi.LastWriteTimeUtc;
                                    if (writeUtc < cutoffUtc)
                                        continue;

                                    DateTime prevWriteUtc;
                                    if (baselineMap.TryGetValue(f, out prevWriteUtc) && writeUtc <= prevWriteUtc)
                                        continue;

                                    using (FileStream fs = new FileStream(f, FileMode.Open, FileAccess.Read, FileShare.Read))
                                    {
                                        if (fs.Length < minFileSizeBytes)
                                            continue;
                                    }

                                    if (!Directory.Exists(downloadDir))
                                        Directory.CreateDirectory(downloadDir);

                                    string destName = Path.GetFileName(f);
                                    string destPath = Path.Combine(downloadDir, destName);
                                    if ((existingFilesSnapshot != null && existingFilesSnapshot.Contains(destPath)) || File.Exists(destPath))
                                    {
                                        destPath = Path.Combine(
                                            downloadDir,
                                            Path.GetFileNameWithoutExtension(destName) + "_" + DateTime.UtcNow.Ticks + Path.GetExtension(destName));
                                    }

                                    File.Move(f, destPath);
                                    lock (_downloadSnapshotLock)
                                    {
                                        _preDownloadUserDownloadsMap[f] = writeUtc;
                                    }

                                    if (_log != null)
                                    {
                                        _log("[CDP] Download capturado da pasta Downloads e movido para o lote -> " + Path.GetFileName(destPath));
                                    }

                                    return destPath;
                                }
                                catch { }
                            }
                        }
                    }
                    catch { }
                }
            }
            return "";
        }

        private void CleanupSocketOnly()
        {
            try { if (_rxCts != null) _rxCts.Cancel(); } catch { }
            try { if (_ws != null) _ws.Dispose(); } catch { }
            _ws = null;
            _rxCts = null;
        }

        public void Dispose()
        {
            CleanupSocketOnly();
        }
    }
}
