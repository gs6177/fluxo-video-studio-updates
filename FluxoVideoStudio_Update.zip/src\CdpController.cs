using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Management;
using System.Net.NetworkInformation;
using System.Net.WebSockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows.Automation;

namespace FluxoVideoStudio
{
    public class CdpTargetInfo
    {
        public string TargetId { get; set; }
        public string Type { get; set; }
        public string Title { get; set; }
        public string Url { get; set; }
        public string BrowserContextId { get; set; }
    }

    public class CdpController : IDisposable
    {
        private ClientWebSocket _ws;
        private CancellationTokenSource _rxCts;
        private readonly SemaphoreSlim _sendLock = new SemaphoreSlim(1, 1);
        private readonly SemaphoreSlim _connectLock = new SemaphoreSlim(1, 1);
        private readonly ConcurrentDictionary<int, TaskCompletionSource<Dictionary<string, object>>> _pending =
            new ConcurrentDictionary<int, TaskCompletionSource<Dictionary<string, object>>>();

        private readonly ConcurrentDictionary<string, string> _profileToContextId =
            new ConcurrentDictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        private readonly ConcurrentDictionary<string, string> _profileToLastTargetId =
            new ConcurrentDictionary<string, string>(StringComparer.OrdinalIgnoreCase);

        private readonly ConcurrentDictionary<string, string> _downloadGuidState =
            new ConcurrentDictionary<string, string>(StringComparer.OrdinalIgnoreCase);

        private volatile TaskCompletionSource<Dictionary<string, object>> _fileChooserTcs;

        private int _nextId = 100;
        private readonly Action<string> _log;
        private readonly PipelineConfig _config;

        public bool IsConnected
        {
            get { return _ws != null && _ws.State == WebSocketState.Open; }
        }

        public CdpController(PipelineConfig config, Action<string> logger)
        {
            _config = config;
            _log = logger ?? delegate { };
        }

        private JavaScriptSerializer CreateSerializer()
        {
            JavaScriptSerializer ser = new JavaScriptSerializer();
            ser.MaxJsonLength = int.MaxValue;
            ser.RecursionLimit = 256;
            return ser;
        }

        public static uint LaunchViaWmi(string commandLine)
        {
            using (ManagementClass procClass = new ManagementClass("Win32_Process"))
            {
                ManagementBaseObject inParams = procClass.GetMethodParameters("Create");
                inParams["CommandLine"] = commandLine;
                ManagementBaseObject outParams = procClass.InvokeMethod("Create", inParams, null);
                if (outParams != null && outParams["ReturnValue"] != null)
                {
                    return Convert.ToUInt32(outParams["ReturnValue"]);
                }
            }
            return 0;
        }

        public void LaunchChromeProfileWindow(string profileDir, string url)
        {
            string cmd = string.Format("\"{0}\" --profile-directory=\"{1}\" --new-window \"{2}\"",
                _config.ChromeExePath, profileDir, url);
            LaunchViaWmi(cmd);
        }

        private bool HasVisibleChromeWindow()
        {
            try
            {
                Process[] procs = Process.GetProcessesByName("chrome");
                foreach (Process p in procs)
                {
                    try
                    {
                        if (p.MainWindowHandle != IntPtr.Zero) return true;
                    }
                    catch { }
                }
            }
            catch { }
            return false;
        }

        private void KillOrphanChromeDevtoolsMcpProcesses()
        {
            try
            {
                using (ManagementObjectSearcher searcher = new ManagementObjectSearcher(
                    "SELECT ProcessId, CommandLine FROM Win32_Process WHERE Name = 'node.exe'"))
                {
                    foreach (ManagementObject obj in searcher.Get())
                    {
                        string cmd = Convert.ToString(obj["CommandLine"] ?? "");
                        if (cmd.IndexOf("chrome-devtools-mcp", StringComparison.OrdinalIgnoreCase) >= 0)
                        {
                            int pid = Convert.ToInt32(obj["ProcessId"]);
                            try
                            {
                                Process p = Process.GetProcessById(pid);
                                p.Kill();
                                _log(string.Format("[CDP] Encerrado processo órfão chrome-devtools-mcp (PID {0}) que segurava a porta 9222.", pid));
                            }
                            catch { }
                        }
                    }
                }
            }
            catch { }
        }

        private bool TryReadDevToolsPort(out int port, out string wsPath)
        {
            port = 0;
            wsPath = "";
            string portFile = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                @"Google\Chrome\User Data\DevToolsActivePort");

            if (!File.Exists(portFile)) return false;

            try
            {
                string[] lines = File.ReadAllLines(portFile);
                if (lines.Length < 2) return false;
                int parsedPort;
                if (!int.TryParse(lines[0].Trim(), out parsedPort)) return false;
                port = parsedPort;
                wsPath = lines[1].Trim();

                var listeners = IPGlobalProperties.GetIPGlobalProperties().GetActiveTcpListeners();
                bool isListening = listeners.Any(ep => ep.Port == parsedPort);
                return isListening;
            }
            catch
            {
                return false;
            }
        }

        private void TriggerSingleAutoAllow(int maxSeconds)
        {
            // Regra 0.1: Dispara UMA ÚNICA VEZ em background somente quando ConnectAsync aguarda autorização
            Task.Run(() =>
            {
                try
                {
                    DateTime deadline = DateTime.UtcNow.AddSeconds(maxSeconds);
                    bool waitedGuard = false;

                    while (DateTime.UtcNow < deadline)
                    {
                        bool foundAllow = false;
                        try
                        {
                            AutomationElement root = AutomationElement.RootElement;
                            TreeWalker walker = TreeWalker.ControlViewWalker;
                            AutomationElement win = walker.GetFirstChild(root);
                            while (win != null)
                            {
                                try
                                {
                                    if (win.Current.ClassName == "Chrome_WidgetWin_1")
                                    {
                                        if (ClickAllowButtonRecursive(walker, win, 0, ref waitedGuard))
                                        {
                                            foundAllow = true;
                                            break;
                                        }
                                    }
                                }
                                catch { }
                                win = walker.GetNextSibling(win);
                            }
                        }
                        catch { }

                        if (foundAllow)
                        {
                            return; // exit imediatamente após clicar 1 vez (Regra 0.1)
                        }
                        Thread.Sleep(250);
                    }
                }
                catch { }
            });

            // Fallback opcional com o script oficial via WMI caso UIPI exija sessão separada
            string autoAllowScript = Path.Combine(_config.SkillScriptsDir, "auto_allow_chrome.ps1");
            if (File.Exists(autoAllowScript))
            {
                string wmiCmd = string.Format(
                    "powershell.exe -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File \"{0}\" -DurationSeconds {1}",
                    autoAllowScript, Math.Min(20, maxSeconds));
                try { LaunchViaWmi(wmiCmd); } catch { }
            }
        }

        private bool ClickAllowButtonRecursive(TreeWalker walker, AutomationElement el, int depth, ref bool waitedGuard)
        {
            if (el == null || depth > 12) return false;
            try
            {
                ControlType ct = el.Current.ControlType;
                if (ct == ControlType.Document) return false;
                if (ct == ControlType.Button)
                {
                    string name = el.Current.Name ?? "";
                    if (string.Equals(name, "Permitir", StringComparison.OrdinalIgnoreCase) ||
                        string.Equals(name, "Allow", StringComparison.OrdinalIgnoreCase))
                    {
                        if (!waitedGuard)
                        {
                            // Respeita o input-jacking protection de 500ms do Chrome (550ms)
                            Thread.Sleep(550);
                            waitedGuard = true;
                        }
                        object patObj;
                        if (el.TryGetCurrentPattern(InvokePattern.Pattern, out patObj))
                        {
                            ((InvokePattern)patObj).Invoke();
                            return true;
                        }
                    }
                }

                AutomationElement child = walker.GetFirstChild(el);
                while (child != null)
                {
                    if (ClickAllowButtonRecursive(walker, child, depth + 1, ref waitedGuard))
                        return true;
                    child = walker.GetNextSibling(child);
                }
            }
            catch { }
            return false;
        }

        public async Task EnsureConnectedAsync(CancellationToken ct)
        {
            if (IsConnected) return;

            await _connectLock.WaitAsync(ct);
            try
            {
                if (IsConnected) return;

                int port;
                string wsPath;
                if (!TryReadDevToolsPort(out port, out wsPath))
                {
                    _log("[CDP] Abrindo janela visível do Google Chrome via WMI e aguardando DevToolsActivePort (porta 9222)...");
                    LaunchChromeProfileWindow(_config.FlowProfile, "about:blank");

                    for (int i = 0; i < 30; i++)
                    {
                        ct.ThrowIfCancellationRequested();
                        await Task.Delay(500, ct);
                        if (TryReadDevToolsPort(out port, out wsPath))
                            break;
                    }
                }

                if (!TryReadDevToolsPort(out port, out wsPath))
                {
                    throw new InvalidOperationException(
                        "Não foi possível localizar DevToolsActivePort ativo no Chrome. Verifique se 'chrome://inspect/#remote-debugging' (Discover network targets) está ativado.");
                }

                string wsUri = string.Format("ws://127.0.0.1:{0}{1}", port, wsPath);

                for (int attempt = 1; attempt <= 2; attempt++)
                {
                    CleanupSocketOnly();
                    _ws = new ClientWebSocket();
                    _rxCts = new CancellationTokenSource();
                    bool retryAfter403 = false;

                    try
                    {
                        Task connectTask = _ws.ConnectAsync(new Uri(wsUri), ct);
                        Task completed = await Task.WhenAny(connectTask, Task.Delay(650, ct));
                        if (completed != connectTask)
                        {
                            _log("[CDP] Autorizando popup 'Permitir depuração remota' silenciosamente (1x)...");
                            TriggerSingleAutoAllow(20);
                        }

                        await connectTask;
                        Task rxTask = Task.Run(() => ReceiveLoopAsync(_rxCts.Token));
                        if (rxTask != null) { }
                        _log(string.Format("[CDP] Conectado com sucesso ao Chrome WebSocket (Porta {0}) — conexão persistente ativa!", port));
                        return;
                    }
                    catch (Exception ex)
                    {
                        string msg = ex.ToString();
                        if (attempt == 1 && (msg.Contains("403") || msg.IndexOf("Forbidden", StringComparison.OrdinalIgnoreCase) >= 0 || msg.IndexOf("Proibido", StringComparison.OrdinalIgnoreCase) >= 0))
                        {
                            retryAfter403 = true;
                        }
                        else
                        {
                            throw;
                        }
                    }

                    if (retryAfter403)
                    {
                        _log("[CDP] Recebido 403 Proibido na porta 9222. Limpando conexões MCP órfãs e garantindo janela visível...");
                        KillOrphanChromeDevtoolsMcpProcesses();
                        if (!HasVisibleChromeWindow())
                        {
                            LaunchChromeProfileWindow(_config.FlowProfile, "about:blank");
                            await Task.Delay(2000, ct);
                        }
                        await Task.Delay(800, ct);
                        TryReadDevToolsPort(out port, out wsPath);
                        wsUri = string.Format("ws://127.0.0.1:{0}{1}", port, wsPath);
                    }
                }
            }
            finally
            {
                _connectLock.Release();
            }
        }

        private async Task ReceiveLoopAsync(CancellationToken ct)
        {
            byte[] buffer = new byte[65536];
            JavaScriptSerializer ser = CreateSerializer();

            try
            {
                while (!ct.IsCancellationRequested && _ws != null && _ws.State == WebSocketState.Open)
                {
                    using (MemoryStream ms = new MemoryStream())
                    {
                        WebSocketReceiveResult res;
                        do
                        {
                            res = await _ws.ReceiveAsync(new ArraySegment<byte>(buffer), ct);
                            if (res.MessageType == WebSocketMessageType.Close)
                            {
                                FailAllPending(new IOException("Conexão CDP WebSocket encerrada pelo navegador."));
                                return;
                            }
                            ms.Write(buffer, 0, res.Count);
                        } while (!res.EndOfMessage);

                        string json = Encoding.UTF8.GetString(ms.ToArray());
                        Dictionary<string, object> msg = null;
                        try
                        {
                            msg = ser.Deserialize<Dictionary<string, object>>(json);
                        }
                        catch { }

                        if (msg == null) continue;

                        if (msg.ContainsKey("id") && msg["id"] != null)
                        {
                            int id = Convert.ToInt32(msg["id"]);
                            TaskCompletionSource<Dictionary<string, object>> tcs;
                            if (_pending.TryRemove(id, out tcs))
                            {
                                tcs.TrySetResult(msg);
                            }
                        }
                        else if (msg.ContainsKey("method"))
                        {
                            string method = Convert.ToString(msg["method"] ?? "");
                            if (method == "Browser.downloadWillBegin" || method == "Browser.downloadProgress")
                            {
                                Dictionary<string, object> p = msg.ContainsKey("params") ? msg["params"] as Dictionary<string, object> : null;
                                if (p != null && p.ContainsKey("guid"))
                                {
                                    string guid = Convert.ToString(p["guid"] ?? "");
                                    string state = p.ContainsKey("state") ? Convert.ToString(p["state"] ?? "inProgress") : "inProgress";
                                    if (!string.IsNullOrEmpty(guid))
                                    {
                                        _downloadGuidState[guid] = state;
                                    }
                                }
                            }
                            else if (method == "Page.fileChooserOpened")
                            {
                                Dictionary<string, object> p = msg.ContainsKey("params") ? msg["params"] as Dictionary<string, object> : null;
                                TaskCompletionSource<Dictionary<string, object>> fcTcs = _fileChooserTcs;
                                if (fcTcs != null && p != null)
                                {
                                    fcTcs.TrySetResult(p);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                FailAllPending(ex);
            }
        }

        private void FailAllPending(Exception ex)
        {
            foreach (KeyValuePair<int, TaskCompletionSource<Dictionary<string, object>>> kv in _pending)
            {
                TaskCompletionSource<Dictionary<string, object>> tcs;
                if (_pending.TryRemove(kv.Key, out tcs))
                {
                    tcs.TrySetException(ex);
                }
            }
            TaskCompletionSource<Dictionary<string, object>> fc = _fileChooserTcs;
            if (fc != null)
            {
                fc.TrySetException(ex);
            }
        }

        public async Task<Dictionary<string, object>> SendCommandAsync(
            string method,
            Dictionary<string, object> parameters = null,
            string sessionId = null,
            int timeoutMs = 25000,
            CancellationToken ct = default(CancellationToken))
        {
            await EnsureConnectedAsync(ct);

            int id = Interlocked.Increment(ref _nextId);
            TaskCompletionSource<Dictionary<string, object>> tcs =
                new TaskCompletionSource<Dictionary<string, object>>(TaskCreationOptions.RunContinuationsAsynchronously);
            _pending[id] = tcs;

            Dictionary<string, object> payload = new Dictionary<string, object>();
            payload["id"] = id;
            payload["method"] = method;
            payload["params"] = parameters ?? new Dictionary<string, object>();
            if (!string.IsNullOrEmpty(sessionId))
            {
                payload["sessionId"] = sessionId;
            }

            string json = CreateSerializer().Serialize(payload);
            byte[] bytes = Encoding.UTF8.GetBytes(json);

            await _sendLock.WaitAsync(ct);
            try
            {
                await _ws.SendAsync(new ArraySegment<byte>(bytes), WebSocketMessageType.Text, true, ct);
            }
            finally
            {
                _sendLock.Release();
            }

            using (CancellationTokenSource timeoutCts = CancellationTokenSource.CreateLinkedTokenSource(ct))
            {
                timeoutCts.CancelAfter(timeoutMs);
                using (timeoutCts.Token.Register(() =>
                {
                    TaskCompletionSource<Dictionary<string, object>> removed;
                    if (_pending.TryRemove(id, out removed))
                    {
                        removed.TrySetCanceled();
                    }
                }))
                {
                    Dictionary<string, object> resp = await tcs.Task;
                    if (resp.ContainsKey("error") && resp["error"] != null)
                    {
                        string errJson = CreateSerializer().Serialize(resp["error"]);
                        throw new InvalidOperationException(string.Format("Erro CDP em '{0}': {1}", method, errJson));
                    }
                    return resp.ContainsKey("result") && resp["result"] is Dictionary<string, object>
                        ? (Dictionary<string, object>)resp["result"]
                        : new Dictionary<string, object>();
                }
            }
        }

        public async Task SetDownloadBehaviorAsync(string downloadDirectory, CancellationToken ct)
        {
            if (!Directory.Exists(downloadDirectory))
                Directory.CreateDirectory(downloadDirectory);

            await SendCommandAsync("Browser.setDownloadBehavior", new Dictionary<string, object>
            {
                { "behavior", "allow" },
                { "downloadPath", downloadDirectory },
                { "eventsEnabled", true }
            }, null, 15000, ct);
        }

        public async Task ResetDownloadBehaviorToDefaultAsync()
        {
            try
            {
                string userDownloads = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),
                    "Downloads");
                if (!Directory.Exists(userDownloads))
                    Directory.CreateDirectory(userDownloads);

                await SendCommandAsync("Browser.setDownloadBehavior", new Dictionary<string, object>
                {
                    { "behavior", "allow" },
                    { "downloadPath", userDownloads },
                    { "eventsEnabled", false }
                }, null, 8000, CancellationToken.None);

                await SendCommandAsync("Browser.setDownloadBehavior", new Dictionary<string, object>
                {
                    { "behavior", "default" }
                }, null, 8000, CancellationToken.None);
            }
            catch { }
        }

        public async Task<List<CdpTargetInfo>> GetTargetsAsync(CancellationToken ct)
        {
            Dictionary<string, object> res = await SendCommandAsync("Target.getTargets", null, null, 15000, ct);
            List<CdpTargetInfo> list = new List<CdpTargetInfo>();
            if (!res.ContainsKey("targetInfos")) return list;

            IEnumerable rawList = res["targetInfos"] as IEnumerable;
            if (rawList == null) return list;

            foreach (object item in rawList)
            {
                Dictionary<string, object> d = item as Dictionary<string, object>;
                if (d == null) continue;
                list.Add(new CdpTargetInfo
                {
                    TargetId = d.ContainsKey("targetId") ? Convert.ToString(d["targetId"]) : "",
                    Type = d.ContainsKey("type") ? Convert.ToString(d["type"]) : "",
                    Title = d.ContainsKey("title") ? Convert.ToString(d["title"]) : "",
                    Url = d.ContainsKey("url") ? Convert.ToString(d["url"]) : "",
                    BrowserContextId = d.ContainsKey("browserContextId") ? Convert.ToString(d["browserContextId"]) : ""
                });
            }
            return list;
        }

        public async Task<string> OpenOrAttachProfileTabAsync(
            string profileDir,
            string targetUrl,
            string urlDomainMatch,
            bool forceReloadUrl,
            CancellationToken ct)
        {
            await EnsureConnectedAsync(ct);

            List<CdpTargetInfo> beforeTargets = await GetTargetsAsync(ct);
            CdpTargetInfo chosen = null;

            // 1. Se já conhecemos o browserContextId deste perfil nesta sessão, procure aba existente desse perfil
            string knownCtx;
            if (_profileToContextId.TryGetValue(profileDir, out knownCtx) && !string.IsNullOrEmpty(knownCtx))
            {
                chosen = beforeTargets.FirstOrDefault(t =>
                    t.Type == "page" &&
                    t.BrowserContextId == knownCtx &&
                    t.Url.IndexOf(urlDomainMatch, StringComparison.OrdinalIgnoreCase) >= 0);

                if (chosen == null)
                {
                    chosen = beforeTargets.FirstOrDefault(t => t.Type == "page" && t.BrowserContextId == knownCtx && !t.Url.StartsWith("devtools://"));
                }
            }

            // 2. Se já existir uma aba aberta anteriormente com a tag #fvs_<Perfil> (ou window.name / aba única do projeto Flow), reutilize sem abrir nova aba
            if (chosen == null)
            {
                string profKey = "fvs_" + profileDir.Replace(" ", "_");
                string profTagPrefix = "#" + profKey;
                chosen = beforeTargets.FirstOrDefault(t =>
                    t.Type == "page" &&
                    t.Url.IndexOf(profTagPrefix, StringComparison.OrdinalIgnoreCase) >= 0);

                if (chosen == null && urlDomainMatch.IndexOf("flow.google.com", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    chosen = beforeTargets.FirstOrDefault(t =>
                        t.Type == "page" &&
                        t.Url.IndexOf("flow.google.com/project/", StringComparison.OrdinalIgnoreCase) >= 0);
                }

                // Se o roteador SPA removeu o hash da URL (ex: /imagine/post/... ou /imagine/agent), verifica window.name nas abas do domínio
                if (chosen == null)
                {
                    HashSet<string> claimedContexts = new HashSet<string>(_profileToContextId.Values, StringComparer.OrdinalIgnoreCase);
                    List<CdpTargetInfo> domainCandidates = beforeTargets
                        .Where(t => t.Type == "page" &&
                                    t.Url.IndexOf(urlDomainMatch, StringComparison.OrdinalIgnoreCase) >= 0 &&
                                    (string.IsNullOrEmpty(t.BrowserContextId) || !claimedContexts.Contains(t.BrowserContextId)))
                        .ToList();

                    foreach (CdpTargetInfo cand in domainCandidates)
                    {
                        try
                        {
                            Dictionary<string, object> tmpAttach = await SendCommandAsync("Target.attachToTarget", new Dictionary<string, object>
                            {
                                { "targetId", cand.TargetId },
                                { "flatten", true }
                            }, null, 6000, ct);
                            string tmpSess = Convert.ToString(tmpAttach["sessionId"] ?? "");
                            if (!string.IsNullOrEmpty(tmpSess))
                            {
                                string wName = await EvalStringAsync(tmpSess, "window.name || ''", ct);
                                if (wName.StartsWith(profKey, StringComparison.OrdinalIgnoreCase))
                                {
                                    chosen = cand;
                                    break;
                                }
                            }
                        }
                        catch { }
                    }
                }

                if (chosen != null && !string.IsNullOrEmpty(chosen.BrowserContextId))
                {
                    _profileToContextId[profileDir] = chosen.BrowserContextId;
                }
            }

            // 3. Caso contrário, abra uma janela dedicada do perfil via WMI com tag no hash para rastrear 100% o browserContextId do perfil
            bool openedNewWindow = false;
            if (chosen == null)
            {
                openedNewWindow = true;
                HashSet<string> oldIds = new HashSet<string>(beforeTargets.Select(t => t.TargetId));
                string tag = "fvs_" + profileDir.Replace(" ", "_") + "_" + Guid.NewGuid().ToString("N").Substring(0, 6);
                string launchUrl = targetUrl.Contains("#") ? targetUrl : (targetUrl + "#" + tag);

                _log(string.Format("[Chrome] Abrindo perfil '{0}' em '{1}' via WMI e aguardando carregamento completo da guia...", profileDir, targetUrl));
                LaunchChromeProfileWindow(profileDir, launchUrl);

                for (int i = 0; i < 50; i++)
                {
                    ct.ThrowIfCancellationRequested();
                    await Task.Delay(550, ct);
                    List<CdpTargetInfo> nowTargets = await GetTargetsAsync(ct);

                    chosen = nowTargets.FirstOrDefault(t =>
                        t.Type == "page" &&
                        t.Url.IndexOf(tag, StringComparison.OrdinalIgnoreCase) >= 0);

                    if (chosen == null)
                    {
                        chosen = nowTargets.FirstOrDefault(t =>
                            t.Type == "page" &&
                            !oldIds.Contains(t.TargetId) &&
                            t.Url.IndexOf(urlDomainMatch, StringComparison.OrdinalIgnoreCase) >= 0);
                    }

                    if (chosen != null)
                    {
                        if (!string.IsNullOrEmpty(chosen.BrowserContextId))
                            _profileToContextId[profileDir] = chosen.BrowserContextId;
                        break;
                    }
                }
            }

            if (chosen == null)
            {
                throw new InvalidOperationException(string.Format("Não foi possível localizar/abrir aba para '{0}' ({1}).", profileDir, targetUrl));
            }

            _profileToLastTargetId[profileDir] = chosen.TargetId;

            Dictionary<string, object> attachRes = await SendCommandAsync("Target.attachToTarget", new Dictionary<string, object>
            {
                { "targetId", chosen.TargetId },
                { "flatten", true }
            }, null, 15000, ct);

            string sessionId = Convert.ToString(attachRes["sessionId"]);
            await SendCommandAsync("Page.enable", null, sessionId, 10000, ct);
            await SendCommandAsync("Runtime.enable", null, sessionId, 10000, ct);
            await SendCommandAsync("DOM.enable", null, sessionId, 10000, ct);
            await SendCommandAsync("Page.bringToFront", null, sessionId, 10000, ct);

            string navTargetUrl = targetUrl.Contains("#")
                ? targetUrl
                : (targetUrl + "#fvs_" + profileDir.Replace(" ", "_"));

            bool didNavigate = false;
            if (forceReloadUrl || chosen.Url.IndexOf(urlDomainMatch, StringComparison.OrdinalIgnoreCase) < 0)
            {
                didNavigate = true;
                await SendCommandAsync("Page.navigate", new Dictionary<string, object> { { "url", navTargetUrl } }, sessionId, 25000, ct);
                await Task.Delay(1200, ct);
            }

            await WaitForDocumentReadyAsync(sessionId, 30000, ct);
            if (openedNewWindow || didNavigate)
            {
                await Task.Delay(3200, ct);
            }
            else
            {
                await Task.Delay(1200, ct);
            }

            try
            {
                await EvalStringAsync(sessionId, string.Format("window.name = 'fvs_{0}';", profileDir.Replace(" ", "_")), ct);
            }
            catch { }
            return sessionId;
        }

        public async Task WaitForDocumentReadyAsync(string sessionId, int timeoutMs, CancellationToken ct)
        {
            DateTime start = DateTime.UtcNow;
            DateTime deadline = start.AddMilliseconds(timeoutMs);
            while (DateTime.UtcNow < deadline)
            {
                ct.ThrowIfCancellationRequested();
                string st = await EvalStringAsync(sessionId, @"
(function(){
    var rs = document.readyState || '';
    var href = location.href || '';
    if (href === 'about:blank' || href === '') return 'BLANK';
    var hasBody = !!(document.body && document.body.children && document.body.children.length > 0 && (document.body.innerText || '').trim().length > 10);
    if (rs === 'complete' && hasBody) return 'COMPLETE_READY';
    if (rs === 'complete') return 'COMPLETE';
    return rs;
})()", ct);
                double elapsedMs = (DateTime.UtcNow - start).TotalMilliseconds;
                if (st == "COMPLETE_READY" || (st == "COMPLETE" && elapsedMs >= 2500))
                {
                    await Task.Delay(2200, ct);
                    return;
                }
                await Task.Delay(500, ct);
            }
        }

        public async Task<object> EvalObjectAsync(string sessionId, string jsExpression, CancellationToken ct, int timeoutMs = 25000)
        {
            Dictionary<string, object> res = await SendCommandAsync("Runtime.evaluate", new Dictionary<string, object>
            {
                { "expression", jsExpression },
                { "returnByValue", true },
                { "awaitPromise", true }
            }, sessionId, timeoutMs, ct);

            if (res.ContainsKey("exceptionDetails") && res["exceptionDetails"] != null)
            {
                return null;
            }

            if (res.ContainsKey("result") && res["result"] is Dictionary<string, object>)
            {
                Dictionary<string, object> r = (Dictionary<string, object>)res["result"];
                return r.ContainsKey("value") ? r["value"] : null;
            }
            return null;
        }

        public async Task<string> EvalStringAsync(string sessionId, string jsExpression, CancellationToken ct, int timeoutMs = 25000)
        {
            object v = await EvalObjectAsync(sessionId, jsExpression, ct, timeoutMs);
            return v == null ? "" : Convert.ToString(v);
        }

        public async Task<Dictionary<string, object>> EvalJsonAsync(string sessionId, string jsReturningJsonString, CancellationToken ct, int timeoutMs = 25000)
        {
            string raw = await EvalStringAsync(sessionId, jsReturningJsonString, ct, timeoutMs);
            if (string.IsNullOrWhiteSpace(raw)) return null;
            try
            {
                return CreateSerializer().Deserialize<Dictionary<string, object>>(raw);
            }
            catch
            {
                return null;
            }
        }

        public async Task HoverAsync(string sessionId, int x, int y, CancellationToken ct)
        {
            await SendCommandAsync("Input.dispatchMouseEvent", new Dictionary<string, object>
            {
                { "type", "mouseMoved" },
                { "x", x },
                { "y", y },
                { "button", "none" }
            }, sessionId, 10000, ct);
        }

        public async Task ClickAtAsync(string sessionId, int x, int y, CancellationToken ct)
        {
            await HoverAsync(sessionId, x, y, ct);
            await Task.Delay(50, ct);
            await SendCommandAsync("Input.dispatchMouseEvent", new Dictionary<string, object>
            {
                { "type", "mousePressed" },
                { "x", x },
                { "y", y },
                { "button", "left" },
                { "clickCount", 1 }
            }, sessionId, 10000, ct);
            await Task.Delay(65, ct);
            await SendCommandAsync("Input.dispatchMouseEvent", new Dictionary<string, object>
            {
                { "type", "mouseReleased" },
                { "x", x },
                { "y", y },
                { "button", "left" },
                { "clickCount", 1 }
            }, sessionId, 10000, ct);
        }

        public async Task PressEnterAsync(string sessionId, CancellationToken ct)
        {
            await SendCommandAsync("Input.dispatchKeyEvent", new Dictionary<string, object>
            {
                { "type", "keyDown" },
                { "key", "Enter" },
                { "code", "Enter" },
                { "windowsVirtualKeyCode", 13 },
                { "nativeVirtualKeyCode", 13 }
            }, sessionId, 10000, ct);
            await Task.Delay(50, ct);
            await SendCommandAsync("Input.dispatchKeyEvent", new Dictionary<string, object>
            {
                { "type", "keyUp" },
                { "key", "Enter" },
                { "code", "Enter" },
                { "windowsVirtualKeyCode", 13 },
                { "nativeVirtualKeyCode", 13 }
            }, sessionId, 10000, ct);
        }

        public async Task PressEscapeAsync(string sessionId, CancellationToken ct)
        {
            await SendCommandAsync("Input.dispatchKeyEvent", new Dictionary<string, object>
            {
                { "type", "keyDown" },
                { "key", "Escape" },
                { "code", "Escape" },
                { "windowsVirtualKeyCode", 27 },
                { "nativeVirtualKeyCode", 27 }
            }, sessionId, 10000, ct);
            await Task.Delay(50, ct);
            await SendCommandAsync("Input.dispatchKeyEvent", new Dictionary<string, object>
            {
                { "type", "keyUp" },
                { "key", "Escape" },
                { "code", "Escape" },
                { "windowsVirtualKeyCode", 27 },
                { "nativeVirtualKeyCode", 27 }
            }, sessionId, 10000, ct);
        }

        public async Task<bool> SetFileInputFilesAsync(string sessionId, string cssSelector, IEnumerable<string> filePaths, CancellationToken ct)
        {
            Dictionary<string, object> docRes = await SendCommandAsync("DOM.getDocument", new Dictionary<string, object> { { "depth", 1 } }, sessionId, 15000, ct);
            Dictionary<string, object> root = docRes.ContainsKey("root") ? docRes["root"] as Dictionary<string, object> : null;
            if (root == null || !root.ContainsKey("nodeId")) return false;

            int rootNodeId = Convert.ToInt32(root["nodeId"]);
            Dictionary<string, object> qRes = await SendCommandAsync("DOM.querySelector", new Dictionary<string, object>
            {
                { "nodeId", rootNodeId },
                { "selector", cssSelector }
            }, sessionId, 15000, ct);

            int inputNodeId = qRes.ContainsKey("nodeId") ? Convert.ToInt32(qRes["nodeId"]) : 0;
            if (inputNodeId <= 0) return false;

            await SendCommandAsync("DOM.setFileInputFiles", new Dictionary<string, object>
            {
                { "nodeId", inputNodeId },
                { "files", filePaths.ToArray() }
            }, sessionId, 25000, ct);
            return true;
        }

        public async Task<bool> SetFileInputFilesByObjectIdAsync(
            string sessionId,
            string jsInputExpression,
            IEnumerable<string> filePaths,
            CancellationToken ct)
        {
            string[] files = filePaths.Where(f => !string.IsNullOrEmpty(f) && File.Exists(f)).ToArray();
            if (files.Length == 0) return true;

            Dictionary<string, object> evalRes = await SendCommandAsync("Runtime.evaluate", new Dictionary<string, object>
            {
                { "expression", jsInputExpression },
                { "returnByValue", false }
            }, sessionId, 12000, ct);

            Dictionary<string, object> resObj = evalRes.ContainsKey("result") ? evalRes["result"] as Dictionary<string, object> : null;
            string objId = (resObj != null && resObj.ContainsKey("objectId")) ? Convert.ToString(resObj["objectId"] ?? "") : "";
            if (string.IsNullOrEmpty(objId))
                return false;

            await SendCommandAsync("DOM.setFileInputFiles", new Dictionary<string, object>
            {
                { "objectId", objId },
                { "files", files }
            }, sessionId, 25000, ct);
            return true;
        }

        public async Task<bool> UploadFilesViaFileChooserAsync(
            string sessionId,
            Func<Task> triggerClickAction,
            IEnumerable<string> filePaths,
            CancellationToken ct)
        {
            string[] files = filePaths.Where(f => !string.IsNullOrEmpty(f) && File.Exists(f)).ToArray();
            if (files.Length == 0) return true;

            TaskCompletionSource<Dictionary<string, object>> tcs =
                new TaskCompletionSource<Dictionary<string, object>>(TaskCreationOptions.RunContinuationsAsynchronously);
            _fileChooserTcs = tcs;

            await SendCommandAsync("Page.setInterceptFileChooserDialog", new Dictionary<string, object>
            {
                { "enabled", true }
            }, sessionId, 10000, ct);

            bool success = false;
            Exception capturedError = null;

            try
            {
                await triggerClickAction();
                Task winner = await Task.WhenAny(tcs.Task, Task.Delay(8000, ct));
                if (winner == tcs.Task)
                {
                    Dictionary<string, object> fcParams = await tcs.Task;
                    if (fcParams != null && fcParams.ContainsKey("backendNodeId"))
                    {
                        int backendNodeId = Convert.ToInt32(fcParams["backendNodeId"]);
                        string mode = fcParams.ContainsKey("mode") ? Convert.ToString(fcParams["mode"] ?? "") : "selectMultiple";

                        if (string.Equals(mode, "selectSingle", StringComparison.OrdinalIgnoreCase) && files.Length > 1)
                        {
                            await SendCommandAsync("DOM.setFileInputFiles", new Dictionary<string, object>
                            {
                                { "backendNodeId", backendNodeId },
                                { "files", new string[] { files[0] } }
                            }, sessionId, 25000, ct);

                            for (int i = 1; i < files.Length; i++)
                            {
                                await Task.Delay(700, ct);
                                TaskCompletionSource<Dictionary<string, object>> nextTcs =
                                    new TaskCompletionSource<Dictionary<string, object>>(TaskCreationOptions.RunContinuationsAsynchronously);
                                _fileChooserTcs = nextTcs;
                                await triggerClickAction();
                                Task w2 = await Task.WhenAny(nextTcs.Task, Task.Delay(8000, ct));
                                if (w2 != nextTcs.Task) break;
                                Dictionary<string, object> p2 = await nextTcs.Task;
                                if (p2 != null && p2.ContainsKey("backendNodeId"))
                                {
                                    await SendCommandAsync("DOM.setFileInputFiles", new Dictionary<string, object>
                                    {
                                        { "backendNodeId", Convert.ToInt32(p2["backendNodeId"]) },
                                        { "files", new string[] { files[i] } }
                                    }, sessionId, 25000, ct);
                                }
                            }
                            success = true;
                        }
                        else
                        {
                            await SendCommandAsync("DOM.setFileInputFiles", new Dictionary<string, object>
                            {
                                { "backendNodeId", backendNodeId },
                                { "files", files }
                            }, sessionId, 30000, ct);
                            success = true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                capturedError = ex;
            }

            _fileChooserTcs = null;
            try
            {
                await SendCommandAsync("Page.setInterceptFileChooserDialog", new Dictionary<string, object>
                {
                    { "enabled", false }
                }, sessionId, 8000, ct);
            }
            catch { }

            if (capturedError != null)
            {
                OperationCanceledException oce = capturedError as OperationCanceledException;
                if (oce != null) throw oce;
                throw capturedError;
            }

            return success;
        }

        public async Task<string> WaitForSingleDownloadAsync(
            string downloadDir,
            HashSet<string> existingFilesSnapshot,
            long minFileSizeBytes,
            int timeoutMs,
            CancellationToken ct)
        {
            DateTime deadline = DateTime.UtcNow.AddMilliseconds(timeoutMs);
            while (DateTime.UtcNow < deadline)
            {
                ct.ThrowIfCancellationRequested();
                await Task.Delay(550, ct);

                if (!Directory.Exists(downloadDir)) continue;

                string[] allFiles = Directory.GetFiles(downloadDir);
                bool hasCrDownload = allFiles.Any(f =>
                    f.EndsWith(".crdownload", StringComparison.OrdinalIgnoreCase) ||
                    f.EndsWith(".tmp", StringComparison.OrdinalIgnoreCase));

                if (hasCrDownload) continue;

                foreach (string f in allFiles.OrderByDescending(x => File.GetLastWriteTimeUtc(x)))
                {
                    if (existingFilesSnapshot.Contains(f)) continue;
                    try
                    {
                        FileInfo fi = new FileInfo(f);
                        if (fi.Exists && fi.Length >= minFileSizeBytes)
                        {
                            // Garante que o Chrome soltou o handle de escrita
                            using (FileStream fs = new FileStream(f, FileMode.Open, FileAccess.Read, FileShare.Read))
                            {
                                if (fs.Length >= minFileSizeBytes)
                                    return f;
                            }
                        }
                    }
                    catch { }
                }
            }
            return "";
        }

        private void CleanupSocketOnly()
        {
            try { if (_rxCts != null) _rxCts.Cancel(); } catch { }
            try { if (_ws != null) _ws.Dispose(); } catch { }
            _ws = null;
            _rxCts = null;
        }

        public void Dispose()
        {
            CleanupSocketOnly();
        }
    }
}
