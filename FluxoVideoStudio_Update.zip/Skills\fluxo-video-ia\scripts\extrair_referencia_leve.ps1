param(
    [Parameter(Mandatory=$true)]
    [string[]]$InputPaths,

    [string]$OutputDir = (Join-Path $env:TEMP "fluxo_ref_cache"),

    [switch]$Force
)

$ErrorActionPreference = "Stop"
$inv = [System.Globalization.CultureInfo]::InvariantCulture

# Localizar ffmpeg.exe (CapCut local ou PATH do sistema)
$capcutAppsDir = Join-Path $env:LOCALAPPDATA "CapCut\Apps"
$ffmpegItem = Get-ChildItem -Path $capcutAppsDir -Filter "ffmpeg.exe" -Recurse -ErrorAction SilentlyContinue |
    Sort-Object LastWriteTime -Descending |
    Select-Object -First 1

if ($ffmpegItem) {
    $ffmpegExe = $ffmpegItem.FullName
} else {
    $cmdFfmpeg = Get-Command ffmpeg -ErrorAction SilentlyContinue
    if ($cmdFfmpeg) {
        $ffmpegExe = $cmdFfmpeg.Source
    } else {
        throw "ffmpeg.exe nao encontrado na instalacao do CapCut nem no PATH do sistema."
    }
}

if (-not (Test-Path $OutputDir)) {
    New-Item -ItemType Directory -Force -Path $OutputDir | Out-Null
}
$OutputDir = (Get-Item -LiteralPath $OutputDir).FullName

# Expandir pastas ou arquivos de video validos
$videoExts = @(".mp4", ".mov", ".mkv", ".webm", ".avi")
$resolvedVideos = New-Object System.Collections.Generic.List[System.IO.FileInfo]

foreach ($p in $InputPaths) {
    if (-not (Test-Path -LiteralPath $p)) {
        Write-Warning "Caminho nao encontrado: $p"
        continue
    }
    $item = Get-Item -LiteralPath $p
    if ($item.PSIsContainer) {
        $children = Get-ChildItem -LiteralPath $item.FullName -File |
            Where-Object { $videoExts -contains $_.Extension.ToLowerInvariant() } |
            Sort-Object Name
        foreach ($c in $children) { $resolvedVideos.Add($c) }
    } elseif ($videoExts -contains $item.Extension.ToLowerInvariant()) {
        $resolvedVideos.Add($item)
    }
}

if ($resolvedVideos.Count -eq 0) {
    throw "Nenhum arquivo de video valido encontrado nos caminhos informados."
}

$results = @()

foreach ($vid in $resolvedVideos) {
    $sw = [System.Diagnostics.Stopwatch]::StartNew()

    # Gerar chave unica curta baseada em nome + tamanho + LastWriteTimeUtc
    $rawId = "$($vid.FullName)|$($vid.Length)|$($vid.LastWriteTimeUtc.Ticks)"
    $sha = [System.Security.Cryptography.SHA256]::Create()
    $hashBytes = $sha.ComputeHash([System.Text.Encoding]::UTF8.GetBytes($rawId))
    $shortHash = ([System.BitConverter]::ToString($hashBytes).Replace("-", "")).Substring(0, 10).ToLowerInvariant()

    $safeBase = ($vid.BaseName -replace '[^a-zA-Z0-9_-]', '_')
    if ($safeBase.Length -gt 40) { $safeBase = $safeBase.Substring(0, 40) }
    $prefix = "${safeBase}_${shortHash}"

    $audioPath    = Join-Path $OutputDir "${prefix}.m4a"
    $mosaicPath   = Join-Path $OutputDir "${prefix}_mosaico.jpg"
    $analysisPath = Join-Path $OutputDir "${prefix}_analise.txt"

    $audioExists  = (Test-Path -LiteralPath $audioPath) -and ((Get-Item -LiteralPath $audioPath).Length -gt 1024)
    $mosaicExists = (Test-Path -LiteralPath $mosaicPath) -and ((Get-Item -LiteralPath $mosaicPath).Length -gt 2048)

    # Inspecionar duracao e streams
    $ErrorActionPreference = "Continue"
    $probeOut = (& $ffmpegExe -hide_banner -i $vid.FullName 2>&1) -join "`n"
    $ErrorActionPreference = "Stop"

    $durationSec = 60.0
    if ($probeOut -match "Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)") {
        $durationSec = ([double]$matches[1] * 3600.0) + ([double]$matches[2] * 60.0) + [double]::Parse($matches[3], $inv)
    }
    $hasAudio = $probeOut -match "Stream #\d+:\d+.*Audio:"
    $isCompactAac = ($probeOut -match "Audio:\s*aac") -and ($vid.Length -lt 15MB)

    # 1. Extrair audio leve (.m4a)
    if ($hasAudio -and ($Force -or -not $audioExists)) {
        $ErrorActionPreference = "Continue"
        if ($isCompactAac) {
            & $ffmpegExe -y -hide_banner -loglevel error -i $vid.FullName -vn -c:a copy $audioPath
        }
        if (-not (Test-Path -LiteralPath $audioPath) -or ((Get-Item -LiteralPath $audioPath).Length -le 1024)) {
            & $ffmpegExe -y -hide_banner -loglevel error -i $vid.FullName -vn -ac 1 -ar 24000 -c:a aac -b:a 32k $audioPath
        }
        $ErrorActionPreference = "Stop"
    }

    # 2. Extrair mosaico unico de frames (.jpg) usando keyframes ultra-rapidos (-skip_frame nokey)
    if ($Force -or -not $mosaicExists) {
        # Ate 25 quadros (grade 5x5) cobrindo do inicio ao fim do video
        $stepSec = [Math]::Max(1.5, [Math]::Round(($durationSec / 24.0), 2))
        $stepStr = $stepSec.ToString($inv)
        $vfFilter = "fps=1/${stepStr},scale=220:-1,tile=5x5"

        $ErrorActionPreference = "Continue"
        & $ffmpegExe -y -hide_banner -loglevel error -skip_frame nokey -i $vid.FullName -an -vf $vfFilter -frames:v 1 -q:v 6 $mosaicPath
        if (-not (Test-Path -LiteralPath $mosaicPath) -or ((Get-Item -LiteralPath $mosaicPath).Length -le 2048)) {
            # Fallback decodificando normalmente caso o video quase nao tenha keyframes
            & $ffmpegExe -y -hide_banner -loglevel error -i $vid.FullName -an -vf $vfFilter -frames:v 1 -q:v 6 $mosaicPath
        }
        $ErrorActionPreference = "Stop"
    }

    $sw.Stop()
    $analysisReady = (Test-Path -LiteralPath $analysisPath) -and ((Get-Item -LiteralPath $analysisPath).Length -gt 50)
    $audioKB  = if (Test-Path -LiteralPath $audioPath)  { [Math]::Round((Get-Item -LiteralPath $audioPath).Length / 1KB, 1) } else { 0 }
    $mosaicKB = if (Test-Path -LiteralPath $mosaicPath) { [Math]::Round((Get-Item -LiteralPath $mosaicPath).Length / 1KB, 1) } else { 0 }

    $results += [PSCustomObject]@{
        VideoOriginal    = $vid.FullName
        DuracaoSeg       = [Math]::Round($durationSec, 1)
        AudioLeveM4A     = if ($hasAudio) { $audioPath } else { "(sem audio)" }
        AudioKB          = $audioKB
        MosaicoJPG       = $mosaicPath
        MosaicoKB        = $mosaicKB
        CacheAnaliseTXT  = $analysisPath
        AnaliseEmCache   = $analysisReady
        TempoExtracaoMs  = $sw.ElapsedMilliseconds
    }
}

foreach ($r in $results) {
    Write-Output "=== VIDEO_REF ==="
    Write-Output "VideoOriginal=$($r.VideoOriginal)"
    Write-Output "DuracaoSeg=$($r.DuracaoSeg)"
    Write-Output "AudioLeveM4A=$($r.AudioLeveM4A) ($($r.AudioKB) KB)"
    Write-Output "MosaicoJPG=$($r.MosaicoJPG) ($($r.MosaicoKB) KB)"
    Write-Output "CacheAnaliseTXT=$($r.CacheAnaliseTXT)"
    Write-Output "AnaliseEmCache=$($r.AnaliseEmCache)"
    Write-Output "TempoExtracaoMs=$($r.TempoExtracaoMs)"
}
