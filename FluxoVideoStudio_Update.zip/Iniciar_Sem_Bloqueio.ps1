$ErrorActionPreference = "Stop"

# WPF exige Single-Threaded Apartment (STA). Se o PowerShell abriu em MTA, reinicia automaticamente em STA oculto:
if ([System.Threading.Thread]::CurrentThread.ApartmentState -ne [System.Threading.ApartmentState]::STA) {
    Start-Process -FilePath "powershell.exe" -ArgumentList @(
        "-NoProfile",
        "-STA",
        "-ExecutionPolicy", "Bypass",
        "-WindowStyle", "Hidden",
        "-File", "`"$PSCommandPath`""
    )
    exit
}

$studioRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$env:FVS_BASE_DIR = $studioRoot

# Remove o bloqueio de download da internet/WhatsApp (Mark of the Web / Zone.Identifier)
try {
    Get-ChildItem -Path $studioRoot -Recurse -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue
} catch {}

$fwDir = "C:\Windows\Microsoft.NET\Framework64\v4.0.30319"
$wpfDir = Join-Path $fwDir "WPF"

$refs = @(
    (Join-Path $fwDir "System.dll"),
    (Join-Path $fwDir "System.Core.dll"),
    (Join-Path $fwDir "System.Drawing.dll"),
    (Join-Path $fwDir "System.Management.dll"),
    (Join-Path $fwDir "System.Net.Http.dll"),
    (Join-Path $fwDir "System.Web.Extensions.dll"),
    (Join-Path $fwDir "System.Xaml.dll"),
    (Join-Path $wpfDir "WindowsBase.dll"),
    (Join-Path $wpfDir "PresentationCore.dll"),
    (Join-Path $wpfDir "PresentationFramework.dll"),
    (Join-Path $wpfDir "UIAutomationClient.dll"),
    (Join-Path $wpfDir "UIAutomationTypes.dll")
)

$csFiles = Get-ChildItem -Path (Join-Path $studioRoot "src") -Filter "*.cs" | Select-Object -ExpandProperty FullName

# Compila e executa 100% em memória dentro do powershell.exe (assinado pela Microsoft), evitando bloqueio do Controle Inteligente de Aplicativos do Windows 11
Add-Type -Path $csFiles -ReferencedAssemblies $refs -ErrorAction Stop
[FluxoVideoStudio.Program]::Main(@())
