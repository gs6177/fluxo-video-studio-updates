---
name: fluxo-video-ia
description: >-
  Responsável EXCLUSIVAMENTE pela análise de referências, criação/adaptação de roteiros em 3 episódios (`EP.1`, `EP.2` e `EP.3` via skill `Camaleão part 1, 2 e 3`) e geração local dos arquivos de decupagem e prompts (`roteiro.txt`, `prompts_gem_novela.txt` ou `prompts_gem_terror.txt`, `prompt_grok_passo1_e_2.txt` e `prompt_flow_passo3.txt`) usando as skills locais `gem-novela` ou `gem-terror`.
  A geração de imagens, geração de vídeos, locução e edição no CapCut ficam integralmente sob responsabilidade de outro agente/programa externo. É ESTRITAMENTE PROIBIDO realizar autoaprendizagem ou alterar qualquer regra da skill sem solicitação explícita do usuário.
---

# Fluxo de Roteirização e Decupagem de Prompts para Vídeos com IA (`Camaleão part 1, 2 e 3` -> `gem-novela` / `gem-terror`)

Siga rigorosamente todas as regras abaixo sem exceção. **É ESTRITAMENTE PROIBIDO alterar qualquer regra desta skill por conta própria — alterações só podem ser feitas quando o usuário solicitar explicitamente.**

---

## 🛑 ESCOPO ESTRITO DESTA SKILL (SOMENTE ROTEIROS E ARQUIVOS DE PROMPT `.txt`)

> **[!CAUTION] DIVISÃO ESTRITA E ABSOLUTA DE RESPONSABILIDADES**:
> Esta skill (`/fluxo-video-ia`) é responsável **UNICAMENTE** pela criação de:
> 1. **`roteiro.txt`** (Roteiro adaptado/original de cada episódio via `Camaleão part 1, 2 e 3`);
> 2. **`prompts_gem_novela.txt`** ou **`prompts_gem_terror.txt`** (Decupagem completa contendo Passo 1, Passo 2 e Passo 3);
> 3. **`prompt_grok_passo1_e_2.txt`** (Prompts de Personagens e Cenários inéditos do episódio em `9:16`);
> 4. **`prompt_flow_passo3.txt`** (Prompts cronológicos de todos os Takes decupados em `9:16`).
>
> - **É ESTRITAMENTE PROIBIDO** avançar para geração de imagens (Grok Imagine), geração de vídeos (Google Flow), geração de locução (ElevenLabs) ou montagem/edição (CapCut Desktop). Toda a execução de imagem, vídeo, áudio e edição é realizada separadamente por **outro agente / programa externo**.

---

## Regra 0: Pergunta Obrigatória Antes de Iniciar e Estrutura Estrita de Pastas por História e Episódio (`EP.1`, `EP.2`, `EP.3`)

> **[!CAUTION] PROIBIÇÃO ESTRITA E ABSOLUTA NA ORGANIZAÇÃO DE PASTAS E ARQUIVOS**:
> É **ESTRITAMENTE PROIBIDO** salvar arquivos soltos fora da pasta da história, criar pastas separadas na raiz para cada episódio (`Historia_Parte1`, `Historia_Parte2`) ou deixar de criar as subpastas `EP.1`, `EP.2` e `EP.3`!
> - **Diretórios Raiz Obrigatórios por Gênero**:
>   - **Reflexão / Novela (`gem-novela`)**: `C:\Users\Best Option Notebook\Desktop\MEU TRABALHO\_videos de reflexão`
>   - **Terror (`gem-terror`)**: `C:\Users\Best Option Notebook\Desktop\MEU TRABALHO\_Videos terror`
> - **Estrutura Obrigatória de Cada História (`<Nome_Da_Historia>\EP.1`, `EP.2`, `EP.3`)**:
>   - Como todas as histórias possuem **Episódio 1, 2 e 3**, crie sempre **1 única pasta principal com o nome da história** dentro da pasta do gênero correspondente e, **já no início**, crie dentro dela as **3 subpastas de episódio**: **`EP.1`**, **`EP.2`** e **`EP.3`** (já deixando criadas também as subpastas vazias `EP.X\assets\` e `EP.X\takes\` para uso do outro agente).
>   - Dentro da subpasta de cada episódio (`EP.1\`, `EP.2\`, `EP.3\`), salve em **UTF-8 limpo** todos os arquivos gerados daquele episódio:
>     - `EP.X\roteiro.txt` (roteiro completo daquele episódio);
>     - `EP.X\prompts_gem_novela.txt` (se Novela/Reflexão) ou `EP.X\prompts_gem_terror.txt` (se Terror);
>     - `EP.X\prompt_grok_passo1_e_2.txt` (comando pronto do Passo 1 + Passo 2 apenas com os assets inéditos daquele episódio);
>     - `EP.X\prompt_flow_passo3.txt` (comando pronto do Passo 3 com todos os takes decupados daquele episódio).

Antes de gerar o roteiro e os prompts, **sempre pergunte ao usuário se a história é de TERROR, NOVELA/REFLEXÃO ou estilo 3D PIXAR/DISNEY** (caso ele ainda não tenha informado na mensagem).
- **Skill Local Obrigatória para Criar/Clonar o Roteiro em 3 Partes (`Camaleão part 1,2 e 3`)**: `C:\Users\Best Option Notebook\.gemini\config\skills\Camaleão part 1,2 e 3\SKILL.md`
- **Skill Local Obrigatória para Decupagem de Novela / Reflexão**: `C:\Users\Best Option Notebook\.gemini\config\skills\gem-novela\SKILL.md`
- **Skill Local Obrigatória para Decupagem de Terror**: `C:\Users\Best Option Notebook\.gemini\config\skills\gem-terror\SKILL.md`
- **Skill Local Obrigatória para Decupagem em Estilo 3D Pixar/Disney Cartoon (`gem 3D Pixar/Disney`)**: `C:\Users\Best Option Notebook\.gemini\config\skills\gem 3D Pixar-Disney\SKILL.md`

### Exemplo Exato da Árvore de Pastas Obrigatória:
- **REFLEXÃO / NOVELA (`gem-novela`)**:
  - `C:\Users\Best Option Notebook\Desktop\MEU TRABALHO\_videos de reflexão\<Nome_Da_Historia>\EP.1\` (`roteiro.txt`, `prompts_gem_novela.txt`, `prompt_grok_passo1_e_2.txt`, `prompt_flow_passo3.txt`, `assets\`, `takes\`)
  - `C:\Users\Best Option Notebook\Desktop\MEU TRABALHO\_videos de reflexão\<Nome_Da_Historia>\EP.2\` (`roteiro.txt`, `prompts_gem_novela.txt`, `prompt_grok_passo1_e_2.txt`, `prompt_flow_passo3.txt`, `assets\`, `takes\`)
  - `C:\Users\Best Option Notebook\Desktop\MEU TRABALHO\_videos de reflexão\<Nome_Da_Historia>\EP.3\` (`roteiro.txt`, `prompts_gem_novela.txt`, `prompt_grok_passo1_e_2.txt`, `prompt_flow_passo3.txt`, `assets\`, `takes\`)
- **TERROR (`gem-terror`)**:
  - `C:\Users\Best Option Notebook\Desktop\MEU TRABALHO\_Videos terror\<Nome_Da_Historia>\EP.1\` (`roteiro.txt`, `prompts_gem_terror.txt`, `prompt_grok_passo1_e_2.txt`, `prompt_flow_passo3.txt`, `assets\`, `takes\`)
  - `C:\Users\Best Option Notebook\Desktop\MEU TRABALHO\_Videos terror\<Nome_Da_Historia>\EP.2\` (`roteiro.txt`, `prompts_gem_terror.txt`, `prompt_grok_passo1_e_2.txt`, `prompt_flow_passo3.txt`, `assets\`, `takes\`)
  - `C:\Users\Best Option Notebook\Desktop\MEU TRABALHO\_Videos terror\<Nome_Da_Historia>\EP.3\` (`roteiro.txt`, `prompts_gem_terror.txt`, `prompt_grok_passo1_e_2.txt`, `prompt_flow_passo3.txt`, `assets\`, `takes\`)

---

## Etapa 1: Análise da Referência e Criação do Roteiro (`Camaleão part 1, 2 e 3` -> `EP.X\roteiro.txt`)

1. **Análise Ultra-Rápida do Vídeo/Referência (FFmpeg Leve + Subagentes em Paralelo + Cache `.txt`)**:
   - **PROIBIDO usar `read_file` direto no arquivo `.mp4` bruto na conversa principal** (pois carrega milhares de frames pesados e deixa toda a conversa lenta).
   - **Passo 1 (Extração Instantânea < 0,5s/vídeo)**: Sempre que o usuário indicar vídeo(s) na pasta `Downloads`, `Desktop\MEU TRABALHO\Videos_Referencia` ou outro caminho, execute primeiro o script oficial via `run_command` (`WaitMsBeforeAsync: 10000`):
     `powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Users\Best Option Notebook\.gemini\config\skills\fluxo-video-ia\scripts\extrair_referencia_leve.ps1" -InputPaths "<caminho_do_video_ou_pasta>"`
     Esse script usa o FFmpeg local do CapCut para extrair instantaneamente o áudio compacto (`.m4a`, ~250–400 KB) + 1 único mosaico visual de keyframes (`_mosaico.jpg`, grade `5x5`) e informa `CacheAnaliseTXT` e `AnaliseEmCache`.
   - **Passo 2 (Leitura de Cache ou Subagentes em Paralelo)**:
     - Se `AnaliseEmCache=True`: leia diretamente o arquivo `CacheAnaliseTXT` com `read_file` (instantâneo, sem precisar abrir mídia nem subagente).
     - Se `AnaliseEmCache=False`: lance **subagente(s) em paralelo no mesmo turno** usando `invoke_subagent` (`TypeName: "self"`, 1 subagente por vídeo quando houver múltiplos vídeos na pasta/pedido, ou 1 subagente para vídeo único). Instrua cada subagente a: (a) ler **exclusivamente** seu `AudioLeveM4A` e seu `MosaicoJPG` com `read_file` (jamais o `.mp4` original); (b) extrair **100% da transcrição fiel na íntegra** (todas as falas/narrações em ordem cronológica com minutagem aproximada), o **mapa visual das cenas/expressões/cenários** e a **espinha dorsal, ritmo, conflitos e impacto emocional**; (c) salvar esse relatório completo em UTF-8 no caminho `CacheAnaliseTXT` com `write_file` e devolvê-lo na resposta.
     - Dessa forma, a conversa principal recebe apenas texto puro, mantendo velocidade máxima em todas as fases seguintes!
   - Siga integralmente as regras e fases interativas da skill `C:\Users\Best Option Notebook\.gemini\config\skills\Camaleão part 1,2 e 3\SKILL.md`:
     - **Referências Obrigatórias da Cultura Popular Brasileira (Folclore no Terror & Cotidiano Simples na Novela)**:
       - **Em Histórias de TERROR**: É obrigatório adaptar a trama usando elementos do **folclore brasileiro, lendas urbanas/rurais e crendices populares do Brasil** (ex.: lendas de assombração de beira de estrada, Cruzeiro das Almas, Rasga-Mortalha cantando no telhado, Corpo-Seco, Matinta Perera, Procissão das Almas, cachorros uivando para visagem, reza com arruda, benzedeira, vela para as almas, etc.) para que faça total sentido cultural no Brasil.
       - **Em Histórias de NOVELA / REFLEXÃO**: É obrigatório usar referências autênticas do **cotidiano popular, simples e humilde brasileiro** — não precisa ser necessariamente na roça ou num bairro específico, podendo se passar em qualquer lugar simples (subúrbio, bairro modesto, vila, cidade pequena, comércio popular, ponto de ônibus, feira, marmitaria, oficina, roça, etc.) que traga a estética humilde em que o brasileiro se sinta representado;
     - **Regra dos Arquétipos (ZERO Nomes Próprios)**: Terminantemente proibido usar nomes próprios nas rubricas, descrições ou dentro dos diálogos;
     - **Histórias Bem Desenvolvidas + Narrador Contextualizador**: As histórias devem ser bem desenvolvidas e profundas. Use **O Narrador** para contextualizar as cenas, revelar o peso emocional, os sacrifícios e o contexto da situação para dar mais profundidade à história, combinando com diálogos densos e naturais nos confrontos;
     - **Abertura Apelativa Própria em Cada Episódio (`EP.1`, `EP.2` e `EP.3`)**: Cada episódio deve ter **sua própria abertura apelativa exclusiva** no `Take 1` (um gancho de exatos `10s` inédito e ultra apelativo focado no conflito/tensão daquele episódio específico);
     - **Fases Interativas**:
       - *Fase 1*: Espinha Dorsal + 3 opções de Novo Mundo (incluindo opções em cidades pequenas simples e/ou interior/roça, conforme o que melhor se adapte à história — aguardar escolha);
       - *Fase 2*: 3 opções de Gancho (Hook) apelativo de exatos `10s` exclusivo para abrir o episódio atual (ou definir os ganchos próprios de cada um dos 3 episódios — aguardar escolha);
       - *Fase 3*: Perguntar o tempo de duração da parte (aguardar escolha);
       - *Fase 4*: Escrever e salvar `EP.X\roteiro.txt` bem desenvolvido, usando o Narrador para contextualizar as cenas e dar profundidade, dividido em Takes de `10s`, cada um com fala bruta **obrigatoriamente entre `145` e `150` caracteres** (`{XXX caracteres}`), aplicando a Regra Anti-Bloqueio e terminando sem CTA (com cliffhanger extremo nas Partes 1 e 2, e desfecho em alta na Parte 3).
2. **Continuidade e Abertura Própria nas Partes 2 e 3 (`EP.2` e `EP.3`)**:
   - Mantenha os mesmos arquétipos e universo criados na Parte 1, mas **cada episódio (`EP.1`, `EP.2` e `EP.3`) deve começar no `Take 1` com sua própria abertura apelativa exclusiva de 10s** (sem repetir o mesmo gancho nos três episódios).

---

## Etapa 2: Geração Local dos Prompts de Decupagem (`gem-novela` ou `gem-terror`)

Assim que o roteiro do episódio (`EP.X\roteiro.txt`) for definido, leia a skill local correspondente (`gem-novela\SKILL.md` ou `gem-terror\SKILL.md`) e gere imediatamente na pasta `EP.X\` os **3 arquivos de prompt** para consumo do outro agente, obedecendo a todas as regras técnicas abaixo:

### 1. Regras Inegociáveis de Formatação e Compatibilidade com o Agente Externo

1. **Numeração Sequencial Contínua dos Arquivos `.jpg` entre `EP.1`, `EP.2` e `EP.3` + Múltiplas Pré-Definições de Figurino por Ocasião (`PASSO 1` e `PASSO 3`)**:
   - Nomeie os assets com numeração de 2 dígitos contínua ao longo de toda a história para evitar qualquer colisão de nomes no outro agente:
     - Exemplo `EP.1`: `01_Personagem_1_...jpg` a `04_Personagem_4_...jpg` e `05_Cenario_A_...jpg` a `07_Cenario_C_...jpg`.
     - Exemplo `EP.2` (apenas inéditos): `08_Personagem_5_...jpg`, `09_Cenario_D_...jpg`.
     - Exemplo `EP.3` (apenas inéditos): `10_Cenario_E_...jpg`, `11_Cenario_F_...jpg`.
   - **Regra de Roupas / Figurinos por Ocasião Direto na Pré-Definição (`PASSO 1`)**:
     - Sempre que um mesmo personagem precisar de roupas diferentes ao longo da história de acordo com o contexto do roteiro e da cena (ex.: trabalhando de avental na cozinha vs. indo à formatura ou à cidade com roupa simples, limpa e arrumadinha sem avental; usando beca de formatura com canudo de diploma no baile vs. roupa simples de estudante em casa vs. camisa social de trabalho no escritório no `EP.2`), **crie uma Pré-Definição separada no `PASSO 1` para cada roupa daquele personagem**!
     - Em cada pré-definição adicional de roupa do mesmo personagem no `PASSO 1`, repita **100% a mesma descrição física e facial** (mesmo rosto, idade, cabelo/penteado, tom de pele e expressão) e mude apenas a roupa e o que está nas mãos conforme o contexto da cena (removendo avental, beca ou canudo de diploma quando não pertencerem àquela cena).
     - No **`PASSO 3` (`prompt_flow_passo3.txt`)**, indique diretamente em cada `Take` (`Ingredientes necessários` / `Ingredientes Obrigatórios` e corpo do prompt) o arquivo `.jpg` exato da pré-definição que traz a roupa correta daquela cena.
2. **Regra Estrita de Continuidade no `prompt_grok_passo1_e_2.txt` (`EP.1` vs. `EP.2` / `EP.3`)**:
   - O arquivo `EP.X\prompt_grok_passo1_e_2.txt` deve começar sempre com o cabeçalho:
     ```text
     Faça cada imagem isolada e em 9:16, nome em cima da cabeça:
     ```
   - No `EP.1`, inclua todos os Personagens físicos (`PASSO 1`, corpo inteiro, fundo branco neutro puro, texto com o nome do arquétipo acima da cabeça) e todos os Cenários (`PASSO 2`, ambiente 3D vazio sem personagens e **SEM TEXTO / SEM NOME DO CENÁRIO ESCRITO NA IMAGEM**, grande angular `9:16`).
   - No `EP.2` e `EP.3`, inclua no `PASSO 1` e `PASSO 2` **SOMENTE os personagens físicos inéditos e os cenários inéditos** que ainda não apareceram nos episódios anteriores! *(Se não houver personagem inédito naquele episódio, omita o bloco vazio de `PASSO 1` dentro de `prompt_grok_passo1_e_2.txt` para que o gerador de imagens não crie imagem extra indevida; se 100% dos personagens e cenários já existirem, deixe `prompt_grok_passo1_e_2.txt` vazio ou com aviso claro de zero novos assets).*
   - No `PASSO 3` de `EP.2` e `EP.3`, mantenha exatamente os mesmos nomes de arquivos `.jpg` dos personagens e cenários recorrentes criados no `EP.1` / `EP.2`.
3. **Regra do Narrador (`100% Sem Fala` / `SEM DIALOGO` — Apenas Demonstração Visual)**:
   - Sempre que o roteiro contiver uma fala de `"O Narrador:"`, **NUNCA** crie personagem para `"O Narrador"` no `PASSO 1`.
   - No `PASSO 3`, as cenas do Narrador devem ser marcadas como `100% Sem Fala` e terminar com `SEM DIALOGO`, descrevendo apenas a ação visual silenciosa dos personagens físicos de boca fechada, o som ambiente da cena e o Foley (**sem incluir nenhuma linha ou texto da fala do narrador**, evitando locução indesejada no gerador de vídeo).
4. **Regra de Múltiplos Personagens em Cena (`Ingredientes Obrigatórios`) e Fórmula Obrigatória de Posição Espacial + Lip-Sync no `PASSO 3`**:
   - Em **cada Take** do `PASSO 3` (`prompts_gem_<genero>.txt` e `prompt_flow_passo3.txt`), liste obrigatoriamente no cabeçalho `Ingredientes Obrigatórios: [Arquivo_Personagem_1.jpg] + [Arquivo_Personagem_2_se_presente.jpg] + [Arquivo_Cenario.jpg]` com **TODOS os personagens físicos presentes na cena + o cenário correspondente**, e **NÃO** adicione linha extra `"Citação da fala original:"` fora do `Prompt de Vídeo:`.
   - **Fórmula Obrigatória de Frases Independentes, Posição Espacial e Ordem de Lip-Sync**:
     1. **PROIBIDO sujeito composto com vários personagens na mesma frase** (*"Personagem A, Personagem B e Personagem C estão no Cenário X"*), pois isso faz o gerador de vídeo trocar posições ou errar quem fala.
     2. **Uma frase curta e independente para cada personagem + Posição Exata**: Em toda cena, escreva **1 frase separada por personagem**, indicando explicitamente a **posição espacial exata** dele no ambiente (ex.: *"No banco de trás do carro ao centro..."*, *"No banco dianteiro do motorista à esquerda ao volante..."*, *"No banco do passageiro à direita..."*, *"Em pé ao fundo à direita..."*, *"Sentada na cadeira à direita da mesa..."*).
     3. **Ordem Estrita para Travar o Lip-Sync (Quem Não Fala Primeiro -> Quem Fala por Último com `"e fala"`)**:
        - **1ª(s) frase(s)**: Descreva primeiro o cenário (`[Arquivo_Cenario.jpg]`) e a posição/ação dos personagens que **NÃO falam** naquele Take.
        - **Última frase (imediatamente antes de `IMEDIATAMENTE o áudio entra:`)**: Posicione **SEMPRE por último** o **personagem que fala no Take**, descrevendo sua posição exata, sua reação e terminando a frase com **`"e fala..."`** colado em `IMEDIATAMENTE o áudio entra: "[Fala]"`.
     4. **Reforço Obrigatório na Câmera (`[Câmera e Detalhes]`)**: Repita a posição espacial dos personagens no quadro e marque explicitamente a palavra **`"falando"`** no personagem que tem a fala do Take (ex.: *"Câmera: Plano lateral acompanhando [Personagem A] em [posição], enquanto enquadra [Personagem B] falando em [posição]. Lip-sync preciso."*).
5. **Traços que Realçam Personagens Adultos (Sem Rosto ou Aparência de Criança) + Regra Anti-Bloqueio**:
   - **Traços Faciais e Corporais Maduros Obrigatórios para Personagens Adultos (`PASSO 1` e `PASSO 3`)**: Todos os personagens adultos devem ter **traços que realcem claramente sua maturidade física e facial de adultos**, sendo **TERMINANTEMENTE PROIBIDO** que tenham rosto ou aparência de criança (*babyface*, bochechas rechonchudas infantis, olhos gigantes arredondados de criança, cabeça grande desproporcional ou aspecto de menor de idade).
   - Em todo prompt do **`PASSO 1`** e do **`PASSO 3`**, inclua explicitamente para os personagens adultos: **estrutura óssea facial adulta bem definida, maxilar e queixo marcados, maçãs do rosto salientes, linhas de expressão adultas naturais, pescoço, ombros e estatura de adulto completo, sem rosto ou aparência de criança**, prefixando-os no `PASSO 3` com **`"o homem adulto <Arquétipo>"`**, **`"a mulher adulta <Arquétipo>"`**, **`"o homem idoso <Arquétipo>"`** ou **`"a mulher idosa <Arquétipo>"`**, e evitando arremesso de móveis ou agressão física. *(Caso a história tenha de fato um bebê ou criança no roteiro, aí sim crie-o com proporções reais de bebê/criança, mas jamais permita traços infantis em personagens adultos).*
   - Aplique preventivamente as substituições suaves de vocabulário sensível (*"prestamista"* / *"agiota"* -> *"cobrador"*, *"amenazó"* / *"ameaçou tomar"* -> *"dijo que perderemos"* / *"disse que perderemos"*, *"esclava"* / *"escrava"* -> *"empleada"* / *"empregada"*, *"porquería"* -> *"cuenta"* / *"conta"*, *"inútil quebrado"* -> *"homem sem dinheiro"*, *"víbora"* / *"loca"* -> *"aquela mulher"*, *"calzones viejos"* -> *"roupa velha"*, *"vender uma cria"* / *"comprar uma cria"* -> *"negociar um cavalo forte dessa sua fazenda"* / *"negociar um animal dessa sua linhagem"*), mantendo nos prompts de vídeo do `gem-novela` os sons realistas do ambiente (ex: música de fundo em festas, som saindo da caixa de som, sons da rua/casa) junto com as vozes em tela e Foley.

---

## Regra de Proibição de Autoaprendizagem (Alterações Somente por Solicitação Explícita do Usuário)

> **[!CAUTION] PROIBIÇÃO ESTRITA DE AUTOAPRENDIZAGEM / ALTERAÇÃO AUTOMÁTICA DE REGRAS**:
> - É **ESTRITAMENTE PROIBIDO** ao agente propor autoaprendizagem ao final da entrega ou alterar qualquer regra da `SKILL.md` por conta própria.
> - **As regras desta skill são fixas e imutáveis**, e **SOMENTE** podem ser alteradas quando o próprio usuário solicitar explicitamente uma alteração.
