function Invoke-CDP {
    param(
        [scriptblock]$Action,
        [int]$TimeoutMs = 20000,
        [string]$DownloadPath = "$env:USERPROFILE\Downloads"
    )
    $portActive = $false
    if (Test-Path "$env:LOCALAPPDATA\Google\Chrome\User Data\DevToolsActivePort") {
        try {
            $pLines = Get-Content "$env:LOCALAPPDATA\Google\Chrome\User Data\DevToolsActivePort"
            $chkPort = [int]$pLines[0].Trim()
            $tcp = Get-NetTCPConnection -LocalPort $chkPort -State Listen -ErrorAction SilentlyContinue
            if ($tcp) { $portActive = $true }
        } catch {}
    }

    if (-not $portActive) {
        Invoke-CimMethod -ClassName Win32_Process -MethodName Create -Arguments @{
            CommandLine = '"C:\Program Files\Google\Chrome\Application\chrome.exe" --profile-directory="Profile 2" --new-window "https://flow.google.com/project/9b576f1d-9b0f-4103-ac8e-123edb00a1f0"'
        } | Out-Null
        for ($i = 0; $i -lt 20; $i++) {
            Start-Sleep -Milliseconds 500
            if (Test-Path "$env:LOCALAPPDATA\Google\Chrome\User Data\DevToolsActivePort") {
                try {
                    $pLines = Get-Content "$env:LOCALAPPDATA\Google\Chrome\User Data\DevToolsActivePort"
                    $chkPort = [int]$pLines[0].Trim()
                    if (Get-NetTCPConnection -LocalPort $chkPort -State Listen -ErrorAction SilentlyContinue) { break }
                } catch {}
            }
        }
    }

    $portLines = Get-Content "$env:LOCALAPPDATA\Google\Chrome\User Data\DevToolsActivePort"
    $port = $portLines[0].Trim()
    $wsPath = $portLines[1].Trim()
    $wsUri = "ws://127.0.0.1:$port$wsPath"

    # Abre UMA UNICA conexao WebSocket persistente; so dispara auto_allow_chrome.ps1 se a tentativa bloquear por >600ms
    $ws = New-Object System.Net.WebSockets.ClientWebSocket
    $cts = New-Object System.Threading.CancellationTokenSource($TimeoutMs)
    $connectTask = $ws.ConnectAsync([Uri]$wsUri, $cts.Token)
    if (-not $connectTask.Wait(600)) {
        Invoke-CimMethod -ClassName Win32_Process -MethodName Create -Arguments @{
            CommandLine = 'powershell.exe -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "C:\Users\Best Option Notebook\.gemini\config\skills\fluxo-video-ia\scripts\auto_allow_chrome.ps1" -DurationSeconds 15'
        } | Out-Null
        $connectTask.Wait()
    }

    $script:msgId = 100
    function Send-CDPCommand {
        param(
            [string]$Method,
            [hashtable]$Params = @{},
            [string]$SessionId = $null,
            [int]$CmdTimeoutMs = 20000
        )
        $script:msgId++
        $id = $script:msgId
        $payload = @{ id = $id; method = $Method; params = $Params }
        if ($SessionId) { $payload.sessionId = $SessionId }
        $json = $payload | ConvertTo-Json -Depth 20 -Compress
        $bytes = [System.Text.Encoding]::UTF8.GetBytes($json)
        $seg = New-Object System.ArraySegment[byte](,$bytes)
        $cmdCts = New-Object System.Threading.CancellationTokenSource($CmdTimeoutMs)
        $ws.SendAsync($seg, [System.Net.WebSockets.WebSocketMessageType]::Text, $true, $cmdCts.Token).Wait()

        while ($true) {
            $ms = New-Object System.IO.MemoryStream
            $buf = New-Object byte[] 65536
            $rseg = New-Object System.ArraySegment[byte](,$buf)
            do {
                $res = $ws.ReceiveAsync($rseg, $cmdCts.Token).Result
                $ms.Write($buf, 0, $res.Count)
            } while (-not $res.EndOfMessage)
            $str = [System.Text.Encoding]::UTF8.GetString($ms.ToArray())
            $ms.Dispose()
            $obj = $str | ConvertFrom-Json
            if ($obj.id -eq $id) {
                return $obj
            }
        }
    }

    try {
        Send-CDPCommand -Method "Browser.setDownloadBehavior" -Params @{
            behavior = "allow"
            downloadPath = $DownloadPath
            eventsEnabled = $true
        } | Out-Null
        & $Action
    } finally {
        $ws.Dispose()
    }
}
