using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace FluxoVideoStudio
{
    public partial class FlowAutomation
    {
        private readonly CdpController _cdp;
        private readonly PipelineConfig _config;
        private readonly GrokAutomation _grok;
        private readonly Action<string> _log;
        private static readonly Random _flowRng = new Random();
        private static readonly object _flowRngLock = new object();

        private async Task WaitRandomFlowActionDelayAsync(string actionReason, CancellationToken ct)
        {
            int minSec = _config != null ? Math.Max(0, _config.FlowActionDelayMinSeconds) : 15;
            int maxSec = _config != null ? Math.Max(0, _config.FlowActionDelayMaxSeconds) : 30;
            if (maxSec < minSec)
            {
                int tmp = minSec;
                minSec = maxSec;
                maxSec = tmp;
            }
            if (maxSec <= 0)
                return;

            int waitMs;
            lock (_flowRngLock)
            {
                int minMs = minSec * 1000;
                int maxMs = maxSec * 1000;
                waitMs = (maxMs > minMs) ? _flowRng.Next(minMs, maxMs + 1) : minMs;
            }

            _log(string.Format("[Google Flow | Delay] Aguardando {0:0.0}s ({1})...", waitMs / 1000.0, actionReason));
            await _cdp.WaitOrWakeOnReloadSignalAsync(waitMs, ct);
        }

        public FlowAutomation(CdpController cdp, PipelineConfig config, Action<string> logger)
            : this(cdp, config, new GrokAutomation(cdp, config, logger), logger)
        {
        }

        public FlowAutomation(CdpController cdp, PipelineConfig config, GrokAutomation grok, Action<string> logger)
        {
            _cdp = cdp;
            _config = config;
            _grok = grok ?? new GrokAutomation(cdp, config, logger);
            _log = logger ?? delegate { };
            _grok.SetFlowFallback(this);
        }

        public static bool IsYouthCharacterTake(FlowTakeSpec take, EpisodeWorkItem ep)
        {
            if (take == null) return false;

            // Remove falas entre aspas ("...") para que expressões idiomáticas entre adultos ("meu filho", "minha filha") não gerem falso positivo
            string bodyWithoutQuotes = Regex.Replace(take.RawPromptBody ?? "", @"""[^""]*""", " ");
            StringBuilder sb = new StringBuilder();
            sb.Append(take.RawHeader ?? "").Append(' ');
            sb.Append(bodyWithoutQuotes).Append(' ');
            if (take.Ingredients != null)
            {
                for (int i = 0; i < take.Ingredients.Count; i++)
                    sb.Append(take.Ingredients[i]).Append(' ');
            }

            // Inspeciona também a definição dos personagens vinculados aos ingredientes deste take
            if (ep != null && ep.GrokSpecs != null && take.Ingredients != null && take.Ingredients.Count > 0)
            {
                HashSet<string> takeIngSet = new HashSet<string>(take.Ingredients, StringComparer.OrdinalIgnoreCase);
                for (int i = 0; i < ep.GrokSpecs.Count; i++)
                {
                    GrokAssetSpec gs = ep.GrokSpecs[i];
                    if (gs == null || string.IsNullOrEmpty(gs.TargetFileName)) continue;
                    if (!takeIngSet.Contains(gs.TargetFileName)) continue;

                    string normSpec = EpisodeParser.NormalizeForCompare((gs.DisplayTitle ?? "") + " " + (gs.RawPromptLine ?? ""));
                    bool explicitlyAdult = Regex.IsMatch(normSpec, @"\b(homem adulto|mulher adulta|adulto|adulta|idoso|idosa|senhor|senhora|velho|velha)\b");
                    if (!explicitlyAdult)
                    {
                        sb.Append(gs.DisplayTitle ?? "").Append(' ');
                        sb.Append(gs.RawPromptLine ?? "").Append(' ');
                    }
                }
            }

            string norm = EpisodeParser.NormalizeForCompare(sb.ToString());
            if (string.IsNullOrEmpty(norm)) return false;

            // Remove expressões negativas de estilo visual (ex.: "sem rosto ou aparencia de ...", "sem tracos ...", "zero ...")
            norm = Regex.Replace(norm, @"\b(sem|zero|nunca|jamais|nao)\s+(rosto\s+ou\s+aparencia\s+de\s+|aparencia\s+de\s+|rosto\s+de\s+|feicoes\s+de\s+|tracos\s+de\s+|corpo\s+de\s+|aspecto\s+de\s+|personagens?\s+)?\w+(\s+ou\s+\w+)?", " ");
            norm = Regex.Replace(norm, @"\b(realcam|realcando|destacam)\s+personagens\s+adultos\b", " ");

            if (Regex.IsMatch(norm,
                @"\b(crianca|criancas|bebe|bebes|nenem|nenens|nene|recem nascido|recem nascida|menino|meninos|menininho|menininha|menina|meninas|garoto|garotos|garotinho|garotinha|garota|garotas|guri|guria|guris|gurias|pivete|moleque|molequinho|infantil|infantis|adolescente|adolescentes|juvenil|juvenis|jovem|jovens|moca|mocas|mocinha|mocinhas|rapaz|rapazes|colegial|novinho|novinha|berco|chupeta|mamadeira|filho pequeno|filha pequena|filhos pequenos|filhas pequenas|filhinho|filhinha|irmaozinho|irmazinha|netinho|netinha|bebe de colo|crianca de colo|rosto redondo|rosto super redondo|bochechas rechonchudas)\b"))
            {
                return true;
            }

            if (Regex.IsMatch(norm,
                @"\b(([1-9]|1[0-7])\s+anos\s+de\s+idade|(de|com)\s+([1-9]|1[0-7])\s+meses|(filho|filha|irmao|irma|neto|neta|sobrinho|sobrinha)\s+de\s+([1-9]|1[0-7])\s+anos)\b"))
            {
                return true;
            }

            return false;
        }

        public static int TryExtractExplicitTakeTagNumber(string promptText)
        {
            if (string.IsNullOrWhiteSpace(promptText))
                return 0;

            Match m = Regex.Match(
                promptText,
                @"\[\s*TAKE(?:[_\-\s]*ID)?[_\-\s]*0*(\d{1,3})\s*\]",
                RegexOptions.IgnoreCase);

            if (m.Success)
            {
                int num;
                if (int.TryParse(m.Groups[1].Value, out num) && num > 0)
                    return num;
            }

            return 0;
        }

        public static string NormalizeFlowSceneDurationTag(string durationText)
        {
            string trimmed = (durationText ?? "").Trim();
            if (string.IsNullOrEmpty(trimmed))
                return "10s";

            Match m = Regex.Match(trimmed, @"(\d+(?:[\.,]\d+)?)");
            if (m.Success)
            {
                double val;
                if (double.TryParse(m.Groups[1].Value.Replace(',', '.'), NumberStyles.Float, CultureInfo.InvariantCulture, out val) && val > 0 && val <= 600)
                {
                    double rounded = Math.Round(val);
                    if (Math.Abs(val - rounded) <= 0.15)
                        return string.Format("{0}s", (int)rounded);
                    return string.Format(CultureInfo.InvariantCulture, "{0:0.#}s", val);
                }
            }

            return "10s";
        }

        private static string InjectTakeTagIntoPromptBody(string rawBody, int takeNumber, string durationText = "10s")
        {
            string cleanBody = Regex.Replace(rawBody ?? "", @"(\r?\n|\s)*---\s*$", "").Trim();
            if (string.IsNullOrEmpty(cleanBody) || takeNumber <= 0)
                return cleanBody;

            string durTag = NormalizeFlowSceneDurationTag(durationText);
            string combinedTag = string.Format("[TAKE_{0:00}] [{1}]", takeNumber, durTag);

            bool hasVideoPromptPrefix = false;
            Match prefixMatch = Regex.Match(cleanBody, @"^(Prompt\s+de\s+V[ií]deo\s*:\s*)", RegexOptions.IgnoreCase);
            if (prefixMatch.Success)
            {
                hasVideoPromptPrefix = true;
                cleanBody = cleanBody.Substring(prefixMatch.Length).TrimStart();
            }

            // Remove tags [TAKE_XX] ou [10s] já presentes no início para reinserir de forma padronizada sem duplicar
            cleanBody = Regex.Replace(
                cleanBody,
                @"^(?:\[\s*(?:TAKE(?:[_\-\s]*ID)?[_\-\s]*\d{1,3}|(?:Dura[cç][aã]o\s*:\s*)?\d+(?:[\.,]\d+)?\s*(?:s|seg|segundos))\s*\]\s*)+",
                "",
                RegexOptions.IgnoreCase).TrimStart();

            if (hasVideoPromptPrefix)
            {
                return "Prompt de Vídeo:\r\n" + combinedTag + " " + cleanBody;
            }

            return combinedTag + " " + cleanBody;
        }

        public static string BuildFlowPromptForTakes(string originalPromptText, List<FlowTakeSpec> takes)
        {
            if (takes == null || takes.Count == 0) return "";

            StringBuilder sb = new StringBuilder();

            // Instrução obrigatória ao Agente do Google Flow para preservar as tags [TAKE_XX] [10s] e gerar cada cena com o tempo definido
            sb.AppendLine("[INSTRUÇÃO OBRIGATÓRIA DE RASTREAMENTO E TEMPO DE CENA]:");
            sb.AppendLine("Ao enviar o prompt de cada cena para a ferramenta de geração de vídeo (tanto neste lote inicial quanto nos próximos lotes após \"continue\"), respeite o tempo de cena indicado (ex.: 10s) e mantenha OBRIGATORIAMENTE e literalmente as tags [TAKE_01] [10s], [TAKE_02] [10s], etc. exatamente no início do texto do prompt de cada vídeo gerado (exemplo: \"[TAKE_01] [10s] [Estilo Visual] ...\"). NUNCA remova, omita, traduza ou altere as tags [TAKE_XX] [10s] em nenhum vídeo. Essas tags são apenas controle de identificação e duração — não renderize nenhum texto, número ou legenda escrita na imagem do vídeo.");
            sb.AppendLine();

            // Preserva eventual cabeçalho global existente antes do primeiro "Take X |"
            if (!string.IsNullOrWhiteSpace(originalPromptText))
            {
                string[] lines = originalPromptText.Split(new[] { "\r\n", "\n" }, StringSplitOptions.None);
                List<string> preambleLines = new List<string>();
                for (int i = 0; i < lines.Length; i++)
                {
                    if (Regex.IsMatch(lines[i], @"Take\s*0*(\d+)\s*\|", RegexOptions.IgnoreCase))
                        break;
                    preambleLines.Add(lines[i]);
                }
                string preamble = string.Join("\r\n", preambleLines).Trim();
                if (!string.IsNullOrEmpty(preamble))
                {
                    sb.AppendLine(preamble);
                    sb.AppendLine();
                }
            }

            for (int i = 0; i < takes.Count; i++)
            {
                FlowTakeSpec t = takes[i];
                string durTag = NormalizeFlowSceneDurationTag(t.DurationText);
                string headerLine = (t.RawHeader ?? "").Trim();
                if (!string.IsNullOrEmpty(headerLine) &&
                    !Regex.IsMatch(headerLine, @"\b\d+(?:[\.,]\d+)?\s*(?:s|seg|segundos)\b", RegexOptions.IgnoreCase))
                {
                    headerLine = headerLine + " | Tempo: " + durTag;
                }
                string sanitizedBody = SanitizePromptForFlowPolicy(t.RawPromptBody, false);
                string taggedBody = InjectTakeTagIntoPromptBody(sanitizedBody, t.TakeNumber, durTag);
                sb.AppendLine(headerLine);
                sb.AppendLine(taggedBody);
                if (i < takes.Count - 1)
                {
                    sb.AppendLine();
                    sb.AppendLine("---");
                    sb.AppendLine();
                }
            }

            return sb.ToString().Trim();
        }

        public async Task RunAsync(EpisodeWorkItem ep, CancellationToken ct)
        {
            if (string.IsNullOrWhiteSpace(ep.FlowPromptText) || ep.FlowTakes.Count == 0)
            {
                throw new InvalidOperationException("Arquivo prompt_flow_passo3.txt vazio ou não encontrado para este episódio.");
            }

            if (!Directory.Exists(ep.TakesDir))
                Directory.CreateDirectory(ep.TakesDir);

            // Regra 22: Reaproveitamento automático do Take_01.mp4 (Gancho oficial de 10s) nas Partes 2 e 3 quando aplicável
            int firstTakeNumberInPrompt = ep.FlowTakes[0].TakeNumber;
            if (ep.EpisodeNumber > 1 && _config.ReuseEp1HookTake01 && firstTakeNumberInPrompt >= 2)
            {
                string ep1Take01 = Path.Combine(ep.StoryRootPath, "EP.1", "takes", "Take_01.mp4");
                string destTake01 = Path.Combine(ep.TakesDir, "Take_01.mp4");
                if (File.Exists(ep1Take01) && (!File.Exists(destTake01) || new FileInfo(destTake01).Length < 50 * 1024))
                {
                    File.Copy(ep1Take01, destTake01, true);
                    _log(string.Format("[Google Flow] Regra 22: Take_01.mp4 (Gancho de 10s) reaproveitado automaticamente do EP.1 para {0}!", ep.EpisodeName));
                }
            }

            // Inspeção permanente de takes já existentes na pasta 'takes':
            // Só move para _backup se TODOS os takes do episódio já estiverem concluídos (refazer episódio completo).
            // Se o episódio estiver incompleto, preserva todos os Take_XX.mp4 já salvos e gera apenas os ausentes!
            HashSet<int> existingOnDisk = new HashSet<int>();
            for (int i = 0; i < ep.FlowTakes.Count; i++)
            {
                int tn = ep.FlowTakes[i].TakeNumber;
                string mp4Path = Path.Combine(ep.TakesDir, string.Format("Take_{0:00}.mp4", tn));
                if (File.Exists(mp4Path) && new FileInfo(mp4Path).Length >= 50 * 1024)
                    existingOnDisk.Add(tn);
            }

            bool archivedForFullRemake = false;
            if (_config.ArchiveOldTakesBeforeRemake && existingOnDisk.Count >= ep.FlowTakes.Count)
            {
                string[] existingMedia = Directory.GetFiles(ep.TakesDir)
                    .Where(f => Regex.IsMatch(Path.GetExtension(f), @"^\.(mp4|mov)$", RegexOptions.IgnoreCase))
                    .ToArray();
                if (existingMedia.Length > 0)
                {
                    string backupDir = Path.Combine(ep.TakesDir, "_backup_" + DateTime.Now.ToString("yyyyMMdd_HHmmss"));
                    Directory.CreateDirectory(backupDir);
                    foreach (string oldFile in existingMedia)
                    {
                        string dst = Path.Combine(backupDir, Path.GetFileName(oldFile));
                        File.Move(oldFile, dst);
                    }
                    existingOnDisk.Clear();
                    archivedForFullRemake = true;
                    _log(string.Format("[Modo Refazer] Episódio estava 100% completo -> {0} takes antigos arquivados com segurança em '{1}'.", existingMedia.Length, backupDir));
                }
            }
            else if (existingOnDisk.Count > 0 && existingOnDisk.Count < ep.FlowTakes.Count)
            {
                string existingLabels = string.Join(", ", existingOnDisk.OrderBy(n => n).Select(n => string.Format("Take_{0:00}", n)));
                _log(string.Format("[Inspeção de Takes] {0}/{1} takes já existem na pasta 'takes' ({2}) -> preservando cenas prontas e processando apenas os {3} ausentes!",
                    existingOnDisk.Count, ep.FlowTakes.Count, existingLabels, ep.FlowTakes.Count - existingOnDisk.Count));
            }
            else if (existingOnDisk.Count >= ep.FlowTakes.Count)
            {
                _log(string.Format("[Inspeção de Takes] Todos os {0} takes já estão prontos em '{1}'! Pulando geração de vídeo.", ep.FlowTakes.Count, ep.TakesDir));
                EpisodeParser.RefreshDiskCounters(ep);
                return;
            }

            // Se ainda faltarem imagens de personagens/cenários em assets\ (seja por Grok sem créditos, RunGrok desmarcado ou execução direta do Flow),
            // gera primeiro no Google Flow (anexando obrigatoriamente a imagem do EP anterior para novas versões de personagens existentes)!
            if (ep.GrokSpecs != null && ep.GrokSpecs.Count > 0)
            {
                EpisodeParser.SyncRecurringAssetsFromPreviousEpisodes(ep, _log);
                if (_config.PreserveExistingAssets)
                    EpisodeParser.AutoAlignImportedAssetsOnDisk(ep, _log);

                List<GrokAssetSpec> missingGrokSpecs = ep.GrokSpecs.Where(s =>
                {
                    string p = Path.Combine(ep.AssetsDir, s.TargetFileName);
                    return !File.Exists(p) || new FileInfo(p).Length < 4 * 1024;
                }).ToList();

                if (missingGrokSpecs.Count > 0)
                {
                    _log(string.Format("[Google Flow | Imagens 9:16] Detectadas {0} imagem(ns) de personagens/cenários ainda ausentes -> gerando imagens no Google Flow antes das cenas!",
                        missingGrokSpecs.Count));
                    await GenerateMissingAssetsInFlowAsync(ep, missingGrokSpecs, ct);
                }
            }

            // Regra 6 + Regra 14: Sincronizar assets recorrentes/locais, alinhar nomes e espelhar 100% dos personagens e cenários para Temp\flow_assets
            List<string> allAssetFiles;
            Dictionary<string, string> ingredientToResolvedName;
            PrepareAndResolveEpisodeAssetsForFlow(ep, out allAssetFiles, out ingredientToResolvedName);

            List<FlowTakeSpec> effectiveTakes = EpisodeParser.GetEffectiveTakeSpecsForEpisode(ep);

            // Filtrar apenas os takes que ainda NÃO existem em disco:
            // Todas as cenas pendentes (inclusive com criança) são tentadas 1 a 1 no Google Flow primeiro;
            // somente as que derem erro mesmo após pedir suavização na conversa vão para o Grok Vídeo!
            List<FlowTakeSpec> flowEligibleTakes = new List<FlowTakeSpec>();
            for (int i = 0; i < effectiveTakes.Count; i++)
            {
                FlowTakeSpec t = effectiveTakes[i];
                if (existingOnDisk.Contains(t.TakeNumber))
                    continue;
                flowEligibleTakes.Add(t);
            }

            HashSet<int> skippedAfterFlowRetries = new HashSet<int>();

            if (flowEligibleTakes.Count > 0)
            {
                string sess = await OpenAndPrepareFlowProjectTabAsync(ct);

                // Regra 31: Garantir que o painel lateral do Agente esteja aberto (NUNCA clicar em close y~100)
                await EnsureAgentPanelOpenAsync(sess, ct);
                await Task.Delay(1000, ct);

                // Inspeção completa dentro do projeto Flow antes de iniciar:
                // Caso haja vídeos já gerados dentro do projeto (pausa, erro ou retomada), identifica quais takes já foram gerados,
                // baixa em 720p os que ainda não estão na pasta 'takes' e retoma exatamente de onde parou!
                if (!archivedForFullRemake)
                {
                    HashSet<int> salvagedInFlow = await TrySalvageCompletedTakesFromCurrentFlowScreenAsync(
                        sess,
                        ep,
                        flowEligibleTakes,
                        existingOnDisk,
                        ct);

                    await EnsureAgentPanelOpenAsync(sess, ct);

                    if (salvagedInFlow.Count > 0)
                    {
                        flowEligibleTakes = flowEligibleTakes
                            .Where(t => !salvagedInFlow.Contains(t.TakeNumber))
                            .ToList();
                    }
                }

                if (flowEligibleTakes.Count == 0)
                {
                    _log(string.Format("[Google Flow] Todos os {0} takes de {1} foram recuperados do projeto e já estão salvos em disco! Nenhuma nova geração necessária.",
                        effectiveTakes.Count, ep.EpisodeName));
                }
                else
                {
                    if (existingOnDisk.Count > 0)
                    {
                        string remainingPreview = string.Join(", ",
                            flowEligibleTakes.Take(10).Select(t => string.Format("Take_{0:00}", t.TakeNumber))) +
                            (flowEligibleTakes.Count > 10 ? "..." : "");
                        _log(string.Format("[Google Flow] Retomando geração exatamente de onde parou -> próximo: Take_{0:00} ({1} pendente(s) de {2}: {3}).",
                            flowEligibleTakes[0].TakeNumber, flowEligibleTakes.Count, effectiveTakes.Count, remainingPreview));
                    }

                    await ExecuteOneByOneSceneConversationInFlowAsync(
                        sess,
                        ep,
                        flowEligibleTakes,
                        allAssetFiles,
                        ingredientToResolvedName,
                        skippedAfterFlowRetries,
                        ct);
                }
            }

            // Verifica as cenas do episódio que ainda não possuem arquivo .mp4 válido salvo em disco (deram erro mesmo após suavizar no Flow)
            List<FlowTakeSpec> grokVideoTakes = new List<FlowTakeSpec>();
            for (int i = 0; i < effectiveTakes.Count; i++)
            {
                FlowTakeSpec takeSpec = effectiveTakes[i];
                string expectedMp4 = Path.Combine(ep.TakesDir, string.Format("Take_{0:00}.mp4", takeSpec.TakeNumber));
                bool hasValidMp4 = File.Exists(expectedMp4) && new FileInfo(expectedMp4).Length >= 50 * 1024;
                if (!hasValidMp4)
                {
                    grokVideoTakes.Add(takeSpec);
                }
            }

            if (grokVideoTakes.Count > 0)
            {
                if (!_config.AreAllGrokProfilesMarkedExhausted())
                {
                    string fallbackLabels = string.Join(", ", grokVideoTakes.Select(t => string.Format("Take_{0:00}", t.TakeNumber)));
                    _log(string.Format("[Fallback Flow -> Grok] {0} cena(s) continuaram com erro após pedir suavização na conversa do Flow ({1}) -> gerando vídeo no Grok Imagine!",
                        grokVideoTakes.Count, fallbackLabels));
                    await _grok.GenerateVideoTakesAsync(ep, grokVideoTakes, ingredientToResolvedName, ct);
                }
                else
                {
                    for (int i = 0; i < grokVideoTakes.Count; i++)
                        skippedAfterFlowRetries.Add(grokVideoTakes[i].TakeNumber);
                }
            }

            if (_config.AreAllGrokProfilesMarkedExhausted())
            {
                List<int> stillMissingOnDisk = new List<int>();
                for (int i = 0; i < effectiveTakes.Count; i++)
                {
                    int tn = effectiveTakes[i].TakeNumber;
                    string expectedMp4 = Path.Combine(ep.TakesDir, string.Format("Take_{0:00}.mp4", tn));
                    if (!File.Exists(expectedMp4) || new FileInfo(expectedMp4).Length < 50 * 1024)
                        stillMissingOnDisk.Add(tn);
                }

                if (stillMissingOnDisk.Count > 0)
                {
                    string skippedLabels = string.Join(", ", stillMissingOnDisk.OrderBy(n => n).Select(n => string.Format("Take_{0:00}", n)));
                    _log(string.Format("[Google Flow | Resumo de Cenas Puladas] {0} cena(s) não puderam ser geradas mesmo após suavizar no Flow (e Grok está sem créditos) -> cena(s) pulada(s): {1}. Prosseguindo com o episódio!",
                        stillMissingOnDisk.Count, skippedLabels));
                }
            }

            EpisodeParser.RefreshDiskCounters(ep);
            _log(string.Format("[Vídeo Concluído] Etapa de vídeo finalizada! Takes prontos organizados em '{0}'.", ep.TakesDir));
        }

        public async Task RegenerateSelectedTakesAsync(
            EpisodeWorkItem ep,
            List<int> takeNumbers,
            bool forceGrokVideo,
            CancellationToken ct)
        {
            if (ep == null || takeNumbers == null || takeNumbers.Count == 0)
                return;

            if (!Directory.Exists(ep.TakesDir))
                Directory.CreateDirectory(ep.TakesDir);

            HashSet<int> selectedSet = new HashSet<int>(takeNumbers);
            string backupSubDir = Path.Combine(ep.TakesDir, "_backup_regerados_" + DateTime.Now.ToString("yyyyMMdd_HHmmss"));

            foreach (int tn in selectedSet)
            {
                string existingMp4 = Path.Combine(ep.TakesDir, string.Format("Take_{0:00}.mp4", tn));
                if (File.Exists(existingMp4))
                {
                    if (!Directory.Exists(backupSubDir))
                        Directory.CreateDirectory(backupSubDir);
                    string dst = Path.Combine(backupSubDir, Path.GetFileName(existingMp4));
                    if (File.Exists(dst)) File.Delete(dst);
                    File.Move(existingMp4, dst);
                    _log(string.Format("[Regerar Take] Take_{0:00}.mp4 anterior arquivado em '{1}'.", tn, backupSubDir));
                }
            }

            List<string> allAssetFiles;
            Dictionary<string, string> ingredientToResolvedName;
            PrepareAndResolveEpisodeAssetsForFlow(ep, out allAssetFiles, out ingredientToResolvedName);

            List<FlowTakeSpec> effectiveTakes = EpisodeParser.GetEffectiveTakeSpecsForEpisode(ep)
                .Where(t => selectedSet.Contains(t.TakeNumber))
                .OrderBy(t => t.TakeNumber)
                .ToList();

            if (effectiveTakes.Count == 0)
                return;

            // Logar se houver figurino customizado/automático aplicado nos takes selecionados
            foreach (FlowTakeSpec eff in effectiveTakes)
            {
                string ingList = string.Join(", ", eff.Ingredients);
                _log(string.Format("[Regerar Take] Take_{0:00} | Ingredientes ativos (com figurino): {1}", eff.TakeNumber, ingList));
            }

            if (forceGrokVideo && !_config.AreAllGrokProfilesMarkedExhausted())
            {
                await _grok.GenerateVideoTakesAsync(ep, effectiveTakes, ingredientToResolvedName, ct);
                EpisodeParser.RefreshDiskCounters(ep);
                List<FlowTakeSpec> missingAfterGrok = effectiveTakes.Where(t =>
                {
                    string p = Path.Combine(ep.TakesDir, string.Format("Take_{0:00}.mp4", t.TakeNumber));
                    return !File.Exists(p) || new FileInfo(p).Length < 50 * 1024;
                }).ToList();

                if (missingAfterGrok.Count > 0 && _config.AreAllGrokProfilesMarkedExhausted())
                {
                    _log("[Grok Sem Créditos -> Flow] Contas do Grok sem créditos disponíveis -> regerando take(s) selecionado(s) no Google Flow anexando somente os elementos de cada cena!");
                    await RegenerateSpecificTakesInFlowAsync(ep, missingAfterGrok, allAssetFiles, ingredientToResolvedName, ct);
                }
                else
                {
                    _log(string.Format("[Regerar Take] {0} take(s) regerado(s) com sucesso via Grok Vídeo!", effectiveTakes.Count));
                }
            }
            else
            {
                if (forceGrokVideo && _config.AreAllGrokProfilesMarkedExhausted())
                {
                    _log("[Grok Sem Créditos -> Flow] Todas as contas do Grok estão sem créditos ('LIMITE ATINGIDO') -> regerando take(s) no Google Flow anexando somente os elementos de cada cena!");
                }
                await RegenerateSpecificTakesInFlowAsync(ep, effectiveTakes, allAssetFiles, ingredientToResolvedName, ct);
            }
        }

    }
}
