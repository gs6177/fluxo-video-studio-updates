using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Web.Script.Serialization;

namespace FluxoVideoStudio
{
    public class CoverReferenceModelSpec
    {
        public int ModelIndex { get; set; }
        public string SourceImagePath { get; set; }
        public string SourceFileName { get; set; }
        public string StyleGenre { get; set; }
        public string ArchetypeKey { get; set; }
        public string StyleBadge { get; set; }
        public string TypographyStyle { get; set; }
        public string CompositionAndLightingStyle { get; set; }

        public CoverReferenceModelSpec()
        {
            ModelIndex = 1;
            SourceImagePath = "";
            SourceFileName = "";
            StyleGenre = "";
            ArchetypeKey = "";
            StyleBadge = "";
            TypographyStyle = "";
            CompositionAndLightingStyle = "";
        }
    }

    public class CoverGenerationItem
    {
        public int GlobalIndex { get; set; }
        public int ModelIndex { get; set; }
        public int OptionIndex { get; set; }
        public string TargetFileName { get; set; }
        public string DisplayLabel { get; set; }
        public string ReferenceSourcePath { get; set; }
        public string FullPrompt { get; set; }

        public CoverGenerationItem()
        {
            GlobalIndex = 1;
            ModelIndex = 1;
            OptionIndex = 1;
            TargetFileName = "";
            DisplayLabel = "";
            ReferenceSourcePath = "";
            FullPrompt = "";
        }
    }

    public class StoryCoverConfig
    {
        public string CoverTitle { get; set; }
        public string CoverStyle { get; set; }
        public int OptionsPerModel { get; set; }
        public List<string> SelectedCharacterFiles { get; set; }
        public List<CoverReferenceModelSpec> ReferenceModels { get; set; }

        public StoryCoverConfig()
        {
            CoverTitle = "";
            CoverStyle = "Auto";
            OptionsPerModel = 3;
            SelectedCharacterFiles = new List<string>();
            ReferenceModels = new List<CoverReferenceModelSpec>();
        }
    }

    public static class CoverGenerator
    {
        public static string GenreToStyleKey(GenreType genre)
        {
            if (genre == GenreType.Terror) return "Terror";
            if (genre == GenreType.NovelaMistica) return "NovelaMistica";
            return "NovelaReflexao";
        }

        public static string GetGenreDisplayLabel(GenreType genre)
        {
            if (genre == GenreType.Terror) return "Terror";
            if (genre == GenreType.NovelaMistica) return "Novela Mística";
            return "Novela / Reflexão";
        }

        public static GenreType ResolveEffectiveCoverGenre(EpisodeWorkItem ep1, StoryCoverConfig cfg)
        {
            if (cfg != null && !string.IsNullOrWhiteSpace(cfg.CoverStyle))
            {
                string st = cfg.CoverStyle.Trim();
                if (string.Equals(st, "Terror", StringComparison.OrdinalIgnoreCase))
                    return GenreType.Terror;
                if (string.Equals(st, "NovelaMistica", StringComparison.OrdinalIgnoreCase))
                    return GenreType.NovelaMistica;
                if (string.Equals(st, "NovelaReflexao", StringComparison.OrdinalIgnoreCase))
                    return GenreType.NovelaReflexao;
            }

            if (ep1 != null)
            {
                if (ep1.Genre == GenreType.Terror) return GenreType.Terror;
                if (ep1.Genre == GenreType.NovelaMistica) return GenreType.NovelaMistica;
                if (ep1.Genre == GenreType.NovelaReflexao) return GenreType.NovelaReflexao;
            }

            return GenreType.NovelaReflexao;
        }

        public static List<CoverReferenceModelSpec> BuildPresetModelsForGenre(GenreType genre)
        {
            List<CoverReferenceModelSpec> list = new List<CoverReferenceModelSpec>();
            string styleKey = GenreToStyleKey(genre);
            for (int i = 1; i <= 3; i++)
            {
                CoverReferenceModelSpec spec = new CoverReferenceModelSpec();
                spec.ModelIndex = i;
                spec.SourceImagePath = "";
                spec.SourceFileName = string.Format("Modelo_Padrao_{0}_{1}", styleKey, i);
                ApplyFallbackModelByIndex(spec, i, genre);
                list.Add(spec);
            }
            return list;
        }

        public static void ReanalyzeModelsForGenre(EpisodeWorkItem ep1, StoryCoverConfig cfg)
        {
            if (cfg == null || cfg.ReferenceModels == null || cfg.ReferenceModels.Count == 0)
                return;

            GenreType effectiveGenre = ResolveEffectiveCoverGenre(ep1, cfg);
            string styleKey = GenreToStyleKey(effectiveGenre);

            for (int i = 0; i < cfg.ReferenceModels.Count; i++)
            {
                CoverReferenceModelSpec cur = cfg.ReferenceModels[i];
                int modelIdx = i + 1;
                if (cur != null && !string.IsNullOrEmpty(cur.SourceImagePath) && File.Exists(cur.SourceImagePath))
                {
                    cfg.ReferenceModels[i] = AnalyzeReferenceCoverImage(cur.SourceImagePath, modelIdx, effectiveGenre);
                }
                else
                {
                    CoverReferenceModelSpec rebuilt = new CoverReferenceModelSpec();
                    rebuilt.ModelIndex = modelIdx;
                    rebuilt.SourceImagePath = cur != null ? (cur.SourceImagePath ?? "") : "";
                    rebuilt.SourceFileName = string.Format("Modelo_Padrao_{0}_{1}", styleKey, modelIdx);
                    ApplyFallbackModelByIndex(rebuilt, modelIdx, effectiveGenre);
                    cfg.ReferenceModels[i] = rebuilt;
                }
            }
        }
        public static string GetStoryCoversDir(EpisodeWorkItem ep)
        {
            if (ep == null) return "";
            string baseDir = !string.IsNullOrWhiteSpace(ep.StoryRootPath) && Directory.Exists(ep.StoryRootPath)
                ? ep.StoryRootPath
                : ep.EpisodePath;
            if (string.IsNullOrWhiteSpace(baseDir)) return "";
            return Path.Combine(baseDir, "capas");
        }

        public static string GetStoryCoversConfigPath(EpisodeWorkItem ep)
        {
            string dir = GetStoryCoversDir(ep);
            if (string.IsNullOrEmpty(dir)) return "";
            return Path.Combine(dir, "capas_config.json");
        }

        public static string GetStoryCoversPromptsTxtPath(EpisodeWorkItem ep)
        {
            string dir = GetStoryCoversDir(ep);
            if (string.IsNullOrEmpty(dir)) return "";
            return Path.Combine(dir, "prompts_capas.txt");
        }

        public static EpisodeWorkItem ResolveEp1Episode(StoryProject story, EpisodeWorkItem currentEp)
        {
            if (story != null && story.Episodes != null && story.Episodes.Count > 0)
            {
                EpisodeWorkItem ep1 = story.Episodes.FirstOrDefault(e =>
                    e.EpisodeNumber == 1 ||
                    string.Equals(e.EpisodeName, "EP.1", StringComparison.OrdinalIgnoreCase));
                if (ep1 != null)
                {
                    EpisodeWorkItem refreshed = EpisodeParser.ParseEpisodeFolder(ep1.EpisodePath, ep1.StoryName, ep1.Genre, ep1.StoryRootPath);
                    return refreshed ?? ep1;
                }
            }

            if (currentEp != null && !string.IsNullOrWhiteSpace(currentEp.StoryRootPath))
            {
                string ep1Dir = Path.Combine(currentEp.StoryRootPath, "EP.1");
                if (Directory.Exists(ep1Dir))
                {
                    EpisodeWorkItem parsed = EpisodeParser.ParseEpisodeFolder(ep1Dir, currentEp.StoryName, currentEp.Genre, currentEp.StoryRootPath);
                    if (parsed != null)
                        return parsed;
                }
            }

            return currentEp;
        }

        public static string ExtractRawStoryTitle(EpisodeWorkItem ep1)
        {
            if (ep1 == null) return "HISTÓRIA ORIGINAL";

            if (!string.IsNullOrWhiteSpace(ep1.RoteiroText))
            {
                Match m = Regex.Match(
                    ep1.RoteiroText,
                    @"^\s*T[ÍI]TULO(?:\s+DA\s+HIST[ÓO]RIA)?\s*:\s*(.+)$",
                    RegexOptions.IgnoreCase | RegexOptions.Multiline);
                if (m.Success)
                {
                    string rawTitle = m.Groups[1].Value.Trim().Trim('"', '\'', '.');
                    if (!string.IsNullOrWhiteSpace(rawTitle))
                        return rawTitle.ToUpperInvariant();
                }
            }

            string fallback = (ep1.StoryName ?? "HISTORIA").Replace("_", " ").Replace("-", " ").Trim();
            fallback = Regex.Replace(fallback, @"\s{2,}", " ");
            return string.IsNullOrWhiteSpace(fallback) ? "HISTÓRIA ORIGINAL" : fallback.ToUpperInvariant();
        }

        /// <summary>
        /// Condensa títulos longos (> 22 caracteres) para 2 a 4 palavras de impacto estilo pôster
        /// (ex.: "O PACTO DO VIOLEIRO COM O CRAMULHÃO" -> "O PACTO DO VIOLEIRO"), garantindo letras
        /// gigantes, grossas e fiéis ao modelo de escrita sem espremer dezenas de letras na largura 9:16.
        /// </summary>
        public static string ShortenToImpactPosterTitle(string rawTitle)
        {
            if (string.IsNullOrWhiteSpace(rawTitle))
                return "HISTÓRIA ORIGINAL";

            string t = Regex.Replace(rawTitle.Trim().ToUpperInvariant(), @"\s{2,}", " ");
            if (t.Length <= 22)
                return t;

            // Se tiver "QUE TENTOU ENGANAR O ..." prioriza o núcleo principal ou remove o complemento longo
            string stripped = Regex.Replace(
                t,
                @"\s+(COM\s+O\s+.+|COM\s+A\s+.+|CONTRA\s+O\s+.+|CONTRA\s+A\s+.+|QUE\s+.+|ONDE\s+.+|QUANDO\s+.+)$",
                "",
                RegexOptions.IgnoreCase).Trim();

            if (!string.IsNullOrWhiteSpace(stripped) && stripped.Length >= 6 && stripped.Length <= 24)
                return stripped;

            string[] words = t.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            if (words.Length <= 3)
                return t;

            StringBuilder sb = new StringBuilder();
            string[] trailingConnectors = new[] { "DE", "DO", "DA", "DOS", "DAS", "COM", "NO", "NA", "NOS", "NAS", "PARA", "POR", "E", "O", "A" };
            for (int i = 0; i < words.Length; i++)
            {
                if (sb.Length > 0 && (sb.Length + 1 + words[i].Length) > 22 && i >= 2)
                    break;
                if (sb.Length > 0) sb.Append(" ");
                sb.Append(words[i]);
            }

            List<string> kept = sb.ToString().Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries).ToList();
            while (kept.Count > 2 && trailingConnectors.Contains(kept[kept.Count - 1], StringComparer.OrdinalIgnoreCase))
            {
                kept.RemoveAt(kept.Count - 1);
            }

            return string.Join(" ", kept);
        }

        public static string ExtractDefaultCoverTitle(EpisodeWorkItem ep1)
        {
            return ShortenToImpactPosterTitle(ExtractRawStoryTitle(ep1));
        }

        /// <summary>
        /// Cria uma cópia temporária do personagem de EP.1\assets apagando automaticamente o texto do nome
        /// escrito no topo acima da cabeça ("O Violeiro", "O Cramulhão", etc.), impedindo que a fonte lisa/gótica
        /// do asset contamine o modelo de escrita da capa!
        /// </summary>
        public static string CreateCleanCharacterCopyWithoutTopLabel(string srcCharPath, string tempDir)
        {
            if (string.IsNullOrEmpty(srcCharPath) || !File.Exists(srcCharPath))
                return srcCharPath;

            try
            {
                Directory.CreateDirectory(tempDir);
                string outPath = Path.Combine(tempDir, "char_limpo_" + Path.GetFileName(srcCharPath));
                byte[] bytes = File.ReadAllBytes(srcCharPath);
                using (MemoryStream ms = new MemoryStream(bytes))
                using (Bitmap bmp = new Bitmap(ms))
                {
                    int w = bmp.Width;
                    int h = bmp.Height;
                    int cutY = (int)(h * 0.13);
                    bool sawInk = false;

                    int startY = Math.Max(2, (int)(h * 0.015));
                    int maxScanY = Math.Min(h - 1, (int)(h * 0.25));
                    int minX = (int)(w * 0.08);
                    int maxX = (int)(w * 0.92);

                    for (int y = startY; y < maxScanY; y++)
                    {
                        int darkPixels = 0;
                        for (int x = minX; x < maxX; x += 3)
                        {
                            Color c = bmp.GetPixel(x, y);
                            if (c.R < 228 || c.G < 228 || c.B < 228)
                                darkPixels++;
                        }

                        if (darkPixels > 4)
                        {
                            sawInk = true;
                        }
                        else if (sawInk && darkPixels <= 1)
                        {
                            cutY = Math.Min(maxScanY, y + 2);
                            break;
                        }
                    }

                    Color bgCol = bmp.GetPixel(Math.Min(5, w - 1), Math.Min(5, h - 1));
                    if (bgCol.R < 210 || bgCol.G < 210 || bgCol.B < 210)
                        bgCol = Color.White;

                    using (Graphics g = Graphics.FromImage(bmp))
                    using (SolidBrush br = new SolidBrush(bgCol))
                    {
                        g.FillRectangle(br, 0, 0, w, cutY);
                    }

                    bmp.Save(outPath, ImageFormat.Jpeg);
                }
                return outPath;
            }
            catch
            {
                return srcCharPath;
            }
        }

        /// <summary>
        /// Extrai APENAS a faixa superior limpa da tipografia/escrita da imagem de referência (top 27%),
        /// mascarando qualquer pedaço inferior de cabelo, chifre ou animal da referência em fundo escuro neutro.
        /// Assim o gerador enxerga visualmente 100% o estilo exato das letras sem receber nenhum personagem antigo!
        /// </summary>
        public static string CreateCleanTypographySampleBanner(string refCoverPath, int modelIndex, string tempDir)
        {
            if (string.IsNullOrEmpty(refCoverPath) || !File.Exists(refCoverPath))
                return "";

            try
            {
                Directory.CreateDirectory(tempDir);
                string outPath = Path.Combine(tempDir, string.Format("modelo_escrita_{0}.jpg", modelIndex));
                byte[] bytes = File.ReadAllBytes(refCoverPath);
                using (MemoryStream ms = new MemoryStream(bytes))
                using (Bitmap src = new Bitmap(ms))
                {
                    int w = src.Width;
                    int cropH = Math.Max(80, (int)(src.Height * 0.275));

                    // Detecta a luminosidade real do fundo no topo (para não escurecer capas claras de Novela/Reflexão ou Mística!)
                    long sumR = 0, sumG = 0, sumB = 0;
                    int bgSamples = 0;
                    int edgeW = Math.Max(4, (int)(w * 0.08));
                    int topBandH = Math.Max(6, (int)(cropH * 0.16));
                    for (int y = 2; y < topBandH; y += 2)
                    {
                        for (int x = 2; x < edgeW; x += 2)
                        {
                            Color cl = src.GetPixel(x, y);
                            sumR += cl.R; sumG += cl.G; sumB += cl.B; bgSamples++;
                            Color cr = src.GetPixel(Math.Max(0, w - 1 - x), y);
                            sumR += cr.R; sumG += cr.G; sumB += cr.B; bgSamples++;
                        }
                    }

                    int bgR = bgSamples > 0 ? (int)(sumR / bgSamples) : 12;
                    int bgG = bgSamples > 0 ? (int)(sumG / bgSamples) : 14;
                    int bgB = bgSamples > 0 ? (int)(sumB / bgSamples) : 20;
                    double bgLuma = (0.299 * bgR) + (0.587 * bgG) + (0.114 * bgB);
                    bool isDarkTopBg = bgLuma < 105.0;

                    int fadeTargetR = isDarkTopBg ? 10 : bgR;
                    int fadeTargetG = isDarkTopBg ? 12 : bgG;
                    int fadeTargetB = isDarkTopBg ? 18 : bgB;

                    using (Bitmap dst = new Bitmap(w, cropH))
                    {
                        for (int y = 0; y < cropH; y++)
                        {
                            double yf = (double)y / Math.Max(1, cropH);
                            for (int x = 0; x < w; x++)
                            {
                                double xf = (double)x / Math.Max(1, w);
                                Color c = src.GetPixel(x, y);
                                int r = c.R;
                                int g = c.G;
                                int b = c.B;

                                if (isDarkTopBg)
                                {
                                    bool isWarmOrBrightGlyph =
                                        (r > 105 && r > (b + 30)) ||
                                        (r > 200 && g > 195 && b > 175) ||
                                        (b > 175 && (r > 140 || g > 150));

                                    // Remove olhos/orelhas/topo de cabeça que apareçam na base central da faixa (yf > 0.72)
                                    bool inBottomCenterHeadZone = (yf > 0.72 && xf > 0.34 && xf < 0.66 && g < 70 && r < 210);

                                    if (inBottomCenterHeadZone || (yf > 0.50 && !isWarmOrBrightGlyph))
                                    {
                                        double fade = inBottomCenterHeadZone
                                            ? 1.0
                                            : Math.Min(1.0, (yf - 0.50) / 0.24);
                                        int nr = (int)(r * (1.0 - fade) + fadeTargetR * fade);
                                        int ng = (int)(g * (1.0 - fade) + fadeTargetG * fade);
                                        int nb = (int)(b * (1.0 - fade) + fadeTargetB * fade);
                                        dst.SetPixel(x, y, Color.FromArgb(nr, ng, nb));
                                    }
                                    else
                                    {
                                        dst.SetPixel(x, y, c);
                                    }
                                }
                                else
                                {
                                    // Fundo claro/colorido (Novela/Reflexão ou Mística diurna): preserva 100% das letras e suaviza apenas possível topo de cabeça na borda inferior
                                    int diffFromBg = Math.Abs(r - bgR) + Math.Abs(g - bgG) + Math.Abs(b - bgB);
                                    bool isStrongGlyph = diffFromBg > 135;
                                    bool inBottomHeadZone = (yf > 0.78 && xf > 0.32 && xf < 0.68 && !isStrongGlyph);
                                    if (inBottomHeadZone)
                                    {
                                        double fade = Math.Min(1.0, (yf - 0.78) / 0.16);
                                        int nr = (int)(r * (1.0 - fade) + fadeTargetR * fade);
                                        int ng = (int)(g * (1.0 - fade) + fadeTargetG * fade);
                                        int nb = (int)(b * (1.0 - fade) + fadeTargetB * fade);
                                        dst.SetPixel(x, y, Color.FromArgb(nr, ng, nb));
                                    }
                                    else
                                    {
                                        dst.SetPixel(x, y, c);
                                    }
                                }
                            }
                        }

                        dst.Save(outPath, ImageFormat.Jpeg);
                    }
                }
                return outPath;
            }
            catch
            {
                return "";
            }
        }

        public static List<GrokAssetSpec> DiscoverAvailableEp1Characters(EpisodeWorkItem ep1)
        {
            List<GrokAssetSpec> list = new List<GrokAssetSpec>();
            if (ep1 == null) return list;

            HashSet<string> seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            if (ep1.GrokSpecs != null)
            {
                foreach (GrokAssetSpec s in ep1.GrokSpecs)
                {
                    if (s == null || s.IsScenario || string.IsNullOrWhiteSpace(s.TargetFileName))
                        continue;
                    if (seen.Add(s.TargetFileName))
                        list.Add(s);
                }
            }

            if (!string.IsNullOrWhiteSpace(ep1.AssetsDir) && Directory.Exists(ep1.AssetsDir))
            {
                string[] jpgs = Directory.GetFiles(ep1.AssetsDir, "*.jpg")
                    .OrderBy(p => Path.GetFileName(p), StringComparer.OrdinalIgnoreCase)
                    .ToArray();

                foreach (string full in jpgs)
                {
                    string fn = Path.GetFileName(full);
                    if (fn.IndexOf("Cenario", StringComparison.OrdinalIgnoreCase) >= 0)
                        continue;
                    if (fn.IndexOf("Personagem", StringComparison.OrdinalIgnoreCase) < 0 && list.Count > 0)
                        continue;
                    if (seen.Add(fn))
                    {
                        GrokAssetSpec extra = new GrokAssetSpec();
                        extra.OrderIndex = list.Count + 1;
                        extra.IsScenario = false;
                        extra.TargetFileName = fn;
                        extra.DisplayTitle = EpisodeParser.CleanAssetStem(fn);
                        extra.RawPromptLine = extra.DisplayTitle;
                        list.Add(extra);
                    }
                }
            }

            return list;
        }

        public static List<string> AutoSelectFocalCharacterFileNames(EpisodeWorkItem ep1)
        {
            List<string> selected = new List<string>();
            if (ep1 == null) return selected;

            List<GrokAssetSpec> allChars = DiscoverAvailableEp1Characters(ep1);
            if (allChars.Count == 0) return selected;

            HashSet<string> validCharNames = new HashSet<string>(
                allChars.Select(c => c.TargetFileName),
                StringComparer.OrdinalIgnoreCase);

            if (ep1.FlowTakes != null && ep1.FlowTakes.Count > 0)
            {
                FlowTakeSpec hookTake = ep1.FlowTakes[0];
                if (hookTake != null && hookTake.Ingredients != null)
                {
                    foreach (string ing in hookTake.Ingredients)
                    {
                        if (validCharNames.Contains(ing) && !selected.Contains(ing, StringComparer.OrdinalIgnoreCase))
                        {
                            selected.Add(ing);
                            if (selected.Count >= 2)
                                return selected;
                        }
                    }
                }
            }

            if (selected.Count == 0)
            {
                GrokAssetSpec propVariant = allChars.FirstOrDefault(c =>
                    c.TargetFileName.IndexOf("Personagem_1_", StringComparison.OrdinalIgnoreCase) >= 0 &&
                    c.TargetFileName.IndexOf("_Com_", StringComparison.OrdinalIgnoreCase) >= 0);
                GrokAssetSpec firstChar = propVariant ?? allChars[0];
                selected.Add(firstChar.TargetFileName);
            }

            if (selected.Count < 2 && allChars.Count > 1)
            {
                string[] villainKeywords = new string[]
                {
                    "Cramulhao", "Tinhoso", "Diabo", "Mae_de_Santo", "Mae_DAgua", "Rasga_Mortalha",
                    "Bruxa", "Assombracao", "Lobisomem", "Boto", "Mula", "Corpo_Seco", "Sombra",
                    "Vila", "Rival", "Invejosa", "Rico", "Fazendeiro", "Patrao", "Comerciante"
                };

                string firstPrefix = ExtractPersonagemSlotKey(selected[0]);
                GrokAssetSpec antag = allChars.FirstOrDefault(c =>
                    !string.Equals(ExtractPersonagemSlotKey(c.TargetFileName), firstPrefix, StringComparison.OrdinalIgnoreCase) &&
                    villainKeywords.Any(k =>
                        c.TargetFileName.IndexOf(k, StringComparison.OrdinalIgnoreCase) >= 0 ||
                        (c.DisplayTitle ?? "").IndexOf(k.Replace("_", " "), StringComparison.OrdinalIgnoreCase) >= 0));

                if (antag == null)
                {
                    antag = allChars.FirstOrDefault(c =>
                        !string.Equals(ExtractPersonagemSlotKey(c.TargetFileName), firstPrefix, StringComparison.OrdinalIgnoreCase));
                }

                if (antag != null && !selected.Contains(antag.TargetFileName, StringComparer.OrdinalIgnoreCase))
                    selected.Add(antag.TargetFileName);
            }

            return selected;
        }

        private static string ExtractPersonagemSlotKey(string fileName)
        {
            if (string.IsNullOrEmpty(fileName)) return "";
            Match m = Regex.Match(fileName, @"Personagem[_\s]*(\d+)", RegexOptions.IgnoreCase);
            return m.Success ? ("P" + m.Groups[1].Value) : fileName;
        }

        public static List<string> ResolveSelectedCharacterPathsOnDisk(EpisodeWorkItem ep1, EpisodeWorkItem currentEp, List<string> selectedFileNames)
        {
            List<string> paths = new List<string>();
            if (selectedFileNames == null || selectedFileNames.Count == 0)
                return paths;

            List<string> candidateDirs = new List<string>();
            if (ep1 != null && !string.IsNullOrWhiteSpace(ep1.AssetsDir))
                candidateDirs.Add(ep1.AssetsDir);
            if (currentEp != null && !string.IsNullOrWhiteSpace(currentEp.AssetsDir) &&
                !candidateDirs.Contains(currentEp.AssetsDir, StringComparer.OrdinalIgnoreCase))
                candidateDirs.Add(currentEp.AssetsDir);

            foreach (string fn in selectedFileNames)
            {
                if (string.IsNullOrWhiteSpace(fn)) continue;
                string found = "";
                foreach (string dir in candidateDirs)
                {
                    if (!Directory.Exists(dir)) continue;
                    string p = Path.Combine(dir, fn);
                    if (File.Exists(p) && new FileInfo(p).Length > 1024)
                    {
                        found = p;
                        break;
                    }
                }
                if (!string.IsNullOrEmpty(found) && !paths.Contains(found, StringComparer.OrdinalIgnoreCase))
                    paths.Add(found);
            }

            return paths;
        }

        public static string ExtractStoryUniverseSummary(EpisodeWorkItem ep1)
        {
            return ExtractStoryUniverseSummary(ep1, ep1 != null ? ep1.Genre : GenreType.NovelaReflexao);
        }

        public static string ExtractStoryUniverseSummary(EpisodeWorkItem ep1, GenreType effectiveGenre)
        {
            if (ep1 == null) return "cenário cinematográfico dramático brasileiro";

            if (ep1.GrokSpecs != null)
            {
                string hookScenFile = "";
                if (ep1.FlowTakes != null && ep1.FlowTakes.Count > 0 && ep1.FlowTakes[0].Ingredients != null)
                {
                    hookScenFile = ep1.FlowTakes[0].Ingredients.FirstOrDefault(i =>
                        i.IndexOf("Cenario", StringComparison.OrdinalIgnoreCase) >= 0) ?? "";
                }

                GrokAssetSpec scen = null;
                if (!string.IsNullOrEmpty(hookScenFile))
                {
                    scen = ep1.GrokSpecs.FirstOrDefault(s =>
                        s.IsScenario && string.Equals(s.TargetFileName, hookScenFile, StringComparison.OrdinalIgnoreCase));
                }
                if (scen == null)
                {
                    scen = ep1.GrokSpecs.LastOrDefault(s => s.IsScenario);
                }

                if (scen != null)
                {
                    string title = (scen.DisplayTitle ?? "").Trim();
                    title = Regex.Replace(title, @"^Cen[áa]rio\s*[A-Z0-9]+\s*:\s*", "", RegexOptions.IgnoreCase).Trim();
                    if (!string.IsNullOrEmpty(title))
                        return title;
                }
            }

            if (effectiveGenre == GenreType.Terror)
                return "ambiente rústico sombrio do interior brasileiro";
            if (effectiveGenre == GenreType.NovelaMistica)
                return "ambiente urbano brasileiro bem iluminado com atmosfera mística e elegante";
            return "ambiente brasileiro cotidiano bem iluminado de alto impacto emocional";
        }

        private static string SummarizeCharacterForCoverPrompt(GrokAssetSpec spec)
        {
            if (spec == null) return "personagem principal da história";

            string cleanName = (spec.DisplayTitle ?? "").Trim();
            cleanName = Regex.Replace(cleanName, @"^Personagem\s*\d+[A-Za-z]?\s*:\s*", "", RegexOptions.IgnoreCase).Trim();
            cleanName = Regex.Replace(cleanName, @"^em\s+cima\s+da\s+cabe[cç]a\s+", "", RegexOptions.IgnoreCase).Trim();
            if (string.IsNullOrEmpty(cleanName))
                cleanName = EpisodeParser.CleanAssetStem(spec.TargetFileName);

            string raw = (spec.RawPromptLine ?? "").Trim();
            raw = Regex.Replace(raw, @"^.*?\bFUNDO\s+BRANCO\s+NEUTRO\s+PURO[^.]*\.\s*", "", RegexOptions.IgnoreCase);
            raw = Regex.Replace(raw, @"com\s+o\s+texto\s+""[^""]*""\s+escrito[^.,]*[.,]?", "", RegexOptions.IgnoreCase);
            raw = Regex.Replace(raw, @"Excelente\s+ilumina[çc][ãa]o\s+de\s+est[úu]dio[^.]*\.?", "", RegexOptions.IgnoreCase);
            raw = Regex.Replace(raw, @"\([^)]*sem\s+rosto\s+ou\s+apar[êe]ncia\s+de\s+crian[çc]a[^)]*\)", "(feições adultas maduras)", RegexOptions.IgnoreCase);
            raw = Regex.Replace(raw, @"\s{2,}", " ").Trim();
            if (raw.Length > 240)
                raw = raw.Substring(0, 240).TrimEnd(',', ';', ' ') + "...";

            return string.IsNullOrEmpty(raw)
                ? cleanName
                : string.Format("{0} ({1})", cleanName, raw);
        }

        public static void SplitPosterTitleForModel(
            string rawTitle,
            string archetypeKey,
            out string line1,
            out string middleConnector,
            out string line2)
        {
            middleConnector = "";
            string clean = string.IsNullOrWhiteSpace(rawTitle) ? "HISTÓRIA ORIGINAL" : Regex.Replace(rawTitle.Trim().ToUpperInvariant(), @"\s{2,}", " ");
            string[] words = clean.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

            if (words.Length == 1)
            {
                line1 = words[0];
                line2 = "";
                return;
            }

            if (words.Length == 2)
            {
                line1 = words[0];
                line2 = words[1];
                return;
            }

            string[] connectors = new[] { "DE", "DO", "DA", "DOS", "DAS", "NO", "NA", "E" };

            // Modelos 3D monumentais em 3 níveis (ex.: "CAVALO" / "DAS" / "TREVAS" ou "O SEGREDO" / "DA" / "FORTUNA")
            if (string.Equals(archetypeKey, "ColossalSkyShadow", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(archetypeKey, "MisticaUrbanShadowSplit", StringComparison.OrdinalIgnoreCase))
            {
                int connIdx = -1;
                for (int i = 1; i < words.Length - 1; i++)
                {
                    if (connectors.Contains(words[i], StringComparer.OrdinalIgnoreCase))
                        connIdx = i;
                }
                if (connIdx > 0 && connIdx < words.Length - 1)
                {
                    line1 = string.Join(" ", words.Take(connIdx).ToArray());
                    middleConnector = words[connIdx];
                    line2 = string.Join(" ", words.Skip(connIdx + 1).ToArray());
                    return;
                }
            }

            // Modelos de 2 linhas (ex.: "O PACTO DO" / "VIOLEIRO" ou "A LIÇÃO DA" / "FAXINEIRA")
            string lastWord = words[words.Length - 1];
            if (lastWord.Length >= 6)
            {
                line1 = string.Join(" ", words.Take(words.Length - 1).ToArray());
                line2 = lastWord;
                return;
            }

            int mid = words.Length / 2;
            line1 = string.Join(" ", words.Take(mid).ToArray());
            line2 = string.Join(" ", words.Skip(mid).ToArray());
        }

        public static string BuildStrictTypographyBlueprint(string title, CoverReferenceModelSpec model, bool hasAttachedTypographySample)
        {
            return BuildStrictTypographyBlueprint(title, model, hasAttachedTypographySample, GenreType.Terror);
        }

        public static string BuildStrictTypographyBlueprint(string title, CoverReferenceModelSpec model, bool hasAttachedTypographySample, GenreType effectiveGenre)
        {
            string line1;
            string midConn;
            string line2;
            SplitPosterTitleForModel(title, model != null ? model.ArchetypeKey : "", out line1, out midConn, out line2);

            string sampleRefNote = hasAttachedTypographySample
                ? "Copie FIELMENTE 100% da mesma fonte, espessura, inclinação, textura interna, acabamento das bordas e cores exatas da faixa de amostra de letras anexada (ignorando totalmente as palavras antigas da amostra e escrevendo SOMENTE o novo título abaixo). "
                : "";

            string arch = model != null ? (model.ArchetypeKey ?? "") : "";

            // ===================== TERROR =====================
            if (string.Equals(arch, "CandleFaceToFace", StringComparison.OrdinalIgnoreCase))
            {
                string linesLayout = string.IsNullOrEmpty(line2)
                    ? string.Format("1 LINHA GIGANTE: \"{0}\"", line1)
                    : string.Format("LINHA 1 ACIMA: \"{0}\" / LINHA 2 GIGANTE ABAIXO: \"{1}\"", line1, line2);

                return sampleRefNote + string.Format(
                    "PADRONIZAÇÃO OBRIGATÓRIA DA ESCRITA NO TOPO ({0}): Incline todo o bloco de texto 12 graus para cima na diagonal da esquerda para a direita ocupando de ponta a ponta o terço superior. " +
                    "Use EXCLUSIVAMENTE caligrafia manual selvagem pintada com pincel chato seco largo de cerdas aparentes e pontas de tinta rasgadas (rough hand-painted dry-brush horror lettering, visible brush bristle streaks and jagged paint tips, PROIBIDO fonte lisa ou reta). " +
                    "Cada letra individual deve ter degradê interno vertical contínuo: topo da letra em amarelo-ouro vivo (#FFD200), meio em laranja-fogo (#FF6A00) e base da letra em vermelho-carmim (#D90416).",
                    linesLayout);
            }

            if (string.Equals(arch, "ColossalSkyShadow", StringComparison.OrdinalIgnoreCase))
            {
                string linesLayout;
                if (!string.IsNullOrEmpty(midConn) && !string.IsNullOrEmpty(line2))
                {
                    linesLayout = string.Format(
                        "NÍVEL 1 GRANDE EM ARCO NO TOPO: \"{0}\" / NÍVEL 2 BEM PEQUENO CENTRALIZADO NO VÃO: \"{1}\" / NÍVEL 3 COLOSSAL DE MARGEM A MARGEM: \"{2}\"",
                        line1, midConn, line2);
                }
                else if (!string.IsNullOrEmpty(line2))
                {
                    linesLayout = string.Format("LINHA 1 GRANDE EM ARCO: \"{0}\" / LINHA 2 COLOSSAL DE MARGEM A MARGEM: \"{1}\"", line1, line2);
                }
                else
                {
                    linesLayout = string.Format("BLOCO MONUMENTAL CENTRALIZADO: \"{0}\"", line1);
                }

                return sampleRefNote + string.Format(
                    "PADRONIZAÇÃO OBRIGATÓRIA DA ESCRITA NO TOPO ({0}): Bloco simétrico monumental centralizado ocupando toda a largura superior. " +
                    "Use EXCLUSIVAMENTE letras maiúsculas 3D maciças serifadas chanfradas com paredes laterais grossas extrudadas em rocha vulcânica escura e ferro queimado (heavy 3D extruded chiseled serif block letters made of dark cracked volcanic stone with glowing molten orange-yellow lava fissures inside, PROIBIDO fonte 2D plana). " +
                    "A face escura trincada de cada letra deve revelar rachaduras internas incandescentes de magma amarelo-laranja brilhante (#FF8800) e pontas serifadas afiadas.",
                    linesLayout);
            }

            if (string.Equals(arch, "MysticObjectTemptation", StringComparison.OrdinalIgnoreCase))
            {
                string linesLayout = string.IsNullOrEmpty(line2)
                    ? string.Format("LINHA GIGANTE: \"{0}\"", line1)
                    : string.Format("LINHA 1 MENOR ACIMA: \"{0}\" / LINHA 2 GIGANTE (2,5x MAIS ALTA) ABAIXO: \"{1}\"", line1, line2);

                return sampleRefNote + string.Format(
                    "PADRONIZAÇÃO OBRIGATÓRIA DA ESCRITA NO TOPO ({0}): Incline todo o bloco de texto 10 graus para cima na diagonal da esquerda para a direita. " +
                    "A LINHA 1 (\"{1}\") deve ser escrita em letras maiúsculas condensadas grossas amarelo-ouro vibrante (#FFD000) com textura áspera trincada desgastada e sombra 3D preta curta. " +
                    "A LINHA 2 GIGANTE (\"{2}\") deve ocupar de margem a margem em tipografia de terror condensada alta vermelho-sangue intenso (#EE0A1B) com textura interna riscada áspera e TODAS as bases inferiores das letras terminando em longas farpas verticais pontiagudas rasgadas para baixo como garras/lascas afiadas (tall condensed jagged horror claw-splinter red lettering with shredded vertical spikes at the bottom and red glowing embers, PROIBIDO fonte reta comum).",
                    linesLayout,
                    line1,
                    string.IsNullOrEmpty(line2) ? line1 : line2);
            }

            // ===================== NOVELA MÍSTICA =====================
            if (string.Equals(arch, "MisticaGoldVioletAura", StringComparison.OrdinalIgnoreCase))
            {
                string linesLayout = string.IsNullOrEmpty(line2)
                    ? string.Format("1 LINHA IMPONENTE CENTRALIZADA: \"{0}\"", line1)
                    : string.Format("LINHA 1 ELEGANTE ACIMA: \"{0}\" / LINHA 2 GIGANTE EM DESTAQUE ABAIXO: \"{1}\"", line1, line2);

                return sampleRefNote + string.Format(
                    "PADRONIZAÇÃO OBRIGATÓRIA DA ESCRITA NO TOPO ({0}): Bloco centralizado ocupando com imponência o terço superior da arte. " +
                    "Use EXCLUSIVAMENTE letras maiúsculas 3D cinematográficas luxuosas em ouro metálico polido (#FFD700 para #D48A00) com chanfro brilhante, contorno escuro elegante e leve halo luminoso dourado-violeta (3D luxury metallic gold beveled mystery-drama poster lettering with polished specular highlights and subtle golden-violet glow, PROIBIDO fonte de terror, sangue, lava ou letras rasgadas).",
                    linesLayout);
            }

            if (string.Equals(arch, "MisticaDualDestiny", StringComparison.OrdinalIgnoreCase))
            {
                string linesLayout = string.IsNullOrEmpty(line2)
                    ? string.Format("LINHA GIGANTE: \"{0}\"", line1)
                    : string.Format("LINHA 1 MENOR ACIMA: \"{0}\" / LINHA 2 GIGANTE (2x MAIS ALTA) ABAIXO: \"{1}\"", line1, line2);

                return sampleRefNote + string.Format(
                    "PADRONIZAÇÃO OBRIGATÓRIA DA ESCRITA NO TOPO ({0}): Composição de pôster de série mística urbana ocupando de margem a margem o terço superior. " +
                    "A LINHA 1 (\"{1}\") deve ser escrita em letras maiúsculas limpas em branco-pérola luminoso (#FFF7E6) com sombra 3D discreta. " +
                    "A LINHA 2 GIGANTE (\"{2}\") deve ser em letras maiúsculas 3D encorpadas de alto impacto em dourado-âmbar reluzente (#FFB703) com reflexo metálico suave e brilho místico refinado (bold dual-tone pearl-white and radiant metallic amber-gold prestige drama lettering, clean crisp edges, PROIBIDO farpas de terror, sangue ou aparência macabra).",
                    linesLayout,
                    line1,
                    string.IsNullOrEmpty(line2) ? line1 : line2);
            }

            if (string.Equals(arch, "MisticaUrbanShadowSplit", StringComparison.OrdinalIgnoreCase))
            {
                string linesLayout;
                if (!string.IsNullOrEmpty(midConn) && !string.IsNullOrEmpty(line2))
                {
                    linesLayout = string.Format(
                        "NÍVEL 1 GRANDE NO TOPO: \"{0}\" / NÍVEL 2 MENOR CENTRALIZADO: \"{1}\" / NÍVEL 3 GIGANTE DE MARGEM A MARGEM: \"{2}\"",
                        line1, midConn, line2);
                }
                else if (!string.IsNullOrEmpty(line2))
                {
                    linesLayout = string.Format("LINHA 1 ACIMA: \"{0}\" / LINHA 2 MONUMENTAL ABAIXO: \"{1}\"", line1, line2);
                }
                else
                {
                    linesLayout = string.Format("BLOCO MONUMENTAL CENTRALIZADO: \"{0}\"", line1);
                }

                return sampleRefNote + string.Format(
                    "PADRONIZAÇÃO OBRIGATÓRIA DA ESCRITA NO TOPO ({0}): Bloco simétrico cinematográfico centralizado no terço superior. " +
                    "Use EXCLUSIVAMENTE letras maiúsculas 3D serifadas elegantes em metal escovado ouro-envelhecido e prata luminosa (#F5D061 e #E2E8F0) com relevo chanfrado de pôster de série dramática mística (3D beveled brushed-gold and luminous silver serif prestige series lettering with crisp shadow, PROIBIDO rocha vulcânica, lava, sangue ou estética de horror).",
                    linesLayout);
            }

            // ===================== NOVELA / REFLEXÃO =====================
            if (string.Equals(arch, "NovelaWarmGoldenDrama", StringComparison.OrdinalIgnoreCase))
            {
                string linesLayout = string.IsNullOrEmpty(line2)
                    ? string.Format("1 LINHA GRANDE CENTRALIZADA: \"{0}\"", line1)
                    : string.Format("LINHA 1 ACIMA: \"{0}\" / LINHA 2 GIGANTE ABAIXO: \"{1}\"", line1, line2);

                return sampleRefNote + string.Format(
                    "PADRONIZAÇÃO OBRIGATÓRIA DA ESCRITA NO TOPO ({0}): Bloco limpo e ultra-legível centralizado ocupando o terço superior. " +
                    "A LINHA 1 (\"{1}\") em letras maiúsculas 3D limpas branco puro brilhante (#FFFFFF) e a LINHA 2 GIGANTE (\"{2}\") em amarelo-ouro solar vibrante (#FFCC00 para #F59E0B) com contorno escuro suave e sombra projetada limpa para leitura imediata no celular (clean bold 3D cinematic emotional drama soap-opera lettering in pure white and warm golden-yellow, PROIBIDO fontes de terror, rachaduras, sangue ou estética assustadora).",
                    linesLayout,
                    line1,
                    string.IsNullOrEmpty(line2) ? line1 : line2);
            }

            if (string.Equals(arch, "NovelaFaceToFaceConflict", StringComparison.OrdinalIgnoreCase))
            {
                string linesLayout = string.IsNullOrEmpty(line2)
                    ? string.Format("1 LINHA DE ALTO IMPACTO: \"{0}\"", line1)
                    : string.Format("LINHA 1 ACIMA: \"{0}\" / LINHA 2 GIGANTE ABAIXO: \"{1}\"", line1, line2);

                return sampleRefNote + string.Format(
                    "PADRONIZAÇÃO OBRIGATÓRIA DA ESCRITA NO TOPO ({0}): Bloco firme e chamativo ocupando de margem a margem o terço superior em tipografia bold cinematográfica de novela brasileira. " +
                    "Use letras maiúsculas 3D grossas sem serifa combinando branco-creme luminoso (#FFFDF5) na 1ª linha e laranja-âmbar quente vibrante (#FF9F1C) na 2ª linha com borda escura limpa e brilho sutil de cinema (bold modern Brazilian drama poster typography, crisp thick 3D sans-serif letters with high contrast readability, PROIBIDO fontes de terror, respingos, farpas ou sujeira macabra).",
                    linesLayout);
            }

            if (string.Equals(arch, "NovelaHeartfeltSpotlight", StringComparison.OrdinalIgnoreCase))
            {
                string linesLayout = string.IsNullOrEmpty(line2)
                    ? string.Format("TÍTULO CENTRALIZADO ELEGANTE: \"{0}\"", line1)
                    : string.Format("LINHA 1 ACIMA: \"{0}\" / LINHA 2 EM DESTAQUE ABAIXO: \"{1}\"", line1, line2);

                return sampleRefNote + string.Format(
                    "PADRONIZAÇÃO OBRIGATÓRIA DA ESCRITA NO TOPO ({0}): Bloco centralizado refinado de pôster de filme emocionante de reflexão. " +
                    "Use letras maiúsculas 3D cinematográficas elegantes em dourado champanhe reluzente (#FDE68A) e branco luminoso (#FFFFFF) com brilho quente suave e sombra projetada limpa (refined cinematic emotional drama film poster lettering in luminous white and warm champagne gold, clean beveled edges, PROIBIDO estética de terror ou horror).",
                    linesLayout);
            }

            string defaultLines = string.IsNullOrEmpty(line2)
                ? string.Format("\"{0}\"", line1)
                : string.Format("LINHA 1: \"{0}\" / LINHA 2 GIGANTE: \"{1}\"", line1, line2);

            string antiHorrorNote = effectiveGenre == GenreType.Terror
                ? ""
                : " (PROIBIDO estética de terror, letras rasgadas, sangue ou lava)";

            return sampleRefNote + string.Format(
                "PADRONIZAÇÃO OBRIGATÓRIA DA ESCRITA NO TOPO ({0}): Use {1}, ocupando com grande impacto visual o terço superior da arte, mantendo exatamente o mesmo estilo tipográfico sem usar fontes lisas genéricas{2}.",
                defaultLines,
                model != null && !string.IsNullOrEmpty(model.TypographyStyle)
                    ? model.TypographyStyle
                    : "letras 3D cinematográficas grandes de alto contraste",
                antiHorrorNote);
        }

        public static CoverReferenceModelSpec AnalyzeReferenceCoverImage(string imagePath, int modelIndex, GenreType genre)
        {
            CoverReferenceModelSpec spec = new CoverReferenceModelSpec();
            spec.ModelIndex = modelIndex;
            spec.SourceImagePath = imagePath ?? "";
            spec.SourceFileName = !string.IsNullOrEmpty(imagePath) ? Path.GetFileName(imagePath) : ("Modelo_" + modelIndex);
            spec.StyleGenre = GenreToStyleKey(genre);

            if (string.IsNullOrEmpty(imagePath) || !File.Exists(imagePath))
            {
                ApplyFallbackModelByIndex(spec, modelIndex, genre);
                return spec;
            }

            try
            {
                byte[] bytes = File.ReadAllBytes(imagePath);
                using (MemoryStream ms = new MemoryStream(bytes))
                using (Bitmap bmp = new Bitmap(ms))
                {
                    int w = bmp.Width;
                    int h = bmp.Height;
                    int stepX = Math.Max(2, w / 140);
                    int stepY = Math.Max(2, h / 250);

                    int topYellow = 0;
                    int topRed = 0;
                    int topOrange = 0;
                    int topWhiteGold = 0;
                    int topPurpleBlue = 0;
                    int upperBandYellow = 0;
                    int lowerBandYellow = 0;
                    int lowerBandRed = 0;
                    int volcanicCrust = 0;
                    int skyDark = 0;
                    int skyBright = 0;
                    int midGlow = 0;
                    int midGreenCyan = 0;
                    int midPurpleBlue = 0;
                    int midRedAura = 0;
                    int botWarm = 0;

                    for (int y = 0; y < h; y += stepY)
                    {
                        double yf = (double)y / Math.Max(1, h);
                        for (int x = 0; x < w; x += stepX)
                        {
                            double xf = (double)x / Math.Max(1, w);
                            Color c = bmp.GetPixel(x, y);
                            int r = c.R;
                            int g = c.G;
                            int b = c.B;

                            if (yf >= 0.02 && yf <= 0.30)
                            {
                                if (r > 190 && g > 150 && b < 95)
                                {
                                    topYellow++;
                                    if (yf < 0.14) upperBandYellow++;
                                    else lowerBandYellow++;
                                }
                                else if (r > 170 && g < 75 && b < 75)
                                {
                                    topRed++;
                                    if (yf >= 0.14) lowerBandRed++;
                                }
                                else if (r > 175 && g >= 75 && g <= 150 && b < 75) topOrange++;
                                else if (r > 215 && g > 210 && b > 195) topWhiteGold++;
                                else if (b > 155 && (r > 110 || g > 125)) topPurpleBlue++;

                                if (r >= 85 && r <= 165 && g >= 30 && g <= 85 && b < 45)
                                    volcanicCrust++;
                            }

                            if (yf >= 0.25 && yf <= 0.55)
                            {
                                if (r < 65 && g < 72 && b < 90) skyDark++;
                                else if (r > 135 && g > 135 && b > 135) skyBright++;
                            }

                            if (yf >= 0.45 && yf <= 0.85 && xf >= 0.22 && xf <= 0.78)
                            {
                                if (g > 160 && r > 120) midGlow++;
                                if (g > 130 && g > (r + 25)) midGreenCyan++;
                                if (b > 145 && (r > 95 || b > g + 25)) midPurpleBlue++;
                            }

                            if (yf >= 0.30 && yf <= 0.80 && xf >= 0.44 && r > 170 && g < 60 && b < 60)
                            {
                                midRedAura++;
                            }

                            if (yf >= 0.78 && yf <= 0.96 && r > 200 && g > 135 && b < 115)
                            {
                                botWarm++;
                            }
                        }
                    }

                    // ==================== 1. ESTILO TERROR ====================
                    if (genre == GenreType.Terror)
                    {
                        bool isTwoTierYellowThenPureRed = (upperBandYellow > 120 && lowerBandRed > 220 && lowerBandYellow < (upperBandYellow / 6));

                        if (isTwoTierYellowThenPureRed || midGlow >= 180 || midGreenCyan >= 55)
                        {
                            spec.ArchetypeKey = "MysticObjectTemptation";
                            spec.StyleBadge = "Terror • Tipografia Dupla (Amarelo + Vermelho Rasgado) + Objeto Brilhante";
                            spec.TypographyStyle = "duas linhas inclinadas na diagonal: 1ª linha menor em amarelo-ouro trincado acima da 2ª linha gigante em vermelho-sangue rasgado com farpas pontiagudas na base das letras";
                            spec.CompositionAndLightingStyle =
                                "composição diagonal cinematográfica de alto contraste cercada por névoa e fagulhas luminosas: no alto à direita, o protagonista inclina-se com olhar hipnotizado e tenso estendendo a mão em direção a um elemento simbólico/místico central irradiando feixes intensos de luz quente dourada entre os dois personagens, enquanto embaixo à esquerda a figura antagonista/sobrenatural observa com expressão fria e dominante";
                        }
                        else if (volcanicCrust > 320 || topOrange > topYellow || (skyDark >= 4200 && midRedAura < 60 && botWarm < 50))
                        {
                            spec.ArchetypeKey = "ColossalSkyShadow";
                            spec.StyleBadge = "Terror • Letras 3D Rocha & Lava em Arco + Sombra Colossal no Céu";
                            spec.TypographyStyle = "bloco arqueado simétrico de letras 3D maciças serifadas de rocha vulcânica escura rachada com veios internos incandescentes de lava amarelo-laranja";
                            spec.CompositionAndLightingStyle =
                                "estrutura clássica de pôster épico sombrio: na metade inferior central, o protagonista caminha ou posiciona-se de frente no caminho enevoado com iluminação quente lateral de lampião e expressão assombrada; atrás dele, agigantada nas nuvens escuras carregadas e fumaça, ergue-se a silhueta colossal e ameaçadora do antagonista/entidade dominando todo o céu";
                        }
                        else if (midRedAura >= 70 || botWarm >= 55 || (upperBandYellow > 100 && lowerBandYellow > 80 && topRed > 120))
                        {
                            spec.ArchetypeKey = "CandleFaceToFace";
                            spec.StyleBadge = "Terror • Letras Pinceladas Degradê Fogo + Frente a Frente com Velas";
                            spec.TypographyStyle = "duas linhas grandes inclinadas na diagonal em caligrafia selvagem de pincel seco com cerdas aparentes e degradê vertical amarelo-ouro para vermelho-vivo dentro de cada letra";
                            spec.CompositionAndLightingStyle =
                                "enquadramento vertical imponente frente a frente: velas acesas no chão iluminam de baixo para cima os dois personagens encarando-se em tensão máxima — o protagonista à esquerda em postura firme e a figura antagonista/entidade à direita envolta por aura dramática incandescente e iluminação de recorte intensa";
                        }
                        else
                        {
                            spec.ArchetypeKey = "DramaticSplitPoster";
                            spec.StyleBadge = "Terror • Pôster Cinematográfico Sombrio em Alto Contraste";
                            spec.TypographyStyle = BuildDynamicTopTitleStyle(topYellow, topRed, topOrange, topWhiteGold, topPurpleBlue, genre);
                            spec.CompositionAndLightingStyle = skyBright > skyDark
                                ? "composição de pôster dramático vertical bem iluminado com profundidade de cinema: o protagonista em destaque expressivo no primeiro plano e o segundo personagem em contraponto ameaçador ao fundo lateral, iluminação intensa recortando os rostos e atmosfera de suspense"
                                : "composição de pôster cinematográfico noturno em alto contraste quente vs. frio: os personagens principais em planos dramáticos complementares com iluminação forte valorizando olhares, texturas e tensão sobrenatural";
                        }
                    }
                    // ==================== 2. ESTILO NOVELA MÍSTICA ====================
                    else if (genre == GenreType.NovelaMistica)
                    {
                        if (midGlow >= 140 || midGreenCyan >= 45 || (upperBandYellow > 90 && (topWhiteGold > 80 || topOrange > 80)))
                        {
                            spec.ArchetypeKey = "MisticaDualDestiny";
                            spec.StyleBadge = "Mística • Tipografia Bicolor Luxo + Pacto & Destino Urbano";
                            spec.TypographyStyle = "duas linhas elegantes de série mística: 1ª linha menor em branco-pérola luminoso acima da 2ª linha gigante em dourado-âmbar metálico reluzente";
                            spec.CompositionAndLightingStyle =
                                "composição diagonal sofisticada de novela mística urbana brasileira bem iluminada: o protagonista expressivo estende a mão ou encara um elemento simbólico de destino/prosperidade/trabalho espiritual irradiando luz quente dourada suave entre os dois personagens, enquanto a figura mística ou rival observa com olhar enigmático e magnético, cercados por sutis partículas luminosas douradas e violeta em ótima nitidez";
                        }
                        else if (topPurpleBlue >= 65 || midPurpleBlue >= 120 || (skyDark >= 3200 && topWhiteGold > 70))
                        {
                            spec.ArchetypeKey = "MisticaUrbanShadowSplit";
                            spec.StyleBadge = "Mística • Letras 3D Ouro & Prata + Divisão Luz e Mistério";
                            spec.TypographyStyle = "bloco centralizado monumental de letras maiúsculas 3D serifadas elegantes em ouro-envelhecido escovado e prata luminosa com chanfro refinado";
                            spec.CompositionAndLightingStyle =
                                "enquadramento vertical dividido em dois planos cinematográficos bem iluminados: o protagonista em destaque frontal no cenário urbano brasileiro (cidade iluminada, apartamento ou escritório ao entardecer/noite clara), enquanto atrás/acima surge a presença marcante e enigmática do segundo personagem banhada por luz de recorte azul-índigo e dourado místico, transmitindo segredo, reviravolta e suspense elegante";
                        }
                        else if (topYellow > 75 || topWhiteGold > 85 || topOrange > 65)
                        {
                            spec.ArchetypeKey = "MisticaGoldVioletAura";
                            spec.StyleBadge = "Mística • Tipografia Dourada 3D Luxo + Aura Mística Urbana";
                            spec.TypographyStyle = "duas linhas cinematográficas em letras 3D de ouro metálico polido com chanfro brilhante, contorno escuro elegante e leve halo dourado-violeta";
                            spec.CompositionAndLightingStyle =
                                "pôster cinematográfico de novela mística urbana em altíssima nitidez: o protagonista no primeiro plano bem iluminado com expressão intensa de ambição, choque ou decisão, contrastando com a figura mística ou rival ao fundo lateral envolta em aura suave dourada e violeta, iluminação forte e limpa valorizando rostos adultos e ambiente urbano brasileiro realista";
                        }
                        else
                        {
                            spec.ArchetypeKey = "MisticaCustomPoster";
                            spec.StyleBadge = "Mística • Pôster Urbano Cinematográfico com Aura Espiritual";
                            spec.TypographyStyle = BuildDynamicTopTitleStyle(topYellow, topRed, topOrange, topWhiteGold, topPurpleBlue, genre);
                            spec.CompositionAndLightingStyle = skyBright > skyDark
                                ? "composição vertical clara e sofisticada de novela mística urbana brasileira: protagonista em primeiro plano com expressão intrigante e o segundo personagem em contraponto dramático lateral, iluminação brilhante de cinema com sutis reflexos dourados místicos"
                                : "composição vertical noturna bem iluminada de novela mística urbana brasileira: excelente nitidez nos rostos dos dois personagens, luz quente dourada recortando o primeiro plano e atmosfera urbana azul-violeta elegante ao fundo";
                        }
                    }
                    // ==================== 3. ESTILO NOVELA / REFLEXÃO ====================
                    else
                    {
                        if ((topYellow > 85 || topOrange > 75) && (topWhiteGold > 65 || upperBandYellow > 75))
                        {
                            spec.ArchetypeKey = "NovelaFaceToFaceConflict";
                            spec.StyleBadge = "Novela/Reflexão • Tipografia Impacto Novela + Confronto Emocional";
                            spec.TypographyStyle = "duas linhas grandes e firmes em tipografia bold 3D cinematográfica de novela brasileira combinando branco-creme luminoso e laranja-âmbar quente vibrante com contorno escuro limpo";
                            spec.CompositionAndLightingStyle =
                                "enquadramento vertical de confronto dramático de novela brasileira muito bem iluminado: os dois personagens frente a frente ou em diagonal próxima em plena tensão familiar ou social (olhares marcantes, gestos expressivos de diálogo e emoção genuína), com iluminação clara de cinema, cores vibrantes e profundidade de campo nítida valorizando o cotidiano brasileiro";
                        }
                        else if (skyBright >= skyDark || topWhiteGold > 110)
                        {
                            spec.ArchetypeKey = "NovelaWarmGoldenDrama";
                            spec.StyleBadge = "Novela/Reflexão • Tipografia 3D Branca & Dourada + Drama Solar";
                            spec.TypographyStyle = "bloco limpo e ultra-legível de pôster de novela: 1ª linha em branco puro brilhante e 2ª linha gigante em amarelo-ouro solar vibrante 3D com sombra suave";
                            spec.CompositionAndLightingStyle =
                                "composição cinematográfica vertical bem iluminada de alto apelo emocional: luz natural dourada de manhã clara ou final de tarde recortando os rostos expressivos em primeiro plano; o protagonista com expressão intensa de emoção, dignidade ou superação no foco principal e o segundo personagem em contraponto dramático, ambientado no cenário brasileiro com cores vivas e excelente nitidez";
                        }
                        else if (botWarm >= 45 || midGlow >= 90)
                        {
                            spec.ArchetypeKey = "NovelaHeartfeltSpotlight";
                            spec.StyleBadge = "Novela/Reflexão • Tipografia Elegante + Retrato de Superação";
                            spec.TypographyStyle = "bloco centralizado refinado em letras maiúsculas 3D de dourado champanhe reluzente e branco luminoso com brilho quente acolhedor";
                            spec.CompositionAndLightingStyle =
                                "retrato dramático emocionante em plano médio-americano vertical: protagonista em destaque central com olhar comovente, postura humana e iluminação quente clara valorizando força e emoção real; ao fundo bem iluminado com leve desfoque cinematográfico (bokeh), o segundo personagem e o ambiente brasileiro da história criando forte curiosidade e empatia";
                        }
                        else
                        {
                            spec.ArchetypeKey = "NovelaCustomPoster";
                            spec.StyleBadge = "Novela/Reflexão • Pôster Emocional Brasileiro Bem Iluminado";
                            spec.TypographyStyle = BuildDynamicTopTitleStyle(topYellow, topRed, topOrange, topWhiteGold, topPurpleBlue, genre);
                            spec.CompositionAndLightingStyle =
                                "composição vertical cinematográfica bem iluminada de novela e reflexão brasileira: excelente nitidez, cores vibrantes e naturais, protagonista em forte destaque emocional no primeiro plano e segundo personagem em contraponto narrativo expressivo, transmitindo drama humano real e superação";
                        }
                    }
                }
            }
            catch
            {
                ApplyFallbackModelByIndex(spec, modelIndex, genre);
            }

            return spec;
        }

        private static string BuildDynamicTopTitleStyle(int topYellow, int topRed, int topOrange, int topWhiteGold, int topPurpleBlue, GenreType genre)
        {
            if (genre == GenreType.Terror)
            {
                if (topYellow > 120 && topRed > 140)
                    return "tipografia grande inclinada em pinceladas dramáticas combinando amarelo-ouro vibrante no topo e vermelho intenso na base de cada letra";
                if (topOrange > 90 || topRed > 120)
                    return "letras 3D maciças chanfradas de rocha escura rachada com veios de brasa e lava incandescente";
                if (topPurpleBlue > 90)
                    return "tipografia 3D cinematográfica brilhante com contraste luminoso frio, textura metálica e contorno escuro profundo";
                if (topWhiteGold > 120 || topYellow > 90)
                    return "letras 3D cinematográficas grandes em dourado metálico reluzente com chanfro profundo de cinema";
                return "letras 3D cinematográficas grandes de pôster sombrio com alto relevo e acabamento texturizado";
            }

            if (genre == GenreType.NovelaMistica)
            {
                if (topPurpleBlue > 70)
                    return "tipografia 3D elegante em prata luminosa e ouro metálico com leve brilho azul-violeta místico e contorno escuro refinado";
                if (topYellow > 80 || topOrange > 80)
                    return "letras maiúsculas 3D luxuosas em ouro-âmbar metálico polido com chanfro brilhante e sombra projetada elegante";
                if (topWhiteGold > 90)
                    return "tipografia 3D cinematográfica de prestígio em branco-pérola luminoso e dourado metálico com reflexo sutil";
                return "letras maiúsculas 3D cinematográficas refinadas em ouro metálico e branco reluzente para série mística urbana";
            }

            // Novela / Reflexão
            if (topRed > 110 && topWhiteGold > 70)
                return "tipografia bold 3D limpa de pôster de novela combinando branco puro luminoso e vermelho-coral quente vibrante com contorno limpo";
            if (topYellow > 80 || topOrange > 80)
                return "letras maiúsculas 3D limpas e encorpadas em branco brilhante e amarelo-ouro solar vibrante com sombra suave para leitura imediata";
            if (topWhiteGold > 90)
                return "tipografia 3D cinematográfica luminosa em branco puro e dourado champanhe elegante de filme dramático";
            return "letras maiúsculas 3D limpas, grossas e ultra-legíveis de pôster de novela brasileira com acabamento quente e vibrante";
        }

        private static void ApplyFallbackModelByIndex(CoverReferenceModelSpec spec, int modelIndex, GenreType genre)
        {
            spec.StyleGenre = GenreToStyleKey(genre);
            int slot = ((Math.Max(1, modelIndex) - 1) % 3) + 1;

            if (genre == GenreType.Terror)
            {
                if (slot == 1)
                {
                    spec.ArchetypeKey = "CandleFaceToFace";
                    spec.StyleBadge = "Terror • Letras Pinceladas Degradê Fogo + Frente a Frente com Velas";
                    spec.TypographyStyle = "duas linhas grandes inclinadas na diagonal em caligrafia selvagem de pincel seco com degradê amarelo-ouro para vermelho-vivo dentro de cada letra";
                    spec.CompositionAndLightingStyle = "enquadramento vertical frente a frente com velas acesas no chão iluminando o protagonista à esquerda e o antagonista/entidade à direita envolto por aura vermelha";
                }
                else if (slot == 2)
                {
                    spec.ArchetypeKey = "MysticObjectTemptation";
                    spec.StyleBadge = "Terror • Tipografia Dupla (Amarelo + Vermelho Rasgado) + Objeto Brilhante";
                    spec.TypographyStyle = "duas linhas inclinadas: 1ª linha menor em amarelo trincado e 2ª linha gigante em vermelho rasgado com farpas pontiagudas na base";
                    spec.CompositionAndLightingStyle = "composição diagonal tensa cercada por névoa e fagulhas, com o protagonista estendendo a mão para o elemento central iluminado diante do antagonista";
                }
                else
                {
                    spec.ArchetypeKey = "ColossalSkyShadow";
                    spec.StyleBadge = "Terror • Letras 3D Rocha & Lava em Arco + Sombra Colossal no Céu";
                    spec.TypographyStyle = "bloco arqueado de letras 3D maciças de rocha vulcânica escura rachada com lava incandescente interna";
                    spec.CompositionAndLightingStyle = "protagonista em primeiro plano central no cenário enevoado sob luz quente de lampião, com a figura colossal do antagonista/entidade erguendo-se imponente nas nuvens escuras atrás dele";
                }
                return;
            }

            if (genre == GenreType.NovelaMistica)
            {
                if (slot == 1)
                {
                    spec.ArchetypeKey = "MisticaGoldVioletAura";
                    spec.StyleBadge = "Mística • Tipografia Dourada 3D Luxo + Aura Mística Urbana";
                    spec.TypographyStyle = "duas linhas cinematográficas em letras 3D de ouro metálico polido com chanfro brilhante e halo sutil dourado-violeta";
                    spec.CompositionAndLightingStyle = "pôster cinematográfico de novela mística urbana em altíssima nitidez: protagonista em primeiro plano bem iluminado com expressão intensa, contrastando com a figura mística ou rival ao fundo lateral envolta em suave aura dourada e violeta";
                }
                else if (slot == 2)
                {
                    spec.ArchetypeKey = "MisticaDualDestiny";
                    spec.StyleBadge = "Mística • Tipografia Bicolor Luxo + Pacto & Destino Urbano";
                    spec.TypographyStyle = "duas linhas elegantes: 1ª linha em branco-pérola luminoso e 2ª linha gigante em dourado-âmbar metálico reluzente";
                    spec.CompositionAndLightingStyle = "composição diagonal sofisticada bem iluminada de novela mística urbana: protagonista estendendo a mão ou encarando um símbolo de destino/prosperidade/trabalho espiritual irradiando luz quente dourada suave diante do segundo personagem";
                }
                else
                {
                    spec.ArchetypeKey = "MisticaUrbanShadowSplit";
                    spec.StyleBadge = "Mística • Letras 3D Ouro & Prata + Divisão Luz e Mistério";
                    spec.TypographyStyle = "bloco centralizado monumental de letras maiúsculas 3D serifadas elegantes em ouro-envelhecido escovado e prata luminosa";
                    spec.CompositionAndLightingStyle = "enquadramento vertical dividido bem iluminado: protagonista em destaque frontal no cenário urbano brasileiro, com a presença marcante e enigmática do segundo personagem atrás/acima sob luz de recorte azul-índigo e dourado místico";
                }
                return;
            }

            // Novela / Reflexão
            if (slot == 1)
            {
                spec.ArchetypeKey = "NovelaWarmGoldenDrama";
                spec.StyleBadge = "Novela/Reflexão • Tipografia 3D Branca & Dourada + Drama Solar";
                spec.TypographyStyle = "bloco limpo e ultra-legível de pôster de novela: 1ª linha em branco puro brilhante e 2ª linha gigante em amarelo-ouro solar vibrante 3D";
                spec.CompositionAndLightingStyle = "composição cinematográfica vertical bem iluminada sob luz natural dourada: protagonista em primeiro plano com forte expressão de emoção ou superação e o segundo personagem em contraponto dramático no cenário cotidiano brasileiro";
            }
            else if (slot == 2)
            {
                spec.ArchetypeKey = "NovelaFaceToFaceConflict";
                spec.StyleBadge = "Novela/Reflexão • Tipografia Impacto Novela + Confronto Emocional";
                spec.TypographyStyle = "duas linhas grandes e firmes em tipografia bold 3D de novela brasileira combinando branco-creme luminoso e laranja-âmbar quente vibrante";
                spec.CompositionAndLightingStyle = "enquadramento vertical frente a frente muito bem iluminado com cores vivas: os dois personagens em tensão dramática familiar ou social com olhares intensos e gestos expressivos no cotidiano brasileiro";
            }
            else
            {
                spec.ArchetypeKey = "NovelaHeartfeltSpotlight";
                spec.StyleBadge = "Novela/Reflexão • Tipografia Elegante + Retrato de Superação";
                spec.TypographyStyle = "bloco centralizado refinado em letras maiúsculas 3D de dourado champanhe reluzente e branco luminoso com brilho quente acolhedor";
                spec.CompositionAndLightingStyle = "retrato dramático emocionante bem iluminado em plano médio-americano: protagonista no foco central com olhar comovente e digno, tendo o segundo personagem e o ambiente brasileiro ao fundo em suave desfoque cinematográfico";
            }
        }

        public static List<CoverGenerationItem> BuildCoverGenerationItems(
            EpisodeWorkItem ep1,
            StoryCoverConfig coverCfg)
        {
            List<CoverGenerationItem> items = new List<CoverGenerationItem>();
            if (ep1 == null || coverCfg == null || coverCfg.ReferenceModels == null || coverCfg.ReferenceModels.Count == 0)
                return items;

            GenreType effectiveGenre = ResolveEffectiveCoverGenre(ep1, coverCfg);

            string title = string.IsNullOrWhiteSpace(coverCfg.CoverTitle)
                ? ExtractDefaultCoverTitle(ep1)
                : coverCfg.CoverTitle.Trim().ToUpperInvariant();

            int optsPerModel = coverCfg.OptionsPerModel <= 0 ? 3 : Math.Min(5, coverCfg.OptionsPerModel);
            string scenarioSummary = ExtractStoryUniverseSummary(ep1, effectiveGenre);

            List<GrokAssetSpec> allChars = DiscoverAvailableEp1Characters(ep1);
            List<GrokAssetSpec> chosenSpecs = new List<GrokAssetSpec>();
            if (coverCfg.SelectedCharacterFiles != null && coverCfg.SelectedCharacterFiles.Count > 0)
            {
                foreach (string fn in coverCfg.SelectedCharacterFiles)
                {
                    GrokAssetSpec match = allChars.FirstOrDefault(c =>
                        string.Equals(c.TargetFileName, fn, StringComparison.OrdinalIgnoreCase));
                    if (match != null)
                        chosenSpecs.Add(match);
                }
            }
            if (chosenSpecs.Count == 0 && allChars.Count > 0)
            {
                List<string> autoNames = AutoSelectFocalCharacterFileNames(ep1);
                foreach (string fn in autoNames)
                {
                    GrokAssetSpec match = allChars.FirstOrDefault(c =>
                        string.Equals(c.TargetFileName, fn, StringComparison.OrdinalIgnoreCase));
                    if (match != null)
                        chosenSpecs.Add(match);
                }
            }

            List<string> charDescriptions = new List<string>();
            for (int c = 0; c < chosenSpecs.Count; c++)
            {
                string roleTag;
                if (c == 0)
                    roleTag = "Protagonista";
                else if (c == 1)
                    roleTag = effectiveGenre == GenreType.Terror
                        ? "Antagonista / Entidade Sombria"
                        : (effectiveGenre == GenreType.NovelaMistica
                            ? "Figura Mística / Rival de Contraste"
                            : "Segundo Personagem (Contraponto Emocional)");
                else
                    roleTag = "Personagem " + (c + 1);

                charDescriptions.Add(string.Format("{0}: {1}", roleTag, SummarizeCharacterForCoverPrompt(chosenSpecs[c])));
            }
            string charsJoined = charDescriptions.Count > 0
                ? string.Join(" | ", charDescriptions)
                : "personagens principais adultos da história";

            string styleOpening;
            string[] optionVariations;
            if (effectiveGenre == GenreType.Terror)
            {
                styleOpening = "Pôster cinematográfico vertical de terror/suspense em proporção 9:16, animação 3D CGI semi-realista de altíssima fidelidade e contraste dramático.";
                optionVariations = new string[]
                {
                    "VARIAÇÃO DE CENA (OPÇÃO 1 - MANTENDO 100% A MESMA TIPOGRAFIA PADRONIZADA NO TOPO): Enquadramento clássico de pôster em plano médio-americano vertical, foco intenso nas expressões dramáticas e iluminação cinematográfica de alto contraste.",
                    "VARIAÇÃO DE CENA (OPÇÃO 2 - MANTENDO 100% A MESMA TIPOGRAFIA PADRONIZADA NO TOPO): Ângulo de câmera levemente mais baixo e imponente (contra-plongée sutil), poses mais tensas em clímax dramático e profundidade atmosférica reforçada.",
                    "VARIAÇÃO DE CENA (OPÇÃO 3 - MANTENDO 100% A MESMA TIPOGRAFIA PADRONIZADA NO TOPO): Enquadramento um pouco mais próximo valorizando rostos, olhares, recortes quentes de luz/fagulhas e impacto emocional máximo."
                };
            }
            else if (effectiveGenre == GenreType.NovelaMistica)
            {
                styleOpening = "Pôster cinematográfico vertical de novela mística urbana brasileira em proporção 9:16, animação 3D CGI semi-realista de altíssima nitidez, bem iluminado mesmo em cenas noturnas, estética elegante de mistério espiritual urbano (PROIBIDO estética de terror sangrento, monstros ou sujeira macabra).";
                optionVariations = new string[]
                {
                    "VARIAÇÃO DE CENA (OPÇÃO 1 - MANTENDO 100% A MESMA TIPOGRAFIA PADRONIZADA NO TOPO): Enquadramento clássico de pôster de série mística urbana em plano médio-americano vertical, excelente nitidez facial, iluminação cinematográfica equilibrada e sutis reflexos dourados e violeta.",
                    "VARIAÇÃO DE CENA (OPÇÃO 2 - MANTENDO 100% A MESMA TIPOGRAFIA PADRONIZADA NO TOPO): Ângulo levemente contra-plongée elegante, poses de mistério e suspense dramático urbano, contraste sofisticado entre luz quente dourada e atmosfera azul-violeta bem iluminada.",
                    "VARIAÇÃO DE CENA (OPÇÃO 3 - MANTENDO 100% A MESMA TIPOGRAFIA PADRONIZADA NO TOPO): Enquadramento mais próximo valorizando olhares expressivos, tensão silenciosa de segredo/reviravolta e aura mística luminosa refinada."
                };
            }
            else
            {
                styleOpening = "Pôster cinematográfico vertical de novela dramática e reflexão brasileira em proporção 9:16, animação 3D CGI semi-realista de altíssima nitidez, cores vibrantes e excelente iluminação clara cinematográfica (PROIBIDO estética sombria de terror, sangue, fumaça macabra ou clima assustador).";
                optionVariations = new string[]
                {
                    "VARIAÇÃO DE CENA (OPÇÃO 1 - MANTENDO 100% A MESMA TIPOGRAFIA PADRONIZADA NO TOPO): Enquadramento clássico de pôster de novela/drama brasileiro em plano médio-americano vertical, excelente iluminação natural/cinematográfica clara, cores vivas e foco máximo na emoção dos rostos.",
                    "VARIAÇÃO DE CENA (OPÇÃO 2 - MANTENDO 100% A MESMA TIPOGRAFIA PADRONIZADA NO TOPO): Composição dramática dinâmica com leve profundidade de campo (bokeh suave), poses expressivas de diálogo ou confronto emocional e iluminação quente dourada valorizando o cenário brasileiro.",
                    "VARIAÇÃO DE CENA (OPÇÃO 3 - MANTENDO 100% A MESMA TIPOGRAFIA PADRONIZADA NO TOPO): Enquadramento mais próximo destacando olhares comoventes, expressão humana autêntica de superação ou conflito familiar, iluminação clara vibrante e ótima nitidez."
                };
            }

            int globalIdx = 1;
            for (int m = 0; m < coverCfg.ReferenceModels.Count; m++)
            {
                CoverReferenceModelSpec model = coverCfg.ReferenceModels[m];
                int modelNum = m + 1;
                bool hasSampleFile = !string.IsNullOrEmpty(model.SourceImagePath) && File.Exists(model.SourceImagePath);
                string strictTypeBlock = BuildStrictTypographyBlueprint(title, model, hasSampleFile, effectiveGenre);

                for (int opt = 1; opt <= optsPerModel; opt++)
                {
                    string varHint = optionVariations[(opt - 1) % optionVariations.Length];
                    string targetFile = string.Format("Capa_Modelo{0}_Opcao{1}.jpg", modelNum, opt);

                    string prompt = string.Format(
                        "{0} " +
                        "[1. MODELO EXATO DE ESCRITA]: {1} " +
                        "[2. COMPOSIÇÃO DA CENA]: Ambientado em {2}, aplicando {3}. " +
                        "[3. PERSONAGENS DA HISTÓRIA ({4})]: Use os personagens das imagens de fundo branco anexadas mantendo 100% o mesmo rosto adulto maduro, cabelos e roupas (removendo totalmente o fundo branco de estúdio). O ÚNICO texto permitido na imagem inteira é o título no topo. " +
                        "{5}",
                        styleOpening,
                        strictTypeBlock,
                        scenarioSummary,
                        model.CompositionAndLightingStyle,
                        charsJoined,
                        varHint);

                    CoverGenerationItem item = new CoverGenerationItem();
                    item.GlobalIndex = globalIdx++;
                    item.ModelIndex = modelNum;
                    item.OptionIndex = opt;
                    item.TargetFileName = targetFile;
                    item.DisplayLabel = string.Format("Modelo {0} • Opção {1}", modelNum, opt);
                    item.ReferenceSourcePath = model.SourceImagePath ?? "";
                    item.FullPrompt = prompt;
                    items.Add(item);
                }
            }

            return items;
        }

        public static string BuildUnifiedCopyableCommand(
            EpisodeWorkItem ep1,
            StoryCoverConfig coverCfg)
        {
            if (ep1 == null || coverCfg == null || coverCfg.ReferenceModels == null || coverCfg.ReferenceModels.Count == 0)
            {
                return "Selecione 1 ou mais imagens de referência do PC — ou clique em '✨ 3 Modelos do Estilo' — para montar automaticamente os comandos de capa desta história.";
            }

            GenreType effectiveGenre = ResolveEffectiveCoverGenre(ep1, coverCfg);
            string styleLabel = GetGenreDisplayLabel(effectiveGenre).ToUpperInvariant();

            string title = string.IsNullOrWhiteSpace(coverCfg.CoverTitle)
                ? ExtractDefaultCoverTitle(ep1)
                : coverCfg.CoverTitle.Trim().ToUpperInvariant();

            int optsPerModel = coverCfg.OptionsPerModel <= 0 ? 3 : Math.Min(5, coverCfg.OptionsPerModel);
            string scenarioSummary = ExtractStoryUniverseSummary(ep1, effectiveGenre);

            List<GrokAssetSpec> allChars = DiscoverAvailableEp1Characters(ep1);
            List<string> charNames = new List<string>();
            if (coverCfg.SelectedCharacterFiles != null)
            {
                foreach (string fn in coverCfg.SelectedCharacterFiles)
                {
                    GrokAssetSpec match = allChars.FirstOrDefault(c =>
                        string.Equals(c.TargetFileName, fn, StringComparison.OrdinalIgnoreCase));
                    if (match != null)
                        charNames.Add(SummarizeCharacterForCoverPrompt(match));
                    else
                        charNames.Add(fn);
                }
            }

            string moodLine;
            if (effectiveGenre == GenreType.Terror)
                moodLine = "estilo animação 3D CGI semi-realista de terror/suspense com alta nitidez e contraste dramático";
            else if (effectiveGenre == GenreType.NovelaMistica)
                moodLine = "estilo animação 3D CGI semi-realista de novela mística urbana brasileira, bem iluminado mesmo à noite, ótima nitidez e aura espiritual elegante (PROIBIDO estética de terror sangrento)";
            else
                moodLine = "estilo animação 3D CGI semi-realista de novela dramática e reflexão brasileira, excelente iluminação clara cinematográfica, cores vibrantes e forte apelo emocional (PROIBIDO estética de terror ou sombria)";

            StringBuilder sb = new StringBuilder();
            sb.AppendLine(string.Format(
                "[ESTILO DE CAPA: {0}] Gere imagens isoladas de pôster cinematográfico vertical em proporção 9:16, {1}, mantendo 100% o rosto e figurino dos personagens da história ({2}) sem fundo branco. Siga RIGOROSAMENTE o padrão exato de fonte, inclinação, relevo e cores de cada modelo abaixo para escrever \"{3}\" no topo (variando apenas ângulo e pose nas {4} opções de cada modelo):",
                styleLabel,
                moodLine,
                coverCfg.SelectedCharacterFiles != null && coverCfg.SelectedCharacterFiles.Count > 0
                    ? string.Join(" + ", coverCfg.SelectedCharacterFiles)
                    : "personagens principais de EP.1\\assets",
                title,
                optsPerModel));
            sb.AppendLine();

            if (charNames.Count > 0)
            {
                sb.AppendLine("PERSONAGENS DA HISTÓRIA:");
                for (int i = 0; i < charNames.Count; i++)
                {
                    sb.AppendLine(string.Format("- {0}", charNames[i]));
                }
                sb.AppendLine();
            }

            for (int m = 0; m < coverCfg.ReferenceModels.Count; m++)
            {
                CoverReferenceModelSpec model = coverCfg.ReferenceModels[m];
                string strictType = BuildStrictTypographyBlueprint(title, model, false, effectiveGenre);
                sb.AppendLine(string.Format(
                    "MODELO {0} ({1} - {2} opções com a MESMA tipografia padronizada):",
                    m + 1,
                    model.StyleBadge,
                    optsPerModel));
                sb.AppendLine(strictType);
                sb.AppendLine(string.Format("Cenário e Cena: {0}, com {1}.", scenarioSummary, model.CompositionAndLightingStyle));
                sb.AppendLine();
            }

            return sb.ToString().Trim();
        }

        public static StoryCoverConfig LoadOrCreateStoryCoverConfig(StoryProject story, EpisodeWorkItem currentEp)
        {
            EpisodeWorkItem ep1 = ResolveEp1Episode(story, currentEp);
            StoryCoverConfig cfg = new StoryCoverConfig();
            if (ep1 == null) return cfg;

            string rawFullTitle = ExtractRawStoryTitle(ep1);
            string shortDefaultTitle = ShortenToImpactPosterTitle(rawFullTitle);
            cfg.CoverTitle = shortDefaultTitle;
            cfg.CoverStyle = "Auto";
            cfg.OptionsPerModel = 3;
            cfg.SelectedCharacterFiles = AutoSelectFocalCharacterFileNames(ep1);

            string cfgPath = GetStoryCoversConfigPath(ep1);
            if (!string.IsNullOrEmpty(cfgPath) && File.Exists(cfgPath))
            {
                try
                {
                    string json = File.ReadAllText(cfgPath, Encoding.UTF8);
                    JavaScriptSerializer ser = new JavaScriptSerializer();
                    Dictionary<string, object> d = ser.Deserialize<Dictionary<string, object>>(json);
                    if (d != null)
                    {
                        if (d.ContainsKey("CoverStyle"))
                        {
                            string cs = Convert.ToString(d["CoverStyle"] ?? "").Trim();
                            if (!string.IsNullOrEmpty(cs))
                                cfg.CoverStyle = cs;
                        }
                        if (d.ContainsKey("CoverTitle"))
                        {
                            string ct = Convert.ToString(d["CoverTitle"] ?? "").Trim();
                            if (!string.IsNullOrEmpty(ct))
                            {
                                // Se estava salvo o título bruto longo completo (> 23 chars) da versão anterior, encurta automaticamente para padrão pôster!
                                if (ct.Length > 23 && string.Equals(ct, rawFullTitle, StringComparison.OrdinalIgnoreCase))
                                    cfg.CoverTitle = shortDefaultTitle;
                                else
                                    cfg.CoverTitle = ct;
                            }
                        }
                        if (d.ContainsKey("OptionsPerModel"))
                        {
                            int opm;
                            if (int.TryParse(Convert.ToString(d["OptionsPerModel"] ?? "3"), out opm) && opm >= 1 && opm <= 5)
                                cfg.OptionsPerModel = opm;
                        }
                        if (d.ContainsKey("SelectedCharacterFiles") && d["SelectedCharacterFiles"] is IEnumerable)
                        {
                            List<string> loadedChars = new List<string>();
                            foreach (object o in (IEnumerable)d["SelectedCharacterFiles"])
                            {
                                string s = Convert.ToString(o ?? "").Trim();
                                if (!string.IsNullOrEmpty(s)) loadedChars.Add(s);
                            }
                            if (loadedChars.Count > 0)
                                cfg.SelectedCharacterFiles = loadedChars;
                        }
                        if (d.ContainsKey("ReferenceModels") && d["ReferenceModels"] is IEnumerable)
                        {
                            GenreType effectiveGenre = ResolveEffectiveCoverGenre(ep1, cfg);
                            string expectedStyleKey = GenreToStyleKey(effectiveGenre);
                            List<CoverReferenceModelSpec> models = new List<CoverReferenceModelSpec>();
                            int idx = 1;
                            foreach (object o in (IEnumerable)d["ReferenceModels"])
                            {
                                Dictionary<string, object> md = o as Dictionary<string, object>;
                                if (md == null) continue;
                                string srcImg = md.ContainsKey("SourceImagePath") ? Convert.ToString(md["SourceImagePath"] ?? "") : "";
                                // Reanalisa sempre se o arquivo existir para garantir o estilo do gênero + assinatura tipográfica mais precisa!
                                CoverReferenceModelSpec ms;
                                if (!string.IsNullOrEmpty(srcImg) && File.Exists(srcImg))
                                {
                                    ms = AnalyzeReferenceCoverImage(srcImg, idx++, effectiveGenre);
                                }
                                else
                                {
                                    ms = new CoverReferenceModelSpec();
                                    ms.ModelIndex = idx++;
                                    ms.SourceImagePath = srcImg;
                                    ms.SourceFileName = md.ContainsKey("SourceFileName") ? Convert.ToString(md["SourceFileName"] ?? "") : Path.GetFileName(srcImg);
                                    ms.StyleGenre = md.ContainsKey("StyleGenre") ? Convert.ToString(md["StyleGenre"] ?? "") : "";
                                    ms.ArchetypeKey = md.ContainsKey("ArchetypeKey") ? Convert.ToString(md["ArchetypeKey"] ?? "") : "";
                                    ms.StyleBadge = md.ContainsKey("StyleBadge") ? Convert.ToString(md["StyleBadge"] ?? "") : "";
                                    ms.TypographyStyle = md.ContainsKey("TypographyStyle") ? Convert.ToString(md["TypographyStyle"] ?? "") : "";
                                    ms.CompositionAndLightingStyle = md.ContainsKey("CompositionAndLightingStyle") ? Convert.ToString(md["CompositionAndLightingStyle"] ?? "") : "";

                                    if (!string.Equals(ms.StyleGenre, expectedStyleKey, StringComparison.OrdinalIgnoreCase) ||
                                        string.IsNullOrWhiteSpace(ms.ArchetypeKey))
                                    {
                                        if (string.IsNullOrWhiteSpace(ms.SourceFileName))
                                            ms.SourceFileName = string.Format("Modelo_Padrao_{0}_{1}", expectedStyleKey, ms.ModelIndex);
                                        ApplyFallbackModelByIndex(ms, ms.ModelIndex, effectiveGenre);
                                    }
                                }
                                models.Add(ms);
                            }
                            cfg.ReferenceModels = models;
                        }
                    }
                }
                catch { }
            }

            return cfg;
        }

        public static void SaveStoryCoverConfigAndPrompts(EpisodeWorkItem ep1, StoryCoverConfig cfg)
        {
            if (ep1 == null || cfg == null) return;
            string dir = GetStoryCoversDir(ep1);
            if (string.IsNullOrEmpty(dir)) return;

            try
            {
                Directory.CreateDirectory(dir);
                UTF8Encoding utf8NoBom = new UTF8Encoding(false);

                Dictionary<string, object> root = new Dictionary<string, object>();
                root["CoverTitle"] = cfg.CoverTitle ?? "";
                root["CoverStyle"] = string.IsNullOrWhiteSpace(cfg.CoverStyle) ? "Auto" : cfg.CoverStyle;
                root["OptionsPerModel"] = cfg.OptionsPerModel <= 0 ? 3 : cfg.OptionsPerModel;
                root["SelectedCharacterFiles"] = cfg.SelectedCharacterFiles ?? new List<string>();

                List<Dictionary<string, object>> modelsArr = new List<Dictionary<string, object>>();
                if (cfg.ReferenceModels != null)
                {
                    for (int i = 0; i < cfg.ReferenceModels.Count; i++)
                    {
                        CoverReferenceModelSpec m = cfg.ReferenceModels[i];
                        m.ModelIndex = i + 1;
                        Dictionary<string, object> md = new Dictionary<string, object>();
                        md["ModelIndex"] = m.ModelIndex;
                        md["SourceImagePath"] = m.SourceImagePath ?? "";
                        md["SourceFileName"] = m.SourceFileName ?? "";
                        md["StyleGenre"] = m.StyleGenre ?? "";
                        md["ArchetypeKey"] = m.ArchetypeKey ?? "";
                        md["StyleBadge"] = m.StyleBadge ?? "";
                        md["TypographyStyle"] = m.TypographyStyle ?? "";
                        md["CompositionAndLightingStyle"] = m.CompositionAndLightingStyle ?? "";
                        modelsArr.Add(md);
                    }
                }
                root["ReferenceModels"] = modelsArr;

                JavaScriptSerializer ser = new JavaScriptSerializer();
                File.WriteAllText(GetStoryCoversConfigPath(ep1), ser.Serialize(root), utf8NoBom);

                StringBuilder txt = new StringBuilder();
                txt.AppendLine("=== COMANDO UNIFICADO (COPIAR E COLAR) ===");
                txt.AppendLine();
                txt.AppendLine(BuildUnifiedCopyableCommand(ep1, cfg));
                txt.AppendLine();
                txt.AppendLine("=== PROMPTS INDIVIDUAIS POR OPÇÃO (9:16) ===");
                txt.AppendLine();

                List<CoverGenerationItem> items = BuildCoverGenerationItems(ep1, cfg);
                foreach (CoverGenerationItem item in items)
                {
                    txt.AppendLine(string.Format("[{0}] ({1})", item.DisplayLabel, item.TargetFileName));
                    txt.AppendLine(item.FullPrompt);
                    txt.AppendLine();
                }

                File.WriteAllText(GetStoryCoversPromptsTxtPath(ep1), txt.ToString(), utf8NoBom);
            }
            catch { }
        }

        public static int CountExistingGeneratedCovers(EpisodeWorkItem ep1, StoryCoverConfig cfg, out int totalExpected)
        {
            List<CoverGenerationItem> items = BuildCoverGenerationItems(ep1, cfg);
            totalExpected = items.Count;
            if (totalExpected == 0) return 0;

            string dir = GetStoryCoversDir(ep1);
            if (string.IsNullOrEmpty(dir) || !Directory.Exists(dir)) return 0;

            int existing = 0;
            foreach (CoverGenerationItem item in items)
            {
                string p = Path.Combine(dir, item.TargetFileName);
                if (File.Exists(p) && new FileInfo(p).Length >= 10 * 1024)
                    existing++;
            }
            return existing;
        }
    }
}
