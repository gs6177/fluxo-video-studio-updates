using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Microsoft.Win32;

namespace FluxoVideoStudio
{
    public partial class MainWindow : Window
    {
        private readonly PipelineConfig _config;
        private readonly CdpController _cdp;
        private readonly GrokAutomation _grok;
        private readonly FlowAutomation _flow;
        private readonly ElevenLabsAutomation _eleven;
        private readonly CapCutWebVoiceAutomation _capcutVoice;
        private readonly CapCutAutomation _capcut;

        private List<StoryProject> _allStories = new List<StoryProject>();
        private StoryProject _selectedStory;
        private EpisodeWorkItem _selectedEpisode;

        private CancellationTokenSource _runCts;
        private TaskCompletionSource<bool> _reviewContinueTcs;
        private bool _isRunning;

        // UI Controls
        private ComboBox _cmbGenreFilter;
        private TextBox _txtSearch;
        private ListBox _lstStories;
        private StackPanel _pnlEpisodeButtons;
        private TextBlock _lblSelectedContext;
        private TextBlock _lblCdpStatus;

        // Stage Cards
        private CheckBox _chkStageGrok;
        private CheckBox _chkStageFlow;
        private CheckBox _chkStageEleven;
        private CheckBox _chkStageCapCut;
        private TextBlock _badgeGrok;
        private TextBlock _badgeFlow;
        private TextBlock _badgeEleven;
        private TextBlock _badgeCapCut;

        // Main Action Buttons
        private Button _btnRunAllEpisodes;
        private Button _btnContinueReview;
        private Button _btnReloadResume;
        private Button _btnStop;
        private Button _btnConnectCdp;

        // Tab 1: Console
        private TextBox _txtLog;
        private ProgressBar _progressBar;
        private TextBlock _lblProgressStep;
        private TextBox _txtCapCutProjName;

        // Tab 2: Visual Asset Grid
        private WrapPanel _wrapAssets;
        private TextBlock _lblAssetsSummary;

        // Tab 3: Takes & Figurinos Manager
        private StackPanel _pnlTakesList;
        private TextBlock _lblTakesManagerSummary;
        private readonly Dictionary<int, CheckBox> _takeSelectionChecks = new Dictionary<int, CheckBox>();

        // Tab 4: Prompts & Narrator
        private TextBox _txtGrokPrompt;
        private TextBox _txtFlowPrompt;
        private TextBox _txtNarratorPrompt;
        private ComboBox _cmbElevenVoiceQuick;
        private ComboBox _cmbEpisodeCategoryQuick;
        private ComboBox _cmbEpisodeCapCutVoiceQuick;
        private StackPanel _pnlCapCutQuickControls;
        private StackPanel _pnlElevenQuickControls;
        private TextBlock _lblStageVoiceTitle;

        // Tab 5: Settings
        private CheckBox _chkPreserveAssets;
        private CheckBox _chkArchiveOldTakes;
        private CheckBox _chkPauseAfterGrok;
        private CheckBox _chkReuseHook;
        private CheckBox _chkLaunchCapCut;
        private TextBox _txtGrokProfiles;
        private WrapPanel _wrapGrokProfileBadges;
        private TextBox _txtNewGrokProfile;
        private TextBox _txtFlowProfile;
        private TextBox _txtFlowUrl;
        private TextBox _txtFlowDelayMin;
        private TextBox _txtFlowDelayMax;
        private TextBlock _lblFlowDelayActiveBadge;
        private RadioButton _rbVoiceEngineCapCut;
        private RadioButton _rbVoiceEngineEleven;
        private ComboBox _cmbCapCutVoiceNovela;
        private ComboBox _cmbCapCutVoiceMistica;
        private ComboBox _cmbCapCutVoiceTerror;
        private TextBox _txtCapCutWebProfiles;
        private TextBox _txtElevenProfiles;
        private TextBox _txtElevenUrl;
        private ComboBox _cmbElevenVoiceSettings;
        private TextBox _txtNovelaRootDir;
        private TextBox _txtTerrorRootDir;

        // Theme Brushes
        private static readonly Brush BgMain = BrushFromHex("#0D1017");
        private static readonly Brush BgPanel = BrushFromHex("#151923");
        private static readonly Brush BgCard = BrushFromHex("#1C2230");
        private static readonly Brush BgInput = BrushFromHex("#10141D");
        private static readonly Brush BorderSubtle = BrushFromHex("#2A3245");
        private static readonly Brush TextPrimary = BrushFromHex("#F3F4F6");
        private static readonly Brush TextSecondary = BrushFromHex("#9CA3AF");
        private static readonly Brush AccentPrimary = BrushFromHex("#6366F1");
        private static readonly Brush AccentGreen = BrushFromHex("#10B981");
        private static readonly Brush AccentAmber = BrushFromHex("#F59E0B");
        private static readonly Brush AccentRed = BrushFromHex("#EF4444");
        private static readonly Brush AccentBlue = BrushFromHex("#3B82F6");

        private readonly string _startupEpisodePath;
        private readonly bool _startupAutoRun;

        public MainWindow(string startupEpisodePath, bool startupAutoRun)
        {
            _startupEpisodePath = startupEpisodePath;
            _startupAutoRun = startupAutoRun;

            _config = new PipelineConfig();
            _config.OnProfileStatusChanged = (prof, st) =>
            {
                Dispatcher.BeginInvoke(new Action(() => RefreshGrokProfileBadges()));
            };
            _cdp = new CdpController(_config, AppendLog);
            _grok = new GrokAutomation(_cdp, _config, AppendLog);
            _flow = new FlowAutomation(_cdp, _config, _grok, AppendLog);
            _eleven = new ElevenLabsAutomation(_cdp, _config, AppendLog);
            _capcutVoice = new CapCutWebVoiceAutomation(_cdp, _config, AppendLog);
            _capcut = new CapCutAutomation(_config, AppendLog);

            Title = "Fluxo Vídeo IA Studio — Executor Nativo PC (Grok ➔ Google Flow ➔ Voz CapCut/ElevenLabs ➔ CapCut)";
            Width = 1420;
            Height = 880;
            MinWidth = 1120;
            MinHeight = 720;
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
            Background = BgMain;
            Foreground = TextPrimary;
            FontFamily = new FontFamily("Segoe UI");

            BuildLayout();

            Loaded += OnMainWindowLoaded;
            Closed += (s, e) =>
            {
                try { if (_runCts != null) _runCts.Cancel(); } catch { }
                _cdp.Dispose();
            };
        }

        private static SolidColorBrush BrushFromHex(string hex)
        {
            SolidColorBrush b = (SolidColorBrush)new BrushConverter().ConvertFromString(hex);
            b.Freeze();
            return b;
        }

        private void BuildLayout()
        {
            Grid root = new Grid();
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto }); // Header
            root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) }); // Body

            root.Children.Add(BuildTopHeader());

            Grid body = new Grid();
            Grid.SetRow(body, 1);
            body.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(350) }); // Left Explorer
            body.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) }); // Right Studio

            UIElement leftExplorer = BuildLeftExplorer();
            Grid.SetColumn(leftExplorer, 0);
            body.Children.Add(leftExplorer);

            UIElement rightWorkspace = BuildRightWorkspace();
            Grid.SetColumn(rightWorkspace, 1);
            body.Children.Add(rightWorkspace);

            root.Children.Add(body);
            Content = root;
        }

        private UIElement BuildTopHeader()
        {
            Border header = new Border
            {
                Background = BgPanel,
                BorderBrush = BorderSubtle,
                BorderThickness = new Thickness(0, 0, 0, 1),
                Padding = new Thickness(16, 8, 16, 8)
            };

            Grid g = new Grid();
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            StackPanel row1 = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };
            row1.Children.Add(new TextBlock
            {
                Text = "🎬 FLUXO VÍDEO IA STUDIO",
                FontSize = 16,
                FontWeight = FontWeights.Bold,
                Foreground = TextPrimary,
                VerticalAlignment = VerticalAlignment.Center
            });
            g.Children.Add(row1);

            StackPanel rightControls = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };

            _lblCdpStatus = new TextBlock
            {
                Text = "● Chrome: Desconectado",
                Foreground = AccentAmber,
                FontSize = 12,
                FontWeight = FontWeights.SemiBold,
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(0, 0, 12, 0)
            };
            rightControls.Children.Add(_lblCdpStatus);

            if (PipelineConfig.IsMasterDeveloperPc())
            {
                Button btnRemoteUpdate = CreateStyledButton("🔄 Publicar Atualização", BrushFromHex("#0284C7"), Brushes.White, new Thickness(11, 6, 11, 6));
                btnRemoteUpdate.FontWeight = FontWeights.Bold;
                btnRemoteUpdate.Margin = new Thickness(0, 0, 8, 0);
                btnRemoteUpdate.ToolTip = "Exclusivo deste PC Principal: Publicar atualização para os outros PCs via GitHub";
                btnRemoteUpdate.Click += (s, e) => ShowRemoteUpdateDialog();
                rightControls.Children.Add(btnRemoteUpdate);
            }

            _btnConnectCdp = CreateStyledButton("🔗 Conectar Chrome", BgCard, TextPrimary, new Thickness(11, 6, 11, 6));
            _btnConnectCdp.Click += async (s, e) => await TestChromeCdpConnectionAsync();
            rightControls.Children.Add(_btnConnectCdp);

            Grid.SetColumn(rightControls, 1);
            g.Children.Add(rightControls);

            header.Child = g;
            return header;
        }

        private UIElement BuildLeftExplorer()
        {
            Border panel = new Border
            {
                Background = BgPanel,
                BorderBrush = BorderSubtle,
                BorderThickness = new Thickness(0, 0, 1, 0),
                Padding = new Thickness(14)
            };

            Grid g = new Grid();
            g.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto }); // Title + Refresh
            g.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto }); // Genre filter
            g.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto }); // Search
            g.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) }); // Stories list
            g.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto }); // Episode selector

            // Row 0
            Grid topBar = new Grid { Margin = new Thickness(0, 0, 0, 8) };
            topBar.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            topBar.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            topBar.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            topBar.Children.Add(new TextBlock
            {
                Text = "HISTÓRIAS DO ANTIGRAVITY",
                FontSize = 12,
                FontWeight = FontWeights.Bold,
                Foreground = TextSecondary,
                VerticalAlignment = VerticalAlignment.Center
            });

            Button btnBrowse = CreateStyledButton("📂 Pasta...", BgCard, TextPrimary, new Thickness(8, 4, 8, 4));
            btnBrowse.Margin = new Thickness(0, 0, 6, 0);
            btnBrowse.Click += OnBrowseCustomEpisodeFolder;
            Grid.SetColumn(btnBrowse, 1);
            topBar.Children.Add(btnBrowse);

            Button btnRefresh = CreateStyledButton("🔄", BgCard, TextPrimary, new Thickness(8, 4, 8, 4));
            btnRefresh.ToolTip = "Recarregar pastas de Novela e Terror";
            btnRefresh.Click += (s, e) => RefreshStoriesList();
            Grid.SetColumn(btnRefresh, 2);
            topBar.Children.Add(btnRefresh);

            g.Children.Add(topBar);

            // Row 1: Genre Filter
            _cmbGenreFilter = new ComboBox
            {
                Margin = new Thickness(0, 0, 0, 8),
                Padding = new Thickness(8, 6, 8, 6),
                FontSize = 12.5
            };
            _cmbGenreFilter.Items.Add("Todos os Gêneros (Novela + Mística + Terror)");
            _cmbGenreFilter.Items.Add("Novela / Reflexão");
            _cmbGenreFilter.Items.Add("Novela Mística");
            _cmbGenreFilter.Items.Add("Terror (_Videos terror)");
            _cmbGenreFilter.SelectedIndex = 0;
            _cmbGenreFilter.SelectionChanged += (s, e) => ApplyStoryFilter();
            Grid.SetRow(_cmbGenreFilter, 1);
            g.Children.Add(_cmbGenreFilter);

            // Row 2: Search
            _txtSearch = CreateStyledTextBox("Filtrar história pelo nome...");
            _txtSearch.Margin = new Thickness(0, 0, 0, 8);
            _txtSearch.TextChanged += (s, e) => ApplyStoryFilter();
            Grid.SetRow(_txtSearch, 2);
            g.Children.Add(_txtSearch);

            // Row 3: ListBox of Stories
            _lstStories = new ListBox
            {
                Background = BgInput,
                Foreground = TextPrimary,
                BorderBrush = BorderSubtle,
                BorderThickness = new Thickness(1),
                Padding = new Thickness(4)
            };
            _lstStories.SelectionChanged += OnStorySelectionChanged;
            Grid.SetRow(_lstStories, 3);
            g.Children.Add(_lstStories);

            // Row 4: Episodes panel (EP.1 / EP.2 / EP.3)
            Border epBox = new Border
            {
                Background = BgCard,
                BorderBrush = BorderSubtle,
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(8),
                Padding = new Thickness(10),
                Margin = new Thickness(0, 10, 0, 0)
            };
            StackPanel epStack = new StackPanel();
            epStack.Children.Add(new TextBlock
            {
                Text = "SELECIONE O EPISÓDIO (EP.1 / EP.2 / EP.3):",
                FontSize = 11.5,
                FontWeight = FontWeights.Bold,
                Foreground = TextSecondary,
                Margin = new Thickness(0, 0, 0, 6)
            });
            _pnlEpisodeButtons = new StackPanel { Orientation = Orientation.Vertical };
            epStack.Children.Add(_pnlEpisodeButtons);
            epBox.Child = epStack;
            Grid.SetRow(epBox, 4);
            g.Children.Add(epBox);

            panel.Child = g;
            return panel;
        }

        private UIElement BuildRightWorkspace()
        {
            Grid g = new Grid { Margin = new Thickness(14, 10, 14, 12) };
            g.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto }); // Barra Única: Episódio Selecionado + Botões de Ação
            g.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto }); // 4 Etapas Compactas
            g.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) }); // Abas

            // Row 0: Barra Unificada (Episódio Selecionado à esquerda + Ações principais à direita)
            Border commandBar = new Border
            {
                Background = BgPanel,
                BorderBrush = BorderSubtle,
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(8),
                Padding = new Thickness(12, 8, 12, 8),
                Margin = new Thickness(0, 0, 0, 8)
            };
            Grid cmdGrid = new Grid();
            cmdGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            cmdGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            _lblSelectedContext = new TextBlock
            {
                Text = "Selecione uma história e episódio à esquerda.",
                FontSize = 13,
                FontWeight = FontWeights.SemiBold,
                Foreground = TextPrimary,
                VerticalAlignment = VerticalAlignment.Center,
                TextTrimming = TextTrimming.CharacterEllipsis,
                Margin = new Thickness(0, 0, 12, 0)
            };
            Grid.SetColumn(_lblSelectedContext, 0);
            cmdGrid.Children.Add(_lblSelectedContext);

            StackPanel actionBtns = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };

            _btnContinueReview = CreateStyledButton("✅ Confirmar Assets", AccentAmber, Brushes.Black, new Thickness(12, 7, 12, 7));
            _btnContinueReview.FontWeight = FontWeights.Bold;
            _btnContinueReview.Visibility = Visibility.Collapsed;
            _btnContinueReview.Margin = new Thickness(0, 0, 8, 0);
            _btnContinueReview.Click += (s, e) =>
            {
                if (_reviewContinueTcs != null)
                    _reviewContinueTcs.TrySetResult(true);
            };
            actionBtns.Children.Add(_btnContinueReview);

            _btnRunAllEpisodes = CreateStyledButton("⏩ Fila (EP.1 ➔ EP.3)", BgCard, TextPrimary, new Thickness(12, 7, 12, 7));
            _btnRunAllEpisodes.FontWeight = FontWeights.SemiBold;
            _btnRunAllEpisodes.ToolTip = "Executar EP.1, EP.2 e EP.3 em sequência";
            _btnRunAllEpisodes.Margin = new Thickness(0, 0, 8, 0);
            _btnRunAllEpisodes.Click += async (s, e) => await ExecuteFullStoryQueueAsync();
            actionBtns.Children.Add(_btnRunAllEpisodes);

            _btnReloadResume = CreateStyledButton("🔄 Recarregar e Continuar", AccentBlue, Brushes.White, new Thickness(12, 7, 12, 7));
            _btnReloadResume.FontWeight = FontWeights.Bold;
            _btnReloadResume.ToolTip = "Recarrega a aba atual do Chrome (F5) e retoma o processo exatamente a partir da última ação registrada no histórico";
            _btnReloadResume.Visibility = Visibility.Collapsed;
            _btnReloadResume.Margin = new Thickness(0, 0, 8, 0);
            _btnReloadResume.Click += (s, e) =>
            {
                if (_isRunning && _cdp != null)
                {
                    LastActionCheckpoint cp = LastActionHistoryStore.Current;
                    string summary = cp != null
                        ? string.Format("{0} -> {1} ({2})", cp.StageName, cp.SubActionDescription, cp.TargetItemName ?? "em andamento")
                        : "etapa ativa";
                    AppendLog(string.Format("[Recuperação | Histórico] Botão 'Recarregar e Continuar' acionado! Recarregando página e retomando de: {0}...", summary));
                    _cdp.RequestReloadAndResume("Acionado manualmente pelo botão 'Recarregar e Continuar'");
                }
            };
            actionBtns.Children.Add(_btnReloadResume);

            _btnStop = CreateStyledButton("▶ INICIAR", AccentGreen, Brushes.White, new Thickness(18, 7, 18, 7));
            _btnStop.FontWeight = FontWeights.Bold;
            _btnStop.IsEnabled = true;
            _btnStop.Click += async (s, e) =>
            {
                if (_isRunning)
                {
                    AppendLog("[Sistema] Solicitação de parada enviada pelo usuário...");
                    if (_runCts != null)
                    {
                        try { _runCts.Cancel(); } catch { }
                    }
                    if (_cdp != null)
                    {
                        _cdp.CancelCurrentActivity();
                    }
                    if (_reviewContinueTcs != null)
                    {
                        _reviewContinueTcs.TrySetCanceled();
                    }
                }
                else
                {
                    await ExecuteSelectedStagesAsync(
                        _chkStageGrok.IsChecked == true,
                        _chkStageFlow.IsChecked == true,
                        _chkStageEleven.IsChecked == true,
                        _chkStageCapCut.IsChecked == true);
                }
            };
            actionBtns.Children.Add(_btnStop);

            Grid.SetColumn(actionBtns, 1);
            cmdGrid.Children.Add(actionBtns);
            commandBar.Child = cmdGrid;
            g.Children.Add(commandBar);

            // Row 1: 4 Stage Cards Compactos
            UniformGrid stagesGrid = new UniformGrid { Columns = 4, Margin = new Thickness(0, 0, 0, 8) };
            stagesGrid.Children.Add(BuildStageCard(
                "1. Grok Imagine",
                "",
                out _chkStageGrok,
                out _badgeGrok,
                "▶ Só Grok",
                async () => await ExecuteSelectedStagesAsync(true, false, false, false)));

            stagesGrid.Children.Add(BuildStageCard(
                "2. Google Flow",
                "",
                out _chkStageFlow,
                out _badgeFlow,
                "▶ Só Flow",
                async () => await ExecuteSelectedStagesAsync(false, true, false, false)));

            stagesGrid.Children.Add(BuildStageCard(
                _config.IsCapCutVoiceEngine() ? "3. Voz (CapCut)" : "3. Voz (ElevenLabs)",
                "",
                out _chkStageEleven,
                out _badgeEleven,
                "▶ Só Voz",
                async () => await ExecuteSelectedStagesAsync(false, false, true, false)));
            _lblStageVoiceTitle = _chkStageEleven != null ? _chkStageEleven.Content as TextBlock : null;

            stagesGrid.Children.Add(BuildStageCard(
                "4. CapCut",
                "",
                out _chkStageCapCut,
                out _badgeCapCut,
                "▶ Só CapCut",
                async () => await ExecuteSelectedStagesAsync(false, false, false, true)));

            Grid.SetRow(stagesGrid, 1);
            g.Children.Add(stagesGrid);

            // Row 2: Workspace Tabs
            TabControl tabs = new TabControl
            {
                Background = BgPanel,
                BorderBrush = BorderSubtle,
                Foreground = TextPrimary,
                Padding = new Thickness(6)
            };

            tabs.Items.Add(BuildConsoleTab());
            tabs.Items.Add(BuildAssetsVisualTab());
            tabs.Items.Add(BuildTakesAndOutfitsTab());
            tabs.Items.Add(BuildPromptsInspectorTab());
            tabs.Items.Add(BuildSettingsTab());

            Grid.SetRow(tabs, 2);
            g.Children.Add(tabs);

            return g;
        }

        private UIElement BuildStageCard(
            string title,
            string subtitle,
            out CheckBox chkOut,
            out TextBlock badgeOut,
            string quickBtnText,
            Func<Task> quickAction)
        {
            Border card = new Border
            {
                Background = BgCard,
                BorderBrush = BorderSubtle,
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(8),
                Padding = new Thickness(10, 7, 10, 7),
                Margin = new Thickness(3, 0, 3, 0)
            };

            StackPanel sp = new StackPanel();

            DockPanel topRow = new DockPanel { Margin = new Thickness(0, 0, 0, 5) };
            chkOut = new CheckBox
            {
                IsChecked = true,
                Content = new TextBlock
                {
                    Text = title,
                    FontWeight = FontWeights.Bold,
                    FontSize = 12.5,
                    Foreground = TextPrimary
                },
                VerticalAlignment = VerticalAlignment.Center
            };
            topRow.Children.Add(chkOut);
            sp.Children.Add(topRow);

            Grid bottomRow = new Grid();
            bottomRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            bottomRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            badgeOut = new TextBlock
            {
                Text = "AGUARDANDO",
                FontSize = 10.5,
                FontWeight = FontWeights.Bold,
                Foreground = TextSecondary,
                VerticalAlignment = VerticalAlignment.Center
            };
            bottomRow.Children.Add(badgeOut);

            Button btnQuick = CreateStyledButton(quickBtnText, BgPanel, TextPrimary, new Thickness(7, 2, 7, 2));
            btnQuick.FontSize = 10.5;
            btnQuick.Click += async (s, e) => await quickAction();
            Grid.SetColumn(btnQuick, 1);
            bottomRow.Children.Add(btnQuick);

            sp.Children.Add(bottomRow);
            card.Child = sp;
            return card;
        }

        private TabItem BuildConsoleTab()
        {
            TabItem tab = new TabItem { Header = "  🖥 Console  " };
            Grid g = new Grid { Margin = new Thickness(6) };
            g.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            g.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
            g.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

            // Top bar: Progress + CapCut project name
            Grid top = new Grid { Margin = new Thickness(0, 0, 0, 8) };
            top.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            top.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            StackPanel progStack = new StackPanel { Margin = new Thickness(0, 0, 14, 0) };
            _lblProgressStep = new TextBlock
            {
                Text = "Pronto para executar.",
                FontSize = 12,
                FontWeight = FontWeights.SemiBold,
                Foreground = TextPrimary,
                Margin = new Thickness(0, 0, 0, 4)
            };
            progStack.Children.Add(_lblProgressStep);

            _progressBar = new ProgressBar
            {
                Height = 8,
                Minimum = 0,
                Maximum = 100,
                Value = 0,
                Background = BgInput,
                Foreground = AccentPrimary
            };
            progStack.Children.Add(_progressBar);
            top.Children.Add(progStack);

            StackPanel capProjStack = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };
            capProjStack.Children.Add(new TextBlock
            {
                Text = "Projeto CapCut:",
                Foreground = TextSecondary,
                FontSize = 12,
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(0, 0, 6, 0)
            });
            _txtCapCutProjName = CreateStyledTextBox("");
            _txtCapCutProjName.Width = 220;
            capProjStack.Children.Add(_txtCapCutProjName);
            Grid.SetColumn(capProjStack, 1);
            top.Children.Add(capProjStack);

            g.Children.Add(top);

            // Center Log Console
            _txtLog = new TextBox
            {
                Background = BrushFromHex("#090B10"),
                Foreground = BrushFromHex("#D1FAE5"),
                BorderBrush = BorderSubtle,
                BorderThickness = new Thickness(1),
                FontFamily = new FontFamily("Consolas"),
                FontSize = 12.5,
                IsReadOnly = true,
                TextWrapping = TextWrapping.Wrap,
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                Padding = new Thickness(10)
            };
            Grid.SetRow(_txtLog, 1);
            g.Children.Add(_txtLog);

            // Bottom Quick Folder Tools
            StackPanel bottomTools = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin = new Thickness(0, 8, 0, 0)
            };

            Button btnOpenEp = CreateStyledButton("📁 Pasta Episódio", BgCard, TextPrimary, new Thickness(10, 6, 10, 6));
            btnOpenEp.Margin = new Thickness(0, 0, 8, 0);
            btnOpenEp.Click += (s, e) => OpenDirectoryInExplorer(_selectedEpisode != null ? _selectedEpisode.EpisodePath : "");
            bottomTools.Children.Add(btnOpenEp);

            Button btnOpenAssets = CreateStyledButton("🖼 Pasta Assets", BgCard, TextPrimary, new Thickness(10, 6, 10, 6));
            btnOpenAssets.Margin = new Thickness(0, 0, 8, 0);
            btnOpenAssets.Click += (s, e) => OpenDirectoryInExplorer(_selectedEpisode != null ? _selectedEpisode.AssetsDir : "");
            bottomTools.Children.Add(btnOpenAssets);

            Button btnOpenTakes = CreateStyledButton("🎬 Pasta Takes", BgCard, TextPrimary, new Thickness(10, 6, 10, 6));
            btnOpenTakes.Margin = new Thickness(0, 0, 8, 0);
            btnOpenTakes.Click += (s, e) => OpenDirectoryInExplorer(_selectedEpisode != null ? _selectedEpisode.TakesDir : "");
            bottomTools.Children.Add(btnOpenTakes);

            Button btnManualAudio = CreateStyledButton("✂ Travar Silêncio (MP3 ➔ WAV)", BgCard, TextPrimary, new Thickness(10, 6, 10, 6));
            btnManualAudio.Margin = new Thickness(0, 0, 8, 0);
            btnManualAudio.Click += OnManualSilenceProcessClick;
            bottomTools.Children.Add(btnManualAudio);

            Button btnClearLog = CreateStyledButton("🧹 Limpar", BgCard, TextSecondary, new Thickness(10, 6, 10, 6));
            btnClearLog.Click += (s, e) => _txtLog.Clear();
            bottomTools.Children.Add(btnClearLog);

            Grid.SetRow(bottomTools, 2);
            g.Children.Add(bottomTools);

            tab.Content = g;
            return tab;
        }

        private TabItem BuildAssetsVisualTab()
        {
            TabItem tab = new TabItem { Header = "  🖼 Personagens & Cenários  " };
            Grid g = new Grid { Margin = new Thickness(6) };
            g.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            g.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });

            DockPanel bar = new DockPanel { Margin = new Thickness(0, 0, 0, 8) };
            _lblAssetsSummary = new TextBlock
            {
                Text = "Personagens e Cenários do episódio:",
                FontSize = 12.5,
                Foreground = TextPrimary,
                VerticalAlignment = VerticalAlignment.Center
            };
            bar.Children.Add(_lblAssetsSummary);

            StackPanel btns = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };

            Button btnImportCast = CreateStyledButton("👥 Importar Elenco", BrushFromHex("#7C3AED"), Brushes.White, new Thickness(10, 5, 10, 5));
            btnImportCast.Margin = new Thickness(0, 0, 8, 0);
            btnImportCast.Click += OnImportCastFromAnotherStoryClick;
            btns.Children.Add(btnImportCast);

            Button btnRunOcr = CreateStyledButton("🔍 Conferir OCR", AccentBlue, Brushes.White, new Thickness(10, 5, 10, 5));
            btnRunOcr.Margin = new Thickness(0, 0, 8, 0);
            btnRunOcr.Click += async (s, e) => await InspectCurrentAssetsWithOcrAsync();
            btns.Children.Add(btnRunOcr);

            Button btnReloadGrid = CreateStyledButton("🔄 Atualizar", BgCard, TextPrimary, new Thickness(10, 5, 10, 5));
            btnReloadGrid.Click += (s, e) => RefreshAssetsGallery(null);
            btns.Children.Add(btnReloadGrid);

            DockPanel.SetDock(btns, Dock.Right);
            bar.Children.Add(btns);
            g.Children.Add(bar);

            ScrollViewer sv = new ScrollViewer
            {
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                Background = BgInput
            };
            _wrapAssets = new WrapPanel { Margin = new Thickness(8) };
            sv.Content = _wrapAssets;
            Grid.SetRow(sv, 1);
            g.Children.Add(sv);

            tab.Content = g;
            return tab;
        }

        private TabItem BuildTakesAndOutfitsTab()
        {
            TabItem tab = new TabItem { Header = "  🎬 Takes & Roupas  " };
            Grid g = new Grid { Margin = new Thickness(6) };
            g.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            g.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });

            DockPanel topBar = new DockPanel { Margin = new Thickness(0, 0, 0, 8) };
            _lblTakesManagerSummary = new TextBlock
            {
                Text = "Takes do episódio:",
                FontSize = 12.5,
                FontWeight = FontWeights.SemiBold,
                Foreground = TextPrimary,
                VerticalAlignment = VerticalAlignment.Center
            };
            topBar.Children.Add(_lblTakesManagerSummary);

            StackPanel rightBtns = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };

            Button btnToggleAll = CreateStyledButton("☑ Todos", BgCard, TextPrimary, new Thickness(10, 5, 10, 5));
            btnToggleAll.Margin = new Thickness(0, 0, 8, 0);
            btnToggleAll.Click += (s, e) =>
            {
                bool anyUnchecked = _takeSelectionChecks.Values.Any(c => c.IsChecked != true);
                foreach (CheckBox chk in _takeSelectionChecks.Values)
                    chk.IsChecked = anyUnchecked;
            };
            rightBtns.Children.Add(btnToggleAll);

            Button btnRegenSelectedFlow = CreateStyledButton("🌊 Regerar no Flow", AccentBlue, Brushes.White, new Thickness(10, 5, 10, 5));
            btnRegenSelectedFlow.FontWeight = FontWeights.Bold;
            btnRegenSelectedFlow.Margin = new Thickness(0, 0, 8, 0);
            btnRegenSelectedFlow.Click += async (s, e) => await RegenerateCheckedTakesAsync(false);
            rightBtns.Children.Add(btnRegenSelectedFlow);

            Button btnRegenSelectedGrok = CreateStyledButton("🚀 Regerar no Grok 🪄", AccentPrimary, Brushes.White, new Thickness(10, 5, 10, 5));
            btnRegenSelectedGrok.FontWeight = FontWeights.Bold;
            btnRegenSelectedGrok.Margin = new Thickness(0, 0, 8, 0);
            btnRegenSelectedGrok.Click += async (s, e) => await RegenerateCheckedTakesAsync(true);
            rightBtns.Children.Add(btnRegenSelectedGrok);

            Button btnRefreshTakes = CreateStyledButton("🔄 Atualizar", BgCard, TextPrimary, new Thickness(10, 5, 10, 5));
            btnRefreshTakes.Click += (s, e) => RefreshTakesManagerList();
            rightBtns.Children.Add(btnRefreshTakes);

            DockPanel.SetDock(rightBtns, Dock.Right);
            topBar.Children.Add(rightBtns);
            g.Children.Add(topBar);

            ScrollViewer sv = new ScrollViewer
            {
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                Background = BgInput
            };
            _pnlTakesList = new StackPanel { Margin = new Thickness(8) };
            sv.Content = _pnlTakesList;
            Grid.SetRow(sv, 1);
            g.Children.Add(sv);

            tab.Content = g;
            return tab;
        }

        private TabItem BuildPromptsInspectorTab()
        {
            TabItem tab = new TabItem { Header = "  📝 Prompts & Voz  " };
            Grid g = new Grid { Margin = new Thickness(6) };
            g.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            g.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });

            DockPanel topBar = new DockPanel { Margin = new Thickness(0, 0, 0, 8) };
            topBar.Children.Add(new TextBlock
            {
                Text = "Prompts e voz do Narrador:",
                Foreground = TextSecondary,
                FontSize = 12.5,
                VerticalAlignment = VerticalAlignment.Center
            });

            StackPanel rightControls = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };

            _pnlCapCutQuickControls = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                VerticalAlignment = VerticalAlignment.Center,
                Visibility = _config.IsCapCutVoiceEngine() ? Visibility.Visible : Visibility.Collapsed
            };
            _pnlCapCutQuickControls.Children.Add(new TextBlock
            {
                Text = "Tipo:",
                FontSize = 11.5,
                FontWeight = FontWeights.SemiBold,
                Foreground = TextSecondary,
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(0, 0, 5, 0)
            });
            _cmbEpisodeCategoryQuick = new ComboBox
            {
                Width = 148,
                FontSize = 11.5,
                Padding = new Thickness(6, 4, 6, 4),
                Margin = new Thickness(0, 0, 8, 0)
            };
            _cmbEpisodeCategoryQuick.Items.Add("Novela / Reflexão");
            _cmbEpisodeCategoryQuick.Items.Add("Novela Mística");
            _cmbEpisodeCategoryQuick.Items.Add("Terror");
            _cmbEpisodeCategoryQuick.SelectedIndex = 0;
            _cmbEpisodeCategoryQuick.SelectionChanged += OnEpisodeCategoryQuickChanged;
            _pnlCapCutQuickControls.Children.Add(_cmbEpisodeCategoryQuick);

            _pnlCapCutQuickControls.Children.Add(new TextBlock
            {
                Text = "🎙 Voz CapCut:",
                FontSize = 11.5,
                FontWeight = FontWeights.SemiBold,
                Foreground = TextPrimary,
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(0, 0, 5, 0)
            });
            _cmbEpisodeCapCutVoiceQuick = new ComboBox
            {
                Width = 195,
                IsEditable = true,
                FontSize = 11.5,
                Padding = new Thickness(6, 4, 6, 4),
                Margin = new Thickness(0, 0, 8, 0),
                ToolTip = "Escolha ou digite o nome exato da voz do CapCut para esta categoria de vídeo"
            };
            _cmbEpisodeCapCutVoiceQuick.SelectionChanged += OnQuickCapCutVoiceSelectionChanged;
            _cmbEpisodeCapCutVoiceQuick.LostFocus += OnQuickCapCutVoiceLostFocus;
            _pnlCapCutQuickControls.Children.Add(_cmbEpisodeCapCutVoiceQuick);
            rightControls.Children.Add(_pnlCapCutQuickControls);

            _pnlElevenQuickControls = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                VerticalAlignment = VerticalAlignment.Center,
                Visibility = _config.IsCapCutVoiceEngine() ? Visibility.Collapsed : Visibility.Visible
            };
            _pnlElevenQuickControls.Children.Add(new TextBlock
            {
                Text = "🎙 Voz Eleven:",
                FontSize = 12,
                FontWeight = FontWeights.SemiBold,
                Foreground = TextPrimary,
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(0, 0, 6, 0)
            });

            _cmbElevenVoiceQuick = new ComboBox
            {
                Width = 240,
                FontSize = 11.5,
                Padding = new Thickness(6, 4, 6, 4),
                Margin = new Thickness(0, 0, 6, 0)
            };
            _cmbElevenVoiceQuick.SelectionChanged += OnQuickVoiceSelectionChanged;
            _pnlElevenQuickControls.Children.Add(_cmbElevenVoiceQuick);

            Button btnAddVoiceQuick = CreateStyledButton("➕ Voz", BgCard, TextPrimary, new Thickness(8, 5, 8, 5));
            btnAddVoiceQuick.Margin = new Thickness(0, 0, 8, 0);
            btnAddVoiceQuick.Click += (s, e) => ShowAddElevenLabsVoiceDialog();
            _pnlElevenQuickControls.Children.Add(btnAddVoiceQuick);
            rightControls.Children.Add(_pnlElevenQuickControls);

            Button btnSavePrompts = CreateStyledButton("💾 Salvar Prompts", AccentGreen, Brushes.White, new Thickness(12, 6, 12, 6));
            btnSavePrompts.Click += OnSavePromptsClick;
            rightControls.Children.Add(btnSavePrompts);

            DockPanel.SetDock(rightControls, Dock.Right);
            topBar.Children.Add(rightControls);
            g.Children.Add(topBar);

            Grid cols = new Grid();
            cols.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            cols.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            cols.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(0.85, GridUnitType.Star) });

            cols.Children.Add(BuildPromptColumn("1. Grok Imagine (prompt_grok_passo1_e_2.txt)", out _txtGrokPrompt, 0));
            cols.Children.Add(BuildPromptColumn("2. Google Flow (prompt_flow_passo3.txt)", out _txtFlowPrompt, 1));
            cols.Children.Add(BuildPromptColumn("3. Texto Unificado do Narrador (CapCut / ElevenLabs)", out _txtNarratorPrompt, 2));

            Grid.SetRow(cols, 1);
            g.Children.Add(cols);
            tab.Content = g;
            return tab;
        }

        private UIElement BuildPromptColumn(string label, out TextBox boxOut, int col)
        {
            Grid g = new Grid { Margin = new Thickness(4, 0, 4, 0) };
            g.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            g.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });

            g.Children.Add(new TextBlock
            {
                Text = label,
                FontSize = 12,
                FontWeight = FontWeights.Bold,
                Foreground = TextPrimary,
                Margin = new Thickness(0, 0, 0, 4)
            });

            boxOut = new TextBox
            {
                Background = BgInput,
                Foreground = TextPrimary,
                BorderBrush = BorderSubtle,
                BorderThickness = new Thickness(1),
                FontFamily = new FontFamily("Consolas"),
                FontSize = 11.5,
                AcceptsReturn = true,
                TextWrapping = TextWrapping.Wrap,
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                Padding = new Thickness(8)
            };
            Grid.SetRow(boxOut, 1);
            g.Children.Add(boxOut);
            Grid.SetColumn(g, col);
            return g;
        }

        private TabItem BuildSettingsTab()
        {
            TabItem tab = new TabItem { Header = "  ⚙ Perfis Chrome, Contas Grok & Vozes  " };
            ScrollViewer sv = new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto };
            StackPanel sp = new StackPanel { Margin = new Thickness(12), MaxWidth = 960, HorizontalAlignment = HorizontalAlignment.Left };

            sp.Children.Add(new TextBlock
            {
                Text = "OPÇÕES DE EXECUÇÃO DA ESTEIRA",
                FontSize = 13,
                FontWeight = FontWeights.Bold,
                Foreground = TextPrimary,
                Margin = new Thickness(0, 0, 0, 8)
            });

            _chkPreserveAssets = new CheckBox
            {
                IsChecked = _config.PreserveExistingAssets,
                Content = new TextBlock { Text = "🔒 Trava de Elenco: Preservar Personagens/Assets .jpg já existentes na pasta assets\\ (gerar no Grok SOMENTE os ausentes)", Foreground = TextPrimary, FontWeight = FontWeights.SemiBold },
                Margin = new Thickness(0, 0, 0, 8)
            };
            sp.Children.Add(_chkPreserveAssets);

            _chkArchiveOldTakes = new CheckBox
            {
                IsChecked = _config.ArchiveOldTakesBeforeRemake,
                Content = new TextBlock { Text = "🧹 Modo Refazer Seguro: Mover takes/áudios antigos para takes\\_backup_<data> antes de gerar novos vídeos no Flow", Foreground = TextPrimary },
                Margin = new Thickness(0, 0, 0, 8)
            };
            sp.Children.Add(_chkArchiveOldTakes);

            _chkPauseAfterGrok = new CheckBox
            {
                IsChecked = _config.PauseAfterGrokForVisualReview,
                Content = new TextBlock { Text = "Pausar após o Grok Imagine para conferência visual manual das miniaturas antes de iniciar o Google Flow", Foreground = TextPrimary },
                Margin = new Thickness(0, 0, 0, 8)
            };
            sp.Children.Add(_chkPauseAfterGrok);

            _chkReuseHook = new CheckBox
            {
                IsChecked = _config.ReuseEp1HookTake01,
                Content = new TextBlock { Text = "Regra 22: Reaproveitar automaticamente Take_01.mp4 (Gancho de 10s) do EP.1 nas continuações EP.2 e EP.3 quando aplicável", Foreground = TextPrimary },
                Margin = new Thickness(0, 0, 0, 8)
            };
            sp.Children.Add(_chkReuseHook);

            _chkLaunchCapCut = new CheckBox
            {
                IsChecked = _config.LaunchCapCutDesktop,
                Content = new TextBlock { Text = "Abrir o CapCut Desktop automaticamente ao concluir a montagem da Timeline", Foreground = TextPrimary },
                Margin = new Thickness(0, 0, 0, 16)
            };
            sp.Children.Add(_chkLaunchCapCut);

            // PAINEL VISUAL DE CONTAS GROK (SUGESTÃO D)
            Border grokStatusBox = new Border
            {
                Background = BgCard,
                BorderBrush = BorderSubtle,
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(8),
                Padding = new Thickness(12),
                Margin = new Thickness(0, 0, 0, 14)
            };
            StackPanel grokStatusStack = new StackPanel();
            DockPanel grokHeaderRow = new DockPanel { Margin = new Thickness(0, 0, 0, 8) };
            grokHeaderRow.Children.Add(new TextBlock
            {
                Text = "STATUS DAS CONTAS / PERFIS DO GROK IMAGINE (DETECÇÃO DE LIMITE DE USO)",
                FontSize = 12.5,
                FontWeight = FontWeights.Bold,
                Foreground = TextPrimary,
                VerticalAlignment = VerticalAlignment.Center
            });

            Button btnCheckGrokQuotas = CreateStyledButton("🔍 Verificar Créditos / Limite das Contas Agora", AccentBlue, Brushes.White, new Thickness(10, 5, 10, 5));
            btnCheckGrokQuotas.HorizontalAlignment = HorizontalAlignment.Right;
            btnCheckGrokQuotas.Click += async (s, e) => await CheckGrokAccountsStatusFromUiAsync();
            DockPanel.SetDock(btnCheckGrokQuotas, Dock.Right);
            grokHeaderRow.Children.Add(btnCheckGrokQuotas);
            grokStatusStack.Children.Add(grokHeaderRow);

            _wrapGrokProfileBadges = new WrapPanel { Margin = new Thickness(0, 0, 0, 8) };
            grokStatusStack.Children.Add(_wrapGrokProfileBadges);

            StackPanel addProfileRow = new StackPanel { Orientation = Orientation.Horizontal };
            addProfileRow.Children.Add(new TextBlock
            {
                Text = "Adicionar Novo Perfil Chrome (ex: Profile 68):",
                FontSize = 12,
                Foreground = TextSecondary,
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(0, 0, 8, 0)
            });
            _txtNewGrokProfile = CreateStyledTextBox("Ex: Profile 68");
            _txtNewGrokProfile.Width = 170;
            _txtNewGrokProfile.Margin = new Thickness(0, 0, 8, 0);
            addProfileRow.Children.Add(_txtNewGrokProfile);

            Button btnAddProfile = CreateStyledButton("➕ Adicionar Perfil Grok", AccentPrimary, Brushes.White, new Thickness(10, 5, 10, 5));
            btnAddProfile.Click += OnAddGrokProfileClick;
            addProfileRow.Children.Add(btnAddProfile);

            grokStatusStack.Children.Add(addProfileRow);
            grokStatusBox.Child = grokStatusStack;
            sp.Children.Add(grokStatusBox);

            // MOTOR DE LOCUÇÃO + VOZES DO CAPCUT POR TIPO DE VÍDEO (3 CATEGORIAS)
            Border capcutVoiceBox = new Border
            {
                Background = BgCard,
                BorderBrush = AccentGreen,
                BorderThickness = new Thickness(1.5),
                CornerRadius = new CornerRadius(8),
                Padding = new Thickness(14),
                Margin = new Thickness(0, 0, 0, 14)
            };
            StackPanel ccVoiceStack = new StackPanel();
            ccVoiceStack.Children.Add(new TextBlock
            {
                Text = "🎙 MOTOR DE LOCUÇÃO E VOZES DO CAPCUT POR TIPO DE VÍDEO (ETAPA 3)",
                FontSize = 13,
                FontWeight = FontWeights.Bold,
                Foreground = TextPrimary,
                Margin = new Thickness(0, 0, 0, 6)
            });
            ccVoiceStack.Children.Add(new TextBlock
            {
                Text = "Escolha abaixo qual voz do CapCut usar automaticamente em cada categoria (Novela / Reflexão, Novela Mística e Terror). Você pode escolher na lista ou digitar exatamente o nome da voz como aparece no CapCut.",
                FontSize = 11.5,
                Foreground = TextSecondary,
                TextWrapping = TextWrapping.Wrap,
                Margin = new Thickness(0, 0, 0, 10)
            });

            WrapPanel engineRow = new WrapPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 0, 0, 12) };
            engineRow.Children.Add(new TextBlock
            {
                Text = "Motor de Voz Ativo:",
                FontSize = 12,
                FontWeight = FontWeights.Bold,
                Foreground = TextPrimary,
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(0, 0, 12, 0)
            });

            _rbVoiceEngineCapCut = new RadioButton
            {
                GroupName = "VoiceEngineGroup",
                Content = "Vozes do CapCut (100% Automático via CapCut Web -> CapCut Desktop)",
                Foreground = AccentGreen,
                FontWeight = FontWeights.Bold,
                IsChecked = _config.IsCapCutVoiceEngine(),
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(0, 0, 18, 0)
            };
            _rbVoiceEngineCapCut.Checked += OnVoiceEngineRadioChanged;
            engineRow.Children.Add(_rbVoiceEngineCapCut);

            _rbVoiceEngineEleven = new RadioButton
            {
                GroupName = "VoiceEngineGroup",
                Content = "ElevenLabs (Opcional)",
                Foreground = TextSecondary,
                IsChecked = !_config.IsCapCutVoiceEngine(),
                VerticalAlignment = VerticalAlignment.Center
            };
            _rbVoiceEngineEleven.Checked += OnVoiceEngineRadioChanged;
            engineRow.Children.Add(_rbVoiceEngineEleven);
            ccVoiceStack.Children.Add(engineRow);

            Grid catVoicesGrid = new Grid { Margin = new Thickness(0, 0, 0, 12) };
            catVoicesGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(230) });
            catVoicesGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(320) });
            catVoicesGrid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            catVoicesGrid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            catVoicesGrid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

            TextBlock lblCat1 = new TextBlock { Text = "📖 1. Novela / Reflexão:", FontSize = 12, FontWeight = FontWeights.SemiBold, Foreground = BrushFromHex("#93C5FD"), VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 4, 8, 6) };
            Grid.SetRow(lblCat1, 0); Grid.SetColumn(lblCat1, 0);
            catVoicesGrid.Children.Add(lblCat1);
            _cmbCapCutVoiceNovela = new ComboBox { IsEditable = true, FontSize = 12, Padding = new Thickness(6, 4, 6, 4), Margin = new Thickness(0, 2, 0, 6), Text = _config.CapCutVoiceNovela };
            Grid.SetRow(_cmbCapCutVoiceNovela, 0); Grid.SetColumn(_cmbCapCutVoiceNovela, 1);
            catVoicesGrid.Children.Add(_cmbCapCutVoiceNovela);

            TextBlock lblCat2 = new TextBlock { Text = "🔮 2. Novela Mística:", FontSize = 12, FontWeight = FontWeights.SemiBold, Foreground = BrushFromHex("#D8B4FE"), VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 4, 8, 6) };
            Grid.SetRow(lblCat2, 1); Grid.SetColumn(lblCat2, 0);
            catVoicesGrid.Children.Add(lblCat2);
            _cmbCapCutVoiceMistica = new ComboBox { IsEditable = true, FontSize = 12, Padding = new Thickness(6, 4, 6, 4), Margin = new Thickness(0, 2, 0, 6), Text = _config.CapCutVoiceNovelaMistica };
            Grid.SetRow(_cmbCapCutVoiceMistica, 1); Grid.SetColumn(_cmbCapCutVoiceMistica, 1);
            catVoicesGrid.Children.Add(_cmbCapCutVoiceMistica);

            TextBlock lblCat3 = new TextBlock { Text = "👻 3. Terror:", FontSize = 12, FontWeight = FontWeights.SemiBold, Foreground = BrushFromHex("#FCA5A5"), VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 4, 8, 4) };
            Grid.SetRow(lblCat3, 2); Grid.SetColumn(lblCat3, 0);
            catVoicesGrid.Children.Add(lblCat3);
            _cmbCapCutVoiceTerror = new ComboBox { IsEditable = true, FontSize = 12, Padding = new Thickness(6, 4, 6, 4), Margin = new Thickness(0, 2, 0, 2), Text = _config.CapCutVoiceTerror };
            Grid.SetRow(_cmbCapCutVoiceTerror, 2); Grid.SetColumn(_cmbCapCutVoiceTerror, 1);
            catVoicesGrid.Children.Add(_cmbCapCutVoiceTerror);

            ccVoiceStack.Children.Add(catVoicesGrid);

            WrapPanel ccVoiceBtns = new WrapPanel { Orientation = Orientation.Horizontal };
            Button btnSaveCapCutVoices = CreateStyledButton("💾 Salvar Vozes das 3 Categorias", AccentGreen, Brushes.White, new Thickness(12, 6, 12, 6));
            btnSaveCapCutVoices.FontWeight = FontWeights.Bold;
            btnSaveCapCutVoices.Margin = new Thickness(0, 0, 8, 4);
            btnSaveCapCutVoices.Click += OnSaveCapCutVoicesClick;
            ccVoiceBtns.Children.Add(btnSaveCapCutVoices);

            Button btnDiscoverCapCutVoices = CreateStyledButton("🔍 Carregar Vozes da Minha Conta CapCut (Chrome)", AccentPrimary, Brushes.White, new Thickness(12, 6, 12, 6));
            btnDiscoverCapCutVoices.Margin = new Thickness(0, 0, 8, 4);
            btnDiscoverCapCutVoices.Click += async (s, e) => await DiscoverCapCutVoicesFromUiAsync();
            ccVoiceBtns.Children.Add(btnDiscoverCapCutVoices);

            Button btnOpenCapCutWeb = CreateStyledButton("🌐 Abrir CapCut Web (Login / Ouvir Vozes)", BgInput, TextPrimary, new Thickness(12, 6, 12, 6));
            btnOpenCapCutWeb.Margin = new Thickness(0, 0, 0, 4);
            btnOpenCapCutWeb.Click += (s, e) =>
            {
                SyncSettingsFromUi();
                string prof = (_config.CapCutWebProfiles != null && _config.CapCutWebProfiles.Count > 0) ? _config.CapCutWebProfiles[0] : "Default";
                _cdp.LaunchChromeProfileWindow(prof, _config.CapCutWebTtsUrl);
                AppendLog(string.Format("[CapCut Web] Abrindo '{0}' no perfil '{1}' para login ou prévia de vozes.", _config.CapCutWebTtsUrl, prof));
            };
            ccVoiceBtns.Children.Add(btnOpenCapCutWeb);

            ccVoiceStack.Children.Add(ccVoiceBtns);
            capcutVoiceBox.Child = ccVoiceStack;
            sp.Children.Add(capcutVoiceBox);

            // SELETOR DE VOZES FAVORITAS DO ELEVENLABS (SUGESTÃO E)
            Border voiceBox = new Border
            {
                Background = BgCard,
                BorderBrush = BorderSubtle,
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(8),
                Padding = new Thickness(12),
                Margin = new Thickness(0, 0, 0, 14)
            };
            StackPanel voiceStack = new StackPanel();
            voiceStack.Children.Add(new TextBlock
            {
                Text = "🎙 VOZES FAVORITAS DO ELEVENLABS (USADO APENAS SE O MOTOR ELEVENLABS ESTIVER MARCADO ACIMA)",
                FontSize = 12,
                FontWeight = FontWeights.Bold,
                Foreground = TextSecondary,
                Margin = new Thickness(0, 0, 0, 8)
            });

            StackPanel voiceRow = new StackPanel { Orientation = Orientation.Horizontal };
            _cmbElevenVoiceSettings = new ComboBox
            {
                Width = 420,
                FontSize = 12,
                Padding = new Thickness(8, 5, 8, 5),
                Margin = new Thickness(0, 0, 10, 0)
            };
            _cmbElevenVoiceSettings.SelectionChanged += OnSettingsVoiceSelectionChanged;
            voiceRow.Children.Add(_cmbElevenVoiceSettings);

            Button btnAddVoice = CreateStyledButton("➕ Cadastrar Nova Voz Favorita...", AccentPrimary, Brushes.White, new Thickness(12, 5, 12, 5));
            btnAddVoice.Click += (s, e) => ShowAddElevenLabsVoiceDialog();
            voiceRow.Children.Add(btnAddVoice);

            voiceStack.Children.Add(voiceRow);
            voiceBox.Child = voiceStack;
            sp.Children.Add(voiceBox);

            sp.Children.Add(new TextBlock
            {
                Text = "MAPEAMENTO OFICIAL DE PERFIS DO GOOGLE CHROME (/fluxo-video-ia)",
                FontSize = 13,
                FontWeight = FontWeights.Bold,
                Foreground = TextPrimary,
                Margin = new Thickness(0, 0, 0, 8)
            });

            StackPanel detectProfRow = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 0, 0, 10) };
            Button btnDetectProfiles = CreateStyledButton("🔍 Detectar e Selecionar Perfis do Chrome deste PC (Grok / Flow / CapCut / Eleven)", BrushFromHex("#7C3AED"), Brushes.White, new Thickness(14, 7, 14, 7));
            btnDetectProfiles.FontWeight = FontWeights.Bold;
            btnDetectProfiles.Margin = new Thickness(0, 0, 10, 0);
            btnDetectProfiles.Click += (s, e) => ShowChromeProfileSelectorDialog();
            detectProfRow.Children.Add(btnDetectProfiles);

            Button btnOpenInspect = CreateStyledButton("🔧 Abrir chrome://inspect (Ativar Depuração Remota)", BgCard, TextPrimary, new Thickness(12, 7, 12, 7));
            btnOpenInspect.Click += (s, e) =>
            {
                string prof = _config.GrokProfiles.Count > 0 ? _config.GrokProfiles[0] : "Default";
                _cdp.LaunchChromeProfileWindow(prof, "chrome://inspect/#remote-debugging");
                AppendLog("[Chrome CDP] Aviso: Na tela chrome://inspect/#remote-debugging, marque a caixinha 'Discover network targets' para ativar a porta 9222.");
            };
            detectProfRow.Children.Add(btnOpenInspect);
            sp.Children.Add(detectProfRow);

            sp.Children.Add(BuildLabeledSetting("Perfis Autorizados Grok Imagine (ordem de fallback automático):",
                string.Join(", ", _config.GrokProfiles), out _txtGrokProfiles));

            sp.Children.Add(BuildLabeledSetting("Perfil Google Flow (GUILHERME - Google AI Ultra):",
                _config.FlowProfile, out _txtFlowProfile));

            sp.Children.Add(BuildLabeledSetting("URL Fixa do Projeto Google Flow:",
                _config.FlowProjectUrl, out _txtFlowUrl));

            Border flowDelayBox = new Border
            {
                Background = BgCard,
                BorderBrush = BorderSubtle,
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(6),
                Padding = new Thickness(12, 10, 12, 10),
                Margin = new Thickness(0, 2, 0, 12),
                Width = 760,
                HorizontalAlignment = HorizontalAlignment.Left
            };
            StackPanel flowDelayStack = new StackPanel();
            flowDelayStack.Children.Add(new TextBlock
            {
                Text = "⏱ DELAY ALEATÓRIO ENTRE AÇÕES DO GOOGLE FLOW (pesquisa de imagens, anexações e após colar comando)",
                FontSize = 12,
                FontWeight = FontWeights.Bold,
                Foreground = TextPrimary,
                Margin = new Thickness(0, 0, 0, 6)
            });

            WrapPanel flowDelayRow = new WrapPanel { Orientation = Orientation.Horizontal };
            flowDelayRow.Children.Add(new TextBlock
            {
                Text = "Mínimo (s):",
                FontSize = 12,
                Foreground = TextSecondary,
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(0, 0, 6, 0)
            });
            _txtFlowDelayMin = CreateStyledTextBox("");
            _txtFlowDelayMin.Text = _config.FlowActionDelayMinSeconds.ToString();
            _txtFlowDelayMin.Width = 58;
            _txtFlowDelayMin.Margin = new Thickness(0, 0, 14, 0);
            flowDelayRow.Children.Add(_txtFlowDelayMin);

            flowDelayRow.Children.Add(new TextBlock
            {
                Text = "Máximo (s):",
                FontSize = 12,
                Foreground = TextSecondary,
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(0, 0, 6, 0)
            });
            _txtFlowDelayMax = CreateStyledTextBox("");
            _txtFlowDelayMax.Text = _config.FlowActionDelayMaxSeconds.ToString();
            _txtFlowDelayMax.Width = 58;
            _txtFlowDelayMax.Margin = new Thickness(0, 0, 14, 0);
            flowDelayRow.Children.Add(_txtFlowDelayMax);

            Button btnApplyFlowDelay = CreateStyledButton("⏱ Aplicar Delay do Flow", AccentPrimary, Brushes.White, new Thickness(12, 6, 12, 6));
            btnApplyFlowDelay.FontWeight = FontWeights.Bold;
            btnApplyFlowDelay.Margin = new Thickness(0, 0, 8, 0);
            btnApplyFlowDelay.Click += (s, e) => ApplyManualFlowDelayFromUi(true);
            flowDelayRow.Children.Add(btnApplyFlowDelay);

            Button btnPresetDefaultDelay = CreateStyledButton("15–30s (Padrão)", BgInput, TextSecondary, new Thickness(10, 6, 10, 6));
            btnPresetDefaultDelay.Margin = new Thickness(0, 0, 6, 0);
            btnPresetDefaultDelay.Click += (s, e) =>
            {
                _txtFlowDelayMin.Text = "15";
                _txtFlowDelayMax.Text = "30";
                ApplyManualFlowDelayFromUi(true);
            };
            flowDelayRow.Children.Add(btnPresetDefaultDelay);

            Button btnPresetZeroDelay = CreateStyledButton("0s (Desativar)", BgInput, TextSecondary, new Thickness(10, 6, 10, 6));
            btnPresetZeroDelay.Margin = new Thickness(0, 0, 10, 0);
            btnPresetZeroDelay.Click += (s, e) =>
            {
                _txtFlowDelayMin.Text = "0";
                _txtFlowDelayMax.Text = "0";
                ApplyManualFlowDelayFromUi(true);
            };
            flowDelayRow.Children.Add(btnPresetZeroDelay);

            _lblFlowDelayActiveBadge = new TextBlock
            {
                Text = string.Format("Ativo: {0}–{1}s", _config.FlowActionDelayMinSeconds, _config.FlowActionDelayMaxSeconds),
                FontSize = 12,
                FontWeight = FontWeights.Bold,
                Foreground = AccentGreen,
                VerticalAlignment = VerticalAlignment.Center
            };
            flowDelayRow.Children.Add(_lblFlowDelayActiveBadge);

            flowDelayStack.Children.Add(flowDelayRow);
            flowDelayBox.Child = flowDelayStack;
            sp.Children.Add(flowDelayBox);

            sp.Children.Add(BuildLabeledSetting("Perfis Autorizados CapCut Web (Principal -> Fallback):",
                string.Join(", ", _config.CapCutWebProfiles), out _txtCapCutWebProfiles));

            sp.Children.Add(BuildLabeledSetting("Perfis Autorizados ElevenLabs (Principal -> Fallback):",
                string.Join(", ", _config.ElevenLabsProfiles), out _txtElevenProfiles));

            sp.Children.Add(BuildLabeledSetting("URL Ativa do ElevenLabs (atualizada automaticamente ao trocar a Voz Favorita acima):",
                _config.ElevenLabsUrl, out _txtElevenUrl));

            sp.Children.Add(new TextBlock
            {
                Text = "DIRETÓRIOS DAS HISTÓRIAS E VÍDEOS NO COMPUTADOR",
                FontSize = 13,
                FontWeight = FontWeights.Bold,
                Foreground = TextPrimary,
                Margin = new Thickness(0, 12, 0, 8)
            });

            sp.Children.Add(BuildLabeledSetting("Pasta Raiz de Novela / Reflexão (_videos de reflexão):",
                string.IsNullOrEmpty(_config.NovelaRootDir) ? EpisodeParser.GetNovelaRoot() : _config.NovelaRootDir,
                out _txtNovelaRootDir));

            sp.Children.Add(BuildLabeledSetting("Pasta Raiz de Terror (_Videos terror):",
                string.IsNullOrEmpty(_config.TerrorRootDir) ? EpisodeParser.GetTerrorRoot() : _config.TerrorRootDir,
                out _txtTerrorRootDir));

            StackPanel dirBtns = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 2, 0, 10) };
            Button btnOpenNovelaDir = CreateStyledButton("📂 Criar / Abrir Pasta Novela", BgCard, TextPrimary, new Thickness(12, 6, 12, 6));
            btnOpenNovelaDir.Margin = new Thickness(0, 0, 8, 0);
            btnOpenNovelaDir.Click += (s, e) =>
            {
                SyncSettingsFromUi();
                OpenDirectoryInExplorer(EpisodeParser.GetNovelaRoot());
            };
            dirBtns.Children.Add(btnOpenNovelaDir);

            Button btnOpenTerrorDir = CreateStyledButton("📂 Criar / Abrir Pasta Terror", BgCard, TextPrimary, new Thickness(12, 6, 12, 6));
            btnOpenTerrorDir.Click += (s, e) =>
            {
                SyncSettingsFromUi();
                OpenDirectoryInExplorer(EpisodeParser.GetTerrorRoot());
            };
            dirBtns.Children.Add(btnOpenTerrorDir);
            sp.Children.Add(dirBtns);

            StackPanel wmiBtns = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 12, 0, 0) };
            Button btnPreOpen = CreateStyledButton("🌐 Pré-Abrir Perfis Grok + Flow no Chrome via WMI", AccentBlue, Brushes.White, new Thickness(14, 8, 14, 8));
            btnPreOpen.Margin = new Thickness(0, 0, 10, 0);
            btnPreOpen.Click += (s, e) => PreOpenAuthorizedChromeProfiles();
            wmiBtns.Children.Add(btnPreOpen);

            Button btnApplyCfg = CreateStyledButton("💾 Salvar e Aplicar Configurações", AccentGreen, Brushes.White, new Thickness(14, 8, 14, 8));
            btnApplyCfg.Click += (s, e) =>
            {
                SyncSettingsFromUi();
                _config.SaveUserSettings();
                RefreshGrokProfileBadges();
                RefreshStoriesList();
                AppendLog("[Configurações] Parâmetros, diretórios e perfis salvos com sucesso!");
            };
            wmiBtns.Children.Add(btnApplyCfg);

            sp.Children.Add(wmiBtns);
            sv.Content = sp;
            tab.Content = sv;
            return tab;
        }

        private UIElement BuildLabeledSetting(string label, string initialValue, out TextBox txtOut)
        {
            StackPanel sp = new StackPanel { Margin = new Thickness(0, 0, 0, 10) };
            sp.Children.Add(new TextBlock
            {
                Text = label,
                FontSize = 12,
                Foreground = TextSecondary,
                Margin = new Thickness(0, 0, 0, 3)
            });
            txtOut = CreateStyledTextBox("");
            txtOut.Text = initialValue;
            txtOut.Width = 760;
            txtOut.HorizontalAlignment = HorizontalAlignment.Left;
            sp.Children.Add(txtOut);
            return sp;
        }

        private Button CreateStyledButton(string text, Brush bg, Brush fg, Thickness padding)
        {
            return new Button
            {
                Content = text,
                Background = bg,
                Foreground = fg,
                BorderBrush = BorderSubtle,
                BorderThickness = new Thickness(1),
                Padding = padding,
                Cursor = Cursors.Hand,
                FontSize = 12
            };
        }

        private TextBox CreateStyledTextBox(string placeholder)
        {
            return new TextBox
            {
                Background = BgInput,
                Foreground = TextPrimary,
                BorderBrush = BorderSubtle,
                BorderThickness = new Thickness(1),
                Padding = new Thickness(8, 5, 8, 5),
                FontSize = 12,
                ToolTip = string.IsNullOrEmpty(placeholder) ? null : placeholder
            };
        }

    }
}
