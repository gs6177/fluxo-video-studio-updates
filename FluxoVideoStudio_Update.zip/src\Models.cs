using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Web.Script.Serialization;

namespace FluxoVideoStudio
{
    public enum GenreType
    {
        NovelaReflexao,
        Terror,
        Custom
    }

    public enum StageState
    {
        Idle,
        Running,
        Success,
        Skipped,
        PausedReview,
        Failed
    }

    public class ElevenLabsVoicePreset
    {
        public string Name { get; set; }
        public string VoiceId { get; set; }
        public string Category { get; set; }

        public ElevenLabsVoicePreset()
        {
            Name = "";
            VoiceId = "";
            Category = "Novela / Reflexão";
        }

        public string BuildUrl()
        {
            string vid = (VoiceId ?? "").Trim();
            if (vid.IndexOf("http", StringComparison.OrdinalIgnoreCase) >= 0)
                return vid;
            return "https://elevenlabs.io/app/speech-synthesis/text-to-speech?voiceId=" + vid;
        }

        public override string ToString()
        {
            return string.Format("[{0}] {1} ({2})", Category ?? "Voz", Name ?? "Voz", VoiceId ?? "");
        }
    }

    public class GrokAssetSpec
    {
        public int OrderIndex { get; set; }
        public bool IsScenario { get; set; }
        public string LabelPrefix { get; set; }
        public string DisplayTitle { get; set; }
        public string TargetFileName { get; set; }
        public string RawPromptLine { get; set; }

        public GrokAssetSpec()
        {
            LabelPrefix = "";
            DisplayTitle = "";
            TargetFileName = "";
            RawPromptLine = "";
        }
    }

    public class CharacterWardrobeSpec
    {
        public string BaseCharacterFileName { get; set; }
        public string CharacterDisplayName { get; set; }
        public string CategoryKey { get; set; }
        public string DisplayLabel { get; set; }
        public string VariantFileName { get; set; }
        public string OutfitPromptDescription { get; set; }
        public string ReasonFromText { get; set; }

        public CharacterWardrobeSpec()
        {
            BaseCharacterFileName = "";
            CharacterDisplayName = "";
            CategoryKey = "";
            DisplayLabel = "";
            VariantFileName = "";
            OutfitPromptDescription = "";
            ReasonFromText = "";
        }
    }

    public class FlowTakeSpec
    {
        public int TakeNumber { get; set; }
        public string ScenarioName { get; set; }
        public List<string> Ingredients { get; set; }
        public string DurationText { get; set; }
        public bool HasSpeech { get; set; }
        public string RawHeader { get; set; }
        public string RawPromptBody { get; set; }
        public Dictionary<string, string> CharacterOutfitOverrides { get; set; }
        public string PreferredEngine { get; set; }

        public FlowTakeSpec()
        {
            ScenarioName = "";
            Ingredients = new List<string>();
            DurationText = "10s";
            RawHeader = "";
            RawPromptBody = "";
            CharacterOutfitOverrides = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            PreferredEngine = "Auto";
        }

        public FlowTakeSpec Clone()
        {
            FlowTakeSpec c = new FlowTakeSpec();
            c.TakeNumber = TakeNumber;
            c.ScenarioName = ScenarioName;
            c.Ingredients = new List<string>(Ingredients);
            c.DurationText = DurationText;
            c.HasSpeech = HasSpeech;
            c.RawHeader = RawHeader;
            c.RawPromptBody = RawPromptBody;
            c.PreferredEngine = PreferredEngine;
            foreach (KeyValuePair<string, string> kv in CharacterOutfitOverrides)
            {
                c.CharacterOutfitOverrides[kv.Key] = kv.Value;
            }
            return c;
        }
    }

    public class AssetFileEntry : INotifyPropertyChanged
    {
        private string _fileName;
        private string _fullPath;
        private string _expectedTitle;
        private string _ocrText;
        private bool _exists;
        private long _sizeKb;

        public int Index { get; set; }

        public string FileName
        {
            get { return _fileName; }
            set { _fileName = value; OnPropertyChanged("FileName"); }
        }

        public string FullPath
        {
            get { return _fullPath; }
            set { _fullPath = value; OnPropertyChanged("FullPath"); }
        }

        public string ExpectedTitle
        {
            get { return _expectedTitle; }
            set { _expectedTitle = value; OnPropertyChanged("ExpectedTitle"); }
        }

        public string OcrText
        {
            get { return _ocrText; }
            set { _ocrText = value; OnPropertyChanged("OcrText"); }
        }

        public bool Exists
        {
            get { return _exists; }
            set { _exists = value; OnPropertyChanged("Exists"); OnPropertyChanged("StatusBadge"); }
        }

        public long SizeKb
        {
            get { return _sizeKb; }
            set { _sizeKb = value; OnPropertyChanged("SizeKb"); OnPropertyChanged("StatusBadge"); }
        }

        public string StatusBadge
        {
            get
            {
                if (!_exists) return "PENDENTE";
                return string.Format("OK ({0} KB)", _sizeKb);
            }
        }

        public AssetFileEntry()
        {
            _fileName = "";
            _fullPath = "";
            _expectedTitle = "";
            _ocrText = "";
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string prop)
        {
            PropertyChangedEventHandler h = PropertyChanged;
            if (h != null) h(this, new PropertyChangedEventArgs(prop));
        }
    }

    public class EpisodeWorkItem
    {
        public string StoryName { get; set; }
        public GenreType Genre { get; set; }
        public string EpisodeName { get; set; }
        public int EpisodeNumber { get; set; }
        public string StoryRootPath { get; set; }
        public string EpisodePath { get; set; }
        public string AssetsDir { get; set; }
        public string TakesDir { get; set; }

        public string RoteiroPath { get; set; }
        public string GrokPromptPath { get; set; }
        public string FlowPromptPath { get; set; }
        public string NarradorTxtPath { get; set; }

        public string GrokPromptText { get; set; }
        public string FlowPromptText { get; set; }
        public string RoteiroText { get; set; }
        public string UnifiedNarratorText { get; set; }
        public int NarratorSegmentsCount { get; set; }

        public List<GrokAssetSpec> GrokSpecs { get; set; }
        public List<FlowTakeSpec> FlowTakes { get; set; }
        public List<string> AllRequiredFlowIngredients { get; set; }

        public int ExistingAssetsCount { get; set; }
        public int ExistingTakesCount { get; set; }
        public bool HasProcessedNarratorWav { get; set; }

        public string CapCutProjectName
        {
            get
            {
                string cleanStory = (StoryName ?? "Projeto").Replace(" ", "_");
                string cleanEp = (EpisodeName ?? "EP1").Replace(".", "");
                return string.Format("{0}_{1}", cleanStory, cleanEp);
            }
        }

        public string SummaryLine
        {
            get
            {
                int reqAssets = AllRequiredFlowIngredients.Count > 0 ? AllRequiredFlowIngredients.Count : GrokSpecs.Count;
                int reqTakes = FlowTakes.Count;
                string narInfo = string.IsNullOrWhiteSpace(UnifiedNarratorText)
                    ? "Sem Narrador"
                    : (HasProcessedNarratorWav ? "Narrador WAV OK" : string.Format("Narrador ({0} falas)", NarratorSegmentsCount));
                return string.Format("{0}  |  Assets: {1}/{2}  |  Takes: {3}/{4}  |  {5}",
                    EpisodeName, ExistingAssetsCount, reqAssets, ExistingTakesCount, reqTakes, narInfo);
            }
        }

        public EpisodeWorkItem()
        {
            StoryName = "";
            EpisodeName = "EP.1";
            EpisodeNumber = 1;
            StoryRootPath = "";
            EpisodePath = "";
            AssetsDir = "";
            TakesDir = "";
            RoteiroPath = "";
            GrokPromptPath = "";
            FlowPromptPath = "";
            NarradorTxtPath = "";
            GrokPromptText = "";
            FlowPromptText = "";
            RoteiroText = "";
            UnifiedNarratorText = "";
            GrokSpecs = new List<GrokAssetSpec>();
            FlowTakes = new List<FlowTakeSpec>();
            AllRequiredFlowIngredients = new List<string>();
        }
    }

    public class StoryProject
    {
        public string Name { get; set; }
        public GenreType Genre { get; set; }
        public string FolderPath { get; set; }
        public DateTime LastModified { get; set; }
        public List<EpisodeWorkItem> Episodes { get; set; }

        public string GenreBadge
        {
            get
            {
                if (Genre == GenreType.NovelaReflexao) return "NOVELA / REFLEXÃO";
                if (Genre == GenreType.Terror) return "TERROR";
                return "PASTA MANUAL";
            }
        }

        public string DisplayHeader
        {
            get { return string.Format("[{0}] {1}", Genre == GenreType.Terror ? "TERROR" : (Genre == GenreType.NovelaReflexao ? "NOVELA" : "CUSTOM"), Name); }
        }

        public StoryProject()
        {
            Name = "";
            FolderPath = "";
            Episodes = new List<EpisodeWorkItem>();
        }
    }

    public class PipelineConfig
    {
        public bool RunGrok { get; set; }
        public bool PreserveExistingAssets { get; set; }
        public bool ArchiveOldTakesBeforeRemake { get; set; }
        public bool PauseAfterGrokForVisualReview { get; set; }
        public bool RunFlow { get; set; }
        public bool ReuseEp1HookTake01 { get; set; }
        public bool RunElevenLabs { get; set; }
        public bool RunCapCut { get; set; }
        public bool LaunchCapCutDesktop { get; set; }

        public string ChromeExePath { get; set; }
        public List<string> GrokProfiles { get; set; }
        public string GrokUrl { get; set; }

        public string FlowProfile { get; set; }
        public string FlowProjectUrl { get; set; }

        public List<string> ElevenLabsProfiles { get; set; }
        public string ElevenLabsUrl { get; set; }

        public List<ElevenLabsVoicePreset> VoicePresets { get; set; }
        public Dictionary<string, string> GrokProfileStatuses { get; set; }
        public Action<string, string> OnProfileStatusChanged { get; set; }

        public string SkillScriptsDir { get; set; }
        public string StudioScriptsDir { get; set; }
        public string TempFlowAssetsDir { get; set; }

        public string NovelaRootDir { get; set; }
        public string TerrorRootDir { get; set; }

        public string RemoteUpdateRepo { get; set; }
        public string RemoteUpdateToken { get; set; }
        public bool AutoCheckUpdatesOnStartup { get; set; }

        public PipelineConfig()
        {
            RunGrok = true;
            PreserveExistingAssets = true;
            ArchiveOldTakesBeforeRemake = true;
            PauseAfterGrokForVisualReview = false;
            RunFlow = true;
            ReuseEp1HookTake01 = true;
            RunElevenLabs = true;
            RunCapCut = true;
            LaunchCapCutDesktop = true;

            ChromeExePath = @"C:\Program Files\Google\Chrome\Application\chrome.exe";
            GrokProfiles = new List<string> { "Profile 62", "Profile 1", "Profile 67" };
            GrokUrl = "https://grok.com/imagine";

            FlowProfile = "Profile 2";
            FlowProjectUrl = "https://flow.google.com/project/9b576f1d-9b0f-4103-ac8e-123edb00a1f0";

            ElevenLabsProfiles = new List<string> { "Profile 4", "Profile 63" };
            ElevenLabsUrl = "https://elevenlabs.io/app/speech-synthesis/text-to-speech?voiceId=ppLqTilh7rH7fbUVlXsf";

            VoicePresets = new List<ElevenLabsVoicePreset>
            {
                new ElevenLabsVoicePreset { Name = "David - Documentary (Padrão)", VoiceId = "ppLqTilh7rH7fbUVlXsf", Category = "Novela / Reflexão" },
                new ElevenLabsVoicePreset { Name = "Narrador Sombrio / Suspense", VoiceId = "N2lVS1w4EtoT3dr4eOWO", Category = "Terror" },
                new ElevenLabsVoicePreset { Name = "Narrador Emotivo / Calmo", VoiceId = "pNInz6obpgDQGcFmaJgB", Category = "Reflexão" }
            };

            GrokProfileStatuses = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            foreach (string p in GrokProfiles)
            {
                GrokProfileStatuses[p] = "NÃO VERIFICADO";
            }

            string userProfile = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
            string localAppData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            string appRoot = GetAppRootDir();
            StudioScriptsDir = System.IO.Path.Combine(appRoot, "scripts");
            string defaultSkillScripts = System.IO.Path.Combine(userProfile, @".gemini\config\skills\fluxo-video-ia\scripts");
            SkillScriptsDir = Directory.Exists(defaultSkillScripts) ? defaultSkillScripts : StudioScriptsDir;
            TempFlowAssetsDir = System.IO.Path.Combine(localAppData, @"Temp\flow_assets");

            RemoteUpdateRepo = "gs6177/fluxo-video-studio-updates";
            RemoteUpdateToken = "";
            AutoCheckUpdatesOnStartup = true;

            LoadSharedRemoteUpdateConfig();
            LoadUserSettings();
            if (string.IsNullOrWhiteSpace(RemoteUpdateRepo))
                RemoteUpdateRepo = "gs6177/fluxo-video-studio-updates";
        }

        public string LocalInstalledVersion { get; set; }

        public static bool IsMasterDeveloperPc()
        {
            string u = Environment.UserName ?? "";
            if (string.Equals(u, "Best Option Notebook", StringComparison.OrdinalIgnoreCase))
                return true;
            if (Directory.Exists(@"C:\Users\Best Option Notebook\.gemini\antigravity\scratch\fluxo-video-studio"))
                return true;
            return false;
        }

        public void LoadSharedRemoteUpdateConfig()
        {
            try
            {
                string cfgPath = Path.Combine(GetAppRootDir(), "remote_update_config.json");
                if (!File.Exists(cfgPath)) return;
                JavaScriptSerializer ser = new JavaScriptSerializer();
                Dictionary<string, object> d = ser.Deserialize<Dictionary<string, object>>(File.ReadAllText(cfgPath, System.Text.Encoding.UTF8));
                if (d != null)
                {
                    if (d.ContainsKey("RemoteUpdateRepo"))
                    {
                        string r = Convert.ToString(d["RemoteUpdateRepo"] ?? "").Trim();
                        if (!string.IsNullOrEmpty(r)) RemoteUpdateRepo = r;
                    }
                    if (d.ContainsKey("Version"))
                    {
                        string v = Convert.ToString(d["Version"] ?? "").Trim();
                        if (!string.IsNullOrEmpty(v)) LocalInstalledVersion = v;
                    }
                }
            }
            catch { }
        }

        public void SaveSharedRemoteUpdateConfig()
        {
            try
            {
                if (string.IsNullOrWhiteSpace(RemoteUpdateRepo)) return;
                string cfgPath = Path.Combine(GetAppRootDir(), "remote_update_config.json");
                JavaScriptSerializer ser = new JavaScriptSerializer();
                string existingVer = LocalInstalledVersion ?? "";
                if (string.IsNullOrEmpty(existingVer) && File.Exists(cfgPath))
                {
                    try
                    {
                        Dictionary<string, object> old = ser.Deserialize<Dictionary<string, object>>(File.ReadAllText(cfgPath, System.Text.Encoding.UTF8));
                        if (old != null && old.ContainsKey("Version"))
                            existingVer = Convert.ToString(old["Version"] ?? "");
                    }
                    catch { }
                }
                Dictionary<string, object> d = new Dictionary<string, object>
                {
                    { "RemoteUpdateRepo", RemoteUpdateRepo.Trim() },
                    { "Version", existingVer },
                    { "UpdatedAt", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") }
                };
                File.WriteAllText(cfgPath, ser.Serialize(d), new System.Text.UTF8Encoding(false));
            }
            catch { }
        }

        public static string GetAppRootDir()
        {
            string envDir = Environment.GetEnvironmentVariable("FVS_BASE_DIR");
            if (!string.IsNullOrEmpty(envDir) && Directory.Exists(envDir))
                return envDir;
            return AppDomain.CurrentDomain.BaseDirectory;
        }

        public void SetProfileStatus(string profile, string status)
        {
            if (string.IsNullOrEmpty(profile)) return;
            lock (GrokProfileStatuses)
            {
                GrokProfileStatuses[profile] = status ?? "NÃO VERIFICADO";
            }
            SaveUserSettings();
            Action<string, string> cb = OnProfileStatusChanged;
            if (cb != null)
            {
                try { cb(profile, status); } catch { }
            }
        }

        public string GetProfileStatus(string profile)
        {
            if (string.IsNullOrEmpty(profile)) return "NÃO VERIFICADO";
            lock (GrokProfileStatuses)
            {
                string st;
                if (GrokProfileStatuses.TryGetValue(profile, out st) && !string.IsNullOrEmpty(st))
                    return st;
            }
            return "NÃO VERIFICADO";
        }

        public List<string> GetAvailableGrokProfiles(Action<string> logger)
        {
            List<string> available = new List<string>();
            List<string> exhausted = new List<string>();

            foreach (string prof in GrokProfiles)
            {
                string st = GetProfileStatus(prof);
                if (st.IndexOf("LIMITE", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    exhausted.Add(prof);
                }
                else
                {
                    available.Add(prof);
                }
            }

            if (exhausted.Count > 0 && available.Count > 0 && logger != null)
            {
                logger(string.Format("[Grok Contas] Pulando automaticamente perfil(is) com limite já atingido: {0}. Usando perfil(is) disponível(is): {1}.",
                    string.Join(", ", exhausted), string.Join(", ", available)));
            }
            else if (available.Count == 0 && exhausted.Count > 0)
            {
                if (logger != null)
                {
                    logger("[Grok Contas] Aviso: Todos os perfis estavam marcados com 'LIMITE ATINGIDO'. Re-testando perfis em caso de renovação de cota...");
                }
                return new List<string>(GrokProfiles);
            }

            return available;
        }

        public void ResetAllGrokProfileStatuses()
        {
            lock (GrokProfileStatuses)
            {
                foreach (string p in GrokProfiles)
                {
                    GrokProfileStatuses[p] = "NÃO VERIFICADO";
                }
            }
            SaveUserSettings();
            Action<string, string> cb = OnProfileStatusChanged;
            if (cb != null)
            {
                try { cb("", "NÃO VERIFICADO"); } catch { }
            }
        }

        public string GetSettingsFilePath()
        {
            return Path.Combine(GetAppRootDir(), "studio_user_settings.json");
        }

        public void SaveUserSettings()
        {
            try
            {
                Dictionary<string, object> data = new Dictionary<string, object>();
                data["GrokProfiles"] = GrokProfiles;
                data["FlowProfile"] = FlowProfile;
                data["FlowProjectUrl"] = FlowProjectUrl;
                data["ElevenLabsProfiles"] = ElevenLabsProfiles;
                data["ElevenLabsUrl"] = ElevenLabsUrl;
                data["NovelaRootDir"] = NovelaRootDir ?? "";
                data["TerrorRootDir"] = TerrorRootDir ?? "";
                data["RemoteUpdateRepo"] = RemoteUpdateRepo ?? "";
                data["RemoteUpdateToken"] = RemoteUpdateToken ?? "";
                data["AutoCheckUpdatesOnStartup"] = AutoCheckUpdatesOnStartup;

                Dictionary<string, string> statusCopy = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                lock (GrokProfileStatuses)
                {
                    foreach (KeyValuePair<string, string> kv in GrokProfileStatuses)
                    {
                        statusCopy[kv.Key] = kv.Value ?? "NÃO VERIFICADO";
                    }
                }
                data["GrokProfileStatuses"] = statusCopy;

                List<Dictionary<string, string>> voices = new List<Dictionary<string, string>>();
                if (VoicePresets != null)
                {
                    foreach (ElevenLabsVoicePreset vp in VoicePresets)
                    {
                        Dictionary<string, string> vd = new Dictionary<string, string>();
                        vd["Name"] = vp.Name ?? "";
                        vd["VoiceId"] = vp.VoiceId ?? "";
                        vd["Category"] = vp.Category ?? "Novela / Reflexão";
                        voices.Add(vd);
                    }
                }
                data["VoicePresets"] = voices;

                JavaScriptSerializer ser = new JavaScriptSerializer();
                string json = ser.Serialize(data);
                File.WriteAllText(GetSettingsFilePath(), json, new System.Text.UTF8Encoding(false));
            }
            catch { }
        }

        public void LoadUserSettings()
        {
            try
            {
                string path = GetSettingsFilePath();
                if (!File.Exists(path)) return;
                string json = File.ReadAllText(path, System.Text.Encoding.UTF8);
                JavaScriptSerializer ser = new JavaScriptSerializer();
                Dictionary<string, object> data = ser.Deserialize<Dictionary<string, object>>(json);
                if (data == null) return;

                if (data.ContainsKey("GrokProfiles") && data["GrokProfiles"] is System.Collections.IEnumerable)
                {
                    List<string> gp = new List<string>();
                    foreach (object o in (System.Collections.IEnumerable)data["GrokProfiles"])
                    {
                        string s = Convert.ToString(o ?? "").Trim();
                        if (!string.IsNullOrEmpty(s)) gp.Add(s);
                    }
                    if (gp.Count > 0) GrokProfiles = gp;
                }

                if (data.ContainsKey("GrokProfileStatuses") && data["GrokProfileStatuses"] is Dictionary<string, object>)
                {
                    Dictionary<string, object> stMap = (Dictionary<string, object>)data["GrokProfileStatuses"];
                    lock (GrokProfileStatuses)
                    {
                        foreach (KeyValuePair<string, object> kv in stMap)
                        {
                            string stVal = Convert.ToString(kv.Value ?? "").Trim();
                            if (!string.IsNullOrEmpty(kv.Key) && !string.IsNullOrEmpty(stVal))
                                GrokProfileStatuses[kv.Key] = stVal;
                        }
                    }
                }

                if (data.ContainsKey("FlowProfile"))
                {
                    string fp = Convert.ToString(data["FlowProfile"] ?? "").Trim();
                    if (!string.IsNullOrEmpty(fp)) FlowProfile = fp;
                }

                if (data.ContainsKey("FlowProjectUrl"))
                {
                    string fu = Convert.ToString(data["FlowProjectUrl"] ?? "").Trim();
                    if (!string.IsNullOrEmpty(fu)) FlowProjectUrl = fu;
                }

                if (data.ContainsKey("ElevenLabsProfiles") && data["ElevenLabsProfiles"] is System.Collections.IEnumerable)
                {
                    List<string> ep = new List<string>();
                    foreach (object o in (System.Collections.IEnumerable)data["ElevenLabsProfiles"])
                    {
                        string s = Convert.ToString(o ?? "").Trim();
                        if (!string.IsNullOrEmpty(s)) ep.Add(s);
                    }
                    if (ep.Count > 0) ElevenLabsProfiles = ep;
                }

                if (data.ContainsKey("ElevenLabsUrl"))
                {
                    string eu = Convert.ToString(data["ElevenLabsUrl"] ?? "").Trim();
                    if (!string.IsNullOrEmpty(eu)) ElevenLabsUrl = eu;
                }

                if (data.ContainsKey("NovelaRootDir"))
                {
                    string nr = Convert.ToString(data["NovelaRootDir"] ?? "").Trim();
                    if (!string.IsNullOrEmpty(nr))
                    {
                        NovelaRootDir = nr;
                        EpisodeParser.CustomNovelaRoot = nr;
                    }
                }

                if (data.ContainsKey("TerrorRootDir"))
                {
                    string tr = Convert.ToString(data["TerrorRootDir"] ?? "").Trim();
                    if (!string.IsNullOrEmpty(tr))
                    {
                        TerrorRootDir = tr;
                        EpisodeParser.CustomTerrorRoot = tr;
                    }
                }

                if (data.ContainsKey("RemoteUpdateRepo"))
                {
                    string rur = Convert.ToString(data["RemoteUpdateRepo"] ?? "").Trim();
                    if (!string.IsNullOrEmpty(rur)) RemoteUpdateRepo = rur;
                }

                if (data.ContainsKey("RemoteUpdateToken"))
                {
                    string rut = Convert.ToString(data["RemoteUpdateToken"] ?? "").Trim();
                    if (!string.IsNullOrEmpty(rut)) RemoteUpdateToken = rut;
                }

                if (data.ContainsKey("AutoCheckUpdatesOnStartup"))
                {
                    try { AutoCheckUpdatesOnStartup = Convert.ToBoolean(data["AutoCheckUpdatesOnStartup"]); } catch { }
                }

                if (data.ContainsKey("VoicePresets") && data["VoicePresets"] is System.Collections.IEnumerable)
                {
                    List<ElevenLabsVoicePreset> loadedVoices = new List<ElevenLabsVoicePreset>();
                    foreach (object item in (System.Collections.IEnumerable)data["VoicePresets"])
                    {
                        Dictionary<string, object> vd = item as Dictionary<string, object>;
                        if (vd == null) continue;
                        string n = vd.ContainsKey("Name") ? Convert.ToString(vd["Name"] ?? "").Trim() : "";
                        string v = vd.ContainsKey("VoiceId") ? Convert.ToString(vd["VoiceId"] ?? "").Trim() : "";
                        string c = vd.ContainsKey("Category") ? Convert.ToString(vd["Category"] ?? "Novela").Trim() : "Novela";
                        if (!string.IsNullOrEmpty(n) && !string.IsNullOrEmpty(v))
                        {
                            loadedVoices.Add(new ElevenLabsVoicePreset { Name = n, VoiceId = v, Category = c });
                        }
                    }
                    if (loadedVoices.Count > 0) VoicePresets = loadedVoices;
                }

                foreach (string p in GrokProfiles)
                {
                    if (!GrokProfileStatuses.ContainsKey(p))
                        GrokProfileStatuses[p] = "NÃO VERIFICADO";
                }
            }
            catch { }
        }
    }

    public class LastActionCheckpoint
    {
        public string Timestamp { get; set; }
        public string StoryName { get; set; }
        public string EpisodeName { get; set; }
        public string EpisodePath { get; set; }
        public string StageName { get; set; }
        public string SubActionDescription { get; set; }
        public string ChromeProfile { get; set; }
        public string SessionId { get; set; }
        public string PageUrl { get; set; }
        public string TargetItemName { get; set; }
        public int TargetTakeNumber { get; set; }
        public int BatchNumber { get; set; }
        public string PromptSent { get; set; }
        public List<string> AttachedFiles { get; set; }
        public string Status { get; set; }

        public LastActionCheckpoint()
        {
            Timestamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            StoryName = "";
            EpisodeName = "";
            EpisodePath = "";
            StageName = "";
            SubActionDescription = "";
            ChromeProfile = "";
            SessionId = "";
            PageUrl = "";
            TargetItemName = "";
            PromptSent = "";
            AttachedFiles = new List<string>();
            Status = "IN_PROGRESS";
        }
    }

    public static class LastActionHistoryStore
    {
        private static readonly object _sync = new object();
        private static LastActionCheckpoint _current;
        private static readonly List<LastActionCheckpoint> _recentHistory = new List<LastActionCheckpoint>();

        public static LastActionCheckpoint Current
        {
            get
            {
                lock (_sync)
                {
                    return _current;
                }
            }
        }

        public static string GetGlobalHistoryFilePath()
        {
            return Path.Combine(PipelineConfig.GetAppRootDir(), "last_action_history.json");
        }

        public static void RecordAction(
            EpisodeWorkItem ep,
            string stageName,
            string subActionDescription,
            string chromeProfile,
            string sessionId,
            string pageUrl,
            string targetItemName,
            int targetTakeNumber,
            int batchNumber,
            string promptSent,
            IEnumerable<string> attachedFiles,
            string status)
        {
            lock (_sync)
            {
                LastActionCheckpoint cp = new LastActionCheckpoint();
                cp.Timestamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                cp.StoryName = ep != null ? (ep.StoryName ?? "") : (_current != null ? _current.StoryName : "");
                cp.EpisodeName = ep != null ? (ep.EpisodeName ?? "") : (_current != null ? _current.EpisodeName : "");
                cp.EpisodePath = ep != null ? (ep.EpisodePath ?? "") : (_current != null ? _current.EpisodePath : "");
                cp.StageName = stageName ?? (_current != null ? _current.StageName : "");
                cp.SubActionDescription = subActionDescription ?? "";
                cp.ChromeProfile = chromeProfile ?? (_current != null ? _current.ChromeProfile : "");
                cp.SessionId = sessionId ?? (_current != null ? _current.SessionId : "");
                cp.PageUrl = pageUrl ?? (_current != null ? _current.PageUrl : "");
                cp.TargetItemName = targetItemName ?? "";
                cp.TargetTakeNumber = targetTakeNumber;
                cp.BatchNumber = batchNumber;
                cp.PromptSent = !string.IsNullOrEmpty(promptSent)
                    ? promptSent
                    : (_current != null && _current.TargetItemName == cp.TargetItemName ? _current.PromptSent : "");

                if (attachedFiles != null)
                {
                    foreach (string f in attachedFiles)
                    {
                        if (!string.IsNullOrEmpty(f))
                            cp.AttachedFiles.Add(f);
                    }
                }
                else if (_current != null && _current.TargetItemName == cp.TargetItemName && _current.AttachedFiles != null)
                {
                    cp.AttachedFiles.AddRange(_current.AttachedFiles);
                }

                cp.Status = status ?? "IN_PROGRESS";
                _current = cp;

                _recentHistory.Insert(0, cp);
                if (_recentHistory.Count > 30)
                {
                    _recentHistory.RemoveRange(30, _recentHistory.Count - 30);
                }

                SaveToDiskInternal(cp);
            }
        }

        public static void UpdateStatus(EpisodeWorkItem ep, string status, string subActionDescription = null)
        {
            lock (_sync)
            {
                if (_current == null)
                    _current = new LastActionCheckpoint();
                if (ep != null)
                {
                    if (!string.IsNullOrEmpty(ep.StoryName)) _current.StoryName = ep.StoryName;
                    if (!string.IsNullOrEmpty(ep.EpisodeName)) _current.EpisodeName = ep.EpisodeName;
                    if (!string.IsNullOrEmpty(ep.EpisodePath)) _current.EpisodePath = ep.EpisodePath;
                }
                _current.Timestamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                if (!string.IsNullOrEmpty(status))
                    _current.Status = status;
                if (!string.IsNullOrEmpty(subActionDescription))
                    _current.SubActionDescription = subActionDescription;
                SaveToDiskInternal(_current);
            }
        }

        public static LastActionCheckpoint LoadLastCheckpointFromDisk(string episodePath = null)
        {
            lock (_sync)
            {
                try
                {
                    string targetFile = GetGlobalHistoryFilePath();
                    if (!string.IsNullOrEmpty(episodePath))
                    {
                        string epFile = Path.Combine(episodePath, "last_action_history.json");
                        if (File.Exists(epFile))
                            targetFile = epFile;
                    }

                    if (!File.Exists(targetFile))
                        return _current;

                    JavaScriptSerializer ser = new JavaScriptSerializer();
                    ser.MaxJsonLength = int.MaxValue;
                    Dictionary<string, object> root = ser.Deserialize<Dictionary<string, object>>(File.ReadAllText(targetFile, System.Text.Encoding.UTF8));
                    if (root == null || !root.ContainsKey("CurrentAction"))
                        return _current;

                    Dictionary<string, object> d = root["CurrentAction"] as Dictionary<string, object>;
                    if (d == null) return _current;

                    LastActionCheckpoint cp = new LastActionCheckpoint();
                    cp.Timestamp = d.ContainsKey("Timestamp") ? Convert.ToString(d["Timestamp"] ?? "") : "";
                    cp.StoryName = d.ContainsKey("StoryName") ? Convert.ToString(d["StoryName"] ?? "") : "";
                    cp.EpisodeName = d.ContainsKey("EpisodeName") ? Convert.ToString(d["EpisodeName"] ?? "") : "";
                    cp.EpisodePath = d.ContainsKey("EpisodePath") ? Convert.ToString(d["EpisodePath"] ?? "") : "";
                    cp.StageName = d.ContainsKey("StageName") ? Convert.ToString(d["StageName"] ?? "") : "";
                    cp.SubActionDescription = d.ContainsKey("SubActionDescription") ? Convert.ToString(d["SubActionDescription"] ?? "") : "";
                    cp.ChromeProfile = d.ContainsKey("ChromeProfile") ? Convert.ToString(d["ChromeProfile"] ?? "") : "";
                    cp.PageUrl = d.ContainsKey("PageUrl") ? Convert.ToString(d["PageUrl"] ?? "") : "";
                    cp.TargetItemName = d.ContainsKey("TargetItemName") ? Convert.ToString(d["TargetItemName"] ?? "") : "";
                    cp.TargetTakeNumber = d.ContainsKey("TargetTakeNumber") ? Convert.ToInt32(d["TargetTakeNumber"]) : 0;
                    cp.BatchNumber = d.ContainsKey("BatchNumber") ? Convert.ToInt32(d["BatchNumber"]) : 0;
                    cp.PromptSent = d.ContainsKey("PromptSent") ? Convert.ToString(d["PromptSent"] ?? "") : "";
                    cp.Status = d.ContainsKey("Status") ? Convert.ToString(d["Status"] ?? "") : "";

                    if (d.ContainsKey("AttachedFiles") && d["AttachedFiles"] is System.Collections.IEnumerable)
                    {
                        foreach (object o in (System.Collections.IEnumerable)d["AttachedFiles"])
                        {
                            string s = Convert.ToString(o ?? "").Trim();
                            if (!string.IsNullOrEmpty(s))
                                cp.AttachedFiles.Add(s);
                        }
                    }

                    _current = cp;
                    return cp;
                }
                catch
                {
                    return _current;
                }
            }
        }

        private static void SaveToDiskInternal(LastActionCheckpoint current)
        {
            try
            {
                JavaScriptSerializer ser = new JavaScriptSerializer();
                ser.MaxJsonLength = int.MaxValue;

                Dictionary<string, object> payload = new Dictionary<string, object>();
                payload["UpdatedAt"] = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                payload["CurrentAction"] = current;
                payload["RecentHistory"] = _recentHistory;

                string json = ser.Serialize(payload);
                System.Text.UTF8Encoding utf8 = new System.Text.UTF8Encoding(false);

                File.WriteAllText(GetGlobalHistoryFilePath(), json, utf8);

                if (current != null && !string.IsNullOrEmpty(current.EpisodePath) && Directory.Exists(current.EpisodePath))
                {
                    string epHistoryPath = Path.Combine(current.EpisodePath, "last_action_history.json");
                    File.WriteAllText(epHistoryPath, json, utf8);
                }
            }
            catch { }
        }
    }
}
