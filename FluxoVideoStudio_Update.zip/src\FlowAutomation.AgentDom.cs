using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace FluxoVideoStudio
{
    public partial class FlowAutomation
    {
        private async Task EnsureAgentPanelOpenAsync(string sess, CancellationToken ct)
        {
            for (int attempt = 0; attempt < 4; attempt++)
            {
                ct.ThrowIfCancellationRequested();
                Dictionary<string, object> state = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var newSess = Array.from(document.querySelectorAll('button')).find(b => {
        var al = (b.getAttribute('aria-label') || '').toLowerCase();
        var txt = (b.innerText || '').trim().toLowerCase();
        var r = b.getBoundingClientRect();
        return r.width > 10 && r.height > 10 &&
               (al.indexOf('nova sess') >= 0 || al.indexOf('new session') >= 0 || txt === 'edit_square' || txt.indexOf('edit_square') >= 0);
    });
    if (newSess) return JSON.stringify({ step: 'OPEN' });

    var expBtn = Array.from(document.querySelectorAll('button')).find(x => {
        var al = (x.getAttribute('aria-label') || '').toLowerCase();
        var txt = (x.innerText || '').trim().toLowerCase();
        var r = x.getBoundingClientRect();
        return r.width > 10 && r.height > 10 &&
               (al === 'abrir' || al === 'expandir' || al === 'open' || al === 'expand' || txt.indexOf('expand_content') >= 0);
    });
    if (expBtn) {
        var re = expBtn.getBoundingClientRect();
        return JSON.stringify({ step: 'CLICK_EXPAND', x: Math.round(re.left + re.width/2), y: Math.round(re.top + re.height/2) });
    }

    var agBtn = document.querySelector('button.agent-mode-chip') ||
        Array.from(document.querySelectorAll('button')).find(b => {
            var al = (b.getAttribute('aria-label') || '');
            var txt = (b.innerText || '');
            var r = b.getBoundingClientRect();
            return r.width > 10 && r.height > 10 && (txt.indexOf('Agente') >= 0 || al.indexOf('Agente') >= 0 || txt.indexOf('Agent') >= 0);
        });
    if (agBtn) {
        var r = agBtn.getBoundingClientRect();
        var isChecked = agBtn.getAttribute('aria-pressed') === 'true' ||
                        ((agBtn.className || '').toString().indexOf('agent-mode-chip-checked') >= 0);
        if (!isChecked) {
            return JSON.stringify({ step: 'CLICK_AGENTE', x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) });
        }
        return JSON.stringify({ step: 'WAIT_EXPAND' });
    }
    return JSON.stringify({ step: 'OPEN' });
})()", ct);

                if (state == null) return;
                string step = Convert.ToString(state.ContainsKey("step") ? state["step"] : "OPEN");
                if (step == "OPEN")
                    return;

                if (step == "CLICK_AGENTE")
                {
                    if (attempt == 0)
                        _log("[Google Flow] Regra 31: Ativando modo Agente na barra de comando...");
                    await _cdp.ClickAtAsync(sess, Convert.ToInt32(state["x"]), Convert.ToInt32(state["y"]), ct);
                    await Task.Delay(850, ct);
                    continue;
                }

                if (step == "CLICK_EXPAND")
                {
                    _log("[Google Flow] Regra 31: Expandindo painel lateral do Agente ('Abrir' / expand_content)...");
                    await _cdp.ClickAtAsync(sess, Convert.ToInt32(state["x"]), Convert.ToInt32(state["y"]), ct);
                    await Task.Delay(1100, ct);
                    continue;
                }

                await Task.Delay(600, ct);
            }
        }

        private async Task ClickNewAgentSessionAsync(string sess, CancellationToken ct)
        {
            await EnsureAgentPanelOpenAsync(sess, ct);

            // Regra 25: NUNCA chamar scrollIntoView() em botões fixos do Google Flow!
            string findNewSessJs = @"
(function(){
    var b = Array.from(document.querySelectorAll('button')).find(x => {
        var al = ((x.getAttribute('aria-label') || '') + ' ' + (x.getAttribute('title') || '') + ' ' + (x.getAttribute('mattooltip') || '')).toLowerCase();
        var txt = (x.innerText || '').trim().toLowerCase();
        var r = x.getBoundingClientRect();
        return r.width > 10 && r.height > 10 &&
               (al.indexOf('nova sess') >= 0 || al.indexOf('new session') >= 0 || al.indexOf('novo chat') >= 0 ||
                txt === 'edit_square' || txt.indexOf('edit_square') >= 0 || txt === 'add_comment');
    });
    if (b) {
        var r = b.getBoundingClientRect();
        return JSON.stringify({ x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2), alreadyEmpty: false });
    }
    var panel = document.querySelector('flow-agent-panel');
    var tb = document.querySelector('[role=""textbox""][contenteditable=""true""], textarea');
    if (tb) {
        var tr = tb.getBoundingClientRect();
        var bubbles = panel ? panel.querySelectorAll('flow-chat-bubble').length : 0;
        if (tr.width > 30 && tr.height > 10 && bubbles === 0) {
            return JSON.stringify({ x: 0, y: 0, alreadyEmpty: true });
        }
    }
    return null;
})()";

            Dictionary<string, object> pt = await _cdp.EvalJsonAsync(sess, findNewSessJs, ct);
            if (pt == null)
            {
                await EnsureAgentPanelOpenAsync(sess, ct);
                await Task.Delay(900, ct);
                pt = await _cdp.EvalJsonAsync(sess, findNewSessJs, ct);
            }

            if (pt == null)
                throw new InvalidOperationException("Botão 'Nova sessão' (edit_square) não encontrado no painel do Agente do Google Flow.");

            if (pt.ContainsKey("alreadyEmpty") && Convert.ToBoolean(pt["alreadyEmpty"]))
            {
                _log("[Google Flow] Painel do Agente já está em uma sessão nova e vazia.");
                return;
            }

            await _cdp.ClickAtAsync(sess, Convert.ToInt32(pt["x"]), Convert.ToInt32(pt["y"]), ct);
        }

        private class PreSessionGridBaseline
        {
            public HashSet<string> PreExistingAsbIds;
            public HashSet<string> PreExistingImageUrls;
            public int PreExistingTopFailedCount;
            public int PreExistingChatBubblesCount;
            public int PreExistingAgentVideoOptionsCount;

            public PreSessionGridBaseline()
            {
                PreExistingAsbIds = new HashSet<string>(StringComparer.Ordinal);
                PreExistingImageUrls = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                PreExistingTopFailedCount = 0;
                PreExistingChatBubblesCount = 0;
                PreExistingAgentVideoOptionsCount = 0;
            }
        }

        private class MountedGridTileState
        {
            public int MountedIndex;
            public string AsbId;
            public bool HasPct;
            public string PctText;
            public bool HasVideo;
            public bool HasMoreBtn;
            public bool HasErr;
            public bool IsMinorErr;
        }

        private class SessionPollSnapshot
        {
            public int TotalSessionCards;
            public int GeneratingCards;
            public int CompletedCards;
            public int FailedCards;
            public int SessionSliceEndIndex;
            public int AgentVideoOptionsCount;
            public int AgentChatBubblesCount;
            public int UnusualActivityCount;
            public bool AgentBusy;
            public bool AgentHasRetryButton;
            public int RetryButtonX;
            public int RetryButtonY;
            public bool AgentHasUnusualActivity;
            public bool AgentBlockedByUnusualActivity;
            public bool PageReloadedDuringWait;
            public string PctSummary;
            public List<int> FailedMountedIndices;
            public List<int> MinorFailedMountedIndices;

            public SessionPollSnapshot()
            {
                PctSummary = "";
                FailedMountedIndices = new List<int>();
                MinorFailedMountedIndices = new List<int>();
            }
        }

        private class SessionCompletedVideoInfo
        {
            public int ChronologicalOrder;
            public string AsbId;
            public string AltPrompt;
        }

        private async Task ScrollAgentPanelToBottomAsync(string sess, CancellationToken ct)
        {
            await _cdp.EvalStringAsync(sess, @"
(function(){
    var panel = document.querySelector('flow-agent-panel');
    if (!panel) return 'NO_PANEL';
    var scroller = panel.querySelector('.scroll-viewport') ||
                   Array.from(panel.querySelectorAll('div')).find(el => el.scrollHeight > el.clientHeight + 40);
    if (scroller) scroller.scrollTop = scroller.scrollHeight;
    return 'OK';
})()", ct);
            await Task.Delay(250, ct);
        }

        private async Task WaitForFlowPageLoadedAsync(string sess, CancellationToken ct)
        {
            DateTime deadline = DateTime.UtcNow.AddSeconds(30);
            while (DateTime.UtcNow < deadline)
            {
                ct.ThrowIfCancellationRequested();
                string st = await _cdp.EvalStringAsync(sess, @"
(function(){
    var hasControls = !!Array.from(document.querySelectorAll('button')).find(b => {
        var al = (b.getAttribute('aria-label') || '');
        var txt = (b.innerText || '');
        var r = b.getBoundingClientRect();
        return r.width > 10 && r.height > 10 &&
               (al.indexOf('Adicionar elementos') >= 0 || al.indexOf('Add elements') >= 0 ||
                b.className.indexOf('add-menu-trigger') >= 0 || txt.indexOf('Agente') >= 0 ||
                al.indexOf('Nova sess') >= 0);
    });
    var hasWorkspace = !!document.querySelector('cdk-virtual-scroll-viewport, flow-agent-panel, div[role=""textbox""]');
    return (hasControls && hasWorkspace) ? 'READY' : 'WAIT';
})()", ct);

                if (st == "READY")
                {
                    await Task.Delay(4000, ct);
                    return;
                }
                await Task.Delay(600, ct);
            }
            await Task.Delay(3500, ct);
        }

        private async Task WaitForEmptyAgentSessionAsync(string sess, CancellationToken ct)
        {
            for (int i = 0; i < 10; i++)
            {
                await Task.Delay(i == 0 ? 1200 : 450, ct);
                string countStr = await _cdp.EvalStringAsync(sess, @"
(function(){
    var vids = document.querySelectorAll('flow-agent-panel flow-a2ui-video-option').length;
    var bubbles = document.querySelectorAll('flow-agent-panel flow-chat-bubble').length;
    return String(vids + bubbles);
})()", ct);
                int n;
                if (int.TryParse(countStr, out n) && n == 0)
                    return;
            }
        }

        private async Task WaitForOverlayImagesLibraryLoadedAsync(string sess, CancellationToken ct)
        {
            DateTime deadline = DateTime.UtcNow.AddSeconds(22);
            int stableReadyCount = 0;

            while (DateTime.UtcNow < deadline)
            {
                ct.ThrowIfCancellationRequested();
                string st = await _cdp.EvalStringAsync(sess, @"
(function(){
    var hasSearch = !!Array.from(document.querySelectorAll('.cdk-overlay-container input.search-input'))
        .find(el => el.getBoundingClientRect().width > 10);
    var hasUploadBtn = !!Array.from(document.querySelectorAll('.cdk-overlay-container .sidebar-upload-btn, .cdk-overlay-container button'))
        .find(el => {
            var t = (el.innerText || '') + ' ' + (el.getAttribute('aria-label') || '');
            return el.getBoundingClientRect().width > 10 &&
                   (el.className.indexOf('sidebar-upload-btn') >= 0 || t.indexOf('Enviar m') >= 0 || t.indexOf('Upload') >= 0);
        });
    if (!hasSearch && !hasUploadBtn) return 'WAIT';

    var spinners = Array.from(document.querySelectorAll(
        '.cdk-overlay-container mat-progress-spinner, .cdk-overlay-container mat-spinner, .cdk-overlay-container [role=""progressbar""], .cdk-overlay-container [class*=""uploading""]'
    )).filter(el => el.getBoundingClientRect().width > 4);
    if (spinners.length > 0) return 'SPINNING';

    var thumbs = Array.from(document.querySelectorAll('.cdk-overlay-container img.asset-thumbnail-image'))
        .filter(im => im.getBoundingClientRect().width > 10);
    if (thumbs.length > 0) {
        var loadingCount = thumbs.filter(im => !im.complete || (im.naturalWidth || 0) <= 0).length;
        if (loadingCount > 0) return 'LOADING_THUMBS';
    }
    return 'READY';
})()", ct);

                if (st == "READY")
                {
                    stableReadyCount++;
                    if (stableReadyCount >= 2)
                    {
                        await Task.Delay(1200, ct);
                        return;
                    }
                }
                else
                {
                    stableReadyCount = 0;
                }

                await Task.Delay(600, ct);
            }
            await Task.Delay(1200, ct);
        }

        private async Task WaitForAttachedPromptChipsImagesLoadedAsync(string sess, CancellationToken ct)
        {
            DateTime deadline = DateTime.UtcNow.AddSeconds(20);
            while (DateTime.UtcNow < deadline)
            {
                ct.ThrowIfCancellationRequested();
                string st = await _cdp.EvalStringAsync(sess, @"
(function(){
    var chips = Array.from(document.querySelectorAll('flow-image-ingredient-chip'))
        .filter(c => {
            if (c.closest('flow-chat-bubble')) return false;
            var r = c.getBoundingClientRect();
            return r.width > 10 && r.top > 100;
        });
    if (chips.length === 0) return 'EMPTY';
    var pending = chips.filter(c => {
        var im = c.querySelector('img');
        if (!im) return false;
        return !im.complete || (im.naturalWidth || 0) <= 0;
    }).length;
    return pending === 0 ? 'READY' : 'LOADING';
})()", ct);

                if (st == "READY" || st == "EMPTY")
                {
                    await Task.Delay(1500, ct);
                    return;
                }
                await Task.Delay(500, ct);
            }
            await Task.Delay(1500, ct);
        }

        private async Task<PreSessionGridBaseline> CapturePreSessionBaselineAsync(string sess, CancellationToken ct)
        {
            PreSessionGridBaseline baseline = new PreSessionGridBaseline();

            // 1. Vai para o topo do grid virtualizado (scrollTop = 0) e captura os primeiros ~36 cards preexistentes
            await _cdp.EvalStringAsync(sess, @"
(function(){
    var vp = document.querySelector('cdk-virtual-scroll-viewport.tiles-container') || document.querySelector('cdk-virtual-scroll-viewport');
    if (vp) vp.scrollTop = 0;
    return 'OK';
})()", ct);
            await Task.Delay(450, ct);

            Dictionary<string, object> topSnap = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var tiles = Array.from(document.querySelectorAll('flow-video-tile, flow-image-tile, flow-asset-tile, [data-asb-id]'));
    var asbs = [];
    var urls = [];
    var topFailedBeforeFirstAsb = 0;
    var seenFirstAsb = false;

    tiles.forEach(t => {
        var host = t.closest('flow-video-tile, flow-image-tile, flow-asset-tile') || t;
        var vid = host.querySelector('video');
        var img = host.querySelector('img.thumbnail') || host.querySelector('img');
        var imgSrc = img ? (img.currentSrc || img.src || img.getAttribute('src') || '') : '';
        if (imgSrc.length > 12) urls.push(imgSrc);
        var mediaUrl = imgSrc + ' ' +
                       (vid ? ((vid.getAttribute('poster') || '') + ' ' + (vid.getAttribute('src') || '')) : '');
        var allMatches = mediaUrl.match(/\/asb\/([A-Za-z0-9_\-]{25,80})/g) || [];
        var dataAsb = host.getAttribute('data-asb-id') || '';
        if (dataAsb) asbs.push(dataAsb);
        var hasMoreBtn = !!host.querySelector('button[aria-label*=""Mais op""], button[aria-label*=""More""]');
        var txt = (host.innerText || '');
        var hasErr = !vid && !hasMoreBtn && allMatches.length === 0 && !imgSrc &&
                     /violar|pol[ií]ticas|falha|erro|n[aã]o foi poss[ií]vel|violate|failed/i.test(txt);

        if (allMatches.length > 0 || imgSrc.length > 12) {
            seenFirstAsb = true;
            allMatches.forEach(tok => asbs.push(tok.replace('/asb/', '')));
        } else if (!seenFirstAsb && hasErr) {
            topFailedBeforeFirstAsb++;
        }
    });

    var panel = document.querySelector('flow-agent-panel');
    var preBubbles = 0;
    var preVidOpts = 0;
    if (panel) {
        preBubbles = panel.querySelectorAll('flow-chat-bubble').length;
        preVidOpts = panel.querySelectorAll('flow-a2ui-video-option').length;
        Array.from(panel.querySelectorAll('img, video')).forEach(el => {
            var s = (el.currentSrc || el.src || el.getAttribute('src') || '') + ' ' + (el.getAttribute('poster') || '');
            var trimmedSrc = (el.currentSrc || el.src || el.getAttribute('src') || '').trim();
            if (trimmedSrc.length > 12) urls.push(trimmedSrc);
            var m = s.match(/\/asb\/([A-Za-z0-9_\-]{25,80})/g) || [];
            m.forEach(tok => asbs.push(tok.replace('/asb/', '')));
        });
    }

    return JSON.stringify({ asbs: asbs, urls: urls, topFailed: topFailedBeforeFirstAsb, preBubbles: preBubbles, preVidOpts: preVidOpts });
})()", ct);

            if (topSnap != null)
            {
                if (topSnap.ContainsKey("topFailed"))
                    baseline.PreExistingTopFailedCount = Convert.ToInt32(topSnap["topFailed"]);
                if (topSnap.ContainsKey("preBubbles"))
                    baseline.PreExistingChatBubblesCount = Convert.ToInt32(topSnap["preBubbles"]);
                if (topSnap.ContainsKey("preVidOpts"))
                    baseline.PreExistingAgentVideoOptionsCount = Convert.ToInt32(topSnap["preVidOpts"]);

                IEnumerable asbList = topSnap.ContainsKey("asbs") ? topSnap["asbs"] as IEnumerable : null;
                if (asbList != null)
                {
                    foreach (object item in asbList)
                    {
                        string id = Convert.ToString(item ?? "").Trim();
                        if (!string.IsNullOrEmpty(id))
                            baseline.PreExistingAsbIds.Add(id);
                    }
                }

                IEnumerable urlList = topSnap.ContainsKey("urls") ? topSnap["urls"] as IEnumerable : null;
                if (urlList != null)
                {
                    foreach (object item in urlList)
                    {
                        string u = Convert.ToString(item ?? "").Trim();
                        if (!string.IsNullOrEmpty(u))
                            baseline.PreExistingImageUrls.Add(u);
                    }
                }
            }

            // 2. Captura também uma segunda página (+550px) de âncoras preexistentes e volta para scrollTop = 0
            string page2Raw = await _cdp.EvalStringAsync(sess, @"
(function(){
    var vp = document.querySelector('cdk-virtual-scroll-viewport.tiles-container') || document.querySelector('cdk-virtual-scroll-viewport');
    if (!vp) return '';
    vp.scrollTop = 550;
    return 'SCROLLED';
})()", ct);

            if (page2Raw == "SCROLLED")
            {
                await Task.Delay(350, ct);
                Dictionary<string, object> p2Snap = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var tiles = Array.from(document.querySelectorAll('flow-video-tile, flow-image-tile, flow-asset-tile, [data-asb-id]'));
    var asbs = [];
    var urls = [];
    tiles.forEach(t => {
        var host = t.closest('flow-video-tile, flow-image-tile, flow-asset-tile') || t;
        var vid = host.querySelector('video');
        var img = host.querySelector('img.thumbnail') || host.querySelector('img');
        var imgSrc = img ? (img.currentSrc || img.src || img.getAttribute('src') || '') : '';
        if (imgSrc.length > 12) urls.push(imgSrc);
        var mediaUrl = imgSrc + ' ' +
                       (vid ? ((vid.getAttribute('poster') || '') + ' ' + (vid.getAttribute('src') || '')) : '');
        var allMatches = mediaUrl.match(/\/asb\/([A-Za-z0-9_\-]{25,80})/g) || [];
        allMatches.forEach(tok => asbs.push(tok.replace('/asb/', '')));
        var dataAsb = host.getAttribute('data-asb-id') || '';
        if (dataAsb) asbs.push(dataAsb);
    });
    var vp = document.querySelector('cdk-virtual-scroll-viewport.tiles-container') || document.querySelector('cdk-virtual-scroll-viewport');
    if (vp) vp.scrollTop = 0;
    return JSON.stringify({ asbs: asbs, urls: urls });
})()", ct);

                if (p2Snap != null)
                {
                    if (p2Snap.ContainsKey("asbs"))
                    {
                        IEnumerable p2List = p2Snap["asbs"] as IEnumerable;
                        if (p2List != null)
                        {
                            foreach (object item in p2List)
                            {
                                string id = Convert.ToString(item ?? "").Trim();
                                if (!string.IsNullOrEmpty(id))
                                    baseline.PreExistingAsbIds.Add(id);
                            }
                        }
                    }
                    if (p2Snap.ContainsKey("urls"))
                    {
                        IEnumerable p2Urls = p2Snap["urls"] as IEnumerable;
                        if (p2Urls != null)
                        {
                            foreach (object item in p2Urls)
                            {
                                string u = Convert.ToString(item ?? "").Trim();
                                if (!string.IsNullOrEmpty(u))
                                    baseline.PreExistingImageUrls.Add(u);
                            }
                        }
                    }
                }
                await Task.Delay(250, ct);
            }

            return baseline;
        }


        private async Task<int> CountAttachedPromptChipsAsync(string sess, CancellationToken ct)
        {
            string s = await _cdp.EvalStringAsync(sess, @"
(function(){
    var panel = document.querySelector('flow-agent-panel');
    var hasOpenAgentBox = !!(panel && Array.from(panel.querySelectorAll('div[role=""textbox""], [contenteditable=""true""], textarea')).find(el => el.getBoundingClientRect().width > 80));
    var root = hasOpenAgentBox ? panel : document;
    return Array.from(root.querySelectorAll('flow-image-ingredient-chip button.chip-container'))
        .filter(b => {
            if (b.closest('flow-chat-bubble')) return false;
            var r = b.getBoundingClientRect();
            return r.width > 10 && r.top > 100;
        }).length;
})()", ct);
            int n;
            return int.TryParse(s, out n) ? n : 0;
        }

        private async Task ClearAttachedPromptChipsAsync(string sess, CancellationToken ct)
        {
            int initialCount = await CountAttachedPromptChipsAsync(sess, ct);
            if (initialCount <= 0)
                return;

            await ToggleAddElementsMenuAsync(sess, false, ct);

            for (int i = 0; i < 16; i++)
            {
                int beforeCount = await CountAttachedPromptChipsAsync(sess, ct);
                if (beforeCount <= 0) break;

                Dictionary<string, object> hoverPt = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var panel = document.querySelector('flow-agent-panel');
    var hasOpenAgentBox = !!(panel && Array.from(panel.querySelectorAll('div[role=""textbox""], [contenteditable=""true""], textarea')).find(el => el.getBoundingClientRect().width > 80));
    var root = hasOpenAgentBox ? panel : document;
    var hosts = Array.from(root.querySelectorAll('flow-image-ingredient-chip'))
        .filter(h => {
            if (h.closest('flow-chat-bubble')) return false;
            var r = h.getBoundingClientRect();
            return r.width > 10 && r.top > 100;
        });
    if (hosts.length === 0) return null;
    var hr = hosts[0].getBoundingClientRect();
    return JSON.stringify({ x: Math.round(hr.left + hr.width/2), y: Math.round(hr.top + hr.height/2) });
})()", ct);

                if (hoverPt == null) break;
                await _cdp.HoverAsync(sess, Convert.ToInt32(hoverPt["x"]), Convert.ToInt32(hoverPt["y"]), ct);
                await Task.Delay(220, ct);

                Dictionary<string, object> remPt = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var panel = document.querySelector('flow-agent-panel');
    var hasOpenAgentBox = !!(panel && Array.from(panel.querySelectorAll('div[role=""textbox""], [contenteditable=""true""], textarea')).find(el => el.getBoundingClientRect().width > 80));
    var root = hasOpenAgentBox ? panel : document;
    var hosts = Array.from(root.querySelectorAll('flow-image-ingredient-chip'))
        .filter(h => !h.closest('flow-chat-bubble') && h.getBoundingClientRect().width > 10 && h.getBoundingClientRect().top > 100);
    if (hosts.length === 0) return null;
    var host = hosts[0];
    var remBtn = Array.from(host.querySelectorAll('button')).find(b => {
        if (b.classList.contains('chip-container')) return false;
        var al = ((b.getAttribute('aria-label') || '') + ' ' + (b.innerText || '')).toLowerCase();
        var r = b.getBoundingClientRect();
        return r.width > 6 && r.height > 6 &&
               (al.indexOf('remov') >= 0 || al.indexOf('exclu') >= 0 || al.indexOf('delet') >= 0 || al.indexOf('close') >= 0 || al.indexOf('cancel') >= 0);
    });
    if (!remBtn) return null;
    var r2 = remBtn.getBoundingClientRect();
    return JSON.stringify({ x: Math.round(r2.left + r2.width/2), y: Math.round(r2.top + r2.height/2) });
})()", ct);

                if (remPt == null) break;
                await _cdp.ClickAtAsync(sess, Convert.ToInt32(remPt["x"]), Convert.ToInt32(remPt["y"]), ct);
                await Task.Delay(260, ct);

                int afterCount = await CountAttachedPromptChipsAsync(sess, ct);
                if (afterCount >= beforeCount)
                    break;
            }
        }

        private async Task InsertTextIntoFlowTextboxAsync(string sess, string text, bool clearExistingText, CancellationToken ct)
        {
            Dictionary<string, object> boxInfo = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var agentBoxes = Array.from(document.querySelectorAll('flow-agent-panel div[role=""textbox""], flow-agent-panel [contenteditable=""true""]'))
        .filter(el => el.getBoundingClientRect().width > 80);
    var allBoxes = Array.from(document.querySelectorAll('div[role=""textbox""], [contenteditable=""true""]'))
        .filter(el => el.getBoundingClientRect().width > 80);
    var boxes = agentBoxes.length > 0 ? agentBoxes : allBoxes;
    if (boxes.length === 0) return null;
    var tb = boxes[boxes.length - 1];
    var r = tb.getBoundingClientRect();
    var curVal = (tb.innerText || '').trim();
    return JSON.stringify({
        x: Math.round(r.left + Math.min(48, r.width / 3)),
        y: Math.round(r.top + r.height / 2),
        curLen: curVal.length
    });
})()", ct);

            if (boxInfo == null)
                throw new InvalidOperationException("Caixa de comando 'O que você quer criar?' não encontrada no Google Flow.");

            int boxX = Convert.ToInt32(boxInfo["x"]);
            int boxY = Convert.ToInt32(boxInfo["y"]);
            int curLen = boxInfo.ContainsKey("curLen") ? Convert.ToInt32(boxInfo["curLen"]) : 0;

            string normalized = text ?? "";
            if (!clearExistingText && normalized.Length == 0)
                return;
            if (clearExistingText && normalized.Length == 0 && curLen == 0)
                return;

            // Clique real de mouse para posicionar o cursor com foco legítimo antes do execCommand('insertText') (mesmo mecanismo da versão 09/11)
            await _cdp.ClickAtAsync(sess, boxX, boxY, ct);
            await Task.Delay(140, ct);

            string b64 = Convert.ToBase64String(Encoding.UTF8.GetBytes(normalized));
            string clearFlag = clearExistingText ? "true" : "false";

            string len = await _cdp.EvalStringAsync(sess, string.Format(@"
(function(){{
    var bytes = Uint8Array.from(atob('{0}'), c => c.charCodeAt(0));
    var text = new TextDecoder('utf-8').decode(bytes);
    var agentBoxes = Array.from(document.querySelectorAll('flow-agent-panel div[role=""textbox""], flow-agent-panel [contenteditable=""true""]'))
        .filter(el => el.getBoundingClientRect().width > 80);
    var allBoxes = Array.from(document.querySelectorAll('div[role=""textbox""], [contenteditable=""true""]'))
        .filter(el => el.getBoundingClientRect().width > 80);
    var boxes = agentBoxes.length > 0 ? agentBoxes : allBoxes;
    var tb = boxes[boxes.length - 1];
    if (!tb) return '-1';
    if ({1} && text.length === 0) {{
        for (var k = 0; k < allBoxes.length; k++) {{
            if (((allBoxes[k].innerText || '').trim()).length > 0) {{
                allBoxes[k].focus();
                document.execCommand('selectAll', false, null);
                document.execCommand('insertText', false, '');
            }}
        }}
        return String((tb.innerText || '').trim().length);
    }}
    tb.focus();
    if ({1}) {{
        document.execCommand('selectAll', false, null);
    }}
    document.execCommand('insertText', false, text);
    return String((tb.innerText || '').length);
}})()", b64, clearFlag), ct);

            if (len == "-1")
                throw new InvalidOperationException("Caixa de comando 'O que você quer criar?' não encontrada no Google Flow.");
        }

        private async Task<string> ReadCurrentFlowTextboxAsync(string sess, CancellationToken ct)
        {
            string txt = await _cdp.EvalStringAsync(sess, @"
(function(){
    var agentBoxes = Array.from(document.querySelectorAll('flow-agent-panel div[role=""textbox""], flow-agent-panel [contenteditable=""true""]'))
        .filter(el => el.getBoundingClientRect().width > 80);
    var allBoxes = Array.from(document.querySelectorAll('div[role=""textbox""], [contenteditable=""true""]'))
        .filter(el => el.getBoundingClientRect().width > 80);
    for (var i = agentBoxes.length - 1; i >= 0; i--) {
        var t = (agentBoxes[i].innerText || '').trim();
        if (t.length > 0) return t;
    }
    for (var j = allBoxes.length - 1; j >= 0; j--) {
        var t2 = (allBoxes[j].innerText || '').trim();
        if (t2.length > 0) return t2;
    }
    return '';
})()", ct);
            return txt ?? "";
        }

        private async Task ClickStartGenerationAsync(string sess, CancellationToken ct)
        {
            // Regra 25: Exatamente o envio único e limpo via CDP ClickAtAsync da versão estável (sem PressEnter ou eventos sintéticos)
            Dictionary<string, object> sendPt = null;
            for (int waitBtn = 0; waitBtn < 6; waitBtn++)
            {
                sendPt = await _cdp.EvalJsonAsync(sess, @"
(function(){
    function findSend(root) {
        return Array.from(root.querySelectorAll('button')).filter(x => {
            var txt = (x.innerText || '');
            var al = (x.getAttribute('aria-label') || '');
            var r = x.getBoundingClientRect();
            return r.width > 10 && r.height > 10 && !x.disabled && x.getAttribute('aria-disabled') !== 'true' &&
                   (txt.indexOf('arrow_forward') >= 0 || txt.indexOf('send') >= 0 || al.indexOf('Iniciar') >= 0 || al.indexOf('Enviar') >= 0);
        });
    }
    var panel = document.querySelector('flow-agent-panel');
    var btns = panel ? findSend(panel) : [];
    if (btns.length === 0) btns = findSend(document);
    if (btns.length === 0) return null;
    var b = btns[btns.length - 1];
    var r = b.getBoundingClientRect();
    return JSON.stringify({ x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) });
})()", ct);

                if (sendPt != null)
                    break;
                await Task.Delay(300, ct);
            }

            if (sendPt == null)
                throw new InvalidOperationException("Botão 'Iniciar geração' (→) não encontrado ou desabilitado no Google Flow.");

            await _cdp.ClickAtAsync(sess, Convert.ToInt32(sendPt["x"]), Convert.ToInt32(sendPt["y"]), ct);
        }

    }
}
