using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Microsoft.Win32;

namespace FluxoVideoStudio
{
    public partial class MainWindow : Window
    {
        // =================================================================================================
        // GERENCIADOR DE TAKES & FIGURINOS POR OCASIÃO (ITENS 1 E 2)
        // =================================================================================================

        private void RefreshTakesManagerList()
        {
            if (_pnlTakesList == null) return;
            _pnlTakesList.Children.Clear();
            _takeSelectionChecks.Clear();

            if (_selectedEpisode == null || _selectedEpisode.FlowTakes == null || _selectedEpisode.FlowTakes.Count == 0)
            {
                if (_lblTakesManagerSummary != null)
                    _lblTakesManagerSummary.Text = "Selecione um episódio com takes decupados para gerenciar takes e figurinos.";
                return;
            }

            int readyCount = 0;
            foreach (FlowTakeSpec take in _selectedEpisode.FlowTakes.OrderBy(t => t.TakeNumber))
            {
                string mp4Path = Path.Combine(_selectedEpisode.TakesDir, string.Format("Take_{0:00}.mp4", take.TakeNumber));
                bool exists = File.Exists(mp4Path) && new FileInfo(mp4Path).Length >= 50 * 1024;
                if (exists) readyCount++;

                _pnlTakesList.Children.Add(BuildTakeManagerCard(take, mp4Path, exists));
            }

            if (_lblTakesManagerSummary != null)
            {
                _lblTakesManagerSummary.Text = string.Format(
                    "{0} ({1}): {2}/{3} takes prontos em 'takes\\'. Marque ou escolha qualquer take abaixo para regerar:",
                    _selectedEpisode.StoryName, _selectedEpisode.EpisodeName, readyCount, _selectedEpisode.FlowTakes.Count);
            }
        }

        private UIElement BuildTakeManagerCard(FlowTakeSpec take, string mp4Path, bool exists)
        {
            Border card = new Border
            {
                Background = BgCard,
                BorderBrush = exists ? BrushFromHex("#065F46") : BorderSubtle,
                BorderThickness = new Thickness(1.5),
                CornerRadius = new CornerRadius(8),
                Padding = new Thickness(12, 10, 12, 10),
                Margin = new Thickness(0, 0, 0, 8)
            };

            StackPanel root = new StackPanel();

            // Linha 1: Checkbox + Take_XX + Badge Status + Cenário + Botões de Ação Rápida
            DockPanel headerRow = new DockPanel { Margin = new Thickness(0, 0, 0, 6) };

            StackPanel leftInfo = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };
            CheckBox chkTake = new CheckBox
            {
                IsChecked = !exists,
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(0, 0, 8, 0)
            };
            _takeSelectionChecks[take.TakeNumber] = chkTake;
            leftInfo.Children.Add(chkTake);

            leftInfo.Children.Add(new TextBlock
            {
                Text = string.Format("TAKE {0:00}", take.TakeNumber),
                FontSize = 14,
                FontWeight = FontWeights.Bold,
                Foreground = TextPrimary,
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(0, 0, 10, 0)
            });

            Border statusBadge = new Border
            {
                Background = exists ? BrushFromHex("#064E3B") : BrushFromHex("#451A03"),
                BorderBrush = exists ? AccentGreen : AccentAmber,
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(5),
                Padding = new Thickness(7, 2, 7, 2),
                Margin = new Thickness(0, 0, 10, 0)
            };
            double mb = exists ? (new FileInfo(mp4Path).Length / (1024.0 * 1024.0)) : 0.0;
            statusBadge.Child = new TextBlock
            {
                Text = exists ? string.Format("✔ PRONTO ({0:0.1} MB)", mb) : "⏳ PENDENTE",
                FontSize = 10.5,
                FontWeight = FontWeights.Bold,
                Foreground = exists ? BrushFromHex("#A7F3D0") : BrushFromHex("#FDE68A")
            };
            leftInfo.Children.Add(statusBadge);

            if (!string.IsNullOrEmpty(take.ScenarioName))
            {
                leftInfo.Children.Add(new TextBlock
                {
                    Text = "📍 Cenário: " + take.ScenarioName,
                    FontSize = 12,
                    Foreground = TextSecondary,
                    VerticalAlignment = VerticalAlignment.Center,
                    Margin = new Thickness(0, 0, 12, 0)
                });
            }

            headerRow.Children.Add(leftInfo);

            // Botões de Ação Individual por Take
            StackPanel actionBtns = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };

            if (exists)
            {
                Button btnWatch = CreateStyledButton("▶ Assistir", BgPanel, TextPrimary, new Thickness(9, 4, 9, 4));
                btnWatch.FontSize = 11;
                btnWatch.Margin = new Thickness(0, 0, 6, 0);
                btnWatch.Click += (s, e) =>
                {
                    try { Process.Start(new ProcessStartInfo(mp4Path) { UseShellExecute = true }); } catch { }
                };
                actionBtns.Children.Add(btnWatch);
            }

            int capturedTakeNum = take.TakeNumber;

            Button btnRegenFlow = CreateStyledButton("🌊 Regerar no Flow", AccentBlue, Brushes.White, new Thickness(10, 4, 10, 4));
            btnRegenFlow.FontSize = 11;
            btnRegenFlow.FontWeight = FontWeights.SemiBold;
            btnRegenFlow.Margin = new Thickness(0, 0, 6, 0);
            btnRegenFlow.Click += async (s, e) => await RegenerateSingleTakeAsync(capturedTakeNum, false);
            actionBtns.Children.Add(btnRegenFlow);

            Button btnRegenGrok = CreateStyledButton("🚀 Regerar no Grok Vídeo (🪄)", AccentPrimary, Brushes.White, new Thickness(10, 4, 10, 4));
            btnRegenGrok.FontSize = 11;
            btnRegenGrok.FontWeight = FontWeights.SemiBold;
            btnRegenGrok.Click += async (s, e) => await RegenerateSingleTakeAsync(capturedTakeNum, true);
            actionBtns.Children.Add(btnRegenGrok);

            DockPanel.SetDock(actionBtns, Dock.Right);
            headerRow.Children.Add(actionBtns);
            root.Children.Add(headerRow);

            // Linha 2: Ingredientes vinculados pelo roteiro/pré-definição (PASSO 1 e PASSO 3)
            if (take.Ingredients != null && take.Ingredients.Count > 0)
            {
                root.Children.Add(new TextBlock
                {
                    Text = "📎 Ingredientes da Cena (definidos no Passo 1/3): " + string.Join(", ", take.Ingredients),
                    FontSize = 11,
                    Foreground = BrushFromHex("#93C5FD"),
                    Margin = new Thickness(0, 0, 0, 5)
                });
            }

            // Linha 3: Prompt editável do Take
            TextBox txtTakePrompt = new TextBox
            {
                Text = take.RawPromptBody ?? "",
                Background = BgInput,
                Foreground = TextPrimary,
                BorderBrush = BorderSubtle,
                BorderThickness = new Thickness(1),
                FontFamily = new FontFamily("Consolas"),
                FontSize = 11,
                TextWrapping = TextWrapping.Wrap,
                AcceptsReturn = true,
                MaxHeight = 76,
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                Padding = new Thickness(6, 4, 6, 4)
            };
            FlowTakeSpec capturedForPrompt = take;
            txtTakePrompt.LostFocus += (s, e) =>
            {
                if (_selectedEpisode == null) return;
                string newTxt = (txtTakePrompt.Text ?? "").Trim();
                if (!string.Equals(newTxt, capturedForPrompt.RawPromptBody ?? "", StringComparison.Ordinal))
                {
                    capturedForPrompt.RawPromptBody = newTxt;
                    EpisodeParser.SaveEpisodeCustomTakesConfig(_selectedEpisode);
                }
            };
            root.Children.Add(txtTakePrompt);

            card.Child = root;
            return card;
        }

        private async Task RegenerateSingleTakeAsync(int takeNumber, bool forceGrokVideo)
        {
            if (_selectedEpisode == null || _selectedEpisode.FlowTakes == null) return;
            FlowTakeSpec take = _selectedEpisode.FlowTakes.FirstOrDefault(t => t.TakeNumber == takeNumber);
            if (take == null) return;

            await RegenerateSpecificTakesCoreAsync(new List<int> { takeNumber }, forceGrokVideo);
        }

        private async Task RegenerateCheckedTakesAsync(bool forceGrokVideo)
        {
            List<int> selectedNums = _takeSelectionChecks
                .Where(kv => kv.Value.IsChecked == true)
                .Select(kv => kv.Key)
                .OrderBy(n => n)
                .ToList();

            if (selectedNums.Count == 0)
            {
                MessageBox.Show("Marque pelo menos 1 Take na lista para regerar.", "Regerar Takes", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            await RegenerateSpecificTakesCoreAsync(selectedNums, forceGrokVideo);
        }

        private async Task RegenerateSpecificTakesCoreAsync(List<int> takeNumbers, bool forceGrokVideo)
        {
            if (_isRunning || _selectedEpisode == null || takeNumbers == null || takeNumbers.Count == 0)
                return;

            SyncSettingsFromUi();
            EpisodeParser.SaveEpisodeCustomTakesConfig(_selectedEpisode);
            SetRunningUiState(true);
            _runCts = new CancellationTokenSource();

            string labels = string.Join(", ", takeNumbers.Select(n => string.Format("Take_{0:00}", n)));
            string engineName = forceGrokVideo ? "Grok Vídeo (com varinha mágica 🪄)" : "Google Flow";

            EpisodeWorkItem ep = _selectedEpisode;
            CancellationToken token = _runCts.Token;

            try
            {
                SetStageBadge(_badgeFlow, StageState.Running, "REGERANDO...");
                UpdateProgress(35, string.Format("Regerando {0} em {1}...", labels, engineName));
                AppendLog(string.Format("===== Iniciando regeração de {0} via {1} =====", labels, engineName));

                await Task.Run(async () =>
                {
                    await _cdp.EnsureConnectedAsync(token);
                    await _flow.RegenerateSelectedTakesAsync(ep, takeNumbers, forceGrokVideo, token);
                });

                SetStageBadge(_badgeFlow, StageState.Success, "CONCLUÍDO");
                UpdateProgress(100, string.Format("Regeração concluída: {0}!", labels));
            }
            catch (OperationCanceledException)
            {
                UpdateProgress(0, "Regeração cancelada pelo usuário.");
                AppendLog("[Sistema] Regeração de take(s) cancelada.");
            }
            catch (Exception ex)
            {
                SetStageBadge(_badgeFlow, StageState.Failed, "ERRO");
                UpdateProgress(0, "Erro ao regerar take(s): " + ex.Message);
                AppendLog("[ERRO] " + ex.ToString());
                MessageBox.Show(ex.Message, "Erro ao Regerar Take", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                if (_selectedStory != null) RebuildEpisodeButtons(_selectedStory);
                RefreshAssetsGallery(null);
                RefreshTakesManagerList();
                SetRunningUiState(false);
            }
        }


        // =================================================================================================
        // ITEM 1: CRIAR NOVA ROUPA PARA PERSONAGEM POR OCASIÃO (MANTENDO MESMO ROSTO NO GROK)
        // =================================================================================================

        private void ShowCreateCharacterOutfitDialog(string preselectedBaseChar)
        {
            if (_selectedEpisode == null)
            {
                MessageBox.Show("Selecione primeiro uma história e episódio na coluna esquerda.", "Criar Roupa de Personagem", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            List<string> charFiles = new List<string>();
            if (Directory.Exists(_selectedEpisode.AssetsDir))
            {
                charFiles = Directory.GetFiles(_selectedEpisode.AssetsDir)
                    .Select(f => Path.GetFileName(f))
                    .Where(fn => Regex.IsMatch(Path.GetExtension(fn), @"^\.(jpg|jpeg|png)$", RegexOptions.IgnoreCase) &&
                                 !EpisodeParser.IsScenarioAssetName(fn) &&
                                 fn.IndexOf("__Roupa_", StringComparison.OrdinalIgnoreCase) < 0)
                    .OrderBy(fn => fn)
                    .ToList();
            }

            if (charFiles.Count == 0)
            {
                MessageBox.Show("Nenhuma imagem base de personagem (.jpg) foi encontrada na pasta assets\\ deste episódio. Gere ou importe os personagens base primeiro.",
                    "Criar Roupa de Personagem", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            Window dlg = new Window
            {
                Title = "👔 Criar Roupa Padrão por Ocasião (Mantendo 100% o Mesmo Rosto do Personagem)",
                Width = 640,
                Height = 450,
                WindowStartupLocation = WindowStartupLocation.CenterOwner,
                Owner = this,
                Background = BgPanel,
                Foreground = TextPrimary,
                ResizeMode = ResizeMode.NoResize
            };

            StackPanel sp = new StackPanel { Margin = new Thickness(18) };

            sp.Children.Add(new TextBlock
            {
                Text = "1. Escolha o Personagem Base (a imagem original será enviada como referência ao Grok):",
                FontWeight = FontWeights.Bold,
                FontSize = 12.5,
                Foreground = TextPrimary,
                Margin = new Thickness(0, 0, 0, 5)
            });

            ComboBox cmbChar = new ComboBox { FontSize = 12, Padding = new Thickness(8, 5, 8, 5), Margin = new Thickness(0, 0, 0, 12) };
            int selIdx = 0;
            for (int i = 0; i < charFiles.Count; i++)
            {
                cmbChar.Items.Add(charFiles[i]);
                if (!string.IsNullOrEmpty(preselectedBaseChar) &&
                    string.Equals(charFiles[i], preselectedBaseChar, StringComparison.OrdinalIgnoreCase))
                {
                    selIdx = i;
                }
            }
            cmbChar.SelectedIndex = selIdx;
            sp.Children.Add(cmbChar);

            sp.Children.Add(new TextBlock
            {
                Text = "2. Categoria de Roupa Padrão (gerada e selecionada de acordo com o texto):",
                FontWeight = FontWeights.Bold,
                FontSize = 12.5,
                Foreground = TextPrimary,
                Margin = new Thickness(0, 0, 0, 4)
            });

            ComboBox cmbCategory = new ComboBox { FontSize = 12, Padding = new Thickness(8, 5, 8, 5), Margin = new Thickness(0, 0, 0, 12) };
            cmbCategory.Items.Add(new ComboBoxItem { Content = "👔 Roupa de Trabalho (Obra / Escritório / Serviço)", Tag = "Trabalho" });
            cmbCategory.Items.Add(new ComboBoxItem { Content = "🏠 Roupa Simples (Casa / Dia a Dia / Pós-Formatura)", Tag = "Simples" });
            cmbCategory.Items.Add(new ComboBoxItem { Content = "🌿 Roupa de Lazer (Passeio / Encontro / Fim de Semana)", Tag = "Lazer" });
            cmbCategory.Items.Add(new ComboBoxItem { Content = "🎩 Roupa Formal (Formatura / Casamento / Festa / Gala)", Tag = "Formal" });
            cmbCategory.SelectedIndex = 0;
            sp.Children.Add(cmbCategory);

            sp.Children.Add(new TextBlock
            {
                Text = "3. Descrição da Roupa (gerada automaticamente de acordo com o personagem e o texto):",
                FontWeight = FontWeights.Bold,
                FontSize = 12.5,
                Foreground = TextPrimary,
                Margin = new Thickness(0, 0, 0, 5)
            });

            TextBox txtOutfitDesc = new TextBox
            {
                Text = "",
                Background = BgInput,
                Foreground = TextPrimary,
                BorderBrush = BorderSubtle,
                BorderThickness = new Thickness(1),
                FontSize = 12,
                TextWrapping = TextWrapping.Wrap,
                AcceptsReturn = true,
                Height = 82,
                Padding = new Thickness(8, 5, 8, 5),
                Margin = new Thickness(0, 0, 0, 10)
            };
            sp.Children.Add(txtOutfitDesc);

            Action refreshPresetDesc = () =>
            {
                string chosenChar = Convert.ToString(cmbChar.SelectedItem ?? "");
                ComboBoxItem catItem = cmbCategory.SelectedItem as ComboBoxItem;
                string catKey = catItem != null ? Convert.ToString(catItem.Tag ?? "Trabalho") : "Trabalho";
                txtOutfitDesc.Text = EpisodeParser.GetStandardWardrobePresetDescription(_selectedEpisode, chosenChar, catKey);
            };
            cmbChar.SelectionChanged += (s, e) => refreshPresetDesc();
            cmbCategory.SelectionChanged += (s, e) => refreshPresetDesc();
            refreshPresetDesc();

            CheckBox chkAllEps = new CheckBox
            {
                IsChecked = true,
                Content = new TextBlock { Text = "Disponibilizar esta roupa automaticamente em todos os episódios da história (EP.1, EP.2 e EP.3)", Foreground = TextPrimary },
                Margin = new Thickness(0, 0, 0, 16)
            };
            sp.Children.Add(chkAllEps);

            StackPanel btnRow = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };

            Button btnImportDisk = CreateStyledButton("📂 Já tenho o .jpg no PC...", BgCard, TextPrimary, new Thickness(12, 7, 12, 7));
            btnImportDisk.Margin = new Thickness(0, 0, 10, 0);
            btnImportDisk.Click += (s, e) =>
            {
                string chosenChar = Convert.ToString(cmbChar.SelectedItem ?? "");
                ComboBoxItem catItem = cmbCategory.SelectedItem as ComboBoxItem;
                string occ = catItem != null ? Convert.ToString(catItem.Tag ?? "Simples") : "Simples";
                if (string.IsNullOrEmpty(chosenChar) || string.IsNullOrEmpty(occ))
                    return;

                OpenFileDialog ofd = new OpenFileDialog
                {
                    Title = "Selecione a imagem .jpg/.png com a nova roupa do personagem",
                    Filter = "Imagens (*.jpg;*.jpeg;*.png)|*.jpg;*.jpeg;*.png"
                };
                if (ofd.ShowDialog() == true)
                {
                    string varFile = EpisodeParser.BuildOutfitVariantFileName(chosenChar, occ);
                    string dst = Path.Combine(_selectedEpisode.AssetsDir, varFile);
                    File.Copy(ofd.FileName, dst, true);
                    if (chkAllEps.IsChecked == true && !string.IsNullOrEmpty(_selectedEpisode.StoryRootPath) && Directory.Exists(_selectedEpisode.StoryRootPath))
                    {
                        foreach (string sub in Directory.GetDirectories(_selectedEpisode.StoryRootPath))
                        {
                            string subAssets = Path.Combine(sub, "assets");
                            if (Directory.Exists(subAssets))
                                File.Copy(dst, Path.Combine(subAssets, varFile), true);
                        }
                    }
                    _grok.MirrorAssetsToTempFlow(_selectedEpisode.AssetsDir);
                    RefreshAssetsGallery(null);
                    RefreshTakesManagerList();
                    AppendLog(string.Format("[Figurino] {0} importada com sucesso: {1}", EpisodeParser.FormatOutfitDisplayLabel(occ), varFile));
                    dlg.DialogResult = false;
                }
            };
            btnRow.Children.Add(btnImportDisk);

            Button btnCancel = CreateStyledButton("Cancelar", BgCard, TextPrimary, new Thickness(12, 7, 12, 7));
            btnCancel.Margin = new Thickness(0, 0, 10, 0);
            btnCancel.Click += (s, e) => dlg.DialogResult = false;
            btnRow.Children.Add(btnCancel);

            Button btnGenerate = CreateStyledButton("🪄 Gerar Roupa no Grok (Mantendo Mesmo Rosto)", AccentPrimary, Brushes.White, new Thickness(14, 7, 14, 7));
            btnGenerate.FontWeight = FontWeights.Bold;
            btnGenerate.Click += (s, e) => dlg.DialogResult = true;
            btnRow.Children.Add(btnGenerate);

            sp.Children.Add(btnRow);
            dlg.Content = sp;

            if (dlg.ShowDialog() == true)
            {
                string chosenChar = Convert.ToString(cmbChar.SelectedItem ?? "");
                ComboBoxItem catItem = cmbCategory.SelectedItem as ComboBoxItem;
                string occ = catItem != null ? Convert.ToString(catItem.Tag ?? "Simples") : "Simples";
                string desc = (txtOutfitDesc.Text ?? "").Trim();
                bool copyAll = chkAllEps.IsChecked == true;
                var _ = RunGenerateOutfitVariantFromUiAsync(chosenChar, occ, desc, copyAll);
            }
        }

        private async Task RunAutoDetectAndGenerateOutfitsFromUiAsync()
        {
            if (_isRunning) return;
            if (_selectedEpisode == null)
            {
                MessageBox.Show("Selecione primeiro uma história e episódio na coluna esquerda.", "Gerar Roupas Automáticas pelo Texto", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            List<CharacterWardrobeSpec> detected = EpisodeParser.DetectRequiredCharacterOutfitsFromText(_selectedEpisode);
            if (detected.Count == 0)
            {
                MessageBox.Show("O texto desta história usa apenas a Roupa Padrão original de cada personagem (nenhuma troca de ocasião extra detectada). Se desejar criar uma roupa extra manualmente, clique em '👔 + Criar Roupa Padrão...'.",
                    "Roupas de Acordo com o Texto", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            SyncSettingsFromUi();
            SetRunningUiState(true);
            _runCts = new CancellationTokenSource();

            EpisodeWorkItem ep = _selectedEpisode;
            CancellationToken token = _runCts.Token;

            try
            {
                SetStageBadge(_badgeGrok, StageState.Running, "GERANDO ROUPAS...");
                UpdateProgress(20, string.Format("Gerando {0} opções de roupas padrão de acordo com o texto no Grok...", detected.Count));
                int count = await Task.Run(async () =>
                {
                    await _cdp.EnsureConnectedAsync(token);
                    return await _grok.EnsureAutoDetectedCharacterOutfitsAsync(ep, token);
                });
                SetStageBadge(_badgeGrok, StageState.Success, "ROUPAS OK");
                UpdateProgress(100, string.Format("Roupas automáticas prontas ({0} novas geradas)!", count));
            }
            catch (OperationCanceledException)
            {
                UpdateProgress(0, "Geração de roupas cancelada.");
            }
            catch (Exception ex)
            {
                SetStageBadge(_badgeGrok, StageState.Failed, "ERRO");
                AppendLog("[Erro Figurino Automático] " + ex.Message);
                MessageBox.Show(ex.Message, "Erro ao Gerar Roupas pelo Texto", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                if (_selectedStory != null) RebuildEpisodeButtons(_selectedStory);
                RefreshAssetsGallery(null);
                RefreshTakesManagerList();
                SetRunningUiState(false);
            }
        }

        private async Task RunGenerateOutfitVariantFromUiAsync(string baseCharFile, string occasion, string outfitDesc, bool copyAll)
        {
            if (_isRunning || _selectedEpisode == null) return;
            SyncSettingsFromUi();
            SetRunningUiState(true);
            _runCts = new CancellationTokenSource();

            EpisodeWorkItem ep = _selectedEpisode;
            CancellationToken token = _runCts.Token;

            try
            {
                SetStageBadge(_badgeGrok, StageState.Running, "GERANDO ROUPA...");
                UpdateProgress(25, string.Format("Gerando roupa '{0}' para '{1}' no Grok Imagine...", occasion, baseCharFile));
                string variantName = await Task.Run(async () =>
                {
                    return await _grok.GenerateCharacterOutfitVariantAsync(ep, baseCharFile, occasion, outfitDesc, copyAll, token);
                });
                SetStageBadge(_badgeGrok, StageState.Success, "ROUPA OK");
                UpdateProgress(100, "Nova roupa criada e vinculada automaticamente: " + variantName);
            }
            catch (OperationCanceledException)
            {
                UpdateProgress(0, "Geração de roupa cancelada pelo usuário.");
                AppendLog("[Sistema] Geração de roupa cancelada.");
            }
            catch (Exception ex)
            {
                SetStageBadge(_badgeGrok, StageState.Failed, "ERRO");
                AppendLog("[Erro Figurino] " + ex.Message);
                MessageBox.Show(ex.Message, "Erro ao Gerar Roupa", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                if (_selectedStory != null) RebuildEpisodeButtons(_selectedStory);
                RefreshAssetsGallery(null);
                RefreshTakesManagerList();
                SetRunningUiState(false);
            }
        }

        // =================================================================================================
        // SUGESTÃO D: INDICADOR VISUAL DE CONTAS GROK + ADICIONAR PERFIL CHROME FÁCIL
        // =================================================================================================

    }
}
