using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Microsoft.Win32;

namespace FluxoVideoStudio
{
    public partial class MainWindow : Window
    {
        // =================================================================================================
        // GERENCIADOR DE TAKES & FIGURINOS POR OCASIÃO (ITENS 1 E 2)
        // =================================================================================================

        private struct CachedMp4Duration
        {
            public long Length;
            public long LastWriteTicks;
            public double Seconds;
        }

        private static readonly Dictionary<string, CachedMp4Duration> _mp4DurationCache =
            new Dictionary<string, CachedMp4Duration>(StringComparer.OrdinalIgnoreCase);

        private void RefreshTakesManagerList()
        {
            if (_pnlTakesList == null) return;
            _pnlTakesList.Children.Clear();
            _takeSelectionChecks.Clear();

            if (_selectedEpisode == null || _selectedEpisode.FlowTakes == null || _selectedEpisode.FlowTakes.Count == 0)
            {
                if (_lblTakesManagerSummary != null)
                    _lblTakesManagerSummary.Text = "Selecione um episódio com takes decupados para gerenciar takes e figurinos.";
                return;
            }

            int readyCount = 0;
            double totalReadySeconds = 0.0;
            int measuredReadyCount = 0;

            foreach (FlowTakeSpec take in _selectedEpisode.FlowTakes.OrderBy(t => t.TakeNumber))
            {
                string mp4Path = Path.Combine(_selectedEpisode.TakesDir, string.Format("Take_{0:00}.mp4", take.TakeNumber));
                bool exists = File.Exists(mp4Path) && new FileInfo(mp4Path).Length >= 50 * 1024;
                if (exists) readyCount++;

                double realDurationSec = 0.0;
                bool hasRealDuration = exists && TryGetMp4DurationSeconds(mp4Path, out realDurationSec) && realDurationSec > 0.05;
                if (hasRealDuration)
                {
                    totalReadySeconds += realDurationSec;
                    measuredReadyCount++;
                }

                _pnlTakesList.Children.Add(BuildTakeManagerCard(take, mp4Path, exists, realDurationSec, hasRealDuration));
            }

            if (_lblTakesManagerSummary != null)
            {
                string totalTimeSuffix = measuredReadyCount > 0
                    ? string.Format(" • ⏱ Total pronto: {0}", FormatTotalDurationSummary(totalReadySeconds))
                    : "";
                _lblTakesManagerSummary.Text = string.Format(
                    "{0} ({1}): {2}/{3} takes prontos em 'takes\\'{4}. Marque ou escolha qualquer take abaixo para regerar:",
                    _selectedEpisode.StoryName, _selectedEpisode.EpisodeName, readyCount, _selectedEpisode.FlowTakes.Count, totalTimeSuffix);
            }
        }

        private UIElement BuildTakeManagerCard(FlowTakeSpec take, string mp4Path, bool exists, double realDurationSec, bool hasRealDuration)
        {
            Border card = new Border
            {
                Background = BgCard,
                BorderBrush = exists ? BrushFromHex("#065F46") : BorderSubtle,
                BorderThickness = new Thickness(1.5),
                CornerRadius = new CornerRadius(8),
                Padding = new Thickness(12, 10, 12, 10),
                Margin = new Thickness(0, 0, 0, 8)
            };

            StackPanel root = new StackPanel();

            // Linha 1: Checkbox + Take_XX + Tag Tempo da Cena (ex: 10s) + Badge Status + Cenário + Botões de Ação Rápida
            DockPanel headerRow = new DockPanel { Margin = new Thickness(0, 0, 0, 6) };

            StackPanel leftInfo = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };
            CheckBox chkTake = new CheckBox
            {
                IsChecked = !exists,
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(0, 0, 8, 0)
            };
            _takeSelectionChecks[take.TakeNumber] = chkTake;
            leftInfo.Children.Add(chkTake);

            leftInfo.Children.Add(new TextBlock
            {
                Text = string.Format("TAKE {0:00}", take.TakeNumber),
                FontSize = 14,
                FontWeight = FontWeights.Bold,
                Foreground = TextPrimary,
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(0, 0, 8, 0)
            });

            string durationTagText = hasRealDuration
                ? FormatSceneDurationTag(realDurationSec)
                : NormalizePlannedDurationTag(take != null ? take.DurationText : "10s");

            Border durationBadge = new Border
            {
                Background = hasRealDuration ? BrushFromHex("#172554") : BrushFromHex("#1F2937"),
                BorderBrush = hasRealDuration ? BrushFromHex("#38BDF8") : BrushFromHex("#4B5563"),
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(5),
                Padding = new Thickness(7, 2, 7, 2),
                Margin = new Thickness(0, 0, 8, 0),
                VerticalAlignment = VerticalAlignment.Center,
                ToolTip = hasRealDuration
                    ? string.Format(CultureInfo.InvariantCulture, "Tempo real da cena ({0}): {1:0.00}s", Path.GetFileName(mp4Path), realDurationSec)
                    : string.Format("Tempo previsto da cena: {0} (vídeo ainda pendente)", durationTagText)
            };
            durationBadge.Child = new TextBlock
            {
                Text = "⏱ " + durationTagText,
                FontSize = 10.5,
                FontWeight = FontWeights.Bold,
                Foreground = hasRealDuration ? BrushFromHex("#BAE6FD") : BrushFromHex("#D1D5DB")
            };
            leftInfo.Children.Add(durationBadge);

            Border statusBadge = new Border
            {
                Background = exists ? BrushFromHex("#064E3B") : BrushFromHex("#451A03"),
                BorderBrush = exists ? AccentGreen : AccentAmber,
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(5),
                Padding = new Thickness(7, 2, 7, 2),
                Margin = new Thickness(0, 0, 10, 0),
                VerticalAlignment = VerticalAlignment.Center
            };
            double mb = exists ? (new FileInfo(mp4Path).Length / (1024.0 * 1024.0)) : 0.0;
            statusBadge.Child = new TextBlock
            {
                Text = exists ? string.Format("✔ PRONTO ({0:0.1} MB)", mb) : "⏳ PENDENTE",
                FontSize = 10.5,
                FontWeight = FontWeights.Bold,
                Foreground = exists ? BrushFromHex("#A7F3D0") : BrushFromHex("#FDE68A")
            };
            leftInfo.Children.Add(statusBadge);

            if (!string.IsNullOrEmpty(take.ScenarioName))
            {
                leftInfo.Children.Add(new TextBlock
                {
                    Text = "📍 Cenário: " + take.ScenarioName,
                    FontSize = 12,
                    Foreground = TextSecondary,
                    VerticalAlignment = VerticalAlignment.Center,
                    Margin = new Thickness(0, 0, 12, 0)
                });
            }

            headerRow.Children.Add(leftInfo);

            // Botões de Ação Individual por Take
            StackPanel actionBtns = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };

            if (exists)
            {
                Button btnWatch = CreateStyledButton("▶ Assistir", BgPanel, TextPrimary, new Thickness(9, 4, 9, 4));
                btnWatch.FontSize = 11;
                btnWatch.Margin = new Thickness(0, 0, 6, 0);
                btnWatch.Click += (s, e) =>
                {
                    try { Process.Start(new ProcessStartInfo(mp4Path) { UseShellExecute = true }); } catch { }
                };
                actionBtns.Children.Add(btnWatch);
            }

            int capturedTakeNum = take.TakeNumber;

            Button btnRegenFlow = CreateStyledButton("🌊 Regerar no Flow", AccentBlue, Brushes.White, new Thickness(10, 4, 10, 4));
            btnRegenFlow.FontSize = 11;
            btnRegenFlow.FontWeight = FontWeights.SemiBold;
            btnRegenFlow.Margin = new Thickness(0, 0, 6, 0);
            btnRegenFlow.Click += async (s, e) => await RegenerateSingleTakeAsync(capturedTakeNum, false);
            actionBtns.Children.Add(btnRegenFlow);

            Button btnRegenGrok = CreateStyledButton("🚀 Regerar no Grok Vídeo (🪄)", AccentPrimary, Brushes.White, new Thickness(10, 4, 10, 4));
            btnRegenGrok.FontSize = 11;
            btnRegenGrok.FontWeight = FontWeights.SemiBold;
            btnRegenGrok.Click += async (s, e) => await RegenerateSingleTakeAsync(capturedTakeNum, true);
            actionBtns.Children.Add(btnRegenGrok);

            DockPanel.SetDock(actionBtns, Dock.Right);
            headerRow.Children.Add(actionBtns);
            root.Children.Add(headerRow);

            // Linha 2: Ingredientes vinculados pelo roteiro/pré-definição (PASSO 1 e PASSO 3)
            if (take.Ingredients != null && take.Ingredients.Count > 0)
            {
                root.Children.Add(new TextBlock
                {
                    Text = "📎 Ingredientes da Cena (definidos no Passo 1/3): " + string.Join(", ", take.Ingredients),
                    FontSize = 11,
                    Foreground = BrushFromHex("#93C5FD"),
                    Margin = new Thickness(0, 0, 0, 5)
                });
            }

            // Linha 3: Prompt editável do Take
            TextBox txtTakePrompt = new TextBox
            {
                Text = take.RawPromptBody ?? "",
                Background = BgInput,
                Foreground = TextPrimary,
                BorderBrush = BorderSubtle,
                BorderThickness = new Thickness(1),
                FontFamily = new FontFamily("Consolas"),
                FontSize = 11,
                TextWrapping = TextWrapping.Wrap,
                AcceptsReturn = true,
                MaxHeight = 76,
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                Padding = new Thickness(6, 4, 6, 4)
            };
            FlowTakeSpec capturedForPrompt = take;
            txtTakePrompt.LostFocus += (s, e) =>
            {
                if (_selectedEpisode == null) return;
                string newTxt = (txtTakePrompt.Text ?? "").Trim();
                if (!string.Equals(newTxt, capturedForPrompt.RawPromptBody ?? "", StringComparison.Ordinal))
                {
                    capturedForPrompt.RawPromptBody = newTxt;
                    EpisodeParser.SaveEpisodeCustomTakesConfig(_selectedEpisode);
                }
            };
            root.Children.Add(txtTakePrompt);

            card.Child = root;
            return card;
        }

        private async Task RegenerateSingleTakeAsync(int takeNumber, bool forceGrokVideo)
        {
            if (_selectedEpisode == null || _selectedEpisode.FlowTakes == null) return;
            FlowTakeSpec take = _selectedEpisode.FlowTakes.FirstOrDefault(t => t.TakeNumber == takeNumber);
            if (take == null) return;

            await RegenerateSpecificTakesCoreAsync(new List<int> { takeNumber }, forceGrokVideo);
        }

        private async Task RegenerateCheckedTakesAsync(bool forceGrokVideo)
        {
            List<int> selectedNums = _takeSelectionChecks
                .Where(kv => kv.Value.IsChecked == true)
                .Select(kv => kv.Key)
                .OrderBy(n => n)
                .ToList();

            if (selectedNums.Count == 0)
            {
                MessageBox.Show("Marque pelo menos 1 Take na lista para regerar.", "Regerar Takes", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            await RegenerateSpecificTakesCoreAsync(selectedNums, forceGrokVideo);
        }

        private async Task RegenerateSpecificTakesCoreAsync(List<int> takeNumbers, bool forceGrokVideo)
        {
            if (_isRunning || _selectedEpisode == null || takeNumbers == null || takeNumbers.Count == 0)
                return;

            SyncSettingsFromUi();
            EpisodeParser.SaveEpisodeCustomTakesConfig(_selectedEpisode);
            SetRunningUiState(true);
            _runCts = new CancellationTokenSource();

            string labels = string.Join(", ", takeNumbers.Select(n => string.Format("Take_{0:00}", n)));
            string engineName = forceGrokVideo ? "Grok Vídeo (com varinha mágica 🪄)" : "Google Flow";

            EpisodeWorkItem ep = _selectedEpisode;
            CancellationToken token = _runCts.Token;

            try
            {
                SetStageBadge(_badgeFlow, StageState.Running, "REGERANDO...");
                UpdateProgress(35, string.Format("Regerando {0} em {1}...", labels, engineName));
                AppendLog(string.Format("===== Iniciando regeração de {0} via {1} =====", labels, engineName));

                await Task.Run(async () =>
                {
                    await _cdp.EnsureConnectedAsync(token);
                    await _flow.RegenerateSelectedTakesAsync(ep, takeNumbers, forceGrokVideo, token);
                });

                SetStageBadge(_badgeFlow, StageState.Success, "CONCLUÍDO");
                UpdateProgress(100, string.Format("Regeração concluída: {0}!", labels));
            }
            catch (OperationCanceledException)
            {
                UpdateProgress(0, "Regeração cancelada pelo usuário.");
                AppendLog("[Sistema] Regeração de take(s) cancelada.");
            }
            catch (Exception ex)
            {
                SetStageBadge(_badgeFlow, StageState.Failed, "ERRO");
                UpdateProgress(0, "Erro ao regerar take(s): " + ex.Message);
                AppendLog("[ERRO] " + ex.ToString());
                MessageBox.Show(ex.Message, "Erro ao Regerar Take", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                if (_selectedStory != null) RebuildEpisodeButtons(_selectedStory);
                RefreshAssetsGallery(null);
                RefreshTakesManagerList();
                SetRunningUiState(false);
            }
        }


        // =================================================================================================
        // ITEM 1: CRIAR NOVA ROUPA PARA PERSONAGEM POR OCASIÃO (MANTENDO MESMO ROSTO NO GROK)
        // =================================================================================================

        private void ShowCreateCharacterOutfitDialog(string preselectedBaseChar)
        {
            if (_selectedEpisode == null)
            {
                MessageBox.Show("Selecione primeiro uma história e episódio na coluna esquerda.", "Criar Roupa de Personagem", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            List<string> charFiles = new List<string>();
            if (Directory.Exists(_selectedEpisode.AssetsDir))
            {
                charFiles = Directory.GetFiles(_selectedEpisode.AssetsDir)
                    .Select(f => Path.GetFileName(f))
                    .Where(fn => Regex.IsMatch(Path.GetExtension(fn), @"^\.(jpg|jpeg|png)$", RegexOptions.IgnoreCase) &&
                                 !EpisodeParser.IsScenarioAssetName(fn) &&
                                 fn.IndexOf("__Roupa_", StringComparison.OrdinalIgnoreCase) < 0)
                    .OrderBy(fn => fn)
                    .ToList();
            }

            if (charFiles.Count == 0)
            {
                MessageBox.Show("Nenhuma imagem base de personagem (.jpg) foi encontrada na pasta assets\\ deste episódio. Gere ou importe os personagens base primeiro.",
                    "Criar Roupa de Personagem", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            Window dlg = new Window
            {
                Title = "👔 Criar Roupa Padrão por Ocasião (Mantendo 100% o Mesmo Rosto do Personagem)",
                Width = 640,
                Height = 450,
                WindowStartupLocation = WindowStartupLocation.CenterOwner,
                Owner = this,
                Background = BgPanel,
                Foreground = TextPrimary,
                ResizeMode = ResizeMode.NoResize
            };

            StackPanel sp = new StackPanel { Margin = new Thickness(18) };

            sp.Children.Add(new TextBlock
            {
                Text = "1. Escolha o Personagem Base (a imagem original será enviada como referência ao Grok):",
                FontWeight = FontWeights.Bold,
                FontSize = 12.5,
                Foreground = TextPrimary,
                Margin = new Thickness(0, 0, 0, 5)
            });

            ComboBox cmbChar = new ComboBox { FontSize = 12, Padding = new Thickness(8, 5, 8, 5), Margin = new Thickness(0, 0, 0, 12) };
            int selIdx = 0;
            for (int i = 0; i < charFiles.Count; i++)
            {
                cmbChar.Items.Add(charFiles[i]);
                if (!string.IsNullOrEmpty(preselectedBaseChar) &&
                    string.Equals(charFiles[i], preselectedBaseChar, StringComparison.OrdinalIgnoreCase))
                {
                    selIdx = i;
                }
            }
            cmbChar.SelectedIndex = selIdx;
            sp.Children.Add(cmbChar);

            sp.Children.Add(new TextBlock
            {
                Text = "2. Categoria de Roupa Padrão (gerada e selecionada de acordo com o texto):",
                FontWeight = FontWeights.Bold,
                FontSize = 12.5,
                Foreground = TextPrimary,
                Margin = new Thickness(0, 0, 0, 4)
            });

            ComboBox cmbCategory = new ComboBox { FontSize = 12, Padding = new Thickness(8, 5, 8, 5), Margin = new Thickness(0, 0, 0, 12) };
            cmbCategory.Items.Add(new ComboBoxItem { Content = "👔 Roupa de Trabalho (Obra / Escritório / Serviço)", Tag = "Trabalho" });
            cmbCategory.Items.Add(new ComboBoxItem { Content = "🏠 Roupa Simples (Casa / Dia a Dia / Pós-Formatura)", Tag = "Simples" });
            cmbCategory.Items.Add(new ComboBoxItem { Content = "🌿 Roupa de Lazer (Passeio / Encontro / Fim de Semana)", Tag = "Lazer" });
            cmbCategory.Items.Add(new ComboBoxItem { Content = "🎩 Roupa Formal (Formatura / Casamento / Festa / Gala)", Tag = "Formal" });
            cmbCategory.SelectedIndex = 0;
            sp.Children.Add(cmbCategory);

            sp.Children.Add(new TextBlock
            {
                Text = "3. Descrição da Roupa (gerada automaticamente de acordo com o personagem e o texto):",
                FontWeight = FontWeights.Bold,
                FontSize = 12.5,
                Foreground = TextPrimary,
                Margin = new Thickness(0, 0, 0, 5)
            });

            TextBox txtOutfitDesc = new TextBox
            {
                Text = "",
                Background = BgInput,
                Foreground = TextPrimary,
                BorderBrush = BorderSubtle,
                BorderThickness = new Thickness(1),
                FontSize = 12,
                TextWrapping = TextWrapping.Wrap,
                AcceptsReturn = true,
                Height = 82,
                Padding = new Thickness(8, 5, 8, 5),
                Margin = new Thickness(0, 0, 0, 10)
            };
            sp.Children.Add(txtOutfitDesc);

            Action refreshPresetDesc = () =>
            {
                string chosenChar = Convert.ToString(cmbChar.SelectedItem ?? "");
                ComboBoxItem catItem = cmbCategory.SelectedItem as ComboBoxItem;
                string catKey = catItem != null ? Convert.ToString(catItem.Tag ?? "Trabalho") : "Trabalho";
                txtOutfitDesc.Text = EpisodeParser.GetStandardWardrobePresetDescription(_selectedEpisode, chosenChar, catKey);
            };
            cmbChar.SelectionChanged += (s, e) => refreshPresetDesc();
            cmbCategory.SelectionChanged += (s, e) => refreshPresetDesc();
            refreshPresetDesc();

            CheckBox chkAllEps = new CheckBox
            {
                IsChecked = true,
                Content = new TextBlock { Text = "Disponibilizar esta roupa automaticamente em todos os episódios da história (EP.1, EP.2 e EP.3)", Foreground = TextPrimary },
                Margin = new Thickness(0, 0, 0, 16)
            };
            sp.Children.Add(chkAllEps);

            StackPanel btnRow = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };

            Button btnImportDisk = CreateStyledButton("📂 Já tenho o .jpg no PC...", BgCard, TextPrimary, new Thickness(12, 7, 12, 7));
            btnImportDisk.Margin = new Thickness(0, 0, 10, 0);
            btnImportDisk.Click += (s, e) =>
            {
                string chosenChar = Convert.ToString(cmbChar.SelectedItem ?? "");
                ComboBoxItem catItem = cmbCategory.SelectedItem as ComboBoxItem;
                string occ = catItem != null ? Convert.ToString(catItem.Tag ?? "Simples") : "Simples";
                if (string.IsNullOrEmpty(chosenChar) || string.IsNullOrEmpty(occ))
                    return;

                OpenFileDialog ofd = new OpenFileDialog
                {
                    Title = "Selecione a imagem .jpg/.png com a nova roupa do personagem",
                    Filter = "Imagens (*.jpg;*.jpeg;*.png)|*.jpg;*.jpeg;*.png"
                };
                if (ofd.ShowDialog() == true)
                {
                    string varFile = EpisodeParser.BuildOutfitVariantFileName(chosenChar, occ);
                    string dst = Path.Combine(_selectedEpisode.AssetsDir, varFile);
                    File.Copy(ofd.FileName, dst, true);
                    if (chkAllEps.IsChecked == true && !string.IsNullOrEmpty(_selectedEpisode.StoryRootPath) && Directory.Exists(_selectedEpisode.StoryRootPath))
                    {
                        foreach (string sub in Directory.GetDirectories(_selectedEpisode.StoryRootPath))
                        {
                            string subAssets = Path.Combine(sub, "assets");
                            if (Directory.Exists(subAssets))
                                File.Copy(dst, Path.Combine(subAssets, varFile), true);
                        }
                    }
                    _grok.MirrorAssetsToTempFlow(_selectedEpisode.AssetsDir);
                    RefreshAssetsGallery(null);
                    RefreshTakesManagerList();
                    AppendLog(string.Format("[Figurino] {0} importada com sucesso: {1}", EpisodeParser.FormatOutfitDisplayLabel(occ), varFile));
                    dlg.DialogResult = false;
                }
            };
            btnRow.Children.Add(btnImportDisk);

            Button btnCancel = CreateStyledButton("Cancelar", BgCard, TextPrimary, new Thickness(12, 7, 12, 7));
            btnCancel.Margin = new Thickness(0, 0, 10, 0);
            btnCancel.Click += (s, e) => dlg.DialogResult = false;
            btnRow.Children.Add(btnCancel);

            Button btnGenerate = CreateStyledButton("🪄 Gerar Roupa no Grok (Mantendo Mesmo Rosto)", AccentPrimary, Brushes.White, new Thickness(14, 7, 14, 7));
            btnGenerate.FontWeight = FontWeights.Bold;
            btnGenerate.Click += (s, e) => dlg.DialogResult = true;
            btnRow.Children.Add(btnGenerate);

            sp.Children.Add(btnRow);
            dlg.Content = sp;

            if (dlg.ShowDialog() == true)
            {
                string chosenChar = Convert.ToString(cmbChar.SelectedItem ?? "");
                ComboBoxItem catItem = cmbCategory.SelectedItem as ComboBoxItem;
                string occ = catItem != null ? Convert.ToString(catItem.Tag ?? "Simples") : "Simples";
                string desc = (txtOutfitDesc.Text ?? "").Trim();
                bool copyAll = chkAllEps.IsChecked == true;
                var _ = RunGenerateOutfitVariantFromUiAsync(chosenChar, occ, desc, copyAll);
            }
        }

        private async Task RunAutoDetectAndGenerateOutfitsFromUiAsync()
        {
            if (_isRunning) return;
            if (_selectedEpisode == null)
            {
                MessageBox.Show("Selecione primeiro uma história e episódio na coluna esquerda.", "Gerar Roupas Automáticas pelo Texto", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            List<CharacterWardrobeSpec> detected = EpisodeParser.DetectRequiredCharacterOutfitsFromText(_selectedEpisode);
            if (detected.Count == 0)
            {
                MessageBox.Show("O texto desta história usa apenas a Roupa Padrão original de cada personagem (nenhuma troca de ocasião extra detectada). Se desejar criar uma roupa extra manualmente, clique em '👔 + Criar Roupa Padrão...'.",
                    "Roupas de Acordo com o Texto", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            SyncSettingsFromUi();
            SetRunningUiState(true);
            _runCts = new CancellationTokenSource();

            EpisodeWorkItem ep = _selectedEpisode;
            CancellationToken token = _runCts.Token;

            try
            {
                SetStageBadge(_badgeGrok, StageState.Running, "GERANDO ROUPAS...");
                UpdateProgress(20, string.Format("Gerando {0} opções de roupas padrão de acordo com o texto no Grok...", detected.Count));
                int count = await Task.Run(async () =>
                {
                    await _cdp.EnsureConnectedAsync(token);
                    return await _grok.EnsureAutoDetectedCharacterOutfitsAsync(ep, token);
                });
                SetStageBadge(_badgeGrok, StageState.Success, "ROUPAS OK");
                UpdateProgress(100, string.Format("Roupas automáticas prontas ({0} novas geradas)!", count));
            }
            catch (OperationCanceledException)
            {
                UpdateProgress(0, "Geração de roupas cancelada.");
            }
            catch (Exception ex)
            {
                SetStageBadge(_badgeGrok, StageState.Failed, "ERRO");
                AppendLog("[Erro Figurino Automático] " + ex.Message);
                MessageBox.Show(ex.Message, "Erro ao Gerar Roupas pelo Texto", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                if (_selectedStory != null) RebuildEpisodeButtons(_selectedStory);
                RefreshAssetsGallery(null);
                RefreshTakesManagerList();
                SetRunningUiState(false);
            }
        }

        private async Task RunGenerateOutfitVariantFromUiAsync(string baseCharFile, string occasion, string outfitDesc, bool copyAll)
        {
            if (_isRunning || _selectedEpisode == null) return;
            SyncSettingsFromUi();
            SetRunningUiState(true);
            _runCts = new CancellationTokenSource();

            EpisodeWorkItem ep = _selectedEpisode;
            CancellationToken token = _runCts.Token;

            try
            {
                SetStageBadge(_badgeGrok, StageState.Running, "GERANDO ROUPA...");
                UpdateProgress(25, string.Format("Gerando roupa '{0}' para '{1}' no Grok Imagine...", occasion, baseCharFile));
                string variantName = await Task.Run(async () =>
                {
                    return await _grok.GenerateCharacterOutfitVariantAsync(ep, baseCharFile, occasion, outfitDesc, copyAll, token);
                });
                SetStageBadge(_badgeGrok, StageState.Success, "ROUPA OK");
                UpdateProgress(100, "Nova roupa criada e vinculada automaticamente: " + variantName);
            }
            catch (OperationCanceledException)
            {
                UpdateProgress(0, "Geração de roupa cancelada pelo usuário.");
                AppendLog("[Sistema] Geração de roupa cancelada.");
            }
            catch (Exception ex)
            {
                SetStageBadge(_badgeGrok, StageState.Failed, "ERRO");
                AppendLog("[Erro Figurino] " + ex.Message);
                MessageBox.Show(ex.Message, "Erro ao Gerar Roupa", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                if (_selectedStory != null) RebuildEpisodeButtons(_selectedStory);
                RefreshAssetsGallery(null);
                RefreshTakesManagerList();
                SetRunningUiState(false);
            }
        }

        // =================================================================================================
        // LEITURA RÁPIDA DE DURAÇÃO DE VÍDEO MP4 (TAG DE TEMPO DE CENA — EX: 10s)
        // =================================================================================================

        private static string FormatSceneDurationTag(double seconds)
        {
            if (seconds <= 0.05)
                return "10s";
            double rounded = Math.Round(seconds);
            if (Math.Abs(seconds - rounded) <= 0.15)
                return string.Format("{0}s", (int)rounded);
            return string.Format(CultureInfo.InvariantCulture, "{0:0.#}s", seconds);
        }

        private static string NormalizePlannedDurationTag(string rawDuration)
        {
            string trimmed = (rawDuration ?? "").Trim();
            if (string.IsNullOrEmpty(trimmed))
                return "10s";

            Match m = Regex.Match(trimmed, @"(\d+(?:[\.,]\d+)?)");
            if (m.Success)
            {
                double val;
                if (double.TryParse(m.Groups[1].Value.Replace(',', '.'), NumberStyles.Float, CultureInfo.InvariantCulture, out val) && val > 0)
                    return FormatSceneDurationTag(val);
            }
            return "10s";
        }

        private static string FormatTotalDurationSummary(double totalSeconds)
        {
            int totalRounded = (int)Math.Round(Math.Max(0.0, totalSeconds));
            if (totalRounded < 60)
                return string.Format("{0}s", totalRounded);
            int mins = totalRounded / 60;
            int secs = totalRounded % 60;
            return string.Format("{0}m {1:00}s ({2}s)", mins, secs, totalRounded);
        }

        private static bool TryGetMp4DurationSeconds(string mp4Path, out double seconds)
        {
            seconds = 0.0;
            if (string.IsNullOrEmpty(mp4Path))
                return false;

            try
            {
                FileInfo fi = new FileInfo(mp4Path);
                if (!fi.Exists || fi.Length < 64)
                    return false;

                long len = fi.Length;
                long ticks = fi.LastWriteTimeUtc.Ticks;

                lock (_mp4DurationCache)
                {
                    CachedMp4Duration cached;
                    if (_mp4DurationCache.TryGetValue(mp4Path, out cached) &&
                        cached.Length == len &&
                        cached.LastWriteTicks == ticks)
                    {
                        seconds = cached.Seconds;
                        return seconds > 0.05;
                    }
                }

                double parsed = 0.0;
                using (FileStream fs = new FileStream(mp4Path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                {
                    parsed = ParseMp4DurationFromStream(fs, 0, fs.Length);
                }

                lock (_mp4DurationCache)
                {
                    CachedMp4Duration entry = new CachedMp4Duration();
                    entry.Length = len;
                    entry.LastWriteTicks = ticks;
                    entry.Seconds = parsed;
                    _mp4DurationCache[mp4Path] = entry;
                }

                seconds = parsed;
                return seconds > 0.05;
            }
            catch
            {
                seconds = 0.0;
                return false;
            }
        }

        private static double ParseMp4DurationFromStream(Stream fs, long startOffset, long endOffset)
        {
            byte[] hdr = new byte[8];
            long pos = startOffset;

            while (pos + 8 <= endOffset)
            {
                string boxType;
                long payloadStart;
                long boxEnd;
                if (!ReadBoxHeader(fs, pos, endOffset, hdr, out boxType, out payloadStart, out boxEnd))
                    break;

                if (boxType == "moov")
                {
                    double moovSec = ParseMoovBoxDuration(fs, payloadStart, boxEnd, hdr);
                    if (moovSec > 0.05)
                        return moovSec;
                }

                pos = boxEnd;
            }

            return 0.0;
        }

        private static double ParseMoovBoxDuration(Stream fs, long moovStart, long moovEnd, byte[] hdr)
        {
            uint mvhdTimescale = 0;
            ulong mehdRawDuration = 0;
            double maxTrackSeconds = 0.0;

            long pos = moovStart;
            while (pos + 8 <= moovEnd)
            {
                string boxType;
                long payloadStart;
                long boxEnd;
                if (!ReadBoxHeader(fs, pos, moovEnd, hdr, out boxType, out payloadStart, out boxEnd))
                    break;

                if (boxType == "mvhd")
                {
                    uint ts;
                    double sec = ParseFullHeaderBoxSeconds(fs, payloadStart, boxEnd, out ts);
                    if (ts > 0) mvhdTimescale = ts;
                    if (sec > 0.05)
                        return sec;
                }
                else if (boxType == "mvex")
                {
                    long mvPos = payloadStart;
                    while (mvPos + 8 <= boxEnd)
                    {
                        string mvType;
                        long mvPayload;
                        long mvEnd;
                        if (!ReadBoxHeader(fs, mvPos, boxEnd, hdr, out mvType, out mvPayload, out mvEnd))
                            break;
                        if (mvType == "mehd" && (mvEnd - mvPayload) >= 8)
                        {
                            byte[] mehdBuf = new byte[12];
                            int rLen = (int)Math.Min(12L, mvEnd - mvPayload);
                            fs.Position = mvPayload;
                            if (ReadExact(fs, mehdBuf, rLen))
                            {
                                byte ver = mehdBuf[0];
                                if (ver == 0 && rLen >= 8)
                                    mehdRawDuration = ReadUInt32BE(mehdBuf, 4);
                                else if (ver == 1 && rLen >= 12)
                                    mehdRawDuration = ReadUInt64BE(mehdBuf, 4);
                            }
                        }
                        mvPos = mvEnd;
                    }
                }
                else if (boxType == "trak")
                {
                    long trPos = payloadStart;
                    while (trPos + 8 <= boxEnd)
                    {
                        string trType;
                        long trPayload;
                        long trEnd;
                        if (!ReadBoxHeader(fs, trPos, boxEnd, hdr, out trType, out trPayload, out trEnd))
                            break;
                        if (trType == "mdia")
                        {
                            long mdPos = trPayload;
                            while (mdPos + 8 <= trEnd)
                            {
                                string mdType;
                                long mdPayload;
                                long mdEnd;
                                if (!ReadBoxHeader(fs, mdPos, trEnd, hdr, out mdType, out mdPayload, out mdEnd))
                                    break;
                                if (mdType == "mdhd")
                                {
                                    uint mdTs;
                                    double mdSec = ParseFullHeaderBoxSeconds(fs, mdPayload, mdEnd, out mdTs);
                                    if (mdSec > maxTrackSeconds)
                                        maxTrackSeconds = mdSec;
                                }
                                mdPos = mdEnd;
                            }
                        }
                        trPos = trEnd;
                    }
                }

                pos = boxEnd;
            }

            if (mehdRawDuration > 0 && mvhdTimescale > 0)
                return (double)mehdRawDuration / (double)mvhdTimescale;

            return maxTrackSeconds;
        }

        private static double ParseFullHeaderBoxSeconds(Stream fs, long payloadStart, long boxEnd, out uint timescaleOut)
        {
            timescaleOut = 0;
            long avail = boxEnd - payloadStart;
            if (avail < 20)
                return 0.0;

            byte[] buf = new byte[32];
            int toRead = (int)Math.Min(32L, avail);
            fs.Position = payloadStart;
            if (!ReadExact(fs, buf, toRead))
                return 0.0;

            byte version = buf[0];
            if (version == 0)
            {
                uint ts = ReadUInt32BE(buf, 12);
                uint dur = ReadUInt32BE(buf, 16);
                timescaleOut = ts;
                if (ts > 0 && dur > 0 && dur != 0xFFFFFFFFu)
                    return (double)dur / (double)ts;
            }
            else if (version == 1 && toRead >= 32)
            {
                uint ts = ReadUInt32BE(buf, 20);
                ulong dur = ReadUInt64BE(buf, 24);
                timescaleOut = ts;
                if (ts > 0 && dur > 0 && dur != 0xFFFFFFFFFFFFFFFFul)
                    return (double)dur / (double)ts;
            }

            return 0.0;
        }

        private static bool ReadBoxHeader(
            Stream fs,
            long pos,
            long endOffset,
            byte[] hdrBuf,
            out string boxType,
            out long payloadStart,
            out long boxEnd)
        {
            boxType = "";
            payloadStart = pos;
            boxEnd = pos;

            if (pos < 0 || pos + 8 > endOffset)
                return false;

            fs.Position = pos;
            if (!ReadExact(fs, hdrBuf, 8))
                return false;

            uint size32 = ReadUInt32BE(hdrBuf, 0);
            boxType = Encoding.ASCII.GetString(hdrBuf, 4, 4);

            long boxSize;
            int headerLen;
            if (size32 == 1)
            {
                if (pos + 16 > endOffset)
                    return false;
                if (!ReadExact(fs, hdrBuf, 8))
                    return false;
                ulong size64 = ReadUInt64BE(hdrBuf, 0);
                if (size64 < 16 || size64 > (ulong)(endOffset - pos))
                    return false;
                boxSize = (long)size64;
                headerLen = 16;
            }
            else if (size32 == 0)
            {
                boxSize = endOffset - pos;
                headerLen = 8;
            }
            else
            {
                if (size32 < 8)
                    return false;
                boxSize = (long)size32;
                if (pos + boxSize > endOffset)
                    boxSize = endOffset - pos;
                headerLen = 8;
            }

            payloadStart = pos + headerLen;
            boxEnd = pos + boxSize;
            return boxEnd > pos && payloadStart <= boxEnd;
        }

        private static bool ReadExact(Stream fs, byte[] buffer, int count)
        {
            int offset = 0;
            while (offset < count)
            {
                int read = fs.Read(buffer, offset, count - offset);
                if (read <= 0)
                    return false;
                offset += read;
            }
            return true;
        }

        private static uint ReadUInt32BE(byte[] buf, int offset)
        {
            return ((uint)buf[offset] << 24)
                 | ((uint)buf[offset + 1] << 16)
                 | ((uint)buf[offset + 2] << 8)
                 | (uint)buf[offset + 3];
        }

        private static ulong ReadUInt64BE(byte[] buf, int offset)
        {
            ulong hi = ReadUInt32BE(buf, offset);
            ulong lo = ReadUInt32BE(buf, offset + 4);
            return (hi << 32) | lo;
        }

    }
}
