using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Microsoft.Win32;

namespace FluxoVideoStudio
{
    public class MainWindow : Window
    {
        private readonly PipelineConfig _config;
        private readonly CdpController _cdp;
        private readonly GrokAutomation _grok;
        private readonly FlowAutomation _flow;
        private readonly ElevenLabsAutomation _eleven;
        private readonly CapCutAutomation _capcut;

        private List<StoryProject> _allStories = new List<StoryProject>();
        private StoryProject _selectedStory;
        private EpisodeWorkItem _selectedEpisode;

        private CancellationTokenSource _runCts;
        private TaskCompletionSource<bool> _reviewContinueTcs;
        private bool _isRunning;

        // UI Controls
        private ComboBox _cmbGenreFilter;
        private TextBox _txtSearch;
        private ListBox _lstStories;
        private StackPanel _pnlEpisodeButtons;
        private TextBlock _lblSelectedContext;
        private TextBlock _lblCdpStatus;

        // Stage Cards
        private CheckBox _chkStageGrok;
        private CheckBox _chkStageFlow;
        private CheckBox _chkStageEleven;
        private CheckBox _chkStageCapCut;
        private TextBlock _badgeGrok;
        private TextBlock _badgeFlow;
        private TextBlock _badgeEleven;
        private TextBlock _badgeCapCut;

        // Main Action Buttons
        private Button _btnRunAllEpisodes;
        private Button _btnContinueReview;
        private Button _btnReloadResume;
        private Button _btnStop;
        private Button _btnConnectCdp;

        // Tab 1: Console
        private TextBox _txtLog;
        private ProgressBar _progressBar;
        private TextBlock _lblProgressStep;
        private TextBox _txtCapCutProjName;

        // Tab 2: Visual Asset Grid
        private WrapPanel _wrapAssets;
        private TextBlock _lblAssetsSummary;

        // Tab 3: Takes & Figurinos Manager
        private StackPanel _pnlTakesList;
        private TextBlock _lblTakesManagerSummary;
        private readonly Dictionary<int, CheckBox> _takeSelectionChecks = new Dictionary<int, CheckBox>();

        // Tab 4: Prompts & Narrator
        private TextBox _txtGrokPrompt;
        private TextBox _txtFlowPrompt;
        private TextBox _txtNarratorPrompt;
        private ComboBox _cmbElevenVoiceQuick;

        // Tab 5: Settings
        private CheckBox _chkPreserveAssets;
        private CheckBox _chkArchiveOldTakes;
        private CheckBox _chkPauseAfterGrok;
        private CheckBox _chkReuseHook;
        private CheckBox _chkLaunchCapCut;
        private TextBox _txtGrokProfiles;
        private WrapPanel _wrapGrokProfileBadges;
        private TextBox _txtNewGrokProfile;
        private TextBox _txtFlowProfile;
        private TextBox _txtFlowUrl;
        private TextBox _txtElevenProfiles;
        private TextBox _txtElevenUrl;
        private ComboBox _cmbElevenVoiceSettings;
        private TextBox _txtNovelaRootDir;
        private TextBox _txtTerrorRootDir;

        // Theme Brushes
        private static readonly Brush BgMain = BrushFromHex("#0D1017");
        private static readonly Brush BgPanel = BrushFromHex("#151923");
        private static readonly Brush BgCard = BrushFromHex("#1C2230");
        private static readonly Brush BgInput = BrushFromHex("#10141D");
        private static readonly Brush BorderSubtle = BrushFromHex("#2A3245");
        private static readonly Brush TextPrimary = BrushFromHex("#F3F4F6");
        private static readonly Brush TextSecondary = BrushFromHex("#9CA3AF");
        private static readonly Brush AccentPrimary = BrushFromHex("#6366F1");
        private static readonly Brush AccentGreen = BrushFromHex("#10B981");
        private static readonly Brush AccentAmber = BrushFromHex("#F59E0B");
        private static readonly Brush AccentRed = BrushFromHex("#EF4444");
        private static readonly Brush AccentBlue = BrushFromHex("#3B82F6");

        private readonly string _startupEpisodePath;
        private readonly bool _startupAutoRun;

        public MainWindow(string startupEpisodePath, bool startupAutoRun)
        {
            _startupEpisodePath = startupEpisodePath;
            _startupAutoRun = startupAutoRun;

            _config = new PipelineConfig();
            _config.OnProfileStatusChanged = (prof, st) =>
            {
                Dispatcher.BeginInvoke(new Action(() => RefreshGrokProfileBadges()));
            };
            _cdp = new CdpController(_config, AppendLog);
            _grok = new GrokAutomation(_cdp, _config, AppendLog);
            _flow = new FlowAutomation(_cdp, _config, _grok, AppendLog);
            _eleven = new ElevenLabsAutomation(_cdp, _config, AppendLog);
            _capcut = new CapCutAutomation(_config, AppendLog);

            Title = "Fluxo Vídeo IA Studio — Executor Nativo PC (Grok ➔ Google Flow ➔ ElevenLabs ➔ CapCut)";
            Width = 1420;
            Height = 880;
            MinWidth = 1120;
            MinHeight = 720;
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
            Background = BgMain;
            Foreground = TextPrimary;
            FontFamily = new FontFamily("Segoe UI");

            BuildLayout();

            Loaded += OnMainWindowLoaded;
            Closed += (s, e) =>
            {
                try { if (_runCts != null) _runCts.Cancel(); } catch { }
                _cdp.Dispose();
            };
        }

        private static SolidColorBrush BrushFromHex(string hex)
        {
            SolidColorBrush b = (SolidColorBrush)new BrushConverter().ConvertFromString(hex);
            b.Freeze();
            return b;
        }

        private void BuildLayout()
        {
            Grid root = new Grid();
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto }); // Header
            root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) }); // Body

            root.Children.Add(BuildTopHeader());

            Grid body = new Grid();
            Grid.SetRow(body, 1);
            body.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(350) }); // Left Explorer
            body.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) }); // Right Studio

            UIElement leftExplorer = BuildLeftExplorer();
            Grid.SetColumn(leftExplorer, 0);
            body.Children.Add(leftExplorer);

            UIElement rightWorkspace = BuildRightWorkspace();
            Grid.SetColumn(rightWorkspace, 1);
            body.Children.Add(rightWorkspace);

            root.Children.Add(body);
            Content = root;
        }

        private UIElement BuildTopHeader()
        {
            Border header = new Border
            {
                Background = BgPanel,
                BorderBrush = BorderSubtle,
                BorderThickness = new Thickness(0, 0, 0, 1),
                Padding = new Thickness(16, 8, 16, 8)
            };

            Grid g = new Grid();
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            StackPanel row1 = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };
            row1.Children.Add(new TextBlock
            {
                Text = "🎬 FLUXO VÍDEO IA STUDIO",
                FontSize = 16,
                FontWeight = FontWeights.Bold,
                Foreground = TextPrimary,
                VerticalAlignment = VerticalAlignment.Center
            });
            g.Children.Add(row1);

            StackPanel rightControls = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };

            _lblCdpStatus = new TextBlock
            {
                Text = "● Chrome: Desconectado",
                Foreground = AccentAmber,
                FontSize = 12,
                FontWeight = FontWeights.SemiBold,
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(0, 0, 12, 0)
            };
            rightControls.Children.Add(_lblCdpStatus);

            if (PipelineConfig.IsMasterDeveloperPc())
            {
                Button btnRemoteUpdate = CreateStyledButton("🔄 Publicar Atualização", BrushFromHex("#0284C7"), Brushes.White, new Thickness(11, 6, 11, 6));
                btnRemoteUpdate.FontWeight = FontWeights.Bold;
                btnRemoteUpdate.Margin = new Thickness(0, 0, 8, 0);
                btnRemoteUpdate.ToolTip = "Exclusivo deste PC Principal: Publicar atualização para os outros PCs via GitHub";
                btnRemoteUpdate.Click += (s, e) => ShowRemoteUpdateDialog();
                rightControls.Children.Add(btnRemoteUpdate);
            }

            _btnConnectCdp = CreateStyledButton("🔗 Conectar Chrome", BgCard, TextPrimary, new Thickness(11, 6, 11, 6));
            _btnConnectCdp.Click += async (s, e) => await TestChromeCdpConnectionAsync();
            rightControls.Children.Add(_btnConnectCdp);

            Grid.SetColumn(rightControls, 1);
            g.Children.Add(rightControls);

            header.Child = g;
            return header;
        }

        private UIElement BuildLeftExplorer()
        {
            Border panel = new Border
            {
                Background = BgPanel,
                BorderBrush = BorderSubtle,
                BorderThickness = new Thickness(0, 0, 1, 0),
                Padding = new Thickness(14)
            };

            Grid g = new Grid();
            g.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto }); // Title + Refresh
            g.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto }); // Genre filter
            g.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto }); // Search
            g.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) }); // Stories list
            g.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto }); // Episode selector

            // Row 0
            Grid topBar = new Grid { Margin = new Thickness(0, 0, 0, 8) };
            topBar.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            topBar.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            topBar.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            topBar.Children.Add(new TextBlock
            {
                Text = "HISTÓRIAS DO ANTIGRAVITY",
                FontSize = 12,
                FontWeight = FontWeights.Bold,
                Foreground = TextSecondary,
                VerticalAlignment = VerticalAlignment.Center
            });

            Button btnBrowse = CreateStyledButton("📂 Pasta...", BgCard, TextPrimary, new Thickness(8, 4, 8, 4));
            btnBrowse.Margin = new Thickness(0, 0, 6, 0);
            btnBrowse.Click += OnBrowseCustomEpisodeFolder;
            Grid.SetColumn(btnBrowse, 1);
            topBar.Children.Add(btnBrowse);

            Button btnRefresh = CreateStyledButton("🔄", BgCard, TextPrimary, new Thickness(8, 4, 8, 4));
            btnRefresh.ToolTip = "Recarregar pastas de Novela e Terror";
            btnRefresh.Click += (s, e) => RefreshStoriesList();
            Grid.SetColumn(btnRefresh, 2);
            topBar.Children.Add(btnRefresh);

            g.Children.Add(topBar);

            // Row 1: Genre Filter
            _cmbGenreFilter = new ComboBox
            {
                Margin = new Thickness(0, 0, 0, 8),
                Padding = new Thickness(8, 6, 8, 6),
                FontSize = 12.5
            };
            _cmbGenreFilter.Items.Add("Todos os Gêneros (Novela + Terror)");
            _cmbGenreFilter.Items.Add("Novela / Reflexão (_videos de reflexão)");
            _cmbGenreFilter.Items.Add("Terror (_Videos terror)");
            _cmbGenreFilter.SelectedIndex = 0;
            _cmbGenreFilter.SelectionChanged += (s, e) => ApplyStoryFilter();
            Grid.SetRow(_cmbGenreFilter, 1);
            g.Children.Add(_cmbGenreFilter);

            // Row 2: Search
            _txtSearch = CreateStyledTextBox("Filtrar história pelo nome...");
            _txtSearch.Margin = new Thickness(0, 0, 0, 8);
            _txtSearch.TextChanged += (s, e) => ApplyStoryFilter();
            Grid.SetRow(_txtSearch, 2);
            g.Children.Add(_txtSearch);

            // Row 3: ListBox of Stories
            _lstStories = new ListBox
            {
                Background = BgInput,
                Foreground = TextPrimary,
                BorderBrush = BorderSubtle,
                BorderThickness = new Thickness(1),
                Padding = new Thickness(4)
            };
            _lstStories.SelectionChanged += OnStorySelectionChanged;
            Grid.SetRow(_lstStories, 3);
            g.Children.Add(_lstStories);

            // Row 4: Episodes panel (EP.1 / EP.2 / EP.3)
            Border epBox = new Border
            {
                Background = BgCard,
                BorderBrush = BorderSubtle,
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(8),
                Padding = new Thickness(10),
                Margin = new Thickness(0, 10, 0, 0)
            };
            StackPanel epStack = new StackPanel();
            epStack.Children.Add(new TextBlock
            {
                Text = "SELECIONE O EPISÓDIO (EP.1 / EP.2 / EP.3):",
                FontSize = 11.5,
                FontWeight = FontWeights.Bold,
                Foreground = TextSecondary,
                Margin = new Thickness(0, 0, 0, 6)
            });
            _pnlEpisodeButtons = new StackPanel { Orientation = Orientation.Vertical };
            epStack.Children.Add(_pnlEpisodeButtons);
            epBox.Child = epStack;
            Grid.SetRow(epBox, 4);
            g.Children.Add(epBox);

            panel.Child = g;
            return panel;
        }

        private UIElement BuildRightWorkspace()
        {
            Grid g = new Grid { Margin = new Thickness(14, 10, 14, 12) };
            g.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto }); // Barra Única: Episódio Selecionado + Botões de Ação
            g.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto }); // 4 Etapas Compactas
            g.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) }); // Abas

            // Row 0: Barra Unificada (Episódio Selecionado à esquerda + Ações principais à direita)
            Border commandBar = new Border
            {
                Background = BgPanel,
                BorderBrush = BorderSubtle,
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(8),
                Padding = new Thickness(12, 8, 12, 8),
                Margin = new Thickness(0, 0, 0, 8)
            };
            Grid cmdGrid = new Grid();
            cmdGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            cmdGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            _lblSelectedContext = new TextBlock
            {
                Text = "Selecione uma história e episódio à esquerda.",
                FontSize = 13,
                FontWeight = FontWeights.SemiBold,
                Foreground = TextPrimary,
                VerticalAlignment = VerticalAlignment.Center,
                TextTrimming = TextTrimming.CharacterEllipsis,
                Margin = new Thickness(0, 0, 12, 0)
            };
            Grid.SetColumn(_lblSelectedContext, 0);
            cmdGrid.Children.Add(_lblSelectedContext);

            StackPanel actionBtns = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };

            _btnContinueReview = CreateStyledButton("✅ Confirmar Assets", AccentAmber, Brushes.Black, new Thickness(12, 7, 12, 7));
            _btnContinueReview.FontWeight = FontWeights.Bold;
            _btnContinueReview.Visibility = Visibility.Collapsed;
            _btnContinueReview.Margin = new Thickness(0, 0, 8, 0);
            _btnContinueReview.Click += (s, e) =>
            {
                if (_reviewContinueTcs != null)
                    _reviewContinueTcs.TrySetResult(true);
            };
            actionBtns.Children.Add(_btnContinueReview);

            _btnRunAllEpisodes = CreateStyledButton("⏩ Fila (EP.1 ➔ EP.3)", BgCard, TextPrimary, new Thickness(12, 7, 12, 7));
            _btnRunAllEpisodes.FontWeight = FontWeights.SemiBold;
            _btnRunAllEpisodes.ToolTip = "Executar EP.1, EP.2 e EP.3 em sequência";
            _btnRunAllEpisodes.Margin = new Thickness(0, 0, 8, 0);
            _btnRunAllEpisodes.Click += async (s, e) => await ExecuteFullStoryQueueAsync();
            actionBtns.Children.Add(_btnRunAllEpisodes);

            _btnReloadResume = CreateStyledButton("🔄 Recarregar e Continuar", AccentBlue, Brushes.White, new Thickness(12, 7, 12, 7));
            _btnReloadResume.FontWeight = FontWeights.Bold;
            _btnReloadResume.ToolTip = "Recarrega a aba atual do Chrome (F5) e retoma o processo exatamente a partir da última ação registrada no histórico";
            _btnReloadResume.Visibility = Visibility.Collapsed;
            _btnReloadResume.Margin = new Thickness(0, 0, 8, 0);
            _btnReloadResume.Click += (s, e) =>
            {
                if (_isRunning && _cdp != null)
                {
                    LastActionCheckpoint cp = LastActionHistoryStore.Current;
                    string summary = cp != null
                        ? string.Format("{0} -> {1} ({2})", cp.StageName, cp.SubActionDescription, cp.TargetItemName ?? "em andamento")
                        : "etapa ativa";
                    AppendLog(string.Format("[Recuperação | Histórico] Botão 'Recarregar e Continuar' acionado! Recarregando página e retomando de: {0}...", summary));
                    _cdp.RequestReloadAndResume("Acionado manualmente pelo botão 'Recarregar e Continuar'");
                }
            };
            actionBtns.Children.Add(_btnReloadResume);

            _btnStop = CreateStyledButton("▶ INICIAR", AccentGreen, Brushes.White, new Thickness(18, 7, 18, 7));
            _btnStop.FontWeight = FontWeights.Bold;
            _btnStop.IsEnabled = true;
            _btnStop.Click += async (s, e) =>
            {
                if (_isRunning)
                {
                    AppendLog("[Sistema] Solicitação de parada enviada pelo usuário...");
                    if (_runCts != null)
                    {
                        try { _runCts.Cancel(); } catch { }
                    }
                    if (_cdp != null)
                    {
                        _cdp.CancelCurrentActivity();
                    }
                    if (_reviewContinueTcs != null)
                    {
                        _reviewContinueTcs.TrySetCanceled();
                    }
                }
                else
                {
                    await ExecuteSelectedStagesAsync(
                        _chkStageGrok.IsChecked == true,
                        _chkStageFlow.IsChecked == true,
                        _chkStageEleven.IsChecked == true,
                        _chkStageCapCut.IsChecked == true);
                }
            };
            actionBtns.Children.Add(_btnStop);

            Grid.SetColumn(actionBtns, 1);
            cmdGrid.Children.Add(actionBtns);
            commandBar.Child = cmdGrid;
            g.Children.Add(commandBar);

            // Row 1: 4 Stage Cards Compactos
            UniformGrid stagesGrid = new UniformGrid { Columns = 4, Margin = new Thickness(0, 0, 0, 8) };
            stagesGrid.Children.Add(BuildStageCard(
                "1. Grok Imagine",
                "",
                out _chkStageGrok,
                out _badgeGrok,
                "▶ Só Grok",
                async () => await ExecuteSelectedStagesAsync(true, false, false, false)));

            stagesGrid.Children.Add(BuildStageCard(
                "2. Google Flow",
                "",
                out _chkStageFlow,
                out _badgeFlow,
                "▶ Só Flow",
                async () => await ExecuteSelectedStagesAsync(false, true, false, false)));

            stagesGrid.Children.Add(BuildStageCard(
                "3. ElevenLabs",
                "",
                out _chkStageEleven,
                out _badgeEleven,
                "▶ Só Voz",
                async () => await ExecuteSelectedStagesAsync(false, false, true, false)));

            stagesGrid.Children.Add(BuildStageCard(
                "4. CapCut",
                "",
                out _chkStageCapCut,
                out _badgeCapCut,
                "▶ Só CapCut",
                async () => await ExecuteSelectedStagesAsync(false, false, false, true)));

            Grid.SetRow(stagesGrid, 1);
            g.Children.Add(stagesGrid);

            // Row 2: Workspace Tabs
            TabControl tabs = new TabControl
            {
                Background = BgPanel,
                BorderBrush = BorderSubtle,
                Foreground = TextPrimary,
                Padding = new Thickness(6)
            };

            tabs.Items.Add(BuildConsoleTab());
            tabs.Items.Add(BuildAssetsVisualTab());
            tabs.Items.Add(BuildTakesAndOutfitsTab());
            tabs.Items.Add(BuildPromptsInspectorTab());
            tabs.Items.Add(BuildSettingsTab());

            Grid.SetRow(tabs, 2);
            g.Children.Add(tabs);

            return g;
        }

        private UIElement BuildStageCard(
            string title,
            string subtitle,
            out CheckBox chkOut,
            out TextBlock badgeOut,
            string quickBtnText,
            Func<Task> quickAction)
        {
            Border card = new Border
            {
                Background = BgCard,
                BorderBrush = BorderSubtle,
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(8),
                Padding = new Thickness(10, 7, 10, 7),
                Margin = new Thickness(3, 0, 3, 0)
            };

            StackPanel sp = new StackPanel();

            DockPanel topRow = new DockPanel { Margin = new Thickness(0, 0, 0, 5) };
            chkOut = new CheckBox
            {
                IsChecked = true,
                Content = new TextBlock
                {
                    Text = title,
                    FontWeight = FontWeights.Bold,
                    FontSize = 12.5,
                    Foreground = TextPrimary
                },
                VerticalAlignment = VerticalAlignment.Center
            };
            topRow.Children.Add(chkOut);
            sp.Children.Add(topRow);

            Grid bottomRow = new Grid();
            bottomRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            bottomRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            badgeOut = new TextBlock
            {
                Text = "AGUARDANDO",
                FontSize = 10.5,
                FontWeight = FontWeights.Bold,
                Foreground = TextSecondary,
                VerticalAlignment = VerticalAlignment.Center
            };
            bottomRow.Children.Add(badgeOut);

            Button btnQuick = CreateStyledButton(quickBtnText, BgPanel, TextPrimary, new Thickness(7, 2, 7, 2));
            btnQuick.FontSize = 10.5;
            btnQuick.Click += async (s, e) => await quickAction();
            Grid.SetColumn(btnQuick, 1);
            bottomRow.Children.Add(btnQuick);

            sp.Children.Add(bottomRow);
            card.Child = sp;
            return card;
        }

        private TabItem BuildConsoleTab()
        {
            TabItem tab = new TabItem { Header = "  🖥 Console  " };
            Grid g = new Grid { Margin = new Thickness(6) };
            g.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            g.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
            g.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

            // Top bar: Progress + CapCut project name
            Grid top = new Grid { Margin = new Thickness(0, 0, 0, 8) };
            top.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            top.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            StackPanel progStack = new StackPanel { Margin = new Thickness(0, 0, 14, 0) };
            _lblProgressStep = new TextBlock
            {
                Text = "Pronto para executar.",
                FontSize = 12,
                FontWeight = FontWeights.SemiBold,
                Foreground = TextPrimary,
                Margin = new Thickness(0, 0, 0, 4)
            };
            progStack.Children.Add(_lblProgressStep);

            _progressBar = new ProgressBar
            {
                Height = 8,
                Minimum = 0,
                Maximum = 100,
                Value = 0,
                Background = BgInput,
                Foreground = AccentPrimary
            };
            progStack.Children.Add(_progressBar);
            top.Children.Add(progStack);

            StackPanel capProjStack = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };
            capProjStack.Children.Add(new TextBlock
            {
                Text = "Projeto CapCut:",
                Foreground = TextSecondary,
                FontSize = 12,
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(0, 0, 6, 0)
            });
            _txtCapCutProjName = CreateStyledTextBox("");
            _txtCapCutProjName.Width = 220;
            capProjStack.Children.Add(_txtCapCutProjName);
            Grid.SetColumn(capProjStack, 1);
            top.Children.Add(capProjStack);

            g.Children.Add(top);

            // Center Log Console
            _txtLog = new TextBox
            {
                Background = BrushFromHex("#090B10"),
                Foreground = BrushFromHex("#D1FAE5"),
                BorderBrush = BorderSubtle,
                BorderThickness = new Thickness(1),
                FontFamily = new FontFamily("Consolas"),
                FontSize = 12.5,
                IsReadOnly = true,
                TextWrapping = TextWrapping.Wrap,
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                Padding = new Thickness(10)
            };
            Grid.SetRow(_txtLog, 1);
            g.Children.Add(_txtLog);

            // Bottom Quick Folder Tools
            StackPanel bottomTools = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin = new Thickness(0, 8, 0, 0)
            };

            Button btnOpenEp = CreateStyledButton("📁 Pasta Episódio", BgCard, TextPrimary, new Thickness(10, 6, 10, 6));
            btnOpenEp.Margin = new Thickness(0, 0, 8, 0);
            btnOpenEp.Click += (s, e) => OpenDirectoryInExplorer(_selectedEpisode != null ? _selectedEpisode.EpisodePath : "");
            bottomTools.Children.Add(btnOpenEp);

            Button btnOpenAssets = CreateStyledButton("🖼 Pasta Assets", BgCard, TextPrimary, new Thickness(10, 6, 10, 6));
            btnOpenAssets.Margin = new Thickness(0, 0, 8, 0);
            btnOpenAssets.Click += (s, e) => OpenDirectoryInExplorer(_selectedEpisode != null ? _selectedEpisode.AssetsDir : "");
            bottomTools.Children.Add(btnOpenAssets);

            Button btnOpenTakes = CreateStyledButton("🎬 Pasta Takes", BgCard, TextPrimary, new Thickness(10, 6, 10, 6));
            btnOpenTakes.Margin = new Thickness(0, 0, 8, 0);
            btnOpenTakes.Click += (s, e) => OpenDirectoryInExplorer(_selectedEpisode != null ? _selectedEpisode.TakesDir : "");
            bottomTools.Children.Add(btnOpenTakes);

            Button btnManualAudio = CreateStyledButton("✂ Travar Silêncio (MP3 ➔ WAV)", BgCard, TextPrimary, new Thickness(10, 6, 10, 6));
            btnManualAudio.Margin = new Thickness(0, 0, 8, 0);
            btnManualAudio.Click += OnManualSilenceProcessClick;
            bottomTools.Children.Add(btnManualAudio);

            Button btnClearLog = CreateStyledButton("🧹 Limpar", BgCard, TextSecondary, new Thickness(10, 6, 10, 6));
            btnClearLog.Click += (s, e) => _txtLog.Clear();
            bottomTools.Children.Add(btnClearLog);

            Grid.SetRow(bottomTools, 2);
            g.Children.Add(bottomTools);

            tab.Content = g;
            return tab;
        }

        private TabItem BuildAssetsVisualTab()
        {
            TabItem tab = new TabItem { Header = "  🖼 Personagens & Cenários  " };
            Grid g = new Grid { Margin = new Thickness(6) };
            g.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            g.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });

            DockPanel bar = new DockPanel { Margin = new Thickness(0, 0, 0, 8) };
            _lblAssetsSummary = new TextBlock
            {
                Text = "Personagens e Cenários do episódio:",
                FontSize = 12.5,
                Foreground = TextPrimary,
                VerticalAlignment = VerticalAlignment.Center
            };
            bar.Children.Add(_lblAssetsSummary);

            StackPanel btns = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };

            Button btnImportCast = CreateStyledButton("👥 Importar Elenco", BrushFromHex("#7C3AED"), Brushes.White, new Thickness(10, 5, 10, 5));
            btnImportCast.Margin = new Thickness(0, 0, 8, 0);
            btnImportCast.Click += OnImportCastFromAnotherStoryClick;
            btns.Children.Add(btnImportCast);

            Button btnRunOcr = CreateStyledButton("🔍 Conferir OCR", AccentBlue, Brushes.White, new Thickness(10, 5, 10, 5));
            btnRunOcr.Margin = new Thickness(0, 0, 8, 0);
            btnRunOcr.Click += async (s, e) => await InspectCurrentAssetsWithOcrAsync();
            btns.Children.Add(btnRunOcr);

            Button btnReloadGrid = CreateStyledButton("🔄 Atualizar", BgCard, TextPrimary, new Thickness(10, 5, 10, 5));
            btnReloadGrid.Click += (s, e) => RefreshAssetsGallery(null);
            btns.Children.Add(btnReloadGrid);

            DockPanel.SetDock(btns, Dock.Right);
            bar.Children.Add(btns);
            g.Children.Add(bar);

            ScrollViewer sv = new ScrollViewer
            {
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                Background = BgInput
            };
            _wrapAssets = new WrapPanel { Margin = new Thickness(8) };
            sv.Content = _wrapAssets;
            Grid.SetRow(sv, 1);
            g.Children.Add(sv);

            tab.Content = g;
            return tab;
        }

        private TabItem BuildTakesAndOutfitsTab()
        {
            TabItem tab = new TabItem { Header = "  🎬 Takes & Roupas  " };
            Grid g = new Grid { Margin = new Thickness(6) };
            g.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            g.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });

            DockPanel topBar = new DockPanel { Margin = new Thickness(0, 0, 0, 8) };
            _lblTakesManagerSummary = new TextBlock
            {
                Text = "Takes do episódio:",
                FontSize = 12.5,
                FontWeight = FontWeights.SemiBold,
                Foreground = TextPrimary,
                VerticalAlignment = VerticalAlignment.Center
            };
            topBar.Children.Add(_lblTakesManagerSummary);

            StackPanel rightBtns = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };

            Button btnToggleAll = CreateStyledButton("☑ Todos", BgCard, TextPrimary, new Thickness(10, 5, 10, 5));
            btnToggleAll.Margin = new Thickness(0, 0, 8, 0);
            btnToggleAll.Click += (s, e) =>
            {
                bool anyUnchecked = _takeSelectionChecks.Values.Any(c => c.IsChecked != true);
                foreach (CheckBox chk in _takeSelectionChecks.Values)
                    chk.IsChecked = anyUnchecked;
            };
            rightBtns.Children.Add(btnToggleAll);

            Button btnRegenSelectedFlow = CreateStyledButton("🌊 Regerar no Flow", AccentBlue, Brushes.White, new Thickness(10, 5, 10, 5));
            btnRegenSelectedFlow.FontWeight = FontWeights.Bold;
            btnRegenSelectedFlow.Margin = new Thickness(0, 0, 8, 0);
            btnRegenSelectedFlow.Click += async (s, e) => await RegenerateCheckedTakesAsync(false);
            rightBtns.Children.Add(btnRegenSelectedFlow);

            Button btnRegenSelectedGrok = CreateStyledButton("🚀 Regerar no Grok 🪄", AccentPrimary, Brushes.White, new Thickness(10, 5, 10, 5));
            btnRegenSelectedGrok.FontWeight = FontWeights.Bold;
            btnRegenSelectedGrok.Margin = new Thickness(0, 0, 8, 0);
            btnRegenSelectedGrok.Click += async (s, e) => await RegenerateCheckedTakesAsync(true);
            rightBtns.Children.Add(btnRegenSelectedGrok);

            Button btnRefreshTakes = CreateStyledButton("🔄 Atualizar", BgCard, TextPrimary, new Thickness(10, 5, 10, 5));
            btnRefreshTakes.Click += (s, e) => RefreshTakesManagerList();
            rightBtns.Children.Add(btnRefreshTakes);

            DockPanel.SetDock(rightBtns, Dock.Right);
            topBar.Children.Add(rightBtns);
            g.Children.Add(topBar);

            ScrollViewer sv = new ScrollViewer
            {
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                Background = BgInput
            };
            _pnlTakesList = new StackPanel { Margin = new Thickness(8) };
            sv.Content = _pnlTakesList;
            Grid.SetRow(sv, 1);
            g.Children.Add(sv);

            tab.Content = g;
            return tab;
        }

        private TabItem BuildPromptsInspectorTab()
        {
            TabItem tab = new TabItem { Header = "  📝 Prompts & Voz  " };
            Grid g = new Grid { Margin = new Thickness(6) };
            g.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            g.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });

            DockPanel topBar = new DockPanel { Margin = new Thickness(0, 0, 0, 8) };
            topBar.Children.Add(new TextBlock
            {
                Text = "Prompts e voz do Narrador:",
                Foreground = TextSecondary,
                FontSize = 12.5,
                VerticalAlignment = VerticalAlignment.Center
            });

            StackPanel rightControls = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };

            rightControls.Children.Add(new TextBlock
            {
                Text = "🎙 Voz:",
                FontSize = 12,
                FontWeight = FontWeights.SemiBold,
                Foreground = TextPrimary,
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(0, 0, 6, 0)
            });

            _cmbElevenVoiceQuick = new ComboBox
            {
                Width = 260,
                FontSize = 11.5,
                Padding = new Thickness(6, 4, 6, 4),
                Margin = new Thickness(0, 0, 6, 0)
            };
            _cmbElevenVoiceQuick.SelectionChanged += OnQuickVoiceSelectionChanged;
            rightControls.Children.Add(_cmbElevenVoiceQuick);

            Button btnAddVoiceQuick = CreateStyledButton("➕ Voz", BgCard, TextPrimary, new Thickness(8, 5, 8, 5));
            btnAddVoiceQuick.Margin = new Thickness(0, 0, 8, 0);
            btnAddVoiceQuick.Click += (s, e) => ShowAddElevenLabsVoiceDialog();
            rightControls.Children.Add(btnAddVoiceQuick);

            Button btnSavePrompts = CreateStyledButton("💾 Salvar Prompts", AccentGreen, Brushes.White, new Thickness(12, 6, 12, 6));
            btnSavePrompts.Click += OnSavePromptsClick;
            rightControls.Children.Add(btnSavePrompts);

            DockPanel.SetDock(rightControls, Dock.Right);
            topBar.Children.Add(rightControls);
            g.Children.Add(topBar);

            Grid cols = new Grid();
            cols.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            cols.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            cols.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(0.85, GridUnitType.Star) });

            cols.Children.Add(BuildPromptColumn("1. Grok Imagine (prompt_grok_passo1_e_2.txt)", out _txtGrokPrompt, 0));
            cols.Children.Add(BuildPromptColumn("2. Google Flow (prompt_flow_passo3.txt)", out _txtFlowPrompt, 1));
            cols.Children.Add(BuildPromptColumn("3. Texto Unificado do Narrador (ElevenLabs)", out _txtNarratorPrompt, 2));

            Grid.SetRow(cols, 1);
            g.Children.Add(cols);
            tab.Content = g;
            return tab;
        }

        private UIElement BuildPromptColumn(string label, out TextBox boxOut, int col)
        {
            Grid g = new Grid { Margin = new Thickness(4, 0, 4, 0) };
            g.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            g.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });

            g.Children.Add(new TextBlock
            {
                Text = label,
                FontSize = 12,
                FontWeight = FontWeights.Bold,
                Foreground = TextPrimary,
                Margin = new Thickness(0, 0, 0, 4)
            });

            boxOut = new TextBox
            {
                Background = BgInput,
                Foreground = TextPrimary,
                BorderBrush = BorderSubtle,
                BorderThickness = new Thickness(1),
                FontFamily = new FontFamily("Consolas"),
                FontSize = 11.5,
                AcceptsReturn = true,
                TextWrapping = TextWrapping.Wrap,
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                Padding = new Thickness(8)
            };
            Grid.SetRow(boxOut, 1);
            g.Children.Add(boxOut);
            Grid.SetColumn(g, col);
            return g;
        }

        private TabItem BuildSettingsTab()
        {
            TabItem tab = new TabItem { Header = "  ⚙ Perfis Chrome, Contas Grok & Vozes  " };
            ScrollViewer sv = new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto };
            StackPanel sp = new StackPanel { Margin = new Thickness(12), MaxWidth = 960, HorizontalAlignment = HorizontalAlignment.Left };

            sp.Children.Add(new TextBlock
            {
                Text = "OPÇÕES DE EXECUÇÃO DA ESTEIRA",
                FontSize = 13,
                FontWeight = FontWeights.Bold,
                Foreground = TextPrimary,
                Margin = new Thickness(0, 0, 0, 8)
            });

            _chkPreserveAssets = new CheckBox
            {
                IsChecked = _config.PreserveExistingAssets,
                Content = new TextBlock { Text = "🔒 Trava de Elenco: Preservar Personagens/Assets .jpg já existentes na pasta assets\\ (gerar no Grok SOMENTE os ausentes)", Foreground = TextPrimary, FontWeight = FontWeights.SemiBold },
                Margin = new Thickness(0, 0, 0, 8)
            };
            sp.Children.Add(_chkPreserveAssets);

            _chkArchiveOldTakes = new CheckBox
            {
                IsChecked = _config.ArchiveOldTakesBeforeRemake,
                Content = new TextBlock { Text = "🧹 Modo Refazer Seguro: Mover takes/áudios antigos para takes\\_backup_<data> antes de gerar novos vídeos no Flow", Foreground = TextPrimary },
                Margin = new Thickness(0, 0, 0, 8)
            };
            sp.Children.Add(_chkArchiveOldTakes);

            _chkPauseAfterGrok = new CheckBox
            {
                IsChecked = _config.PauseAfterGrokForVisualReview,
                Content = new TextBlock { Text = "Pausar após o Grok Imagine para conferência visual manual das miniaturas antes de iniciar o Google Flow", Foreground = TextPrimary },
                Margin = new Thickness(0, 0, 0, 8)
            };
            sp.Children.Add(_chkPauseAfterGrok);

            _chkReuseHook = new CheckBox
            {
                IsChecked = _config.ReuseEp1HookTake01,
                Content = new TextBlock { Text = "Regra 22: Reaproveitar automaticamente Take_01.mp4 (Gancho de 10s) do EP.1 nas continuações EP.2 e EP.3 quando aplicável", Foreground = TextPrimary },
                Margin = new Thickness(0, 0, 0, 8)
            };
            sp.Children.Add(_chkReuseHook);

            _chkLaunchCapCut = new CheckBox
            {
                IsChecked = _config.LaunchCapCutDesktop,
                Content = new TextBlock { Text = "Abrir o CapCut Desktop automaticamente ao concluir a montagem da Timeline", Foreground = TextPrimary },
                Margin = new Thickness(0, 0, 0, 16)
            };
            sp.Children.Add(_chkLaunchCapCut);

            // PAINEL VISUAL DE CONTAS GROK (SUGESTÃO D)
            Border grokStatusBox = new Border
            {
                Background = BgCard,
                BorderBrush = BorderSubtle,
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(8),
                Padding = new Thickness(12),
                Margin = new Thickness(0, 0, 0, 14)
            };
            StackPanel grokStatusStack = new StackPanel();
            DockPanel grokHeaderRow = new DockPanel { Margin = new Thickness(0, 0, 0, 8) };
            grokHeaderRow.Children.Add(new TextBlock
            {
                Text = "STATUS DAS CONTAS / PERFIS DO GROK IMAGINE (DETECÇÃO DE LIMITE DE USO)",
                FontSize = 12.5,
                FontWeight = FontWeights.Bold,
                Foreground = TextPrimary,
                VerticalAlignment = VerticalAlignment.Center
            });

            Button btnCheckGrokQuotas = CreateStyledButton("🔍 Verificar Créditos / Limite das Contas Agora", AccentBlue, Brushes.White, new Thickness(10, 5, 10, 5));
            btnCheckGrokQuotas.HorizontalAlignment = HorizontalAlignment.Right;
            btnCheckGrokQuotas.Click += async (s, e) => await CheckGrokAccountsStatusFromUiAsync();
            DockPanel.SetDock(btnCheckGrokQuotas, Dock.Right);
            grokHeaderRow.Children.Add(btnCheckGrokQuotas);
            grokStatusStack.Children.Add(grokHeaderRow);

            _wrapGrokProfileBadges = new WrapPanel { Margin = new Thickness(0, 0, 0, 8) };
            grokStatusStack.Children.Add(_wrapGrokProfileBadges);

            StackPanel addProfileRow = new StackPanel { Orientation = Orientation.Horizontal };
            addProfileRow.Children.Add(new TextBlock
            {
                Text = "Adicionar Novo Perfil Chrome (ex: Profile 68):",
                FontSize = 12,
                Foreground = TextSecondary,
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(0, 0, 8, 0)
            });
            _txtNewGrokProfile = CreateStyledTextBox("Ex: Profile 68");
            _txtNewGrokProfile.Width = 170;
            _txtNewGrokProfile.Margin = new Thickness(0, 0, 8, 0);
            addProfileRow.Children.Add(_txtNewGrokProfile);

            Button btnAddProfile = CreateStyledButton("➕ Adicionar Perfil Grok", AccentPrimary, Brushes.White, new Thickness(10, 5, 10, 5));
            btnAddProfile.Click += OnAddGrokProfileClick;
            addProfileRow.Children.Add(btnAddProfile);

            grokStatusStack.Children.Add(addProfileRow);
            grokStatusBox.Child = grokStatusStack;
            sp.Children.Add(grokStatusBox);

            // SELETOR DE VOZES FAVORITAS DO ELEVENLABS (SUGESTÃO E)
            Border voiceBox = new Border
            {
                Background = BgCard,
                BorderBrush = BorderSubtle,
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(8),
                Padding = new Thickness(12),
                Margin = new Thickness(0, 0, 0, 14)
            };
            StackPanel voiceStack = new StackPanel();
            voiceStack.Children.Add(new TextBlock
            {
                Text = "🎙 VOZES FAVORITAS DO ELEVENLABS (SELEÇÃO COM 1 CLIQUE)",
                FontSize = 12.5,
                FontWeight = FontWeights.Bold,
                Foreground = TextPrimary,
                Margin = new Thickness(0, 0, 0, 8)
            });

            StackPanel voiceRow = new StackPanel { Orientation = Orientation.Horizontal };
            _cmbElevenVoiceSettings = new ComboBox
            {
                Width = 420,
                FontSize = 12,
                Padding = new Thickness(8, 5, 8, 5),
                Margin = new Thickness(0, 0, 10, 0)
            };
            _cmbElevenVoiceSettings.SelectionChanged += OnSettingsVoiceSelectionChanged;
            voiceRow.Children.Add(_cmbElevenVoiceSettings);

            Button btnAddVoice = CreateStyledButton("➕ Cadastrar Nova Voz Favorita...", AccentPrimary, Brushes.White, new Thickness(12, 5, 12, 5));
            btnAddVoice.Click += (s, e) => ShowAddElevenLabsVoiceDialog();
            voiceRow.Children.Add(btnAddVoice);

            voiceStack.Children.Add(voiceRow);
            voiceBox.Child = voiceStack;
            sp.Children.Add(voiceBox);

            sp.Children.Add(new TextBlock
            {
                Text = "MAPEAMENTO OFICIAL DE PERFIS DO GOOGLE CHROME (/fluxo-video-ia)",
                FontSize = 13,
                FontWeight = FontWeights.Bold,
                Foreground = TextPrimary,
                Margin = new Thickness(0, 0, 0, 8)
            });

            StackPanel detectProfRow = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 0, 0, 10) };
            Button btnDetectProfiles = CreateStyledButton("🔍 Detectar e Selecionar Perfis do Chrome deste PC (Grok / Flow / ElevenLabs)", BrushFromHex("#7C3AED"), Brushes.White, new Thickness(14, 7, 14, 7));
            btnDetectProfiles.FontWeight = FontWeights.Bold;
            btnDetectProfiles.Margin = new Thickness(0, 0, 10, 0);
            btnDetectProfiles.Click += (s, e) => ShowChromeProfileSelectorDialog();
            detectProfRow.Children.Add(btnDetectProfiles);

            Button btnOpenInspect = CreateStyledButton("🔧 Abrir chrome://inspect (Ativar Depuração Remota)", BgCard, TextPrimary, new Thickness(12, 7, 12, 7));
            btnOpenInspect.Click += (s, e) =>
            {
                string prof = _config.GrokProfiles.Count > 0 ? _config.GrokProfiles[0] : "Default";
                _cdp.LaunchChromeProfileWindow(prof, "chrome://inspect/#remote-debugging");
                AppendLog("[Chrome CDP] Aviso: Na tela chrome://inspect/#remote-debugging, marque a caixinha 'Discover network targets' para ativar a porta 9222.");
            };
            detectProfRow.Children.Add(btnOpenInspect);
            sp.Children.Add(detectProfRow);

            sp.Children.Add(BuildLabeledSetting("Perfis Autorizados Grok Imagine (ordem de fallback automático):",
                string.Join(", ", _config.GrokProfiles), out _txtGrokProfiles));

            sp.Children.Add(BuildLabeledSetting("Perfil Google Flow (GUILHERME - Google AI Ultra):",
                _config.FlowProfile, out _txtFlowProfile));

            sp.Children.Add(BuildLabeledSetting("URL Fixa do Projeto Google Flow:",
                _config.FlowProjectUrl, out _txtFlowUrl));

            sp.Children.Add(BuildLabeledSetting("Perfis Autorizados ElevenLabs (Principal -> Fallback):",
                string.Join(", ", _config.ElevenLabsProfiles), out _txtElevenProfiles));

            sp.Children.Add(BuildLabeledSetting("URL Ativa do ElevenLabs (atualizada automaticamente ao trocar a Voz Favorita acima):",
                _config.ElevenLabsUrl, out _txtElevenUrl));

            sp.Children.Add(new TextBlock
            {
                Text = "DIRETÓRIOS DAS HISTÓRIAS E VÍDEOS NO COMPUTADOR",
                FontSize = 13,
                FontWeight = FontWeights.Bold,
                Foreground = TextPrimary,
                Margin = new Thickness(0, 12, 0, 8)
            });

            sp.Children.Add(BuildLabeledSetting("Pasta Raiz de Novela / Reflexão (_videos de reflexão):",
                string.IsNullOrEmpty(_config.NovelaRootDir) ? EpisodeParser.GetNovelaRoot() : _config.NovelaRootDir,
                out _txtNovelaRootDir));

            sp.Children.Add(BuildLabeledSetting("Pasta Raiz de Terror (_Videos terror):",
                string.IsNullOrEmpty(_config.TerrorRootDir) ? EpisodeParser.GetTerrorRoot() : _config.TerrorRootDir,
                out _txtTerrorRootDir));

            StackPanel dirBtns = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 2, 0, 10) };
            Button btnOpenNovelaDir = CreateStyledButton("📂 Criar / Abrir Pasta Novela", BgCard, TextPrimary, new Thickness(12, 6, 12, 6));
            btnOpenNovelaDir.Margin = new Thickness(0, 0, 8, 0);
            btnOpenNovelaDir.Click += (s, e) =>
            {
                SyncSettingsFromUi();
                OpenDirectoryInExplorer(EpisodeParser.GetNovelaRoot());
            };
            dirBtns.Children.Add(btnOpenNovelaDir);

            Button btnOpenTerrorDir = CreateStyledButton("📂 Criar / Abrir Pasta Terror", BgCard, TextPrimary, new Thickness(12, 6, 12, 6));
            btnOpenTerrorDir.Click += (s, e) =>
            {
                SyncSettingsFromUi();
                OpenDirectoryInExplorer(EpisodeParser.GetTerrorRoot());
            };
            dirBtns.Children.Add(btnOpenTerrorDir);
            sp.Children.Add(dirBtns);

            StackPanel wmiBtns = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 12, 0, 0) };
            Button btnPreOpen = CreateStyledButton("🌐 Pré-Abrir Perfis Grok + Flow no Chrome via WMI", AccentBlue, Brushes.White, new Thickness(14, 8, 14, 8));
            btnPreOpen.Margin = new Thickness(0, 0, 10, 0);
            btnPreOpen.Click += (s, e) => PreOpenAuthorizedChromeProfiles();
            wmiBtns.Children.Add(btnPreOpen);

            Button btnApplyCfg = CreateStyledButton("💾 Salvar e Aplicar Configurações", AccentGreen, Brushes.White, new Thickness(14, 8, 14, 8));
            btnApplyCfg.Click += (s, e) =>
            {
                SyncSettingsFromUi();
                _config.SaveUserSettings();
                RefreshGrokProfileBadges();
                RefreshStoriesList();
                AppendLog("[Configurações] Parâmetros, diretórios e perfis salvos com sucesso!");
            };
            wmiBtns.Children.Add(btnApplyCfg);

            sp.Children.Add(wmiBtns);
            sv.Content = sp;
            tab.Content = sv;
            return tab;
        }

        private UIElement BuildLabeledSetting(string label, string initialValue, out TextBox txtOut)
        {
            StackPanel sp = new StackPanel { Margin = new Thickness(0, 0, 0, 10) };
            sp.Children.Add(new TextBlock
            {
                Text = label,
                FontSize = 12,
                Foreground = TextSecondary,
                Margin = new Thickness(0, 0, 0, 3)
            });
            txtOut = CreateStyledTextBox("");
            txtOut.Text = initialValue;
            txtOut.Width = 760;
            txtOut.HorizontalAlignment = HorizontalAlignment.Left;
            sp.Children.Add(txtOut);
            return sp;
        }

        private Button CreateStyledButton(string text, Brush bg, Brush fg, Thickness padding)
        {
            return new Button
            {
                Content = text,
                Background = bg,
                Foreground = fg,
                BorderBrush = BorderSubtle,
                BorderThickness = new Thickness(1),
                Padding = padding,
                Cursor = Cursors.Hand,
                FontSize = 12
            };
        }

        private TextBox CreateStyledTextBox(string placeholder)
        {
            return new TextBox
            {
                Background = BgInput,
                Foreground = TextPrimary,
                BorderBrush = BorderSubtle,
                BorderThickness = new Thickness(1),
                Padding = new Thickness(8, 5, 8, 5),
                FontSize = 12,
                ToolTip = string.IsNullOrEmpty(placeholder) ? null : placeholder
            };
        }

        private async void OnMainWindowLoaded(object sender, RoutedEventArgs e)
        {
            AppendLog("=== Fluxo Vídeo IA Studio iniciado ===");
            AppendLog("Pronto para executar: [1] Grok Imagine -> [2] Google Flow -> [3] ElevenLabs (WAV -40dB) -> [4] CapCut Desktop.");
            RefreshGrokProfileBadges();
            RefreshElevenVoicePresetCombos();
            RefreshStoriesList();

            if (!PipelineConfig.IsMasterDeveloperPc())
            {
                var unused = MonitorAndPromptRemoteUpdateOnOtherPcAsync();
            }

            if (!string.IsNullOrWhiteSpace(_startupEpisodePath) && Directory.Exists(_startupEpisodePath))
            {
                LoadCustomPathDirectly(_startupEpisodePath);
                if (_startupAutoRun && _selectedEpisode != null)
                {
                    await Task.Delay(600);
                    await ExecuteSelectedStagesAsync(true, true, true, true);
                }
            }
        }

        private void RefreshStoriesList()
        {
            _allStories = EpisodeParser.DiscoverAllStories();
            ApplyStoryFilter();
            AppendLog(string.Format("[Explorador] {0} histórias encontradas nas pastas de Novela/Reflexão e Terror.", _allStories.Count));
        }

        private void ApplyStoryFilter()
        {
            if (_lstStories == null) return;
            int filterIdx = _cmbGenreFilter != null ? _cmbGenreFilter.SelectedIndex : 0;
            string q = (_txtSearch != null ? _txtSearch.Text : "").Trim();

            IEnumerable<StoryProject> filtered = _allStories;
            if (filterIdx == 1) filtered = filtered.Where(s => s.Genre == GenreType.NovelaReflexao);
            else if (filterIdx == 2) filtered = filtered.Where(s => s.Genre == GenreType.Terror);

            if (!string.IsNullOrEmpty(q))
            {
                filtered = filtered.Where(s => s.Name.IndexOf(q, StringComparison.OrdinalIgnoreCase) >= 0);
            }

            List<StoryProject> finalList = filtered.ToList();
            _lstStories.Items.Clear();

            foreach (StoryProject sp in finalList)
            {
                Border itemBorder = new Border
                {
                    Background = BgCard,
                    BorderBrush = BorderSubtle,
                    BorderThickness = new Thickness(1),
                    CornerRadius = new CornerRadius(6),
                    Padding = new Thickness(9, 7, 9, 7),
                    Margin = new Thickness(0, 2, 0, 2),
                    Width = 292
                };

                StackPanel st = new StackPanel();
                st.Children.Add(new TextBlock
                {
                    Text = sp.Name,
                    FontWeight = FontWeights.Bold,
                    FontSize = 12.5,
                    Foreground = TextPrimary,
                    TextTrimming = TextTrimming.CharacterEllipsis
                });
                st.Children.Add(new TextBlock
                {
                    Text = string.Format("{0}  •  {1} ep(s)  •  {2:dd/MM HH:mm}",
                        sp.GenreBadge, sp.Episodes.Count, sp.LastModified),
                    FontSize = 11,
                    Foreground = sp.Genre == GenreType.Terror ? BrushFromHex("#FCA5A5") : BrushFromHex("#93C5FD"),
                    Margin = new Thickness(0, 2, 0, 0)
                });

                itemBorder.Child = st;
                ListBoxItem lbi = new ListBoxItem { Content = itemBorder, Tag = sp, Padding = new Thickness(0) };
                _lstStories.Items.Add(lbi);
            }

            if (_lstStories.Items.Count > 0 && _lstStories.SelectedIndex < 0)
            {
                _lstStories.SelectedIndex = 0;
            }
        }

        private void OnStorySelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ListBoxItem lbi = _lstStories.SelectedItem as ListBoxItem;
            if (lbi == null) return;
            StoryProject story = lbi.Tag as StoryProject;
            if (story == null) return;

            _selectedStory = story;
            RebuildEpisodeButtons(story);
            if (story.Episodes.Count > 0)
            {
                SelectEpisode(story.Episodes[0]);
            }
        }

        private void RebuildEpisodeButtons(StoryProject story)
        {
            _pnlEpisodeButtons.Children.Clear();
            foreach (EpisodeWorkItem ep in story.Episodes)
            {
                EpisodeParser.RefreshDiskCounters(ep);
                EpisodeWorkItem captured = ep;
                Button b = CreateStyledButton(
                    ep.SummaryLine,
                    _selectedEpisode == ep ? AccentPrimary : BgInput,
                    TextPrimary,
                    new Thickness(8, 6, 8, 6));
                b.HorizontalContentAlignment = HorizontalAlignment.Left;
                b.Margin = new Thickness(0, 2, 0, 2);
                b.FontSize = 11.5;
                b.Click += (s, ev) =>
                {
                    SelectEpisode(captured);
                    RebuildEpisodeButtons(story);
                };
                _pnlEpisodeButtons.Children.Add(b);
            }
        }

        private void SelectEpisode(EpisodeWorkItem ep)
        {
            if (ep == null) return;
            // Re-parse fresh from disk in case Antigravity just wrote new prompts
            EpisodeWorkItem refreshed = EpisodeParser.ParseEpisodeFolder(ep.EpisodePath, ep.StoryName, ep.Genre, ep.StoryRootPath);
            if (refreshed != null && _selectedStory != null)
            {
                int idx = _selectedStory.Episodes.IndexOf(ep);
                if (idx >= 0) _selectedStory.Episodes[idx] = refreshed;
                ep = refreshed;
            }

            _selectedEpisode = ep;
            _lblSelectedContext.Text = string.Format("📂 {0}  ➔  {1}   ({2})",
                ep.StoryName, ep.EpisodeName, ep.SummaryLine);

            _txtCapCutProjName.Text = ep.CapCutProjectName;
            _txtGrokPrompt.Text = ep.GrokPromptText ?? "";
            _txtFlowPrompt.Text = ep.FlowPromptText ?? "";
            _txtNarratorPrompt.Text = ep.UnifiedNarratorText ?? "";

            ResetStageBadges();
            RefreshAssetsGallery(null);
            RefreshTakesManagerList();
        }

        private void ResetStageBadges()
        {
            SetStageBadge(_badgeGrok, StageState.Idle, "AGUARDANDO");
            SetStageBadge(_badgeFlow, StageState.Idle, "AGUARDANDO");
            SetStageBadge(_badgeEleven, StageState.Idle,
                (_selectedEpisode != null && string.IsNullOrWhiteSpace(_selectedEpisode.UnifiedNarratorText))
                    ? "SEM NARRADOR"
                    : "AGUARDANDO");
            SetStageBadge(_badgeCapCut, StageState.Idle, "AGUARDANDO");
        }

        private void SetStageBadge(TextBlock badge, StageState state, string text)
        {
            Action act = () =>
            {
                if (badge == null) return;
                badge.Text = text;
                switch (state)
                {
                    case StageState.Running: badge.Foreground = AccentAmber; break;
                    case StageState.Success: badge.Foreground = AccentGreen; break;
                    case StageState.Skipped: badge.Foreground = AccentBlue; break;
                    case StageState.PausedReview: badge.Foreground = AccentAmber; break;
                    case StageState.Failed: badge.Foreground = AccentRed; break;
                    default: badge.Foreground = TextSecondary; break;
                }
            };
            if (Dispatcher.CheckAccess()) act();
            else Dispatcher.BeginInvoke(act);
        }

        private void RefreshAssetsGallery(Dictionary<string, string> ocrLookup)
        {
            _wrapAssets.Children.Clear();
            if (_selectedEpisode == null) return;

            List<string> expectedNames = _selectedEpisode.AllRequiredFlowIngredients.Count > 0
                ? new List<string>(_selectedEpisode.AllRequiredFlowIngredients)
                : _selectedEpisode.GrokSpecs.Select(s => s.TargetFileName).ToList();

            if (Directory.Exists(_selectedEpisode.AssetsDir))
            {
                foreach (string f in Directory.GetFiles(_selectedEpisode.AssetsDir))
                {
                    if (! f.EndsWith(".jpg", StringComparison.OrdinalIgnoreCase) &&
                        ! f.EndsWith(".jpeg", StringComparison.OrdinalIgnoreCase) &&
                        ! f.EndsWith(".png", StringComparison.OrdinalIgnoreCase))
                        continue;

                    string fn = Path.GetFileName(f);
                    if (!expectedNames.Contains(fn, StringComparer.OrdinalIgnoreCase))
                        expectedNames.Add(fn);
                }
            }

            int readyCount = 0;
            foreach (string fileName in expectedNames)
            {
                string fullPath = Path.Combine(_selectedEpisode.AssetsDir, fileName);
                bool exists = File.Exists(fullPath) && new FileInfo(fullPath).Length > 1024;
                if (exists) readyCount++;

                GrokAssetSpec spec = _selectedEpisode.GrokSpecs.FirstOrDefault(s =>
                    string.Equals(s.TargetFileName, fileName, StringComparison.OrdinalIgnoreCase));

                string ocrText = (ocrLookup != null && ocrLookup.ContainsKey(fullPath)) ? ocrLookup[fullPath] : "";
                _wrapAssets.Children.Add(BuildAssetThumbnailCard(fileName, fullPath, exists, spec != null ? spec.DisplayTitle : "", ocrText, expectedNames));
            }

            _lblAssetsSummary.Text = string.Format("Assets do episódio {0}: {1}/{2} arquivos prontos em '{3}'",
                _selectedEpisode.EpisodeName, readyCount, expectedNames.Count, _selectedEpisode.AssetsDir);
        }

        private UIElement BuildAssetThumbnailCard(
            string fileName,
            string fullPath,
            bool exists,
            string expectedTitle,
            string ocrText,
            List<string> allNames)
        {
            Border card = new Border
            {
                Width = 205,
                Background = BgCard,
                BorderBrush = exists ? BrushFromHex("#065F46") : BorderSubtle,
                BorderThickness = new Thickness(1.5),
                CornerRadius = new CornerRadius(8),
                Padding = new Thickness(8),
                Margin = new Thickness(5)
            };

            StackPanel sp = new StackPanel();

            Border imgBox = new Border
            {
                Height = 250,
                Background = BgInput,
                CornerRadius = new CornerRadius(5),
                ClipToBounds = true
            };

            if (exists)
            {
                try
                {
                    BitmapImage bmp = new BitmapImage();
                    using (FileStream fs = new FileStream(fullPath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                    {
                        bmp.BeginInit();
                        bmp.CacheOption = BitmapCacheOption.OnLoad;
                        bmp.DecodePixelWidth = 260;
                        bmp.StreamSource = fs;
                        bmp.EndInit();
                    }
                    bmp.Freeze();

                    Image img = new Image { Source = bmp, Stretch = Stretch.Uniform };
                    img.Cursor = Cursors.Hand;
                    img.ToolTip = "Clique para abrir a imagem em tamanho real";
                    img.MouseLeftButtonUp += (s, e) =>
                    {
                        try { Process.Start(new ProcessStartInfo(fullPath) { UseShellExecute = true }); } catch { }
                    };
                    imgBox.Child = img;
                }
                catch
                {
                    imgBox.Child = new TextBlock { Text = "Erro ao ler imagem", Foreground = AccentRed, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
                }
            }
            else
            {
                imgBox.Child = new TextBlock
                {
                    Text = "⏳ PENDENTE\n(Grok Imagine)",
                    Foreground = TextSecondary,
                    TextAlignment = TextAlignment.Center,
                    HorizontalAlignment = HorizontalAlignment.Center,
                    VerticalAlignment = VerticalAlignment.Center
                };
            }
            sp.Children.Add(imgBox);

            sp.Children.Add(new TextBlock
            {
                Text = fileName,
                FontSize = 11.5,
                FontWeight = FontWeights.Bold,
                Foreground = TextPrimary,
                TextWrapping = TextWrapping.Wrap,
                Margin = new Thickness(0, 6, 0, 2)
            });

            if (!string.IsNullOrEmpty(expectedTitle))
            {
                sp.Children.Add(new TextBlock
                {
                    Text = "Esperado: " + expectedTitle,
                    FontSize = 10.5,
                    Foreground = TextSecondary,
                    TextTrimming = TextTrimming.CharacterEllipsis
                });
            }

            if (!string.IsNullOrEmpty(ocrText))
            {
                sp.Children.Add(new TextBlock
                {
                    Text = "OCR Topo: \"" + ocrText + "\"",
                    FontSize = 10.5,
                    FontWeight = FontWeights.SemiBold,
                    Foreground = AccentGreen,
                    TextWrapping = TextWrapping.Wrap
                });
            }

            if (exists && allNames.Count > 1)
            {
                ComboBox cmbSwap = new ComboBox { FontSize = 10.5, Margin = new Thickness(0, 5, 0, 0) };
                cmbSwap.Items.Add("⇄ Trocar nome com...");
                foreach (string other in allNames)
                {
                    if (!string.Equals(other, fileName, StringComparison.OrdinalIgnoreCase))
                        cmbSwap.Items.Add(other);
                }
                cmbSwap.SelectedIndex = 0;
                cmbSwap.SelectionChanged += (s, e) =>
                {
                    if (cmbSwap.SelectedIndex <= 0) return;
                    string targetOther = Convert.ToString(cmbSwap.SelectedItem);
                    SwapTwoAssetFiles(fullPath, Path.Combine(_selectedEpisode.AssetsDir, targetOther));
                };
                sp.Children.Add(cmbSwap);
            }

            StackPanel actionRow = new StackPanel { Orientation = Orientation.Vertical, Margin = new Thickness(0, 6, 0, 0) };
            Button btnRegenAsset = CreateStyledButton("🔄 Regerar só este Asset", BgPanel, TextPrimary, new Thickness(6, 4, 6, 4));
            btnRegenAsset.FontSize = 10.5;
            btnRegenAsset.Click += (s, e) => ShowRegenerateSingleAssetDialog(fileName);
            actionRow.Children.Add(btnRegenAsset);

            sp.Children.Add(actionRow);

            card.Child = sp;
            return card;
        }

        private void SwapTwoAssetFiles(string pathA, string pathB)
        {
            try
            {
                if (!File.Exists(pathA)) return;
                if (File.Exists(pathB))
                {
                    string tmp = pathA + ".swap_tmp";
                    File.Move(pathA, tmp);
                    File.Move(pathB, pathA);
                    File.Move(tmp, pathB);
                    AppendLog(string.Format("[Assets] Nomes trocados com sucesso: '{0}' <-> '{1}'",
                        Path.GetFileName(pathA), Path.GetFileName(pathB)));
                }
                else
                {
                    File.Move(pathA, pathB);
                    AppendLog(string.Format("[Assets] Arquivo renomeado: '{0}' -> '{1}'",
                        Path.GetFileName(pathA), Path.GetFileName(pathB)));
                }
                _grok.MirrorAssetsToTempFlow(_selectedEpisode.AssetsDir);
                EpisodeParser.RefreshDiskCounters(_selectedEpisode);
                RefreshAssetsGallery(null);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao trocar nomes: " + ex.Message, "Assets", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private async Task InspectCurrentAssetsWithOcrAsync()
        {
            if (_selectedEpisode == null || !Directory.Exists(_selectedEpisode.AssetsDir)) return;
            AppendLog("[OCR] Lendo títulos no topo dos arquivos .jpg em assets via Windows OCR (pt-BR)...");
            string dir = _selectedEpisode.AssetsDir;
            Dictionary<string, string> res = await Task.Run(() => _grok.RunWindowsOcrOnFolder(dir));
            AppendLog(string.Format("[OCR] Leitura concluída para {0} imagens.", res.Count));
            RefreshAssetsGallery(res);
        }

        private void SyncSettingsFromUi()
        {
            _config.PreserveExistingAssets = _chkPreserveAssets.IsChecked == true;
            _config.ArchiveOldTakesBeforeRemake = _chkArchiveOldTakes.IsChecked == true;
            _config.PauseAfterGrokForVisualReview = _chkPauseAfterGrok.IsChecked == true;
            _config.ReuseEp1HookTake01 = _chkReuseHook.IsChecked == true;
            _config.LaunchCapCutDesktop = _chkLaunchCapCut.IsChecked == true;

            List<string> grokProfs = _txtGrokProfiles.Text
                .Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(s => s.Trim()).Where(s => s.Length > 0).ToList();
            if (grokProfs.Count > 0) _config.GrokProfiles = grokProfs;

            if (!string.IsNullOrWhiteSpace(_txtFlowProfile.Text))
                _config.FlowProfile = _txtFlowProfile.Text.Trim();
            if (!string.IsNullOrWhiteSpace(_txtFlowUrl.Text))
                _config.FlowProjectUrl = _txtFlowUrl.Text.Trim();

            List<string> elProfs = _txtElevenProfiles.Text
                .Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(s => s.Trim()).Where(s => s.Length > 0).ToList();
            if (elProfs.Count > 0) _config.ElevenLabsProfiles = elProfs;

            if (!string.IsNullOrWhiteSpace(_txtElevenUrl.Text))
                _config.ElevenLabsUrl = _txtElevenUrl.Text.Trim();

            if (_txtNovelaRootDir != null)
            {
                _config.NovelaRootDir = (_txtNovelaRootDir.Text ?? "").Trim();
                EpisodeParser.CustomNovelaRoot = _config.NovelaRootDir;
            }

            if (_txtTerrorRootDir != null)
            {
                _config.TerrorRootDir = (_txtTerrorRootDir.Text ?? "").Trim();
                EpisodeParser.CustomTerrorRoot = _config.TerrorRootDir;
            }
        }

        private void SyncEditedPromptsToEpisodeMemory()
        {
            if (_selectedEpisode == null) return;
            _selectedEpisode.GrokPromptText = _txtGrokPrompt.Text ?? "";
            _selectedEpisode.FlowPromptText = _txtFlowPrompt.Text ?? "";
            _selectedEpisode.UnifiedNarratorText = (_txtNarratorPrompt.Text ?? "").Trim();

            Dictionary<string, string> titleMap = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            EpisodeParser.ParseFlowTakes(_selectedEpisode.FlowPromptText, _selectedEpisode.FlowTakes, _selectedEpisode.AllRequiredFlowIngredients, titleMap);
            EpisodeParser.ParseGrokSpecs(_selectedEpisode.GrokPromptText, titleMap, _selectedEpisode.AllRequiredFlowIngredients, _selectedEpisode.GrokSpecs);
            EpisodeParser.LoadEpisodeCustomTakesConfig(_selectedEpisode);
        }

        private void OnSavePromptsClick(object sender, RoutedEventArgs e)
        {
            if (_selectedEpisode == null) return;
            try
            {
                UTF8Encoding utf8NoBom = new UTF8Encoding(false);
                string grokFile = string.IsNullOrEmpty(_selectedEpisode.GrokPromptPath)
                    ? Path.Combine(_selectedEpisode.EpisodePath, "prompt_grok_passo1_e_2.txt")
                    : _selectedEpisode.GrokPromptPath;
                string flowFile = string.IsNullOrEmpty(_selectedEpisode.FlowPromptPath)
                    ? Path.Combine(_selectedEpisode.EpisodePath, "prompt_flow_passo3.txt")
                    : _selectedEpisode.FlowPromptPath;
                string narFile = Path.Combine(_selectedEpisode.EpisodePath, "narrador_unificado.txt");

                File.WriteAllText(grokFile, _txtGrokPrompt.Text ?? "", utf8NoBom);
                File.WriteAllText(flowFile, _txtFlowPrompt.Text ?? "", utf8NoBom);
                if (!string.IsNullOrWhiteSpace(_txtNarratorPrompt.Text))
                    File.WriteAllText(narFile, _txtNarratorPrompt.Text.Trim(), utf8NoBom);

                _selectedEpisode.GrokPromptPath = grokFile;
                _selectedEpisode.FlowPromptPath = flowFile;
                _selectedEpisode.NarradorTxtPath = narFile;
                SyncEditedPromptsToEpisodeMemory();
                RefreshAssetsGallery(null);

                AppendLog("[Arquivos] Prompts e texto do Narrador salvos em UTF-8 sem BOM com sucesso!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao salvar arquivos: " + ex.Message, "Erro", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private async Task TestChromeCdpConnectionAsync()
        {
            try
            {
                _lblCdpStatus.Text = "● Chrome CDP: Conectando...";
                _lblCdpStatus.Foreground = AccentAmber;
                using (CancellationTokenSource cts = new CancellationTokenSource(30000))
                {
                    await _cdp.EnsureConnectedAsync(cts.Token);
                    var targets = await _cdp.GetTargetsAsync(cts.Token);
                    int pages = targets.Count(t => t.Type == "page");
                    _lblCdpStatus.Text = string.Format("● Chrome CDP: Conectado ({0} abas)", pages);
                    _lblCdpStatus.Foreground = AccentGreen;
                }
            }
            catch (Exception ex)
            {
                _lblCdpStatus.Text = "● Chrome CDP: Erro na conexão";
                _lblCdpStatus.Foreground = AccentRed;
                AppendLog("[CDP Erro] " + ex.Message);
            }
        }

        private void PreOpenAuthorizedChromeProfiles()
        {
            SyncSettingsFromUi();
            AppendLog("[WMI] Pré-abrindo janelas autorizadas do Grok Imagine e Google Flow no Chrome...");
            foreach (string prof in _config.GrokProfiles)
            {
                _cdp.LaunchChromeProfileWindow(prof, _config.GrokUrl);
            }
            _cdp.LaunchChromeProfileWindow(_config.FlowProfile, _config.FlowProjectUrl);
            AppendLog("[WMI] Comandos de abertura enviados para os perfis autorizados!");
        }

        private async Task ExecuteFullStoryQueueAsync()
        {
            if (_isRunning || _selectedStory == null || _selectedStory.Episodes.Count == 0) return;

            SyncSettingsFromUi();
            SetRunningUiState(true);
            _runCts = new CancellationTokenSource();

            try
            {
                AppendLog(string.Format("========== INICIANDO FILA COMPLETA DA HISTÓRIA: {0} ({1} episódios) ==========",
                    _selectedStory.Name, _selectedStory.Episodes.Count));

                for (int i = 0; i < _selectedStory.Episodes.Count; i++)
                {
                    _runCts.Token.ThrowIfCancellationRequested();
                    EpisodeWorkItem ep = _selectedStory.Episodes[i];
                    SelectEpisode(ep);
                    RebuildEpisodeButtons(_selectedStory);

                    bool isLastEp = (i == _selectedStory.Episodes.Count - 1);
                    bool doG = _chkStageGrok.IsChecked == true;
                    bool doF = _chkStageFlow.IsChecked == true;
                    bool doE = _chkStageEleven.IsChecked == true;
                    bool doC = _chkStageCapCut.IsChecked == true;
                    bool launchC = isLastEp && _config.LaunchCapCutDesktop;
                    CancellationToken token = _runCts.Token;

                    await Task.Run(async () =>
                    {
                        await RunEpisodePipelineCoreAsync(ep, doG, doF, doE, doC, launchC, token);
                    });
                }

                UpdateProgress(100, "Fila completa (EP.1 ➔ EP.3) finalizada com sucesso!");
                AppendLog("========== FILA COMPLETA CONCLUÍDA COM SUCESSO! ==========");
            }
            catch (OperationCanceledException)
            {
                UpdateProgress(0, "Execução interrompida pelo usuário.");
                AppendLog("[Sistema] Fila interrompida pelo usuário.");
            }
            catch (Exception ex)
            {
                UpdateProgress(0, "Erro na fila: " + ex.Message);
                AppendLog("[ERRO CRÍTICO] " + ex.ToString());
                MessageBox.Show(ex.Message, "Erro na Esteira", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                SetRunningUiState(false);
            }
        }

        private async Task ExecuteSelectedStagesAsync(bool doGrok, bool doFlow, bool doEleven, bool doCapCut)
        {
            if (_isRunning) return;
            if (_selectedEpisode == null)
            {
                MessageBox.Show("Selecione primeiro uma história e um episódio na coluna esquerda.", "Aviso", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            SyncSettingsFromUi();
            SyncEditedPromptsToEpisodeMemory();
            SetRunningUiState(true);
            _runCts = new CancellationTokenSource();
            EpisodeWorkItem ep = _selectedEpisode;
            bool launchC = _config.LaunchCapCutDesktop;
            CancellationToken token = _runCts.Token;

            try
            {
                await Task.Run(async () =>
                {
                    await RunEpisodePipelineCoreAsync(
                        ep,
                        doGrok,
                        doFlow,
                        doEleven,
                        doCapCut,
                        launchC,
                        token);
                });

                UpdateProgress(100, string.Format("{0} ({1}) concluído com sucesso!", _selectedEpisode.StoryName, _selectedEpisode.EpisodeName));
            }
            catch (OperationCanceledException)
            {
                UpdateProgress(0, "Execução cancelada pelo usuário.");
                AppendLog("[Sistema] Execução cancelada.");
            }
            catch (Exception ex)
            {
                UpdateProgress(0, "Erro: " + ex.Message);
                AppendLog("[ERRO] " + ex.ToString());
                MessageBox.Show(ex.Message, "Erro na Execução", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                if (_selectedStory != null) RebuildEpisodeButtons(_selectedStory);
                RefreshAssetsGallery(null);
                SetRunningUiState(false);
            }
        }

        private async Task RunEpisodePipelineCoreAsync(
            EpisodeWorkItem ep,
            bool doGrok,
            bool doFlow,
            bool doEleven,
            bool doCapCut,
            bool launchCapCutAtEnd,
            CancellationToken ct)
        {
            AppendLog(string.Format("----- Iniciando {0} | {1} -----", ep.StoryName, ep.EpisodeName));

            if (doGrok || doFlow || (doEleven && !string.IsNullOrWhiteSpace(ep.UnifiedNarratorText)))
            {
                UpdateProgress(5, "Conectando ao Google Chrome via CDP WebSocket...");
                await _cdp.EnsureConnectedAsync(ct);
                var op1 = Dispatcher.BeginInvoke(new Action(() =>
                {
                    _lblCdpStatus.Text = "● Chrome CDP: Conectado (Sessão Persistente)";
                    _lblCdpStatus.Foreground = AccentGreen;
                }));
            }

            // ETAPA 1: GROK IMAGINE
            if (doGrok)
            {
                SetStageBadge(_badgeGrok, StageState.Running, "EXECUTANDO...");
                UpdateProgress(15, "Etapa 1/4: Gerando e baixando Personagens + Cenários no Grok Imagine...");
                try
                {
                    await _grok.RunAsync(ep, ct);
                    SetStageBadge(_badgeGrok, StageState.Success, "CONCLUÍDO");
                    var op2 = Dispatcher.BeginInvoke(new Action(() => RefreshAssetsGallery(null)));

                    if (_config.PauseAfterGrokForVisualReview && doFlow)
                    {
                        SetStageBadge(_badgeGrok, StageState.PausedReview, "AGUARDANDO REVISÃO");
                        UpdateProgress(32, "Pausado para conferência visual dos Assets. Clique em 'CONFIRMAR ASSETS E IR P/ FLOW'.");
                        AppendLog("[Revisão Visual] Confira as miniaturas na aba 'Conferência Visual de Assets' e clique no botão amarelo 'CONFIRMAR ASSETS E IR P/ FLOW' para continuar.");

                        _reviewContinueTcs = new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
                        var op3 = Dispatcher.BeginInvoke(new Action(() => _btnContinueReview.Visibility = Visibility.Visible));
                        try
                        {
                            await _reviewContinueTcs.Task;
                        }
                        finally
                        {
                            var op4 = Dispatcher.BeginInvoke(new Action(() => _btnContinueReview.Visibility = Visibility.Collapsed));
                            _reviewContinueTcs = null;
                        }
                        SetStageBadge(_badgeGrok, StageState.Success, "CONFIRMADO");
                    }
                }
                catch
                {
                    SetStageBadge(_badgeGrok, StageState.Failed, "ERRO");
                    throw;
                }
            }
            else
            {
                SetStageBadge(_badgeGrok, StageState.Skipped, "PULADO");
            }

            // ETAPA 2: GOOGLE FLOW
            if (doFlow)
            {
                SetStageBadge(_badgeFlow, StageState.Running, "EXECUTANDO...");
                UpdateProgress(45, "Etapa 2/4: Gerando Takes em lotes de 5 no Google Flow e baixando em 720p...");
                try
                {
                    await _flow.RunAsync(ep, ct);
                    SetStageBadge(_badgeFlow, StageState.Success, "CONCLUÍDO");
                }
                catch
                {
                    SetStageBadge(_badgeFlow, StageState.Failed, "ERRO");
                    throw;
                }
            }
            else
            {
                SetStageBadge(_badgeFlow, StageState.Skipped, "PULADO");
            }

            // ETAPA 3: ELEVENLABS + TRAVAR SILÊNCIO (-40dB / 0,3s WAV)
            if (doEleven)
            {
                if (string.IsNullOrWhiteSpace(ep.UnifiedNarratorText))
                {
                    SetStageBadge(_badgeEleven, StageState.Skipped, "SEM NARRADOR");
                    AppendLog("[ElevenLabs] Episódio sem falas do Narrador — pulando síntese de voz.");
                }
                else
                {
                    SetStageBadge(_badgeEleven, StageState.Running, "EXECUTANDO...");
                    UpdateProgress(75, "Etapa 3/4: Gerando locução no ElevenLabs e aplicando Travar Silêncio (-40dB / 0,3s WAV)...");
                    try
                    {
                        await _eleven.RunAsync(ep, ct);
                        SetStageBadge(_badgeEleven, StageState.Success, "WAV PRONTO");
                    }
                    catch
                    {
                        SetStageBadge(_badgeEleven, StageState.Failed, "ERRO");
                        throw;
                    }
                }
            }
            else
            {
                SetStageBadge(_badgeEleven, StageState.Skipped, "PULADO");
            }

            // ETAPA 4: CAPCUT DESKTOP TIMELINE
            if (doCapCut)
            {
                SetStageBadge(_badgeCapCut, StageState.Running, "MONTANDO...");
                UpdateProgress(90, "Etapa 4/4: Montando takes e áudio do Narrador na Timeline do CapCut Desktop...");
                try
                {
                    string projName = ep.CapCutProjectName;
                    await _capcut.RunAsync(ep, projName, launchCapCutAtEnd, ct);
                    SetStageBadge(_badgeCapCut, StageState.Success, "TIMELINE OK");
                }
                catch
                {
                    SetStageBadge(_badgeCapCut, StageState.Failed, "ERRO");
                    throw;
                }
            }
            else
            {
                SetStageBadge(_badgeCapCut, StageState.Skipped, "PULADO");
            }
        }

        private void SetRunningUiState(bool running)
        {
            _isRunning = running;
            if (_cdp != null)
            {
                _cdp.ClearReloadAndResumeRequest();
            }
            if (!running && _cdp != null)
            {
                Task.Run(async () =>
                {
                    try { await _cdp.ResetDownloadBehaviorToDefaultAsync(); } catch { }
                });
            }
            Action act = () =>
            {
                if (_btnRunAllEpisodes != null) _btnRunAllEpisodes.IsEnabled = !running;
                if (_btnReloadResume != null) _btnReloadResume.Visibility = running ? Visibility.Visible : Visibility.Collapsed;
                if (_btnStop != null)
                {
                    _btnStop.IsEnabled = true;
                    _btnStop.Content = running ? "⏹ PARAR AGORA" : "▶ INICIAR";
                    _btnStop.Background = running ? AccentRed : AccentGreen;
                    _btnStop.Foreground = Brushes.White;
                }
                if (!running && _btnContinueReview != null) _btnContinueReview.Visibility = Visibility.Collapsed;
            };
            if (Dispatcher.CheckAccess()) act();
            else Dispatcher.BeginInvoke(act);
        }

        private void OnImportCastFromAnotherStoryClick(object sender, RoutedEventArgs e)
        {
            if (_selectedEpisode == null || _selectedStory == null)
            {
                MessageBox.Show("Selecione primeiro a história/episódio de destino na coluna esquerda.", "Importar Personagens", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            List<StoryProject> storiesWithAssets = _allStories.Where(s =>
                s.Episodes.Any(ep => Directory.Exists(ep.AssetsDir) && Directory.GetFiles(ep.AssetsDir, "*.jpg").Length > 0))
                .ToList();

            if (storiesWithAssets.Count == 0)
            {
                MessageBox.Show("Nenhuma história pronta com imagens .jpg em assets\\ foi encontrada.", "Importar Personagens", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            Window dlg = new Window
            {
                Title = "👥 Importar Elenco (Personagens / Cenários) de Outra História Pronta",
                Width = 560,
                Height = 360,
                WindowStartupLocation = WindowStartupLocation.CenterOwner,
                Owner = this,
                Background = BgPanel,
                Foreground = TextPrimary,
                ResizeMode = ResizeMode.NoResize
            };

            StackPanel sp = new StackPanel { Margin = new Thickness(18) };
            sp.Children.Add(new TextBlock
            {
                Text = "Escolha a história pronta da qual deseja copiar os personagens:",
                FontWeight = FontWeights.Bold,
                FontSize = 13,
                Foreground = TextPrimary,
                Margin = new Thickness(0, 0, 0, 8)
            });

            ComboBox cmbSourceStory = new ComboBox { Padding = new Thickness(8, 6, 8, 6), Margin = new Thickness(0, 0, 0, 14), FontSize = 12.5 };
            foreach (StoryProject s in storiesWithAssets)
            {
                cmbSourceStory.Items.Add(new ComboBoxItem { Content = s.DisplayHeader, Tag = s });
            }
            cmbSourceStory.SelectedIndex = 0;
            sp.Children.Add(cmbSourceStory);

            CheckBox chkOnlyChars = new CheckBox
            {
                IsChecked = true,
                Content = new TextBlock { Text = "Importar SOMENTE os Personagens (ignorar arquivos de Cenário)", Foreground = TextPrimary },
                Margin = new Thickness(0, 0, 0, 8)
            };
            sp.Children.Add(chkOnlyChars);

            CheckBox chkApplyAllEps = new CheckBox
            {
                IsChecked = true,
                Content = new TextBlock { Text = "Copiar elenco para todos os episódios desta história (EP.1, EP.2 e EP.3)", Foreground = TextPrimary },
                Margin = new Thickness(0, 0, 0, 18)
            };
            sp.Children.Add(chkApplyAllEps);

            sp.Children.Add(new TextBlock
            {
                Text = "Dica: Após importar, você pode usar o menu '⇄ Trocar nome com...' abaixo de cada miniatura caso o novo roteiro use outro arquétipo para o mesmo personagem.",
                FontSize = 11.5,
                Foreground = TextSecondary,
                TextWrapping = TextWrapping.Wrap,
                Margin = new Thickness(0, 0, 0, 16)
            });

            StackPanel btnRow = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };
            Button btnCancel = CreateStyledButton("Cancelar", BgCard, TextPrimary, new Thickness(14, 7, 14, 7));
            btnCancel.Margin = new Thickness(0, 0, 10, 0);
            btnCancel.Click += (s2, e2) => dlg.DialogResult = false;
            btnRow.Children.Add(btnCancel);

            Button btnConfirm = CreateStyledButton("👥 Importar Personagens Agora", AccentPrimary, Brushes.White, new Thickness(14, 7, 14, 7));
            btnConfirm.FontWeight = FontWeights.Bold;
            btnConfirm.Click += (s2, e2) => dlg.DialogResult = true;
            btnRow.Children.Add(btnConfirm);

            sp.Children.Add(btnRow);
            dlg.Content = sp;

            if (dlg.ShowDialog() == true)
            {
                ComboBoxItem selItem = cmbSourceStory.SelectedItem as ComboBoxItem;
                StoryProject srcStory = selItem != null ? selItem.Tag as StoryProject : null;
                if (srcStory == null) return;

                bool onlyChars = chkOnlyChars.IsChecked == true;
                bool allEps = chkApplyAllEps.IsChecked == true;

                Dictionary<string, string> uniqueAssets = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                foreach (EpisodeWorkItem srcEp in srcStory.Episodes)
                {
                    if (!Directory.Exists(srcEp.AssetsDir)) continue;
                    foreach (string f in Directory.GetFiles(srcEp.AssetsDir, "*.jpg"))
                    {
                        string fn = Path.GetFileName(f);
                        bool isScen = fn.IndexOf("Cenario", StringComparison.OrdinalIgnoreCase) >= 0 ||
                                      fn.IndexOf("Quarto_", StringComparison.OrdinalIgnoreCase) >= 0 ||
                                      fn.IndexOf("Sala_", StringComparison.OrdinalIgnoreCase) >= 0 ||
                                      fn.IndexOf("Cozinha_", StringComparison.OrdinalIgnoreCase) >= 0 ||
                                      fn.IndexOf("Rua_", StringComparison.OrdinalIgnoreCase) >= 0 ||
                                      fn.IndexOf("Casa_", StringComparison.OrdinalIgnoreCase) >= 0;
                        if (onlyChars && isScen) continue;
                        if (!uniqueAssets.ContainsKey(fn))
                            uniqueAssets[fn] = f;
                    }
                }

                List<EpisodeWorkItem> targetEps = allEps ? _selectedStory.Episodes : new List<EpisodeWorkItem> { _selectedEpisode };
                int copiedTotal = 0;
                foreach (EpisodeWorkItem dstEp in targetEps)
                {
                    if (!Directory.Exists(dstEp.AssetsDir))
                        Directory.CreateDirectory(dstEp.AssetsDir);

                    foreach (KeyValuePair<string, string> kv in uniqueAssets)
                    {
                        string dstFile = Path.Combine(dstEp.AssetsDir, kv.Key);
                        File.Copy(kv.Value, dstFile, true);
                        copiedTotal++;
                    }
                    EpisodeParser.RefreshDiskCounters(dstEp);
                }

                _grok.MirrorAssetsToTempFlow(_selectedEpisode.AssetsDir);
                RebuildEpisodeButtons(_selectedStory);
                RefreshAssetsGallery(null);
                AppendLog(string.Format("[Elenco Importado] {0} imagens copiadas de '{1}' para '{2}' e espelhadas em Temp\\flow_assets!",
                    uniqueAssets.Count, srcStory.Name, _selectedStory.Name));
            }
        }

        private void UpdateProgress(double value, string label)
        {
            Action act = () =>
            {
                if (_progressBar != null) _progressBar.Value = value;
                if (_lblProgressStep != null) _lblProgressStep.Text = label;
            };
            if (Dispatcher.CheckAccess()) act();
            else Dispatcher.BeginInvoke(act);
        }

        private readonly object _fileLogLock = new object();

        private void AppendLog(string message)
        {
            string line = string.Format("[{0:HH:mm:ss}] {1}", DateTime.Now, message);
            try
            {
                lock (_fileLogLock)
                {
                    string logFile = Path.Combine(PipelineConfig.GetAppRootDir(), "studio_runtime.log");
                    File.AppendAllText(logFile, line + Environment.NewLine, Encoding.UTF8);
                }
            }
            catch { }

            Dispatcher.BeginInvoke(new Action(() =>
            {
                if (_txtLog == null) return;
                _txtLog.AppendText(line + Environment.NewLine);
                _txtLog.ScrollToEnd();
            }));
        }

        private void OpenDirectoryInExplorer(string dir)
        {
            if (string.IsNullOrWhiteSpace(dir)) return;
            if (!Directory.Exists(dir)) Directory.CreateDirectory(dir);
            try { Process.Start(new ProcessStartInfo("explorer.exe", "\"" + dir + "\"") { UseShellExecute = true }); } catch { }
        }

        private void OnBrowseCustomEpisodeFolder(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog
            {
                Title = "Selecione qualquer arquivo .txt (ex: prompt_flow_passo3.txt ou roteiro.txt) dentro da pasta do Episódio/História",
                Filter = "Arquivos da História (*.txt)|*.txt|Todos os arquivos (*.*)|*.*",
                InitialDirectory = Directory.Exists(EpisodeParser.GetNovelaRoot())
                    ? EpisodeParser.GetNovelaRoot()
                    : Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory)
            };

            if (dlg.ShowDialog() == true)
            {
                string folder = Path.GetDirectoryName(dlg.FileName);
                LoadCustomPathDirectly(folder);
            }
        }

        private void LoadCustomPathDirectly(string folder)
        {
            if (string.IsNullOrEmpty(folder) || !Directory.Exists(folder)) return;

            string dirName = Path.GetFileName(folder);
            string storyFolder = folder;
            string targetEpName = "";

            if (dirName.StartsWith("EP.", StringComparison.OrdinalIgnoreCase) ||
                dirName.StartsWith("EP", StringComparison.OrdinalIgnoreCase))
            {
                storyFolder = Directory.GetParent(folder).FullName;
                targetEpName = dirName;
            }

            GenreType g = folder.IndexOf("_Videos terror", StringComparison.OrdinalIgnoreCase) >= 0
                ? GenreType.Terror
                : (folder.IndexOf("_videos de reflex", StringComparison.OrdinalIgnoreCase) >= 0 ? GenreType.NovelaReflexao : GenreType.Custom);

            StoryProject existing = _allStories.FirstOrDefault(s => string.Equals(s.FolderPath, storyFolder, StringComparison.OrdinalIgnoreCase));
            if (existing == null)
            {
                existing = EpisodeParser.LoadStoryFolder(storyFolder, g);
                if (existing != null && existing.Episodes.Count > 0)
                {
                    _allStories.Insert(0, existing);
                    ApplyStoryFilter();
                }
            }

            if (existing != null)
            {
                foreach (ListBoxItem item in _lstStories.Items)
                {
                    if (item.Tag == existing)
                    {
                        _lstStories.SelectedItem = item;
                        break;
                    }
                }

                if (!string.IsNullOrEmpty(targetEpName))
                {
                    EpisodeWorkItem matchEp = existing.Episodes.FirstOrDefault(ep =>
                        string.Equals(ep.EpisodeName, targetEpName, StringComparison.OrdinalIgnoreCase));
                    if (matchEp != null)
                    {
                        SelectEpisode(matchEp);
                        RebuildEpisodeButtons(existing);
                    }
                }
            }
        }

        private void OnManualSilenceProcessClick(object sender, RoutedEventArgs e)
        {
            if (_selectedEpisode == null)
            {
                MessageBox.Show("Selecione um episódio primeiro.", "Aviso", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            OpenFileDialog dlg = new OpenFileDialog
            {
                Title = "Selecione o arquivo .mp3 ou .wav do Narrador para aplicar Travar Silêncio (-40dB / 0,3s)",
                Filter = "Áudio (*.mp3;*.wav;*.m4a)|*.mp3;*.wav;*.m4a",
                InitialDirectory = Directory.Exists(_selectedEpisode.EpisodePath)
                    ? _selectedEpisode.EpisodePath
                    : Environment.GetFolderPath(Environment.SpecialFolder.UserProfile) + "\\Downloads"
            };

            if (dlg.ShowDialog() == true)
            {
                try
                {
                    if (!Directory.Exists(_selectedEpisode.TakesDir))
                        Directory.CreateDirectory(_selectedEpisode.TakesDir);

                    string outTakesWav = Path.Combine(_selectedEpisode.TakesDir, "Narrador_Take_01.wav");
                    string outRootWav = Path.Combine(_selectedEpisode.EpisodePath, "Narrador_Completo.wav");
                    _eleven.RunSilenceTruncationToWav(dlg.FileName, outTakesWav);
                    File.Copy(outTakesWav, outRootWav, true);
                    EpisodeParser.RefreshDiskCounters(_selectedEpisode);
                    if (_selectedStory != null) RebuildEpisodeButtons(_selectedStory);
                    MessageBox.Show("Áudio processado e salvo em:\n" + outTakesWav, "Travar Silêncio Concluído", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao processar áudio: " + ex.Message, "Erro", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        // =================================================================================================
        // GERENCIADOR DE TAKES & FIGURINOS POR OCASIÃO (ITENS 1 E 2)
        // =================================================================================================

        private void RefreshTakesManagerList()
        {
            if (_pnlTakesList == null) return;
            _pnlTakesList.Children.Clear();
            _takeSelectionChecks.Clear();

            if (_selectedEpisode == null || _selectedEpisode.FlowTakes == null || _selectedEpisode.FlowTakes.Count == 0)
            {
                if (_lblTakesManagerSummary != null)
                    _lblTakesManagerSummary.Text = "Selecione um episódio com takes decupados para gerenciar takes e figurinos.";
                return;
            }

            int readyCount = 0;
            foreach (FlowTakeSpec take in _selectedEpisode.FlowTakes.OrderBy(t => t.TakeNumber))
            {
                string mp4Path = Path.Combine(_selectedEpisode.TakesDir, string.Format("Take_{0:00}.mp4", take.TakeNumber));
                bool exists = File.Exists(mp4Path) && new FileInfo(mp4Path).Length >= 50 * 1024;
                if (exists) readyCount++;

                _pnlTakesList.Children.Add(BuildTakeManagerCard(take, mp4Path, exists));
            }

            if (_lblTakesManagerSummary != null)
            {
                _lblTakesManagerSummary.Text = string.Format(
                    "{0} ({1}): {2}/{3} takes prontos em 'takes\\'. Marque ou escolha qualquer take abaixo para regerar:",
                    _selectedEpisode.StoryName, _selectedEpisode.EpisodeName, readyCount, _selectedEpisode.FlowTakes.Count);
            }
        }

        private UIElement BuildTakeManagerCard(FlowTakeSpec take, string mp4Path, bool exists)
        {
            Border card = new Border
            {
                Background = BgCard,
                BorderBrush = exists ? BrushFromHex("#065F46") : BorderSubtle,
                BorderThickness = new Thickness(1.5),
                CornerRadius = new CornerRadius(8),
                Padding = new Thickness(12, 10, 12, 10),
                Margin = new Thickness(0, 0, 0, 8)
            };

            StackPanel root = new StackPanel();

            // Linha 1: Checkbox + Take_XX + Badge Status + Cenário + Botões de Ação Rápida
            DockPanel headerRow = new DockPanel { Margin = new Thickness(0, 0, 0, 6) };

            StackPanel leftInfo = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };
            CheckBox chkTake = new CheckBox
            {
                IsChecked = !exists,
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(0, 0, 8, 0)
            };
            _takeSelectionChecks[take.TakeNumber] = chkTake;
            leftInfo.Children.Add(chkTake);

            leftInfo.Children.Add(new TextBlock
            {
                Text = string.Format("TAKE {0:00}", take.TakeNumber),
                FontSize = 14,
                FontWeight = FontWeights.Bold,
                Foreground = TextPrimary,
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(0, 0, 10, 0)
            });

            Border statusBadge = new Border
            {
                Background = exists ? BrushFromHex("#064E3B") : BrushFromHex("#451A03"),
                BorderBrush = exists ? AccentGreen : AccentAmber,
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(5),
                Padding = new Thickness(7, 2, 7, 2),
                Margin = new Thickness(0, 0, 10, 0)
            };
            double mb = exists ? (new FileInfo(mp4Path).Length / (1024.0 * 1024.0)) : 0.0;
            statusBadge.Child = new TextBlock
            {
                Text = exists ? string.Format("✔ PRONTO ({0:0.1} MB)", mb) : "⏳ PENDENTE",
                FontSize = 10.5,
                FontWeight = FontWeights.Bold,
                Foreground = exists ? BrushFromHex("#A7F3D0") : BrushFromHex("#FDE68A")
            };
            leftInfo.Children.Add(statusBadge);

            if (!string.IsNullOrEmpty(take.ScenarioName))
            {
                leftInfo.Children.Add(new TextBlock
                {
                    Text = "📍 Cenário: " + take.ScenarioName,
                    FontSize = 12,
                    Foreground = TextSecondary,
                    VerticalAlignment = VerticalAlignment.Center,
                    Margin = new Thickness(0, 0, 12, 0)
                });
            }

            headerRow.Children.Add(leftInfo);

            // Botões de Ação Individual por Take
            StackPanel actionBtns = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };

            if (exists)
            {
                Button btnWatch = CreateStyledButton("▶ Assistir", BgPanel, TextPrimary, new Thickness(9, 4, 9, 4));
                btnWatch.FontSize = 11;
                btnWatch.Margin = new Thickness(0, 0, 6, 0);
                btnWatch.Click += (s, e) =>
                {
                    try { Process.Start(new ProcessStartInfo(mp4Path) { UseShellExecute = true }); } catch { }
                };
                actionBtns.Children.Add(btnWatch);
            }

            int capturedTakeNum = take.TakeNumber;

            Button btnRegenFlow = CreateStyledButton("🌊 Regerar no Flow", AccentBlue, Brushes.White, new Thickness(10, 4, 10, 4));
            btnRegenFlow.FontSize = 11;
            btnRegenFlow.FontWeight = FontWeights.SemiBold;
            btnRegenFlow.Margin = new Thickness(0, 0, 6, 0);
            btnRegenFlow.Click += async (s, e) => await RegenerateSingleTakeAsync(capturedTakeNum, false);
            actionBtns.Children.Add(btnRegenFlow);

            Button btnRegenGrok = CreateStyledButton("🚀 Regerar no Grok Vídeo (🪄)", AccentPrimary, Brushes.White, new Thickness(10, 4, 10, 4));
            btnRegenGrok.FontSize = 11;
            btnRegenGrok.FontWeight = FontWeights.SemiBold;
            btnRegenGrok.Click += async (s, e) => await RegenerateSingleTakeAsync(capturedTakeNum, true);
            actionBtns.Children.Add(btnRegenGrok);

            DockPanel.SetDock(actionBtns, Dock.Right);
            headerRow.Children.Add(actionBtns);
            root.Children.Add(headerRow);

            // Linha 2: Ingredientes vinculados pelo roteiro/pré-definição (PASSO 1 e PASSO 3)
            if (take.Ingredients != null && take.Ingredients.Count > 0)
            {
                root.Children.Add(new TextBlock
                {
                    Text = "📎 Ingredientes da Cena (definidos no Passo 1/3): " + string.Join(", ", take.Ingredients),
                    FontSize = 11,
                    Foreground = BrushFromHex("#93C5FD"),
                    Margin = new Thickness(0, 0, 0, 5)
                });
            }

            // Linha 3: Prompt editável do Take
            TextBox txtTakePrompt = new TextBox
            {
                Text = take.RawPromptBody ?? "",
                Background = BgInput,
                Foreground = TextPrimary,
                BorderBrush = BorderSubtle,
                BorderThickness = new Thickness(1),
                FontFamily = new FontFamily("Consolas"),
                FontSize = 11,
                TextWrapping = TextWrapping.Wrap,
                AcceptsReturn = true,
                MaxHeight = 76,
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                Padding = new Thickness(6, 4, 6, 4)
            };
            FlowTakeSpec capturedForPrompt = take;
            txtTakePrompt.LostFocus += (s, e) =>
            {
                if (_selectedEpisode == null) return;
                string newTxt = (txtTakePrompt.Text ?? "").Trim();
                if (!string.Equals(newTxt, capturedForPrompt.RawPromptBody ?? "", StringComparison.Ordinal))
                {
                    capturedForPrompt.RawPromptBody = newTxt;
                    EpisodeParser.SaveEpisodeCustomTakesConfig(_selectedEpisode);
                }
            };
            root.Children.Add(txtTakePrompt);

            card.Child = root;
            return card;
        }

        private async Task RegenerateSingleTakeAsync(int takeNumber, bool forceGrokVideo)
        {
            if (_selectedEpisode == null || _selectedEpisode.FlowTakes == null) return;
            FlowTakeSpec take = _selectedEpisode.FlowTakes.FirstOrDefault(t => t.TakeNumber == takeNumber);
            if (take == null) return;

            await RegenerateSpecificTakesCoreAsync(new List<int> { takeNumber }, forceGrokVideo);
        }

        private async Task RegenerateCheckedTakesAsync(bool forceGrokVideo)
        {
            List<int> selectedNums = _takeSelectionChecks
                .Where(kv => kv.Value.IsChecked == true)
                .Select(kv => kv.Key)
                .OrderBy(n => n)
                .ToList();

            if (selectedNums.Count == 0)
            {
                MessageBox.Show("Marque pelo menos 1 Take na lista para regerar.", "Regerar Takes", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            await RegenerateSpecificTakesCoreAsync(selectedNums, forceGrokVideo);
        }

        private async Task RegenerateSpecificTakesCoreAsync(List<int> takeNumbers, bool forceGrokVideo)
        {
            if (_isRunning || _selectedEpisode == null || takeNumbers == null || takeNumbers.Count == 0)
                return;

            SyncSettingsFromUi();
            EpisodeParser.SaveEpisodeCustomTakesConfig(_selectedEpisode);
            SetRunningUiState(true);
            _runCts = new CancellationTokenSource();

            string labels = string.Join(", ", takeNumbers.Select(n => string.Format("Take_{0:00}", n)));
            string engineName = forceGrokVideo ? "Grok Vídeo (com varinha mágica 🪄)" : "Google Flow";

            EpisodeWorkItem ep = _selectedEpisode;
            CancellationToken token = _runCts.Token;

            try
            {
                SetStageBadge(_badgeFlow, StageState.Running, "REGERANDO...");
                UpdateProgress(35, string.Format("Regerando {0} em {1}...", labels, engineName));
                AppendLog(string.Format("===== Iniciando regeração de {0} via {1} =====", labels, engineName));

                await Task.Run(async () =>
                {
                    await _cdp.EnsureConnectedAsync(token);
                    await _flow.RegenerateSelectedTakesAsync(ep, takeNumbers, forceGrokVideo, token);
                });

                SetStageBadge(_badgeFlow, StageState.Success, "CONCLUÍDO");
                UpdateProgress(100, string.Format("Regeração concluída: {0}!", labels));
            }
            catch (OperationCanceledException)
            {
                UpdateProgress(0, "Regeração cancelada pelo usuário.");
                AppendLog("[Sistema] Regeração de take(s) cancelada.");
            }
            catch (Exception ex)
            {
                SetStageBadge(_badgeFlow, StageState.Failed, "ERRO");
                UpdateProgress(0, "Erro ao regerar take(s): " + ex.Message);
                AppendLog("[ERRO] " + ex.ToString());
                MessageBox.Show(ex.Message, "Erro ao Regerar Take", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                if (_selectedStory != null) RebuildEpisodeButtons(_selectedStory);
                RefreshAssetsGallery(null);
                RefreshTakesManagerList();
                SetRunningUiState(false);
            }
        }

        // =================================================================================================
        // SUGESTÃO A: REGERAR 1 ÚNICO PERSONAGEM OU CENÁRIO (.JPG) NA ABA DE ASSETS
        // =================================================================================================

        private void ShowRegenerateSingleAssetDialog(string fileName)
        {
            if (_selectedEpisode == null || string.IsNullOrEmpty(fileName)) return;

            GrokAssetSpec spec = _selectedEpisode.GrokSpecs.FirstOrDefault(s =>
                string.Equals(s.TargetFileName, fileName, StringComparison.OrdinalIgnoreCase));

            string initialPrompt = spec != null && !string.IsNullOrWhiteSpace(spec.RawPromptLine)
                ? spec.RawPromptLine
                : string.Format("- {0}: Animação 3D estilizada semi-realista (CGI), proporções 9:16 verticais, corpo inteiro sobre fundo branco neutro puro (#FFFFFF), escrito \"{0}\" no topo.",
                    EpisodeParser.CleanAssetStem(fileName));

            Window dlg = new Window
            {
                Title = "🔄 Regerar Asset Individual no Grok Imagine — " + fileName,
                Width = 640,
                Height = 340,
                WindowStartupLocation = WindowStartupLocation.CenterOwner,
                Owner = this,
                Background = BgPanel,
                Foreground = TextPrimary,
                ResizeMode = ResizeMode.NoResize
            };

            StackPanel sp = new StackPanel { Margin = new Thickness(18) };
            sp.Children.Add(new TextBlock
            {
                Text = "Arquivo alvo: " + fileName,
                FontWeight = FontWeights.Bold,
                FontSize = 13,
                Foreground = TextPrimary,
                Margin = new Thickness(0, 0, 0, 6)
            });
            sp.Children.Add(new TextBlock
            {
                Text = "Você pode ajustar a descrição abaixo antes de enviar para o Grok Imagine (somente esta imagem será regerada):",
                FontSize = 11.5,
                Foreground = TextSecondary,
                Margin = new Thickness(0, 0, 0, 8)
            });

            TextBox txtPrompt = new TextBox
            {
                Text = initialPrompt,
                Background = BgInput,
                Foreground = TextPrimary,
                BorderBrush = BorderSubtle,
                BorderThickness = new Thickness(1),
                FontFamily = new FontFamily("Consolas"),
                FontSize = 11.5,
                TextWrapping = TextWrapping.Wrap,
                AcceptsReturn = true,
                Height = 140,
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                Padding = new Thickness(8),
                Margin = new Thickness(0, 0, 0, 14)
            };
            sp.Children.Add(txtPrompt);

            StackPanel btns = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };
            Button btnCancel = CreateStyledButton("Cancelar", BgCard, TextPrimary, new Thickness(14, 7, 14, 7));
            btnCancel.Margin = new Thickness(0, 0, 10, 0);
            btnCancel.Click += (s, e) => dlg.DialogResult = false;
            btns.Children.Add(btnCancel);

            Button btnConfirm = CreateStyledButton("🚀 Regerar Somente Este Asset no Grok", AccentPrimary, Brushes.White, new Thickness(14, 7, 14, 7));
            btnConfirm.FontWeight = FontWeights.Bold;
            btnConfirm.Click += (s, e) => dlg.DialogResult = true;
            btns.Children.Add(btnConfirm);

            sp.Children.Add(btns);
            dlg.Content = sp;

            if (dlg.ShowDialog() == true)
            {
                string customLine = (txtPrompt.Text ?? "").Trim();
                var _ = RunSingleAssetRegenerationFromUiAsync(fileName, customLine);
            }
        }

        private async Task RunSingleAssetRegenerationFromUiAsync(string fileName, string customPromptLine)
        {
            if (_isRunning || _selectedEpisode == null) return;
            SyncSettingsFromUi();
            SetRunningUiState(true);
            _runCts = new CancellationTokenSource();

            EpisodeWorkItem ep = _selectedEpisode;
            CancellationToken token = _runCts.Token;

            try
            {
                SetStageBadge(_badgeGrok, StageState.Running, "REGERANDO 1...");
                UpdateProgress(25, "Regerando asset individual no Grok Imagine: " + fileName);
                await Task.Run(async () =>
                {
                    await _grok.RegenerateSingleAssetAsync(ep, fileName, customPromptLine, token);
                });
                SetStageBadge(_badgeGrok, StageState.Success, "CONCLUÍDO");
                UpdateProgress(100, "Asset regerado com sucesso: " + fileName);
            }
            catch (OperationCanceledException)
            {
                UpdateProgress(0, "Regeração de asset cancelada pelo usuário.");
                AppendLog("[Sistema] Regeração de asset cancelada.");
            }
            catch (Exception ex)
            {
                SetStageBadge(_badgeGrok, StageState.Failed, "ERRO");
                AppendLog("[Erro Asset Individual] " + ex.Message);
                MessageBox.Show(ex.Message, "Erro ao Regerar Asset", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                if (_selectedStory != null) RebuildEpisodeButtons(_selectedStory);
                RefreshAssetsGallery(null);
                RefreshTakesManagerList();
                SetRunningUiState(false);
            }
        }

        // =================================================================================================
        // ITEM 1: CRIAR NOVA ROUPA PARA PERSONAGEM POR OCASIÃO (MANTENDO MESMO ROSTO NO GROK)
        // =================================================================================================

        private void ShowCreateCharacterOutfitDialog(string preselectedBaseChar)
        {
            if (_selectedEpisode == null)
            {
                MessageBox.Show("Selecione primeiro uma história e episódio na coluna esquerda.", "Criar Roupa de Personagem", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            List<string> charFiles = new List<string>();
            if (Directory.Exists(_selectedEpisode.AssetsDir))
            {
                charFiles = Directory.GetFiles(_selectedEpisode.AssetsDir)
                    .Select(f => Path.GetFileName(f))
                    .Where(fn => Regex.IsMatch(Path.GetExtension(fn), @"^\.(jpg|jpeg|png)$", RegexOptions.IgnoreCase) &&
                                 !EpisodeParser.IsScenarioAssetName(fn) &&
                                 fn.IndexOf("__Roupa_", StringComparison.OrdinalIgnoreCase) < 0)
                    .OrderBy(fn => fn)
                    .ToList();
            }

            if (charFiles.Count == 0)
            {
                MessageBox.Show("Nenhuma imagem base de personagem (.jpg) foi encontrada na pasta assets\\ deste episódio. Gere ou importe os personagens base primeiro.",
                    "Criar Roupa de Personagem", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            Window dlg = new Window
            {
                Title = "👔 Criar Roupa Padrão por Ocasião (Mantendo 100% o Mesmo Rosto do Personagem)",
                Width = 640,
                Height = 450,
                WindowStartupLocation = WindowStartupLocation.CenterOwner,
                Owner = this,
                Background = BgPanel,
                Foreground = TextPrimary,
                ResizeMode = ResizeMode.NoResize
            };

            StackPanel sp = new StackPanel { Margin = new Thickness(18) };

            sp.Children.Add(new TextBlock
            {
                Text = "1. Escolha o Personagem Base (a imagem original será enviada como referência ao Grok):",
                FontWeight = FontWeights.Bold,
                FontSize = 12.5,
                Foreground = TextPrimary,
                Margin = new Thickness(0, 0, 0, 5)
            });

            ComboBox cmbChar = new ComboBox { FontSize = 12, Padding = new Thickness(8, 5, 8, 5), Margin = new Thickness(0, 0, 0, 12) };
            int selIdx = 0;
            for (int i = 0; i < charFiles.Count; i++)
            {
                cmbChar.Items.Add(charFiles[i]);
                if (!string.IsNullOrEmpty(preselectedBaseChar) &&
                    string.Equals(charFiles[i], preselectedBaseChar, StringComparison.OrdinalIgnoreCase))
                {
                    selIdx = i;
                }
            }
            cmbChar.SelectedIndex = selIdx;
            sp.Children.Add(cmbChar);

            sp.Children.Add(new TextBlock
            {
                Text = "2. Categoria de Roupa Padrão (gerada e selecionada de acordo com o texto):",
                FontWeight = FontWeights.Bold,
                FontSize = 12.5,
                Foreground = TextPrimary,
                Margin = new Thickness(0, 0, 0, 4)
            });

            ComboBox cmbCategory = new ComboBox { FontSize = 12, Padding = new Thickness(8, 5, 8, 5), Margin = new Thickness(0, 0, 0, 12) };
            cmbCategory.Items.Add(new ComboBoxItem { Content = "👔 Roupa de Trabalho (Obra / Escritório / Serviço)", Tag = "Trabalho" });
            cmbCategory.Items.Add(new ComboBoxItem { Content = "🏠 Roupa Simples (Casa / Dia a Dia / Pós-Formatura)", Tag = "Simples" });
            cmbCategory.Items.Add(new ComboBoxItem { Content = "🌿 Roupa de Lazer (Passeio / Encontro / Fim de Semana)", Tag = "Lazer" });
            cmbCategory.Items.Add(new ComboBoxItem { Content = "🎩 Roupa Formal (Formatura / Casamento / Festa / Gala)", Tag = "Formal" });
            cmbCategory.SelectedIndex = 0;
            sp.Children.Add(cmbCategory);

            sp.Children.Add(new TextBlock
            {
                Text = "3. Descrição da Roupa (gerada automaticamente de acordo com o personagem e o texto):",
                FontWeight = FontWeights.Bold,
                FontSize = 12.5,
                Foreground = TextPrimary,
                Margin = new Thickness(0, 0, 0, 5)
            });

            TextBox txtOutfitDesc = new TextBox
            {
                Text = "",
                Background = BgInput,
                Foreground = TextPrimary,
                BorderBrush = BorderSubtle,
                BorderThickness = new Thickness(1),
                FontSize = 12,
                TextWrapping = TextWrapping.Wrap,
                AcceptsReturn = true,
                Height = 82,
                Padding = new Thickness(8, 5, 8, 5),
                Margin = new Thickness(0, 0, 0, 10)
            };
            sp.Children.Add(txtOutfitDesc);

            Action refreshPresetDesc = () =>
            {
                string chosenChar = Convert.ToString(cmbChar.SelectedItem ?? "");
                ComboBoxItem catItem = cmbCategory.SelectedItem as ComboBoxItem;
                string catKey = catItem != null ? Convert.ToString(catItem.Tag ?? "Trabalho") : "Trabalho";
                txtOutfitDesc.Text = EpisodeParser.GetStandardWardrobePresetDescription(_selectedEpisode, chosenChar, catKey);
            };
            cmbChar.SelectionChanged += (s, e) => refreshPresetDesc();
            cmbCategory.SelectionChanged += (s, e) => refreshPresetDesc();
            refreshPresetDesc();

            CheckBox chkAllEps = new CheckBox
            {
                IsChecked = true,
                Content = new TextBlock { Text = "Disponibilizar esta roupa automaticamente em todos os episódios da história (EP.1, EP.2 e EP.3)", Foreground = TextPrimary },
                Margin = new Thickness(0, 0, 0, 16)
            };
            sp.Children.Add(chkAllEps);

            StackPanel btnRow = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };

            Button btnImportDisk = CreateStyledButton("📂 Já tenho o .jpg no PC...", BgCard, TextPrimary, new Thickness(12, 7, 12, 7));
            btnImportDisk.Margin = new Thickness(0, 0, 10, 0);
            btnImportDisk.Click += (s, e) =>
            {
                string chosenChar = Convert.ToString(cmbChar.SelectedItem ?? "");
                ComboBoxItem catItem = cmbCategory.SelectedItem as ComboBoxItem;
                string occ = catItem != null ? Convert.ToString(catItem.Tag ?? "Simples") : "Simples";
                if (string.IsNullOrEmpty(chosenChar) || string.IsNullOrEmpty(occ))
                    return;

                OpenFileDialog ofd = new OpenFileDialog
                {
                    Title = "Selecione a imagem .jpg/.png com a nova roupa do personagem",
                    Filter = "Imagens (*.jpg;*.jpeg;*.png)|*.jpg;*.jpeg;*.png"
                };
                if (ofd.ShowDialog() == true)
                {
                    string varFile = EpisodeParser.BuildOutfitVariantFileName(chosenChar, occ);
                    string dst = Path.Combine(_selectedEpisode.AssetsDir, varFile);
                    File.Copy(ofd.FileName, dst, true);
                    if (chkAllEps.IsChecked == true && !string.IsNullOrEmpty(_selectedEpisode.StoryRootPath) && Directory.Exists(_selectedEpisode.StoryRootPath))
                    {
                        foreach (string sub in Directory.GetDirectories(_selectedEpisode.StoryRootPath))
                        {
                            string subAssets = Path.Combine(sub, "assets");
                            if (Directory.Exists(subAssets))
                                File.Copy(dst, Path.Combine(subAssets, varFile), true);
                        }
                    }
                    _grok.MirrorAssetsToTempFlow(_selectedEpisode.AssetsDir);
                    RefreshAssetsGallery(null);
                    RefreshTakesManagerList();
                    AppendLog(string.Format("[Figurino] {0} importada com sucesso: {1}", EpisodeParser.FormatOutfitDisplayLabel(occ), varFile));
                    dlg.DialogResult = false;
                }
            };
            btnRow.Children.Add(btnImportDisk);

            Button btnCancel = CreateStyledButton("Cancelar", BgCard, TextPrimary, new Thickness(12, 7, 12, 7));
            btnCancel.Margin = new Thickness(0, 0, 10, 0);
            btnCancel.Click += (s, e) => dlg.DialogResult = false;
            btnRow.Children.Add(btnCancel);

            Button btnGenerate = CreateStyledButton("🪄 Gerar Roupa no Grok (Mantendo Mesmo Rosto)", AccentPrimary, Brushes.White, new Thickness(14, 7, 14, 7));
            btnGenerate.FontWeight = FontWeights.Bold;
            btnGenerate.Click += (s, e) => dlg.DialogResult = true;
            btnRow.Children.Add(btnGenerate);

            sp.Children.Add(btnRow);
            dlg.Content = sp;

            if (dlg.ShowDialog() == true)
            {
                string chosenChar = Convert.ToString(cmbChar.SelectedItem ?? "");
                ComboBoxItem catItem = cmbCategory.SelectedItem as ComboBoxItem;
                string occ = catItem != null ? Convert.ToString(catItem.Tag ?? "Simples") : "Simples";
                string desc = (txtOutfitDesc.Text ?? "").Trim();
                bool copyAll = chkAllEps.IsChecked == true;
                var _ = RunGenerateOutfitVariantFromUiAsync(chosenChar, occ, desc, copyAll);
            }
        }

        private async Task RunAutoDetectAndGenerateOutfitsFromUiAsync()
        {
            if (_isRunning) return;
            if (_selectedEpisode == null)
            {
                MessageBox.Show("Selecione primeiro uma história e episódio na coluna esquerda.", "Gerar Roupas Automáticas pelo Texto", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            List<CharacterWardrobeSpec> detected = EpisodeParser.DetectRequiredCharacterOutfitsFromText(_selectedEpisode);
            if (detected.Count == 0)
            {
                MessageBox.Show("O texto desta história usa apenas a Roupa Padrão original de cada personagem (nenhuma troca de ocasião extra detectada). Se desejar criar uma roupa extra manualmente, clique em '👔 + Criar Roupa Padrão...'.",
                    "Roupas de Acordo com o Texto", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            SyncSettingsFromUi();
            SetRunningUiState(true);
            _runCts = new CancellationTokenSource();

            EpisodeWorkItem ep = _selectedEpisode;
            CancellationToken token = _runCts.Token;

            try
            {
                SetStageBadge(_badgeGrok, StageState.Running, "GERANDO ROUPAS...");
                UpdateProgress(20, string.Format("Gerando {0} opções de roupas padrão de acordo com o texto no Grok...", detected.Count));
                int count = await Task.Run(async () =>
                {
                    await _cdp.EnsureConnectedAsync(token);
                    return await _grok.EnsureAutoDetectedCharacterOutfitsAsync(ep, token);
                });
                SetStageBadge(_badgeGrok, StageState.Success, "ROUPAS OK");
                UpdateProgress(100, string.Format("Roupas automáticas prontas ({0} novas geradas)!", count));
            }
            catch (OperationCanceledException)
            {
                UpdateProgress(0, "Geração de roupas cancelada.");
            }
            catch (Exception ex)
            {
                SetStageBadge(_badgeGrok, StageState.Failed, "ERRO");
                AppendLog("[Erro Figurino Automático] " + ex.Message);
                MessageBox.Show(ex.Message, "Erro ao Gerar Roupas pelo Texto", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                if (_selectedStory != null) RebuildEpisodeButtons(_selectedStory);
                RefreshAssetsGallery(null);
                RefreshTakesManagerList();
                SetRunningUiState(false);
            }
        }

        private async Task RunGenerateOutfitVariantFromUiAsync(string baseCharFile, string occasion, string outfitDesc, bool copyAll)
        {
            if (_isRunning || _selectedEpisode == null) return;
            SyncSettingsFromUi();
            SetRunningUiState(true);
            _runCts = new CancellationTokenSource();

            EpisodeWorkItem ep = _selectedEpisode;
            CancellationToken token = _runCts.Token;

            try
            {
                SetStageBadge(_badgeGrok, StageState.Running, "GERANDO ROUPA...");
                UpdateProgress(25, string.Format("Gerando roupa '{0}' para '{1}' no Grok Imagine...", occasion, baseCharFile));
                string variantName = await Task.Run(async () =>
                {
                    return await _grok.GenerateCharacterOutfitVariantAsync(ep, baseCharFile, occasion, outfitDesc, copyAll, token);
                });
                SetStageBadge(_badgeGrok, StageState.Success, "ROUPA OK");
                UpdateProgress(100, "Nova roupa criada e vinculada automaticamente: " + variantName);
            }
            catch (OperationCanceledException)
            {
                UpdateProgress(0, "Geração de roupa cancelada pelo usuário.");
                AppendLog("[Sistema] Geração de roupa cancelada.");
            }
            catch (Exception ex)
            {
                SetStageBadge(_badgeGrok, StageState.Failed, "ERRO");
                AppendLog("[Erro Figurino] " + ex.Message);
                MessageBox.Show(ex.Message, "Erro ao Gerar Roupa", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                if (_selectedStory != null) RebuildEpisodeButtons(_selectedStory);
                RefreshAssetsGallery(null);
                RefreshTakesManagerList();
                SetRunningUiState(false);
            }
        }

        // =================================================================================================
        // SUGESTÃO D: INDICADOR VISUAL DE CONTAS GROK + ADICIONAR PERFIL CHROME FÁCIL
        // =================================================================================================

        private void RefreshGrokProfileBadges()
        {
            if (_wrapGrokProfileBadges == null) return;
            _wrapGrokProfileBadges.Children.Clear();

            foreach (string prof in _config.GrokProfiles.ToList())
            {
                string st = _config.GetProfileStatus(prof);
                bool isExhausted = st.IndexOf("LIMITE", StringComparison.OrdinalIgnoreCase) >= 0;
                bool isAvailable = st.IndexOf("DISPONÍVEL", StringComparison.OrdinalIgnoreCase) >= 0;

                Brush borderBrush = isExhausted ? AccentRed : (isAvailable ? AccentGreen : BorderSubtle);
                Brush bgBrush = isExhausted ? BrushFromHex("#450A0A") : (isAvailable ? BrushFromHex("#064E3B") : BgInput);
                Brush fgBrush = isExhausted ? BrushFromHex("#FCA5A5") : (isAvailable ? BrushFromHex("#A7F3D0") : TextSecondary);

                Border pill = new Border
                {
                    Background = bgBrush,
                    BorderBrush = borderBrush,
                    BorderThickness = new Thickness(1.5),
                    CornerRadius = new CornerRadius(6),
                    Padding = new Thickness(10, 5, 10, 5),
                    Margin = new Thickness(0, 0, 8, 6)
                };

                StackPanel row = new StackPanel { Orientation = Orientation.Horizontal };
                string capturedProfForToggle = prof;
                TextBlock lblProfStatus = new TextBlock
                {
                    Text = string.Format("● {0}: {1}", prof, st),
                    FontSize = 11.5,
                    FontWeight = FontWeights.Bold,
                    Foreground = fgBrush,
                    VerticalAlignment = VerticalAlignment.Center,
                    Cursor = Cursors.Hand,
                    ToolTip = "Clique para alternar manualmente entre DISPONÍVEL e LIMITE ATINGIDO"
                };
                lblProfStatus.MouseLeftButtonUp += (s, e) =>
                {
                    string cur = _config.GetProfileStatus(capturedProfForToggle);
                    string next = cur.IndexOf("LIMITE", StringComparison.OrdinalIgnoreCase) >= 0 ? "DISPONÍVEL" : "LIMITE ATINGIDO";
                    _config.SetProfileStatus(capturedProfForToggle, next);
                    AppendLog(string.Format("[Contas Grok] Status do perfil '{0}' alterado manualmente para: {1}", capturedProfForToggle, next));
                };
                row.Children.Add(lblProfStatus);

                if (_config.GrokProfiles.Count > 1)
                {
                    string capturedProf = prof;
                    Button btnRemove = CreateStyledButton("✕", Brushes.Transparent, fgBrush, new Thickness(5, 0, 2, 0));
                    btnRemove.BorderThickness = new Thickness(0);
                    btnRemove.FontSize = 10.5;
                    btnRemove.Margin = new Thickness(6, 0, 0, 0);
                    btnRemove.ToolTip = "Remover este perfil da lista de fallback";
                    btnRemove.Click += (s, e) =>
                    {
                        _config.GrokProfiles.RemoveAll(p => string.Equals(p, capturedProf, StringComparison.OrdinalIgnoreCase));
                        if (_txtGrokProfiles != null)
                            _txtGrokProfiles.Text = string.Join(", ", _config.GrokProfiles);
                        _config.SaveUserSettings();
                        RefreshGrokProfileBadges();
                    };
                    row.Children.Add(btnRemove);
                }

                pill.Child = row;
                _wrapGrokProfileBadges.Children.Add(pill);
            }
        }

        private async Task CheckGrokAccountsStatusFromUiAsync()
        {
            if (_isRunning) return;
            SyncSettingsFromUi();
            AppendLog("[Contas Grok] Verificando status de limite de uso nos perfis configurados...");
            try
            {
                using (CancellationTokenSource cts = new CancellationTokenSource(45000))
                {
                    await _grok.CheckAllGrokProfilesStatusAsync(cts.Token);
                }
                RefreshGrokProfileBadges();
            }
            catch (Exception ex)
            {
                AppendLog("[Contas Grok] Erro ao verificar perfis: " + ex.Message);
            }
        }

        private void OnAddGrokProfileClick(object sender, RoutedEventArgs e)
        {
            string newProf = (_txtNewGrokProfile != null ? _txtNewGrokProfile.Text : "").Trim();
            if (string.IsNullOrEmpty(newProf))
            {
                MessageBox.Show("Digite o nome da pasta do perfil do Chrome (ex: Profile 68).", "Adicionar Perfil Grok", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            if (!_config.GrokProfiles.Contains(newProf, StringComparer.OrdinalIgnoreCase))
            {
                _config.GrokProfiles.Add(newProf);
                _config.SetProfileStatus(newProf, "NÃO VERIFICADO");
                if (_txtGrokProfiles != null)
                    _txtGrokProfiles.Text = string.Join(", ", _config.GrokProfiles);
                _config.SaveUserSettings();
                RefreshGrokProfileBadges();
                AppendLog(string.Format("[Contas Grok] Novo perfil adicionado e salvo: '{0}'.", newProf));
            }

            if (_txtNewGrokProfile != null)
                _txtNewGrokProfile.Text = "";
        }

        // =================================================================================================
        // SUGESTÃO E: SELETOR DE VOZES FAVORITAS DO ELEVENLABS COM 1 CLIQUE
        // =================================================================================================

        private bool _updatingVoiceCombos;

        private void RefreshElevenVoicePresetCombos()
        {
            _updatingVoiceCombos = true;
            try
            {
                ComboBox[] combos = new[] { _cmbElevenVoiceQuick, _cmbElevenVoiceSettings };
                foreach (ComboBox cmb in combos)
                {
                    if (cmb == null) continue;
                    cmb.Items.Clear();

                    int selectedIndex = 0;
                    for (int i = 0; i < _config.VoicePresets.Count; i++)
                    {
                        ElevenLabsVoicePreset vp = _config.VoicePresets[i];
                        cmb.Items.Add(new ComboBoxItem { Content = vp.ToString(), Tag = vp });
                        if (!string.IsNullOrEmpty(_config.ElevenLabsUrl) &&
                            _config.ElevenLabsUrl.IndexOf(vp.VoiceId ?? "", StringComparison.OrdinalIgnoreCase) >= 0)
                        {
                            selectedIndex = i;
                        }
                    }

                    if (cmb.Items.Count > 0)
                        cmb.SelectedIndex = selectedIndex;
                }
            }
            finally
            {
                _updatingVoiceCombos = false;
            }
        }

        private void OnQuickVoiceSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (_updatingVoiceCombos || _cmbElevenVoiceQuick == null) return;
            ComboBoxItem item = _cmbElevenVoiceQuick.SelectedItem as ComboBoxItem;
            if (item == null || !(item.Tag is ElevenLabsVoicePreset)) return;
            ApplySelectedVoicePreset((ElevenLabsVoicePreset)item.Tag);
        }

        private void OnSettingsVoiceSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (_updatingVoiceCombos || _cmbElevenVoiceSettings == null) return;
            ComboBoxItem item = _cmbElevenVoiceSettings.SelectedItem as ComboBoxItem;
            if (item == null || !(item.Tag is ElevenLabsVoicePreset)) return;
            ApplySelectedVoicePreset((ElevenLabsVoicePreset)item.Tag);
        }

        private void ApplySelectedVoicePreset(ElevenLabsVoicePreset preset)
        {
            if (preset == null) return;
            _config.ElevenLabsUrl = preset.BuildUrl();
            if (_txtElevenUrl != null)
                _txtElevenUrl.Text = _config.ElevenLabsUrl;
            _config.SaveUserSettings();
            RefreshElevenVoicePresetCombos();
            AppendLog(string.Format("[ElevenLabs Voz] Voz ativa alterada para: {0} -> {1}", preset.Name, _config.ElevenLabsUrl));
        }

        private void ShowAddElevenLabsVoiceDialog()
        {
            Window dlg = new Window
            {
                Title = "🎙 Cadastrar Nova Voz Favorita do ElevenLabs",
                Width = 520,
                Height = 310,
                WindowStartupLocation = WindowStartupLocation.CenterOwner,
                Owner = this,
                Background = BgPanel,
                Foreground = TextPrimary,
                ResizeMode = ResizeMode.NoResize
            };

            StackPanel sp = new StackPanel { Margin = new Thickness(18) };

            sp.Children.Add(new TextBlock { Text = "Nome da Voz (ex: Voz Feminina Novela, Voz Terror Grave):", FontSize = 12, Foreground = TextPrimary, Margin = new Thickness(0, 0, 0, 4) });
            TextBox txtName = CreateStyledTextBox("Ex: Narrador Misterioso");
            txtName.Margin = new Thickness(0, 0, 0, 10);
            sp.Children.Add(txtName);

            sp.Children.Add(new TextBlock { Text = "Categoria / Estilo (ex: Novela / Reflexão, Terror):", FontSize = 12, Foreground = TextPrimary, Margin = new Thickness(0, 0, 0, 4) });
            TextBox txtCat = CreateStyledTextBox("Novela / Reflexão");
            txtCat.Text = "Novela / Reflexão";
            txtCat.Margin = new Thickness(0, 0, 0, 10);
            sp.Children.Add(txtCat);

            sp.Children.Add(new TextBlock { Text = "Voice ID ou URL completa do ElevenLabs:", FontSize = 12, Foreground = TextPrimary, Margin = new Thickness(0, 0, 0, 4) });
            TextBox txtVoiceId = CreateStyledTextBox("Ex: ppLqTilh7rH7fbUVlXsf ou https://elevenlabs.io/app/...?voiceId=...");
            txtVoiceId.Margin = new Thickness(0, 0, 0, 16);
            sp.Children.Add(txtVoiceId);

            StackPanel btns = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };
            Button btnCancel = CreateStyledButton("Cancelar", BgCard, TextPrimary, new Thickness(12, 6, 12, 6));
            btnCancel.Margin = new Thickness(0, 0, 10, 0);
            btnCancel.Click += (s, e) => dlg.DialogResult = false;
            btns.Children.Add(btnCancel);

            Button btnSave = CreateStyledButton("💾 Salvar e Selecionar Voz", AccentGreen, Brushes.White, new Thickness(14, 6, 14, 6));
            btnSave.FontWeight = FontWeights.Bold;
            btnSave.Click += (s, e) => dlg.DialogResult = true;
            btns.Children.Add(btnSave);

            sp.Children.Add(btns);
            dlg.Content = sp;

            if (dlg.ShowDialog() == true)
            {
                string name = (txtName.Text ?? "").Trim();
                string cat = (txtCat.Text ?? "Novela").Trim();
                string rawVid = (txtVoiceId.Text ?? "").Trim();
                if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(rawVid)) return;

                Match m = Regex.Match(rawVid, @"voiceId=([A-Za-z0-9]+)", RegexOptions.IgnoreCase);
                string cleanVid = m.Success ? m.Groups[1].Value : rawVid;

                ElevenLabsVoicePreset newPreset = new ElevenLabsVoicePreset
                {
                    Name = name,
                    Category = cat,
                    VoiceId = cleanVid
                };
                _config.VoicePresets.Add(newPreset);
                ApplySelectedVoicePreset(newPreset);
            }
        }

        private class ChromeLocalProfileItem
        {
            public string DirName;
            public string DisplayName;
            public string Email;
            public CheckBox ChkGrok;
            public RadioButton RbFlow;
            public CheckBox ChkEleven;
        }

        private List<ChromeLocalProfileItem> DiscoverLocalChromeProfiles()
        {
            List<ChromeLocalProfileItem> result = new List<ChromeLocalProfileItem>();
            string localAppData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            string userDataDir = Path.Combine(localAppData, @"Google\Chrome\User Data");
            string localStatePath = Path.Combine(userDataDir, "Local State");

            Dictionary<string, ChromeLocalProfileItem> byDir = new Dictionary<string, ChromeLocalProfileItem>(StringComparer.OrdinalIgnoreCase);

            try
            {
                if (File.Exists(localStatePath))
                {
                    string json = File.ReadAllText(localStatePath, Encoding.UTF8);
                    System.Web.Script.Serialization.JavaScriptSerializer ser = new System.Web.Script.Serialization.JavaScriptSerializer();
                    ser.MaxJsonLength = int.MaxValue;
                    Dictionary<string, object> root = ser.Deserialize<Dictionary<string, object>>(json);
                    if (root != null && root.ContainsKey("profile") && root["profile"] is Dictionary<string, object>)
                    {
                        Dictionary<string, object> profObj = (Dictionary<string, object>)root["profile"];
                        if (profObj.ContainsKey("info_cache") && profObj["info_cache"] is Dictionary<string, object>)
                        {
                            Dictionary<string, object> cache = (Dictionary<string, object>)profObj["info_cache"];
                            foreach (KeyValuePair<string, object> kv in cache)
                            {
                                Dictionary<string, object> info = kv.Value as Dictionary<string, object>;
                                if (info == null) continue;
                                string name = info.ContainsKey("name") ? Convert.ToString(info["name"] ?? "").Trim() : "";
                                string email = info.ContainsKey("user_name") ? Convert.ToString(info["user_name"] ?? "").Trim() : "";
                                byDir[kv.Key] = new ChromeLocalProfileItem
                                {
                                    DirName = kv.Key,
                                    DisplayName = string.IsNullOrEmpty(name) ? kv.Key : name,
                                    Email = email
                                };
                            }
                        }
                    }
                }
            }
            catch { }

            try
            {
                if (Directory.Exists(userDataDir))
                {
                    foreach (string sub in Directory.GetDirectories(userDataDir))
                    {
                        string dn = Path.GetFileName(sub);
                        if (string.Equals(dn, "Default", StringComparison.OrdinalIgnoreCase) ||
                            dn.StartsWith("Profile ", StringComparison.OrdinalIgnoreCase))
                        {
                            if (!byDir.ContainsKey(dn))
                            {
                                byDir[dn] = new ChromeLocalProfileItem
                                {
                                    DirName = dn,
                                    DisplayName = dn,
                                    Email = ""
                                };
                            }
                        }
                    }
                }
            }
            catch { }

            if (byDir.Count == 0)
            {
                byDir["Default"] = new ChromeLocalProfileItem { DirName = "Default", DisplayName = "Perfil Padrão", Email = "" };
                byDir["Profile 1"] = new ChromeLocalProfileItem { DirName = "Profile 1", DisplayName = "Profile 1", Email = "" };
                byDir["Profile 2"] = new ChromeLocalProfileItem { DirName = "Profile 2", DisplayName = "Profile 2", Email = "" };
            }

            result = byDir.Values
                .OrderBy(p => string.Equals(p.DirName, "Default", StringComparison.OrdinalIgnoreCase) ? 0 : 1)
                .ThenBy(p =>
                {
                    int num;
                    if (p.DirName.StartsWith("Profile ", StringComparison.OrdinalIgnoreCase) &&
                        int.TryParse(p.DirName.Substring(8).Trim(), out num))
                        return num;
                    return 9999;
                })
                .ToList();

            return result;
        }

        private void ShowChromeProfileSelectorDialog()
        {
            SyncSettingsFromUi();
            List<ChromeLocalProfileItem> profiles = DiscoverLocalChromeProfiles();

            Window dlg = new Window
            {
                Title = "Configurar Contas do Chrome neste PC (Grok Imagine / Google Flow / ElevenLabs)",
                Width = 860,
                Height = 620,
                WindowStartupLocation = WindowStartupLocation.CenterOwner,
                Owner = this,
                Background = BgPanel,
                Foreground = TextPrimary
            };

            Grid root = new Grid { Margin = new Thickness(16) };
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

            StackPanel header = new StackPanel { Margin = new Thickness(0, 0, 0, 12) };
            header.Children.Add(new TextBlock
            {
                Text = "Perfis do Google Chrome encontrados neste computador:",
                FontSize = 14,
                FontWeight = FontWeights.Bold,
                Foreground = TextPrimary
            });
            header.Children.Add(new TextBlock
            {
                Text = "Marque quais perfis deste PC você usa para o Grok Imagine, qual usa para o Google Flow e quais usa para o ElevenLabs. Use os botões 'Abrir' para fazer login se ainda não estiver logado.",
                FontSize = 11.5,
                Foreground = TextSecondary,
                TextWrapping = TextWrapping.Wrap,
                Margin = new Thickness(0, 4, 0, 0)
            });
            Grid.SetRow(header, 0);
            root.Children.Add(header);

            ScrollViewer sv = new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto };
            StackPanel listStack = new StackPanel();

            foreach (ChromeLocalProfileItem item in profiles)
            {
                Border card = new Border
                {
                    Background = BgCard,
                    BorderBrush = BorderSubtle,
                    BorderThickness = new Thickness(1),
                    CornerRadius = new CornerRadius(6),
                    Padding = new Thickness(10, 8, 10, 8),
                    Margin = new Thickness(0, 0, 0, 6)
                };

                Grid row = new Grid();
                row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
                row.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
                row.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

                StackPanel infoCol = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
                infoCol.Children.Add(new TextBlock
                {
                    Text = string.Format("{0}  —  {1}", item.DirName, item.DisplayName),
                    FontSize = 12.5,
                    FontWeight = FontWeights.Bold,
                    Foreground = TextPrimary
                });
                infoCol.Children.Add(new TextBlock
                {
                    Text = string.IsNullOrEmpty(item.Email) ? "(Sem e-mail Google sincronizado)" : item.Email,
                    FontSize = 11,
                    Foreground = TextSecondary
                });
                Grid.SetColumn(infoCol, 0);
                row.Children.Add(infoCol);

                StackPanel checksCol = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(12, 0, 12, 0) };
                item.ChkGrok = new CheckBox
                {
                    Content = "Grok",
                    Foreground = TextPrimary,
                    IsChecked = _config.GrokProfiles.Any(p => string.Equals(p, item.DirName, StringComparison.OrdinalIgnoreCase)),
                    Margin = new Thickness(0, 0, 12, 0),
                    VerticalAlignment = VerticalAlignment.Center
                };
                checksCol.Children.Add(item.ChkGrok);

                item.RbFlow = new RadioButton
                {
                    GroupName = "FlowProfGroup",
                    Content = "Flow",
                    Foreground = TextPrimary,
                    IsChecked = string.Equals(_config.FlowProfile, item.DirName, StringComparison.OrdinalIgnoreCase),
                    Margin = new Thickness(0, 0, 12, 0),
                    VerticalAlignment = VerticalAlignment.Center
                };
                checksCol.Children.Add(item.RbFlow);

                item.ChkEleven = new CheckBox
                {
                    Content = "ElevenLabs",
                    Foreground = TextPrimary,
                    IsChecked = _config.ElevenLabsProfiles.Any(p => string.Equals(p, item.DirName, StringComparison.OrdinalIgnoreCase)),
                    VerticalAlignment = VerticalAlignment.Center
                };
                checksCol.Children.Add(item.ChkEleven);
                Grid.SetColumn(checksCol, 1);
                row.Children.Add(checksCol);

                StackPanel openBtns = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };
                string capDir = item.DirName;

                Button bGrok = CreateStyledButton("Abrir Grok", BgInput, TextPrimary, new Thickness(8, 4, 8, 4));
                bGrok.FontSize = 10.5;
                bGrok.Margin = new Thickness(0, 0, 4, 0);
                bGrok.Click += (s, e) => _cdp.LaunchChromeProfileWindow(capDir, "https://grok.com/imagine");
                openBtns.Children.Add(bGrok);

                Button bFlow = CreateStyledButton("Abrir Flow", BgInput, TextPrimary, new Thickness(8, 4, 8, 4));
                bFlow.FontSize = 10.5;
                bFlow.Margin = new Thickness(0, 0, 4, 0);
                bFlow.Click += (s, e) => _cdp.LaunchChromeProfileWindow(capDir, _config.FlowProjectUrl);
                openBtns.Children.Add(bFlow);

                Button bEl = CreateStyledButton("Abrir Eleven", BgInput, TextPrimary, new Thickness(8, 4, 8, 4));
                bEl.FontSize = 10.5;
                bEl.Click += (s, e) => _cdp.LaunchChromeProfileWindow(capDir, _config.ElevenLabsUrl);
                openBtns.Children.Add(bEl);

                Grid.SetColumn(openBtns, 2);
                row.Children.Add(openBtns);

                card.Child = row;
                listStack.Children.Add(card);
            }

            sv.Content = listStack;
            Grid.SetRow(sv, 1);
            root.Children.Add(sv);

            StackPanel footer = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(0, 12, 0, 0) };

            Button btnCancel = CreateStyledButton("Cancelar", BgCard, TextPrimary, new Thickness(14, 7, 14, 7));
            btnCancel.Margin = new Thickness(0, 0, 10, 0);
            btnCancel.Click += (s, e) => dlg.DialogResult = false;
            footer.Children.Add(btnCancel);

            Button btnSave = CreateStyledButton("💾 Salvar e Aplicar Perfis neste PC", AccentGreen, Brushes.White, new Thickness(16, 7, 16, 7));
            btnSave.FontWeight = FontWeights.Bold;
            btnSave.Click += (s, e) => dlg.DialogResult = true;
            footer.Children.Add(btnSave);

            Grid.SetRow(footer, 2);
            root.Children.Add(footer);
            dlg.Content = root;

            if (dlg.ShowDialog() == true)
            {
                List<string> newGrok = profiles.Where(p => p.ChkGrok.IsChecked == true).Select(p => p.DirName).ToList();
                ChromeLocalProfileItem flowSel = profiles.FirstOrDefault(p => p.RbFlow.IsChecked == true);
                List<string> newEleven = profiles.Where(p => p.ChkEleven.IsChecked == true).Select(p => p.DirName).ToList();

                if (newGrok.Count > 0)
                {
                    _config.GrokProfiles = newGrok;
                    if (_txtGrokProfiles != null) _txtGrokProfiles.Text = string.Join(", ", newGrok);
                }
                if (flowSel != null)
                {
                    _config.FlowProfile = flowSel.DirName;
                    if (_txtFlowProfile != null) _txtFlowProfile.Text = flowSel.DirName;
                }
                if (newEleven.Count > 0)
                {
                    _config.ElevenLabsProfiles = newEleven;
                    if (_txtElevenProfiles != null) _txtElevenProfiles.Text = string.Join(", ", newEleven);
                }

                _config.SaveUserSettings();
                RefreshGrokProfileBadges();
                AppendLog(string.Format("[Configurações] Perfis do Chrome atualizados neste PC -> Grok: [{0}] | Flow: {1} | ElevenLabs: [{2}]",
                    string.Join(", ", _config.GrokProfiles), _config.FlowProfile, string.Join(", ", _config.ElevenLabsProfiles)));
            }
        }

        private string _lastDismissedUpdateVersion = "";
        private bool _isUpdatePromptOpen = false;

        private async Task MonitorAndPromptRemoteUpdateOnOtherPcAsync()
        {
            await Task.Delay(2500);
            while (true)
            {
                try
                {
                    if (!_isRunning && !_isUpdatePromptOpen)
                    {
                        _config.LoadSharedRemoteUpdateConfig();
                        string repo = (_config.RemoteUpdateRepo ?? "").Trim();
                        if (string.IsNullOrEmpty(repo))
                            repo = "gs6177/fluxo-video-studio-updates";

                        if (!repo.StartsWith("http", StringComparison.OrdinalIgnoreCase))
                        {
                            System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072; // Tls12
                            string cleanRepo = repo.Replace("https://github.com/", "").Replace(".git", "").Trim('/');
                            string apiUrl = string.Format("https://api.github.com/repos/{0}/contents/version.json?t={1}",
                                cleanRepo, DateTime.UtcNow.Ticks);
                            string rawUrl = string.Format("https://raw.githubusercontent.com/{0}/main/version.json?t={1}",
                                cleanRepo, DateTime.UtcNow.Ticks);

                            string json = await Task.Run(() =>
                            {
                                try
                                {
                                    using (System.Net.WebClient wc = new System.Net.WebClient())
                                    {
                                        wc.Encoding = Encoding.UTF8;
                                        wc.Headers.Add("User-Agent", "FluxoVideoStudio-AutoUpdater");
                                        wc.Headers.Add("Accept", "application/vnd.github.v3.raw");
                                        wc.Headers.Add("Cache-Control", "no-cache");
                                        return wc.DownloadString(apiUrl);
                                    }
                                }
                                catch
                                {
                                    using (System.Net.WebClient wc = new System.Net.WebClient())
                                    {
                                        wc.Encoding = Encoding.UTF8;
                                        wc.Headers.Add("User-Agent", "FluxoVideoStudio-AutoUpdater");
                                        wc.Headers.Add("Cache-Control", "no-cache");
                                        return wc.DownloadString(rawUrl);
                                    }
                                }
                            });

                            if (!string.IsNullOrWhiteSpace(json))
                            {
                                System.Web.Script.Serialization.JavaScriptSerializer ser = new System.Web.Script.Serialization.JavaScriptSerializer();
                                Dictionary<string, object> d = ser.Deserialize<Dictionary<string, object>>(json);
                                if (d != null && d.ContainsKey("Version"))
                                {
                                    string remoteVer = Convert.ToString(d["Version"] ?? "").Trim();
                                    string updatedAt = d.ContainsKey("UpdatedAt") ? Convert.ToString(d["UpdatedAt"] ?? "").Trim() : remoteVer;
                                    string localVer = (_config.LocalInstalledVersion ?? "").Trim();

                                    if (!string.IsNullOrEmpty(remoteVer) &&
                                        !string.Equals(remoteVer, localVer, StringComparison.OrdinalIgnoreCase) &&
                                        !string.Equals(remoteVer, _lastDismissedUpdateVersion, StringComparison.OrdinalIgnoreCase))
                                    {
                                        string pullScript = Path.Combine(PipelineConfig.GetAppRootDir(), "Baixar_Atualizacao_Remota.ps1");
                                        if (File.Exists(pullScript))
                                        {
                                            Dispatcher.Invoke(() =>
                                            {
                                                PromptOtherPcForUpdateDialog(cleanRepo, remoteVer, updatedAt, pullScript);
                                            });
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                catch { }

                await Task.Delay(20000);
            }
        }

        private void PromptOtherPcForUpdateDialog(string cleanRepo, string remoteVer, string updatedAt, string pullScript)
        {
            if (_isUpdatePromptOpen) return;
            _isUpdatePromptOpen = true;
            try
            {
                try { System.Media.SystemSounds.Asterisk.Play(); } catch { }

                AppendLog(string.Format("[Atualização Disponível] Nova versão ({0}) liberada pelo PC Principal!", remoteVer));

                Window notif = new Window
                {
                    Title = "🔔 Nova Atualização Disponível — Fluxo Vídeo IA Studio",
                    Width = 520,
                    Height = 250,
                    WindowStartupLocation = WindowStartupLocation.CenterScreen,
                    Topmost = true,
                    Background = BgPanel,
                    Foreground = TextPrimary,
                    ResizeMode = ResizeMode.NoResize
                };

                StackPanel sp = new StackPanel { Margin = new Thickness(20) };

                sp.Children.Add(new TextBlock
                {
                    Text = "🔔 Nova Atualização Disponível!",
                    FontSize = 16,
                    FontWeight = FontWeights.Bold,
                    Foreground = AccentGreen,
                    Margin = new Thickness(0, 0, 0, 8)
                });

                sp.Children.Add(new TextBlock
                {
                    Text = string.Format(
                        "Uma nova atualização do programa e das 5 Skills foi liberada pelo PC Principal ({0}).\n\nDeseja baixar e instalar a atualização agora?\n(Suas contas do Chrome e pastas configuradas neste PC serão mantidas).",
                        updatedAt),
                    FontSize = 12.5,
                    Foreground = TextPrimary,
                    TextWrapping = TextWrapping.Wrap,
                    Margin = new Thickness(0, 0, 0, 20)
                });

                StackPanel btnRow = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };

                Button btnLater = CreateStyledButton("Mais Tarde", BgCard, TextSecondary, new Thickness(14, 8, 14, 8));
                btnLater.Margin = new Thickness(0, 0, 10, 0);
                btnLater.Click += (s, e) =>
                {
                    _lastDismissedUpdateVersion = remoteVer;
                    notif.DialogResult = false;
                };
                btnRow.Children.Add(btnLater);

                Button btnNow = CreateStyledButton("🔄 Sim, Atualizar Agora", AccentGreen, Brushes.White, new Thickness(16, 8, 16, 8));
                btnNow.FontWeight = FontWeights.Bold;
                btnNow.Click += (s, e) => notif.DialogResult = true;
                btnRow.Children.Add(btnNow);

                sp.Children.Add(btnRow);
                notif.Content = sp;

                if (notif.ShowDialog() == true)
                {
                    int curPid = Process.GetCurrentProcess().Id;
                    ProcessStartInfo psi = new ProcessStartInfo
                    {
                        FileName = "powershell.exe",
                        Arguments = string.Format("-NoProfile -ExecutionPolicy Bypass -File \"{0}\" -RepoOrUrl \"{1}\" -WaitPid {2} -RestartApp",
                            pullScript, cleanRepo, curPid),
                        UseShellExecute = true,
                        WorkingDirectory = PipelineConfig.GetAppRootDir()
                    };
                    Process.Start(psi);
                    Application.Current.Shutdown();
                }
            }
            finally
            {
                _isUpdatePromptOpen = false;
            }
        }

        private void ShowRemoteUpdateDialog()
        {
            if (!PipelineConfig.IsMasterDeveloperPc())
                return;

            Window dlg = new Window
            {
                Title = "☁️ Publicar Atualização Remota (Exclusivo deste PC Principal)",
                Width = 680,
                Height = 470,
                WindowStartupLocation = WindowStartupLocation.CenterOwner,
                Owner = this,
                Background = BgPanel,
                Foreground = TextPrimary,
                ResizeMode = ResizeMode.NoResize
            };

            StackPanel sp = new StackPanel { Margin = new Thickness(18) };

            sp.Children.Add(new TextBlock
            {
                Text = "Publicação Remota via GitHub (Exclusivo do seu PC Principal)",
                FontSize = 14,
                FontWeight = FontWeights.Bold,
                Foreground = TextPrimary,
                Margin = new Thickness(0, 0, 0, 6)
            });

            sp.Children.Add(new TextBlock
            {
                Text = "• Este botão aparece SOMENTE no seu PC principal.\n• Quando você clicar em 'Publicar Atualização no GitHub', os outros PCs atualizarão sozinhos automaticamente ao abrirem o programa!",
                FontSize = 11.5,
                Foreground = TextSecondary,
                TextWrapping = TextWrapping.Wrap,
                Margin = new Thickness(0, 0, 0, 14)
            });

            sp.Children.Add(new TextBlock
            {
                Text = "Repositório GitHub (ex: seu-usuario/fluxo-video-studio-updates) ou Link Direto (.zip):",
                FontSize = 12,
                FontWeight = FontWeights.SemiBold,
                Foreground = TextPrimary,
                Margin = new Thickness(0, 0, 0, 4)
            });
            TextBox txtRepo = CreateStyledTextBox("Deixe em branco na 1ª publicação para criar 'fluxo-video-studio-updates' automaticamente");
            txtRepo.Text = _config.RemoteUpdateRepo ?? "";
            txtRepo.Margin = new Thickness(0, 0, 0, 12);
            sp.Children.Add(txtRepo);

            Grid tokenHeader = new Grid { Margin = new Thickness(0, 0, 0, 4) };
            tokenHeader.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            tokenHeader.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            tokenHeader.Children.Add(new TextBlock
            {
                Text = "Token do GitHub (Necessário APENAS neste PC principal para enviar atualizações):",
                FontSize = 12,
                FontWeight = FontWeights.SemiBold,
                Foreground = TextPrimary,
                VerticalAlignment = VerticalAlignment.Center
            });

            Button btnGenToken = CreateStyledButton("🔑 Abrir GitHub para Gerar Token (1 Clique)", BgCard, AccentBlue, new Thickness(10, 4, 10, 4));
            btnGenToken.FontSize = 11;
            btnGenToken.Click += (s, e) =>
            {
                try
                {
                    Process.Start("https://github.com/settings/tokens/new?description=FluxoVideoStudio&scopes=repo");
                }
                catch { }
            };
            Grid.SetColumn(btnGenToken, 1);
            tokenHeader.Children.Add(btnGenToken);
            sp.Children.Add(tokenHeader);

            TextBox txtToken = CreateStyledTextBox("Cole aqui seu Personal Access Token do GitHub (ghp_...)");
            txtToken.Text = _config.RemoteUpdateToken ?? "";
            txtToken.Margin = new Thickness(0, 0, 0, 14);
            sp.Children.Add(txtToken);

            TextBlock lblStatus = new TextBlock
            {
                Text = "Pronto.",
                FontSize = 12,
                FontWeight = FontWeights.SemiBold,
                Foreground = AccentAmber,
                TextWrapping = TextWrapping.Wrap,
                Margin = new Thickness(0, 0, 0, 14)
            };
            sp.Children.Add(lblStatus);

            StackPanel actionRow = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 0, 0, 14) };

            Button btnPull = CreateStyledButton("🔄 Baixar e Instalar Atualização Agora (Outro PC)", AccentGreen, Brushes.White, new Thickness(14, 9, 14, 9));
            btnPull.FontWeight = FontWeights.Bold;
            btnPull.Margin = new Thickness(0, 0, 10, 0);

            Button btnPush = CreateStyledButton("☁️ Publicar Atualização no GitHub (PC Principal)", BrushFromHex("#0284C7"), Brushes.White, new Thickness(14, 9, 14, 9));
            btnPush.FontWeight = FontWeights.Bold;

            btnPush.Click += async (s, e) =>
            {
                string repoVal = (txtRepo.Text ?? "").Trim();
                string tokenVal = (txtToken.Text ?? "").Trim();
                if (string.IsNullOrEmpty(tokenVal))
                {
                    MessageBox.Show("Para publicar a partir deste PC, clique em '🔑 Abrir GitHub para Gerar Token (1 Clique)', role até o final da página do GitHub, clique no botão verde 'Generate token' e cole o código aqui.", "Token do GitHub Necessário", MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }

                _config.RemoteUpdateRepo = repoVal;
                _config.RemoteUpdateToken = tokenVal;
                _config.SaveUserSettings();

                btnPush.IsEnabled = false;
                btnPull.IsEnabled = false;
                lblStatus.Foreground = AccentAmber;
                lblStatus.Text = "⏳ Empacotando Programa + 6 Skills (incluindo gem 3D Pixar/Disney) e enviando para o GitHub...";

                try
                {
                    string scriptPath = Path.Combine(PipelineConfig.GetAppRootDir(), "Publicar_Atualizacao_Remota.ps1");
                    string output = await Task.Run(() =>
                    {
                        ProcessStartInfo psi = new ProcessStartInfo
                        {
                            FileName = "powershell.exe",
                            Arguments = string.Format("-NoProfile -ExecutionPolicy Bypass -File \"{0}\" -Token \"{1}\" -Repo \"{2}\"",
                                scriptPath, tokenVal, repoVal),
                            UseShellExecute = false,
                            RedirectStandardOutput = true,
                            RedirectStandardError = true,
                            CreateNoWindow = true,
                            StandardOutputEncoding = Encoding.UTF8,
                            StandardErrorEncoding = Encoding.UTF8
                        };
                        using (Process p = Process.Start(psi))
                        {
                            string stdOut = p.StandardOutput.ReadToEnd();
                            string stdErr = p.StandardError.ReadToEnd();
                            p.WaitForExit();
                            if (p.ExitCode != 0)
                                throw new InvalidOperationException((stdErr + "\n" + stdOut).Trim());
                            return stdOut;
                        }
                    });

                    _config.LoadUserSettings();
                    txtRepo.Text = _config.RemoteUpdateRepo;
                    lblStatus.Foreground = AccentGreen;
                    lblStatus.Text = string.Format("✅ Publicado com sucesso em '{0}'! Agora no outro PC basta clicar em 'Baixar e Instalar Atualização Agora'.", _config.RemoteUpdateRepo);
                    AppendLog(string.Format("[Atualização Remota] Publicada com sucesso no GitHub: https://github.com/{0}", _config.RemoteUpdateRepo));
                }
                catch (Exception ex)
                {
                    lblStatus.Foreground = AccentRed;
                    lblStatus.Text = "❌ Erro ao publicar: " + ex.Message;
                }
                finally
                {
                    btnPush.IsEnabled = true;
                    btnPull.IsEnabled = true;
                }
            };

            btnPull.Click += (s, e) =>
            {
                string repoVal = (txtRepo.Text ?? "").Trim();
                string tokenVal = (txtToken.Text ?? "").Trim();
                if (string.IsNullOrEmpty(repoVal))
                {
                    MessageBox.Show("Informe o nome do Repositório GitHub (ex: usuario/fluxo-video-studio-updates) ou link direto do .zip.", "Repositório Necessário", MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }

                _config.RemoteUpdateRepo = repoVal;
                _config.RemoteUpdateToken = tokenVal;
                _config.SaveUserSettings();

                string pullScript = Path.Combine(PipelineConfig.GetAppRootDir(), "Baixar_Atualizacao_Remota.ps1");
                if (!File.Exists(pullScript))
                {
                    MessageBox.Show("Script Baixar_Atualizacao_Remota.ps1 não encontrado na pasta do programa.", "Erro", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                int curPid = Process.GetCurrentProcess().Id;
                ProcessStartInfo psi = new ProcessStartInfo
                {
                    FileName = "powershell.exe",
                    Arguments = string.Format("-NoProfile -ExecutionPolicy Bypass -File \"{0}\" -RepoOrUrl \"{1}\" -Token \"{2}\" -WaitPid {3} -RestartApp",
                        pullScript, repoVal, tokenVal, curPid),
                    UseShellExecute = true,
                    WorkingDirectory = PipelineConfig.GetAppRootDir()
                };
                Process.Start(psi);
                Application.Current.Shutdown();
            };

            actionRow.Children.Add(btnPull);
            actionRow.Children.Add(btnPush);
            sp.Children.Add(actionRow);

            StackPanel bottomRow = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };
            Button btnClose = CreateStyledButton("Salvar e Fechar", BgCard, TextPrimary, new Thickness(14, 7, 14, 7));
            btnClose.Click += (s, e) =>
            {
                _config.RemoteUpdateRepo = (txtRepo.Text ?? "").Trim();
                _config.RemoteUpdateToken = (txtToken.Text ?? "").Trim();
                _config.SaveUserSettings();
                dlg.Close();
            };
            bottomRow.Children.Add(btnClose);
            sp.Children.Add(bottomRow);

            dlg.Content = sp;
            dlg.ShowDialog();
        }
    }
}
