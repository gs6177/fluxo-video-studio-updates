using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace FluxoVideoStudio
{
    public partial class FlowAutomation
    {
        private List<MountedGridTileState> ParseMountedTilesFromEval(Dictionary<string, object> rawObj)
        {
            List<MountedGridTileState> list = new List<MountedGridTileState>();
            if (rawObj == null || !rawObj.ContainsKey("tiles")) return list;
            IEnumerable arr = rawObj["tiles"] as IEnumerable;
            if (arr == null) return list;

            foreach (object elem in arr)
            {
                Dictionary<string, object> d = elem as Dictionary<string, object>;
                if (d == null) continue;
                MountedGridTileState st = new MountedGridTileState();
                st.MountedIndex = d.ContainsKey("idx") ? Convert.ToInt32(d["idx"]) : list.Count;
                st.AsbId = d.ContainsKey("asb") ? Convert.ToString(d["asb"] ?? "") : "";
                st.HasPct = d.ContainsKey("hasPct") && Convert.ToBoolean(d["hasPct"]);
                st.PctText = d.ContainsKey("pctText") ? Convert.ToString(d["pctText"] ?? "") : "";
                st.HasVideo = d.ContainsKey("hasVideo") && Convert.ToBoolean(d["hasVideo"]);
                st.HasMoreBtn = d.ContainsKey("hasMoreBtn") && Convert.ToBoolean(d["hasMoreBtn"]);
                st.HasErr = d.ContainsKey("hasErr") && Convert.ToBoolean(d["hasErr"]);
                st.IsMinorErr = d.ContainsKey("isMinorErr") && Convert.ToBoolean(d["isMinorErr"]);
                st.HasSpinner = d.ContainsKey("hasSpinner") && Convert.ToBoolean(d["hasSpinner"]);
                list.Add(st);
            }
            return list;
        }

        private async Task<SessionPollSnapshot> InspectCurrentSessionStateAsync(
            string sess,
            PreSessionGridBaseline baseline,
            CancellationToken ct)
        {
            // Garante que o virtual scroll esteja em scrollTop = 0 para inspecionar os cards recém-criados no topo
            string scrolledReset = await _cdp.EvalStringAsync(sess, @"
(function(){
    var vp = document.querySelector('cdk-virtual-scroll-viewport.tiles-container') || document.querySelector('cdk-virtual-scroll-viewport');
    if (vp && vp.scrollTop > 8) {
        vp.scrollTop = 0;
        return 'RESET';
    }
    return 'AT_TOP';
})()", ct);

            if (scrolledReset == "RESET")
                await Task.Delay(380, ct);

            string inspectJs = @"
(function(){
    var rawTiles = Array.from(document.querySelectorAll('flow-video-tile, flow-pending-tile, flow-error-tile'));
    var topLevelTiles = rawTiles.filter(function(el) {
        var p = el.parentElement;
        return !p || !p.closest('flow-video-tile, flow-pending-tile, flow-error-tile');
    });
    var tiles = topLevelTiles.map((t, idx) => {
        var tagLower = (t.tagName || '').toLowerCase();
        var isPendingTileTag = tagLower === 'flow-pending-tile' || !!t.querySelector('flow-pending-tile');
        var isErrorTileTag = tagLower === 'flow-error-tile' || !!t.querySelector('flow-error-tile');
        var vid = t.querySelector('video');
        var img = t.querySelector('img.thumbnail') || t.querySelector('img');
        var mediaUrl = (img ? (img.getAttribute('src') || '') : '') + ' ' +
                       (vid ? ((vid.getAttribute('poster') || '') + ' ' + (vid.getAttribute('src') || '')) : '');
        var m = mediaUrl.match(/\/asb\/([A-Za-z0-9_\-]{25,80})/);
        var asb = m ? m[1] : '';
        var txt = (t.innerText || '');
        var pctM = txt.match(/\b\d{1,2}%\b/);
        var pctText = pctM ? pctM[0] : '';
        var hasPct = !!pctM;
        var hasMoreBtn = !!t.querySelector('button[aria-label*=""Mais op""], button[aria-label*=""More""]');
        var hasVideo = !!vid || (!!img && asb.length > 0);
        var hasSpinner = isPendingTileTag || !!t.querySelector('mat-progress-spinner, mat-spinner, [role=""progressbar""], [class*=""spinner""], [class*=""loading""]');
        var hasFailActionBtn = !hasVideo && !asb && !!t.querySelector(
            'button[aria-label*=""Excluir""], button[aria-label*=""Delete""], button[aria-label*=""Reutilizar""], button[aria-label*=""Reuse""], button[aria-label*=""Tentar""], button[aria-label*=""Retry""]'
        );
        var hasErr = !hasVideo && !hasMoreBtn && !asb && !hasPct && (
            isErrorTileTag ||
            /violar|pol[ií]ticas|falha|erro|errado|n[aã]o\s+foi\s+poss[ií]vel|n[aã]o\s+[eé]\s+poss[ií]vel|n[aã]o\s+p[oô]de|bloquead|tente\s+(?:novamente|de\s+novo)|violate|failed|error|wrong|unable\s+to|cannot\s+generate|blocked|try\s+again|policy/i.test(txt) ||
            (hasFailActionBtn && !hasSpinner)
        );
        var isMinorErr = hasErr &&
                     /\b(menores\s+de\s+idade|menor\s+de\s+idade|relacionado\s+a\s+menores|menores|crian[cç]as?|minors?|children|child|underage)\b/i.test(txt);
        return {
            idx: idx,
            asb: asb,
            hasPct: hasPct,
            pctText: pctText,
            hasVideo: hasVideo,
            hasMoreBtn: hasMoreBtn,
            hasErr: hasErr,
            isMinorErr: isMinorErr,
            hasSpinner: hasSpinner
        };
    });

    var panel = document.querySelector('flow-agent-panel');
    var vidOptCount = panel ? panel.querySelectorAll('flow-a2ui-video-option').length : 0;
    var chatBubbles = panel ? Array.from(panel.querySelectorAll('flow-chat-bubble')) : [];
    var bubbleCount = chatBubbles.length;

    // Restrito estritamente ao painel do Agente para nunca confundir botão Stop/Parar de players da grade
    var agentStopBtn = !!(panel && Array.from(panel.querySelectorAll('button')).find(b => {
        var al = (b.getAttribute('aria-label') || '');
        var txt = (b.innerText || '').trim();
        var r = b.getBoundingClientRect();
        return r.width > 10 && (al.indexOf('Parar') >= 0 || al.indexOf('Stop') >= 0 || txt === 'stop' || txt === 'stop_circle');
    }));

    var agentSpinner = !!(panel && Array.from(panel.querySelectorAll('mat-progress-spinner, [role=""progressbar""], .thinking-indicator, flow-chat-thinking-indicator'))
        .find(el => !el.closest('flow-a2ui-video-option, flow-video-tile, flow-image-tile') && el.getBoundingClientRect().width > 6));

    var panelTxt = panel ? (panel.innerText || '').toLowerCase() : '';
    var unusualMatches = panelTxt.match(/atividade incomum|unusual activity/g) || [];
    var unusualCount = unusualMatches.length;

    // Inspeciona apenas o último turno no final da sessão aberta para não disparar em avisos antigos do histórico
    var tailTxt = '';
    if (chatBubbles.length > 0) {
        var lastBubble = chatBubbles[chatBubbles.length - 1];
        tailTxt = (lastBubble.innerText || '').toLowerCase();
        if (panel) {
            Array.from(panel.querySelectorAll('div, p, span')).forEach(el => {
                if (el.closest('[role=""textbox""]') || el.querySelector('[role=""textbox""]')) return;
                if (lastBubble.contains(el)) return;
                if ((lastBubble.compareDocumentPosition(el) & Node.DOCUMENT_POSITION_FOLLOWING) !== 0) {
                    var t = (el.innerText || '').trim().toLowerCase();
                    if (t.length > 0 && t.length < 400) tailTxt += ' ' + t;
                }
            });
        }
    } else {
        tailTxt = panelTxt;
    }

    var hasUnusualActivity = tailTxt.indexOf('atividade incomum') >= 0 ||
                             tailTxt.indexOf('extensões do navegador') >= 0 ||
                             tailTxt.indexOf('extensoes do navegador') >= 0 ||
                             tailTxt.indexOf('unusual activity') >= 0;

    var retryBtns = panel ? Array.from(panel.querySelectorAll('button')).filter(b => {
        var al = (b.getAttribute('aria-label') || '').trim().toLowerCase();
        var txt = (b.innerText || '').trim().toLowerCase();
        var r = b.getBoundingClientRect();
        return r.width > 20 && r.height > 14 && !b.disabled &&
               (txt === 'tentar de novo' || txt === 'tentar novamente' || txt === 'try again' ||
                txt.indexOf('tentar de novo') >= 0 || al.indexOf('tentar de novo') >= 0 || al.indexOf('try again') >= 0);
    }) : [];
    var retryBtn = retryBtns.length > 0 ? retryBtns[retryBtns.length - 1] : null;
    if (retryBtn && panel) {
        var ownBubble = retryBtn.closest('flow-chat-bubble');
        var hasNewerNode = Array.from(panel.querySelectorAll('flow-chat-bubble, flow-a2ui-video-option')).some(n => {
            if (n === ownBubble || n.contains(retryBtn)) return false;
            return (retryBtn.compareDocumentPosition(n) & Node.DOCUMENT_POSITION_FOLLOWING) !== 0;
        });
        if (hasNewerNode) retryBtn = null;
    }

    var retryRect = retryBtn ? retryBtn.getBoundingClientRect() : null;

    return JSON.stringify({
        tiles: tiles,
        vidOptCount: vidOptCount,
        bubbleCount: bubbleCount,
        unusualCount: unusualCount,
        agentBusy: agentStopBtn || agentSpinner,
        hasUnusualActivity: hasUnusualActivity,
        hasRetryBtn: !!retryRect,
        retryX: retryRect ? Math.round(retryRect.left + retryRect.width / 2) : 0,
        retryY: retryRect ? Math.round(retryRect.top + retryRect.height / 2) : 0
    });
})()";

            Dictionary<string, object> raw = await _cdp.EvalJsonAsync(sess, inspectJs, ct);
            SessionPollSnapshot snap = new SessionPollSnapshot();
            if (raw == null) return snap;

            snap.AgentVideoOptionsCount = raw.ContainsKey("vidOptCount") ? Convert.ToInt32(raw["vidOptCount"]) : 0;
            snap.AgentChatBubblesCount = raw.ContainsKey("bubbleCount") ? Convert.ToInt32(raw["bubbleCount"]) : 0;
            snap.UnusualActivityCount = raw.ContainsKey("unusualCount") ? Convert.ToInt32(raw["unusualCount"]) : 0;
            snap.AgentBusy = raw.ContainsKey("agentBusy") && Convert.ToBoolean(raw["agentBusy"]);
            snap.AgentHasUnusualActivity = raw.ContainsKey("hasUnusualActivity") && Convert.ToBoolean(raw["hasUnusualActivity"]);
            snap.AgentHasRetryButton = raw.ContainsKey("hasRetryBtn") && Convert.ToBoolean(raw["hasRetryBtn"]);
            snap.RetryButtonX = raw.ContainsKey("retryX") ? Convert.ToInt32(raw["retryX"]) : 0;
            snap.RetryButtonY = raw.ContainsKey("retryY") ? Convert.ToInt32(raw["retryY"]) : 0;

            List<MountedGridTileState> topTiles = ParseMountedTilesFromEval(raw);

            int anchorIdx = -1;
            for (int i = 0; i < topTiles.Count; i++)
            {
                string id = topTiles[i].AsbId;
                if (!string.IsNullOrEmpty(id) && baseline.PreExistingAsbIds.Contains(id))
                {
                    anchorIdx = i;
                    break;
                }
            }

            if (anchorIdx >= 0 || baseline.PreExistingAsbIds.Count == 0 || topTiles.Count < 30)
            {
                int rawEnd = anchorIdx >= 0 ? anchorIdx : topTiles.Count;
                int sessionEnd = Math.Max(0, rawEnd - baseline.PreExistingTopFailedCount);
                snap.SessionSliceEndIndex = sessionEnd;
                List<string> pctList = new List<string>();

                for (int i = 0; i < sessionEnd; i++)
                {
                    MountedGridTileState t = topTiles[i];
                    if (t.HasPct)
                    {
                        snap.GeneratingCards++;
                        if (!string.IsNullOrEmpty(t.PctText))
                            pctList.Add(t.PctText);
                    }
                    else if (t.HasErr && !t.HasVideo)
                    {
                        snap.FailedCards++;
                        snap.FailedMountedIndices.Add(t.MountedIndex);
                        if (t.IsMinorErr)
                        {
                            snap.MinorFailedMountedIndices.Add(t.MountedIndex);
                        }
                    }
                    else if (t.HasVideo || t.HasMoreBtn || !string.IsNullOrEmpty(t.AsbId))
                    {
                        snap.CompletedCards++;
                    }
                    else if (t.HasSpinner)
                    {
                        snap.GeneratingCards++;
                    }
                    else
                    {
                        snap.GeneratingCards++;
                        snap.UnknownPendingCards++;
                    }
                }
                snap.PctSummary = string.Join(",", pctList);
            }
            else
            {
                // Caso raro de episódio longo (>35 takes na mesma sessão) onde a âncora preexistente desceu além da 1ª janela virtualizada
                snap.SessionSliceEndIndex = topTiles.Count;
                HashSet<string> seenSessionCompletedAsbs = new HashSet<string>(StringComparer.Ordinal);
                int totalGenerating = 0;
                int totalFailed = 0;

                for (int i = 0; i < topTiles.Count; i++)
                {
                    MountedGridTileState t = topTiles[i];
                    if (t.HasPct) totalGenerating++;
                    else if (t.HasErr && !t.HasVideo)
                    {
                        totalFailed++;
                        snap.FailedMountedIndices.Add(t.MountedIndex);
                        if (t.IsMinorErr)
                            snap.MinorFailedMountedIndices.Add(t.MountedIndex);
                    }
                    else if (!string.IsNullOrEmpty(t.AsbId)) seenSessionCompletedAsbs.Add(t.AsbId);
                }

                for (int page = 1; page <= 4; page++)
                {
                    await _cdp.EvalStringAsync(sess, string.Format(@"
(function(){{
    var vp = document.querySelector('cdk-virtual-scroll-viewport.tiles-container') || document.querySelector('cdk-virtual-scroll-viewport');
    if (vp) vp.scrollTop = {0};
    return 'OK';
}})()", page * 520), ct);
                    await Task.Delay(320, ct);

                    Dictionary<string, object> pageRaw = await _cdp.EvalJsonAsync(sess, inspectJs, ct);
                    List<MountedGridTileState> pageTiles = ParseMountedTilesFromEval(pageRaw);
                    bool hitAnchor = false;
                    for (int i = 0; i < pageTiles.Count; i++)
                    {
                        MountedGridTileState pt = pageTiles[i];
                        if (!string.IsNullOrEmpty(pt.AsbId) && baseline.PreExistingAsbIds.Contains(pt.AsbId))
                        {
                            hitAnchor = true;
                            break;
                        }
                        if (!string.IsNullOrEmpty(pt.AsbId))
                            seenSessionCompletedAsbs.Add(pt.AsbId);
                    }
                    if (hitAnchor) break;
                }

                await _cdp.EvalStringAsync(sess, @"
(function(){
    var vp = document.querySelector('cdk-virtual-scroll-viewport.tiles-container') || document.querySelector('cdk-virtual-scroll-viewport');
    if (vp) vp.scrollTop = 0;
    return 'OK';
})()", ct);
                await Task.Delay(250, ct);

                int newAgentVidOpts = Math.Max(0, snap.AgentVideoOptionsCount - (baseline != null ? baseline.PreExistingAgentVideoOptionsCount : 0));
                snap.GeneratingCards = totalGenerating;
                snap.FailedCards = Math.Max(0, totalFailed - baseline.PreExistingTopFailedCount);
                snap.CompletedCards = Math.Max(seenSessionCompletedAsbs.Count, newAgentVidOpts);
            }

            snap.TotalSessionCards = snap.GeneratingCards + snap.CompletedCards + snap.FailedCards;
            return snap;
        }

        private static double ComputeProjectSalvageMatchScore(FlowTakeSpec spec, string candidatePrompt, int hintedTakeNum)
        {
            if (spec == null || string.IsNullOrWhiteSpace(spec.RawPromptBody))
                return 0.0;

            if (string.IsNullOrWhiteSpace(candidatePrompt))
                return 0.0;

            int explicitTag = TryExtractExplicitTakeTagNumber(candidatePrompt);
            if (explicitTag > 0 && explicitTag != spec.TakeNumber)
                return 0.0;

            if (hintedTakeNum > 0 && explicitTag == 0 && hintedTakeNum != spec.TakeNumber)
                return 0.0;

            string promptWithoutTag = Regex.Replace(
                candidatePrompt,
                @"\[\s*TAKE(?:[_\-\s]*ID)?[_\-\s]*0*\d{1,3}\s*\]",
                " ",
                RegexOptions.IgnoreCase);

            double contentScore = ComputeTakeToVideoMatchScore(spec, promptWithoutTag);
            double bodySim = ComputeContentWordBigramSimilarity(
                ExtractDistinctiveTakeBody(spec.RawPromptBody),
                ExtractDistinctiveTakeBody(promptWithoutTag));

            if (explicitTag > 0 && explicitTag == spec.TakeNumber)
            {
                // Confirma que o [TAKE_XX] pertence realmente a ESTE episódio (e não a um EP anterior no mesmo projeto Flow)
                if (bodySim >= 0.26 || contentScore >= 0.32)
                {
                    return Math.Min(1.0, 0.95 + (0.05 * Math.Max(bodySim, contentScore)));
                }
                return 0.0;
            }

            if (hintedTakeNum > 0 && hintedTakeNum == spec.TakeNumber)
            {
                if (bodySim >= 0.20 || contentScore >= 0.25)
                {
                    return Math.Min(0.96, Math.Max(contentScore, 0.86 + (0.10 * Math.Max(bodySim, contentScore))));
                }
                return 0.0;
            }

            return contentScore;
        }

        private static bool DoesPromptMatchAnyEpisodeTake(List<FlowTakeSpec> allEpisodeTakes, string candidatePrompt, int hintedTakeNum)
        {
            if (allEpisodeTakes == null || allEpisodeTakes.Count == 0 || string.IsNullOrWhiteSpace(candidatePrompt))
                return false;

            for (int i = 0; i < allEpisodeTakes.Count; i++)
            {
                double score = ComputeProjectSalvageMatchScore(allEpisodeTakes[i], candidatePrompt, hintedTakeNum);
                if (score >= 0.56)
                    return true;
            }
            return false;
        }

        private async Task<HashSet<int>> TrySalvageCompletedTakesFromCurrentFlowScreenAsync(
            string sess,
            EpisodeWorkItem ep,
            List<FlowTakeSpec> missingFlowTakes,
            HashSet<int> existingOnDisk,
            CancellationToken ct)
        {
            HashSet<int> handledTakeNumbers = new HashSet<int>();
            if (missingFlowTakes == null || missingFlowTakes.Count == 0)
                return handledTakeNumbers;

            List<FlowTakeSpec> allEpisodeTakes = EpisodeParser.GetEffectiveTakeSpecsForEpisode(ep);
            if (allEpisodeTakes == null || allEpisodeTakes.Count == 0)
                allEpisodeTakes = ep.FlowTakes ?? new List<FlowTakeSpec>();

            // 1. Posiciona o grid no topo e verifica se existem vídeos gerados (ou ainda renderizando) dentro do projeto
            await _cdp.EvalStringAsync(sess, @"
(function(){
    var vp = document.querySelector('cdk-virtual-scroll-viewport.tiles-container') || document.querySelector('cdk-virtual-scroll-viewport');
    if (vp && vp.scrollTop > 8) vp.scrollTop = 0;
    return 'OK';
})()", ct);
            await Task.Delay(350, ct);

            string quickProbeJs = @"
(function(){
    var tiles = Array.from(document.querySelectorAll('flow-video-tile'));
    var genCount = 0;
    var okCount = 0;
    var pctParts = [];
    tiles.forEach(t => {
        var vid = t.querySelector('video');
        var img = t.querySelector('img.thumbnail') || t.querySelector('img');
        var mediaUrl = (img ? (img.getAttribute('src') || '') : '') + ' ' +
                       (vid ? ((vid.getAttribute('poster') || '') + ' ' + (vid.getAttribute('src') || '')) : '');
        var m = mediaUrl.match(/\/asb\/([A-Za-z0-9_\-]{25,80})/);
        var asb = m ? m[1] : '';
        var txt = (t.innerText || '');
        var pm = txt.match(/\b\d{1,2}%\b/);
        if (pm) {
            genCount++;
            pctParts.push(pm[0]);
        } else if (asb.length > 0 && !/violar|pol[ií]ticas|falha|erro|n[aã]o foi poss[ií]vel|violate|failed/i.test(txt)) {
            okCount++;
        }
    });
    var agentCount = document.querySelectorAll('flow-a2ui-video-option').length;
    return JSON.stringify({
        genCount: genCount,
        okCount: okCount,
        agentCount: agentCount,
        pctSig: pctParts.join('|')
    });
})()";

            Dictionary<string, object> initProbe = await _cdp.EvalJsonAsync(sess, quickProbeJs, ct);
            int initGenCount = initProbe != null && initProbe.ContainsKey("genCount") ? Convert.ToInt32(initProbe["genCount"]) : 0;
            int initOkCount = initProbe != null && initProbe.ContainsKey("okCount") ? Convert.ToInt32(initProbe["okCount"]) : 0;
            int initAgentCount = initProbe != null && initProbe.ContainsKey("agentCount") ? Convert.ToInt32(initProbe["agentCount"]) : 0;

            // Se o usuário pausou/retomou enquanto algum take ainda estava renderizando (ex.: 65%), aguarda concluir antes de inspecionar!
            if (initGenCount > 0)
            {
                _log(string.Format("[Inspeção do Projeto | Google Flow] Detectada(s) {0} cena(s) ainda renderizando dentro do projeto -> aguardando finalizar antes de verificar os takes...",
                    initGenCount));
                DateTime waitStart = DateTime.UtcNow;
                DateTime lastPctMove = DateTime.UtcNow;
                string lastPctSig = initProbe != null && initProbe.ContainsKey("pctSig") ? Convert.ToString(initProbe["pctSig"] ?? "") : "";

                while ((DateTime.UtcNow - waitStart).TotalSeconds < 150)
                {
                    ct.ThrowIfCancellationRequested();
                    await _cdp.WaitOrWakeOnReloadSignalAsync(4000, ct);
                    Dictionary<string, object> pNow = await _cdp.EvalJsonAsync(sess, quickProbeJs, ct);
                    int gNow = pNow != null && pNow.ContainsKey("genCount") ? Convert.ToInt32(pNow["genCount"]) : 0;
                    initOkCount = pNow != null && pNow.ContainsKey("okCount") ? Convert.ToInt32(pNow["okCount"]) : initOkCount;
                    initAgentCount = pNow != null && pNow.ContainsKey("agentCount") ? Convert.ToInt32(pNow["agentCount"]) : initAgentCount;
                    string sigNow = pNow != null && pNow.ContainsKey("pctSig") ? Convert.ToString(pNow["pctSig"] ?? "") : "";

                    if (gNow <= 0)
                        break;

                    if (!string.Equals(sigNow, lastPctSig, StringComparison.Ordinal))
                    {
                        lastPctSig = sigNow;
                        lastPctMove = DateTime.UtcNow;
                    }
                    else if ((DateTime.UtcNow - lastPctMove).TotalSeconds >= 45)
                    {
                        break;
                    }
                }
            }

            if (initOkCount == 0 && initAgentCount == 0)
            {
                _log("[Inspeção do Projeto | Google Flow] Nenhum vídeo gerado anteriormente encontrado dentro do projeto.");
                return handledTakeNumbers;
            }

            _log("[Inspeção do Projeto | Google Flow] Vídeos encontrados dentro do projeto -> verificando quais takes já foram gerados e quais faltam baixar...");

            Dictionary<string, string> promptByAsb = new Dictionary<string, string>(StringComparer.Ordinal);
            Dictionary<string, int> hintTakeByAsb = new Dictionary<string, int>(StringComparer.Ordinal);

            // 2A. Coleta prompts e opções de vídeo do painel lateral do Agente (incluindo expansão de 'Ver tudo')
            List<SessionCompletedVideoInfo> agentOpts = await CollectSessionVideosFromAgentPanelAsync(sess, null, ct);
            for (int i = 0; i < agentOpts.Count; i++)
            {
                SessionCompletedVideoInfo info = agentOpts[i];
                if (info == null || string.IsNullOrEmpty(info.AsbId))
                    continue;
                if (!string.IsNullOrWhiteSpace(info.AltPrompt) && !promptByAsb.ContainsKey(info.AsbId))
                    promptByAsb[info.AsbId] = info.AltPrompt.Trim();
            }

            // Captura também pistas [TAKE_XX] das bolhas da conversa (útil quando uma cena foi suavizada pelo Agente e perdeu a tag [TAKE_XX] no alt)
            Dictionary<string, object> rawBubbleHints = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var panel = document.querySelector('flow-agent-panel');
    if (!panel) return JSON.stringify({});
    var hints = {};
    var lastSingleTakeNum = 0;
    var bubbles = Array.from(panel.querySelectorAll('flow-chat-bubble'));
    bubbles.forEach(b => {
        var vos = Array.from(b.querySelectorAll('flow-a2ui-video-option'));
        if (vos.length === 0) {
            var txt = (b.innerText || '');
            var re = /\[\s*TAKE(?:[_\-\s]*ID)?[_\-\s]*0*(\d{1,3})\s*\]/gi;
            var nums = [];
            var m;
            while ((m = re.exec(txt)) !== null) {
                var n = parseInt(m[1], 10);
                if (n > 0 && nums.indexOf(n) < 0) nums.push(n);
            }
            if (nums.length === 0) {
                var reWord = /\btake[\s_]+0*(\d{1,3})\b/gi;
                while ((m = reWord.exec(txt)) !== null) {
                    var n2 = parseInt(m[1], 10);
                    if (n2 > 0 && nums.indexOf(n2) < 0) nums.push(n2);
                }
            }
            if (nums.length === 1) lastSingleTakeNum = nums[0];
            else if (nums.length > 1) lastSingleTakeNum = 0;
        } else if (lastSingleTakeNum > 0 && vos.length <= 2) {
            vos.forEach(vo => {
                var img = vo.querySelector('img');
                var vid = vo.querySelector('video');
                var u = (img ? (img.getAttribute('src') || '') : '') + ' ' +
                        (vid ? ((vid.getAttribute('poster') || '') + ' ' + (vid.getAttribute('src') || '')) : '');
                var am = u.match(/\/asb\/([A-Za-z0-9_\-]{25,80})/);
                if (am && !hints[am[1]]) hints[am[1]] = lastSingleTakeNum;
            });
        }
    });
    return JSON.stringify(hints);
})()", ct);

            if (rawBubbleHints != null)
            {
                foreach (KeyValuePair<string, object> kv in rawBubbleHints)
                {
                    int tnHint;
                    if (!string.IsNullOrEmpty(kv.Key) && int.TryParse(Convert.ToString(kv.Value ?? "0"), out tnHint) && tnHint > 0)
                        hintTakeByAsb[kv.Key] = tnHint;
                }
            }

            // 2B. Varredura paginada do grid virtualizado (cdk-virtual-scroll-viewport) do mais recente ao mais antigo
            List<string> gridAsbsNewestFirst = new List<string>();
            HashSet<string> seenGridAsbs = new HashSet<string>(StringComparer.Ordinal);
            int maxScanTiles = Math.Max(42, (allEpisodeTakes.Count * 2) + 12);
            bool foundAnyKnownEpisodeTile = false;
            int consecutiveKnownUnrelated = 0;

            for (int page = 0; page <= 18 && gridAsbsNewestFirst.Count < maxScanTiles; page++)
            {
                ct.ThrowIfCancellationRequested();
                string scrollStatus = await _cdp.EvalStringAsync(sess, string.Format(@"
(function(){{
    var vp = document.querySelector('cdk-virtual-scroll-viewport.tiles-container') || document.querySelector('cdk-virtual-scroll-viewport');
    if (!vp) return 'NO_VP';
    var maxScroll = Math.max(0, vp.scrollHeight - vp.clientHeight);
    var nextTop = Math.min(maxScroll, {0});
    vp.scrollTop = nextTop;
    return (nextTop >= maxScroll && {0} > 0) ? 'AT_END' : 'OK';
}})()", page * 460), ct);
                await Task.Delay(300, ct);

                Dictionary<string, object> rawPage = await _cdp.EvalJsonAsync(sess, @"
(function(){
    function tryExtractNgPrompt(host, asb) {
        try {
            var keys = Object.keys(host);
            for (var k = 0; k < keys.length; k++) {
                if (keys[k].indexOf('__ngContext__') < 0) continue;
                var ctx = host[keys[k]];
                var queue = [{ v: ctx, d: 0 }];
                var visited = [];
                while (queue.length > 0 && visited.length < 90) {
                    var cur = queue.shift();
                    var val = cur.v;
                    if (!val || cur.d > 3) continue;
                    if (typeof val === 'string') {
                        var s = val.trim();
                        if (s.length >= 45 && s.length <= 3500 && s.indexOf('http') !== 0 &&
                            (/\[\s*TAKE/i.test(s) || /Anima[cç][aã]o|propor[cç][aã]o\s*9:16|Foley/i.test(s))) {
                            return s;
                        }
                        continue;
                    }
                    if (typeof val === 'object') {
                        if (visited.indexOf(val) >= 0) continue;
                        visited.push(val);
                        if (Array.isArray(val)) {
                            for (var i = 0; i < Math.min(val.length, 45); i++) {
                                queue.push({ v: val[i], d: cur.d + 1 });
                            }
                        } else if (!(val instanceof Node)) {
                            var okKeys = Object.keys(val);
                            for (var j = 0; j < Math.min(okKeys.length, 30); j++) {
                                var prop = okKeys[j];
                                if (prop === 'prompt' || prop === 'textPrompt' || prop === 'userPrompt' || prop === 'description' || prop === 'altText') {
                                    var pv = val[prop];
                                    if (typeof pv === 'string' && pv.trim().length >= 25) return pv.trim();
                                }
                                queue.push({ v: val[prop], d: cur.d + 1 });
                            }
                        }
                    }
                }
            }
        } catch(e) {}
        return '';
    }
    var list = Array.from(document.querySelectorAll('flow-video-tile')).map(t => {
        var vid = t.querySelector('video');
        var img = t.querySelector('img.thumbnail') || t.querySelector('img');
        var mediaUrl = (img ? (img.getAttribute('src') || '') : '') + ' ' +
                       (vid ? ((vid.getAttribute('poster') || '') + ' ' + (vid.getAttribute('src') || '')) : '');
        var m = mediaUrl.match(/\/asb\/([A-Za-z0-9_\-]{25,80})/);
        var asb = m ? m[1] : '';
        var txt = (t.innerText || '');
        var hasPct = /\b\d{1,2}%\b/.test(txt);
        var hasErr = !vid && !img && !asb && /violar|pol[ií]ticas|falha|erro|n[aã]o foi poss[ií]vel|violate|failed/i.test(txt);
        var p = (img ? (img.getAttribute('alt') || '') : '').trim();
        if (!p && vid) p = (vid.getAttribute('aria-label') || '').trim();
        if (!p) p = (t.getAttribute('aria-label') || t.getAttribute('title') || '').trim();
        if (!p && asb) p = tryExtractNgPrompt(t, asb);
        return {
            asb: asb,
            ok: (!hasPct && !hasErr && asb.length > 0),
            prompt: p
        };
    });
    return JSON.stringify({ list: list });
})()", ct);

                if (rawPage == null || !rawPage.ContainsKey("list"))
                    break;
                IEnumerable pageArr = rawPage["list"] as IEnumerable;
                if (pageArr == null)
                    break;

                bool stopEarlyOldEpisode = false;
                foreach (object elem in pageArr)
                {
                    Dictionary<string, object> d = elem as Dictionary<string, object>;
                    if (d == null) continue;
                    string asb = d.ContainsKey("asb") ? Convert.ToString(d["asb"] ?? "").Trim() : "";
                    bool ok = d.ContainsKey("ok") && Convert.ToBoolean(d["ok"]);
                    string tilePrompt = d.ContainsKey("prompt") ? Convert.ToString(d["prompt"] ?? "").Trim() : "";

                    if (!ok || string.IsNullOrEmpty(asb))
                        continue;

                    if (!string.IsNullOrEmpty(tilePrompt) && !promptByAsb.ContainsKey(asb))
                        promptByAsb[asb] = tilePrompt;

                    if (!seenGridAsbs.Add(asb))
                        continue;

                    gridAsbsNewestFirst.Add(asb);

                    string knownPrompt;
                    if (promptByAsb.TryGetValue(asb, out knownPrompt) && !string.IsNullOrWhiteSpace(knownPrompt))
                    {
                        int hintNum = hintTakeByAsb.ContainsKey(asb) ? hintTakeByAsb[asb] : 0;
                        if (DoesPromptMatchAnyEpisodeTake(allEpisodeTakes, knownPrompt, hintNum))
                        {
                            foundAnyKnownEpisodeTile = true;
                            consecutiveKnownUnrelated = 0;
                        }
                        else
                        {
                            consecutiveKnownUnrelated++;
                            if ((foundAnyKnownEpisodeTile && consecutiveKnownUnrelated >= 8) ||
                                (!foundAnyKnownEpisodeTile && consecutiveKnownUnrelated >= 10))
                            {
                                stopEarlyOldEpisode = true;
                                break;
                            }
                        }
                    }

                    if (gridAsbsNewestFirst.Count >= maxScanTiles)
                        break;
                }

                if (stopEarlyOldEpisode || scrollStatus == "AT_END" || scrollStatus == "NO_VP")
                    break;
            }

            // 2C. Se ainda houver tiles recentes no grid sem prompt legível (ex.: após reload da página com chat limpo),
            // recupera o prompt deles do mais recente ao mais antigo, parando assim que encontrar vídeos de outro episódio antigo
            List<string> missingPromptAsbs = new List<string>();
            for (int i = 0; i < gridAsbsNewestFirst.Count; i++)
            {
                string asb = gridAsbsNewestFirst[i];
                string existingP;
                if (!promptByAsb.TryGetValue(asb, out existingP) || string.IsNullOrWhiteSpace(existingP))
                {
                    missingPromptAsbs.Add(asb);
                }
            }

            if (missingPromptAsbs.Count > 0)
            {
                int maxEnrich = Math.Min(missingPromptAsbs.Count, allEpisodeTakes.Count + 8);
                bool foundDuringEnrich = foundAnyKnownEpisodeTile;
                int consecutiveUnrelatedEnrich = 0;

                for (int m = 0; m < maxEnrich; m++)
                {
                    ct.ThrowIfCancellationRequested();
                    string gAsb = missingPromptAsbs[m];
                    try
                    {
                        Dictionary<string, object> cardCenter = await ScrollToAndLocateTileByAsbIdAsync(sess, gAsb, ct);
                        if (cardCenter == null) continue;

                        await _cdp.HoverAsync(sess, Convert.ToInt32(cardCenter["x"]), Convert.ToInt32(cardCenter["y"]), ct);
                        await Task.Delay(360, ct);

                        string b64Asb = Convert.ToBase64String(Encoding.UTF8.GetBytes(gAsb));
                        string hoverAlt = await _cdp.EvalStringAsync(sess, string.Format(@"
(function(){{
    var want = atob('{0}');
    var tile = Array.from(document.querySelectorAll('flow-video-tile')).find(t => {{
        var vid = t.querySelector('video');
        var img = t.querySelector('img');
        var u = (vid ? ((vid.getAttribute('src') || '') + ' ' + (vid.getAttribute('poster') || '')) : '') + ' ' +
                (img ? (img.getAttribute('src') || '') : '');
        return u.indexOf(want) >= 0;
    }});
    if (!tile) return '';
    var img = tile.querySelector('img');
    var vid = tile.querySelector('video');
    var p = (img ? (img.getAttribute('alt') || '') : '').trim();
    if (!p && vid) p = (vid.getAttribute('aria-label') || '').trim();
    return p;
}})()", b64Asb), ct);

                        string recoveredPrompt = (hoverAlt ?? "").Trim();
                        if (string.IsNullOrWhiteSpace(recoveredPrompt))
                        {
                            Dictionary<string, object> reusePt = await _cdp.EvalJsonAsync(sess, string.Format(@"
(function(){{
    var want = atob('{0}');
    var tile = Array.from(document.querySelectorAll('flow-video-tile')).find(t => {{
        var vid = t.querySelector('video');
        var img = t.querySelector('img');
        var u = (vid ? ((vid.getAttribute('src') || '') + ' ' + (vid.getAttribute('poster') || '')) : '') + ' ' +
                (img ? (img.getAttribute('src') || '') : '');
        return u.indexOf(want) >= 0;
    }});
    if (!tile) return null;
    var btn = tile.querySelector('button[aria-label*=""Reutilizar""], button[aria-label*=""Reuse""]') ||
              Array.from(tile.querySelectorAll('button')).find(b => {{
                  var al = (b.getAttribute('aria-label') || '');
                  var txt = (b.innerText || '').trim();
                  return al.indexOf('Reutilizar') >= 0 || al.indexOf('Reuse') >= 0 || txt === 'undo' || txt === 'replay';
              }});
    if (!btn) return null;
    var r = btn.getBoundingClientRect();
    if (r.width < 4) {{
        btn.click();
        return JSON.stringify({{ clickedNative: true, x: 0, y: 0 }});
    }}
    return JSON.stringify({{ clickedNative: false, x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) }});
}})()", b64Asb), ct);

                            if (reusePt != null)
                            {
                                bool clickedNative = reusePt.ContainsKey("clickedNative") && Convert.ToBoolean(reusePt["clickedNative"]);
                                if (!clickedNative)
                                {
                                    await _cdp.ClickAtAsync(sess, Convert.ToInt32(reusePt["x"]), Convert.ToInt32(reusePt["y"]), ct);
                                }
                                await Task.Delay(800, ct);
                                recoveredPrompt = (await ReadCurrentFlowTextboxAsync(sess, ct) ?? "").Trim();
                                await InsertTextIntoFlowTextboxAsync(sess, "", true, ct);
                                await ClearAttachedPromptChipsAsync(sess, ct);
                            }
                        }

                        if (!string.IsNullOrWhiteSpace(recoveredPrompt))
                        {
                            promptByAsb[gAsb] = recoveredPrompt;
                            int hintNum = hintTakeByAsb.ContainsKey(gAsb) ? hintTakeByAsb[gAsb] : 0;
                            if (DoesPromptMatchAnyEpisodeTake(allEpisodeTakes, recoveredPrompt, hintNum))
                            {
                                foundDuringEnrich = true;
                                consecutiveUnrelatedEnrich = 0;
                            }
                            else
                            {
                                consecutiveUnrelatedEnrich++;
                                if ((!foundDuringEnrich && consecutiveUnrelatedEnrich >= 4) ||
                                    (foundDuringEnrich && consecutiveUnrelatedEnrich >= 5))
                                {
                                    break;
                                }
                            }
                        }
                    }
                    catch (OperationCanceledException)
                    {
                        throw;
                    }
                    catch
                    {
                    }
                }
            }

            // Retorna o scroll do grid ao topo antes do casamento/download
            await _cdp.EvalStringAsync(sess, @"
(function(){
    var vp = document.querySelector('cdk-virtual-scroll-viewport.tiles-container') || document.querySelector('cdk-virtual-scroll-viewport');
    if (vp) vp.scrollTop = 0;
    return 'OK';
})()", ct);
            await Task.Delay(250, ct);

            // 3. Reúne todos os candidatos únicos (do mais recente ao mais antigo) e faz o casamento global 1:1 com os takes do episódio
            List<string> candidateAsbsNewestFirst = new List<string>(gridAsbsNewestFirst);
            HashSet<string> candidateAsbSet = new HashSet<string>(gridAsbsNewestFirst, StringComparer.Ordinal);
            for (int i = 0; i < agentOpts.Count; i++)
            {
                string aAsb = agentOpts[i].AsbId;
                if (!string.IsNullOrEmpty(aAsb) && candidateAsbSet.Add(aAsb))
                    candidateAsbsNewestFirst.Add(aAsb);
            }

            List<TakeVideoMatchCandidate> matchPairs = new List<TakeVideoMatchCandidate>();
            for (int v = 0; v < candidateAsbsNewestFirst.Count; v++)
            {
                string asb = candidateAsbsNewestFirst[v];
                string prompt;
                if (!promptByAsb.TryGetValue(asb, out prompt) || string.IsNullOrWhiteSpace(prompt))
                    continue;

                int hintNum = hintTakeByAsb.ContainsKey(asb) ? hintTakeByAsb[asb] : 0;
                for (int k = 0; k < allEpisodeTakes.Count; k++)
                {
                    double score = ComputeProjectSalvageMatchScore(allEpisodeTakes[k], prompt, hintNum);
                    if (score >= 0.56)
                    {
                        TakeVideoMatchCandidate pair = new TakeVideoMatchCandidate();
                        pair.TakeIndex = k;
                        pair.VideoIndex = v;
                        pair.AsbId = asb;
                        pair.RawScore = score;
                        pair.ScoreBucket = score >= 0.93 ? 50 : (int)Math.Round(score * 50.0);
                        matchPairs.Add(pair);
                    }
                }
            }

            // Prioriza maior pontuação; em empate de bucket, prefere o vídeo mais recente (menor VideoIndex)
            matchPairs.Sort(delegate(TakeVideoMatchCandidate a, TakeVideoMatchCandidate b)
            {
                int cmpBucket = b.ScoreBucket.CompareTo(a.ScoreBucket);
                if (cmpBucket != 0) return cmpBucket;
                int cmpVid = a.VideoIndex.CompareTo(b.VideoIndex);
                if (cmpVid != 0) return cmpVid;
                return b.RawScore.CompareTo(a.RawScore);
            });

            Dictionary<int, string> salvagedAsbByTake = new Dictionary<int, string>();
            HashSet<string> usedAsbs = new HashSet<string>(StringComparer.Ordinal);

            for (int p = 0; p < matchPairs.Count; p++)
            {
                TakeVideoMatchCandidate cand = matchPairs[p];
                int takeNum = allEpisodeTakes[cand.TakeIndex].TakeNumber;
                if (salvagedAsbByTake.ContainsKey(takeNum) || usedAsbs.Contains(cand.AsbId))
                    continue;

                salvagedAsbByTake[takeNum] = cand.AsbId;
                usedAsbs.Add(cand.AsbId);
            }

            if (salvagedAsbByTake.Count == 0)
            {
                _log("[Inspeção do Projeto | Google Flow] Verificação concluída: nenhum vídeo deste episódio foi encontrado gerado no projeto -> iniciando do primeiro take pendente.");
                return handledTakeNumbers;
            }

            List<int> alreadySavedInProject = salvagedAsbByTake.Keys
                .Where(tn => existingOnDisk.Contains(tn))
                .OrderBy(tn => tn)
                .ToList();

            List<FlowTakeSpec> toDownload = missingFlowTakes
                .Where(t => salvagedAsbByTake.ContainsKey(t.TakeNumber) && !existingOnDisk.Contains(t.TakeNumber))
                .OrderBy(t => t.TakeNumber)
                .ToList();

            if (toDownload.Count == 0)
            {
                string savedLabels = string.Join(", ", alreadySavedInProject.Select(n => string.Format("Take_{0:00}", n)));
                _log(string.Format("[Inspeção do Projeto | Google Flow] Verificação concluída: {0} take(s) deste episódio encontrados no projeto ({1}) já estão baixados na pasta 'takes'!",
                    alreadySavedInProject.Count, savedLabels));
                return handledTakeNumbers;
            }

            // 4. Baixa em 720p todos os takes já gerados no projeto que ainda não estavam salvos em disco!
            string dlLabels = string.Join(", ", toDownload.Select(t => string.Format("Take_{0:00}", t.TakeNumber)));
            _log(string.Format("[Inspeção do Projeto | Google Flow] Encontrados {0} take(s) deste episódio já gerados no projeto ({1} já baixado(s); {2} pendente(s) de download: {3}) -> baixando em 720p antes de continuar!",
                salvagedAsbByTake.Count, alreadySavedInProject.Count, toDownload.Count, dlLabels));

            string stagingDl = Path.Combine(ep.TakesDir, "_flow_salvage_" + DateTime.Now.ToString("HHmmss"));
            Directory.CreateDirectory(stagingDl);
            await _cdp.SetDownloadBehaviorAsync(stagingDl, ct);

            for (int i = 0; i < toDownload.Count; i++)
            {
                ct.ThrowIfCancellationRequested();
                FlowTakeSpec spec = toDownload[i];
                string asbId = salvagedAsbByTake[spec.TakeNumber];
                string finalTakePath = Path.Combine(ep.TakesDir, string.Format("Take_{0:00}.mp4", spec.TakeNumber));
                try
                {
                    await DownloadSingleTileByAsbIdAsync(
                        sess,
                        asbId,
                        spec.TakeNumber,
                        i + 1,
                        toDownload.Count,
                        stagingDl,
                        finalTakePath,
                        ct);
                    handledTakeNumbers.Add(spec.TakeNumber);
                    existingOnDisk.Add(spec.TakeNumber);
                }
                catch (OperationCanceledException)
                {
                    throw;
                }
                catch (Exception ex)
                {
                    _log(string.Format("[Google Flow | Aviso] Falha ao baixar Take_{0:00}.mp4 do projeto ({1}) -> será incluído na retomada da geração.",
                        spec.TakeNumber, ex.Message));
                }
            }

            try { await _cdp.ResetDownloadBehaviorToDefaultAsync(); } catch { }
            try { Directory.Delete(stagingDl, true); } catch { }

            await _cdp.EvalStringAsync(sess, @"
(function(){
    var vp = document.querySelector('cdk-virtual-scroll-viewport.tiles-container') || document.querySelector('cdk-virtual-scroll-viewport');
    if (vp) vp.scrollTop = 0;
    return 'OK';
})()", ct);
            await Task.Delay(250, ct);

            _log(string.Format("[Inspeção do Projeto | Google Flow] Recuperação concluída: {0}/{1} take(s) baixados em 720p do projeto!",
                handledTakeNumbers.Count, toDownload.Count));

            return handledTakeNumbers;
        }

        private async Task<SessionPollSnapshot> WaitForCurrentBatchToFinishAsync(
            string sess,
            PreSessionGridBaseline baseline,
            int batchNumber,
            int totalExpectedTakes,
            int baselineCardsBeforeSubmit,
            int deletedMinorCardsTotal,
            CancellationToken ct)
        {
            DateTime start = DateTime.UtcNow;
            DateTime deadline = start.AddMinutes(12);
            DateTime lastProgressUtc = DateTime.UtcNow;
            string lastProgressFingerprint = "";
            int consecutiveIdleAfterCards = 0;
            bool nudgedContinueOnce = false;
            int retryBtnClicks = 0;

            int initialBubblesAfterSubmit = -1;
            string initBubblesStr = await _cdp.EvalStringAsync(sess, @"
(function(){
    var panel = document.querySelector('flow-agent-panel');
    return panel ? String(panel.querySelectorAll('flow-chat-bubble').length) : '-1';
})()", ct);
            int parsedBubbles;
            if (int.TryParse(initBubblesStr, out parsedBubbles) && parsedBubbles >= 0)
                initialBubblesAfterSubmit = parsedBubbles;

            while (DateTime.UtcNow < deadline)
            {
                ct.ThrowIfCancellationRequested();
                await _cdp.WaitOrWakeOnReloadSignalAsync(6500, ct);

                SessionPollSnapshot snap = await InspectCurrentSessionStateAsync(sess, baseline, ct);

                string curFp = string.Format("{0}|{1}|{2}|{3}|{4}|{5}|{6}",
                    snap.TotalSessionCards,
                    snap.GeneratingCards,
                    snap.CompletedCards,
                    snap.FailedCards,
                    snap.PctSummary ?? "",
                    snap.AgentVideoOptionsCount,
                    snap.AgentChatBubblesCount);
                if (curFp != lastProgressFingerprint)
                {
                    lastProgressFingerprint = curFp;
                    lastProgressUtc = DateTime.UtcNow;
                }

                string pctInfo = !string.IsNullOrEmpty(snap.PctSummary) ? string.Format(" [{0}]", snap.PctSummary) : "";

                if (deletedMinorCardsTotal > 0)
                {
                    _log(string.Format("[Google Flow | Lote {0}] Takes na sessão: {1}/{2} (no Flow: {3} | Grok/menores: {4}) | Em geração: {5}{6} | Concluídos (100%): {7} | Erros: {8}",
                        batchNumber, snap.TotalSessionCards + deletedMinorCardsTotal, totalExpectedTakes, snap.TotalSessionCards, deletedMinorCardsTotal, snap.GeneratingCards, pctInfo, snap.CompletedCards, snap.FailedCards));
                }
                else
                {
                    _log(string.Format("[Google Flow | Lote {0}] Cards na sessão: {1}/{2} | Em geração: {3}{4} | Concluídos (100%): {5} | Erros: {6}",
                        batchNumber, snap.TotalSessionCards, totalExpectedTakes, snap.GeneratingCards, pctInfo, snap.CompletedCards, snap.FailedCards));
                }

                bool newCardsAppeared = snap.TotalSessionCards > baselineCardsBeforeSubmit;
                if (newCardsAppeared && snap.GeneratingCards == 0 && !snap.AgentBusy)
                {
                    consecutiveIdleAfterCards++;
                    if (consecutiveIdleAfterCards >= 2)
                    {
                        return snap;
                    }
                }
                else
                {
                    consecutiveIdleAfterCards = 0;

                    // Detecção automática do aviso "Notamos uma atividade incomum... [Tentar de novo]" no painel do Agente
                    if (!newCardsAppeared && snap.GeneratingCards == 0 && !snap.AgentBusy &&
                        (snap.AgentHasRetryButton || snap.AgentHasUnusualActivity))
                    {
                        if (snap.AgentHasRetryButton && retryBtnClicks < 2 && snap.RetryButtonX > 0 && snap.RetryButtonY > 0)
                        {
                            retryBtnClicks++;
                            _log(string.Format("[Google Flow | Lote {0}] Aviso de 'atividade incomum' detectado no Agente -> aguardando 4s e clicando em 'Tentar de novo' (tentativa {1}/2)...",
                                batchNumber, retryBtnClicks));
                            await Task.Delay(4000, ct);
                            await _cdp.ClickAtAsync(sess, snap.RetryButtonX, snap.RetryButtonY, ct);
                            await Task.Delay(2500, ct);
                            lastProgressUtc = DateTime.UtcNow;
                            continue;
                        }
                        else
                        {
                            snap.AgentBlockedByUnusualActivity = true;
                            _log("[Google Flow -> Grok] O painel do Agente do Google Flow permaneceu com aviso de 'atividade incomum' após tentar novamente -> transferindo automaticamente os takes restantes para o Grok Vídeo (9:16)!");
                            return snap;
                        }
                    }

                    // Watchdog de Travamento no Google Flow ou Clique Manual no botão 'Recarregar e Continuar'
                    string manualReason;
                    bool manualReload = _cdp.ConsumeReloadAndResumeRequest(out manualReason);
                    double stalledSec = (DateTime.UtcNow - lastProgressUtc).TotalSeconds;

                    if (manualReload || (stalledSec >= 105 && batchNumber < 90))
                    {
                        string why = manualReload
                            ? manualReason
                            : string.Format("sem avanço de porcentagem/cards por {0:0}s", stalledSec);
                        _log(string.Format("[Recuperação | Histórico] Travamento detectado no Google Flow (Lote {0}: {1}). Recarregando a página do Flow e retomando com base no histórico da última ação...",
                            batchNumber, why));

                        await _cdp.ReloadPageAndWaitReadyAsync(sess, 30000, ct);
                        await WaitForFlowPageLoadedAsync(sess, ct);

                        SessionPollSnapshot reloadedSnap = await InspectCurrentSessionStateAsync(sess, baseline, ct);
                        reloadedSnap.PageReloadedDuringWait = true;
                        return reloadedSnap;
                    }

                    double elapsedSec = (DateTime.UtcNow - start).TotalSeconds;
                    bool agentRepliedOnlyText = initialBubblesAfterSubmit >= 0 &&
                                                snap.AgentChatBubblesCount > initialBubblesAfterSubmit &&
                                                elapsedSec >= 20;

                    // Nos lotes de reciclagem (Lote 91 / Lote 92), se nenhum card novo surgiu e o Agente já ficou ocioso (ex.: erro 'Media not found' no chat), encerra imediatamente sem travar!
                    if (!newCardsAppeared && snap.GeneratingCards == 0 && !snap.AgentBusy &&
                        batchNumber >= 90 && (agentRepliedOnlyText || elapsedSec >= 25))
                    {
                        _log(string.Format("[Google Flow | Lote {0}] Tentativa encerrada sem novo card em geração ({1:0}s) -> prosseguindo...", batchNumber, elapsedSec));
                        return snap;
                    }

                    // Se em um lote 'continue' o Agente respondeu apenas em texto (ex.: 'Como deseja proceder?') ou não iniciou cards após 95s, envia reforço único
                    if (!newCardsAppeared && !snap.AgentBusy && !nudgedContinueOnce &&
                        batchNumber >= 2 && batchNumber < 90 &&
                        (agentRepliedOnlyText || elapsedSec >= 95))
                    {
                        nudgedContinueOnce = true;
                        _log(string.Format("[Google Flow | Lote {0}] Agente aguardando confirmação sem iniciar cards -> reforçando avanço imediato dos próximos takes...", batchNumber));
                        await InsertTextIntoFlowTextboxAsync(sess, "Ignore quaisquer falhas anteriores (já resolvidas) e inicie imediatamente a geração em vídeo dos próximos takes pendentes na sequência exata do roteiro, mantendo obrigatoriamente a tag exata [TAKE_XX] no início do prompt de cada vídeo.", true, ct);
                        await Task.Delay(500, ct);
                        await ClickStartGenerationAsync(sess, ct);
                    }
                }
            }

            throw new TimeoutException(string.Format("Timeout aguardando término do Lote {0} no Google Flow.", batchNumber));
        }

        private async Task<FlowTakeSpec> ResolveMinorFailedTakeSpecAsync(
            string sess,
            PreSessionGridBaseline baseline,
            EpisodeWorkItem ep,
            string reusedPrompt,
            List<FlowTakeSpec> flowEligibleTakes,
            HashSet<int> minorHandledTakeNumbers,
            int batchStartTakeIndex,
            int batchExpectedCount,
            CancellationToken ct)
        {
            if (flowEligibleTakes == null || flowEligibleTakes.Count == 0)
                return null;

            int batchEndExclusive = Math.Min(flowEligibleTakes.Count, Math.Max(0, batchStartTakeIndex) + Math.Max(1, batchExpectedCount));

            if (!string.IsNullOrWhiteSpace(reusedPrompt))
            {
                FlowTakeSpec bestSpec = null;
                double bestScore = 0.0;

                for (int i = 0; i < flowEligibleTakes.Count; i++)
                {
                    FlowTakeSpec candidate = flowEligibleTakes[i];
                    if (minorHandledTakeNumbers != null && minorHandledTakeNumbers.Contains(candidate.TakeNumber))
                        continue;

                    double s = ComputeTakeToVideoMatchScore(candidate, reusedPrompt);
                    // Em caso de empate técnico muito próximo, prioriza take pertencente à janela do lote atual
                    bool inBatchWindow = (i >= batchStartTakeIndex && i < batchEndExclusive);
                    double effectiveScore = inBatchWindow ? (s + 0.015) : s;

                    if (effectiveScore > bestScore)
                    {
                        bestScore = effectiveScore;
                        bestSpec = candidate;
                    }
                }

                if (bestSpec != null && bestScore >= 0.36)
                    return bestSpec;
            }

            // Fallback: identifica quais takes da janela do lote atual ainda não têm vídeo concluído no painel do Agente nem .mp4 salvo em disco
            List<SessionCompletedVideoInfo> completedVids = await CollectSessionVideosFromAgentPanelAsync(sess, baseline, ct);
            HashSet<int> completedTakeNums = new HashSet<int>();
            for (int v = 0; v < completedVids.Count; v++)
            {
                int tNum = IdentifyTakeNumberFromPrompt(completedVids[v].AltPrompt, flowEligibleTakes);
                if (tNum > 0)
                    completedTakeNums.Add(tNum);
            }

            for (int i = Math.Max(0, batchStartTakeIndex); i < batchEndExclusive; i++)
            {
                FlowTakeSpec candidate = flowEligibleTakes[i];
                if (minorHandledTakeNumbers != null && minorHandledTakeNumbers.Contains(candidate.TakeNumber))
                    continue;
                if (completedTakeNums.Contains(candidate.TakeNumber))
                    continue;

                string mp4Path = Path.Combine(ep.TakesDir, string.Format("Take_{0:00}.mp4", candidate.TakeNumber));
                if (File.Exists(mp4Path) && new FileInfo(mp4Path).Length >= 50 * 1024)
                    continue;

                return candidate;
            }

            return null;
        }

        private async Task<bool> DeleteMinorErrorCardInFlowAsync(
            string sess,
            PreSessionGridBaseline baseline,
            int preferredMountedIdx,
            CancellationToken ct)
        {
            SessionPollSnapshot beforeSnap = await InspectCurrentSessionStateAsync(sess, baseline, ct);
            int beforeMinorCount = beforeSnap.MinorFailedMountedIndices.Count;
            if (beforeMinorCount == 0)
                return true;

            int targetIdx = beforeSnap.MinorFailedMountedIndices.Contains(preferredMountedIdx)
                ? preferredMountedIdx
                : beforeSnap.MinorFailedMountedIndices[0];

            // 1ª tentativa: clique via coordenadas CDP no botão 'Excluir' (delete_forever) do card de menores
            await ClickFailedTileActionButtonAsync(sess, targetIdx, beforeSnap.SessionSliceEndIndex, true, true, ct);
            await Task.Delay(850, ct);

            // Se aparecer algum diálogo de confirmação no overlay, confirma imediatamente
            await _cdp.EvalStringAsync(sess, @"
(function(){
    var dlgBtns = Array.from(document.querySelectorAll('mat-dialog-container button, [role=""dialog""] button, [role=""alertdialog""] button'));
    var confirmBtn = dlgBtns.find(b => {
        var t = ((b.innerText || '') + ' ' + (b.getAttribute('aria-label') || '')).toLowerCase();
        return t.indexOf('excluir') >= 0 || t.indexOf('delete') >= 0 || t.indexOf('confirm') >= 0 || t.indexOf('remover') >= 0;
    });
    if (confirmBtn) { confirmBtn.click(); return 'CONFIRMED'; }
    return 'NONE';
})()", ct);

            SessionPollSnapshot afterSnap = await InspectCurrentSessionStateAsync(sess, baseline, ct);
            if (afterSnap.MinorFailedMountedIndices.Count < beforeMinorCount)
                return true;

            // 2ª tentativa (fallback): aciona .click() nativo direto no botão 'Excluir' (delete_forever) do card de menores
            int fallbackTargetIdx = afterSnap.MinorFailedMountedIndices.Contains(preferredMountedIdx)
                ? preferredMountedIdx
                : (afterSnap.MinorFailedMountedIndices.Count > 0 ? afterSnap.MinorFailedMountedIndices[0] : 0);

            await _cdp.EvalStringAsync(sess, string.Format(@"
(function(){{
    var tiles = Array.from(document.querySelectorAll('flow-video-tile'));
    var limit = Math.min(tiles.length, {1});
    function isMinorErr(el) {{
        if (!el) return false;
        var hasMore = !!el.querySelector('button[aria-label*=""Mais op""], button[aria-label*=""More""]');
        var hasThumb = !!(el.querySelector('img.thumbnail') || el.querySelector('video'));
        if (hasMore || hasThumb) return false;
        var txt = (el.innerText || '');
        return /violar|pol[ií]ticas|falha|erro|n[aã]o foi poss[ií]vel|violate|failed/i.test(txt) &&
               /\b(menores\s+de\s+idade|menor\s+de\s+idade|relacionado\s+a\s+menores|menores|crian[cç]as?|minors?|children|child|underage)\b/i.test(txt);
    }}
    var t = ({0} < limit && isMinorErr(tiles[{0}])) ? tiles[{0}] : null;
    if (!t) {{
        for (var i = 0; i < limit; i++) {{
            if (isMinorErr(tiles[i])) {{ t = tiles[i]; break; }}
        }}
    }}
    if (!t) return 'NO_TILE';
    var btn = Array.from(t.querySelectorAll('button')).find(b => {{
        var al = (b.getAttribute('aria-label') || '');
        var txt = (b.innerText || '').trim();
        return al.indexOf('Excluir') >= 0 || al.indexOf('Delete') >= 0 || txt.indexOf('delete') >= 0;
    }});
    if (!btn) return 'NO_BTN';
    btn.click();
    return 'CLICKED';
}})()", fallbackTargetIdx, Math.Max(1, afterSnap.SessionSliceEndIndex)), ct);

            await Task.Delay(850, ct);
            SessionPollSnapshot afterFallbackSnap = await InspectCurrentSessionStateAsync(sess, baseline, ct);
            return afterFallbackSnap.MinorFailedMountedIndices.Count < beforeMinorCount;
        }

        private async Task<int> HandleMinorPolicyFailedTakesAsync(
            string sess,
            PreSessionGridBaseline baseline,
            EpisodeWorkItem ep,
            List<FlowTakeSpec> flowEligibleTakes,
            Dictionary<string, string> ingredientToResolvedName,
            HashSet<int> minorHandledTakeNumbers,
            int batchStartTakeIndex,
            int batchExpectedCount,
            CancellationToken ct)
        {
            if (_config.AreAllGrokProfilesMarkedExhausted())
                return 0;

            int deletedCount = 0;
            int safetyLimit = Math.Max(6, (flowEligibleTakes != null ? flowEligibleTakes.Count : 6) + 4);

            for (int guard = 0; guard < safetyLimit; guard++)
            {
                ct.ThrowIfCancellationRequested();
                if (_config.AreAllGrokProfilesMarkedExhausted())
                    break;

                SessionPollSnapshot snap = await InspectCurrentSessionStateAsync(sess, baseline, ct);
                if (snap.MinorFailedMountedIndices.Count == 0)
                    break;

                int minorMountedIdx = snap.MinorFailedMountedIndices[0];
                int sessionSliceLimit = snap.SessionSliceEndIndex;

                // 1. Lê o comando exato do card bloqueado por menores clicando em 'Reutilizar comando' (↩) e limpa a caixa do Flow logo em seguida
                string reusedPrompt = "";
                bool clickedReuse = await ClickFailedTileActionButtonAsync(sess, minorMountedIdx, sessionSliceLimit, false, true, ct);
                if (clickedReuse)
                {
                    await Task.Delay(900, ct);
                    reusedPrompt = await ReadCurrentFlowTextboxAsync(sess, ct);
                    await InsertTextIntoFlowTextboxAsync(sess, "", true, ct);
                    await ClearAttachedPromptChipsAsync(sess, ct);
                }

                FlowTakeSpec matchedTake = await ResolveMinorFailedTakeSpecAsync(
                    sess,
                    baseline,
                    ep,
                    reusedPrompt,
                    flowEligibleTakes,
                    minorHandledTakeNumbers,
                    batchStartTakeIndex,
                    batchExpectedCount,
                    ct);

                // 2. Gera imediatamente a cena no Grok Vídeo
                if (matchedTake != null)
                {
                    string expectedMp4 = Path.Combine(ep.TakesDir, string.Format("Take_{0:00}.mp4", matchedTake.TakeNumber));
                    bool alreadyHasValidMp4 = File.Exists(expectedMp4) && new FileInfo(expectedMp4).Length >= 50 * 1024;
                    if (!alreadyHasValidMp4)
                    {
                        _log(string.Format("[Flow -> Grok | Menores] Take_{0:00} não foi gerado no Google Flow por política de menores de idade -> gerando cena no Grok Vídeo...",
                            matchedTake.TakeNumber));
                        await _grok.GenerateVideoTakesAsync(
                            ep,
                            new List<FlowTakeSpec> { matchedTake },
                            ingredientToResolvedName,
                            ct);
                    }

                    bool hasMp4Now = File.Exists(expectedMp4) && new FileInfo(expectedMp4).Length >= 50 * 1024;
                    try { await _cdp.SendCommandAsync("Page.bringToFront", null, sess, 10000, ct); } catch { }
                    await Task.Delay(500, ct);

                    if (!hasMp4Now && _config.AreAllGrokProfilesMarkedExhausted())
                    {
                        _log(string.Format("[Grok Sem Créditos -> Flow] Todas as contas Grok ficaram sem créditos ao tentar o Take_{0:00}. Mantendo o card no Google Flow para tentar 1ª vez, 2ª suavizada ou pular...",
                            matchedTake.TakeNumber));
                        break;
                    }

                    if (minorHandledTakeNumbers != null)
                        minorHandledTakeNumbers.Add(matchedTake.TakeNumber);
                }
                else
                {
                    _log(string.Format("[Flow -> Grok | Menores] Card #{0} bloqueado por política de menores de idade -> será gerado no Grok Vídeo.",
                        minorMountedIdx + 1));
                }

                // 3. Deleta o card de erro no Google Flow e prossegue
                bool deletedOk = await DeleteMinorErrorCardInFlowAsync(sess, baseline, minorMountedIdx, ct);
                if (deletedOk)
                {
                    deletedCount++;
                    _log(string.Format("[Google Flow | Menores] Erro de menores excluído no Google Flow{0}. Prosseguindo...",
                        matchedTake != null ? string.Format(" (Take_{0:00})", matchedTake.TakeNumber) : ""));
                }
                else
                {
                    _log("[Google Flow | Aviso] Não foi possível confirmar a exclusão do card de erro de menores no Google Flow. Prosseguindo...");
                    break;
                }
            }

            return deletedCount;
        }

        private async Task HandleFailedTakesStrictlyAsync(
            string sess,
            PreSessionGridBaseline baseline,
            EpisodeWorkItem ep,
            List<FlowTakeSpec> targetTakes,
            Dictionary<string, string> ingredientToResolvedName,
            HashSet<int> minorHandledTakeNumbers,
            HashSet<int> skippedTakeNumbersOut,
            CancellationToken ct)
        {
            // Regra 16 (somente nos cards desta Nova sessão!):
            // Se houver card com erro de menores de idade (e Grok tiver créditos), gera direto no Grok e deleta o erro no Flow sem retentar!
            // Quando Grok está sem créditos (ou para demais erros): 1ª TENTATIVA OBRIGATÓRIA sem alterar o texto; 2ª TENTATIVA com suavização anti-bloqueio; se ainda falhar sem créditos no Grok, pula a cena!
            Dictionary<string, int> promptRetryCounts = new Dictionary<string, int>(StringComparer.Ordinal);
            int maxOperations = Math.Max(6, targetTakes.Count * 2 + 2);

            for (int op = 0; op < maxOperations; op++)
            {
                ct.ThrowIfCancellationRequested();
                SessionPollSnapshot snap = await InspectCurrentSessionStateAsync(sess, baseline, ct);
                if (snap.FailedCards == 0 || snap.FailedMountedIndices.Count == 0)
                    return;

                if (snap.MinorFailedMountedIndices.Count > 0 && !_config.AreAllGrokProfilesMarkedExhausted())
                {
                    int delMinor = await HandleMinorPolicyFailedTakesAsync(
                        sess,
                        baseline,
                        ep,
                        targetTakes,
                        ingredientToResolvedName,
                        minorHandledTakeNumbers,
                        0,
                        targetTakes.Count,
                        ct);
                    if (delMinor > 0)
                        continue;
                }

                int failedMountedIdx = snap.FailedMountedIndices[0];
                int sessionSliceLimit = snap.SessionSliceEndIndex;

                bool clickedReuse = await ClickFailedTileActionButtonAsync(sess, failedMountedIdx, sessionSliceLimit, false, false, ct);
                if (!clickedReuse)
                {
                    _log(string.Format("[Google Flow] Aviso: botão 'Reutilizar comando' não localizado no card com erro (idx {0}).", failedMountedIdx));
                    break;
                }

                await Task.Delay(950, ct);
                string reusedPrompt = await ReadCurrentFlowTextboxAsync(sess, ct);
                int explicitFailedTag = TryExtractExplicitTakeTagNumber(reusedPrompt);
                int matchedTakeNum = explicitFailedTag > 0
                    ? explicitFailedTag
                    : IdentifyTakeNumberFromPrompt(reusedPrompt, targetTakes);
                string distinctiveKey = matchedTakeNum > 0
                    ? ("take_num_" + matchedTakeNum)
                    : EpisodeParser.NormalizeForCompare(ExtractDistinctiveTakeBody(reusedPrompt));
                if (string.IsNullOrEmpty(distinctiveKey))
                    distinctiveKey = "card_slot_" + failedMountedIdx;

                string takeLabel = matchedTakeNum > 0
                    ? string.Format("Take {0:00}", matchedTakeNum)
                    : string.Format("Card #{0}", failedMountedIdx + 1);

                int prevRetries;
                if (!promptRetryCounts.TryGetValue(distinctiveKey, out prevRetries))
                    prevRetries = 0;

                if (prevRetries >= 2)
                {
                    if (_config.AreAllGrokProfilesMarkedExhausted())
                    {
                        if (matchedTakeNum > 0 && skippedTakeNumbersOut != null)
                            skippedTakeNumbersOut.Add(matchedTakeNum);
                        _log(string.Format("[Google Flow | Cena Pulada] {0} falhou após a 1ª tentativa e a 2ª tentativa suavizada no Google Flow (e o Grok está sem créditos) -> pulando cena e removendo card com erro...", takeLabel));
                    }
                    else
                    {
                        _log(string.Format("[Google Flow -> Grok] {0} falhou após as 2 tentativas padrões no Google Flow. Limpando card com erro residual para gerar no Grok Vídeo...", takeLabel));
                    }
                    await InsertTextIntoFlowTextboxAsync(sess, "", true, ct);
                    await ClearAttachedPromptChipsAsync(sess, ct);
                    await ClickFailedTileActionButtonAsync(sess, failedMountedIdx, sessionSliceLimit, true, false, ct);
                    await Task.Delay(500, ct);
                    continue;
                }

                int currentAttemptNumber = prevRetries + 1;
                promptRetryCounts[distinctiveKey] = currentAttemptNumber;

                if (currentAttemptNumber == 1)
                {
                    _log(string.Format("[Google Flow | Regra 16] {0} apresentou erro -> 1ª TENTATIVA OBRIGATÓRIA: 'Reutilizar comando' (↩) e regerando SEM ALTERAR O TEXTO!", takeLabel));
                    if (explicitFailedTag == 0 && matchedTakeNum > 0)
                    {
                        string taggedRetry1 = InjectTakeTagIntoPromptBody(reusedPrompt, matchedTakeNum);
                        await InsertTextIntoFlowTextboxAsync(sess, taggedRetry1, true, ct);
                        await Task.Delay(400, ct);
                    }
                }
                else
                {
                    _log(string.Format("[Google Flow | Regra 16] {0} falhou novamente após 1ª regeneração -> 2ª TENTATIVA: 'Reutilizar comando' (↩) com suavização anti-bloqueio...", takeLabel));
                    string softened = SoftenPromptForSecondAttempt(reusedPrompt);
                    if (matchedTakeNum > 0)
                    {
                        softened = InjectTakeTagIntoPromptBody(softened, matchedTakeNum);
                        promptRetryCounts["take_num_" + matchedTakeNum] = 2;
                    }
                    string softenedKey = EpisodeParser.NormalizeForCompare(ExtractDistinctiveTakeBody(softened));
                    if (!string.IsNullOrEmpty(softenedKey))
                        promptRetryCounts[softenedKey] = 2;

                    await InsertTextIntoFlowTextboxAsync(sess, softened, true, ct);
                    await Task.Delay(550, ct);
                }

                // IMPORTANTE (Opção 2): NÃO excluir o card antes do envio da tentativa (excluir antes apaga a referência de mídia e causa 'Media not found'!).
                int baselineBeforeRetrySubmit = snap.TotalSessionCards;
                int minorDeletedSoFar = minorHandledTakeNumbers != null ? minorHandledTakeNumbers.Count : 0;

                await ClickStartGenerationAsync(sess, ct);
                try
                {
                    SessionPollSnapshot afterRetrySnap = await WaitForCurrentBatchToFinishAsync(
                        sess,
                        baseline,
                        90 + currentAttemptNumber,
                        targetTakes.Count,
                        baselineBeforeRetrySubmit,
                        minorDeletedSoFar,
                        ct);

                    // Se a tentativa criou um novo card no grid (concluído ou novo erro), remove o card de erro antigo para não duplicar.
                    // Quando o novo card também falha, ele entra em FailedMountedIndices[0] e o erro antigo desloca para FailedMountedIndices[1].
                    // Quando o novo card conclui com sucesso, o erro antigo permanece em FailedMountedIndices[0].
                    if (afterRetrySnap.TotalSessionCards > baselineBeforeRetrySubmit && afterRetrySnap.FailedMountedIndices.Count > 0)
                    {
                        bool newCardAlsoFailed = afterRetrySnap.FailedCards > snap.FailedCards;
                        int oldErrorIdx = (newCardAlsoFailed && afterRetrySnap.FailedMountedIndices.Count > 1)
                            ? afterRetrySnap.FailedMountedIndices[1]
                            : afterRetrySnap.FailedMountedIndices[0];
                        await ClickFailedTileActionButtonAsync(sess, oldErrorIdx, afterRetrySnap.SessionSliceEndIndex, true, false, ct);
                        await Task.Delay(500, ct);
                    }
                }
                catch (OperationCanceledException)
                {
                    throw;
                }
                catch (Exception ex)
                {
                    _log(string.Format("[Google Flow | Aviso] Falha ao aguardar regeneração de {0} ({1}). Prosseguindo...", takeLabel, ex.Message));
                    break;
                }
            }
        }

        private async Task<bool> ClickFailedTileActionButtonAsync(
            string sess,
            int preferredMountedIdx,
            int sessionSliceLimit,
            bool clickDeleteInsteadOfReuse,
            bool requireMinorError,
            CancellationToken ct)
        {
            string wantDeleteJs = clickDeleteInsteadOfReuse ? "true" : "false";
            string requireMinorJs = requireMinorError ? "true" : "false";

            // Garante scrollTop = 0 para que o índice dentro da fatia da sessão seja exato
            await _cdp.EvalStringAsync(sess, @"
(function(){
    var vp = document.querySelector('cdk-virtual-scroll-viewport.tiles-container') || document.querySelector('cdk-virtual-scroll-viewport');
    if (vp && vp.scrollTop > 8) vp.scrollTop = 0;
    return 'OK';
})()", ct);
            await Task.Delay(250, ct);

            Dictionary<string, object> tileCenter = await _cdp.EvalJsonAsync(sess, string.Format(@"
(function(){{
    var requireMinor = {2};
    var tiles = Array.from(document.querySelectorAll('flow-video-tile, flow-pending-tile, flow-error-tile')).filter(function(el) {{
        var p = el.parentElement;
        return !p || !p.closest('flow-video-tile, flow-pending-tile, flow-error-tile');
    }});
    var limit = Math.min(tiles.length, {1});
    var t = ({0} < limit) ? tiles[{0}] : null;
    function isErr(el) {{
        if (!el) return false;
        var hasMore = !!el.querySelector('button[aria-label*=""Mais op""], button[aria-label*=""More""]');
        var hasThumb = !!(el.querySelector('img.thumbnail') || el.querySelector('video'));
        if (hasMore || hasThumb) return false;
        var isErrTag = (el.tagName || '').toLowerCase() === 'flow-error-tile' || !!el.querySelector('flow-error-tile');
        var txt = (el.innerText || '');
        if (!isErrTag && !/violar|pol[ií]ticas|falha|erro|errado|n[aã]o\s+foi\s+poss[ií]vel|n[aã]o\s+[eé]\s+poss[ií]vel|n[aã]o\s+p[oô]de|bloquead|tente\s+(?:novamente|de\s+novo)|violate|failed|error|wrong|unable\s+to|cannot\s+generate|blocked|try\s+again|policy/i.test(txt)) return false;
        if (requireMinor) {{
            return /\b(menores\s+de\s+idade|menor\s+de\s+idade|relacionado\s+a\s+menores|menores|crian[cç]as?|minors?|children|child|underage)\b/i.test(txt);
        }}
        return true;
    }}
    if (!isErr(t)) {{
        t = null;
        for (var i = 0; i < limit; i++) {{
            if (isErr(tiles[i])) {{ t = tiles[i]; break; }}
        }}
    }}
    if (!t) return null;
    var r = t.getBoundingClientRect();
    if (r.top < 40 || r.bottom > window.innerHeight - 20) {{
        t.scrollIntoView({{ block: 'center' }});
        r = t.getBoundingClientRect();
    }}
    return JSON.stringify({{ x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) }});
}})()", preferredMountedIdx, Math.Max(1, sessionSliceLimit), requireMinorJs), ct);

            if (tileCenter == null) return false;

            await Task.Delay(350, ct);
            await _cdp.HoverAsync(sess, Convert.ToInt32(tileCenter["x"]), Convert.ToInt32(tileCenter["y"]), ct);
            await Task.Delay(350, ct);

            Dictionary<string, object> btnPt = await _cdp.EvalJsonAsync(sess, string.Format(@"
(function(){{
    var wantDelete = {2};
    var requireMinor = {3};
    var tiles = Array.from(document.querySelectorAll('flow-video-tile, flow-pending-tile, flow-error-tile')).filter(function(el) {{
        var p = el.parentElement;
        return !p || !p.closest('flow-video-tile, flow-pending-tile, flow-error-tile');
    }});
    var limit = Math.min(tiles.length, {1});
    function isErr(el) {{
        if (!el) return false;
        var hasMore = !!el.querySelector('button[aria-label*=""Mais op""], button[aria-label*=""More""]');
        var hasThumb = !!(el.querySelector('img.thumbnail') || el.querySelector('video'));
        if (hasMore || hasThumb) return false;
        var isErrTag = (el.tagName || '').toLowerCase() === 'flow-error-tile' || !!el.querySelector('flow-error-tile');
        var txt = (el.innerText || '');
        if (!isErrTag && !/violar|pol[ií]ticas|falha|erro|errado|n[aã]o\s+foi\s+poss[ií]vel|n[aã]o\s+[eé]\s+poss[ií]vel|n[aã]o\s+p[oô]de|bloquead|tente\s+(?:novamente|de\s+novo)|violate|failed|error|wrong|unable\s+to|cannot\s+generate|blocked|try\s+again|policy/i.test(txt)) return false;
        if (requireMinor) {{
            return /\b(menores\s+de\s+idade|menor\s+de\s+idade|relacionado\s+a\s+menores|menores|crian[cç]as?|minors?|children|child|underage)\b/i.test(txt);
        }}
        return true;
    }}
    var t = ({0} < limit && isErr(tiles[{0}])) ? tiles[{0}] : null;
    if (!t) {{
        for (var i = 0; i < limit; i++) {{
            if (isErr(tiles[i])) {{ t = tiles[i]; break; }}
        }}
    }}
    if (!t) return null;
    var btn = Array.from(t.querySelectorAll('button')).find(b => {{
        var al = (b.getAttribute('aria-label') || '');
        var txt = (b.innerText || '').trim();
        if (wantDelete) {{
            return al.indexOf('Excluir') >= 0 || al.indexOf('Delete') >= 0 || txt.indexOf('delete') >= 0;
        }}
        return al.indexOf('Reutilizar comando') >= 0 || al.indexOf('Reuse') >= 0 || txt === 'replay' || txt === 'undo';
    }});
    if (!btn) return null;
    var r = btn.getBoundingClientRect();
    if (r.width < 5) return null;
    return JSON.stringify({{ x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) }});
}})()", preferredMountedIdx, Math.Max(1, sessionSliceLimit), wantDeleteJs, requireMinorJs), ct);

            if (btnPt == null) return false;
            await _cdp.ClickAtAsync(sess, Convert.ToInt32(btnPt["x"]), Convert.ToInt32(btnPt["y"]), ct);
            return true;
        }

        private string SoftenPromptForSecondAttempt(string text)
        {
            if (string.IsNullOrEmpty(text)) return text;

            // Protege nomes de arquivos de ingredientes (.jpg/.jpeg/.png/.webp) para não alterar as referências anexadas
            List<string> protectedFiles = new List<string>();
            string s = Regex.Replace(text, @"\b[^\s,;:""'\(\)\[\]<>]+?\.(?:jpg|jpeg|png|webp)\b", m =>
            {
                string token = "__FLOW_ASSET_TOKEN_" + protectedFiles.Count + "__";
                protectedFiles.Add(m.Value);
                return token;
            }, RegexOptions.IgnoreCase);

            var phraseReplacements = new Tuple<string, string>[]
            {
                Tuple.Create("proporções corporais adultas", "proporções corporais de adultos maduros (acima de 30 anos)"),
                Tuple.Create("derruba uma cadeira", "se afasta da mesa apontando para a porta"),
                Tuple.Create("arremessa a cadeira", "aponta a mão com firmeza para a porta"),
                Tuple.Create("bate com força na mesa", "apoia as mãos com firmeza na mesa"),
                Tuple.Create("vender uma cria", "negociar um animal dessa sua linhagem"),
                Tuple.Create("comprar uma cria", "negociar um cavalo forte dessa sua fazenda"),
                Tuple.Create("agiota", "cobrador"),
                Tuple.Create("prestamista", "cobrador"),
                Tuple.Create("ameaçou", "disse que perderemos"),
                Tuple.Create("amenazó", "dijo que perderemos"),
                Tuple.Create("sua alma será só minha", "cobrarei a promessa combinada"),
                Tuple.Create("olhos faiscando de exaustão e revolta", "olhar expressivo de cansaço e indignação"),
                Tuple.Create("olhar fulminante", "olhar sério e firme"),
                Tuple.Create("choque e raiva", "espanto e indignação"),
                Tuple.Create("camisola modesta", "roupa caseira comprida"),
                Tuple.Create("em pânico sutil", "com nervosismo visível"),
                Tuple.Create("em pânico", "com expressão surpresa"),
                Tuple.Create("fúria", "indignação intensa"),
                Tuple.Create("menor de idade", "jovem adulto"),
                Tuple.Create("menores de idade", "jovens adultos"),
                Tuple.Create("filho pequeno", "filho jovem"),
                Tuple.Create("filha pequena", "filha jovem"),
                Tuple.Create("neto pequeno", "neto jovem"),
                Tuple.Create("neta pequena", "neta jovem"),
                Tuple.Create("irmão pequeno", "irmão mais novo"),
                Tuple.Create("irmã pequena", "irmã mais nova"),
                Tuple.Create("criança pequena", "pessoa jovem de estatura baixa"),
                Tuple.Create("recém-nascido", "pequeno embrulho de manta"),
                Tuple.Create("bebê de colo", "pequeno embrulho de manta no colo")
            };

            foreach (var rep in phraseReplacements)
            {
                s = Regex.Replace(s, Regex.Escape(rep.Item1), rep.Item2, RegexOptions.IgnoreCase);
            }

            // Suaviza referências diretas a idade infantil ("de 7 anos", "de 10 anos de idade", etc.)
            s = Regex.Replace(s, @"\b(?:de\s+)?(?:[1-9]|1[0-7])\s+anos(?:\s+de\s+idade)?\b", "jovem adulto", RegexOptions.IgnoreCase);

            // Suaviza substantivos infantis e termos de sofrimento/violência intensa que acionam filtro de menores no Google Flow
            var wordReplacements = new Tuple<string, string>[]
            {
                Tuple.Create(@"\bcrianças\b", "jovens"),
                Tuple.Create(@"\bcriança\b", "jovem"),
                Tuple.Create(@"\bmeninos\b", "rapazes jovens"),
                Tuple.Create(@"\bmenino\b", "rapaz jovem"),
                Tuple.Create(@"\bmeninas\b", "moças jovens"),
                Tuple.Create(@"\bmenina\b", "moça jovem"),
                Tuple.Create(@"\bgarotos\b", "rapazes jovens"),
                Tuple.Create(@"\bgaroto\b", "rapaz jovem"),
                Tuple.Create(@"\bgarotas\b", "moças jovens"),
                Tuple.Create(@"\bgarota\b", "moça jovem"),
                Tuple.Create(@"\bguris\b", "rapazes jovens"),
                Tuple.Create(@"\bguri\b", "rapaz jovem"),
                Tuple.Create(@"\bpirralho\b", "rapaz"),
                Tuple.Create(@"\bpirralha\b", "moça"),
                Tuple.Create(@"\bbebê\b", "pequeno embrulho"),
                Tuple.Create(@"\bbebês\b", "pequenos embrulhos"),
                Tuple.Create(@"\binfantil\b", "juvenil"),
                Tuple.Create(@"\binfantis\b", "juvenis"),
                Tuple.Create(@"\bchorando\s+muito\b", "com expressão emocionada"),
                Tuple.Create(@"\bchorando\b", "com olhar entristecido"),
                Tuple.Create(@"\bchora\b", "abaixa o olhar emocionado"),
                Tuple.Create(@"\bchorar\b", "se emocionar"),
                Tuple.Create(@"\bsoluçando\b", "respirando fundo emocionado"),
                Tuple.Create(@"\blágrimas\b", "emoção no olhar"),
                Tuple.Create(@"\bassustado\b", "surpreso"),
                Tuple.Create(@"\bassustada\b", "surpresa"),
                Tuple.Create(@"\baterrorizado\b", "muito surpreso"),
                Tuple.Create(@"\baterrorizada\b", "muito surpresa"),
                Tuple.Create(@"\bhumilhado\b", "constrangido"),
                Tuple.Create(@"\bhumilhada\b", "constrangida"),
                Tuple.Create(@"\bgritando\b", "falando com voz firme"),
                Tuple.Create(@"\bgrita\b", "fala com firmeza"),
                Tuple.Create(@"\bempurra\b", "afasta o braço"),
                Tuple.Create(@"\bameaça\b", "avisa seriamente"),
                Tuple.Create(@"\bviolência\b", "tensão dramática"),
                Tuple.Create(@"\bsangue\b", "mancha escura")
            };

            foreach (var wrep in wordReplacements)
            {
                s = Regex.Replace(s, wrep.Item1, wrep.Item2, RegexOptions.IgnoreCase);
            }

            for (int i = 0; i < protectedFiles.Count; i++)
            {
                s = s.Replace("__FLOW_ASSET_TOKEN_" + i + "__", protectedFiles[i]);
            }

            return s;
        }

    }
}
