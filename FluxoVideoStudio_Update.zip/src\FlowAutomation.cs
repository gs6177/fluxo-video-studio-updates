using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace FluxoVideoStudio
{
    public class FlowAutomation
    {
        private readonly CdpController _cdp;
        private readonly PipelineConfig _config;
        private readonly GrokAutomation _grok;
        private readonly Action<string> _log;
        private static readonly Random _flowRng = new Random();
        private static readonly object _flowRngLock = new object();

        private async Task WaitRandomFlowActionDelayAsync(string actionReason, CancellationToken ct)
        {
            int minSec = _config != null ? Math.Max(0, _config.FlowActionDelayMinSeconds) : 15;
            int maxSec = _config != null ? Math.Max(0, _config.FlowActionDelayMaxSeconds) : 30;
            if (maxSec < minSec)
            {
                int tmp = minSec;
                minSec = maxSec;
                maxSec = tmp;
            }
            if (maxSec <= 0)
                return;

            int waitMs;
            lock (_flowRngLock)
            {
                int minMs = minSec * 1000;
                int maxMs = maxSec * 1000;
                waitMs = (maxMs > minMs) ? _flowRng.Next(minMs, maxMs + 1) : minMs;
            }

            _log(string.Format("[Google Flow | Delay] Aguardando {0:0.0}s ({1})...", waitMs / 1000.0, actionReason));
            await _cdp.WaitOrWakeOnReloadSignalAsync(waitMs, ct);
        }

        public FlowAutomation(CdpController cdp, PipelineConfig config, Action<string> logger)
            : this(cdp, config, new GrokAutomation(cdp, config, logger), logger)
        {
        }

        public FlowAutomation(CdpController cdp, PipelineConfig config, GrokAutomation grok, Action<string> logger)
        {
            _cdp = cdp;
            _config = config;
            _grok = grok ?? new GrokAutomation(cdp, config, logger);
            _log = logger ?? delegate { };
            _grok.SetFlowFallback(this);
        }

        public static bool IsYouthCharacterTake(FlowTakeSpec take, EpisodeWorkItem ep)
        {
            if (take == null) return false;

            // Remove falas entre aspas ("...") para que expressões idiomáticas entre adultos ("meu filho", "minha filha") não gerem falso positivo
            string bodyWithoutQuotes = Regex.Replace(take.RawPromptBody ?? "", @"""[^""]*""", " ");
            StringBuilder sb = new StringBuilder();
            sb.Append(take.RawHeader ?? "").Append(' ');
            sb.Append(bodyWithoutQuotes).Append(' ');
            if (take.Ingredients != null)
            {
                for (int i = 0; i < take.Ingredients.Count; i++)
                    sb.Append(take.Ingredients[i]).Append(' ');
            }

            // Inspeciona também a definição dos personagens vinculados aos ingredientes deste take
            if (ep != null && ep.GrokSpecs != null && take.Ingredients != null && take.Ingredients.Count > 0)
            {
                HashSet<string> takeIngSet = new HashSet<string>(take.Ingredients, StringComparer.OrdinalIgnoreCase);
                for (int i = 0; i < ep.GrokSpecs.Count; i++)
                {
                    GrokAssetSpec gs = ep.GrokSpecs[i];
                    if (gs == null || string.IsNullOrEmpty(gs.TargetFileName)) continue;
                    if (!takeIngSet.Contains(gs.TargetFileName)) continue;

                    string normSpec = EpisodeParser.NormalizeForCompare((gs.DisplayTitle ?? "") + " " + (gs.RawPromptLine ?? ""));
                    bool explicitlyAdult = Regex.IsMatch(normSpec, @"\b(homem adulto|mulher adulta|adulto|adulta|idoso|idosa|senhor|senhora|velho|velha)\b");
                    if (!explicitlyAdult)
                    {
                        sb.Append(gs.DisplayTitle ?? "").Append(' ');
                        sb.Append(gs.RawPromptLine ?? "").Append(' ');
                    }
                }
            }

            string norm = EpisodeParser.NormalizeForCompare(sb.ToString());
            if (string.IsNullOrEmpty(norm)) return false;

            // Remove expressões negativas de estilo visual (ex.: "sem rosto ou aparencia de ...", "sem tracos ...", "zero ...")
            norm = Regex.Replace(norm, @"\b(sem|zero|nunca|jamais|nao)\s+(rosto\s+ou\s+aparencia\s+de\s+|aparencia\s+de\s+|rosto\s+de\s+|feicoes\s+de\s+|tracos\s+de\s+|corpo\s+de\s+|aspecto\s+de\s+|personagens?\s+)?\w+(\s+ou\s+\w+)?", " ");
            norm = Regex.Replace(norm, @"\b(realcam|realcando|destacam)\s+personagens\s+adultos\b", " ");

            if (Regex.IsMatch(norm,
                @"\b(crianca|criancas|bebe|bebes|nenem|nenens|recem nascido|recem nascida|menino|meninos|menininho|menininha|menina|meninas|garoto|garotos|garotinho|garotinha|garota|garotas|guri|guria|pivete|moleque|molequinho|infantil|infantis|berco|chupeta|mamadeira|filho pequeno|filha pequena|filhos pequenos|filhas pequenas|filhinho|filhinha|irmaozinho|irmazinha|netinho|netinha|bebe de colo|crianca de colo)\b"))
            {
                return true;
            }

            if (Regex.IsMatch(norm,
                @"\b(([1-9]|1[0-7])\s+anos\s+de\s+idade|(de|com)\s+([1-9]|1[0-7])\s+meses|(filho|filha|irmao|irma|neto|neta|sobrinho|sobrinha)\s+de\s+([1-9]|1[0-7])\s+anos)\b"))
            {
                return true;
            }

            return false;
        }

        public static int TryExtractExplicitTakeTagNumber(string promptText)
        {
            if (string.IsNullOrWhiteSpace(promptText))
                return 0;

            Match m = Regex.Match(
                promptText,
                @"\[\s*TAKE(?:[_\-\s]*ID)?[_\-\s]*0*(\d{1,3})\s*\]",
                RegexOptions.IgnoreCase);

            if (m.Success)
            {
                int num;
                if (int.TryParse(m.Groups[1].Value, out num) && num > 0)
                    return num;
            }

            return 0;
        }

        private static string InjectTakeTagIntoPromptBody(string rawBody, int takeNumber)
        {
            string cleanBody = Regex.Replace(rawBody ?? "", @"(\r?\n|\s)*---\s*$", "").Trim();
            if (string.IsNullOrEmpty(cleanBody) || takeNumber <= 0)
                return cleanBody;

            if (TryExtractExplicitTakeTagNumber(cleanBody) == takeNumber)
                return cleanBody;

            string tag = string.Format("[TAKE_{0:00}]", takeNumber);

            Match prefixMatch = Regex.Match(cleanBody, @"^(Prompt\s+de\s+V[ií]deo\s*:\s*)", RegexOptions.IgnoreCase);
            if (prefixMatch.Success)
            {
                string rest = cleanBody.Substring(prefixMatch.Length).TrimStart();
                return "Prompt de Vídeo:\r\n" + tag + " " + rest;
            }

            return tag + " " + cleanBody;
        }

        public static string BuildFlowPromptForTakes(string originalPromptText, List<FlowTakeSpec> takes)
        {
            if (takes == null || takes.Count == 0) return "";

            StringBuilder sb = new StringBuilder();

            // Instrução obrigatória ao Agente do Google Flow para preservar a tag [TAKE_XX] no texto final de cada vídeo gerado
            sb.AppendLine("[INSTRUÇÃO OBRIGATÓRIA DE RASTREAMENTO DE TAKES]:");
            sb.AppendLine("Ao enviar o prompt de cada cena para a ferramenta de geração de vídeo (tanto neste lote inicial quanto nos próximos lotes após \"continue\"), mantenha OBRIGATORIAMENTE e literalmente a tag [TAKE_01], [TAKE_02], [TAKE_03], etc. exatamente no início do texto do prompt de cada vídeo gerado (exemplo: \"[TAKE_01] [Estilo Visual] ...\"). NUNCA remova, omita, traduza ou altere a tag [TAKE_XX] em nenhum vídeo. Essa tag é apenas controle interno de identificação — não renderize nenhum texto, número ou legenda escrita na imagem do vídeo.");
            sb.AppendLine();

            // Preserva eventual cabeçalho global existente antes do primeiro "Take X |"
            if (!string.IsNullOrWhiteSpace(originalPromptText))
            {
                string[] lines = originalPromptText.Split(new[] { "\r\n", "\n" }, StringSplitOptions.None);
                List<string> preambleLines = new List<string>();
                for (int i = 0; i < lines.Length; i++)
                {
                    if (Regex.IsMatch(lines[i], @"Take\s*0*(\d+)\s*\|", RegexOptions.IgnoreCase))
                        break;
                    preambleLines.Add(lines[i]);
                }
                string preamble = string.Join("\r\n", preambleLines).Trim();
                if (!string.IsNullOrEmpty(preamble))
                {
                    sb.AppendLine(preamble);
                    sb.AppendLine();
                }
            }

            for (int i = 0; i < takes.Count; i++)
            {
                FlowTakeSpec t = takes[i];
                string taggedBody = InjectTakeTagIntoPromptBody(t.RawPromptBody, t.TakeNumber);
                sb.AppendLine((t.RawHeader ?? "").Trim());
                sb.AppendLine(taggedBody);
                if (i < takes.Count - 1)
                {
                    sb.AppendLine();
                    sb.AppendLine("---");
                    sb.AppendLine();
                }
            }

            return sb.ToString().Trim();
        }

        public async Task RunAsync(EpisodeWorkItem ep, CancellationToken ct)
        {
            if (string.IsNullOrWhiteSpace(ep.FlowPromptText) || ep.FlowTakes.Count == 0)
            {
                throw new InvalidOperationException("Arquivo prompt_flow_passo3.txt vazio ou não encontrado para este episódio.");
            }

            if (!Directory.Exists(ep.TakesDir))
                Directory.CreateDirectory(ep.TakesDir);

            // Regra 22: Reaproveitamento automático do Take_01.mp4 (Gancho oficial de 10s) nas Partes 2 e 3 quando aplicável
            int firstTakeNumberInPrompt = ep.FlowTakes[0].TakeNumber;
            if (ep.EpisodeNumber > 1 && _config.ReuseEp1HookTake01 && firstTakeNumberInPrompt >= 2)
            {
                string ep1Take01 = Path.Combine(ep.StoryRootPath, "EP.1", "takes", "Take_01.mp4");
                string destTake01 = Path.Combine(ep.TakesDir, "Take_01.mp4");
                if (File.Exists(ep1Take01) && (!File.Exists(destTake01) || new FileInfo(destTake01).Length < 50 * 1024))
                {
                    File.Copy(ep1Take01, destTake01, true);
                    _log(string.Format("[Google Flow] Regra 22: Take_01.mp4 (Gancho de 10s) reaproveitado automaticamente do EP.1 para {0}!", ep.EpisodeName));
                }
            }

            // Inspeção permanente de takes já existentes na pasta 'takes':
            // Só move para _backup se TODOS os takes do episódio já estiverem concluídos (refazer episódio completo).
            // Se o episódio estiver incompleto, preserva todos os Take_XX.mp4 já salvos e gera apenas os ausentes!
            HashSet<int> existingOnDisk = new HashSet<int>();
            for (int i = 0; i < ep.FlowTakes.Count; i++)
            {
                int tn = ep.FlowTakes[i].TakeNumber;
                string mp4Path = Path.Combine(ep.TakesDir, string.Format("Take_{0:00}.mp4", tn));
                if (File.Exists(mp4Path) && new FileInfo(mp4Path).Length >= 50 * 1024)
                    existingOnDisk.Add(tn);
            }

            if (_config.ArchiveOldTakesBeforeRemake && existingOnDisk.Count >= ep.FlowTakes.Count)
            {
                string[] existingMedia = Directory.GetFiles(ep.TakesDir)
                    .Where(f => Regex.IsMatch(Path.GetExtension(f), @"^\.(mp4|mov)$", RegexOptions.IgnoreCase))
                    .ToArray();
                if (existingMedia.Length > 0)
                {
                    string backupDir = Path.Combine(ep.TakesDir, "_backup_" + DateTime.Now.ToString("yyyyMMdd_HHmmss"));
                    Directory.CreateDirectory(backupDir);
                    foreach (string oldFile in existingMedia)
                    {
                        string dst = Path.Combine(backupDir, Path.GetFileName(oldFile));
                        File.Move(oldFile, dst);
                    }
                    existingOnDisk.Clear();
                    _log(string.Format("[Modo Refazer] Episódio estava 100% completo -> {0} takes antigos arquivados com segurança em '{1}'.", existingMedia.Length, backupDir));
                }
            }
            else if (existingOnDisk.Count > 0 && existingOnDisk.Count < ep.FlowTakes.Count)
            {
                string existingLabels = string.Join(", ", existingOnDisk.OrderBy(n => n).Select(n => string.Format("Take_{0:00}", n)));
                _log(string.Format("[Inspeção de Takes] {0}/{1} takes já existem na pasta 'takes' ({2}) -> preservando cenas prontas e processando apenas os {3} ausentes!",
                    existingOnDisk.Count, ep.FlowTakes.Count, existingLabels, ep.FlowTakes.Count - existingOnDisk.Count));
            }
            else if (existingOnDisk.Count >= ep.FlowTakes.Count)
            {
                _log(string.Format("[Inspeção de Takes] Todos os {0} takes já estão prontos em '{1}'! Pulando geração de vídeo.", ep.FlowTakes.Count, ep.TakesDir));
                EpisodeParser.RefreshDiskCounters(ep);
                return;
            }

            // Se o Grok estiver sem créditos (ou desmarcado) e ainda faltarem imagens de personagens/cenários em assets\, gera primeiro no Google Flow!
            if (ep.GrokSpecs != null && ep.GrokSpecs.Count > 0 && (_config.AreAllGrokProfilesMarkedExhausted() || !_config.RunGrok))
            {
                EpisodeParser.SyncRecurringAssetsFromPreviousEpisodes(ep, _log);
                if (_config.PreserveExistingAssets)
                    EpisodeParser.AutoAlignImportedAssetsOnDisk(ep, _log);

                List<GrokAssetSpec> missingGrokSpecs = ep.GrokSpecs.Where(s =>
                {
                    string p = Path.Combine(ep.AssetsDir, s.TargetFileName);
                    return !File.Exists(p) || new FileInfo(p).Length < 4 * 1024;
                }).ToList();

                if (missingGrokSpecs.Count > 0)
                {
                    _log(string.Format("[Google Flow | Imagens 9:16] Detectadas {0} imagem(ns) de personagens/cenários ainda ausentes (Grok sem créditos) -> gerando imagens no Google Flow antes das cenas!",
                        missingGrokSpecs.Count));
                    await GenerateMissingAssetsInFlowAsync(ep, missingGrokSpecs, ct);
                }
            }

            // Regra 6 + Regra 14: Sincronizar assets recorrentes/locais, alinhar nomes e espelhar 100% dos personagens e cenários para Temp\flow_assets
            List<string> allAssetFiles;
            Dictionary<string, string> ingredientToResolvedName;
            PrepareAndResolveEpisodeAssetsForFlow(ep, out allAssetFiles, out ingredientToResolvedName);

            List<FlowTakeSpec> effectiveTakes = EpisodeParser.GetEffectiveTakeSpecsForEpisode(ep);

            // Filtrar apenas os takes que ainda NÃO existem em disco:
            // Todas as cenas pendentes (inclusive com criança) são tentadas 1 a 1 no Google Flow primeiro;
            // somente as que derem erro mesmo após pedir suavização na conversa vão para o Grok Vídeo!
            List<FlowTakeSpec> flowEligibleTakes = new List<FlowTakeSpec>();
            for (int i = 0; i < effectiveTakes.Count; i++)
            {
                FlowTakeSpec t = effectiveTakes[i];
                if (existingOnDisk.Contains(t.TakeNumber))
                    continue;
                flowEligibleTakes.Add(t);
            }

            HashSet<int> skippedAfterFlowRetries = new HashSet<int>();

            if (flowEligibleTakes.Count > 0)
            {
                string sess = await OpenAndPrepareFlowProjectTabAsync(ct);

                // Regra 31: Garantir que o painel lateral do Agente esteja aberto (NUNCA clicar em close y~100)
                await EnsureAgentPanelOpenAsync(sess, ct);
                await Task.Delay(1000, ct);

                // Inspeção antes de iniciar na sessão já aberta: se já existirem takes concluídos deste episódio na tela aberta do Flow, baixa-os primeiro!
                HashSet<int> salvagedInFlow = await TrySalvageCompletedTakesFromCurrentFlowScreenAsync(
                    sess,
                    ep,
                    flowEligibleTakes,
                    existingOnDisk,
                    ct);

                await EnsureAgentPanelOpenAsync(sess, ct);

                if (salvagedInFlow.Count > 0)
                {
                    flowEligibleTakes = flowEligibleTakes
                        .Where(t => !salvagedInFlow.Contains(t.TakeNumber))
                        .ToList();
                }

                if (flowEligibleTakes.Count > 0)
                {
                    await ExecuteOneByOneSceneConversationInFlowAsync(
                        sess,
                        ep,
                        flowEligibleTakes,
                        allAssetFiles,
                        ingredientToResolvedName,
                        skippedAfterFlowRetries,
                        ct);
                }
            }

            // Verifica as cenas do episódio que ainda não possuem arquivo .mp4 válido salvo em disco (deram erro mesmo após suavizar no Flow)
            List<FlowTakeSpec> grokVideoTakes = new List<FlowTakeSpec>();
            for (int i = 0; i < effectiveTakes.Count; i++)
            {
                FlowTakeSpec takeSpec = effectiveTakes[i];
                string expectedMp4 = Path.Combine(ep.TakesDir, string.Format("Take_{0:00}.mp4", takeSpec.TakeNumber));
                bool hasValidMp4 = File.Exists(expectedMp4) && new FileInfo(expectedMp4).Length >= 50 * 1024;
                if (!hasValidMp4)
                {
                    grokVideoTakes.Add(takeSpec);
                }
            }

            if (grokVideoTakes.Count > 0)
            {
                if (!_config.AreAllGrokProfilesMarkedExhausted())
                {
                    string fallbackLabels = string.Join(", ", grokVideoTakes.Select(t => string.Format("Take_{0:00}", t.TakeNumber)));
                    _log(string.Format("[Fallback Flow -> Grok] {0} cena(s) continuaram com erro após pedir suavização na conversa do Flow ({1}) -> gerando vídeo no Grok Imagine!",
                        grokVideoTakes.Count, fallbackLabels));
                    await _grok.GenerateVideoTakesAsync(ep, grokVideoTakes, ingredientToResolvedName, ct);
                }
                else
                {
                    for (int i = 0; i < grokVideoTakes.Count; i++)
                        skippedAfterFlowRetries.Add(grokVideoTakes[i].TakeNumber);
                }
            }

            if (_config.AreAllGrokProfilesMarkedExhausted())
            {
                List<int> stillMissingOnDisk = new List<int>();
                for (int i = 0; i < effectiveTakes.Count; i++)
                {
                    int tn = effectiveTakes[i].TakeNumber;
                    string expectedMp4 = Path.Combine(ep.TakesDir, string.Format("Take_{0:00}.mp4", tn));
                    if (!File.Exists(expectedMp4) || new FileInfo(expectedMp4).Length < 50 * 1024)
                        stillMissingOnDisk.Add(tn);
                }

                if (stillMissingOnDisk.Count > 0)
                {
                    string skippedLabels = string.Join(", ", stillMissingOnDisk.OrderBy(n => n).Select(n => string.Format("Take_{0:00}", n)));
                    _log(string.Format("[Google Flow | Resumo de Cenas Puladas] {0} cena(s) não puderam ser geradas mesmo após suavizar no Flow (e Grok está sem créditos) -> cena(s) pulada(s): {1}. Prosseguindo com o episódio!",
                        stillMissingOnDisk.Count, skippedLabels));
                }
            }

            EpisodeParser.RefreshDiskCounters(ep);
            _log(string.Format("[Vídeo Concluído] Etapa de vídeo finalizada! Takes prontos organizados em '{0}'.", ep.TakesDir));
        }

        public async Task RegenerateSelectedTakesAsync(
            EpisodeWorkItem ep,
            List<int> takeNumbers,
            bool forceGrokVideo,
            CancellationToken ct)
        {
            if (ep == null || takeNumbers == null || takeNumbers.Count == 0)
                return;

            if (!Directory.Exists(ep.TakesDir))
                Directory.CreateDirectory(ep.TakesDir);

            HashSet<int> selectedSet = new HashSet<int>(takeNumbers);
            string backupSubDir = Path.Combine(ep.TakesDir, "_backup_regerados_" + DateTime.Now.ToString("yyyyMMdd_HHmmss"));

            foreach (int tn in selectedSet)
            {
                string existingMp4 = Path.Combine(ep.TakesDir, string.Format("Take_{0:00}.mp4", tn));
                if (File.Exists(existingMp4))
                {
                    if (!Directory.Exists(backupSubDir))
                        Directory.CreateDirectory(backupSubDir);
                    string dst = Path.Combine(backupSubDir, Path.GetFileName(existingMp4));
                    if (File.Exists(dst)) File.Delete(dst);
                    File.Move(existingMp4, dst);
                    _log(string.Format("[Regerar Take] Take_{0:00}.mp4 anterior arquivado em '{1}'.", tn, backupSubDir));
                }
            }

            List<string> allAssetFiles;
            Dictionary<string, string> ingredientToResolvedName;
            PrepareAndResolveEpisodeAssetsForFlow(ep, out allAssetFiles, out ingredientToResolvedName);

            List<FlowTakeSpec> effectiveTakes = EpisodeParser.GetEffectiveTakeSpecsForEpisode(ep)
                .Where(t => selectedSet.Contains(t.TakeNumber))
                .OrderBy(t => t.TakeNumber)
                .ToList();

            if (effectiveTakes.Count == 0)
                return;

            // Logar se houver figurino customizado/automático aplicado nos takes selecionados
            foreach (FlowTakeSpec eff in effectiveTakes)
            {
                string ingList = string.Join(", ", eff.Ingredients);
                _log(string.Format("[Regerar Take] Take_{0:00} | Ingredientes ativos (com figurino): {1}", eff.TakeNumber, ingList));
            }

            if (forceGrokVideo && !_config.AreAllGrokProfilesMarkedExhausted())
            {
                await _grok.GenerateVideoTakesAsync(ep, effectiveTakes, ingredientToResolvedName, ct);
                EpisodeParser.RefreshDiskCounters(ep);
                List<FlowTakeSpec> missingAfterGrok = effectiveTakes.Where(t =>
                {
                    string p = Path.Combine(ep.TakesDir, string.Format("Take_{0:00}.mp4", t.TakeNumber));
                    return !File.Exists(p) || new FileInfo(p).Length < 50 * 1024;
                }).ToList();

                if (missingAfterGrok.Count > 0 && _config.AreAllGrokProfilesMarkedExhausted())
                {
                    _log("[Grok Sem Créditos -> Flow] Contas do Grok sem créditos disponíveis -> regerando take(s) selecionado(s) no Google Flow anexando somente os elementos de cada cena!");
                    await RegenerateSpecificTakesInFlowAsync(ep, missingAfterGrok, allAssetFiles, ingredientToResolvedName, ct);
                }
                else
                {
                    _log(string.Format("[Regerar Take] {0} take(s) regerado(s) com sucesso via Grok Vídeo!", effectiveTakes.Count));
                }
            }
            else
            {
                if (forceGrokVideo && _config.AreAllGrokProfilesMarkedExhausted())
                {
                    _log("[Grok Sem Créditos -> Flow] Todas as contas do Grok estão sem créditos ('LIMITE ATINGIDO') -> regerando take(s) no Google Flow anexando somente os elementos de cada cena!");
                }
                await RegenerateSpecificTakesInFlowAsync(ep, effectiveTakes, allAssetFiles, ingredientToResolvedName, ct);
            }
        }

        private class SingleSceneDispatchOutcome
        {
            public bool StartedCard;
            public bool RefusedWithoutCard;
            public bool BlockedByUnusualActivity;
            public bool PageReloaded;
        }

        private string BuildSingleSceneConversationPrompt(string originalPromptText, FlowTakeSpec spec, bool isSoftenedRetry)
        {
            string body = InjectTakeTagIntoPromptBody(spec.RawPromptBody, spec.TakeNumber);
            if (isSoftenedRetry)
            {
                body = SoftenPromptForSecondAttempt(body);
                body = InjectTakeTagIntoPromptBody(body, spec.TakeNumber);
            }

            // Remove prefixo redundante "Prompt de Vídeo:" caso venha no corpo e normaliza quebras de linha para \n
            body = Regex.Replace(body ?? "", @"^\s*Prompt\s+de\s+V[ií]deo\s*:\s*", "", RegexOptions.IgnoreCase).Trim();
            body = InjectTakeTagIntoPromptBody(body, spec.TakeNumber);

            StringBuilder sb = new StringBuilder();
            if (isSoftenedRetry)
            {
                sb.AppendFormat(
                    "A cena anterior deu erro. Por favor, suavize qualquer termo sensível ou dramático desta cena mantendo os elementos anexados, o sentido, a fala e o estilo visual 3D, e gere este vídeo em proporção 9:16 (mantenha a tag [TAKE_{0:00}] no início do prompt do vídeo, sem escrever texto na imagem):\n\n",
                    spec.TakeNumber);
            }
            else
            {
                sb.AppendFormat(
                    "Gere em vídeo 9:16 esta cena usando os elementos anexados (mantenha a tag [TAKE_{0:00}] no início do prompt do vídeo, sem escrever texto na imagem):\n\n",
                    spec.TakeNumber);
            }

            sb.Append(body);
            return sb.ToString().Replace("\r\n", "\n").Replace("\r", "\n").Trim();
        }

        private async Task WaitForAgentInputUnlockedAsync(string sess, PreSessionGridBaseline baseline, CancellationToken ct)
        {
            DateTime deadline = DateTime.UtcNow.AddSeconds(45);
            while (DateTime.UtcNow < deadline)
            {
                ct.ThrowIfCancellationRequested();
                SessionPollSnapshot snap = await InspectCurrentSessionStateAsync(sess, baseline, ct);
                if (!snap.AgentBusy)
                    return;
                await Task.Delay(900, ct);
            }
        }

        private async Task<SingleSceneDispatchOutcome> WaitForSingleSceneGenerationStartedAsync(
            string sess,
            PreSessionGridBaseline baseline,
            int cardsBefore,
            int vidOptsBefore,
            int bubblesBefore,
            int unusualCountBefore,
            bool hadUnusualAtBottomBefore,
            int takeNumber,
            int sceneIdxOneBased,
            int totalScenes,
            CancellationToken ct)
        {
            SingleSceneDispatchOutcome outcome = new SingleSceneDispatchOutcome();
            DateTime start = DateTime.UtcNow;
            DateTime deadline = start.AddSeconds(110);
            int retryBtnClicks = 0;
            int textOnlyIdlePolls = 0;

            // Aguarda o envio disparar o estado de processamento do Agente antes da 1ª leitura
            await Task.Delay(1800, ct);

            while (DateTime.UtcNow < deadline)
            {
                ct.ThrowIfCancellationRequested();

                string manualReason;
                if (_cdp.ConsumeReloadAndResumeRequest(out manualReason))
                {
                    _log(string.Format("[Recuperação | Histórico] Botão 'Recarregar e Continuar' acionado durante envio do Take_{0:00} ({1}). Recarregando página...",
                        takeNumber, manualReason));
                    await _cdp.ReloadPageAndWaitReadyAsync(sess, 30000, ct);
                    await WaitForFlowPageLoadedAsync(sess, ct);
                    outcome.PageReloaded = true;
                    return outcome;
                }

                SessionPollSnapshot snap = await InspectCurrentSessionStateAsync(sess, baseline, ct);

                bool newCardCreated = (snap.TotalSessionCards > cardsBefore) || (snap.AgentVideoOptionsCount > vidOptsBefore);
                if (newCardCreated && !snap.AgentBusy)
                {
                    outcome.StartedCard = true;
                    _log(string.Format("[Google Flow | Cena {0}/{1}] ▶ Take_{2:00} começou a ser gerada! Passando imediatamente para a próxima cena...",
                        sceneIdxOneBased, totalScenes, takeNumber));
                    return outcome;
                }

                bool freshUnusualTurn = !hadUnusualAtBottomBefore ||
                                        retryBtnClicks > 0 ||
                                        snap.AgentChatBubblesCount > bubblesBefore ||
                                        snap.UnusualActivityCount > unusualCountBefore;

                if (!newCardCreated && !snap.AgentBusy && freshUnusualTurn && (snap.AgentHasRetryButton || snap.AgentHasUnusualActivity))
                {
                    if (snap.AgentHasUnusualActivity)
                    {
                        if (snap.AgentHasRetryButton && retryBtnClicks < 2 && snap.RetryButtonX > 0 && snap.RetryButtonY > 0)
                        {
                            retryBtnClicks++;
                            _log(string.Format("[Google Flow | Cena {0}/{1}] Aviso de 'atividade incomum' no Take_{2:00} -> clicando em 'Tentar de novo' ({3}/2)...",
                                sceneIdxOneBased, totalScenes, takeNumber, retryBtnClicks));
                            await Task.Delay(3500, ct);
                            await _cdp.ClickAtAsync(sess, snap.RetryButtonX, snap.RetryButtonY, ct);
                            await Task.Delay(2200, ct);
                            continue;
                        }

                        outcome.BlockedByUnusualActivity = true;
                        _log("[Google Flow -> Grok] Painel do Agente permaneceu com aviso de 'atividade incomum' -> transferindo cenas restantes para o Grok Vídeo!");
                        return outcome;
                    }
                    else
                    {
                        if (snap.AgentHasRetryButton && retryBtnClicks < 1 && snap.RetryButtonX > 0 && snap.RetryButtonY > 0)
                        {
                            retryBtnClicks++;
                            _log(string.Format("[Google Flow | Cena {0}/{1}] Aviso 'Algo deu errado. Tente de novo.' no Take_{2:00} -> aguardando 4s e clicando em 'Tentar de novo'...",
                                sceneIdxOneBased, totalScenes, takeNumber));
                            await Task.Delay(4000, ct);
                            await _cdp.ClickAtAsync(sess, snap.RetryButtonX, snap.RetryButtonY, ct);
                            await Task.Delay(2500, ct);
                            continue;
                        }

                        outcome.RefusedWithoutCard = true;
                        _log(string.Format("[Google Flow | Cena {0}/{1}] Aviso: Take_{2:00} retornou 'Algo deu errado' nesta tentativa -> será reenviada suavizada na verificação final.",
                            sceneIdxOneBased, totalScenes, takeNumber));
                        return outcome;
                    }
                }

                double elapsedSec = (DateTime.UtcNow - start).TotalSeconds;
                if (!newCardCreated && !snap.AgentBusy && snap.AgentChatBubblesCount > bubblesBefore && elapsedSec >= 6.0)
                {
                    textOnlyIdlePolls++;
                    if (textOnlyIdlePolls >= 3)
                    {
                        outcome.RefusedWithoutCard = true;
                        _log(string.Format("[Google Flow | Cena {0}/{1}] Aviso: Take_{2:00} não iniciou card nesta tentativa -> será suavizada na verificação final da conversa.",
                            sceneIdxOneBased, totalScenes, takeNumber));
                        return outcome;
                    }
                }
                else
                {
                    textOnlyIdlePolls = 0;
                }

                if (!newCardCreated && !snap.AgentBusy && elapsedSec >= 32.0)
                {
                    outcome.RefusedWithoutCard = true;
                    _log(string.Format("[Google Flow | Cena {0}/{1}] Aviso: Take_{2:00} não gerou card após {3:0}s -> será tratada na verificação de erros.",
                        sceneIdxOneBased, totalScenes, takeNumber, elapsedSec));
                    return outcome;
                }

                await _cdp.WaitOrWakeOnReloadSignalAsync(1200, ct);
            }

            outcome.RefusedWithoutCard = true;
            return outcome;
        }

        private async Task<SessionPollSnapshot> WaitForAllDispatchedScenesToSettleAsync(
            string sess,
            PreSessionGridBaseline baseline,
            string stageLabel,
            CancellationToken ct)
        {
            DateTime start = DateTime.UtcNow;
            DateTime deadline = start.AddMinutes(16);
            DateTime lastProgressUtc = DateTime.UtcNow;
            string lastFp = "";
            int consecutiveIdle = 0;
            int retryBtnClicks = 0;

            while (DateTime.UtcNow < deadline)
            {
                ct.ThrowIfCancellationRequested();
                await _cdp.WaitOrWakeOnReloadSignalAsync(5000, ct);

                string manualReason;
                bool manualReload = _cdp.ConsumeReloadAndResumeRequest(out manualReason);

                SessionPollSnapshot snap = await InspectCurrentSessionStateAsync(sess, baseline, ct);

                string fp = string.Format("{0}|{1}|{2}|{3}|{4}|{5}",
                    snap.TotalSessionCards,
                    snap.GeneratingCards,
                    snap.CompletedCards,
                    snap.FailedCards,
                    snap.PctSummary ?? "",
                    snap.AgentBusy);
                if (fp != lastFp)
                {
                    lastFp = fp;
                    lastProgressUtc = DateTime.UtcNow;
                }

                string pctInfo = !string.IsNullOrEmpty(snap.PctSummary) ? string.Format(" [{0}]", snap.PctSummary) : "";
                _log(string.Format("[Google Flow | {0}] Cards na sessão: {1} | Em geração: {2}{3} | Concluídos (100%): {4} | Erros: {5}",
                    stageLabel, snap.TotalSessionCards, snap.GeneratingCards, pctInfo, snap.CompletedCards, snap.FailedCards));

                if (snap.GeneratingCards == 0 && !snap.AgentBusy)
                {
                    if (snap.AgentHasRetryButton && retryBtnClicks < 2 && snap.RetryButtonX > 0 && snap.RetryButtonY > 0)
                    {
                        retryBtnClicks++;
                        await Task.Delay(3500, ct);
                        await _cdp.ClickAtAsync(sess, snap.RetryButtonX, snap.RetryButtonY, ct);
                        await Task.Delay(2200, ct);
                        consecutiveIdle = 0;
                        lastProgressUtc = DateTime.UtcNow;
                        continue;
                    }

                    consecutiveIdle++;
                    if (consecutiveIdle >= 2)
                        return snap;
                }
                else
                {
                    consecutiveIdle = 0;
                }

                double stalledSec = (DateTime.UtcNow - lastProgressUtc).TotalSeconds;
                if (manualReload || stalledSec >= 135)
                {
                    string why = manualReload ? manualReason : string.Format("sem avanço por {0:0}s", stalledSec);
                    _log(string.Format("[Recuperação | Histórico] Travamento detectado em '{0}' ({1}). Recarregando página do Flow...", stageLabel, why));
                    await _cdp.ReloadPageAndWaitReadyAsync(sess, 30000, ct);
                    await WaitForFlowPageLoadedAsync(sess, ct);
                    SessionPollSnapshot reloaded = await InspectCurrentSessionStateAsync(sess, baseline, ct);
                    reloaded.PageReloadedDuringWait = true;
                    return reloaded;
                }
            }

            return await InspectCurrentSessionStateAsync(sess, baseline, ct);
        }

        private async Task<HashSet<int>> InspectAndRemoveSessionErrorCardsAsync(
            string sess,
            PreSessionGridBaseline baseline,
            List<FlowTakeSpec> candidateTakes,
            CancellationToken ct)
        {
            HashSet<int> errorTakeNums = new HashSet<int>();
            int safetyMax = Math.Max(6, (candidateTakes != null ? candidateTakes.Count : 6) + 4);

            for (int iter = 0; iter < safetyMax; iter++)
            {
                ct.ThrowIfCancellationRequested();
                SessionPollSnapshot snap = await InspectCurrentSessionStateAsync(sess, baseline, ct);
                if (snap.FailedCards <= 0 || snap.FailedMountedIndices.Count == 0)
                    break;

                int errIdx = snap.FailedMountedIndices[0];
                int sliceLimit = Math.Max(4, snap.SessionSliceEndIndex);

                bool clickedReuse = await ClickFailedTileActionButtonAsync(sess, errIdx, sliceLimit, false, false, ct);
                if (clickedReuse)
                {
                    await Task.Delay(750, ct);
                    string reusedPrompt = await ReadCurrentFlowTextboxAsync(sess, ct);
                    if (!string.IsNullOrWhiteSpace(reusedPrompt))
                    {
                        int explicitNum = TryExtractExplicitTakeTagNumber(reusedPrompt);
                        int matchedNum = explicitNum > 0
                            ? explicitNum
                            : IdentifyTakeNumberFromPrompt(reusedPrompt, candidateTakes);
                        if (matchedNum > 0)
                            errorTakeNums.Add(matchedNum);
                    }

                    await InsertTextIntoFlowTextboxAsync(sess, "", true, ct);
                    await ClearAttachedPromptChipsAsync(sess, ct);
                }

                bool deleted = await ClickFailedTileActionButtonAsync(sess, errIdx, sliceLimit, true, false, ct);
                await Task.Delay(450, ct);
                if (!deleted && !clickedReuse)
                    break;
            }

            return errorTakeNums;
        }

        private async Task<HashSet<int>> FindUncompletedTakeNumbersInSessionAsync(
            string sess,
            PreSessionGridBaseline baseline,
            List<FlowTakeSpec> targetTakes,
            HashSet<int> knownFailedTakeNums,
            CancellationToken ct)
        {
            HashSet<int> uncompleted = new HashSet<int>();
            if (knownFailedTakeNums != null)
            {
                foreach (int fn in knownFailedTakeNums)
                    uncompleted.Add(fn);
            }

            List<FlowTakeSpec> remainingCandidates = targetTakes
                .Where(t => !uncompleted.Contains(t.TakeNumber))
                .ToList();
            if (remainingCandidates.Count == 0)
                return uncompleted;

            List<SessionCompletedVideoInfo> agentVideos = await CollectSessionVideosFromAgentPanelAsync(sess, baseline, ct);
            List<string> gridAsbIdsOldestFirst = await CollectSessionGridAsbIdsOldestFirstAsync(sess, baseline, ct);
            await EnrichMissingVideoPromptsFromGridTilesAsync(sess, agentVideos, gridAsbIdsOldestFirst, ct);

            List<Tuple<FlowTakeSpec, string>> matchedPlan = BuildChronologicalDownloadPlan(remainingCandidates, agentVideos, gridAsbIdsOldestFirst);
            HashSet<int> matchedTakeNums = new HashSet<int>();
            for (int i = 0; i < matchedPlan.Count; i++)
            {
                if (!string.IsNullOrEmpty(matchedPlan[i].Item2))
                    matchedTakeNums.Add(matchedPlan[i].Item1.TakeNumber);
            }

            for (int i = 0; i < remainingCandidates.Count; i++)
            {
                int tn = remainingCandidates[i].TakeNumber;
                if (!matchedTakeNums.Contains(tn))
                    uncompleted.Add(tn);
            }

            return uncompleted;
        }

        private async Task ExecuteOneByOneSceneConversationInFlowAsync(
            string sess,
            EpisodeWorkItem ep,
            List<FlowTakeSpec> initialTargetTakes,
            List<string> allAssetFiles,
            Dictionary<string, string> ingredientToResolvedName,
            HashSet<int> skippedAfterFlowRetriesOut,
            CancellationToken ct)
        {
            List<FlowTakeSpec> currentTakes = new List<FlowTakeSpec>(initialTargetTakes);
            int reloadRecoveries = 0;

            while (currentTakes.Count > 0 && reloadRecoveries <= 2)
            {
                ct.ThrowIfCancellationRequested();

                await EnsureAgentPanelOpenAsync(sess, ct);
                _log("[Google Flow] Passo 2: Usando a sessão já aberta no painel do Agente...");
                await ScrollAgentPanelToBottomAsync(sess, ct);
                await ClearAttachedPromptChipsAsync(sess, ct);
                string initLeftoverTxt = await ReadCurrentFlowTextboxAsync(sess, ct);
                if (!string.IsNullOrWhiteSpace(initLeftoverTxt))
                {
                    await InsertTextIntoFlowTextboxAsync(sess, "", true, ct);
                    await Task.Delay(250, ct);
                }

                PreSessionGridBaseline gridBaseline = await CapturePreSessionBaselineAsync(sess, ct);

                if (allAssetFiles != null && allAssetFiles.Count > 0)
                {
                    List<string> assetsForTakes = FilterAssetFilesForTakes(allAssetFiles, currentTakes, ingredientToResolvedName);
                    if (assetsForTakes.Count == 0)
                        assetsForTakes = allAssetFiles;

                    _log(string.Format("[Google Flow] Passo 3: Verificando/enviando {0} imagens de personagens e cenários necessárias na biblioteca do Flow...", assetsForTakes.Count));
                    await UploadAssetsToFlowProjectAsync(sess, assetsForTakes, ct);
                }

                HashSet<int> noCardCreatedInPass1 = new HashSet<int>();
                bool pageReloaded = false;
                bool blockedByUnusualActivity = false;

                _log(string.Format("[Google Flow] Passo 4: Iniciando envio sequencial cena a cena ({0} cena(s)) na mesma conversa...", currentTakes.Count));

                for (int i = 0; i < currentTakes.Count; i++)
                {
                    ct.ThrowIfCancellationRequested();
                    FlowTakeSpec spec = currentTakes[i];

                    await WaitForAgentInputUnlockedAsync(sess, gridBaseline, ct);
                    await ClearAttachedPromptChipsAsync(sess, ct);

                    string leftoverTxt = await ReadCurrentFlowTextboxAsync(sess, ct);
                    if (!string.IsNullOrWhiteSpace(leftoverTxt))
                    {
                        await InsertTextIntoFlowTextboxAsync(sess, "", true, ct);
                        await Task.Delay(250, ct);
                    }

                    SessionPollSnapshot preSnap = await InspectCurrentSessionStateAsync(sess, gridBaseline, ct);
                    int cardsBefore = preSnap.TotalSessionCards;
                    int vidOptsBefore = preSnap.AgentVideoOptionsCount;
                    int bubblesBefore = preSnap.AgentChatBubblesCount;
                    int unusualBefore = preSnap.UnusualActivityCount;
                    bool hadUnusualAtBottomBefore = preSnap.AgentHasRetryButton || preSnap.AgentHasUnusualActivity;

                    List<string> sceneIngredients = ResolveStrictIngredientsForSingleTake(spec, allAssetFiles, ingredientToResolvedName);
                    HashSet<string> attachedForScene = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                    if (sceneIngredients.Count > 0)
                    {
                        _log(string.Format("[Google Flow | Cena {0}/{1}] Vinculando os {2} elemento(s) do Take_{3:00}: {4}",
                            i + 1, currentTakes.Count, sceneIngredients.Count, spec.TakeNumber, string.Join(", ", sceneIngredients)));
                        await AttachIngredientsViaMenuAsync(sess, sceneIngredients, attachedForScene, ct);
                        await WaitForAttachedPromptChipsImagesLoadedAsync(sess, ct);
                    }

                    string scenePrompt = BuildSingleSceneConversationPrompt(ep.FlowPromptText, spec, false);
                    await InsertTextIntoFlowTextboxAsync(sess, scenePrompt, false, ct);
                    await Task.Delay(1500, ct);
                    await WaitRandomFlowActionDelayAsync(string.Format("após colar comando do Take_{0:00}", spec.TakeNumber), ct);

                    LastActionHistoryStore.RecordAction(
                        ep,
                        "Google Flow",
                        string.Format("Enviando Cena {0}/{1} (Take_{2:00}) no Google Flow", i + 1, currentTakes.Count, spec.TakeNumber),
                        _config.FlowProfile,
                        sess,
                        _config.FlowProjectUrl,
                        string.Format("Take_{0:00}", spec.TakeNumber),
                        spec.TakeNumber,
                        i + 1,
                        scenePrompt,
                        attachedForScene,
                        "SUBMITTED_SINGLE_SCENE");

                    await ClickStartGenerationAsync(sess, ct);

                    SingleSceneDispatchOutcome dispatchRes = await WaitForSingleSceneGenerationStartedAsync(
                        sess,
                        gridBaseline,
                        cardsBefore,
                        vidOptsBefore,
                        bubblesBefore,
                        unusualBefore,
                        hadUnusualAtBottomBefore,
                        spec.TakeNumber,
                        i + 1,
                        currentTakes.Count,
                        ct);

                    if (dispatchRes.PageReloaded)
                    {
                        pageReloaded = true;
                        break;
                    }
                    if (dispatchRes.BlockedByUnusualActivity)
                    {
                        blockedByUnusualActivity = true;
                        break;
                    }
                    if (dispatchRes.RefusedWithoutCard)
                    {
                        noCardCreatedInPass1.Add(spec.TakeNumber);
                    }
                }

                if (!pageReloaded)
                {
                    _log(string.Format("[Google Flow] Passo 5: Todas as cenas foram enviadas! Aguardando término da renderização para verificar se houve algum erro..."));
                    SessionPollSnapshot settleSnap = await WaitForAllDispatchedScenesToSettleAsync(sess, gridBaseline, "Aguardando Cenas", ct);
                    if (settleSnap.PageReloadedDuringWait)
                        pageReloaded = true;
                }

                if (pageReloaded)
                {
                    await DownloadAllCompletedTakesIn720pAsync(sess, gridBaseline, ep, currentTakes, ct);
                    HashSet<int> diskReady = new HashSet<int>();
                    for (int k = 0; k < currentTakes.Count; k++)
                    {
                        string pMp4 = Path.Combine(ep.TakesDir, string.Format("Take_{0:00}.mp4", currentTakes[k].TakeNumber));
                        if (File.Exists(pMp4) && new FileInfo(pMp4).Length >= 50 * 1024)
                            diskReady.Add(currentTakes[k].TakeNumber);
                    }
                    await TrySalvageCompletedTakesFromCurrentFlowScreenAsync(sess, ep, currentTakes, diskReady, ct);

                    currentTakes = currentTakes.Where(t =>
                    {
                        string pMp4 = Path.Combine(ep.TakesDir, string.Format("Take_{0:00}.mp4", t.TakeNumber));
                        return !File.Exists(pMp4) || new FileInfo(pMp4).Length < 50 * 1024;
                    }).ToList();

                    reloadRecoveries++;
                    continue;
                }

                HashSet<int> stillFailedAfterSoftening = new HashSet<int>();

                if (!blockedByUnusualActivity)
                {
                    // Passo 6: Verificar se houve algum erro e, na MESMA conversa, pedir para suavizar as cenas com erro e tentar novamente
                    HashSet<int> pass1ErrorCardNums = await InspectAndRemoveSessionErrorCardsAsync(sess, gridBaseline, currentTakes, ct);
                    foreach (int n in noCardCreatedInPass1)
                        pass1ErrorCardNums.Add(n);

                    HashSet<int> allFailedInPass1 = await FindUncompletedTakeNumbersInSessionAsync(
                        sess,
                        gridBaseline,
                        currentTakes,
                        pass1ErrorCardNums,
                        ct);

                    List<FlowTakeSpec> failedSpecs = currentTakes
                        .Where(t => allFailedInPass1.Contains(t.TakeNumber))
                        .OrderBy(t => t.TakeNumber)
                        .ToList();

                    if (failedSpecs.Count == 0)
                    {
                        _log("[Google Flow] Passo 6: Verificação concluída — nenhum erro encontrado nas cenas geradas!");
                    }
                    else
                    {
                        string failedLabels = string.Join(", ", failedSpecs.Select(t => string.Format("Take_{0:00}", t.TakeNumber)));
                        _log(string.Format("[Google Flow] Passo 6: Detectada(s) {0} cena(s) com erro ({1}) -> pedindo na conversa para suavizar e tentar novamente...",
                            failedSpecs.Count, failedLabels));

                        for (int f = 0; f < failedSpecs.Count; f++)
                        {
                            ct.ThrowIfCancellationRequested();
                            FlowTakeSpec failedSpec = failedSpecs[f];

                            await WaitForAgentInputUnlockedAsync(sess, gridBaseline, ct);
                            await ClearAttachedPromptChipsAsync(sess, ct);

                            string remTxt = await ReadCurrentFlowTextboxAsync(sess, ct);
                            if (!string.IsNullOrWhiteSpace(remTxt))
                            {
                                await InsertTextIntoFlowTextboxAsync(sess, "", true, ct);
                                await Task.Delay(250, ct);
                            }

                            SessionPollSnapshot retryPreSnap = await InspectCurrentSessionStateAsync(sess, gridBaseline, ct);
                            int cardsBeforeRetry = retryPreSnap.TotalSessionCards;
                            int vidOptsBeforeRetry = retryPreSnap.AgentVideoOptionsCount;
                            int bubblesBeforeRetry = retryPreSnap.AgentChatBubblesCount;
                            int unusualBeforeRetry = retryPreSnap.UnusualActivityCount;
                            bool hadUnusualBeforeRetry = retryPreSnap.AgentHasRetryButton || retryPreSnap.AgentHasUnusualActivity;

                            List<string> retryIngredients = ResolveStrictIngredientsForSingleTake(failedSpec, allAssetFiles, ingredientToResolvedName);
                            HashSet<string> attachedRetry = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                            if (retryIngredients.Count > 0)
                            {
                                _log(string.Format("[Google Flow | Suavizar {0}/{1}] Vinculando os {2} elemento(s) do Take_{3:00}: {4}",
                                    f + 1, failedSpecs.Count, retryIngredients.Count, failedSpec.TakeNumber, string.Join(", ", retryIngredients)));
                                await AttachIngredientsViaMenuAsync(sess, retryIngredients, attachedRetry, ct);
                                await WaitForAttachedPromptChipsImagesLoadedAsync(sess, ct);
                            }

                            string softenPrompt = BuildSingleSceneConversationPrompt(ep.FlowPromptText, failedSpec, true);
                            await InsertTextIntoFlowTextboxAsync(sess, softenPrompt, false, ct);
                            await Task.Delay(1500, ct);
                            await WaitRandomFlowActionDelayAsync(string.Format("após colar comando suavizado do Take_{0:00}", failedSpec.TakeNumber), ct);

                            await ClickStartGenerationAsync(sess, ct);

                            SingleSceneDispatchOutcome retryDispatch = await WaitForSingleSceneGenerationStartedAsync(
                                sess,
                                gridBaseline,
                                cardsBeforeRetry,
                                vidOptsBeforeRetry,
                                bubblesBeforeRetry,
                                unusualBeforeRetry,
                                hadUnusualBeforeRetry,
                                failedSpec.TakeNumber,
                                f + 1,
                                failedSpecs.Count,
                                ct);

                            if (retryDispatch.PageReloaded || retryDispatch.BlockedByUnusualActivity)
                                break;

                            if (retryDispatch.RefusedWithoutCard)
                                stillFailedAfterSoftening.Add(failedSpec.TakeNumber);
                        }

                        await WaitForAllDispatchedScenesToSettleAsync(sess, gridBaseline, "Aguardando Cenas Suavizadas", ct);
                        HashSet<int> pass2ErrorCardNums = await InspectAndRemoveSessionErrorCardsAsync(sess, gridBaseline, failedSpecs, ct);
                        foreach (int errN in pass2ErrorCardNums)
                            stillFailedAfterSoftening.Add(errN);
                    }
                }

                // Passo 7: Baixar em 720p todas as cenas concluídas nesta conversa do Google Flow
                List<FlowTakeSpec> takesCompletedInFlow = currentTakes
                    .Where(t => !stillFailedAfterSoftening.Contains(t.TakeNumber))
                    .ToList();

                if (takesCompletedInFlow.Count > 0)
                {
                    await DownloadAllCompletedTakesIn720pAsync(sess, gridBaseline, ep, takesCompletedInFlow, ct);
                }

                if (skippedAfterFlowRetriesOut != null && _config.AreAllGrokProfilesMarkedExhausted())
                {
                    foreach (int fn in stillFailedAfterSoftening)
                        skippedAfterFlowRetriesOut.Add(fn);
                }

                break;
            }
        }

        private async Task RegenerateSpecificTakesInFlowAsync(
            EpisodeWorkItem ep,
            List<FlowTakeSpec> targetTakes,
            List<string> allAssetFiles,
            Dictionary<string, string> ingredientToResolvedName,
            CancellationToken ct)
        {
            if (targetTakes == null || targetTakes.Count == 0)
                return;

            string sess = await OpenAndPrepareFlowProjectTabAsync(ct);
            await EnsureAgentPanelOpenAsync(sess, ct);
            await Task.Delay(600, ct);

            HashSet<int> skippedTmp = new HashSet<int>();
            await ExecuteOneByOneSceneConversationInFlowAsync(
                sess,
                ep,
                targetTakes,
                allAssetFiles,
                ingredientToResolvedName,
                skippedTmp,
                ct);

            List<FlowTakeSpec> failedAfterFlow = targetTakes.Where(t =>
            {
                string dstMp4 = Path.Combine(ep.TakesDir, string.Format("Take_{0:00}.mp4", t.TakeNumber));
                return !File.Exists(dstMp4) || new FileInfo(dstMp4).Length < 50 * 1024;
            }).ToList();

            if (failedAfterFlow.Count > 0)
            {
                if (!_config.AreAllGrokProfilesMarkedExhausted())
                {
                    string remLabels = string.Join(", ", failedAfterFlow.Select(t => string.Format("Take_{0:00}", t.TakeNumber)));
                    _log(string.Format("[Regerar Cena | Fallback -> Grok] {0} cena(s) continuaram com erro mesmo após pedir suavização na conversa do Flow ({1}) -> regerando no Grok Vídeo!",
                        failedAfterFlow.Count, remLabels));
                    await _grok.GenerateVideoTakesAsync(ep, failedAfterFlow, ingredientToResolvedName, ct);
                }
                else
                {
                    string remLabels = string.Join(", ", failedAfterFlow.Select(t => string.Format("Take_{0:00}", t.TakeNumber)));
                    _log(string.Format("[Regerar Cena | Aviso] {0} cena(s) não puderam ser geradas após suavizar na conversa do Flow ({1}) e o Grok está sem créditos.",
                        failedAfterFlow.Count, remLabels));
                }
            }

            EpisodeParser.RefreshDiskCounters(ep);
        }

        private async Task<string> OpenAndPrepareFlowProjectTabAsync(CancellationToken ct)
        {
            _log(string.Format("[Google Flow] Conectando ao projeto fixo no perfil '{0}'...", _config.FlowProfile));
            string sess = await _cdp.OpenOrAttachProfileTabAsync(_config.FlowProfile, _config.FlowProjectUrl, "flow.google.com", false, ct);

            string targetProjectUuid = "9b576f1d-9b0f-4103-ac8e-123edb00a1f0";
            if (!string.IsNullOrWhiteSpace(_config.FlowProjectUrl))
            {
                Match mUuid = Regex.Match(_config.FlowProjectUrl, @"/project/([a-f0-9\-]+)", RegexOptions.IgnoreCase);
                if (mUuid.Success)
                    targetProjectUuid = mUuid.Groups[1].Value;
            }

            string currentUrl = await _cdp.EvalStringAsync(sess, "location.href || ''", ct);
            if (currentUrl.IndexOf(targetProjectUuid, StringComparison.OrdinalIgnoreCase) < 0)
            {
                _log("[Google Flow] Navegando para o projeto configurado...");
                await _cdp.SendCommandAsync(
                    "Page.navigate",
                    new Dictionary<string, object> { { "url", _config.FlowProjectUrl } },
                    sess,
                    25000,
                    ct);
                await _cdp.WaitForDocumentReadyAsync(sess, 25000, ct);
                await Task.Delay(3500, ct);
            }

            await WaitForFlowPageLoadedAsync(sess, ct);
            return sess;
        }

        private class SessionCompletedImageInfo
        {
            public int ChronologicalOrder;
            public string CardKey;
            public string AsbId;
            public string ImageUrl;
            public string AltPrompt;
        }

        private class ImageSpecMatchCandidate
        {
            public int SpecIndex;
            public int CardIndex;
            public string CardKey;
            public double Score;
        }

        private static string ComputeBytesMd5Hex(byte[] data)
        {
            if (data == null || data.Length == 0) return "";
            using (var md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] hash = md5.ComputeHash(data);
                StringBuilder sb = new StringBuilder(hash.Length * 2);
                for (int i = 0; i < hash.Length; i++)
                    sb.Append(hash[i].ToString("X2"));
                return sb.ToString();
            }
        }

        private static int TryExtractExplicitImageTagIndex(string promptText, int maxCount)
        {
            if (string.IsNullOrWhiteSpace(promptText) || maxCount <= 0)
                return 0;

            MatchCollection mc = Regex.Matches(
                promptText,
                @"\[\s*IMG(?:[_\-\s]*ID)?[_\-\s]*0*(\d{1,3})\s*\]",
                RegexOptions.IgnoreCase);

            if (mc.Count == 1)
            {
                int idx;
                if (int.TryParse(mc[0].Groups[1].Value, out idx) && idx >= 1 && idx <= maxCount)
                    return idx;
            }
            else if (mc.Count > 1)
            {
                // Se a tag estiver logo nos primeiros 40 caracteres do prompt individual da imagem
                Match first = mc[0];
                if (first.Index <= 40)
                {
                    int idx;
                    if (int.TryParse(first.Groups[1].Value, out idx) && idx >= 1 && idx <= maxCount)
                        return idx;
                }
            }
            return 0;
        }

        private static string ExtractDistinctiveImageSpecBody(string rawText)
        {
            if (string.IsNullOrWhiteSpace(rawText))
                return "";

            string s = rawText;
            s = Regex.Replace(s, @"\[\s*IMG[_\-\s]*\d+\s*\]", " ", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"\b\d{2}_(?:Personagem|Cenario)_[A-Za-z0-9_]+\.jpg\b", " ", RegexOptions.IgnoreCase);

            // Remove parênteses de boilerplate de estilo 3D Pixar / CGI para comparar apenas os detalhes únicos de cada personagem/cenário
            s = Regex.Replace(s, @"\(\s*3D\s+Pixar[^)]*\)", " ", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"\(\s*sem\s+pessoas\s+e\s+sem\s+nenhum\s+texto[^)]*\)", " ", RegexOptions.IgnoreCase);

            string norm = EpisodeParser.NormalizeForCompare(s);
            if (string.IsNullOrEmpty(norm))
                return "";

            string[] boilerplatePhrases = new string[]
            {
                "uma imagem de corpo inteiro em estilo animacao 3d pixar disney cartoon vibrante",
                "ambiente 3d vazio em estilo animacao 3d pixar disney cartoon vibrante",
                "visao grande angular em 9 16 de",
                "com estrutura ossea facial adulta bem definida",
                "proporcoes corporais de mulher adulta completa",
                "proporcoes de mulher adulta completa",
                "ombros largos e estatura de homem adulto completo",
                "linhas de expressao adultas naturais",
                "sem rosto ou aparencia de crianca",
                "olhos grandes 3d arredondados e super expressivos",
                "olhos grandes castanhos",
                "iluminacao cinematografica vibrante",
                "iluminacao cinematografica de alto contraste",
                "fundo branco neutro puro proporcao 9 16",
                "sem texto na imagem proporcao 9 16",
                "em cima da cabeca",
                "escrito"
            };

            for (int i = 0; i < boilerplatePhrases.Length; i++)
            {
                norm = norm.Replace(boilerplatePhrases[i], " ");
            }

            norm = Regex.Replace(norm, @"\s+", " ").Trim();
            return norm;
        }

        private static bool PromptLooksLikeCharacterOnly(string normPrompt)
        {
            if (string.IsNullOrEmpty(normPrompt)) return false;
            bool hasChar = Regex.IsMatch(normPrompt, @"\b(corpo inteiro|fundo branco neutro puro|em cima da cabeca|full body|full length|pure white background|neutral white background|white background)\b");
            bool hasScen = Regex.IsMatch(normPrompt, @"\b(ambiente 3d vazio|sem pessoas|no people|without people|empty 3d|empty room|interior view)\b");
            return hasChar && !hasScen;
        }

        private static bool PromptLooksLikeScenarioOnly(string normPrompt)
        {
            if (string.IsNullOrEmpty(normPrompt)) return false;
            bool hasScen = Regex.IsMatch(normPrompt, @"\b(ambiente 3d vazio|sem pessoas|cenario|sala de estar|quarto antigo|sala de jantar|cozinha simples|quartinho da lavanderia|escritorio montado|empty 3d|no people|without people|living room|bedroom|dining room|kitchen|laundry room|utility room|home office)\b");
            bool hasChar = Regex.IsMatch(normPrompt, @"\b(corpo inteiro|fundo branco neutro puro|em cima da cabeca|full body|pure white background|neutral white background|white background)\b");
            return hasScen && !hasChar;
        }

        private static double ComputeBilingualConceptOverlapBonus(string normSpecRaw, string normPrompt)
        {
            if (string.IsNullOrEmpty(normSpecRaw) || string.IsNullOrEmpty(normPrompt))
                return 0.0;

            string[][] conceptGroups = new string[][]
            {
                new string[] { "quarto antigo", "croche", "novelos", "colcha de retalhos", "old bedroom", "crochet", "yarn", "wool", "patchwork quilt", "knitting" },
                new string[] { "sala de jantar", "girassois", "toalha de renda", "cristaleira", "dining room", "sunflowers", "sunflower", "lace tablecloth", "china cabinet" },
                new string[] { "cozinha simples", "fogao", "geladeira", "laranjas", "kitchen", "stove", "refrigerator", "fridge", "oranges" },
                new string[] { "quartinho da lavanderia", "lavanderia", "maquinas de lavar", "tanque de cimento", "laundry", "washing machine", "washing machines", "utility room", "detergent" },
                new string[] { "escritorio montado", "escrivaninha", "monitores", "computador", "cadeira giratoria", "office", "desk", "monitors", "dual monitor", "computer", "swivel chair" },
                new string[] { "sala de estar", "sofa", "porta retrato", "living room", "couch", "photo frame" },
                new string[] { "mae aposentada", "idosa", "cabelos brancos", "coque", "cardiga", "elderly woman", "retired mother", "white hair", "bun", "cardigan", "grandmother" },
                new string[] { "mulher vaidosa", "vestido vermelho", "vinho", "salto alto", "vain woman", "burgundy dress", "wine dress", "red dress", "high heels", "wavy hair" },
                new string[] { "mecanico", "macacao", "graxa", "mechanic", "overalls", "jumpsuit", "grease" },
                new string[] { "diarista", "avental", "uniforme", "maid", "housekeeper", "apron", "cleaning" }
            };

            int matchedGroups = 0;
            int specGroups = 0;
            for (int g = 0; g < conceptGroups.Length; g++)
            {
                string[] terms = conceptGroups[g];
                bool inSpec = false;
                bool inPrompt = false;
                for (int t = 0; t < terms.Length; t++)
                {
                    if (!inSpec && normSpecRaw.IndexOf(terms[t], StringComparison.Ordinal) >= 0)
                        inSpec = true;
                    if (!inPrompt && normPrompt.IndexOf(terms[t], StringComparison.Ordinal) >= 0)
                        inPrompt = true;
                }
                if (inSpec)
                {
                    specGroups++;
                    if (inPrompt)
                        matchedGroups++;
                }
            }

            if (specGroups == 0 || matchedGroups == 0)
                return 0.0;

            return Math.Min(0.55, matchedGroups * 0.36);
        }

        private static double ComputeImageSpecToPromptMatchScore(
            GrokAssetSpec spec,
            int specIndexOneBased,
            int totalSpecsInBatch,
            string candidatePrompt)
        {
            if (spec == null || string.IsNullOrWhiteSpace(candidatePrompt))
                return 0.0;

            int explicitIdx = TryExtractExplicitImageTagIndex(candidatePrompt, totalSpecsInBatch);
            if (explicitIdx > 0)
            {
                return explicitIdx == specIndexOneBased ? 1.0 : 0.02;
            }

            string normPrompt = EpisodeParser.NormalizeForCompare(candidatePrompt);
            if (string.IsNullOrEmpty(normPrompt))
                return 0.0;

            string fileStem = Path.GetFileNameWithoutExtension(spec.TargetFileName ?? "");
            string normStem = EpisodeParser.NormalizeForCompare(fileStem.Replace('_', ' '));
            if (!string.IsNullOrEmpty(fileStem) &&
                candidatePrompt.IndexOf(fileStem, StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return 0.98;
            }

            // Barreira estrita entre Personagem e Cenário (impede que cenário ocupe vaga de personagem e vice-versa!)
            bool promptLooksScenario = PromptLooksLikeScenarioOnly(normPrompt);
            bool promptLooksCharacter = PromptLooksLikeCharacterOnly(normPrompt);

            if (spec.IsScenario && promptLooksCharacter)
                return 0.0;
            if (!spec.IsScenario && promptLooksScenario)
                return 0.0;

            // Extrai o nome próprio do personagem/cenário (ex.: "A Mãe Aposentada", "O Mecânico Com Flores", "Quarto Antigo da Mãe")
            string cleanTitle = Regex.Replace(spec.DisplayTitle ?? "", @"^(Personagem\s*\d+|Cen[aá]rio\s*[A-Z0-9]+)\s*:\s*", "", RegexOptions.IgnoreCase).Trim();
            cleanTitle = Regex.Replace(cleanTitle, @"^em\s+cima\s+da\s+cabe[cç]a\s+", "", RegexOptions.IgnoreCase).Trim();
            string normTitle = EpisodeParser.NormalizeForCompare(cleanTitle);

            double titleBonus = 0.0;
            if (!string.IsNullOrEmpty(normTitle) && normTitle.Length >= 4)
            {
                if (Regex.IsMatch(normPrompt, @"\b" + Regex.Escape(normTitle) + @"\b"))
                {
                    titleBonus = 0.48;
                }
            }

            // Desambiguação entre variantes do mesmo personagem (ex.: "O Mecânico Com Flores" vs "O Mecânico" de mãos vazias)
            string normSpecRaw = EpisodeParser.NormalizeForCompare(spec.RawPromptLine ?? "");
            bool specHasFlowers = Regex.IsMatch(normSpecRaw, @"\b(flores|buque|rosas|ursinho)\b");
            bool promptHasFlowers = Regex.IsMatch(normPrompt, @"\b(flores|buque|rosas|ursinho|bouquet|flowers|roses|teddy)\b");
            bool specHandsEmpty = Regex.IsMatch(normSpecRaw, @"\b(maos livres|maos vazias)\b");
            bool promptHandsEmpty = Regex.IsMatch(normPrompt, @"\b(maos livres|maos vazias|empty hands|free hands)\b");

            if (specHasFlowers != promptHasFlowers && (!spec.IsScenario))
                titleBonus -= 0.42;
            if (specHandsEmpty && promptHandsEmpty)
                titleBonus += 0.25;

            double bilingualBonus = ComputeBilingualConceptOverlapBonus(normSpecRaw, normPrompt);

            string distinctWant = ExtractDistinctiveImageSpecBody(spec.RawPromptLine ?? "");
            string distinctGot = ExtractDistinctiveImageSpecBody(candidatePrompt);
            double bodySim = ComputeContentWordBigramSimilarity(distinctWant, distinctGot);

            double total = (bodySim * 0.65) + titleBonus + bilingualBonus;
            if (!string.IsNullOrEmpty(normStem) && normPrompt.IndexOf(normStem, StringComparison.Ordinal) >= 0)
                total += 0.35;

            return Math.Max(0.0, Math.Min(0.99, total));
        }

        private string BuildUnifiedFlowImagesCommand(
            List<GrokAssetSpec> specs,
            Dictionary<string, string> specToBaseRefName,
            bool soften)
        {
            if (specs == null || specs.Count == 0)
                return "";

            StringBuilder sb = new StringBuilder();
            sb.AppendLine("[INSTRUÇÃO OBRIGATÓRIA DE GERAÇÃO DE IMAGENS 9:16]:");
            sb.AppendLine("Faça cada imagem isolada da lista abaixo em proporção vertical 9:16 (retrato vertical 9:16 — NÃO gere vídeo, gere SOMENTE IMAGENS estáticas).");
            sb.AppendLine("Ao enviar o prompt de cada imagem para a ferramenta de geração (tanto neste lote inicial quanto nos próximos lotes após \"continue\"), mantenha OBRIGATORIAMENTE e literalmente a tag exata [IMG_01], [IMG_02], [IMG_03], etc. e o nome do arquivo (.jpg) no início do prompt de cada imagem gerada. A tag [IMG_XX] é apenas controle interno de identificação — NÃO escreva a tag \"[IMG_XX]\" nem o nome do arquivo \".jpg\" dentro da arte da imagem:");
            sb.AppendLine();

            for (int i = 0; i < specs.Count; i++)
            {
                GrokAssetSpec spec = specs[i];
                string rawPrompt = (spec.RawPromptLine ?? "").Trim();
                if (soften)
                {
                    rawPrompt = SoftenPromptForSecondAttempt(rawPrompt);
                }

                // Garante que cada linha peça explicitamente proporção 9:16
                if (rawPrompt.IndexOf("9:16", StringComparison.OrdinalIgnoreCase) < 0)
                {
                    rawPrompt = rawPrompt.TrimEnd('.') + ", proporção vertical 9:16.";
                }

                string baseRefName;
                if (specToBaseRefName != null &&
                    specToBaseRefName.TryGetValue(spec.TargetFileName, out baseRefName) &&
                    !string.IsNullOrEmpty(baseRefName))
                {
                    sb.AppendFormat(
                        "[IMG_{0:00}] ({1}) [Use a imagem anexada '{2}' como referência obrigatória de identidade para manter EXATAMENTE o mesmo rosto, idade e estrutura corporal, trocando apenas a roupa/figurino] - {3}",
                        i + 1,
                        spec.TargetFileName,
                        baseRefName,
                        rawPrompt);
                }
                else
                {
                    sb.AppendFormat("[IMG_{0:00}] ({1}) - {2}", i + 1, spec.TargetFileName, rawPrompt);
                }
                sb.AppendLine();
                sb.AppendLine();
            }

            return sb.ToString().Trim();
        }

        public async Task GenerateMissingAssetsInFlowAsync(
            EpisodeWorkItem ep,
            List<GrokAssetSpec> specsToGenerate,
            CancellationToken ct)
        {
            if (ep == null || specsToGenerate == null || specsToGenerate.Count == 0)
                return;

            if (!Directory.Exists(ep.AssetsDir))
                Directory.CreateDirectory(ep.AssetsDir);
            if (!Directory.Exists(_config.TempFlowAssetsDir))
                Directory.CreateDirectory(_config.TempFlowAssetsDir);

            // 1. Audita arquivos existentes em assets\ para remover eventuais duplicatas idênticas (MD5 repetido) e registrar hashes já salvos
            HashSet<string> savedMd5Hashes = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            try
            {
                List<string> existingFiles = Directory.GetFiles(ep.AssetsDir, "*.jpg")
                    .OrderBy(f => Path.GetFileName(f), StringComparer.OrdinalIgnoreCase)
                    .ToList();
                Dictionary<string, string> hashToFirstFile = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                for (int i = 0; i < existingFiles.Count; i++)
                {
                    string fPath = existingFiles[i];
                    FileInfo fi = new FileInfo(fPath);
                    if (fi.Length <= 1024) continue;
                    byte[] bytes = File.ReadAllBytes(fPath);
                    string md5 = ComputeBytesMd5Hex(bytes);
                    if (string.IsNullOrEmpty(md5)) continue;

                    string firstFile;
                    if (hashToFirstFile.TryGetValue(md5, out firstFile))
                    {
                        _log(string.Format("[Google Flow | Auditoria de Assets] Removendo imagem duplicada '{0}' (idêntica a '{1}') para regerar o asset correto...",
                            Path.GetFileName(fPath), Path.GetFileName(firstFile)));
                        try { File.Delete(fPath); } catch { }
                    }
                    else
                    {
                        hashToFirstFile[md5] = fPath;
                        savedMd5Hashes.Add(md5);
                    }
                }
            }
            catch { }

            List<GrokAssetSpec> pendingSpecs = specsToGenerate
                .Where(s => s != null && !string.IsNullOrEmpty(s.TargetFileName) &&
                       (!File.Exists(Path.Combine(ep.AssetsDir, s.TargetFileName)) || new FileInfo(Path.Combine(ep.AssetsDir, s.TargetFileName)).Length < 1024))
                .ToList();

            if (pendingSpecs.Count == 0)
                return;

            _log(string.Format("[Google Flow | Imagens 9:16] Iniciando geração em lote único de {0} imagem(ns) pendente(s) no modo Agente do Google Flow (1 única sessão)...", pendingSpecs.Count));

            string sess = await OpenAndPrepareFlowProjectTabAsync(ct);
            await EnsureAgentPanelOpenAsync(sess, ct);
            await ScrollAgentPanelToBottomAsync(sess, ct);

            string stagingDl = Path.Combine(Path.GetTempPath(), "fluxo_img_dl_" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(stagingDl);
            await _cdp.SetDownloadBehaviorAsync(stagingDl, ct);

            try
            {
                // Se houver variantes de figurino cujos personagens-base já existem em disco, envia e anexa na sessão
                Dictionary<string, string> specToBaseRefName = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                List<string> tempBaseRefsToUpload = new List<string>();
                List<string> baseRefNamesToAttach = new List<string>();

                for (int i = 0; i < pendingSpecs.Count; i++)
                {
                    GrokAssetSpec spec = pendingSpecs[i];
                    if (!spec.IsScenario)
                    {
                        string baseRefPath = EpisodeParser.FindExistingBaseCharacterPathForVariantSpec(ep, spec);
                        if (!string.IsNullOrEmpty(baseRefPath) && File.Exists(baseRefPath))
                        {
                            string baseRefName = Path.GetFileName(baseRefPath);
                            specToBaseRefName[spec.TargetFileName] = baseRefName;
                            string tempBaseRef = Path.Combine(_config.TempFlowAssetsDir, baseRefName);
                            try { File.Copy(baseRefPath, tempBaseRef, true); } catch { }
                            if (!tempBaseRefsToUpload.Contains(tempBaseRef, StringComparer.OrdinalIgnoreCase))
                                tempBaseRefsToUpload.Add(tempBaseRef);
                            if (!baseRefNamesToAttach.Contains(baseRefName, StringComparer.OrdinalIgnoreCase))
                                baseRefNamesToAttach.Add(baseRefName);
                        }
                    }
                }

                if (tempBaseRefsToUpload.Count > 0)
                {
                    await UploadAssetsToFlowProjectAsync(sess, tempBaseRefsToUpload, ct);
                }

                HashSet<string> usedCardKeys = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

                // 1ª Passada: Envia TODAS as imagens pendentes em UM ÚNICO COMANDO na sessão do Agente (e envia "continue" se o Agente dividir em lotes)
                await RunFlowImageBatchesInSessionAsync(
                    sess,
                    ep,
                    pendingSpecs,
                    specToBaseRefName,
                    baseRefNamesToAttach,
                    false,
                    usedCardKeys,
                    savedMd5Hashes,
                    stagingDl,
                    ct);

                // Verifica se alguma imagem falhou na 1ª passada para realizar a 2ª tentativa suavizada (na MESMA sessão!)
                List<GrokAssetSpec> failedInFirstPass = pendingSpecs
                    .Where(s => !File.Exists(Path.Combine(ep.AssetsDir, s.TargetFileName)) || new FileInfo(Path.Combine(ep.AssetsDir, s.TargetFileName)).Length < 1024)
                    .ToList();

                if (failedInFirstPass.Count > 0)
                {
                    string failedNames = string.Join(", ", failedInFirstPass.Select(s => s.TargetFileName));
                    _log(string.Format("[Google Flow | Imagens 9:16] {0} imagem(ns) não foram geradas na 1ª tentativa ({1}) -> enviando 2ª tentativa com suavização anti-bloqueio na mesma sessão...",
                        failedInFirstPass.Count, failedNames));

                    await RunFlowImageBatchesInSessionAsync(
                        sess,
                        ep,
                        failedInFirstPass,
                        specToBaseRefName,
                        baseRefNamesToAttach,
                        true,
                        usedCardKeys,
                        savedMd5Hashes,
                        stagingDl,
                        ct);
                }

                // Qualquer imagem que ainda não tenha sido gerada após a 2ª tentativa suavizada é registrada como pulada
                for (int i = 0; i < pendingSpecs.Count; i++)
                {
                    GrokAssetSpec spec = pendingSpecs[i];
                    string dstPath = Path.Combine(ep.AssetsDir, spec.TargetFileName);
                    if (!File.Exists(dstPath) || new FileInfo(dstPath).Length < 1024)
                    {
                        _log(string.Format("[Google Flow | Imagem Pulada] '{0}' não pôde ser gerada após 1ª tentativa e 2ª tentativa suavizada -> pulando imagem e prosseguindo!", spec.TargetFileName));
                    }
                }
            }
            finally
            {
                Task ignoredCleanup = Task.Run(async () =>
                {
                    try { await _cdp.ResetDownloadBehaviorToDefaultAsync(); } catch { }
                    try { Directory.Delete(stagingDl, true); } catch { }
                });
            }
        }

        private async Task RunFlowImageBatchesInSessionAsync(
            string sess,
            EpisodeWorkItem ep,
            List<GrokAssetSpec> specsForPass,
            Dictionary<string, string> specToBaseRefName,
            List<string> baseRefNamesToAttach,
            bool soften,
            HashSet<string> usedCardKeys,
            HashSet<string> savedMd5Hashes,
            string stagingDl,
            CancellationToken ct)
        {
            if (specsForPass == null || specsForPass.Count == 0)
                return;

            await ClearAttachedPromptChipsAsync(sess, ct);
            string curTxt = await ReadCurrentFlowTextboxAsync(sess, ct);
            if (!string.IsNullOrWhiteSpace(curTxt))
            {
                await InsertTextIntoFlowTextboxAsync(sess, "", true, ct);
                await Task.Delay(350, ct);
            }

            if (baseRefNamesToAttach != null && baseRefNamesToAttach.Count > 0)
            {
                bool anySpecNeedsBase = specsForPass.Any(s => specToBaseRefName != null && specToBaseRefName.ContainsKey(s.TargetFileName));
                if (anySpecNeedsBase)
                {
                    HashSet<string> attachedTmp = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                    await AttachIngredientsViaMenuAsync(sess, baseRefNamesToAttach, attachedTmp, ct);
                    await WaitForAttachedPromptChipsImagesLoadedAsync(sess, ct);
                }
            }

            PreSessionGridBaseline passBaseline = await CapturePreSessionBaselineAsync(sess, ct);
            string unifiedCmd = BuildUnifiedFlowImagesCommand(specsForPass, specToBaseRefName, soften);

            _log(string.Format("[Google Flow | Imagens 9:16] Enviando comando único com {0} imagem(ns) ({1})...",
                specsForPass.Count, soften ? "2ª tentativa suavizada" : "1ª tentativa"));

            await InsertTextIntoFlowTextboxAsync(sess, unifiedCmd, false, ct);
            await WaitRandomFlowActionDelayAsync("após colar comando de imagens", ct);

            LastActionHistoryStore.RecordAction(
                ep,
                "Google Flow",
                string.Format("Gerando lote de {0} imagem(ns) 9:16 ({1}) no Google Flow", specsForPass.Count, soften ? "2ª tentativa suavizada" : "1ª tentativa"),
                _config.FlowProfile,
                sess,
                _config.FlowProjectUrl,
                specsForPass[0].TargetFileName,
                0,
                soften ? 2 : 1,
                unifiedCmd,
                baseRefNamesToAttach ?? new List<string>(),
                "SUBMITTED");

            await ClickStartGenerationAsync(sess, ct);

            int batchNumber = 1;
            int maxBatches = Math.Max(2, (int)Math.Ceiling(specsForPass.Count / 3.0) + 2);
            int baselineCardsBeforeSubmit = 0;

            while (batchNumber <= maxBatches)
            {
                ct.ThrowIfCancellationRequested();

                SessionPollSnapshot snap = await WaitForFlowImageBatchToFinishAsync(
                    sess,
                    passBaseline,
                    batchNumber,
                    specsForPass.Count,
                    baselineCardsBeforeSubmit,
                    ct);

                // Coleta e salva imediatamente todas as imagens concluídas até aqui, casando 1:1 com cada GrokAssetSpec
                await CollectAndSaveCompletedSessionImagesAsync(
                    sess,
                    passBaseline,
                    ep,
                    specsForPass,
                    usedCardKeys,
                    savedMd5Hashes,
                    stagingDl,
                    ct);

                if (snap.FailedCards > 0)
                {
                    await ClickFailedTileActionButtonAsync(sess, 0, Math.Max(6, snap.SessionSliceEndIndex), true, false, ct);
                    await Task.Delay(400, ct);
                }

                // Verifica quais índices (1..N) ainda faltam salvar em disco
                List<int> missingOneBasedIndices = new List<int>();
                for (int i = 0; i < specsForPass.Count; i++)
                {
                    string p = Path.Combine(ep.AssetsDir, specsForPass[i].TargetFileName);
                    if (!File.Exists(p) || new FileInfo(p).Length < 1024)
                        missingOneBasedIndices.Add(i + 1);
                }

                if (missingOneBasedIndices.Count == 0)
                {
                    break;
                }

                if (snap.AgentBlockedByUnusualActivity)
                {
                    break;
                }

                int processedCardsTotal = snap.CompletedCards + snap.FailedCards;
                if (processedCardsTotal >= specsForPass.Count || batchNumber >= maxBatches || snap.TotalSessionCards <= baselineCardsBeforeSubmit)
                {
                    break;
                }

                batchNumber++;
                baselineCardsBeforeSubmit = Math.Max(0, snap.TotalSessionCards - snap.FailedCards);

                List<string> nextItemsDesc = new List<string>();
                for (int m = 0; m < Math.Min(5, missingOneBasedIndices.Count); m++)
                {
                    int idx1 = missingOneBasedIndices[m];
                    nextItemsDesc.Add(string.Format("[IMG_{0:00}] ({1})", idx1, specsForPass[idx1 - 1].TargetFileName));
                }

                string continueCmd = string.Format(
                    "continue gerando imediatamente o próximo lote de imagens estáticas verticais em proporção 9:16 na sequência exata da lista ({0}), mantendo obrigatoriamente a tag exata [IMG_XX] e o nome do arquivo (.jpg) no início do prompt de cada imagem gerada (NÃO gere vídeo).",
                    string.Join(", ", nextItemsDesc));

                _log(string.Format("[Google Flow | Imagens 9:16] Avançando para o Lote {0} na mesma sessão ({1}/{2} imagens concluídas)...",
                    batchNumber, specsForPass.Count - missingOneBasedIndices.Count, specsForPass.Count));

                await InsertTextIntoFlowTextboxAsync(sess, continueCmd, false, ct);
                await WaitRandomFlowActionDelayAsync("após colar comando continue", ct);
                await ClickStartGenerationAsync(sess, ct);
            }
        }

        private async Task<SessionPollSnapshot> WaitForFlowImageBatchToFinishAsync(
            string sess,
            PreSessionGridBaseline baseline,
            int batchNumber,
            int totalExpectedImages,
            int baselineCardsBeforeSubmit,
            CancellationToken ct)
        {
            string b64PreIds = Convert.ToBase64String(Encoding.UTF8.GetBytes(string.Join("|", baseline.PreExistingAsbIds.ToArray())));
            string b64PreUrls = Convert.ToBase64String(Encoding.UTF8.GetBytes(string.Join("|", baseline.PreExistingImageUrls.ToArray())));

            DateTime start = DateTime.UtcNow;
            DateTime deadline = start.AddMinutes(8.0);
            DateTime lastProgressUtc = DateTime.UtcNow;
            string lastFp = "";
            int consecutiveIdleAfterCards = 0;
            int consecutiveIdleNoCards = 0;
            int retryBtnClicks = 0;

            int initBubbles = -1;
            string initBubblesStr = await _cdp.EvalStringAsync(sess, @"
(function(){
    var panel = document.querySelector('flow-agent-panel');
    return panel ? String(panel.querySelectorAll('flow-chat-bubble').length) : '-1';
})()", ct);
            int parsedB;
            if (int.TryParse(initBubblesStr, out parsedB) && parsedB >= 0)
                initBubbles = parsedB;

            while (DateTime.UtcNow < deadline)
            {
                ct.ThrowIfCancellationRequested();
                await _cdp.WaitOrWakeOnReloadSignalAsync(4500, ct);

                string manualReloadReason;
                if (_cdp.ConsumeReloadAndResumeRequest(out manualReloadReason))
                {
                    _log(string.Format("[Recuperação Google Flow] Recarregando guia durante Lote {0} de imagens ({1})...", batchNumber, manualReloadReason));
                    await _cdp.ReloadPageAndWaitReadyAsync(sess, 30000, ct);
                    await WaitForFlowPageLoadedAsync(sess, ct);
                    await EnsureAgentPanelOpenAsync(sess, ct);
                    await Task.Delay(1500, ct);
                    lastProgressUtc = DateTime.UtcNow;
                    retryBtnClicks = 0;
                }

                Dictionary<string, object> st = await _cdp.EvalJsonAsync(sess, string.Format(@"
(function(){{
    var rawPreIds = atob('{0}');
    var preIds = new Set(rawPreIds ? rawPreIds.split('|').filter(Boolean) : []);
    var rawPreUrls = atob('{1}');
    var preUrls = new Set(rawPreUrls ? rawPreUrls.split('|').filter(Boolean) : []);

    var vp = document.querySelector('cdk-virtual-scroll-viewport.tiles-container') || document.querySelector('cdk-virtual-scroll-viewport');
    if (vp && vp.scrollTop > 8) vp.scrollTop = 0;

    var allTiles = Array.from(document.querySelectorAll('flow-image-tile, flow-video-tile, flow-asset-tile, [data-asb-id]'));
    var seenKeys = new Set();
    var generating = 0;
    var completed = 0;
    var failed = 0;
    var pctList = [];
    var sliceEnd = 0;

    for (var i = 0; i < allTiles.length; i++) {{
        var el = allTiles[i];
        var host = el.closest('flow-image-tile, flow-video-tile, flow-asset-tile') || el;
        var vid = host.querySelector('video');
        var imgEl = host.querySelector('img.thumbnail') || host.querySelector('img');
        var imgSrc = imgEl ? (imgEl.currentSrc || imgEl.src || imgEl.getAttribute('src') || '') : '';
        var mAsb = imgSrc.match(/\/asb\/([A-Za-z0-9_\-]{{25,80}})/);
        var asb = mAsb ? mAsb[1] : (host.getAttribute('data-asb-id') || '');
        var key = asb || imgSrc || ('idx_' + i);

        if (seenKeys.has(key)) continue;
        seenKeys.add(key);

        if ((asb && preIds.has(asb)) || (imgSrc && preUrls.has(imgSrc))) {{
            break;
        }}
        sliceEnd = i + 1;

        var txt = (host.innerText || '').trim();
        var pctM = txt.match(/\b\d{{1,3}}\s*%/);
        var hasPct = !!pctM;
        var hasMore = !!host.querySelector('button[aria-label*=""Mais op""], button[aria-label*=""More""]');
        var hasErr = !hasPct && !hasMore && !imgSrc && /violar|pol[ií]ticas|falha|erro|n[aã]o foi poss[ií]vel|violate|failed/i.test(txt);

        if (hasPct) {{
            generating++;
            pctList.push(pctM[0]);
        }} else if (hasErr) {{
            failed++;
        }} else if (!vid && (imgSrc.length > 12 || hasMore)) {{
            completed++;
        }}
    }}

    var panel = document.querySelector('flow-agent-panel');
    var bubbles = panel ? panel.querySelectorAll('flow-chat-bubble').length : 0;
    var panelNewImgs = 0;
    var panelBusy = false;
    var hasUnusual = false;
    var retryBtn = null;

    if (panel) {{
        var stopBtn = !!Array.from(panel.querySelectorAll('button')).find(b => {{
            var al = (b.getAttribute('aria-label') || '');
            var t = (b.innerText || '').trim();
            return b.getBoundingClientRect().width > 10 && (al.indexOf('Parar') >= 0 || al.indexOf('Stop') >= 0 || t === 'stop' || t === 'stop_circle');
        }});
        var spinner = !!Array.from(panel.querySelectorAll('mat-progress-spinner, mat-spinner, [role=""progressbar""], .thinking-indicator'))
            .find(s => s.getBoundingClientRect().width > 6);
        panelBusy = stopBtn || spinner;

        var pImgs = Array.from(panel.querySelectorAll('flow-chat-bubble img, flow-image-option img, flow-a2ui-image-option img'));
        var seenP = new Set();
        pImgs.forEach(pim => {{
            if (pim.closest('flow-image-ingredient-chip')) return;
            var s = pim.currentSrc || pim.src || pim.getAttribute('src') || '';
            if (s.length <= 12 || preUrls.has(s)) return;
            var m = s.match(/\/asb\/([A-Za-z0-9_\-]{{25,80}})/);
            var a = m ? m[1] : '';
            if (a && preIds.has(a)) return;
            var k = a || s;
            if (!seenP.has(k)) {{
                seenP.add(k);
                panelNewImgs++;
            }}
        }});

        var chatBubbles = Array.from(panel.querySelectorAll('flow-chat-bubble'));
        var tailBubbles = chatBubbles.slice(Math.max(0, chatBubbles.length - 3));
        for (var bIdx = tailBubbles.length - 1; bIdx >= 0; bIdx--) {{
            var bEl = tailBubbles[bIdx];
            var bTxt = (bEl.innerText || '');
            if (bTxt.indexOf('atividade incomum') >= 0 || bTxt.indexOf('unusual activity') >= 0 || bTxt.indexOf('Tentar de novo') >= 0 || bTxt.indexOf('Try again') >= 0) {{
                var btns = Array.from(bEl.querySelectorAll('button, [role=""button""]')).filter(btn => {{
                    var r = btn.getBoundingClientRect();
                    var t = (btn.innerText || '').trim();
                    return r.width > 20 && r.height > 14 && !btn.disabled && (t.indexOf('Tentar de novo') >= 0 || t.indexOf('Try again') >= 0);
                }});
                if (btns.length > 0) {{
                    hasUnusual = true;
                    var targetBtn = btns[btns.length - 1];
                    targetBtn.scrollIntoView({{ block: 'center', inline: 'nearest' }});
                    var br = targetBtn.getBoundingClientRect();
                    retryBtn = {{ x: Math.round(br.left + br.width / 2), y: Math.round(br.top + br.height / 2) }};
                    break;
                }}
            }}
        }}
    }}

    var effCompleted = Math.max(completed, panelNewImgs);
    return JSON.stringify({{
        generating: generating,
        completed: effCompleted,
        failed: failed,
        sliceEnd: sliceEnd,
        pctSummary: pctList.join(','),
        bubbles: bubbles,
        busy: panelBusy,
        unusual: hasUnusual,
        retryBtn: retryBtn
    }});
}})()", b64PreIds, b64PreUrls), ct);

                SessionPollSnapshot snap = new SessionPollSnapshot();
                if (st == null) continue;

                snap.GeneratingCards = st.ContainsKey("generating") ? Convert.ToInt32(st["generating"]) : 0;
                snap.CompletedCards = st.ContainsKey("completed") ? Convert.ToInt32(st["completed"]) : 0;
                snap.FailedCards = st.ContainsKey("failed") ? Convert.ToInt32(st["failed"]) : 0;
                snap.SessionSliceEndIndex = st.ContainsKey("sliceEnd") ? Convert.ToInt32(st["sliceEnd"]) : 0;
                snap.PctSummary = st.ContainsKey("pctSummary") ? Convert.ToString(st["pctSummary"] ?? "") : "";
                snap.AgentChatBubblesCount = st.ContainsKey("bubbles") ? Convert.ToInt32(st["bubbles"]) : 0;
                snap.AgentBusy = st.ContainsKey("busy") && Convert.ToBoolean(st["busy"]);
                snap.AgentHasUnusualActivity = st.ContainsKey("unusual") && Convert.ToBoolean(st["unusual"]);
                Dictionary<string, object> retryBtn = st.ContainsKey("retryBtn") ? st["retryBtn"] as Dictionary<string, object> : null;
                snap.TotalSessionCards = snap.GeneratingCards + snap.CompletedCards + snap.FailedCards;

                string curFp = string.Format("{0}|{1}|{2}|{3}|{4}|{5}",
                    snap.TotalSessionCards, snap.GeneratingCards, snap.CompletedCards, snap.FailedCards, snap.PctSummary, snap.AgentChatBubblesCount);
                if (curFp != lastFp)
                {
                    lastFp = curFp;
                    lastProgressUtc = DateTime.UtcNow;
                }

                string pctInfo = !string.IsNullOrEmpty(snap.PctSummary) ? string.Format(" [{0}]", snap.PctSummary) : "";
                _log(string.Format("[Google Flow | Imagens 9:16 | Lote {0}] Cards na sessão: {1}/{2} | Em geração: {3}{4} | Concluídas (100%): {5} | Erros: {6}",
                    batchNumber, snap.TotalSessionCards, totalExpectedImages, snap.GeneratingCards, pctInfo, snap.CompletedCards, snap.FailedCards));

                bool newCardsAppeared = snap.TotalSessionCards > baselineCardsBeforeSubmit;
                if (newCardsAppeared && snap.GeneratingCards == 0 && !snap.AgentBusy)
                {
                    consecutiveIdleAfterCards++;
                    if (consecutiveIdleAfterCards >= 2)
                    {
                        return snap;
                    }
                }
                else
                {
                    consecutiveIdleAfterCards = 0;

                    if (!newCardsAppeared && snap.GeneratingCards == 0 && !snap.AgentBusy && snap.AgentHasUnusualActivity)
                    {
                        if (retryBtn != null && retryBtnClicks < 2)
                        {
                            retryBtnClicks++;
                            int rx = Convert.ToInt32(retryBtn["x"]);
                            int ry = Convert.ToInt32(retryBtn["y"]);
                            _log(string.Format("[Google Flow | Imagens 9:16 | Lote {0}] Aviso 'Notamos uma atividade incomum' detectado -> aguardando 4s e clicando em 'Tentar de novo' ({1}/2)...",
                                batchNumber, retryBtnClicks));
                            await Task.Delay(4000, ct);
                            await _cdp.ClickAtAsync(sess, rx, ry, ct);
                            await Task.Delay(3000, ct);
                            lastProgressUtc = DateTime.UtcNow;
                            continue;
                        }
                        else
                        {
                            snap.AgentBlockedByUnusualActivity = true;
                            return snap;
                        }
                    }

                    double elapsedSec = (DateTime.UtcNow - start).TotalSeconds;
                    if (!newCardsAppeared && snap.GeneratingCards == 0 && !snap.AgentBusy &&
                        initBubbles >= 0 && snap.AgentChatBubblesCount > initBubbles && elapsedSec >= 20)
                    {
                        consecutiveIdleNoCards++;
                        if (consecutiveIdleNoCards >= 2)
                            return snap;
                    }
                    else
                    {
                        consecutiveIdleNoCards = 0;
                    }
                }
            }

            return new SessionPollSnapshot();
        }

        private async Task<int> CollectAndSaveCompletedSessionImagesAsync(
            string sess,
            PreSessionGridBaseline baseline,
            EpisodeWorkItem ep,
            List<GrokAssetSpec> specsForPass,
            HashSet<string> usedCardKeys,
            HashSet<string> savedMd5Hashes,
            string stagingDl,
            CancellationToken ct)
        {
            if (specsForPass == null || specsForPass.Count == 0)
                return 0;

            await EnsureAgentPanelOpenAsync(sess, ct);

            // 1. Expande botões "Ver tudo" / "Show all" nas bolhas do painel do Agente para exibir todas as imagens do lote
            for (int expandPass = 0; expandPass < 2; expandPass++)
            {
                string clickedStr = await _cdp.EvalStringAsync(sess, @"
(function(){
    var panel = document.querySelector('flow-agent-panel');
    if (!panel) return '0';
    var btns = Array.from(panel.querySelectorAll('button')).filter(b => {
        var t = ((b.innerText || '') + ' ' + (b.getAttribute('aria-label') || '')).trim();
        if (!t || /racioc[ií]nio|thinking|menos|less/i.test(t)) return false;
        return /\b(ver tudo|ver mais|mostrar tudo|mostrar mais|view all|show all|see all)\b/i.test(t);
    });
    btns.forEach(b => { try { b.click(); } catch(e) {} });
    return String(btns.length);
})()", ct);
                int c;
                if (!int.TryParse(clickedStr, out c) || c <= 0)
                    break;
                await Task.Delay(450, ct);
            }

            string b64PreIds = Convert.ToBase64String(Encoding.UTF8.GetBytes(string.Join("|", baseline.PreExistingAsbIds.ToArray())));
            string b64PreUrls = Convert.ToBase64String(Encoding.UTF8.GetBytes(string.Join("|", baseline.PreExistingImageUrls.ToArray())));

            // 2. Coleta todas as imagens novas da grade principal (em ordem cronológica: mais antiga -> mais recente) enriquecidas pelo painel do Agente
            Dictionary<string, object> raw = await _cdp.EvalJsonAsync(sess, string.Format(@"
(function(){{
    var rawPreIds = atob('{0}');
    var preIds = new Set(rawPreIds ? rawPreIds.split('|').filter(Boolean) : []);
    var rawPreUrls = atob('{1}');
    var preUrls = new Set(rawPreUrls ? rawPreUrls.split('|').filter(Boolean) : []);

    function normUrlKey(asb, u) {{
        if (asb && asb.length > 4) return asb;
        if (!u) return '';
        var clean = u.split('#')[0].split('?')[0];
        clean = clean.replace(/=(?:w|s|h)\d+[^\/]*$/i, '');
        return clean || u;
    }}

    var preNormKeys = new Set();
    preUrls.forEach(u => {{
        var nk = normUrlKey('', u);
        if (nk) preNormKeys.add(nk);
    }});

    function cleanAltText(rawAlt) {{
        var a = (rawAlt || '').trim();
        if (!a) return '';
        if (a.length < 36 && /^(imagem|image|thumbnail|miniatura|gerada|generated|asset|recurso|foto|photo|agente|agent|painel|historico|chat)\b/i.test(a)) {{
            return '';
        }}
        return a;
    }}

    var vp = document.querySelector('cdk-virtual-scroll-viewport.tiles-container') || document.querySelector('cdk-virtual-scroll-viewport');
    if (vp && vp.scrollTop > 8) vp.scrollTop = 0;

    // A) Painel do Agente (já está em ordem cronológica: mais antiga -> mais recente)
    var panelItems = [];
    var seenPanelKeys = new Set();
    var panel = document.querySelector('flow-agent-panel');
    if (panel) {{
        var pImgs = Array.from(panel.querySelectorAll('flow-chat-bubble img, flow-image-option img, flow-a2ui-image-option img'));
        pImgs.forEach(pim => {{
            if (pim.closest('flow-image-ingredient-chip')) return;
            var r = pim.getBoundingClientRect();
            if (r.width > 0 && r.width < 45 && (pim.naturalWidth || 0) < 100) return;
            var s = pim.currentSrc || pim.src || pim.getAttribute('src') || '';
            if (s.length <= 12) return;
            var m = s.match(/\/asb\/([A-Za-z0-9_\-]{{25,80}})/);
            var a = m ? m[1] : '';
            var nk = normUrlKey(a, s);
            if ((a && preIds.has(a)) || preUrls.has(s) || (nk && preNormKeys.has(nk))) return;
            if (!nk || seenPanelKeys.has(nk)) return;
            seenPanelKeys.add(nk);

            var alt = cleanAltText(pim.getAttribute('alt') || pim.getAttribute('aria-label') || '');
            if (!alt) {{
                var hostOpt = pim.closest('flow-a2ui-image-option, flow-image-option');
                if (hostOpt) alt = cleanAltText(hostOpt.getAttribute('aria-label') || '');
            }}
            panelItems.push({{ key: nk, asb: a || '', url: s, alt: alt }});
        }});
    }}

    // B) Grade principal (está em ordem reversa: mais recente no topo -> invertemos para ordem cronológica!)
    var allTiles = Array.from(document.querySelectorAll('flow-image-tile, flow-video-tile, flow-asset-tile, [data-asb-id]'));
    var gridNewOldestFirst = [];
    var seenGridKeys = new Set();

    for (var i = 0; i < allTiles.length; i++) {{
        var el = allTiles[i];
        var host = el.closest('flow-image-tile, flow-video-tile, flow-asset-tile') || el;
        var vid = host.querySelector('video');
        if (vid) continue;
        var imgEl = host.querySelector('img.thumbnail') || host.querySelector('img');
        var imgSrc = imgEl ? (imgEl.currentSrc || imgEl.src || imgEl.getAttribute('src') || '') : '';
        var mAsb = imgSrc.match(/\/asb\/([A-Za-z0-9_\-]{{25,80}})/);
        var asb = mAsb ? mAsb[1] : (host.getAttribute('data-asb-id') || '');
        var nk = normUrlKey(asb, imgSrc);
        if (!nk) continue;
        if (seenGridKeys.has(nk)) continue;
        seenGridKeys.add(nk);

        if ((asb && preIds.has(asb)) || (imgSrc && preUrls.has(imgSrc)) || preNormKeys.has(nk)) {{
            break;
        }}

        var txt = (host.innerText || '').trim();
        if (/\b\d{{1,3}}\s*%/.test(txt)) continue;
        if (!imgSrc || imgSrc.length <= 12) continue;

        var alt = imgEl ? cleanAltText(imgEl.getAttribute('alt') || imgEl.getAttribute('aria-label') || '') : '';
        gridNewOldestFirst.push({{ key: nk, asb: asb || '', url: imgSrc, alt: alt }});
    }}

    gridNewOldestFirst.reverse();

    var finalList = [];
    if (gridNewOldestFirst.length > 0) {{
        var panelByKey = new Map();
        panelItems.forEach(p => panelByKey.set(p.key, p));
        for (var gIdx = 0; gIdx < gridNewOldestFirst.length; gIdx++) {{
            var gItem = gridNewOldestFirst[gIdx];
            if (!gItem.alt) {{
                var pMatch = panelByKey.get(gItem.key);
                if (pMatch && pMatch.alt) {{
                    gItem.alt = pMatch.alt;
                }} else if (panelItems.length === gridNewOldestFirst.length && panelItems[gIdx] && panelItems[gIdx].alt) {{
                    gItem.alt = panelItems[gIdx].alt;
                }}
            }}
            finalList.push(gItem);
        }}
    }} else {{
        finalList = panelItems;
    }}

    var items = finalList.map((it, idx) => {{
        return {{
            idx: idx,
            key: it.key,
            asb: it.asb,
            url: it.url,
            alt: it.alt || ''
        }};
    }});

    return JSON.stringify({{ items: items }});
}})()", b64PreIds, b64PreUrls), ct);

            if (raw == null || !raw.ContainsKey("items"))
                return 0;

            IEnumerable arr = raw["items"] as IEnumerable;
            if (arr == null)
                return 0;

            List<SessionCompletedImageInfo> candidates = new List<SessionCompletedImageInfo>();
            foreach (object elem in arr)
            {
                Dictionary<string, object> d = elem as Dictionary<string, object>;
                if (d == null) continue;
                string key = d.ContainsKey("key") ? Convert.ToString(d["key"] ?? "").Trim() : "";
                string url = d.ContainsKey("url") ? Convert.ToString(d["url"] ?? "").Trim() : "";
                if (string.IsNullOrEmpty(key) || string.IsNullOrEmpty(url)) continue;
                if (usedCardKeys.Contains(key) || usedCardKeys.Contains(url)) continue;

                SessionCompletedImageInfo info = new SessionCompletedImageInfo();
                info.ChronologicalOrder = d.ContainsKey("idx") ? Convert.ToInt32(d["idx"]) : candidates.Count;
                info.CardKey = key;
                info.AsbId = d.ContainsKey("asb") ? Convert.ToString(d["asb"] ?? "").Trim() : "";
                info.ImageUrl = url;
                info.AltPrompt = d.ContainsKey("alt") ? Convert.ToString(d["alt"] ?? "").Trim() : "";
                candidates.Add(info);
            }

            if (candidates.Count == 0)
            {
                _log("[Google Flow | Imagens 9:16] Aviso: Nenhum card de imagem novo foi localizado no DOM após conclusão do lote.");
                return 0;
            }

            _log(string.Format("[Google Flow | Imagens 9:16] {0} imagem(ns) concluída(s) localizada(s) na sessão para download e identificação...", candidates.Count));

            // 3. Se houver mais de 1 spec pendente e algum card não tiver tag explícita [IMG_XX], tenta ler o prompt via botão "Reutilizar comando" (↩) no card da grade!
            if (specsForPass.Count > 1)
            {
                for (int c = 0; c < candidates.Count; c++)
                {
                    ct.ThrowIfCancellationRequested();
                    SessionCompletedImageInfo card = candidates[c];
                    if (TryExtractExplicitImageTagIndex(card.AltPrompt, specsForPass.Count) > 0)
                        continue;

                    string lookupToken = !string.IsNullOrEmpty(card.AsbId) ? card.AsbId : card.ImageUrl;
                    if (string.IsNullOrEmpty(lookupToken))
                        continue;

                    try
                    {
                        Dictionary<string, object> cardCenter = await ScrollToAndLocateTileByAsbIdAsync(sess, lookupToken, ct);
                        if (cardCenter == null) continue;

                        await _cdp.HoverAsync(sess, Convert.ToInt32(cardCenter["x"]), Convert.ToInt32(cardCenter["y"]), ct);
                        await Task.Delay(340, ct);

                        string b64Token = Convert.ToBase64String(Encoding.UTF8.GetBytes(lookupToken));
                        Dictionary<string, object> reusePt = await _cdp.EvalJsonAsync(sess, string.Format(@"
(function(){{
    var want = atob('{0}');
    var tile = Array.from(document.querySelectorAll('flow-image-tile, flow-video-tile, flow-asset-tile, [data-asb-id]')).find(t => {{
        var host = t.closest('flow-image-tile, flow-video-tile, flow-asset-tile') || t;
        var img = host.querySelector('img');
        var u = (img ? ((img.currentSrc || img.src || img.getAttribute('src') || '')) : '') + ' ' + (host.getAttribute('data-asb-id') || '');
        return u.indexOf(want) >= 0;
    }});
    if (!tile) return null;
    var hostTile = tile.closest('flow-image-tile, flow-video-tile, flow-asset-tile') || tile;
    var btn = hostTile.querySelector('button[aria-label*=""Reutilizar""], button[aria-label*=""Reuse""]') ||
              Array.from(hostTile.querySelectorAll('button')).find(b => {{
                  var al = (b.getAttribute('aria-label') || '');
                  var txt = (b.innerText || '').trim();
                  return al.indexOf('Reutilizar') >= 0 || al.indexOf('Reuse') >= 0 || txt === 'undo' || txt === 'replay';
              }});
    if (!btn) return null;
    var r = btn.getBoundingClientRect();
    if (r.width < 4) {{
        btn.click();
        return JSON.stringify({{ clickedNative: true, x: 0, y: 0 }});
    }}
    return JSON.stringify({{ clickedNative: false, x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) }});
}})()", b64Token), ct);

                        if (reusePt != null)
                        {
                            bool clickedNative = reusePt.ContainsKey("clickedNative") && Convert.ToBoolean(reusePt["clickedNative"]);
                            if (!clickedNative)
                            {
                                await _cdp.ClickAtAsync(sess, Convert.ToInt32(reusePt["x"]), Convert.ToInt32(reusePt["y"]), ct);
                            }
                            await Task.Delay(650, ct);
                            string recovered = await ReadCurrentFlowTextboxAsync(sess, ct);
                            if (!string.IsNullOrWhiteSpace(recovered))
                            {
                                card.AltPrompt = recovered;
                                await InsertTextIntoFlowTextboxAsync(sess, "", true, ct);
                            }
                            await ClearAttachedPromptChipsAsync(sess, ct);
                        }
                    }
                    catch (OperationCanceledException) { throw; }
                    catch { }
                }
            }

            // 4. Casamento Global Best-First 1:1 entre os specs ainda não salvos e os cards novos desta sessão
            bool[] specAssigned = new bool[specsForPass.Count];
            for (int s = 0; s < specsForPass.Count; s++)
            {
                string p = Path.Combine(ep.AssetsDir, specsForPass[s].TargetFileName);
                if (File.Exists(p) && new FileInfo(p).Length >= 1024)
                    specAssigned[s] = true;
            }

            SessionCompletedImageInfo[] assignedCardPerSpec = new SessionCompletedImageInfo[specsForPass.Count];
            HashSet<int> usedCandidateIndices = new HashSet<int>();

            List<ImageSpecMatchCandidate> allPairs = new List<ImageSpecMatchCandidate>();
            for (int c = 0; c < candidates.Count; c++)
            {
                SessionCompletedImageInfo card = candidates[c];
                if (string.IsNullOrWhiteSpace(card.AltPrompt))
                    continue;

                for (int s = 0; s < specsForPass.Count; s++)
                {
                    if (specAssigned[s]) continue;
                    double sc = ComputeImageSpecToPromptMatchScore(specsForPass[s], s + 1, specsForPass.Count, card.AltPrompt);
                    if (sc >= 0.24)
                    {
                        ImageSpecMatchCandidate pair = new ImageSpecMatchCandidate();
                        pair.SpecIndex = s;
                        pair.CardIndex = c;
                        pair.CardKey = card.CardKey;
                        pair.Score = sc;
                        allPairs.Add(pair);
                    }
                }
            }

            allPairs.Sort(delegate(ImageSpecMatchCandidate a, ImageSpecMatchCandidate b)
            {
                int cmp = b.Score.CompareTo(a.Score);
                if (cmp != 0) return cmp;
                return a.CardIndex.CompareTo(b.CardIndex);
            });

            for (int p = 0; p < allPairs.Count; p++)
            {
                ImageSpecMatchCandidate pair = allPairs[p];
                if (specAssigned[pair.SpecIndex]) continue;
                if (usedCandidateIndices.Contains(pair.CardIndex)) continue;

                specAssigned[pair.SpecIndex] = true;
                assignedCardPerSpec[pair.SpecIndex] = candidates[pair.CardIndex];
                usedCandidateIndices.Add(pair.CardIndex);
            }

            // 4b. Fallback estritamente cronológico (mais antiga -> mais recente) para TODOS os cards ainda não utilizados
            // (mesmo quando o Agente do Flow traduziu o prompt para inglês ou usou um alt genérico!)
            for (int s = 0; s < specsForPass.Count; s++)
            {
                if (specAssigned[s]) continue;
                GrokAssetSpec spec = specsForPass[s];

                int chosenIdx = -1;
                for (int c = 0; c < candidates.Count; c++)
                {
                    if (usedCandidateIndices.Contains(c)) continue;
                    string normCardPrompt = EpisodeParser.NormalizeForCompare(candidates[c].AltPrompt ?? "");
                    if (spec.IsScenario && PromptLooksLikeCharacterOnly(normCardPrompt))
                        continue;
                    if (!spec.IsScenario && PromptLooksLikeScenarioOnly(normCardPrompt))
                        continue;
                    chosenIdx = c;
                    break;
                }

                if (chosenIdx < 0)
                {
                    for (int c = 0; c < candidates.Count; c++)
                    {
                        if (!usedCandidateIndices.Contains(c))
                        {
                            chosenIdx = c;
                            break;
                        }
                    }
                }

                if (chosenIdx >= 0)
                {
                    specAssigned[s] = true;
                    assignedCardPerSpec[s] = candidates[chosenIdx];
                    usedCandidateIndices.Add(chosenIdx);
                }
            }

            // 5. Baixa e salva cada imagem casada, validando unicidade de hash MD5 para NUNCA repetir a mesma imagem em outra vaga
            int savedNow = 0;
            for (int s = 0; s < specsForPass.Count; s++)
            {
                ct.ThrowIfCancellationRequested();
                SessionCompletedImageInfo chosenCard = assignedCardPerSpec[s];
                if (chosenCard == null) continue;

                GrokAssetSpec spec = specsForPass[s];
                string dstPath = Path.Combine(ep.AssetsDir, spec.TargetFileName);
                if (File.Exists(dstPath) && new FileInfo(dstPath).Length >= 1024)
                    continue;

                bool ok = await DownloadFlowGeneratedImageAsync(
                    sess,
                    chosenCard.ImageUrl,
                    chosenCard.AsbId,
                    dstPath,
                    stagingDl,
                    savedMd5Hashes,
                    ct);
                if (ok && File.Exists(dstPath) && new FileInfo(dstPath).Length >= 1024)
                {
                    usedCardKeys.Add(chosenCard.CardKey);
                    usedCardKeys.Add(chosenCard.ImageUrl);
                    if (!string.IsNullOrEmpty(chosenCard.AsbId))
                        usedCardKeys.Add(chosenCard.AsbId);

                    string tempCopy = Path.Combine(_config.TempFlowAssetsDir, spec.TargetFileName);
                    try { File.Copy(dstPath, tempCopy, true); } catch { }
                    savedNow++;
                    _log(string.Format("[Google Flow | Imagens 9:16] ✔ Imagem identificada e salva com sucesso ({0}/{1}): {2}",
                        s + 1, specsForPass.Count, spec.TargetFileName));
                }
            }

            if (savedNow > 0)
            {
                EpisodeParser.SyncRecurringAssetsFromPreviousEpisodes(ep, _log);
                EpisodeParser.RefreshDiskCounters(ep);
            }

            return savedNow;
        }

        private async Task<bool> DownloadFlowGeneratedImageAsync(
            string sess,
            string readySrc,
            string asbId,
            string dstPath,
            string stagingDl,
            HashSet<string> savedMd5Hashes,
            CancellationToken ct)
        {
            try
            {
                string b64Src = Convert.ToBase64String(Encoding.UTF8.GetBytes(readySrc ?? ""));
                string b64 = await _cdp.EvalStringAsync(sess, string.Format(@"
(async function(){{
    var targetSrc = atob('{0}');
    async function blobToJpegBase64(b) {{
        if (!b || b.size <= 1024) return '';
        try {{
            if (typeof createImageBitmap === 'function') {{
                var bmp = await createImageBitmap(b);
                if (bmp && bmp.width > 64 && bmp.height > 64) {{
                    var c = document.createElement('canvas');
                    c.width = bmp.width;
                    c.height = bmp.height;
                    var ctx = c.getContext('2d');
                    ctx.drawImage(bmp, 0, 0);
                    if (typeof bmp.close === 'function') bmp.close();
                    var jpegUrl = c.toDataURL('image/jpeg', 0.96);
                    var jpegB64 = (jpegUrl || '').split(',')[1] || '';
                    if (jpegB64.length > 1400) return jpegB64;
                }}
            }}
        }} catch(convErr) {{}}
        return await new Promise(res => {{
            var fr = new FileReader();
            fr.onloadend = () => res((fr.result || '').split(',')[1] || '');
            fr.onerror = () => res('');
            fr.readAsDataURL(b);
        }});
    }}

    // 1a. Tenta fetch padrão (compatível com Access-Control-Allow-Origin: * no googleusercontent e blob:)
    try {{
        var r1 = await fetch(targetSrc);
        if (r1.ok) {{
            var b1 = await r1.blob();
            var res1 = await blobToJpegBase64(b1);
            if (res1 && res1.length > 1400) return res1;
        }}
    }} catch(e1) {{}}

    // 1b. Tenta fetch com cookies (credentials: 'include')
    try {{
        var r2 = await fetch(targetSrc, {{ credentials: 'include' }});
        if (r2.ok) {{
            var b2 = await r2.blob();
            var res2 = await blobToJpegBase64(b2);
            if (res2 && res2.length > 1400) return res2;
        }}
    }} catch(e2) {{}}

    // 1c. Tenta extrair via canvas direto da tag <img> no DOM
    try {{
        var imgs = Array.from(document.querySelectorAll('img'));
        var im = imgs.find(x => (x.currentSrc || x.src || '') === targetSrc || (x.src || '').indexOf(targetSrc) >= 0);
        if (im && im.naturalWidth > 64 && im.naturalHeight > 64) {{
            var c2 = document.createElement('canvas');
            c2.width = im.naturalWidth;
            c2.height = im.naturalHeight;
            var ctx2 = c2.getContext('2d');
            ctx2.drawImage(im, 0, 0);
            var dataUrl = c2.toDataURL('image/jpeg', 0.96);
            return (dataUrl || '').split(',')[1] || '';
        }}
    }} catch(e3) {{}}
    return '';
}})()", b64Src), ct);

                byte[] finalBytes = null;
                if (!string.IsNullOrEmpty(b64))
                {
                    byte[] bytes = Convert.FromBase64String(b64);
                    if (bytes != null && bytes.Length > 1024)
                        finalBytes = bytes;
                }

                if (finalBytes == null && !string.IsNullOrEmpty(readySrc) && readySrc.StartsWith("http", StringComparison.OrdinalIgnoreCase))
                {
                    try
                    {
                        using (System.Net.WebClient wc = new System.Net.WebClient())
                        {
                            byte[] data = wc.DownloadData(readySrc);
                            if (data != null && data.Length > 1024)
                                finalBytes = data;
                        }
                    }
                    catch { }
                }

                // Fallback via menu nativo do card ("Mais opções" -> "Fazer o download") caso fetch/WebClient não retornem bytes
                if (finalBytes == null && !string.IsNullOrEmpty(stagingDl))
                {
                    string lookupToken = !string.IsNullOrEmpty(asbId) ? asbId : readySrc;
                    if (!string.IsNullOrEmpty(lookupToken))
                    {
                        try
                        {
                            Dictionary<string, object> cardCenter = await ScrollToAndLocateTileByAsbIdAsync(sess, lookupToken, ct);
                            if (cardCenter != null)
                            {
                                await _cdp.HoverAsync(sess, Convert.ToInt32(cardCenter["x"]), Convert.ToInt32(cardCenter["y"]), ct);
                                await Task.Delay(380, ct);

                                string b64Tok = Convert.ToBase64String(Encoding.UTF8.GetBytes(lookupToken));
                                Dictionary<string, object> morePt = await _cdp.EvalJsonAsync(sess, string.Format(@"
(function(){{
    var want = atob('{0}');
    var tile = Array.from(document.querySelectorAll('flow-image-tile, flow-video-tile, flow-asset-tile, [data-asb-id]')).find(t => {{
        var host = t.closest('flow-image-tile, flow-video-tile, flow-asset-tile') || t;
        var img = host.querySelector('img');
        var u = (img ? ((img.currentSrc || img.src || img.getAttribute('src') || '')) : '') + ' ' + (host.getAttribute('data-asb-id') || '');
        return u.indexOf(want) >= 0;
    }});
    if (!tile) return null;
    var hostTile = tile.closest('flow-image-tile, flow-video-tile, flow-asset-tile') || tile;
    var btn = hostTile.querySelector('button[aria-label*=""Mais op""], button[aria-label*=""More""]');
    if (!btn) return null;
    var r = btn.getBoundingClientRect();
    if (r.width < 4) {{
        btn.click();
        return JSON.stringify({{ clickedNative: true, x: 0, y: 0 }});
    }}
    return JSON.stringify({{ clickedNative: false, x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) }});
}})()", b64Tok), ct);

                                if (morePt != null)
                                {
                                    HashSet<string> beforeFiles = new HashSet<string>(Directory.GetFiles(stagingDl), StringComparer.OrdinalIgnoreCase);
                                    bool clickedNative = morePt.ContainsKey("clickedNative") && Convert.ToBoolean(morePt["clickedNative"]);
                                    if (!clickedNative)
                                        await _cdp.ClickAtAsync(sess, Convert.ToInt32(morePt["x"]), Convert.ToInt32(morePt["y"]), ct);
                                    await Task.Delay(450, ct);

                                    Dictionary<string, object> dlItem = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var items = Array.from(document.querySelectorAll('.cdk-overlay-container [role=""menuitem""]'))
        .filter(el => el.getBoundingClientRect().width > 10);
    var dl = items.find(el => /download|baixar/i.test((el.innerText || '') + ' ' + (el.getAttribute('aria-label') || '')));
    if (!dl) return null;
    var r = dl.getBoundingClientRect();
    return JSON.stringify({ x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) });
})()", ct);

                                    if (dlItem != null)
                                    {
                                        await _cdp.ClickAtAsync(sess, Convert.ToInt32(dlItem["x"]), Convert.ToInt32(dlItem["y"]), ct);
                                        await Task.Delay(500, ct);

                                        // Se abriu submenu de resolução, clica na primeira opção do submenu
                                        Dictionary<string, object> subItem = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var items = Array.from(document.querySelectorAll('.cdk-overlay-container [role=""menuitem""]'))
        .filter(el => el.getBoundingClientRect().width > 10 && /1k|2k|original|alta|baixa|download|png|jpg|jpeg/i.test(el.innerText || ''));
    if (items.length === 0) return null;
    var target = items[items.length - 1];
    var r = target.getBoundingClientRect();
    return JSON.stringify({ x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) });
})()", ct);
                                        if (subItem != null)
                                        {
                                            await _cdp.ClickAtAsync(sess, Convert.ToInt32(subItem["x"]), Convert.ToInt32(subItem["y"]), ct);
                                        }

                                        string downloadedPath = await _cdp.WaitForSingleDownloadAsync(stagingDl, beforeFiles, 1024, 25000, ct);
                                        if (!string.IsNullOrEmpty(downloadedPath) && File.Exists(downloadedPath))
                                        {
                                            byte[] dlBytes = File.ReadAllBytes(downloadedPath);
                                            try { File.Delete(downloadedPath); } catch { }
                                            if (dlBytes != null && dlBytes.Length > 1024)
                                                finalBytes = dlBytes;
                                        }
                                    }
                                    else
                                    {
                                        await _cdp.PressEscapeAsync(sess, ct);
                                    }
                                }
                            }
                        }
                        catch (OperationCanceledException) { throw; }
                        catch { }
                    }
                }

                if (finalBytes != null && finalBytes.Length > 1024)
                {
                    string md5 = ComputeBytesMd5Hex(finalBytes);
                    if (savedMd5Hashes != null && !string.IsNullOrEmpty(md5))
                    {
                        if (savedMd5Hashes.Contains(md5))
                        {
                            _log(string.Format("[Google Flow | Imagens 9:16] Aviso: Imagem ignorada para '{0}' pois possui o mesmo conteúdo (MD5 {1}) de outra imagem já salva.",
                                Path.GetFileName(dstPath), md5.Substring(0, Math.Min(8, md5.Length))));
                            return false;
                        }
                        savedMd5Hashes.Add(md5);
                    }

                    File.WriteAllBytes(dstPath, finalBytes);
                    return true;
                }
                else
                {
                    _log(string.Format("[Google Flow | Imagens 9:16] Aviso: Não foi possível extrair os bytes da imagem para '{0}'.", Path.GetFileName(dstPath)));
                }
            }
            catch (OperationCanceledException)
            {
                throw;
            }
            catch (Exception ex)
            {
                _log(string.Format("[Google Flow | Imagens 9:16] Erro ao baixar '{0}': {1}", Path.GetFileName(dstPath), ex.Message));
            }
            return false;
        }

        private async Task TryGenerateRemainingTakesInFlowWithRetryAndSkipAsync(
            EpisodeWorkItem ep,
            List<FlowTakeSpec> remainingTakes,
            List<string> allAssetFiles,
            Dictionary<string, string> ingredientToResolvedName,
            HashSet<int> skippedTakeNumbersOut,
            CancellationToken ct)
        {
            if (remainingTakes == null || remainingTakes.Count == 0)
                return;

            string sess = await OpenAndPrepareFlowProjectTabAsync(ct);
            await EnsureAgentPanelOpenAsync(sess, ct);
            await ScrollAgentPanelToBottomAsync(sess, ct);

            List<string> neededRemAssets = FilterAssetFilesForTakes(allAssetFiles, remainingTakes, ingredientToResolvedName);
            await UploadAssetsToFlowProjectAsync(sess, neededRemAssets.Count > 0 ? neededRemAssets : allAssetFiles, ct);

            string stagingDl = Path.Combine(Path.GetTempPath(), "fluxo_dl_rem_" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(stagingDl);
            await _cdp.SetDownloadBehaviorAsync(stagingDl, ct);

            try
            {
                for (int i = 0; i < remainingTakes.Count; i++)
                {
                    ct.ThrowIfCancellationRequested();
                    FlowTakeSpec spec = remainingTakes[i];
                    string dstMp4 = Path.Combine(ep.TakesDir, string.Format("Take_{0:00}.mp4", spec.TakeNumber));
                    if (File.Exists(dstMp4) && new FileInfo(dstMp4).Length >= 50 * 1024)
                        continue;

                    bool generated = false;
                    for (int attempt = 1; attempt <= 2; attempt++)
                    {
                        ct.ThrowIfCancellationRequested();

                        await ClearAttachedPromptChipsAsync(sess, ct);
                        string curTxt = await ReadCurrentFlowTextboxAsync(sess, ct);
                        if (!string.IsNullOrWhiteSpace(curTxt))
                        {
                            await InsertTextIntoFlowTextboxAsync(sess, "", true, ct);
                            await Task.Delay(350, ct);
                        }

                        List<string> resolvedTakeIngs = new List<string>();
                        foreach (string rawIng in spec.Ingredients)
                        {
                            string resName;
                            if (!ingredientToResolvedName.TryGetValue(rawIng, out resName))
                                resName = rawIng;
                            if (!resolvedTakeIngs.Contains(resName, StringComparer.OrdinalIgnoreCase))
                                resolvedTakeIngs.Add(resName);
                        }

                        if (resolvedTakeIngs.Count > 0)
                        {
                            HashSet<string> attachedTmp = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                            await AttachIngredientsViaMenuAsync(sess, resolvedTakeIngs, attachedTmp, ct);
                            await WaitForAttachedPromptChipsImagesLoadedAsync(sess, ct);
                        }

                        string singleBlock = BuildFlowPromptForTakes("", new List<FlowTakeSpec> { spec });
                        if (attempt == 2)
                        {
                            singleBlock = SoftenPromptForSecondAttempt(singleBlock);
                        }

                        string singleCmd =
                            "Gere imediatamente em vídeo 9:16 o take abaixo usando os ingredientes anexados. " +
                            "Mantenha obrigatoriamente a tag [TAKE_" + spec.TakeNumber.ToString("00") + "] no início do prompt do vídeo:\n\n" +
                            singleBlock;

                        if (attempt == 1)
                            _log(string.Format("[Google Flow | Sem Créditos Grok] Tentando gerar Take_{0:00} no Google Flow (1ª tentativa)...", spec.TakeNumber));
                        else
                            _log(string.Format("[Google Flow | Sem Créditos Grok] Take_{0:00} falhou na 1ª tentativa -> 2ª tentativa com suavização anti-bloqueio...", spec.TakeNumber));

                        PreSessionGridBaseline singleBase = await CapturePreSessionBaselineAsync(sess, ct);
                        await InsertTextIntoFlowTextboxAsync(sess, singleCmd, false, ct);
                        await WaitRandomFlowActionDelayAsync(string.Format("após colar comando do Take_{0:00}", spec.TakeNumber), ct);
                        await ClickStartGenerationAsync(sess, ct);

                        try
                        {
                            SessionPollSnapshot snap = await WaitForCurrentBatchToFinishAsync(
                                sess,
                                singleBase,
                                92 + attempt,
                                1,
                                0,
                                0,
                                ct);

                            if (snap.CompletedCards > 0)
                            {
                                await DownloadAllCompletedTakesIn720pAsync(sess, singleBase, ep, new List<FlowTakeSpec> { spec }, ct);
                            }
                            else if (snap.FailedCards > 0)
                            {
                                await ClickFailedTileActionButtonAsync(sess, 0, Math.Max(4, snap.SessionSliceEndIndex), true, false, ct);
                                await Task.Delay(400, ct);
                            }
                        }
                        catch (OperationCanceledException)
                        {
                            throw;
                        }
                        catch (Exception ex)
                        {
                            _log(string.Format("[Google Flow | Aviso] Falha ao aguardar tentativa {0} do Take_{1:00} ({2}).", attempt, spec.TakeNumber, ex.Message));
                        }

                        if (File.Exists(dstMp4) && new FileInfo(dstMp4).Length >= 50 * 1024)
                        {
                            generated = true;
                            _log(string.Format("[Google Flow | Sem Créditos Grok] ✔ Take_{0:00}.mp4 gerado e salvo com sucesso no Google Flow!", spec.TakeNumber));
                            break;
                        }
                    }

                    if (!generated)
                    {
                        if (skippedTakeNumbersOut != null)
                            skippedTakeNumbersOut.Add(spec.TakeNumber);
                        _log(string.Format("[Google Flow | Cena Pulada] Take_{0:00} não foi gerado após 1ª tentativa e 2ª tentativa suavizada (e todas as contas Grok estão sem créditos) -> pulando cena e continuando!", spec.TakeNumber));
                    }
                }
            }
            finally
            {
                Task ignoredCleanup = Task.Run(async () =>
                {
                    try { await _cdp.ResetDownloadBehaviorToDefaultAsync(); } catch { }
                    try { Directory.Delete(stagingDl, true); } catch { }
                });
            }
        }

        private void PrepareAndResolveEpisodeAssetsForFlow(
            EpisodeWorkItem ep,
            out List<string> allTempAssetPaths,
            out Dictionary<string, string> ingredientToResolvedName)
        {
            allTempAssetPaths = new List<string>();
            ingredientToResolvedName = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

            EpisodeParser.SyncRecurringAssetsFromPreviousEpisodes(ep, _log);
            EpisodeParser.AutoAlignImportedAssetsOnDisk(ep, _log);

            if (!Directory.Exists(_config.TempFlowAssetsDir))
                Directory.CreateDirectory(_config.TempFlowAssetsDir);

            List<string> diskAssets = new List<string>();
            if (Directory.Exists(ep.AssetsDir))
            {
                diskAssets = Directory.GetFiles(ep.AssetsDir)
                    .Where(f => Regex.IsMatch(Path.GetExtension(f), @"^\.(jpg|jpeg|png)$", RegexOptions.IgnoreCase) && new FileInfo(f).Length > 1024)
                    .OrderBy(f => Path.GetFileName(f))
                    .ToList();
            }

            HashSet<string> addedTempPaths = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            HashSet<string> mappedDiskSources = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            // 1. Espelha 100% dos arquivos de imagem presentes na pasta assets\ do episódio
            foreach (string srcPath in diskAssets)
            {
                string fn = Path.GetFileName(srcPath);
                string dstTemp = Path.Combine(_config.TempFlowAssetsDir, fn);
                File.Copy(srcPath, dstTemp, true);
            }

            // 2. Resolve 100% dos ingredientes exigidos em prompt_flow_passo3.txt (incluindo mapeamento por similaridade quando o nome no prompt difere do disco)
            foreach (string reqIng in ep.AllRequiredFlowIngredients)
            {
                string exactDisk = diskAssets.FirstOrDefault(f =>
                    string.Equals(Path.GetFileName(f), reqIng, StringComparison.OrdinalIgnoreCase));

                if (!string.IsNullOrEmpty(exactDisk))
                {
                    mappedDiskSources.Add(exactDisk);
                    string actualName = Path.GetFileName(exactDisk);
                    string tempPath = Path.Combine(_config.TempFlowAssetsDir, actualName);
                    ingredientToResolvedName[reqIng] = actualName;
                    if (addedTempPaths.Add(tempPath))
                        allTempAssetPaths.Add(tempPath);
                }
                else
                {
                    string fuzzyDisk = EpisodeParser.FindMatchingDiskAssetFile(reqIng, diskAssets);
                    if (!string.IsNullOrEmpty(fuzzyDisk))
                    {
                        mappedDiskSources.Add(fuzzyDisk);
                        // Cria cópia com o nome exato esperado pelo prompt_flow_passo3.txt em Temp\flow_assets
                        string aliasTempPath = Path.Combine(_config.TempFlowAssetsDir, reqIng);
                        File.Copy(fuzzyDisk, aliasTempPath, true);
                        ingredientToResolvedName[reqIng] = reqIng;
                        if (addedTempPaths.Add(aliasTempPath))
                            allTempAssetPaths.Add(aliasTempPath);

                        _log(string.Format("[Google Flow | Assets] Mapeado asset equivalente do disco '{0}' -> '{1}'",
                            Path.GetFileName(fuzzyDisk), reqIng));
                    }
                    else
                    {
                        // Tenta verificar se já existe em Temp\flow_assets de execução anterior
                        string fallbackTemp = Path.Combine(_config.TempFlowAssetsDir, reqIng);
                        if (File.Exists(fallbackTemp) && new FileInfo(fallbackTemp).Length > 1024)
                        {
                            ingredientToResolvedName[reqIng] = reqIng;
                            if (addedTempPaths.Add(fallbackTemp))
                                allTempAssetPaths.Add(fallbackTemp);
                        }
                        else
                        {
                            _log(string.Format("[Google Flow | Aviso] Ingrediente '{0}' citado no roteiro não foi encontrado em '{1}'.",
                                reqIng, ep.AssetsDir));
                        }
                    }
                }
            }

            // 3. Inclui também quaisquer outros personagens e cenários presentes em ep.AssetsDir que ainda não tenham sido mapeados (garantindo que NENHUM personagem ou cenário da pasta fique de fora sem duplicar aliases)
            foreach (string srcPath in diskAssets)
            {
                if (mappedDiskSources.Contains(srcPath)) continue;
                string fn = Path.GetFileName(srcPath);
                string tempPath = Path.Combine(_config.TempFlowAssetsDir, fn);
                if (addedTempPaths.Add(tempPath))
                {
                    allTempAssetPaths.Add(tempPath);
                }
            }
        }

        private List<string> GetRequiredIngredientsForRange(
            List<FlowTakeSpec> targetTakes,
            Dictionary<string, string> ingredientToResolvedName,
            int startTakeIndex,
            int count)
        {
            List<string> list = new List<string>();
            HashSet<string> seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            int end = Math.Min(targetTakes.Count, startTakeIndex + count);
            for (int i = Math.Max(0, startTakeIndex); i < end; i++)
            {
                foreach (string rawIng in targetTakes[i].Ingredients)
                {
                    string resolved;
                    if (!ingredientToResolvedName.TryGetValue(rawIng, out resolved))
                        resolved = rawIng;

                    if (seen.Add(resolved))
                        list.Add(resolved);
                }
            }
            return list;
        }

        private List<string> ResolveStrictIngredientsForSingleTake(
            FlowTakeSpec spec,
            List<string> allTempAssetPaths,
            Dictionary<string, string> ingredientToResolvedName)
        {
            List<string> result = new List<string>();
            if (spec == null || spec.Ingredients == null || spec.Ingredients.Count == 0)
                return result;

            HashSet<string> availableSet = new HashSet<string>(
                (allTempAssetPaths ?? new List<string>()).Select(Path.GetFileName),
                StringComparer.OrdinalIgnoreCase);
            HashSet<string> seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            // Personagens da cena primeiro, depois cenários da cena
            for (int pass = 0; pass < 2; pass++)
            {
                for (int i = 0; i < spec.Ingredients.Count; i++)
                {
                    string rawIng = spec.Ingredients[i];
                    string resolved;
                    if (ingredientToResolvedName == null || !ingredientToResolvedName.TryGetValue(rawIng, out resolved) || string.IsNullOrEmpty(resolved))
                        resolved = rawIng;

                    if (availableSet.Count > 0 && !availableSet.Contains(resolved))
                        continue;

                    bool isScenario = EpisodeParser.IsScenarioAssetName(resolved);
                    if ((pass == 0 && !isScenario) || (pass == 1 && isScenario))
                    {
                        if (seen.Add(resolved))
                            result.Add(resolved);
                    }
                }
            }

            return result;
        }

        private List<string> FilterAssetFilesForTakes(
            List<string> allTempAssetPaths,
            List<FlowTakeSpec> targetTakes,
            Dictionary<string, string> ingredientToResolvedName)
        {
            List<string> filtered = new List<string>();
            if (allTempAssetPaths == null || allTempAssetPaths.Count == 0 || targetTakes == null || targetTakes.Count == 0)
                return filtered;

            List<string> reqNames = GetRequiredIngredientsForRange(targetTakes, ingredientToResolvedName ?? new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase), 0, targetTakes.Count);
            HashSet<string> reqSet = new HashSet<string>(reqNames, StringComparer.OrdinalIgnoreCase);

            for (int i = 0; i < allTempAssetPaths.Count; i++)
            {
                string p = allTempAssetPaths[i];
                string fn = Path.GetFileName(p);
                if (reqSet.Contains(fn))
                    filtered.Add(p);
            }

            return filtered;
        }

        private List<string> BuildOrderedIngredientsForEpisode(
            EpisodeWorkItem ep,
            List<FlowTakeSpec> targetTakes,
            List<string> allTempAssetPaths,
            Dictionary<string, string> ingredientToResolvedName,
            int startTakeIndex,
            int batchSize)
        {
            List<string> ordered = new List<string>();
            HashSet<string> seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            List<string> allAvailableNames = allTempAssetPaths.Select(Path.GetFileName).ToList();
            HashSet<string> availableSet = new HashSet<string>(allAvailableNames, StringComparer.OrdinalIgnoreCase);

            // Considera EXCLUSIVAMENTE os elementos usados nos takes que realmente serão gerados (targetTakes),
            // para que ao regerar/retomar 1 cena (ou um subconjunto de cenas) nunca sejam anexados elementos de cenas já concluídas!
            List<string> allTargetRequired = GetRequiredIngredientsForRange(targetTakes, ingredientToResolvedName, 0, targetTakes.Count);
            if (allTargetRequired.Count == 0 && targetTakes.Count >= ep.FlowTakes.Count)
            {
                allTargetRequired = new List<string>(ep.AllRequiredFlowIngredients);
            }

            // 1. Personagens efetivamente usados nos takes alvo
            foreach (string resolved in allTargetRequired)
            {
                if (!availableSet.Contains(resolved)) continue;
                if (!EpisodeParser.IsScenarioAssetName(resolved) && seen.Add(resolved))
                    ordered.Add(resolved);
            }

            // 2. Cenários (e ingredientes) dos primeiros takes do lote atual
            foreach (string batchIng in GetRequiredIngredientsForRange(targetTakes, ingredientToResolvedName, startTakeIndex, batchSize))
            {
                if (availableSet.Contains(batchIng) && seen.Add(batchIng))
                    ordered.Add(batchIng);
            }

            // 3. Demais cenários exigidos nos demais takes alvo desta execução (apenas se houver múltiplos lotes)
            foreach (string resolved in allTargetRequired)
            {
                if (availableSet.Contains(resolved) && seen.Add(resolved))
                    ordered.Add(resolved);
            }

            return ordered;
        }

        private List<string> BuildSupplementIngredientsForBatch(
            List<string> allTempAssetPaths,
            List<string> nextBatchRequired,
            HashSet<string> alreadyAttachedInSession)
        {
            List<string> ordered = new List<string>();
            HashSet<string> seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            HashSet<string> availableSet = new HashSet<string>(
                (allTempAssetPaths ?? new List<string>()).Select(Path.GetFileName),
                StringComparer.OrdinalIgnoreCase);

            // 1. Ingredientes inéditos obrigatórios neste lote que ainda não entraram na sessão
            foreach (string req in nextBatchRequired)
            {
                if (availableSet.Contains(req) && !alreadyAttachedInSession.Contains(req) && seen.Add(req))
                    ordered.Add(req);
            }

            // 2. Todos os elementos efetivamente usados neste lote (personagens + cenários do lote)
            foreach (string req in nextBatchRequired)
            {
                if (availableSet.Contains(req) && seen.Add(req))
                    ordered.Add(req);
            }

            return ordered;
        }

        private async Task EnsureAgentPanelOpenAsync(string sess, CancellationToken ct)
        {
            for (int attempt = 0; attempt < 4; attempt++)
            {
                ct.ThrowIfCancellationRequested();
                Dictionary<string, object> state = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var newSess = Array.from(document.querySelectorAll('button')).find(b => {
        var al = (b.getAttribute('aria-label') || '').toLowerCase();
        var txt = (b.innerText || '').trim().toLowerCase();
        var r = b.getBoundingClientRect();
        return r.width > 10 && r.height > 10 &&
               (al.indexOf('nova sess') >= 0 || al.indexOf('new session') >= 0 || txt === 'edit_square' || txt.indexOf('edit_square') >= 0);
    });
    if (newSess) return JSON.stringify({ step: 'OPEN' });

    var expBtn = Array.from(document.querySelectorAll('button')).find(x => {
        var al = (x.getAttribute('aria-label') || '').toLowerCase();
        var txt = (x.innerText || '').trim().toLowerCase();
        var r = x.getBoundingClientRect();
        return r.width > 10 && r.height > 10 &&
               (al === 'abrir' || al === 'expandir' || al === 'open' || al === 'expand' || txt.indexOf('expand_content') >= 0);
    });
    if (expBtn) {
        var re = expBtn.getBoundingClientRect();
        return JSON.stringify({ step: 'CLICK_EXPAND', x: Math.round(re.left + re.width/2), y: Math.round(re.top + re.height/2) });
    }

    var agBtn = document.querySelector('button.agent-mode-chip') ||
        Array.from(document.querySelectorAll('button')).find(b => {
            var al = (b.getAttribute('aria-label') || '');
            var txt = (b.innerText || '');
            var r = b.getBoundingClientRect();
            return r.width > 10 && r.height > 10 && (txt.indexOf('Agente') >= 0 || al.indexOf('Agente') >= 0 || txt.indexOf('Agent') >= 0);
        });
    if (agBtn) {
        var r = agBtn.getBoundingClientRect();
        var isChecked = agBtn.getAttribute('aria-pressed') === 'true' ||
                        ((agBtn.className || '').toString().indexOf('agent-mode-chip-checked') >= 0);
        if (!isChecked) {
            return JSON.stringify({ step: 'CLICK_AGENTE', x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) });
        }
        return JSON.stringify({ step: 'WAIT_EXPAND' });
    }
    return JSON.stringify({ step: 'OPEN' });
})()", ct);

                if (state == null) return;
                string step = Convert.ToString(state.ContainsKey("step") ? state["step"] : "OPEN");
                if (step == "OPEN")
                    return;

                if (step == "CLICK_AGENTE")
                {
                    if (attempt == 0)
                        _log("[Google Flow] Regra 31: Ativando modo Agente na barra de comando...");
                    await _cdp.ClickAtAsync(sess, Convert.ToInt32(state["x"]), Convert.ToInt32(state["y"]), ct);
                    await Task.Delay(850, ct);
                    continue;
                }

                if (step == "CLICK_EXPAND")
                {
                    _log("[Google Flow] Regra 31: Expandindo painel lateral do Agente ('Abrir' / expand_content)...");
                    await _cdp.ClickAtAsync(sess, Convert.ToInt32(state["x"]), Convert.ToInt32(state["y"]), ct);
                    await Task.Delay(1100, ct);
                    continue;
                }

                await Task.Delay(600, ct);
            }
        }

        private async Task ClickNewAgentSessionAsync(string sess, CancellationToken ct)
        {
            await EnsureAgentPanelOpenAsync(sess, ct);

            // Regra 25: NUNCA chamar scrollIntoView() em botões fixos do Google Flow!
            string findNewSessJs = @"
(function(){
    var b = Array.from(document.querySelectorAll('button')).find(x => {
        var al = ((x.getAttribute('aria-label') || '') + ' ' + (x.getAttribute('title') || '') + ' ' + (x.getAttribute('mattooltip') || '')).toLowerCase();
        var txt = (x.innerText || '').trim().toLowerCase();
        var r = x.getBoundingClientRect();
        return r.width > 10 && r.height > 10 &&
               (al.indexOf('nova sess') >= 0 || al.indexOf('new session') >= 0 || al.indexOf('novo chat') >= 0 ||
                txt === 'edit_square' || txt.indexOf('edit_square') >= 0 || txt === 'add_comment');
    });
    if (b) {
        var r = b.getBoundingClientRect();
        return JSON.stringify({ x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2), alreadyEmpty: false });
    }
    var panel = document.querySelector('flow-agent-panel');
    var tb = document.querySelector('[role=""textbox""][contenteditable=""true""], textarea');
    if (tb) {
        var tr = tb.getBoundingClientRect();
        var bubbles = panel ? panel.querySelectorAll('flow-chat-bubble').length : 0;
        if (tr.width > 30 && tr.height > 10 && bubbles === 0) {
            return JSON.stringify({ x: 0, y: 0, alreadyEmpty: true });
        }
    }
    return null;
})()";

            Dictionary<string, object> pt = await _cdp.EvalJsonAsync(sess, findNewSessJs, ct);
            if (pt == null)
            {
                await EnsureAgentPanelOpenAsync(sess, ct);
                await Task.Delay(900, ct);
                pt = await _cdp.EvalJsonAsync(sess, findNewSessJs, ct);
            }

            if (pt == null)
                throw new InvalidOperationException("Botão 'Nova sessão' (edit_square) não encontrado no painel do Agente do Google Flow.");

            if (pt.ContainsKey("alreadyEmpty") && Convert.ToBoolean(pt["alreadyEmpty"]))
            {
                _log("[Google Flow] Painel do Agente já está em uma sessão nova e vazia.");
                return;
            }

            await _cdp.ClickAtAsync(sess, Convert.ToInt32(pt["x"]), Convert.ToInt32(pt["y"]), ct);
        }

        private class PreSessionGridBaseline
        {
            public HashSet<string> PreExistingAsbIds;
            public HashSet<string> PreExistingImageUrls;
            public int PreExistingTopFailedCount;
            public int PreExistingChatBubblesCount;
            public int PreExistingAgentVideoOptionsCount;

            public PreSessionGridBaseline()
            {
                PreExistingAsbIds = new HashSet<string>(StringComparer.Ordinal);
                PreExistingImageUrls = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                PreExistingTopFailedCount = 0;
                PreExistingChatBubblesCount = 0;
                PreExistingAgentVideoOptionsCount = 0;
            }
        }

        private class MountedGridTileState
        {
            public int MountedIndex;
            public string AsbId;
            public bool HasPct;
            public string PctText;
            public bool HasVideo;
            public bool HasMoreBtn;
            public bool HasErr;
            public bool IsMinorErr;
        }

        private class SessionPollSnapshot
        {
            public int TotalSessionCards;
            public int GeneratingCards;
            public int CompletedCards;
            public int FailedCards;
            public int SessionSliceEndIndex;
            public int AgentVideoOptionsCount;
            public int AgentChatBubblesCount;
            public int UnusualActivityCount;
            public bool AgentBusy;
            public bool AgentHasRetryButton;
            public int RetryButtonX;
            public int RetryButtonY;
            public bool AgentHasUnusualActivity;
            public bool AgentBlockedByUnusualActivity;
            public bool PageReloadedDuringWait;
            public string PctSummary;
            public List<int> FailedMountedIndices;
            public List<int> MinorFailedMountedIndices;

            public SessionPollSnapshot()
            {
                PctSummary = "";
                FailedMountedIndices = new List<int>();
                MinorFailedMountedIndices = new List<int>();
            }
        }

        private class SessionCompletedVideoInfo
        {
            public int ChronologicalOrder;
            public string AsbId;
            public string AltPrompt;
        }

        private async Task ScrollAgentPanelToBottomAsync(string sess, CancellationToken ct)
        {
            await _cdp.EvalStringAsync(sess, @"
(function(){
    var panel = document.querySelector('flow-agent-panel');
    if (!panel) return 'NO_PANEL';
    var scroller = panel.querySelector('.scroll-viewport') ||
                   Array.from(panel.querySelectorAll('div')).find(el => el.scrollHeight > el.clientHeight + 40);
    if (scroller) scroller.scrollTop = scroller.scrollHeight;
    return 'OK';
})()", ct);
            await Task.Delay(250, ct);
        }

        private async Task WaitForFlowPageLoadedAsync(string sess, CancellationToken ct)
        {
            DateTime deadline = DateTime.UtcNow.AddSeconds(30);
            while (DateTime.UtcNow < deadline)
            {
                ct.ThrowIfCancellationRequested();
                string st = await _cdp.EvalStringAsync(sess, @"
(function(){
    var hasControls = !!Array.from(document.querySelectorAll('button')).find(b => {
        var al = (b.getAttribute('aria-label') || '');
        var txt = (b.innerText || '');
        var r = b.getBoundingClientRect();
        return r.width > 10 && r.height > 10 &&
               (al.indexOf('Adicionar elementos') >= 0 || al.indexOf('Add elements') >= 0 ||
                b.className.indexOf('add-menu-trigger') >= 0 || txt.indexOf('Agente') >= 0 ||
                al.indexOf('Nova sess') >= 0);
    });
    var hasWorkspace = !!document.querySelector('cdk-virtual-scroll-viewport, flow-agent-panel, div[role=""textbox""]');
    return (hasControls && hasWorkspace) ? 'READY' : 'WAIT';
})()", ct);

                if (st == "READY")
                {
                    await Task.Delay(4000, ct);
                    return;
                }
                await Task.Delay(600, ct);
            }
            await Task.Delay(3500, ct);
        }

        private async Task WaitForEmptyAgentSessionAsync(string sess, CancellationToken ct)
        {
            for (int i = 0; i < 10; i++)
            {
                await Task.Delay(i == 0 ? 1200 : 450, ct);
                string countStr = await _cdp.EvalStringAsync(sess, @"
(function(){
    var vids = document.querySelectorAll('flow-agent-panel flow-a2ui-video-option').length;
    var bubbles = document.querySelectorAll('flow-agent-panel flow-chat-bubble').length;
    return String(vids + bubbles);
})()", ct);
                int n;
                if (int.TryParse(countStr, out n) && n == 0)
                    return;
            }
        }

        private async Task WaitForOverlayImagesLibraryLoadedAsync(string sess, CancellationToken ct)
        {
            DateTime deadline = DateTime.UtcNow.AddSeconds(22);
            int stableReadyCount = 0;

            while (DateTime.UtcNow < deadline)
            {
                ct.ThrowIfCancellationRequested();
                string st = await _cdp.EvalStringAsync(sess, @"
(function(){
    var hasSearch = !!Array.from(document.querySelectorAll('.cdk-overlay-container input.search-input'))
        .find(el => el.getBoundingClientRect().width > 10);
    var hasUploadBtn = !!Array.from(document.querySelectorAll('.cdk-overlay-container .sidebar-upload-btn, .cdk-overlay-container button'))
        .find(el => {
            var t = (el.innerText || '') + ' ' + (el.getAttribute('aria-label') || '');
            return el.getBoundingClientRect().width > 10 &&
                   (el.className.indexOf('sidebar-upload-btn') >= 0 || t.indexOf('Enviar m') >= 0 || t.indexOf('Upload') >= 0);
        });
    if (!hasSearch && !hasUploadBtn) return 'WAIT';

    var spinners = Array.from(document.querySelectorAll(
        '.cdk-overlay-container mat-progress-spinner, .cdk-overlay-container mat-spinner, .cdk-overlay-container [role=""progressbar""], .cdk-overlay-container [class*=""uploading""]'
    )).filter(el => el.getBoundingClientRect().width > 4);
    if (spinners.length > 0) return 'SPINNING';

    var thumbs = Array.from(document.querySelectorAll('.cdk-overlay-container img.asset-thumbnail-image'))
        .filter(im => im.getBoundingClientRect().width > 10);
    if (thumbs.length > 0) {
        var loadingCount = thumbs.filter(im => !im.complete || (im.naturalWidth || 0) <= 0).length;
        if (loadingCount > 0) return 'LOADING_THUMBS';
    }
    return 'READY';
})()", ct);

                if (st == "READY")
                {
                    stableReadyCount++;
                    if (stableReadyCount >= 2)
                    {
                        await Task.Delay(1200, ct);
                        return;
                    }
                }
                else
                {
                    stableReadyCount = 0;
                }

                await Task.Delay(600, ct);
            }
            await Task.Delay(1200, ct);
        }

        private async Task WaitForAttachedPromptChipsImagesLoadedAsync(string sess, CancellationToken ct)
        {
            DateTime deadline = DateTime.UtcNow.AddSeconds(20);
            while (DateTime.UtcNow < deadline)
            {
                ct.ThrowIfCancellationRequested();
                string st = await _cdp.EvalStringAsync(sess, @"
(function(){
    var chips = Array.from(document.querySelectorAll('flow-image-ingredient-chip'))
        .filter(c => {
            if (c.closest('flow-chat-bubble')) return false;
            var r = c.getBoundingClientRect();
            return r.width > 10 && r.top > 100;
        });
    if (chips.length === 0) return 'EMPTY';
    var pending = chips.filter(c => {
        var im = c.querySelector('img');
        if (!im) return false;
        return !im.complete || (im.naturalWidth || 0) <= 0;
    }).length;
    return pending === 0 ? 'READY' : 'LOADING';
})()", ct);

                if (st == "READY" || st == "EMPTY")
                {
                    await Task.Delay(1500, ct);
                    return;
                }
                await Task.Delay(500, ct);
            }
            await Task.Delay(1500, ct);
        }

        private async Task<PreSessionGridBaseline> CapturePreSessionBaselineAsync(string sess, CancellationToken ct)
        {
            PreSessionGridBaseline baseline = new PreSessionGridBaseline();

            // 1. Vai para o topo do grid virtualizado (scrollTop = 0) e captura os primeiros ~36 cards preexistentes
            await _cdp.EvalStringAsync(sess, @"
(function(){
    var vp = document.querySelector('cdk-virtual-scroll-viewport.tiles-container') || document.querySelector('cdk-virtual-scroll-viewport');
    if (vp) vp.scrollTop = 0;
    return 'OK';
})()", ct);
            await Task.Delay(450, ct);

            Dictionary<string, object> topSnap = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var tiles = Array.from(document.querySelectorAll('flow-video-tile, flow-image-tile, flow-asset-tile, [data-asb-id]'));
    var asbs = [];
    var urls = [];
    var topFailedBeforeFirstAsb = 0;
    var seenFirstAsb = false;

    tiles.forEach(t => {
        var host = t.closest('flow-video-tile, flow-image-tile, flow-asset-tile') || t;
        var vid = host.querySelector('video');
        var img = host.querySelector('img.thumbnail') || host.querySelector('img');
        var imgSrc = img ? (img.currentSrc || img.src || img.getAttribute('src') || '') : '';
        if (imgSrc.length > 12) urls.push(imgSrc);
        var mediaUrl = imgSrc + ' ' +
                       (vid ? ((vid.getAttribute('poster') || '') + ' ' + (vid.getAttribute('src') || '')) : '');
        var allMatches = mediaUrl.match(/\/asb\/([A-Za-z0-9_\-]{25,80})/g) || [];
        var dataAsb = host.getAttribute('data-asb-id') || '';
        if (dataAsb) asbs.push(dataAsb);
        var hasMoreBtn = !!host.querySelector('button[aria-label*=""Mais op""], button[aria-label*=""More""]');
        var txt = (host.innerText || '');
        var hasErr = !vid && !hasMoreBtn && allMatches.length === 0 && !imgSrc &&
                     /violar|pol[ií]ticas|falha|erro|n[aã]o foi poss[ií]vel|violate|failed/i.test(txt);

        if (allMatches.length > 0 || imgSrc.length > 12) {
            seenFirstAsb = true;
            allMatches.forEach(tok => asbs.push(tok.replace('/asb/', '')));
        } else if (!seenFirstAsb && hasErr) {
            topFailedBeforeFirstAsb++;
        }
    });

    var panel = document.querySelector('flow-agent-panel');
    var preBubbles = 0;
    var preVidOpts = 0;
    if (panel) {
        preBubbles = panel.querySelectorAll('flow-chat-bubble').length;
        preVidOpts = panel.querySelectorAll('flow-a2ui-video-option').length;
        Array.from(panel.querySelectorAll('img, video')).forEach(el => {
            var s = (el.currentSrc || el.src || el.getAttribute('src') || '') + ' ' + (el.getAttribute('poster') || '');
            var trimmedSrc = (el.currentSrc || el.src || el.getAttribute('src') || '').trim();
            if (trimmedSrc.length > 12) urls.push(trimmedSrc);
            var m = s.match(/\/asb\/([A-Za-z0-9_\-]{25,80})/g) || [];
            m.forEach(tok => asbs.push(tok.replace('/asb/', '')));
        });
    }

    return JSON.stringify({ asbs: asbs, urls: urls, topFailed: topFailedBeforeFirstAsb, preBubbles: preBubbles, preVidOpts: preVidOpts });
})()", ct);

            if (topSnap != null)
            {
                if (topSnap.ContainsKey("topFailed"))
                    baseline.PreExistingTopFailedCount = Convert.ToInt32(topSnap["topFailed"]);
                if (topSnap.ContainsKey("preBubbles"))
                    baseline.PreExistingChatBubblesCount = Convert.ToInt32(topSnap["preBubbles"]);
                if (topSnap.ContainsKey("preVidOpts"))
                    baseline.PreExistingAgentVideoOptionsCount = Convert.ToInt32(topSnap["preVidOpts"]);

                IEnumerable asbList = topSnap.ContainsKey("asbs") ? topSnap["asbs"] as IEnumerable : null;
                if (asbList != null)
                {
                    foreach (object item in asbList)
                    {
                        string id = Convert.ToString(item ?? "").Trim();
                        if (!string.IsNullOrEmpty(id))
                            baseline.PreExistingAsbIds.Add(id);
                    }
                }

                IEnumerable urlList = topSnap.ContainsKey("urls") ? topSnap["urls"] as IEnumerable : null;
                if (urlList != null)
                {
                    foreach (object item in urlList)
                    {
                        string u = Convert.ToString(item ?? "").Trim();
                        if (!string.IsNullOrEmpty(u))
                            baseline.PreExistingImageUrls.Add(u);
                    }
                }
            }

            // 2. Captura também uma segunda página (+550px) de âncoras preexistentes e volta para scrollTop = 0
            string page2Raw = await _cdp.EvalStringAsync(sess, @"
(function(){
    var vp = document.querySelector('cdk-virtual-scroll-viewport.tiles-container') || document.querySelector('cdk-virtual-scroll-viewport');
    if (!vp) return '';
    vp.scrollTop = 550;
    return 'SCROLLED';
})()", ct);

            if (page2Raw == "SCROLLED")
            {
                await Task.Delay(350, ct);
                Dictionary<string, object> p2Snap = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var tiles = Array.from(document.querySelectorAll('flow-video-tile, flow-image-tile, flow-asset-tile, [data-asb-id]'));
    var asbs = [];
    var urls = [];
    tiles.forEach(t => {
        var host = t.closest('flow-video-tile, flow-image-tile, flow-asset-tile') || t;
        var vid = host.querySelector('video');
        var img = host.querySelector('img.thumbnail') || host.querySelector('img');
        var imgSrc = img ? (img.currentSrc || img.src || img.getAttribute('src') || '') : '';
        if (imgSrc.length > 12) urls.push(imgSrc);
        var mediaUrl = imgSrc + ' ' +
                       (vid ? ((vid.getAttribute('poster') || '') + ' ' + (vid.getAttribute('src') || '')) : '');
        var allMatches = mediaUrl.match(/\/asb\/([A-Za-z0-9_\-]{25,80})/g) || [];
        allMatches.forEach(tok => asbs.push(tok.replace('/asb/', '')));
        var dataAsb = host.getAttribute('data-asb-id') || '';
        if (dataAsb) asbs.push(dataAsb);
    });
    var vp = document.querySelector('cdk-virtual-scroll-viewport.tiles-container') || document.querySelector('cdk-virtual-scroll-viewport');
    if (vp) vp.scrollTop = 0;
    return JSON.stringify({ asbs: asbs, urls: urls });
})()", ct);

                if (p2Snap != null)
                {
                    if (p2Snap.ContainsKey("asbs"))
                    {
                        IEnumerable p2List = p2Snap["asbs"] as IEnumerable;
                        if (p2List != null)
                        {
                            foreach (object item in p2List)
                            {
                                string id = Convert.ToString(item ?? "").Trim();
                                if (!string.IsNullOrEmpty(id))
                                    baseline.PreExistingAsbIds.Add(id);
                            }
                        }
                    }
                    if (p2Snap.ContainsKey("urls"))
                    {
                        IEnumerable p2Urls = p2Snap["urls"] as IEnumerable;
                        if (p2Urls != null)
                        {
                            foreach (object item in p2Urls)
                            {
                                string u = Convert.ToString(item ?? "").Trim();
                                if (!string.IsNullOrEmpty(u))
                                    baseline.PreExistingImageUrls.Add(u);
                            }
                        }
                    }
                }
                await Task.Delay(250, ct);
            }

            return baseline;
        }

        private async Task<Dictionary<string, object>> QuickCheckAssetInSearchFieldAsync(
            string sess,
            string searchStem,
            string fullFileName,
            CancellationToken ct)
        {
            string query = !string.IsNullOrWhiteSpace(searchStem) ? searchStem.Trim() : (fullFileName ?? "").Trim();
            if (string.IsNullOrEmpty(query))
                return null;

            string b64Stem = Convert.ToBase64String(Encoding.UTF8.GetBytes(searchStem ?? ""));
            string b64Full = Convert.ToBase64String(Encoding.UTF8.GetBytes(fullFileName ?? ""));

            string checkJs = string.Format(@"
(function(){{
    var wantStem = new TextDecoder('utf-8').decode(Uint8Array.from(atob('{0}'), c => c.charCodeAt(0))).trim().toLowerCase();
    var wantFull = new TextDecoder('utf-8').decode(Uint8Array.from(atob('{1}'), c => c.charCodeAt(0))).trim().toLowerCase();
    var inp = document.querySelector('.cdk-overlay-container input.search-input');
    var curQueryLen = inp ? (inp.value || '').trim().length : 0;

    var items = Array.from(document.querySelectorAll('.cdk-overlay-container button.asset-item, .cdk-overlay-container [class*=""asset-item""]'))
        .filter(el => el.tagName === 'BUTTON' || el.getAttribute('role') === 'option')
        .filter(el => el.getBoundingClientRect().width > 12);

    var chosen = items.find(el => {{
        var rawTxt = (el.innerText || '').trim().toLowerCase();
        var rawAria = (el.getAttribute('aria-label') || '').trim().toLowerCase();
        var combined = rawTxt + ' ' + rawAria;
        return rawTxt === wantFull || rawTxt === wantStem ||
               rawAria === wantFull || rawAria === wantStem ||
               (wantFull.length > 0 && combined.indexOf(wantFull) >= 0) ||
               (wantStem.length > 0 && combined.indexOf(wantStem) >= 0);
    }});

    if (!chosen) {{
        return JSON.stringify({{ found: false, itemCount: items.length, curQueryLen: curQueryLen }});
    }}

    var img = chosen.querySelector('img.asset-thumbnail-image') || chosen.querySelector('img');
    var imgSrc = img ? ((img.currentSrc || img.src || img.getAttribute('src') || '')) : '';
    var hasSpinner = !!chosen.querySelector('mat-progress-spinner, mat-spinner, [role=""progressbar""], [class*=""uploading""]');
    var imgReady = !hasSpinner && !!img && imgSrc.length > 12 && !!img.complete && (img.naturalWidth || 0) > 0;

    return JSON.stringify({{
        found: true,
        imgReady: imgReady,
        hasSpinner: hasSpinner,
        curQueryLen: curQueryLen,
        matchedText: (chosen.innerText || '').trim()
    }});
}})()", b64Stem, b64Full);

            // 1. Se o campo de busca estiver vazio e a imagem já estiver visível nos 15 itens recentes, retorna sem nenhuma mutação de DOM!
            Dictionary<string, object> directRes = await _cdp.EvalJsonAsync(sess, checkJs, ct);
            if (directRes != null &&
                directRes.ContainsKey("found") && Convert.ToBoolean(directRes["found"]) &&
                Convert.ToInt32(directRes.ContainsKey("curQueryLen") ? directRes["curQueryLen"] : 0) == 0)
            {
                return directRes;
            }

            // 2. Caso não esteja nos recentes visíveis, pesquisa no campo "Pesquisar recursos" usando execCommand('insertText') nativo
            string setRes = await SetOverlaySearchQueryAsync(sess, query, ct);
            if (setRes == "NO_INPUT")
                return null;

            for (int poll = 0; poll < 3; poll++)
            {
                await Task.Delay(poll == 0 ? 350 : 250, ct);
                Dictionary<string, object> res = await _cdp.EvalJsonAsync(sess, checkJs, ct);
                if (res != null && res.ContainsKey("found") && Convert.ToBoolean(res["found"]))
                {
                    return res;
                }
                if (poll == 0 && res != null && res.ContainsKey("itemCount") && Convert.ToInt32(res["itemCount"]) == 0)
                {
                    break;
                }
            }

            return null;
        }

        private async Task UploadAssetsToFlowProjectAsync(string sess, List<string> tempAssetPaths, CancellationToken ct)
        {
            if (tempAssetPaths == null || tempAssetPaths.Count == 0) return;

            await ToggleAddElementsMenuAsync(sess, true, ct);
            await EnsureImagesTabInOverlayAsync(sess, ct);
            await WaitForOverlayImagesLibraryLoadedAsync(sess, ct);

            // Verifica rápida e diretamente cada imagem digitando no campo "Pesquisar recursos" da aba "Imagens" (sem rolar lista nem trocar de aba!)
            List<string> toUpload = new List<string>();
            for (int chkIdx = 0; chkIdx < tempAssetPaths.Count; chkIdx++)
            {
                ct.ThrowIfCancellationRequested();
                if (chkIdx > 0)
                {
                    await WaitRandomFlowActionDelayAsync(string.Format("entre pesquisas de imagem ({0}/{1})", chkIdx + 1, tempAssetPaths.Count), ct);
                    await ToggleAddElementsMenuAsync(sess, true, ct);
                    await EnsureImagesTabInOverlayAsync(sess, ct);
                }

                string assetPath = tempAssetPaths[chkIdx];
                string fileName = Path.GetFileName(assetPath);
                string stem = Path.GetFileNameWithoutExtension(assetPath);

                Dictionary<string, object> existingMatch = await QuickCheckAssetInSearchFieldAsync(sess, stem, fileName, ct);
                if (existingMatch == null)
                {
                    toUpload.Add(assetPath);
                }
            }

            await ClearOverlaySearchInputAsync(sess, ct);

            if (toUpload.Count > 0)
            {
                string namesSummary = string.Join(", ", toUpload.Select(Path.GetFileName));
                _log(string.Format("[Google Flow] Fazendo upload de {0} novas imagens de personagens/cenários via 'Enviar mídia': {1}",
                    toUpload.Count, namesSummary));

                bool uploaded = await _cdp.UploadFilesViaFileChooserAsync(
                    sess,
                    async () => await ClickOverlayUploadButtonAsync(sess, ct),
                    toUpload,
                    ct);

                if (!uploaded)
                {
                    // Fallback: tenta input[type="file"] direto caso o DOM tenha anexado algum
                    uploaded = await _cdp.SetFileInputFilesAsync(sess, "input[type=\"file\"]", toUpload, ct);
                }

                if (uploaded)
                {
                    // Aguarda todas as imagens enviadas terminarem 100% o upload e confirma rapidamente pelo campo "Pesquisar recursos" na aba "Imagens"
                    await Task.Delay(3000, ct);
                    DateTime uploadDeadline = DateTime.UtcNow.AddSeconds(Math.Min(600, 60 + (toUpload.Count * 35)));
                    List<string> pendingCheck = new List<string>(toUpload);
                    int lastReadyLogged = -1;

                    while (DateTime.UtcNow < uploadDeadline && pendingCheck.Count > 0)
                    {
                        ct.ThrowIfCancellationRequested();
                        await Task.Delay(1500, ct);
                        await ToggleAddElementsMenuAsync(sess, true, ct);
                        await EnsureImagesTabInOverlayAsync(sess, ct);

                        string overlayBusy = await _cdp.EvalStringAsync(sess, @"
(function(){
    var sp = Array.from(document.querySelectorAll(
        '.cdk-overlay-container mat-progress-spinner, .cdk-overlay-container mat-spinner, .cdk-overlay-container [role=""progressbar""], .cdk-overlay-container [class*=""uploading""]'
    )).filter(el => el.getBoundingClientRect().width > 4);
    return sp.length > 0 ? 'BUSY' : 'IDLE';
})()", ct);

                        if (overlayBusy == "BUSY")
                            continue;

                        List<string> stillPending = new List<string>();
                        for (int upIdx = 0; upIdx < pendingCheck.Count; upIdx++)
                        {
                            if (upIdx > 0)
                            {
                                await WaitRandomFlowActionDelayAsync(string.Format("entre pesquisas de confirmação ({0}/{1})", upIdx + 1, pendingCheck.Count), ct);
                                await ToggleAddElementsMenuAsync(sess, true, ct);
                                await EnsureImagesTabInOverlayAsync(sess, ct);
                            }

                            string upFile = pendingCheck[upIdx];
                            string fn = Path.GetFileName(upFile);
                            string st = Path.GetFileNameWithoutExtension(upFile);
                            Dictionary<string, object> found = await QuickCheckAssetInSearchFieldAsync(sess, st, fn, ct);
                            bool isImgReady = found != null && found.ContainsKey("imgReady") && Convert.ToBoolean(found["imgReady"]);
                            if (!isImgReady)
                            {
                                stillPending.Add(upFile);
                            }
                        }
                        pendingCheck = stillPending;

                        int readyNow = toUpload.Count - pendingCheck.Count;
                        if (readyNow != lastReadyLogged && pendingCheck.Count > 0)
                        {
                            lastReadyLogged = readyNow;
                            _log(string.Format("[Google Flow] Monitorando carregamento das imagens enviadas: {0}/{1} carregadas...",
                                readyNow, toUpload.Count));
                        }
                    }

                    await ClearOverlaySearchInputAsync(sess, ct);
                    await Task.Delay(1500, ct);
                    int indexedCount = toUpload.Count - pendingCheck.Count;
                    _log(string.Format("[Google Flow] Upload confirmado e imagens carregadas na aba Imagens: {0}/{1} novos arquivos prontos!",
                        indexedCount, toUpload.Count));
                }
                else
                {
                    _log("[Google Flow] Aviso: não foi possível acionar o seletor de upload ('Enviar mídia') no menu '+'.");
                }
            }
            else
            {
                _log(string.Format("[Google Flow] Todos os {0} personagens e cenários já estão presentes na aba 'Imagens' do projeto!", tempAssetPaths.Count));
            }

            await WaitRandomFlowActionDelayAsync("após verificar imagens na biblioteca", ct);
        }

        private async Task ClickOverlayUploadButtonAsync(string sess, CancellationToken ct)
        {
            await ToggleAddElementsMenuAsync(sess, true, ct);

            Dictionary<string, object> upPt = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var b = Array.from(document.querySelectorAll('.cdk-overlay-container .sidebar-upload-btn, .cdk-overlay-container button')).find(el => {
        var txt = (el.innerText || '');
        var al = (el.getAttribute('aria-label') || '');
        var r = el.getBoundingClientRect();
        return r.width > 10 && r.height > 10 &&
               (el.className.indexOf('sidebar-upload-btn') >= 0 || txt.indexOf('Enviar m') >= 0 || txt.indexOf('Upload') >= 0 || al.indexOf('Enviar m') >= 0);
    });
    if (!b) return null;
    var r = b.getBoundingClientRect();
    return JSON.stringify({ x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) });
})()", ct);

            if (upPt == null)
                throw new InvalidOperationException("Botão 'Enviar mídia' (.sidebar-upload-btn) não encontrado no menu '+' do Google Flow.");

            await _cdp.ClickAtAsync(sess, Convert.ToInt32(upPt["x"]), Convert.ToInt32(upPt["y"]), ct);
        }

        private async Task ToggleAddElementsMenuAsync(string sess, bool wantOpen, CancellationToken ct)
        {
            // Regra 25 e 31: NUNCA scrollIntoView() e NUNCA clicar em close (1499,100)
            Dictionary<string, object> info = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var isOpen = !!Array.from(document.querySelectorAll(
        '.cdk-overlay-container .side-nav-list-item, .cdk-overlay-container input.search-input, .cdk-overlay-container .detail-add-to-prompt-btn, .cdk-overlay-container .sidebar-upload-btn'
    )).find(el => el.getBoundingClientRect().width > 10);

    function findPlus(root) {
        return Array.from(root.querySelectorAll('button')).filter(b => {
            var al = (b.getAttribute('aria-label') || '');
            var r = b.getBoundingClientRect();
            return r.width > 10 && r.height > 10 &&
                   (al.indexOf('Adicionar elementos') >= 0 || al.indexOf('Add elements') >= 0 || b.className.indexOf('add-menu-trigger') >= 0);
        });
    }

    var panel = document.querySelector('flow-agent-panel');
    var btns = panel ? findPlus(panel) : [];
    if (btns.length === 0) btns = findPlus(document);
    if (btns.length === 0) return JSON.stringify({ isOpen: isOpen, found: false });

    var plusBtn = btns[btns.length - 1];
    var r = plusBtn.getBoundingClientRect();
    return JSON.stringify({
        isOpen: isOpen,
        found: true,
        x: Math.round(r.left + r.width/2),
        y: Math.round(r.top + r.height/2)
    });
})()", ct);

            if (info == null) return;
            bool isOpen = Convert.ToBoolean(info["isOpen"]);
            if (isOpen != wantOpen && Convert.ToBoolean(info["found"]))
            {
                await _cdp.ClickAtAsync(sess, Convert.ToInt32(info["x"]), Convert.ToInt32(info["y"]), ct);
                await Task.Delay(650, ct);
            }
        }

        private async Task EnsureImagesTabInOverlayAsync(string sess, CancellationToken ct)
        {
            // Importante: no menu '+' do Google Flow, o innerText da aba contém o ícone Material ("image\nImagens") dentro de .cdk-overlay-container
            Dictionary<string, object> tabInfo = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var tabs = Array.from(document.querySelectorAll('.cdk-overlay-container [role=""tab""], .cdk-overlay-container .side-nav-list-item, .cdk-overlay-container mat-list-item'));
    var t = tabs.find(el => {
        var txt = (el.innerText || '');
        var r = el.getBoundingClientRect();
        return r.width > 10 && r.height > 10 && (txt.indexOf('Imagens') >= 0 || txt.indexOf('Images') >= 0);
    });
    if (!t) return null;
    var hasSearch = !!Array.from(document.querySelectorAll('.cdk-overlay-container input.search-input')).find(i => i.getBoundingClientRect().width > 10);
    var selected = (t.getAttribute('aria-selected') === 'true') && hasSearch;
    var r = t.getBoundingClientRect();
    return JSON.stringify({
        selected: selected,
        x: Math.round(r.left + r.width/2),
        y: Math.round(r.top + r.height/2)
    });
})()", ct);

            if (tabInfo != null && !Convert.ToBoolean(tabInfo["selected"]))
            {
                await _cdp.ClickAtAsync(sess, Convert.ToInt32(tabInfo["x"]), Convert.ToInt32(tabInfo["y"]), ct);
                await Task.Delay(650, ct);
            }
        }

        private async Task<bool> EnsureUploadsTabInOverlayAsync(string sess, CancellationToken ct)
        {
            Dictionary<string, object> tabInfo = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var tabs = Array.from(document.querySelectorAll('.cdk-overlay-container [role=""tab""], .cdk-overlay-container .side-nav-list-item, .cdk-overlay-container mat-list-item'));
    var t = tabs.find(el => {
        var txt = (el.innerText || '');
        var r = el.getBoundingClientRect();
        return r.width > 10 && r.height > 10 &&
               (txt.indexOf('Envios') >= 0 || txt.indexOf('Uploads') >= 0 || txt.indexOf('drive_folder_upload') >= 0);
    });
    if (!t) return null;
    var selected = (t.getAttribute('aria-selected') === 'true');
    var r = t.getBoundingClientRect();
    return JSON.stringify({
        selected: selected,
        x: Math.round(r.left + r.width/2),
        y: Math.round(r.top + r.height/2)
    });
})()", ct);

            if (tabInfo == null) return false;
            if (!Convert.ToBoolean(tabInfo["selected"]))
            {
                await _cdp.ClickAtAsync(sess, Convert.ToInt32(tabInfo["x"]), Convert.ToInt32(tabInfo["y"]), ct);
                await Task.Delay(600, ct);
            }
            return true;
        }

        private async Task<string> SetOverlaySearchQueryAsync(string sess, string query, CancellationToken ct)
        {
            string b64Query = Convert.ToBase64String(Encoding.UTF8.GetBytes(query ?? ""));
            return await _cdp.EvalStringAsync(sess, string.Format(@"
(function(){{
    var inp = document.querySelector('.cdk-overlay-container input.search-input') ||
              Array.from(document.querySelectorAll('.cdk-overlay-container input')).find(el => el.getBoundingClientRect().width > 30);
    if (!inp) return 'NO_INPUT';
    var q = new TextDecoder('utf-8').decode(Uint8Array.from(atob('{0}'), c => c.charCodeAt(0)));
    if ((inp.value || '') === q) return 'OK';
    inp.focus();
    inp.select();
    document.execCommand('insertText', false, q);

    var vps = Array.from(document.querySelectorAll('.cdk-overlay-container cdk-virtual-scroll-viewport, .cdk-overlay-container .asset-list-viewport'));
    vps.forEach(vp => {{
        try {{
            if (vp.scrollTop > 0) vp.scrollTop = 0;
        }} catch(e) {{}}
    }});
    return 'OK';
}})()", b64Query), ct);
        }

        private async Task ClearOverlaySearchInputAsync(string sess, CancellationToken ct)
        {
            string res = await _cdp.EvalStringAsync(sess, @"
(function(){
    var inp = document.querySelector('.cdk-overlay-container input.search-input') ||
              Array.from(document.querySelectorAll('.cdk-overlay-container input')).find(el => el.getBoundingClientRect().width > 30);
    if (!inp) return 'NO_INPUT';
    if (!inp.value || inp.value.length === 0) return 'ALREADY_EMPTY';
    inp.focus();
    inp.select();
    document.execCommand('delete', false, null);
    var vps = Array.from(document.querySelectorAll('.cdk-overlay-container cdk-virtual-scroll-viewport, .cdk-overlay-container .asset-list-viewport'));
    vps.forEach(vp => {
        try {
            if (vp.scrollTop > 0) vp.scrollTop = 0;
        } catch(e) {}
    });
    return 'OK';
})()", ct);
            if (res == "OK")
                await Task.Delay(250, ct);
        }

        private async Task<Dictionary<string, object>> EvaluateOverlayAssetMatchAsync(
            string sess,
            string b64Stem,
            string b64Full,
            CancellationToken ct)
        {
            string findAssetJs = string.Format(@"
(function(){{
    var wantStem = new TextDecoder('utf-8').decode(Uint8Array.from(atob('{0}'), c => c.charCodeAt(0))).trim().toLowerCase();
    var wantFull = new TextDecoder('utf-8').decode(Uint8Array.from(atob('{1}'), c => c.charCodeAt(0))).trim().toLowerCase();

    var inp = document.querySelector('.cdk-overlay-container input.search-input') ||
              Array.from(document.querySelectorAll('.cdk-overlay-container input')).find(el => el.getBoundingClientRect().width > 30);
    var curQuery = inp ? (inp.value || '').trim() : '';

    var items = Array.from(document.querySelectorAll('.cdk-overlay-container button.asset-item, .cdk-overlay-container [class*=""asset-item""]'))
        .filter(el => el.tagName === 'BUTTON' || el.getAttribute('role') === 'option')
        .filter(el => el.getBoundingClientRect().width > 12);
    if (items.length === 0) return null;

    var exact = items.find(el => {{
        var rawTxt = (el.innerText || '').trim().toLowerCase();
        var rawAria = (el.getAttribute('aria-label') || '').trim().toLowerCase();
        var lines = rawTxt.split(/\r?\n/).map(s => s.trim()).filter(s => s.length > 0);
        return rawTxt === wantFull || rawTxt === wantStem ||
               rawAria === wantFull || rawAria === wantStem ||
               lines.indexOf(wantFull) >= 0 || lines.indexOf(wantStem) >= 0;
    }});

    var chosen = exact || items.find(el => {{
        var combined = ((el.innerText || '') + ' ' + (el.getAttribute('aria-label') || '')).toLowerCase();
        return combined.indexOf(wantFull) >= 0 || combined.indexOf(wantStem) >= 0;
    }});

    if (!chosen) return null;

    var vp = chosen.closest('cdk-virtual-scroll-viewport') ||
             document.querySelector('.cdk-overlay-container cdk-virtual-scroll-viewport.asset-list-viewport') ||
             document.querySelector('.cdk-overlay-container cdk-virtual-scroll-viewport');
    var vpRect = vp ? vp.getBoundingClientRect() : null;
    var pane = chosen.closest('.cdk-overlay-pane') || document.querySelector('.cdk-overlay-container .cdk-overlay-pane');
    var paneRect = pane ? pane.getBoundingClientRect() : null;

    var r = chosen.getBoundingClientRect();
    var cx = Math.round(r.left + Math.min(r.width / 2, 110));
    var cy = Math.round(r.top + r.height / 2);

    var minTop = vpRect ? (vpRect.top + 8) : (paneRect ? paneRect.top + 45 : 45);
    var maxBottom = vpRect ? (vpRect.bottom - 8) : (paneRect ? paneRect.bottom - 12 : (window.innerHeight - 20));
    var inBounds = r.width > 20 && r.height > 12 &&
                   cy >= minTop && cy <= maxBottom &&
                   (!paneRect || (cx >= paneRect.left + 8 && cx <= paneRect.right - 8));

    var scrolled = false;
    if (!inBounds && vp && vpRect && vp.scrollHeight > vp.clientHeight + 4) {{
        var targetScroll = Math.max(0, vp.scrollTop + (cy - (vpRect.top + vpRect.height / 2)));
        if (Math.abs(targetScroll - vp.scrollTop) > 4) {{
            vp.scrollTop = targetScroll;
            scrolled = true;
        }}
    }}

    var img = chosen.querySelector('img.asset-thumbnail-image') || chosen.querySelector('img');
    var imgSrc = img ? ((img.currentSrc || img.src || img.getAttribute('src') || '')) : '';
    var hasSpinner = !!chosen.querySelector('mat-progress-spinner, mat-spinner, [role=""progressbar""], [class*=""uploading""]');
    var imgReady = !hasSpinner && !!img && imgSrc.length > 12 && !!img.complete && (img.naturalWidth || 0) > 0;
    var isActive = chosen.classList.contains('asset-item-active') || chosen.getAttribute('aria-selected') === 'true';

    var hit = (inBounds && cx > 0 && cy > 0 && cy < window.innerHeight) ? document.elementFromPoint(cx, cy) : null;
    var hitOk = !!hit && (chosen.contains(hit) || hit.contains(chosen));

    return JSON.stringify({{
        matchedText: (chosen.innerText || '').trim(),
        isExact: !!exact,
        isActive: isActive,
        imgReady: imgReady,
        hasSpinner: hasSpinner,
        inBounds: inBounds,
        hitOk: hitOk,
        scrolled: scrolled,
        curQueryLen: curQuery.length,
        x: cx,
        y: cy
    }});
}})()", b64Stem, b64Full);

            return await _cdp.EvalJsonAsync(sess, findAssetJs, ct);
        }

        private async Task<Dictionary<string, object>> SweepOverlayVirtualListForAssetAsync(
            string sess,
            string b64Stem,
            string b64Full,
            CancellationToken ct)
        {
            await ClearOverlaySearchInputAsync(sess, ct);

            for (int page = 0; page < 18; page++)
            {
                ct.ThrowIfCancellationRequested();
                Dictionary<string, object> matchPt = await EvaluateOverlayAssetMatchAsync(sess, b64Stem, b64Full, ct);
                if (matchPt != null)
                {
                    bool inBounds = matchPt.ContainsKey("inBounds") && Convert.ToBoolean(matchPt["inBounds"]);
                    if (!inBounds && matchPt.ContainsKey("scrolled") && Convert.ToBoolean(matchPt["scrolled"]))
                    {
                        await Task.Delay(260, ct);
                        Dictionary<string, object> rescrolled = await EvaluateOverlayAssetMatchAsync(sess, b64Stem, b64Full, ct);
                        if (rescrolled != null)
                            matchPt = rescrolled;
                    }
                    return matchPt;
                }

                string nextStep = await _cdp.EvalStringAsync(sess, @"
(function(){
    var vp = document.querySelector('.cdk-overlay-container cdk-virtual-scroll-viewport.asset-list-viewport') ||
             document.querySelector('.cdk-overlay-container cdk-virtual-scroll-viewport');
    if (!vp) return 'NO_VP';
    if (vp.scrollTop + vp.clientHeight >= vp.scrollHeight - 6) return 'END';
    var nextTop = Math.min(vp.scrollHeight - vp.clientHeight, vp.scrollTop + 380);
    if (nextTop <= vp.scrollTop + 2) return 'END';
    vp.scrollTop = nextTop;
    return 'MOVED';
})()", ct);

                if (nextStep != "MOVED")
                    break;

                await Task.Delay(230, ct);
            }

            return null;
        }

        private async Task<Dictionary<string, object>> SearchOverlayAssetAsync(
            string sess,
            string searchStem,
            string fullFileName,
            CancellationToken ct)
        {
            string b64Stem = Convert.ToBase64String(Encoding.UTF8.GetBytes(searchStem ?? ""));
            string b64Full = Convert.ToBase64String(Encoding.UTF8.GetBytes(fullFileName ?? ""));

            // 1. Verifica primeiro se já está visível dentro da janela útil do cdk-virtual-scroll-viewport (sem texto residual de busca anterior)
            Dictionary<string, object> directPt = await EvaluateOverlayAssetMatchAsync(sess, b64Stem, b64Full, ct);
            if (directPt != null &&
                Convert.ToInt32(directPt.ContainsKey("curQueryLen") ? directPt["curQueryLen"] : 0) == 0 &&
                directPt.ContainsKey("isExact") && Convert.ToBoolean(directPt["isExact"]))
            {
                bool directInBounds = directPt.ContainsKey("inBounds") && Convert.ToBoolean(directPt["inBounds"]);
                bool directHitOk = directPt.ContainsKey("hitOk") && Convert.ToBoolean(directPt["hitOk"]);
                bool directImgReady = directPt.ContainsKey("imgReady") && Convert.ToBoolean(directPt["imgReady"]);

                if (directInBounds && directHitOk && directImgReady)
                {
                    return directPt;
                }

                // Se estava montado no final dos 15 recentes (ex.: 9º+ item em y > 560), EvaluateOverlayAssetMatchAsync já rolou o viewport interno: aguarda renderização!
                if (!directInBounds && directPt.ContainsKey("scrolled") && Convert.ToBoolean(directPt["scrolled"]))
                {
                    await Task.Delay(260, ct);
                    Dictionary<string, object> afterScrollPt = await EvaluateOverlayAssetMatchAsync(sess, b64Stem, b64Full, ct);
                    if (afterScrollPt != null &&
                        afterScrollPt.ContainsKey("inBounds") && Convert.ToBoolean(afterScrollPt["inBounds"]) &&
                        afterScrollPt.ContainsKey("hitOk") && Convert.ToBoolean(afterScrollPt["hitOk"]) &&
                        afterScrollPt.ContainsKey("imgReady") && Convert.ToBoolean(afterScrollPt["imgReady"]))
                    {
                        return afterScrollPt;
                    }
                }
            }

            // 2. Busca na biblioteca COMPLETA do projeto via input.search-input (encontra imagens antigas mesmo após dezenas de cenas geradas!)
            List<string> candidateQueries = new List<string>();
            if (!string.IsNullOrWhiteSpace(searchStem))
                candidateQueries.Add(searchStem.Trim());

            Match prefixMatch = Regex.Match(searchStem ?? "", @"^(\d+_[A-Za-z]+_[A-Za-z0-9]+)");
            if (prefixMatch.Success)
            {
                string shortPrefix = prefixMatch.Groups[1].Value;
                if (!string.Equals(shortPrefix, searchStem, StringComparison.OrdinalIgnoreCase))
                    candidateQueries.Add(shortPrefix);
            }

            Dictionary<string, object> lastMatch = null;
            for (int qIdx = 0; qIdx < candidateQueries.Count; qIdx++)
            {
                string query = candidateQueries[qIdx];
                string setRes = await SetOverlaySearchQueryAsync(sess, query, ct);
                if (setRes == "NO_INPUT")
                    break;

                int maxPolls = (qIdx == 0) ? 5 : 4;
                for (int poll = 0; poll < maxPolls; poll++)
                {
                    await Task.Delay(poll == 0 ? 340 : 260, ct);

                    Dictionary<string, object> matchPt = await EvaluateOverlayAssetMatchAsync(sess, b64Stem, b64Full, ct);
                    if (matchPt != null)
                    {
                        lastMatch = matchPt;
                        bool inBounds = matchPt.ContainsKey("inBounds") && Convert.ToBoolean(matchPt["inBounds"]);
                        if (!inBounds && matchPt.ContainsKey("scrolled") && Convert.ToBoolean(matchPt["scrolled"]))
                        {
                            await Task.Delay(260, ct);
                            Dictionary<string, object> rescrolled = await EvaluateOverlayAssetMatchAsync(sess, b64Stem, b64Full, ct);
                            if (rescrolled != null)
                            {
                                matchPt = rescrolled;
                                lastMatch = rescrolled;
                                inBounds = rescrolled.ContainsKey("inBounds") && Convert.ToBoolean(rescrolled["inBounds"]);
                            }
                        }

                        if (inBounds)
                            return matchPt;
                    }
                }

                if (lastMatch != null)
                    return lastMatch;
            }

            // 3. Fallback de varredura completa da lista virtualizada além de 'Mais recentes' (rola página por página até o fim da aba Imagens)
            Dictionary<string, object> sweptInImages = await SweepOverlayVirtualListForAssetAsync(sess, b64Stem, b64Full, ct);
            if (sweptInImages != null)
                return sweptInImages;

            // 4. Fallback na aba 'Envios' (Uploads), onde ficam exclusivamente os arquivos enviados sem mistura com cenas geradas
            if (await EnsureUploadsTabInOverlayAsync(sess, ct))
            {
                if (!string.IsNullOrWhiteSpace(searchStem))
                {
                    string upSet = await SetOverlaySearchQueryAsync(sess, searchStem.Trim(), ct);
                    if (upSet == "OK")
                    {
                        await Task.Delay(360, ct);
                        Dictionary<string, object> upMatch = await EvaluateOverlayAssetMatchAsync(sess, b64Stem, b64Full, ct);
                        if (upMatch != null)
                        {
                            bool inBounds = upMatch.ContainsKey("inBounds") && Convert.ToBoolean(upMatch["inBounds"]);
                            if (!inBounds && upMatch.ContainsKey("scrolled") && Convert.ToBoolean(upMatch["scrolled"]))
                            {
                                await Task.Delay(260, ct);
                                upMatch = await EvaluateOverlayAssetMatchAsync(sess, b64Stem, b64Full, ct) ?? upMatch;
                            }
                            return upMatch;
                        }
                    }
                }

                Dictionary<string, object> sweptInUploads = await SweepOverlayVirtualListForAssetAsync(sess, b64Stem, b64Full, ct);
                if (sweptInUploads != null)
                    return sweptInUploads;

                await EnsureImagesTabInOverlayAsync(sess, ct);
            }

            return null;
        }

        private async Task<int> AttachIngredientsViaMenuAsync(
            string sess,
            List<string> wantedFilenames,
            HashSet<string> attachedInSessionOut,
            CancellationToken ct)
        {
            if (wantedFilenames == null || wantedFilenames.Count == 0) return 0;

            await ToggleAddElementsMenuAsync(sess, true, ct);
            await EnsureImagesTabInOverlayAsync(sess, ct);
            await WaitForOverlayImagesLibraryLoadedAsync(sess, ct);

            int baselineChips = await CountAttachedPromptChipsAsync(sess, ct);
            int currentChips = baselineChips;
            int attachedNow = 0;

            for (int idx = 0; idx < wantedFilenames.Count; idx++)
            {
                ct.ThrowIfCancellationRequested();
                if (idx > 0)
                {
                    await WaitRandomFlowActionDelayAsync(string.Format("entre anexações ({0}/{1})", idx + 1, wantedFilenames.Count), ct);
                }

                string fileName = wantedFilenames[idx];
                string stem = Path.GetFileNameWithoutExtension(fileName);
                bool itemAttached = false;
                bool capReached = false;

                for (int attempt = 1; attempt <= 3; attempt++)
                {
                    await ToggleAddElementsMenuAsync(sess, true, ct);
                    await EnsureImagesTabInOverlayAsync(sess, ct);

                    Dictionary<string, object> itemPt = await SearchOverlayAssetAsync(sess, stem, fileName, ct);
                    if (itemPt == null)
                    {
                        if (attempt < 3)
                        {
                            await Task.Delay(800, ct);
                            continue;
                        }
                        _log(string.Format("[Google Flow] Aviso: imagem '{0}' não localizada na biblioteca do projeto (abas Imagens/Envios).", fileName));
                        break;
                    }

                    bool hasSpinner = itemPt.ContainsKey("hasSpinner") && Convert.ToBoolean(itemPt["hasSpinner"]);
                    bool imgReady = !itemPt.ContainsKey("imgReady") || Convert.ToBoolean(itemPt["imgReady"]);
                    if ((hasSpinner || !imgReady) && attempt < 3)
                    {
                        await Task.Delay(1200, ct);
                        continue;
                    }

                    // Exclusivamente clique real de mouse via CDP (ZERO .click() sintético para não acionar bloqueio do Flow!)
                    await _cdp.ClickAtAsync(sess, Convert.ToInt32(itemPt["x"]), Convert.ToInt32(itemPt["y"]), ct);
                    await Task.Delay(550, ct);

                    // Regra 25: Clicar obrigatoriamente em "Incluir no comando" via CDP ClickAtAsync
                    Dictionary<string, object> incPt = null;
                    for (int pollInc = 0; pollInc < 6; pollInc++)
                    {
                        incPt = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var b = Array.from(document.querySelectorAll('.cdk-overlay-container button, button.detail-add-to-prompt-btn')).find(el => {
        var txt = (el.innerText || '').trim();
        var al = (el.getAttribute('aria-label') || '');
        var r = el.getBoundingClientRect();
        return r.width > 10 && r.height > 10 &&
               (txt.indexOf('Incluir no comando') >= 0 || al.indexOf('Incluir no comando') >= 0 ||
                txt.indexOf('Include in prompt') >= 0);
    });
    if (!b) return null;
    var r = b.getBoundingClientRect();
    return JSON.stringify({
        disabled: !!b.disabled || b.getAttribute('aria-disabled') === 'true',
        x: Math.round(r.left + r.width/2),
        y: Math.round(r.top + r.height/2)
    });
})()", ct);

                        if (incPt != null && !Convert.ToBoolean(incPt["disabled"]))
                            break;

                        if (incPt != null && Convert.ToBoolean(incPt["disabled"]) && currentChips >= 8)
                            break;

                        await Task.Delay(350, ct);
                    }

                    if (incPt != null)
                    {
                        if (Convert.ToBoolean(incPt["disabled"]))
                        {
                            if (currentChips >= 8)
                            {
                                capReached = true;
                                break;
                            }
                            await Task.Delay(900, ct);
                            continue;
                        }
                        await _cdp.ClickAtAsync(sess, Convert.ToInt32(incPt["x"]), Convert.ToInt32(incPt["y"]), ct);
                        await Task.Delay(600, ct);
                    }
                    else
                    {
                        await Task.Delay(500, ct);
                    }

                    int afterChips = currentChips;
                    for (int pollChip = 0; pollChip < 4; pollChip++)
                    {
                        afterChips = await CountAttachedPromptChipsAsync(sess, ct);
                        if (afterChips > currentChips)
                            break;
                        await Task.Delay(250, ct);
                    }

                    if (afterChips > currentChips)
                    {
                        currentChips = afterChips;
                        attachedNow++;
                        itemAttached = true;
                        if (attachedInSessionOut != null)
                            attachedInSessionOut.Add(fileName);

                        _log(string.Format("[Google Flow] ✔ Ingrediente vinculado ({0}/{1}): {2} (chips na caixa: {3})",
                            idx + 1, wantedFilenames.Count, fileName, currentChips));
                        break;
                    }
                }

                if (capReached)
                {
                    _log(string.Format("[Google Flow] Limite máximo de chips simultâneos por comando atingido ({0} chips). Os cenários restantes entrarão automaticamente no próximo lote 'continue'.",
                        currentChips));
                    break;
                }

                if (!itemAttached)
                {
                    _log(string.Format("[Google Flow] Aviso: não foi possível confirmar o chip de '{0}' na caixa de comando.", fileName));
                }
            }

            await ClearOverlaySearchInputAsync(sess, ct);
            await ToggleAddElementsMenuAsync(sess, false, ct);
            _log(string.Format("[Google Flow] Resumo de Ingredientes: {0}/{1} personagens e cenários anexados na caixa de comando!",
                attachedNow, wantedFilenames.Count));
            return attachedNow;
        }

        private async Task<int> CountAttachedPromptChipsAsync(string sess, CancellationToken ct)
        {
            string s = await _cdp.EvalStringAsync(sess, @"
(function(){
    var panel = document.querySelector('flow-agent-panel');
    var hasOpenAgentBox = !!(panel && Array.from(panel.querySelectorAll('div[role=""textbox""], [contenteditable=""true""], textarea')).find(el => el.getBoundingClientRect().width > 80));
    var root = hasOpenAgentBox ? panel : document;
    return Array.from(root.querySelectorAll('flow-image-ingredient-chip button.chip-container'))
        .filter(b => {
            if (b.closest('flow-chat-bubble')) return false;
            var r = b.getBoundingClientRect();
            return r.width > 10 && r.top > 100;
        }).length;
})()", ct);
            int n;
            return int.TryParse(s, out n) ? n : 0;
        }

        private async Task ClearAttachedPromptChipsAsync(string sess, CancellationToken ct)
        {
            int initialCount = await CountAttachedPromptChipsAsync(sess, ct);
            if (initialCount <= 0)
                return;

            await ToggleAddElementsMenuAsync(sess, false, ct);

            for (int i = 0; i < 16; i++)
            {
                int beforeCount = await CountAttachedPromptChipsAsync(sess, ct);
                if (beforeCount <= 0) break;

                Dictionary<string, object> hoverPt = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var panel = document.querySelector('flow-agent-panel');
    var hasOpenAgentBox = !!(panel && Array.from(panel.querySelectorAll('div[role=""textbox""], [contenteditable=""true""], textarea')).find(el => el.getBoundingClientRect().width > 80));
    var root = hasOpenAgentBox ? panel : document;
    var hosts = Array.from(root.querySelectorAll('flow-image-ingredient-chip'))
        .filter(h => {
            if (h.closest('flow-chat-bubble')) return false;
            var r = h.getBoundingClientRect();
            return r.width > 10 && r.top > 100;
        });
    if (hosts.length === 0) return null;
    var hr = hosts[0].getBoundingClientRect();
    return JSON.stringify({ x: Math.round(hr.left + hr.width/2), y: Math.round(hr.top + hr.height/2) });
})()", ct);

                if (hoverPt == null) break;
                await _cdp.HoverAsync(sess, Convert.ToInt32(hoverPt["x"]), Convert.ToInt32(hoverPt["y"]), ct);
                await Task.Delay(220, ct);

                Dictionary<string, object> remPt = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var panel = document.querySelector('flow-agent-panel');
    var hasOpenAgentBox = !!(panel && Array.from(panel.querySelectorAll('div[role=""textbox""], [contenteditable=""true""], textarea')).find(el => el.getBoundingClientRect().width > 80));
    var root = hasOpenAgentBox ? panel : document;
    var hosts = Array.from(root.querySelectorAll('flow-image-ingredient-chip'))
        .filter(h => !h.closest('flow-chat-bubble') && h.getBoundingClientRect().width > 10 && h.getBoundingClientRect().top > 100);
    if (hosts.length === 0) return null;
    var host = hosts[0];
    var remBtn = Array.from(host.querySelectorAll('button')).find(b => {
        if (b.classList.contains('chip-container')) return false;
        var al = ((b.getAttribute('aria-label') || '') + ' ' + (b.innerText || '')).toLowerCase();
        var r = b.getBoundingClientRect();
        return r.width > 6 && r.height > 6 &&
               (al.indexOf('remov') >= 0 || al.indexOf('exclu') >= 0 || al.indexOf('delet') >= 0 || al.indexOf('close') >= 0 || al.indexOf('cancel') >= 0);
    });
    if (!remBtn) return null;
    var r2 = remBtn.getBoundingClientRect();
    return JSON.stringify({ x: Math.round(r2.left + r2.width/2), y: Math.round(r2.top + r2.height/2) });
})()", ct);

                if (remPt == null) break;
                await _cdp.ClickAtAsync(sess, Convert.ToInt32(remPt["x"]), Convert.ToInt32(remPt["y"]), ct);
                await Task.Delay(260, ct);

                int afterCount = await CountAttachedPromptChipsAsync(sess, ct);
                if (afterCount >= beforeCount)
                    break;
            }
        }

        private async Task InsertTextIntoFlowTextboxAsync(string sess, string text, bool clearExistingText, CancellationToken ct)
        {
            Dictionary<string, object> boxInfo = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var agentBoxes = Array.from(document.querySelectorAll('flow-agent-panel div[role=""textbox""], flow-agent-panel [contenteditable=""true""]'))
        .filter(el => el.getBoundingClientRect().width > 80);
    var allBoxes = Array.from(document.querySelectorAll('div[role=""textbox""], [contenteditable=""true""]'))
        .filter(el => el.getBoundingClientRect().width > 80);
    var boxes = agentBoxes.length > 0 ? agentBoxes : allBoxes;
    if (boxes.length === 0) return null;
    var tb = boxes[boxes.length - 1];
    var r = tb.getBoundingClientRect();
    var curVal = (tb.innerText || '').trim();
    return JSON.stringify({
        x: Math.round(r.left + Math.min(48, r.width / 3)),
        y: Math.round(r.top + r.height / 2),
        curLen: curVal.length
    });
})()", ct);

            if (boxInfo == null)
                throw new InvalidOperationException("Caixa de comando 'O que você quer criar?' não encontrada no Google Flow.");

            int boxX = Convert.ToInt32(boxInfo["x"]);
            int boxY = Convert.ToInt32(boxInfo["y"]);
            int curLen = boxInfo.ContainsKey("curLen") ? Convert.ToInt32(boxInfo["curLen"]) : 0;

            string normalized = text ?? "";
            if (!clearExistingText && normalized.Length == 0)
                return;
            if (clearExistingText && normalized.Length == 0 && curLen == 0)
                return;

            // Clique real de mouse para posicionar o cursor com foco legítimo antes do execCommand('insertText') (mesmo mecanismo da versão 09/11)
            await _cdp.ClickAtAsync(sess, boxX, boxY, ct);
            await Task.Delay(140, ct);

            string b64 = Convert.ToBase64String(Encoding.UTF8.GetBytes(normalized));
            string clearFlag = clearExistingText ? "true" : "false";

            string len = await _cdp.EvalStringAsync(sess, string.Format(@"
(function(){{
    var bytes = Uint8Array.from(atob('{0}'), c => c.charCodeAt(0));
    var text = new TextDecoder('utf-8').decode(bytes);
    var agentBoxes = Array.from(document.querySelectorAll('flow-agent-panel div[role=""textbox""], flow-agent-panel [contenteditable=""true""]'))
        .filter(el => el.getBoundingClientRect().width > 80);
    var allBoxes = Array.from(document.querySelectorAll('div[role=""textbox""], [contenteditable=""true""]'))
        .filter(el => el.getBoundingClientRect().width > 80);
    var boxes = agentBoxes.length > 0 ? agentBoxes : allBoxes;
    var tb = boxes[boxes.length - 1];
    if (!tb) return '-1';
    if ({1} && text.length === 0) {{
        for (var k = 0; k < allBoxes.length; k++) {{
            if (((allBoxes[k].innerText || '').trim()).length > 0) {{
                allBoxes[k].focus();
                document.execCommand('selectAll', false, null);
                document.execCommand('insertText', false, '');
            }}
        }}
        return String((tb.innerText || '').trim().length);
    }}
    tb.focus();
    if ({1}) {{
        document.execCommand('selectAll', false, null);
    }}
    document.execCommand('insertText', false, text);
    return String((tb.innerText || '').length);
}})()", b64, clearFlag), ct);

            if (len == "-1")
                throw new InvalidOperationException("Caixa de comando 'O que você quer criar?' não encontrada no Google Flow.");
        }

        private async Task<string> ReadCurrentFlowTextboxAsync(string sess, CancellationToken ct)
        {
            string txt = await _cdp.EvalStringAsync(sess, @"
(function(){
    var agentBoxes = Array.from(document.querySelectorAll('flow-agent-panel div[role=""textbox""], flow-agent-panel [contenteditable=""true""]'))
        .filter(el => el.getBoundingClientRect().width > 80);
    var allBoxes = Array.from(document.querySelectorAll('div[role=""textbox""], [contenteditable=""true""]'))
        .filter(el => el.getBoundingClientRect().width > 80);
    for (var i = agentBoxes.length - 1; i >= 0; i--) {
        var t = (agentBoxes[i].innerText || '').trim();
        if (t.length > 0) return t;
    }
    for (var j = allBoxes.length - 1; j >= 0; j--) {
        var t2 = (allBoxes[j].innerText || '').trim();
        if (t2.length > 0) return t2;
    }
    return '';
})()", ct);
            return txt ?? "";
        }

        private async Task ClickStartGenerationAsync(string sess, CancellationToken ct)
        {
            // Regra 25: Exatamente o envio único e limpo via CDP ClickAtAsync da versão estável (sem PressEnter ou eventos sintéticos)
            Dictionary<string, object> sendPt = null;
            for (int waitBtn = 0; waitBtn < 6; waitBtn++)
            {
                sendPt = await _cdp.EvalJsonAsync(sess, @"
(function(){
    function findSend(root) {
        return Array.from(root.querySelectorAll('button')).filter(x => {
            var txt = (x.innerText || '');
            var al = (x.getAttribute('aria-label') || '');
            var r = x.getBoundingClientRect();
            return r.width > 10 && r.height > 10 && !x.disabled && x.getAttribute('aria-disabled') !== 'true' &&
                   (txt.indexOf('arrow_forward') >= 0 || txt.indexOf('send') >= 0 || al.indexOf('Iniciar') >= 0 || al.indexOf('Enviar') >= 0);
        });
    }
    var panel = document.querySelector('flow-agent-panel');
    var btns = panel ? findSend(panel) : [];
    if (btns.length === 0) btns = findSend(document);
    if (btns.length === 0) return null;
    var b = btns[btns.length - 1];
    var r = b.getBoundingClientRect();
    return JSON.stringify({ x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) });
})()", ct);

                if (sendPt != null)
                    break;
                await Task.Delay(300, ct);
            }

            if (sendPt == null)
                throw new InvalidOperationException("Botão 'Iniciar geração' (→) não encontrado ou desabilitado no Google Flow.");

            await _cdp.ClickAtAsync(sess, Convert.ToInt32(sendPt["x"]), Convert.ToInt32(sendPt["y"]), ct);
        }

        private List<MountedGridTileState> ParseMountedTilesFromEval(Dictionary<string, object> rawObj)
        {
            List<MountedGridTileState> list = new List<MountedGridTileState>();
            if (rawObj == null || !rawObj.ContainsKey("tiles")) return list;
            IEnumerable arr = rawObj["tiles"] as IEnumerable;
            if (arr == null) return list;

            foreach (object elem in arr)
            {
                Dictionary<string, object> d = elem as Dictionary<string, object>;
                if (d == null) continue;
                MountedGridTileState st = new MountedGridTileState();
                st.MountedIndex = d.ContainsKey("idx") ? Convert.ToInt32(d["idx"]) : list.Count;
                st.AsbId = d.ContainsKey("asb") ? Convert.ToString(d["asb"] ?? "") : "";
                st.HasPct = d.ContainsKey("hasPct") && Convert.ToBoolean(d["hasPct"]);
                st.PctText = d.ContainsKey("pctText") ? Convert.ToString(d["pctText"] ?? "") : "";
                st.HasVideo = d.ContainsKey("hasVideo") && Convert.ToBoolean(d["hasVideo"]);
                st.HasMoreBtn = d.ContainsKey("hasMoreBtn") && Convert.ToBoolean(d["hasMoreBtn"]);
                st.HasErr = d.ContainsKey("hasErr") && Convert.ToBoolean(d["hasErr"]);
                st.IsMinorErr = d.ContainsKey("isMinorErr") && Convert.ToBoolean(d["isMinorErr"]);
                list.Add(st);
            }
            return list;
        }

        private async Task<SessionPollSnapshot> InspectCurrentSessionStateAsync(
            string sess,
            PreSessionGridBaseline baseline,
            CancellationToken ct)
        {
            // Garante que o virtual scroll esteja em scrollTop = 0 para inspecionar os cards recém-criados no topo
            string scrolledReset = await _cdp.EvalStringAsync(sess, @"
(function(){
    var vp = document.querySelector('cdk-virtual-scroll-viewport.tiles-container') || document.querySelector('cdk-virtual-scroll-viewport');
    if (vp && vp.scrollTop > 8) {
        vp.scrollTop = 0;
        return 'RESET';
    }
    return 'AT_TOP';
})()", ct);

            if (scrolledReset == "RESET")
                await Task.Delay(380, ct);

            string inspectJs = @"
(function(){
    var tiles = Array.from(document.querySelectorAll('flow-video-tile')).map((t, idx) => {
        var vid = t.querySelector('video');
        var img = t.querySelector('img.thumbnail') || t.querySelector('img');
        var mediaUrl = (img ? (img.getAttribute('src') || '') : '') + ' ' +
                       (vid ? ((vid.getAttribute('poster') || '') + ' ' + (vid.getAttribute('src') || '')) : '');
        var m = mediaUrl.match(/\/asb\/([A-Za-z0-9_\-]{25,80})/);
        var asb = m ? m[1] : '';
        var txt = (t.innerText || '');
        var pctM = txt.match(/\b\d{1,2}%\b/);
        var pctText = pctM ? pctM[0] : '';
        var hasPct = !!pctM;
        var hasMoreBtn = !!t.querySelector('button[aria-label*=""Mais op""], button[aria-label*=""More""]');
        var hasVideo = !!vid || (!!img && asb.length > 0);
        var hasErr = !hasVideo && !hasMoreBtn && !asb &&
                     /violar|pol[ií]ticas|falha|erro|n[aã]o foi poss[ií]vel|violate|failed/i.test(txt);
        var isMinorErr = hasErr &&
                     /\b(menores\s+de\s+idade|menor\s+de\s+idade|relacionado\s+a\s+menores|menores|crian[cç]as?|minors?|children|child|underage)\b/i.test(txt);
        return {
            idx: idx,
            asb: asb,
            hasPct: hasPct,
            pctText: pctText,
            hasVideo: hasVideo,
            hasMoreBtn: hasMoreBtn,
            hasErr: hasErr,
            isMinorErr: isMinorErr
        };
    });

    var panel = document.querySelector('flow-agent-panel');
    var vidOptCount = panel ? panel.querySelectorAll('flow-a2ui-video-option').length : 0;
    var chatBubbles = panel ? Array.from(panel.querySelectorAll('flow-chat-bubble')) : [];
    var bubbleCount = chatBubbles.length;

    var agentStopBtn = !!Array.from(document.querySelectorAll('flow-agent-panel button, button')).find(b => {
        var al = (b.getAttribute('aria-label') || '');
        var txt = (b.innerText || '').trim();
        var r = b.getBoundingClientRect();
        return r.width > 10 && (al.indexOf('Parar') >= 0 || al.indexOf('Stop') >= 0 || txt === 'stop' || txt === 'stop_circle');
    });

    var agentSpinner = !!(panel && Array.from(panel.querySelectorAll('mat-progress-spinner, [role=""progressbar""], .thinking-indicator'))
        .find(el => !el.closest('flow-a2ui-video-option, flow-video-tile, flow-image-tile') && el.getBoundingClientRect().width > 6));

    var panelTxt = panel ? (panel.innerText || '').toLowerCase() : '';
    var unusualMatches = panelTxt.match(/atividade incomum|unusual activity/g) || [];
    var unusualCount = unusualMatches.length;

    // Inspeciona apenas o último turno no final da sessão aberta para não disparar em avisos antigos do histórico
    var tailTxt = '';
    if (chatBubbles.length > 0) {
        var lastBubble = chatBubbles[chatBubbles.length - 1];
        tailTxt = (lastBubble.innerText || '').toLowerCase();
        if (panel) {
            Array.from(panel.querySelectorAll('div, p, span')).forEach(el => {
                if (el.closest('[role=""textbox""]') || el.querySelector('[role=""textbox""]')) return;
                if (lastBubble.contains(el)) return;
                if ((lastBubble.compareDocumentPosition(el) & Node.DOCUMENT_POSITION_FOLLOWING) !== 0) {
                    var t = (el.innerText || '').trim().toLowerCase();
                    if (t.length > 0 && t.length < 400) tailTxt += ' ' + t;
                }
            });
        }
    } else {
        tailTxt = panelTxt;
    }

    var hasUnusualActivity = tailTxt.indexOf('atividade incomum') >= 0 ||
                             tailTxt.indexOf('extensões do navegador') >= 0 ||
                             tailTxt.indexOf('extensoes do navegador') >= 0 ||
                             tailTxt.indexOf('unusual activity') >= 0;

    var retryBtns = panel ? Array.from(panel.querySelectorAll('button')).filter(b => {
        var al = (b.getAttribute('aria-label') || '').trim().toLowerCase();
        var txt = (b.innerText || '').trim().toLowerCase();
        var r = b.getBoundingClientRect();
        return r.width > 20 && r.height > 14 && !b.disabled &&
               (txt === 'tentar de novo' || txt === 'tentar novamente' || txt === 'try again' ||
                txt.indexOf('tentar de novo') >= 0 || al.indexOf('tentar de novo') >= 0 || al.indexOf('try again') >= 0);
    }) : [];
    var retryBtn = retryBtns.length > 0 ? retryBtns[retryBtns.length - 1] : null;
    if (retryBtn && panel) {
        var ownBubble = retryBtn.closest('flow-chat-bubble');
        var hasNewerNode = Array.from(panel.querySelectorAll('flow-chat-bubble, flow-a2ui-video-option')).some(n => {
            if (n === ownBubble || n.contains(retryBtn)) return false;
            return (retryBtn.compareDocumentPosition(n) & Node.DOCUMENT_POSITION_FOLLOWING) !== 0;
        });
        if (hasNewerNode) retryBtn = null;
    }

    var retryRect = retryBtn ? retryBtn.getBoundingClientRect() : null;

    return JSON.stringify({
        tiles: tiles,
        vidOptCount: vidOptCount,
        bubbleCount: bubbleCount,
        unusualCount: unusualCount,
        agentBusy: agentStopBtn || agentSpinner,
        hasUnusualActivity: hasUnusualActivity,
        hasRetryBtn: !!retryRect,
        retryX: retryRect ? Math.round(retryRect.left + retryRect.width / 2) : 0,
        retryY: retryRect ? Math.round(retryRect.top + retryRect.height / 2) : 0
    });
})()";

            Dictionary<string, object> raw = await _cdp.EvalJsonAsync(sess, inspectJs, ct);
            SessionPollSnapshot snap = new SessionPollSnapshot();
            if (raw == null) return snap;

            snap.AgentVideoOptionsCount = raw.ContainsKey("vidOptCount") ? Convert.ToInt32(raw["vidOptCount"]) : 0;
            snap.AgentChatBubblesCount = raw.ContainsKey("bubbleCount") ? Convert.ToInt32(raw["bubbleCount"]) : 0;
            snap.UnusualActivityCount = raw.ContainsKey("unusualCount") ? Convert.ToInt32(raw["unusualCount"]) : 0;
            snap.AgentBusy = raw.ContainsKey("agentBusy") && Convert.ToBoolean(raw["agentBusy"]);
            snap.AgentHasUnusualActivity = raw.ContainsKey("hasUnusualActivity") && Convert.ToBoolean(raw["hasUnusualActivity"]);
            snap.AgentHasRetryButton = raw.ContainsKey("hasRetryBtn") && Convert.ToBoolean(raw["hasRetryBtn"]);
            snap.RetryButtonX = raw.ContainsKey("retryX") ? Convert.ToInt32(raw["retryX"]) : 0;
            snap.RetryButtonY = raw.ContainsKey("retryY") ? Convert.ToInt32(raw["retryY"]) : 0;

            List<MountedGridTileState> topTiles = ParseMountedTilesFromEval(raw);

            int anchorIdx = -1;
            for (int i = 0; i < topTiles.Count; i++)
            {
                string id = topTiles[i].AsbId;
                if (!string.IsNullOrEmpty(id) && baseline.PreExistingAsbIds.Contains(id))
                {
                    anchorIdx = i;
                    break;
                }
            }

            if (anchorIdx >= 0 || baseline.PreExistingAsbIds.Count == 0 || topTiles.Count < 30)
            {
                int rawEnd = anchorIdx >= 0 ? anchorIdx : topTiles.Count;
                int sessionEnd = Math.Max(0, rawEnd - baseline.PreExistingTopFailedCount);
                snap.SessionSliceEndIndex = sessionEnd;
                List<string> pctList = new List<string>();

                for (int i = 0; i < sessionEnd; i++)
                {
                    MountedGridTileState t = topTiles[i];
                    if (t.HasPct)
                    {
                        snap.GeneratingCards++;
                        if (!string.IsNullOrEmpty(t.PctText))
                            pctList.Add(t.PctText);
                    }
                    else if (t.HasErr && !t.HasVideo)
                    {
                        snap.FailedCards++;
                        snap.FailedMountedIndices.Add(t.MountedIndex);
                        if (t.IsMinorErr)
                        {
                            snap.MinorFailedMountedIndices.Add(t.MountedIndex);
                        }
                    }
                    else if (t.HasVideo || t.HasMoreBtn || !string.IsNullOrEmpty(t.AsbId))
                    {
                        snap.CompletedCards++;
                    }
                    else
                    {
                        snap.GeneratingCards++;
                    }
                }
                snap.PctSummary = string.Join(",", pctList);
            }
            else
            {
                // Caso raro de episódio longo (>35 takes na mesma sessão) onde a âncora preexistente desceu além da 1ª janela virtualizada
                snap.SessionSliceEndIndex = topTiles.Count;
                HashSet<string> seenSessionCompletedAsbs = new HashSet<string>(StringComparer.Ordinal);
                int totalGenerating = 0;
                int totalFailed = 0;

                for (int i = 0; i < topTiles.Count; i++)
                {
                    MountedGridTileState t = topTiles[i];
                    if (t.HasPct) totalGenerating++;
                    else if (t.HasErr && !t.HasVideo)
                    {
                        totalFailed++;
                        snap.FailedMountedIndices.Add(t.MountedIndex);
                        if (t.IsMinorErr)
                            snap.MinorFailedMountedIndices.Add(t.MountedIndex);
                    }
                    else if (!string.IsNullOrEmpty(t.AsbId)) seenSessionCompletedAsbs.Add(t.AsbId);
                }

                for (int page = 1; page <= 4; page++)
                {
                    await _cdp.EvalStringAsync(sess, string.Format(@"
(function(){{
    var vp = document.querySelector('cdk-virtual-scroll-viewport.tiles-container') || document.querySelector('cdk-virtual-scroll-viewport');
    if (vp) vp.scrollTop = {0};
    return 'OK';
}})()", page * 520), ct);
                    await Task.Delay(320, ct);

                    Dictionary<string, object> pageRaw = await _cdp.EvalJsonAsync(sess, inspectJs, ct);
                    List<MountedGridTileState> pageTiles = ParseMountedTilesFromEval(pageRaw);
                    bool hitAnchor = false;
                    for (int i = 0; i < pageTiles.Count; i++)
                    {
                        MountedGridTileState pt = pageTiles[i];
                        if (!string.IsNullOrEmpty(pt.AsbId) && baseline.PreExistingAsbIds.Contains(pt.AsbId))
                        {
                            hitAnchor = true;
                            break;
                        }
                        if (!string.IsNullOrEmpty(pt.AsbId))
                            seenSessionCompletedAsbs.Add(pt.AsbId);
                    }
                    if (hitAnchor) break;
                }

                await _cdp.EvalStringAsync(sess, @"
(function(){
    var vp = document.querySelector('cdk-virtual-scroll-viewport.tiles-container') || document.querySelector('cdk-virtual-scroll-viewport');
    if (vp) vp.scrollTop = 0;
    return 'OK';
})()", ct);
                await Task.Delay(250, ct);

                int newAgentVidOpts = Math.Max(0, snap.AgentVideoOptionsCount - (baseline != null ? baseline.PreExistingAgentVideoOptionsCount : 0));
                snap.GeneratingCards = totalGenerating;
                snap.FailedCards = Math.Max(0, totalFailed - baseline.PreExistingTopFailedCount);
                snap.CompletedCards = Math.Max(seenSessionCompletedAsbs.Count, newAgentVidOpts);
            }

            snap.TotalSessionCards = snap.GeneratingCards + snap.CompletedCards + snap.FailedCards;
            return snap;
        }

        private async Task<HashSet<int>> TrySalvageCompletedTakesFromCurrentFlowScreenAsync(
            string sess,
            EpisodeWorkItem ep,
            List<FlowTakeSpec> missingFlowTakes,
            HashSet<int> existingOnDisk,
            CancellationToken ct)
        {
            HashSet<int> handledTakeNumbers = new HashSet<int>();
            if (missingFlowTakes == null || missingFlowTakes.Count == 0)
                return handledTakeNumbers;

            // Garante scroll no topo do grid
            await _cdp.EvalStringAsync(sess, @"
(function(){
    var vp = document.querySelector('cdk-virtual-scroll-viewport.tiles-container') || document.querySelector('cdk-virtual-scroll-viewport');
    if (vp && vp.scrollTop > 8) vp.scrollTop = 0;
    return 'OK';
})()", ct);
            await Task.Delay(300, ct);

            int maxInspectTiles = Math.Max(15, ep.FlowTakes.Count + 4);
            Dictionary<string, object> rawTop = await _cdp.EvalJsonAsync(sess, string.Format(@"
(function(){{
    var tiles = Array.from(document.querySelectorAll('flow-video-tile')).slice(0, {0}).map((t, idx) => {{
        var vid = t.querySelector('video');
        var img = t.querySelector('img.thumbnail') || t.querySelector('img');
        var mediaUrl = (img ? (img.getAttribute('src') || '') : '') + ' ' +
                       (vid ? ((vid.getAttribute('poster') || '') + ' ' + (vid.getAttribute('src') || '')) : '');
        var m = mediaUrl.match(/\/asb\/([A-Za-z0-9_\-]{{25,80}})/);
        var asb = m ? m[1] : '';
        var txt = (t.innerText || '');
        var hasPct = /\b\d{{1,2}}%\b/.test(txt);
        var hasMoreBtn = !!t.querySelector('button[aria-label*=""Mais op""], button[aria-label*=""More""]');
        var hasVideo = !!vid || (!!img && asb.length > 0);
        var hasErr = !hasVideo && !hasMoreBtn && !asb &&
                     /violar|pol[ií]ticas|falha|erro|n[aã]o foi poss[ií]vel|violate|failed/i.test(txt);
        return {{
            idx: idx,
            asb: asb,
            hasPct: hasPct,
            hasVideo: hasVideo,
            hasMoreBtn: hasMoreBtn,
            hasErr: hasErr
        }};
    }});
    return JSON.stringify({{ tiles: tiles }});
}})()", maxInspectTiles), ct);

            List<MountedGridTileState> topTiles = ParseMountedTilesFromEval(rawTop);
            List<MountedGridTileState> completedTiles = new List<MountedGridTileState>();
            for (int i = 0; i < topTiles.Count; i++)
            {
                MountedGridTileState st = topTiles[i];
                if (!st.HasPct && !st.HasErr && !string.IsNullOrEmpty(st.AsbId))
                    completedTiles.Add(st);
            }

            if (completedTiles.Count == 0)
                return handledTakeNumbers;

            // Inspeção 100% somente-leitura (NUNCA clica em 'Reutilizar comando', preservando intacto o estado do editor e dos chips do Agente!)
            Dictionary<string, string> promptByAsbReadOnly = new Dictionary<string, string>(StringComparer.Ordinal);
            Dictionary<string, object> rawPrompts = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var map = {};
    Array.from(document.querySelectorAll('flow-a2ui-video-option, flow-video-tile')).forEach(node => {
        var img = node.querySelector('img');
        var vid = node.querySelector('video');
        var u = (img ? (img.getAttribute('src') || '') : '') + ' ' +
                (vid ? ((vid.getAttribute('poster') || '') + ' ' + (vid.getAttribute('src') || '')) : '');
        var m = u.match(/\/asb\/([A-Za-z0-9_\-]{25,80})/);
        if (!m) return;
        var asb = m[1];
        var p = (img ? (img.getAttribute('alt') || '') : '').trim();
        if (!p && vid) p = (vid.getAttribute('aria-label') || '').trim();
        if (p && !map[asb]) map[asb] = p;
    });
    return JSON.stringify(map);
})()", ct);

            if (rawPrompts != null)
            {
                foreach (KeyValuePair<string, object> kv in rawPrompts)
                {
                    string pVal = Convert.ToString(kv.Value ?? "").Trim();
                    if (!string.IsNullOrEmpty(kv.Key) && !string.IsNullOrEmpty(pVal))
                        promptByAsbReadOnly[kv.Key] = pVal;
                }
            }

            Dictionary<int, string> salvagedAsbByTake = new Dictionary<int, string>();
            bool foundAnyFromThisEpisode = false;
            int consecutiveUnrelatedTiles = 0;

            for (int i = 0; i < completedTiles.Count; i++)
            {
                ct.ThrowIfCancellationRequested();
                MountedGridTileState st = completedTiles[i];
                string prompt;
                if (!promptByAsbReadOnly.TryGetValue(st.AsbId, out prompt) || string.IsNullOrWhiteSpace(prompt))
                    continue;

                FlowTakeSpec matchedSpec = null;
                int explicitTag = TryExtractExplicitTakeTagNumber(prompt);
                if (explicitTag > 0)
                {
                    for (int k = 0; k < ep.FlowTakes.Count; k++)
                    {
                        if (ep.FlowTakes[k].TakeNumber == explicitTag)
                        {
                            double bodySim = ComputeContentWordBigramSimilarity(
                                ExtractDistinctiveTakeBody(ep.FlowTakes[k].RawPromptBody),
                                ExtractDistinctiveTakeBody(prompt));
                            if (bodySim >= 0.30)
                            {
                                matchedSpec = ep.FlowTakes[k];
                            }
                            break;
                        }
                    }
                }

                if (matchedSpec == null)
                {
                    double bestScore = 0.0;
                    for (int k = 0; k < ep.FlowTakes.Count; k++)
                    {
                        double bodySim = ComputeContentWordBigramSimilarity(
                            ExtractDistinctiveTakeBody(ep.FlowTakes[k].RawPromptBody),
                            ExtractDistinctiveTakeBody(prompt));
                        if (bodySim > bestScore)
                        {
                            bestScore = bodySim;
                            matchedSpec = ep.FlowTakes[k];
                        }
                    }
                    if (bestScore < 0.55)
                        matchedSpec = null;
                }

                if (matchedSpec != null)
                {
                    foundAnyFromThisEpisode = true;
                    consecutiveUnrelatedTiles = 0;

                    if (!existingOnDisk.Contains(matchedSpec.TakeNumber) && !salvagedAsbByTake.ContainsKey(matchedSpec.TakeNumber))
                    {
                        salvagedAsbByTake[matchedSpec.TakeNumber] = st.AsbId;
                    }
                }
                else
                {
                    consecutiveUnrelatedTiles++;
                    if (!foundAnyFromThisEpisode && consecutiveUnrelatedTiles >= 2)
                        break;
                    if (foundAnyFromThisEpisode && consecutiveUnrelatedTiles >= 3)
                        break;
                }
            }

            if (salvagedAsbByTake.Count > 0)
            {
                List<FlowTakeSpec> toDownload = missingFlowTakes
                    .Where(t => salvagedAsbByTake.ContainsKey(t.TakeNumber))
                    .OrderBy(t => t.TakeNumber)
                    .ToList();

                string labels = string.Join(", ", toDownload.Select(t => string.Format("Take_{0:00}", t.TakeNumber)));
                _log(string.Format("[Inspeção de Takes | Google Flow] Encontrados {0} vídeos deste episódio já concluídos na tela aberta do Flow ({1}) -> baixando em 720p sem precisar regerar...",
                    toDownload.Count, labels));

                string stagingDl = Path.Combine(ep.TakesDir, "_flow_salvage_" + DateTime.Now.ToString("HHmmss"));
                Directory.CreateDirectory(stagingDl);
                await _cdp.SetDownloadBehaviorAsync(stagingDl, ct);

                for (int i = 0; i < toDownload.Count; i++)
                {
                    ct.ThrowIfCancellationRequested();
                    FlowTakeSpec spec = toDownload[i];
                    string asbId = salvagedAsbByTake[spec.TakeNumber];
                    string finalTakePath = Path.Combine(ep.TakesDir, string.Format("Take_{0:00}.mp4", spec.TakeNumber));
                    try
                    {
                        await DownloadSingleTileByAsbIdAsync(
                            sess,
                            asbId,
                            spec.TakeNumber,
                            i + 1,
                            toDownload.Count,
                            stagingDl,
                            finalTakePath,
                            ct);
                        handledTakeNumbers.Add(spec.TakeNumber);
                        existingOnDisk.Add(spec.TakeNumber);
                    }
                    catch (OperationCanceledException)
                    {
                        throw;
                    }
                    catch (Exception ex)
                    {
                        _log(string.Format("[Google Flow | Aviso] Falha ao baixar Take_{0:00}.mp4 da sessão aberta ({1}).", spec.TakeNumber, ex.Message));
                    }
                }

                try { await _cdp.ResetDownloadBehaviorToDefaultAsync(); } catch { }
                try { Directory.Delete(stagingDl, true); } catch { }
            }

            return handledTakeNumbers;
        }

        private async Task<SessionPollSnapshot> WaitForCurrentBatchToFinishAsync(
            string sess,
            PreSessionGridBaseline baseline,
            int batchNumber,
            int totalExpectedTakes,
            int baselineCardsBeforeSubmit,
            int deletedMinorCardsTotal,
            CancellationToken ct)
        {
            DateTime start = DateTime.UtcNow;
            DateTime deadline = start.AddMinutes(12);
            DateTime lastProgressUtc = DateTime.UtcNow;
            string lastProgressFingerprint = "";
            int consecutiveIdleAfterCards = 0;
            bool nudgedContinueOnce = false;
            int retryBtnClicks = 0;

            int initialBubblesAfterSubmit = -1;
            string initBubblesStr = await _cdp.EvalStringAsync(sess, @"
(function(){
    var panel = document.querySelector('flow-agent-panel');
    return panel ? String(panel.querySelectorAll('flow-chat-bubble').length) : '-1';
})()", ct);
            int parsedBubbles;
            if (int.TryParse(initBubblesStr, out parsedBubbles) && parsedBubbles >= 0)
                initialBubblesAfterSubmit = parsedBubbles;

            while (DateTime.UtcNow < deadline)
            {
                ct.ThrowIfCancellationRequested();
                await _cdp.WaitOrWakeOnReloadSignalAsync(6500, ct);

                SessionPollSnapshot snap = await InspectCurrentSessionStateAsync(sess, baseline, ct);

                string curFp = string.Format("{0}|{1}|{2}|{3}|{4}|{5}|{6}",
                    snap.TotalSessionCards,
                    snap.GeneratingCards,
                    snap.CompletedCards,
                    snap.FailedCards,
                    snap.PctSummary ?? "",
                    snap.AgentVideoOptionsCount,
                    snap.AgentChatBubblesCount);
                if (curFp != lastProgressFingerprint)
                {
                    lastProgressFingerprint = curFp;
                    lastProgressUtc = DateTime.UtcNow;
                }

                string pctInfo = !string.IsNullOrEmpty(snap.PctSummary) ? string.Format(" [{0}]", snap.PctSummary) : "";

                if (deletedMinorCardsTotal > 0)
                {
                    _log(string.Format("[Google Flow | Lote {0}] Takes na sessão: {1}/{2} (no Flow: {3} | Grok/menores: {4}) | Em geração: {5}{6} | Concluídos (100%): {7} | Erros: {8}",
                        batchNumber, snap.TotalSessionCards + deletedMinorCardsTotal, totalExpectedTakes, snap.TotalSessionCards, deletedMinorCardsTotal, snap.GeneratingCards, pctInfo, snap.CompletedCards, snap.FailedCards));
                }
                else
                {
                    _log(string.Format("[Google Flow | Lote {0}] Cards na sessão: {1}/{2} | Em geração: {3}{4} | Concluídos (100%): {5} | Erros: {6}",
                        batchNumber, snap.TotalSessionCards, totalExpectedTakes, snap.GeneratingCards, pctInfo, snap.CompletedCards, snap.FailedCards));
                }

                bool newCardsAppeared = snap.TotalSessionCards > baselineCardsBeforeSubmit;
                if (newCardsAppeared && snap.GeneratingCards == 0 && !snap.AgentBusy)
                {
                    consecutiveIdleAfterCards++;
                    if (consecutiveIdleAfterCards >= 2)
                    {
                        return snap;
                    }
                }
                else
                {
                    consecutiveIdleAfterCards = 0;

                    // Detecção automática do aviso "Notamos uma atividade incomum... [Tentar de novo]" no painel do Agente
                    if (!newCardsAppeared && snap.GeneratingCards == 0 && !snap.AgentBusy &&
                        (snap.AgentHasRetryButton || snap.AgentHasUnusualActivity))
                    {
                        if (snap.AgentHasRetryButton && retryBtnClicks < 2 && snap.RetryButtonX > 0 && snap.RetryButtonY > 0)
                        {
                            retryBtnClicks++;
                            _log(string.Format("[Google Flow | Lote {0}] Aviso de 'atividade incomum' detectado no Agente -> aguardando 4s e clicando em 'Tentar de novo' (tentativa {1}/2)...",
                                batchNumber, retryBtnClicks));
                            await Task.Delay(4000, ct);
                            await _cdp.ClickAtAsync(sess, snap.RetryButtonX, snap.RetryButtonY, ct);
                            await Task.Delay(2500, ct);
                            lastProgressUtc = DateTime.UtcNow;
                            continue;
                        }
                        else
                        {
                            snap.AgentBlockedByUnusualActivity = true;
                            _log("[Google Flow -> Grok] O painel do Agente do Google Flow permaneceu com aviso de 'atividade incomum' após tentar novamente -> transferindo automaticamente os takes restantes para o Grok Vídeo (9:16)!");
                            return snap;
                        }
                    }

                    // Watchdog de Travamento no Google Flow ou Clique Manual no botão 'Recarregar e Continuar'
                    string manualReason;
                    bool manualReload = _cdp.ConsumeReloadAndResumeRequest(out manualReason);
                    double stalledSec = (DateTime.UtcNow - lastProgressUtc).TotalSeconds;

                    if (manualReload || (stalledSec >= 105 && batchNumber < 90))
                    {
                        string why = manualReload
                            ? manualReason
                            : string.Format("sem avanço de porcentagem/cards por {0:0}s", stalledSec);
                        _log(string.Format("[Recuperação | Histórico] Travamento detectado no Google Flow (Lote {0}: {1}). Recarregando a página do Flow e retomando com base no histórico da última ação...",
                            batchNumber, why));

                        await _cdp.ReloadPageAndWaitReadyAsync(sess, 30000, ct);
                        await WaitForFlowPageLoadedAsync(sess, ct);

                        SessionPollSnapshot reloadedSnap = await InspectCurrentSessionStateAsync(sess, baseline, ct);
                        reloadedSnap.PageReloadedDuringWait = true;
                        return reloadedSnap;
                    }

                    double elapsedSec = (DateTime.UtcNow - start).TotalSeconds;
                    bool agentRepliedOnlyText = initialBubblesAfterSubmit >= 0 &&
                                                snap.AgentChatBubblesCount > initialBubblesAfterSubmit &&
                                                elapsedSec >= 20;

                    // Nos lotes de reciclagem (Lote 91 / Lote 92), se nenhum card novo surgiu e o Agente já ficou ocioso (ex.: erro 'Media not found' no chat), encerra imediatamente sem travar!
                    if (!newCardsAppeared && snap.GeneratingCards == 0 && !snap.AgentBusy &&
                        batchNumber >= 90 && (agentRepliedOnlyText || elapsedSec >= 25))
                    {
                        _log(string.Format("[Google Flow | Lote {0}] Tentativa encerrada sem novo card em geração ({1:0}s) -> prosseguindo...", batchNumber, elapsedSec));
                        return snap;
                    }

                    // Se em um lote 'continue' o Agente respondeu apenas em texto (ex.: 'Como deseja proceder?') ou não iniciou cards após 95s, envia reforço único
                    if (!newCardsAppeared && !snap.AgentBusy && !nudgedContinueOnce &&
                        batchNumber >= 2 && batchNumber < 90 &&
                        (agentRepliedOnlyText || elapsedSec >= 95))
                    {
                        nudgedContinueOnce = true;
                        _log(string.Format("[Google Flow | Lote {0}] Agente aguardando confirmação sem iniciar cards -> reforçando avanço imediato dos próximos takes...", batchNumber));
                        await InsertTextIntoFlowTextboxAsync(sess, "Ignore quaisquer falhas anteriores (já resolvidas) e inicie imediatamente a geração em vídeo dos próximos takes pendentes na sequência exata do roteiro, mantendo obrigatoriamente a tag exata [TAKE_XX] no início do prompt de cada vídeo.", true, ct);
                        await Task.Delay(500, ct);
                        await ClickStartGenerationAsync(sess, ct);
                    }
                }
            }

            throw new TimeoutException(string.Format("Timeout aguardando término do Lote {0} no Google Flow.", batchNumber));
        }

        private async Task<FlowTakeSpec> ResolveMinorFailedTakeSpecAsync(
            string sess,
            PreSessionGridBaseline baseline,
            EpisodeWorkItem ep,
            string reusedPrompt,
            List<FlowTakeSpec> flowEligibleTakes,
            HashSet<int> minorHandledTakeNumbers,
            int batchStartTakeIndex,
            int batchExpectedCount,
            CancellationToken ct)
        {
            if (flowEligibleTakes == null || flowEligibleTakes.Count == 0)
                return null;

            int batchEndExclusive = Math.Min(flowEligibleTakes.Count, Math.Max(0, batchStartTakeIndex) + Math.Max(1, batchExpectedCount));

            if (!string.IsNullOrWhiteSpace(reusedPrompt))
            {
                FlowTakeSpec bestSpec = null;
                double bestScore = 0.0;

                for (int i = 0; i < flowEligibleTakes.Count; i++)
                {
                    FlowTakeSpec candidate = flowEligibleTakes[i];
                    if (minorHandledTakeNumbers != null && minorHandledTakeNumbers.Contains(candidate.TakeNumber))
                        continue;

                    double s = ComputeTakeToVideoMatchScore(candidate, reusedPrompt);
                    // Em caso de empate técnico muito próximo, prioriza take pertencente à janela do lote atual
                    bool inBatchWindow = (i >= batchStartTakeIndex && i < batchEndExclusive);
                    double effectiveScore = inBatchWindow ? (s + 0.015) : s;

                    if (effectiveScore > bestScore)
                    {
                        bestScore = effectiveScore;
                        bestSpec = candidate;
                    }
                }

                if (bestSpec != null && bestScore >= 0.36)
                    return bestSpec;
            }

            // Fallback: identifica quais takes da janela do lote atual ainda não têm vídeo concluído no painel do Agente nem .mp4 salvo em disco
            List<SessionCompletedVideoInfo> completedVids = await CollectSessionVideosFromAgentPanelAsync(sess, baseline, ct);
            HashSet<int> completedTakeNums = new HashSet<int>();
            for (int v = 0; v < completedVids.Count; v++)
            {
                int tNum = IdentifyTakeNumberFromPrompt(completedVids[v].AltPrompt, flowEligibleTakes);
                if (tNum > 0)
                    completedTakeNums.Add(tNum);
            }

            for (int i = Math.Max(0, batchStartTakeIndex); i < batchEndExclusive; i++)
            {
                FlowTakeSpec candidate = flowEligibleTakes[i];
                if (minorHandledTakeNumbers != null && minorHandledTakeNumbers.Contains(candidate.TakeNumber))
                    continue;
                if (completedTakeNums.Contains(candidate.TakeNumber))
                    continue;

                string mp4Path = Path.Combine(ep.TakesDir, string.Format("Take_{0:00}.mp4", candidate.TakeNumber));
                if (File.Exists(mp4Path) && new FileInfo(mp4Path).Length >= 50 * 1024)
                    continue;

                return candidate;
            }

            return null;
        }

        private async Task<bool> DeleteMinorErrorCardInFlowAsync(
            string sess,
            PreSessionGridBaseline baseline,
            int preferredMountedIdx,
            CancellationToken ct)
        {
            SessionPollSnapshot beforeSnap = await InspectCurrentSessionStateAsync(sess, baseline, ct);
            int beforeMinorCount = beforeSnap.MinorFailedMountedIndices.Count;
            if (beforeMinorCount == 0)
                return true;

            int targetIdx = beforeSnap.MinorFailedMountedIndices.Contains(preferredMountedIdx)
                ? preferredMountedIdx
                : beforeSnap.MinorFailedMountedIndices[0];

            // 1ª tentativa: clique via coordenadas CDP no botão 'Excluir' (delete_forever) do card de menores
            await ClickFailedTileActionButtonAsync(sess, targetIdx, beforeSnap.SessionSliceEndIndex, true, true, ct);
            await Task.Delay(850, ct);

            // Se aparecer algum diálogo de confirmação no overlay, confirma imediatamente
            await _cdp.EvalStringAsync(sess, @"
(function(){
    var dlgBtns = Array.from(document.querySelectorAll('mat-dialog-container button, [role=""dialog""] button, [role=""alertdialog""] button'));
    var confirmBtn = dlgBtns.find(b => {
        var t = ((b.innerText || '') + ' ' + (b.getAttribute('aria-label') || '')).toLowerCase();
        return t.indexOf('excluir') >= 0 || t.indexOf('delete') >= 0 || t.indexOf('confirm') >= 0 || t.indexOf('remover') >= 0;
    });
    if (confirmBtn) { confirmBtn.click(); return 'CONFIRMED'; }
    return 'NONE';
})()", ct);

            SessionPollSnapshot afterSnap = await InspectCurrentSessionStateAsync(sess, baseline, ct);
            if (afterSnap.MinorFailedMountedIndices.Count < beforeMinorCount)
                return true;

            // 2ª tentativa (fallback): aciona .click() nativo direto no botão 'Excluir' (delete_forever) do card de menores
            int fallbackTargetIdx = afterSnap.MinorFailedMountedIndices.Contains(preferredMountedIdx)
                ? preferredMountedIdx
                : (afterSnap.MinorFailedMountedIndices.Count > 0 ? afterSnap.MinorFailedMountedIndices[0] : 0);

            await _cdp.EvalStringAsync(sess, string.Format(@"
(function(){{
    var tiles = Array.from(document.querySelectorAll('flow-video-tile'));
    var limit = Math.min(tiles.length, {1});
    function isMinorErr(el) {{
        if (!el) return false;
        var hasMore = !!el.querySelector('button[aria-label*=""Mais op""], button[aria-label*=""More""]');
        var hasThumb = !!(el.querySelector('img.thumbnail') || el.querySelector('video'));
        if (hasMore || hasThumb) return false;
        var txt = (el.innerText || '');
        return /violar|pol[ií]ticas|falha|erro|n[aã]o foi poss[ií]vel|violate|failed/i.test(txt) &&
               /\b(menores\s+de\s+idade|menor\s+de\s+idade|relacionado\s+a\s+menores|menores|crian[cç]as?|minors?|children|child|underage)\b/i.test(txt);
    }}
    var t = ({0} < limit && isMinorErr(tiles[{0}])) ? tiles[{0}] : null;
    if (!t) {{
        for (var i = 0; i < limit; i++) {{
            if (isMinorErr(tiles[i])) {{ t = tiles[i]; break; }}
        }}
    }}
    if (!t) return 'NO_TILE';
    var btn = Array.from(t.querySelectorAll('button')).find(b => {{
        var al = (b.getAttribute('aria-label') || '');
        var txt = (b.innerText || '').trim();
        return al.indexOf('Excluir') >= 0 || al.indexOf('Delete') >= 0 || txt.indexOf('delete') >= 0;
    }});
    if (!btn) return 'NO_BTN';
    btn.click();
    return 'CLICKED';
}})()", fallbackTargetIdx, Math.Max(1, afterSnap.SessionSliceEndIndex)), ct);

            await Task.Delay(850, ct);
            SessionPollSnapshot afterFallbackSnap = await InspectCurrentSessionStateAsync(sess, baseline, ct);
            return afterFallbackSnap.MinorFailedMountedIndices.Count < beforeMinorCount;
        }

        private async Task<int> HandleMinorPolicyFailedTakesAsync(
            string sess,
            PreSessionGridBaseline baseline,
            EpisodeWorkItem ep,
            List<FlowTakeSpec> flowEligibleTakes,
            Dictionary<string, string> ingredientToResolvedName,
            HashSet<int> minorHandledTakeNumbers,
            int batchStartTakeIndex,
            int batchExpectedCount,
            CancellationToken ct)
        {
            if (_config.AreAllGrokProfilesMarkedExhausted())
                return 0;

            int deletedCount = 0;
            int safetyLimit = Math.Max(6, (flowEligibleTakes != null ? flowEligibleTakes.Count : 6) + 4);

            for (int guard = 0; guard < safetyLimit; guard++)
            {
                ct.ThrowIfCancellationRequested();
                if (_config.AreAllGrokProfilesMarkedExhausted())
                    break;

                SessionPollSnapshot snap = await InspectCurrentSessionStateAsync(sess, baseline, ct);
                if (snap.MinorFailedMountedIndices.Count == 0)
                    break;

                int minorMountedIdx = snap.MinorFailedMountedIndices[0];
                int sessionSliceLimit = snap.SessionSliceEndIndex;

                // 1. Lê o comando exato do card bloqueado por menores clicando em 'Reutilizar comando' (↩) e limpa a caixa do Flow logo em seguida
                string reusedPrompt = "";
                bool clickedReuse = await ClickFailedTileActionButtonAsync(sess, minorMountedIdx, sessionSliceLimit, false, true, ct);
                if (clickedReuse)
                {
                    await Task.Delay(900, ct);
                    reusedPrompt = await ReadCurrentFlowTextboxAsync(sess, ct);
                    await InsertTextIntoFlowTextboxAsync(sess, "", true, ct);
                    await ClearAttachedPromptChipsAsync(sess, ct);
                }

                FlowTakeSpec matchedTake = await ResolveMinorFailedTakeSpecAsync(
                    sess,
                    baseline,
                    ep,
                    reusedPrompt,
                    flowEligibleTakes,
                    minorHandledTakeNumbers,
                    batchStartTakeIndex,
                    batchExpectedCount,
                    ct);

                // 2. Gera imediatamente a cena no Grok Vídeo
                if (matchedTake != null)
                {
                    string expectedMp4 = Path.Combine(ep.TakesDir, string.Format("Take_{0:00}.mp4", matchedTake.TakeNumber));
                    bool alreadyHasValidMp4 = File.Exists(expectedMp4) && new FileInfo(expectedMp4).Length >= 50 * 1024;
                    if (!alreadyHasValidMp4)
                    {
                        _log(string.Format("[Flow -> Grok | Menores] Take_{0:00} não foi gerado no Google Flow por política de menores de idade -> gerando cena no Grok Vídeo...",
                            matchedTake.TakeNumber));
                        await _grok.GenerateVideoTakesAsync(
                            ep,
                            new List<FlowTakeSpec> { matchedTake },
                            ingredientToResolvedName,
                            ct);
                    }

                    bool hasMp4Now = File.Exists(expectedMp4) && new FileInfo(expectedMp4).Length >= 50 * 1024;
                    try { await _cdp.SendCommandAsync("Page.bringToFront", null, sess, 10000, ct); } catch { }
                    await Task.Delay(500, ct);

                    if (!hasMp4Now && _config.AreAllGrokProfilesMarkedExhausted())
                    {
                        _log(string.Format("[Grok Sem Créditos -> Flow] Todas as contas Grok ficaram sem créditos ao tentar o Take_{0:00}. Mantendo o card no Google Flow para tentar 1ª vez, 2ª suavizada ou pular...",
                            matchedTake.TakeNumber));
                        break;
                    }

                    if (minorHandledTakeNumbers != null)
                        minorHandledTakeNumbers.Add(matchedTake.TakeNumber);
                }
                else
                {
                    _log(string.Format("[Flow -> Grok | Menores] Card #{0} bloqueado por política de menores de idade -> será gerado no Grok Vídeo.",
                        minorMountedIdx + 1));
                }

                // 3. Deleta o card de erro no Google Flow e prossegue
                bool deletedOk = await DeleteMinorErrorCardInFlowAsync(sess, baseline, minorMountedIdx, ct);
                if (deletedOk)
                {
                    deletedCount++;
                    _log(string.Format("[Google Flow | Menores] Erro de menores excluído no Google Flow{0}. Prosseguindo...",
                        matchedTake != null ? string.Format(" (Take_{0:00})", matchedTake.TakeNumber) : ""));
                }
                else
                {
                    _log("[Google Flow | Aviso] Não foi possível confirmar a exclusão do card de erro de menores no Google Flow. Prosseguindo...");
                    break;
                }
            }

            return deletedCount;
        }

        private async Task HandleFailedTakesStrictlyAsync(
            string sess,
            PreSessionGridBaseline baseline,
            EpisodeWorkItem ep,
            List<FlowTakeSpec> targetTakes,
            Dictionary<string, string> ingredientToResolvedName,
            HashSet<int> minorHandledTakeNumbers,
            HashSet<int> skippedTakeNumbersOut,
            CancellationToken ct)
        {
            // Regra 16 (somente nos cards desta Nova sessão!):
            // Se houver card com erro de menores de idade (e Grok tiver créditos), gera direto no Grok e deleta o erro no Flow sem retentar!
            // Quando Grok está sem créditos (ou para demais erros): 1ª TENTATIVA OBRIGATÓRIA sem alterar o texto; 2ª TENTATIVA com suavização anti-bloqueio; se ainda falhar sem créditos no Grok, pula a cena!
            Dictionary<string, int> promptRetryCounts = new Dictionary<string, int>(StringComparer.Ordinal);
            int maxOperations = Math.Max(6, targetTakes.Count * 2 + 2);

            for (int op = 0; op < maxOperations; op++)
            {
                ct.ThrowIfCancellationRequested();
                SessionPollSnapshot snap = await InspectCurrentSessionStateAsync(sess, baseline, ct);
                if (snap.FailedCards == 0 || snap.FailedMountedIndices.Count == 0)
                    return;

                if (snap.MinorFailedMountedIndices.Count > 0 && !_config.AreAllGrokProfilesMarkedExhausted())
                {
                    int delMinor = await HandleMinorPolicyFailedTakesAsync(
                        sess,
                        baseline,
                        ep,
                        targetTakes,
                        ingredientToResolvedName,
                        minorHandledTakeNumbers,
                        0,
                        targetTakes.Count,
                        ct);
                    if (delMinor > 0)
                        continue;
                }

                int failedMountedIdx = snap.FailedMountedIndices[0];
                int sessionSliceLimit = snap.SessionSliceEndIndex;

                bool clickedReuse = await ClickFailedTileActionButtonAsync(sess, failedMountedIdx, sessionSliceLimit, false, false, ct);
                if (!clickedReuse)
                {
                    _log(string.Format("[Google Flow] Aviso: botão 'Reutilizar comando' não localizado no card com erro (idx {0}).", failedMountedIdx));
                    break;
                }

                await Task.Delay(950, ct);
                string reusedPrompt = await ReadCurrentFlowTextboxAsync(sess, ct);
                int explicitFailedTag = TryExtractExplicitTakeTagNumber(reusedPrompt);
                int matchedTakeNum = explicitFailedTag > 0
                    ? explicitFailedTag
                    : IdentifyTakeNumberFromPrompt(reusedPrompt, targetTakes);
                string distinctiveKey = matchedTakeNum > 0
                    ? ("take_num_" + matchedTakeNum)
                    : EpisodeParser.NormalizeForCompare(ExtractDistinctiveTakeBody(reusedPrompt));
                if (string.IsNullOrEmpty(distinctiveKey))
                    distinctiveKey = "card_slot_" + failedMountedIdx;

                string takeLabel = matchedTakeNum > 0
                    ? string.Format("Take {0:00}", matchedTakeNum)
                    : string.Format("Card #{0}", failedMountedIdx + 1);

                int prevRetries;
                if (!promptRetryCounts.TryGetValue(distinctiveKey, out prevRetries))
                    prevRetries = 0;

                if (prevRetries >= 2)
                {
                    if (_config.AreAllGrokProfilesMarkedExhausted())
                    {
                        if (matchedTakeNum > 0 && skippedTakeNumbersOut != null)
                            skippedTakeNumbersOut.Add(matchedTakeNum);
                        _log(string.Format("[Google Flow | Cena Pulada] {0} falhou após a 1ª tentativa e a 2ª tentativa suavizada no Google Flow (e o Grok está sem créditos) -> pulando cena e removendo card com erro...", takeLabel));
                    }
                    else
                    {
                        _log(string.Format("[Google Flow -> Grok] {0} falhou após as 2 tentativas padrões no Google Flow. Limpando card com erro residual para gerar no Grok Vídeo...", takeLabel));
                    }
                    await InsertTextIntoFlowTextboxAsync(sess, "", true, ct);
                    await ClearAttachedPromptChipsAsync(sess, ct);
                    await ClickFailedTileActionButtonAsync(sess, failedMountedIdx, sessionSliceLimit, true, false, ct);
                    await Task.Delay(500, ct);
                    continue;
                }

                int currentAttemptNumber = prevRetries + 1;
                promptRetryCounts[distinctiveKey] = currentAttemptNumber;

                if (currentAttemptNumber == 1)
                {
                    _log(string.Format("[Google Flow | Regra 16] {0} apresentou erro -> 1ª TENTATIVA OBRIGATÓRIA: 'Reutilizar comando' (↩) e regerando SEM ALTERAR O TEXTO!", takeLabel));
                    if (explicitFailedTag == 0 && matchedTakeNum > 0)
                    {
                        string taggedRetry1 = InjectTakeTagIntoPromptBody(reusedPrompt, matchedTakeNum);
                        await InsertTextIntoFlowTextboxAsync(sess, taggedRetry1, true, ct);
                        await Task.Delay(400, ct);
                    }
                }
                else
                {
                    _log(string.Format("[Google Flow | Regra 16] {0} falhou novamente após 1ª regeneração -> 2ª TENTATIVA: 'Reutilizar comando' (↩) com suavização anti-bloqueio...", takeLabel));
                    string softened = SoftenPromptForSecondAttempt(reusedPrompt);
                    if (matchedTakeNum > 0)
                    {
                        softened = InjectTakeTagIntoPromptBody(softened, matchedTakeNum);
                        promptRetryCounts["take_num_" + matchedTakeNum] = 2;
                    }
                    string softenedKey = EpisodeParser.NormalizeForCompare(ExtractDistinctiveTakeBody(softened));
                    if (!string.IsNullOrEmpty(softenedKey))
                        promptRetryCounts[softenedKey] = 2;

                    await InsertTextIntoFlowTextboxAsync(sess, softened, true, ct);
                    await Task.Delay(550, ct);
                }

                // IMPORTANTE (Opção 2): NÃO excluir o card antes do envio da tentativa (excluir antes apaga a referência de mídia e causa 'Media not found'!).
                int baselineBeforeRetrySubmit = snap.TotalSessionCards;
                int minorDeletedSoFar = minorHandledTakeNumbers != null ? minorHandledTakeNumbers.Count : 0;

                await ClickStartGenerationAsync(sess, ct);
                try
                {
                    SessionPollSnapshot afterRetrySnap = await WaitForCurrentBatchToFinishAsync(
                        sess,
                        baseline,
                        90 + currentAttemptNumber,
                        targetTakes.Count,
                        baselineBeforeRetrySubmit,
                        minorDeletedSoFar,
                        ct);

                    // Se a tentativa criou um novo card no grid (concluído ou novo erro), remove o card de erro antigo para não duplicar.
                    // Quando o novo card também falha, ele entra em FailedMountedIndices[0] e o erro antigo desloca para FailedMountedIndices[1].
                    // Quando o novo card conclui com sucesso, o erro antigo permanece em FailedMountedIndices[0].
                    if (afterRetrySnap.TotalSessionCards > baselineBeforeRetrySubmit && afterRetrySnap.FailedMountedIndices.Count > 0)
                    {
                        bool newCardAlsoFailed = afterRetrySnap.FailedCards > snap.FailedCards;
                        int oldErrorIdx = (newCardAlsoFailed && afterRetrySnap.FailedMountedIndices.Count > 1)
                            ? afterRetrySnap.FailedMountedIndices[1]
                            : afterRetrySnap.FailedMountedIndices[0];
                        await ClickFailedTileActionButtonAsync(sess, oldErrorIdx, afterRetrySnap.SessionSliceEndIndex, true, false, ct);
                        await Task.Delay(500, ct);
                    }
                }
                catch (OperationCanceledException)
                {
                    throw;
                }
                catch (Exception ex)
                {
                    _log(string.Format("[Google Flow | Aviso] Falha ao aguardar regeneração de {0} ({1}). Prosseguindo...", takeLabel, ex.Message));
                    break;
                }
            }
        }

        private async Task<bool> ClickFailedTileActionButtonAsync(
            string sess,
            int preferredMountedIdx,
            int sessionSliceLimit,
            bool clickDeleteInsteadOfReuse,
            bool requireMinorError,
            CancellationToken ct)
        {
            string wantDeleteJs = clickDeleteInsteadOfReuse ? "true" : "false";
            string requireMinorJs = requireMinorError ? "true" : "false";

            // Garante scrollTop = 0 para que o índice dentro da fatia da sessão seja exato
            await _cdp.EvalStringAsync(sess, @"
(function(){
    var vp = document.querySelector('cdk-virtual-scroll-viewport.tiles-container') || document.querySelector('cdk-virtual-scroll-viewport');
    if (vp && vp.scrollTop > 8) vp.scrollTop = 0;
    return 'OK';
})()", ct);
            await Task.Delay(250, ct);

            Dictionary<string, object> tileCenter = await _cdp.EvalJsonAsync(sess, string.Format(@"
(function(){{
    var requireMinor = {2};
    var tiles = Array.from(document.querySelectorAll('flow-video-tile'));
    var limit = Math.min(tiles.length, {1});
    var t = ({0} < limit) ? tiles[{0}] : null;
    function isErr(el) {{
        if (!el) return false;
        var hasMore = !!el.querySelector('button[aria-label*=""Mais op""], button[aria-label*=""More""]');
        var hasThumb = !!(el.querySelector('img.thumbnail') || el.querySelector('video'));
        if (hasMore || hasThumb) return false;
        var txt = (el.innerText || '');
        if (!/violar|pol[ií]ticas|falha|erro|n[aã]o foi poss[ií]vel|violate|failed/i.test(txt)) return false;
        if (requireMinor) {{
            return /\b(menores\s+de\s+idade|menor\s+de\s+idade|relacionado\s+a\s+menores|menores|crian[cç]as?|minors?|children|child|underage)\b/i.test(txt);
        }}
        return true;
    }}
    if (!isErr(t)) {{
        t = null;
        for (var i = 0; i < limit; i++) {{
            if (isErr(tiles[i])) {{ t = tiles[i]; break; }}
        }}
    }}
    if (!t) return null;
    var r = t.getBoundingClientRect();
    if (r.top < 40 || r.bottom > window.innerHeight - 20) {{
        t.scrollIntoView({{ block: 'center' }});
        r = t.getBoundingClientRect();
    }}
    return JSON.stringify({{ x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) }});
}})()", preferredMountedIdx, Math.Max(1, sessionSliceLimit), requireMinorJs), ct);

            if (tileCenter == null) return false;

            await Task.Delay(350, ct);
            await _cdp.HoverAsync(sess, Convert.ToInt32(tileCenter["x"]), Convert.ToInt32(tileCenter["y"]), ct);
            await Task.Delay(350, ct);

            Dictionary<string, object> btnPt = await _cdp.EvalJsonAsync(sess, string.Format(@"
(function(){{
    var wantDelete = {2};
    var requireMinor = {3};
    var tiles = Array.from(document.querySelectorAll('flow-video-tile'));
    var limit = Math.min(tiles.length, {1});
    function isErr(el) {{
        if (!el) return false;
        var hasMore = !!el.querySelector('button[aria-label*=""Mais op""], button[aria-label*=""More""]');
        var hasThumb = !!(el.querySelector('img.thumbnail') || el.querySelector('video'));
        if (hasMore || hasThumb) return false;
        var txt = (el.innerText || '');
        if (!/violar|pol[ií]ticas|falha|erro|n[aã]o foi poss[ií]vel|violate|failed/i.test(txt)) return false;
        if (requireMinor) {{
            return /\b(menores\s+de\s+idade|menor\s+de\s+idade|relacionado\s+a\s+menores|menores|crian[cç]as?|minors?|children|child|underage)\b/i.test(txt);
        }}
        return true;
    }}
    var t = ({0} < limit && isErr(tiles[{0}])) ? tiles[{0}] : null;
    if (!t) {{
        for (var i = 0; i < limit; i++) {{
            if (isErr(tiles[i])) {{ t = tiles[i]; break; }}
        }}
    }}
    if (!t) return null;
    var btn = Array.from(t.querySelectorAll('button')).find(b => {{
        var al = (b.getAttribute('aria-label') || '');
        var txt = (b.innerText || '').trim();
        if (wantDelete) {{
            return al.indexOf('Excluir') >= 0 || al.indexOf('Delete') >= 0 || txt.indexOf('delete') >= 0;
        }}
        return al.indexOf('Reutilizar comando') >= 0 || al.indexOf('Reuse') >= 0 || txt === 'replay' || txt === 'undo';
    }});
    if (!btn) return null;
    var r = btn.getBoundingClientRect();
    if (r.width < 5) return null;
    return JSON.stringify({{ x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) }});
}})()", preferredMountedIdx, Math.Max(1, sessionSliceLimit), wantDeleteJs, requireMinorJs), ct);

            if (btnPt == null) return false;
            await _cdp.ClickAtAsync(sess, Convert.ToInt32(btnPt["x"]), Convert.ToInt32(btnPt["y"]), ct);
            return true;
        }

        private string SoftenPromptForSecondAttempt(string text)
        {
            if (string.IsNullOrEmpty(text)) return text;

            // Protege nomes de arquivos de ingredientes (.jpg/.jpeg/.png/.webp) para não alterar as referências anexadas
            List<string> protectedFiles = new List<string>();
            string s = Regex.Replace(text, @"\b[^\s,;:""'\(\)\[\]<>]+?\.(?:jpg|jpeg|png|webp)\b", m =>
            {
                string token = "__FLOW_ASSET_TOKEN_" + protectedFiles.Count + "__";
                protectedFiles.Add(m.Value);
                return token;
            }, RegexOptions.IgnoreCase);

            var phraseReplacements = new Tuple<string, string>[]
            {
                Tuple.Create("proporções corporais adultas", "proporções corporais de adultos maduros (acima de 30 anos)"),
                Tuple.Create("derruba uma cadeira", "se afasta da mesa apontando para a porta"),
                Tuple.Create("arremessa a cadeira", "aponta a mão com firmeza para a porta"),
                Tuple.Create("bate com força na mesa", "apoia as mãos com firmeza na mesa"),
                Tuple.Create("vender uma cria", "negociar um animal dessa sua linhagem"),
                Tuple.Create("comprar uma cria", "negociar um cavalo forte dessa sua fazenda"),
                Tuple.Create("agiota", "cobrador"),
                Tuple.Create("prestamista", "cobrador"),
                Tuple.Create("ameaçou", "disse que perderemos"),
                Tuple.Create("amenazó", "dijo que perderemos"),
                Tuple.Create("sua alma será só minha", "cobrarei a promessa combinada"),
                Tuple.Create("olhos faiscando de exaustão e revolta", "olhar expressivo de cansaço e indignação"),
                Tuple.Create("olhar fulminante", "olhar sério e firme"),
                Tuple.Create("choque e raiva", "espanto e indignação"),
                Tuple.Create("camisola modesta", "roupa caseira comprida"),
                Tuple.Create("em pânico sutil", "com nervosismo visível"),
                Tuple.Create("em pânico", "com expressão surpresa"),
                Tuple.Create("fúria", "indignação intensa"),
                Tuple.Create("menor de idade", "jovem adulto"),
                Tuple.Create("menores de idade", "jovens adultos"),
                Tuple.Create("filho pequeno", "filho jovem"),
                Tuple.Create("filha pequena", "filha jovem"),
                Tuple.Create("neto pequeno", "neto jovem"),
                Tuple.Create("neta pequena", "neta jovem"),
                Tuple.Create("irmão pequeno", "irmão mais novo"),
                Tuple.Create("irmã pequena", "irmã mais nova"),
                Tuple.Create("criança pequena", "pessoa jovem de estatura baixa"),
                Tuple.Create("recém-nascido", "pequeno embrulho de manta"),
                Tuple.Create("bebê de colo", "pequeno embrulho de manta no colo")
            };

            foreach (var rep in phraseReplacements)
            {
                s = Regex.Replace(s, Regex.Escape(rep.Item1), rep.Item2, RegexOptions.IgnoreCase);
            }

            // Suaviza referências diretas a idade infantil ("de 7 anos", "de 10 anos de idade", etc.)
            s = Regex.Replace(s, @"\b(?:de\s+)?(?:[1-9]|1[0-7])\s+anos(?:\s+de\s+idade)?\b", "jovem adulto", RegexOptions.IgnoreCase);

            // Suaviza substantivos infantis e termos de sofrimento/violência intensa que acionam filtro de menores no Google Flow
            var wordReplacements = new Tuple<string, string>[]
            {
                Tuple.Create(@"\bcrianças\b", "jovens"),
                Tuple.Create(@"\bcriança\b", "jovem"),
                Tuple.Create(@"\bmeninos\b", "rapazes jovens"),
                Tuple.Create(@"\bmenino\b", "rapaz jovem"),
                Tuple.Create(@"\bmeninas\b", "moças jovens"),
                Tuple.Create(@"\bmenina\b", "moça jovem"),
                Tuple.Create(@"\bgarotos\b", "rapazes jovens"),
                Tuple.Create(@"\bgaroto\b", "rapaz jovem"),
                Tuple.Create(@"\bgarotas\b", "moças jovens"),
                Tuple.Create(@"\bgarota\b", "moça jovem"),
                Tuple.Create(@"\bguris\b", "rapazes jovens"),
                Tuple.Create(@"\bguri\b", "rapaz jovem"),
                Tuple.Create(@"\bpirralho\b", "rapaz"),
                Tuple.Create(@"\bpirralha\b", "moça"),
                Tuple.Create(@"\bbebê\b", "pequeno embrulho"),
                Tuple.Create(@"\bbebês\b", "pequenos embrulhos"),
                Tuple.Create(@"\binfantil\b", "juvenil"),
                Tuple.Create(@"\binfantis\b", "juvenis"),
                Tuple.Create(@"\bchorando\s+muito\b", "com expressão emocionada"),
                Tuple.Create(@"\bchorando\b", "com olhar entristecido"),
                Tuple.Create(@"\bchora\b", "abaixa o olhar emocionado"),
                Tuple.Create(@"\bchorar\b", "se emocionar"),
                Tuple.Create(@"\bsoluçando\b", "respirando fundo emocionado"),
                Tuple.Create(@"\blágrimas\b", "emoção no olhar"),
                Tuple.Create(@"\bassustado\b", "surpreso"),
                Tuple.Create(@"\bassustada\b", "surpresa"),
                Tuple.Create(@"\baterrorizado\b", "muito surpreso"),
                Tuple.Create(@"\baterrorizada\b", "muito surpresa"),
                Tuple.Create(@"\bhumilhado\b", "constrangido"),
                Tuple.Create(@"\bhumilhada\b", "constrangida"),
                Tuple.Create(@"\bgritando\b", "falando com voz firme"),
                Tuple.Create(@"\bgrita\b", "fala com firmeza"),
                Tuple.Create(@"\bempurra\b", "afasta o braço"),
                Tuple.Create(@"\bameaça\b", "avisa seriamente"),
                Tuple.Create(@"\bviolência\b", "tensão dramática"),
                Tuple.Create(@"\bsangue\b", "mancha escura")
            };

            foreach (var wrep in wordReplacements)
            {
                s = Regex.Replace(s, wrep.Item1, wrep.Item2, RegexOptions.IgnoreCase);
            }

            for (int i = 0; i < protectedFiles.Count; i++)
            {
                s = s.Replace("__FLOW_ASSET_TOKEN_" + i + "__", protectedFiles[i]);
            }

            return s;
        }

        private sealed class TakeVideoMatchCandidate
        {
            public int TakeIndex;
            public int VideoIndex;
            public string AsbId;
            public double RawScore;
            public int ScoreBucket;
        }

        private static readonly HashSet<string> PtStopWords = new HashSet<string>(StringComparer.Ordinal)
        {
            "de", "da", "do", "das", "dos", "em", "no", "na", "nos", "nas",
            "um", "uma", "uns", "umas", "com", "por", "pro", "pra", "para",
            "que", "ao", "aos", "as", "os", "se", "ou", "mas", "seu", "sua",
            "seus", "suas", "ele", "ela", "eles", "elas", "sob", "ate", "sem",
            "esta", "estao", "homem", "mulher", "adulto", "adulta", "idoso", "idosa"
        };

        private static string ExtractDistinctiveTakeBody(string rawPrompt)
        {
            if (string.IsNullOrWhiteSpace(rawPrompt)) return "";
            string s = rawPrompt.Trim();
            s = Regex.Replace(s, @"^\[\s*TAKE(?:[_\-\s]*ID)?[_\-\s]*\d{1,3}\s*\]\s*", "", RegexOptions.IgnoreCase).Trim();
            s = Regex.Replace(s, @"^Prompt\s+de\s+V[ií]deo\s*:\s*", "", RegexOptions.IgnoreCase).Trim();
            s = Regex.Replace(s, @"^\[\s*TAKE(?:[_\-\s]*ID)?[_\-\s]*\d{1,3}\s*\]\s*", "", RegexOptions.IgnoreCase).Trim();
            s = Regex.Replace(s, @"(\r?\n)*---\s*$", "").Trim();

            // 1. Novela: remove tudo até o fechamento de "[Ação...]"
            Match actionTag = Regex.Match(s, @"\[A[cç][aã]o[^\]]*\]\s*", RegexOptions.IgnoreCase);
            if (actionTag.Success)
            {
                s = s.Substring(actionTag.Index + actionTag.Length).Trim();
            }
            else
            {
                // 2. Terror / variantes sem "[Ação...]": remove cabeçalho "[Estilo Visual]... Apenas som ambiente... ."
                string stripped = Regex.Replace(
                    s,
                    @"^\[Estilo\s+Visual\][\s\S]*?(?:Apenas\s+som\s+ambiente[^\.\r\n]*\.|\(sem\s+m[uú]sica\)\.|sem\s+voz\s+em\s+off\.|e\s+vozes\.)\s*",
                    "",
                    RegexOptions.IgnoreCase).Trim();

                if (stripped.Length > 20 && stripped.Length < s.Length)
                {
                    s = stripped;
                }
                else
                {
                    s = Regex.Replace(s, @"^\[Estilo\s+Visual\][^\.\r\n]*\.\s*", "", RegexOptions.IgnoreCase).Trim();
                }
            }

            // 3. Remove conectores de template repetidos em todos os takes para isolar 100% a ação exclusiva da cena
            s = Regex.Replace(
                s,
                @"IMEDIATAMENTE\s+(?:ele|ela)\s+fala\s+em\s+portugu[eê]s,\s*mesclando\s+o\s+movimento\s+do\s+corpo\s+com\s+a\s+fala\s+para\s+n[aã]o\s+perder\s+tempo\s+de\s+tela\s*:",
                " ",
                RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"IMEDIATAMENTE\s+o\s+[aá]udio\s+entra\s*:", " ", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"Em\s+total\s+sil[eê]ncio\s+e\s+de\s+boca\s+fechada\s*,?", " ", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"\[C[aâ]mera\s+e\s+Detalhes\]", " ", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"A\s+atua[cç][aã]o\s+facial\s+[eé]\s+[^\.]{3,70}?com\s+lip-sync\s+preciso\.", " ", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"Lip-sync\s+preciso\.", " ", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"\bSEM\s+DIALOGO\b", " ", RegexOptions.IgnoreCase);

            return s.Trim();
        }

        private static string ExtractFoleyClause(string rawPrompt)
        {
            if (string.IsNullOrWhiteSpace(rawPrompt)) return "";
            Match m = Regex.Match(rawPrompt, @"Foley\s*:\s*([^\r\n]+)", RegexOptions.IgnoreCase);
            return m.Success ? m.Groups[1].Value.Trim() : "";
        }

        private static HashSet<string> ExtractEmbeddedAssetNames(string rawPrompt)
        {
            HashSet<string> set = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            if (string.IsNullOrWhiteSpace(rawPrompt)) return set;
            MatchCollection matches = Regex.Matches(rawPrompt, @"\b([A-Za-z0-9_\-]{3,80}\.(?:jpg|jpeg|png|webp))\b", RegexOptions.IgnoreCase);
            foreach (Match m in matches)
            {
                string fn = m.Groups[1].Value.Trim();
                if (!string.IsNullOrEmpty(fn))
                    set.Add(fn);
            }
            return set;
        }

        private static string ExtractFirstQuotedDialogue(string rawPrompt)
        {
            if (string.IsNullOrWhiteSpace(rawPrompt)) return "";
            MatchCollection matches = Regex.Matches(rawPrompt, @"""([^""]{12,})""");
            string longest = "";
            foreach (Match m in matches)
            {
                string val = m.Groups[1].Value.Trim();
                if (val.Length > longest.Length)
                    longest = val;
            }
            return longest;
        }

        private static double ComputeContentWordBigramSimilarity(string textA, string textB)
        {
            string na = EpisodeParser.NormalizeForCompare(textA);
            string nb = EpisodeParser.NormalizeForCompare(textB);
            if (string.IsNullOrEmpty(na) || string.IsNullOrEmpty(nb)) return 0.0;
            if (na == nb) return 1.0;

            string[] rawA = na.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            string[] rawB = nb.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

            List<string> seqA = new List<string>(rawA.Length);
            HashSet<string> setA = new HashSet<string>(StringComparer.Ordinal);
            for (int i = 0; i < rawA.Length; i++)
            {
                string w = rawA[i];
                if (w.Length >= 3 && !PtStopWords.Contains(w))
                {
                    seqA.Add(w);
                    setA.Add(w);
                }
            }

            List<string> seqB = new List<string>(rawB.Length);
            HashSet<string> setB = new HashSet<string>(StringComparer.Ordinal);
            for (int i = 0; i < rawB.Length; i++)
            {
                string w = rawB[i];
                if (w.Length >= 3 && !PtStopWords.Contains(w))
                {
                    seqB.Add(w);
                    setB.Add(w);
                }
            }

            if (setA.Count == 0 || setB.Count == 0) return 0.0;

            int uniInter = 0;
            foreach (string w in setA)
            {
                if (setB.Contains(w)) uniInter++;
            }
            double uniDice = (2.0 * uniInter) / (setA.Count + setB.Count);

            if (seqA.Count < 2 || seqB.Count < 2)
                return uniDice;

            HashSet<string> biA = new HashSet<string>(StringComparer.Ordinal);
            for (int i = 0; i < seqA.Count - 1; i++)
                biA.Add(seqA[i] + "_" + seqA[i + 1]);

            HashSet<string> biB = new HashSet<string>(StringComparer.Ordinal);
            for (int i = 0; i < seqB.Count - 1; i++)
                biB.Add(seqB[i] + "_" + seqB[i + 1]);

            int biInter = 0;
            foreach (string bg in biA)
            {
                if (biB.Contains(bg)) biInter++;
            }
            double biDice = (biA.Count + biB.Count) > 0
                ? (2.0 * biInter) / (biA.Count + biB.Count)
                : uniDice;

            return (0.45 * uniDice) + (0.55 * biDice);
        }

        private static double ComputeTakeToVideoMatchScore(FlowTakeSpec spec, string candidatePrompt)
        {
            if (spec == null || string.IsNullOrWhiteSpace(spec.RawPromptBody) || string.IsNullOrWhiteSpace(candidatePrompt))
                return 0.0;

            int explicitTag = TryExtractExplicitTakeTagNumber(candidatePrompt);
            if (explicitTag > 0)
            {
                return explicitTag == spec.TakeNumber ? 1.0 : 0.0;
            }

            string wantBody = ExtractDistinctiveTakeBody(spec.RawPromptBody);
            string gotBody = ExtractDistinctiveTakeBody(candidatePrompt);
            double bodySim = ComputeContentWordBigramSimilarity(wantBody, gotBody);

            string wantFoley = ExtractFoleyClause(spec.RawPromptBody);
            string gotFoley = ExtractFoleyClause(candidatePrompt);
            double actionAndFoleySim = (!string.IsNullOrEmpty(wantFoley) && !string.IsNullOrEmpty(gotFoley))
                ? (0.72 * bodySim) + (0.28 * ComputeContentWordBigramSimilarity(wantFoley, gotFoley))
                : bodySim;

            string wantQuote = ExtractFirstQuotedDialogue(spec.RawPromptBody);
            string gotQuote = ExtractFirstQuotedDialogue(candidatePrompt);
            string normWantQuote = EpisodeParser.NormalizeForCompare(wantQuote);
            string normGotQuote = EpisodeParser.NormalizeForCompare(gotQuote);
            string normCandidateFull = EpisodeParser.NormalizeForCompare(candidatePrompt);

            double score = actionAndFoleySim;

            bool wantHasQuote = normWantQuote.Length >= 12;
            bool gotHasQuote = normGotQuote.Length >= 12;

            if (wantHasQuote && normCandidateFull.IndexOf(normWantQuote, StringComparison.Ordinal) >= 0)
            {
                score = Math.Max(actionAndFoleySim, 0.72 + (0.28 * actionAndFoleySim));
                if (actionAndFoleySim >= 0.72)
                    score = Math.Max(score, 0.94 + (0.06 * actionAndFoleySim));
            }
            else if (wantHasQuote && gotHasQuote)
            {
                double quoteSim = ComputeContentWordBigramSimilarity(normWantQuote, normGotQuote);
                if (quoteSim >= 0.78)
                {
                    score = (0.52 * quoteSim) + (0.48 * actionAndFoleySim);
                }
                else if (quoteSim < 0.35)
                {
                    score = actionAndFoleySim * 0.28;
                }
                else
                {
                    score = (0.50 * quoteSim) + (0.50 * actionAndFoleySim);
                }
            }
            else if (wantHasQuote != gotHasQuote)
            {
                score = actionAndFoleySim * 0.32;
            }

            HashSet<string> wantAssets = ExtractEmbeddedAssetNames(spec.RawPromptBody);
            if (wantAssets.Count == 0 && spec.Ingredients != null)
            {
                for (int i = 0; i < spec.Ingredients.Count; i++)
                {
                    if (!string.IsNullOrWhiteSpace(spec.Ingredients[i]))
                        wantAssets.Add(spec.Ingredients[i].Trim());
                }
            }

            HashSet<string> gotAssets = ExtractEmbeddedAssetNames(candidatePrompt);
            if (wantAssets.Count > 0 && gotAssets.Count > 0)
            {
                int inter = 0;
                HashSet<string> union = new HashSet<string>(wantAssets, StringComparer.OrdinalIgnoreCase);
                foreach (string ga in gotAssets)
                {
                    if (wantAssets.Contains(ga)) inter++;
                    union.Add(ga);
                }
                double assetJaccard = union.Count > 0 ? ((double)inter / union.Count) : 1.0;
                score = score * (0.65 + (0.35 * assetJaccard));
            }

            return Math.Max(0.0, Math.Min(1.0, score));
        }

        private static int IdentifyTakeNumberFromPrompt(string promptText, List<FlowTakeSpec> targetTakes)
        {
            if (string.IsNullOrWhiteSpace(promptText) || targetTakes == null || targetTakes.Count == 0)
                return 0;

            int bestTakeNum = 0;
            double bestScore = 0.0;

            for (int i = 0; i < targetTakes.Count; i++)
            {
                FlowTakeSpec spec = targetTakes[i];
                double score = ComputeTakeToVideoMatchScore(spec, promptText);
                if (score > bestScore)
                {
                    bestScore = score;
                    bestTakeNum = spec.TakeNumber;
                }
            }

            return bestScore >= 0.62 ? bestTakeNum : 0;
        }

        private async Task<List<SessionCompletedVideoInfo>> CollectSessionVideosFromAgentPanelAsync(
            string sess,
            PreSessionGridBaseline baseline,
            CancellationToken ct)
        {
            List<SessionCompletedVideoInfo> result = new List<SessionCompletedVideoInfo>();
            int preBubbles = baseline != null ? baseline.PreExistingChatBubblesCount : 0;

            // Garante que o painel lateral do Agente esteja visível para ler 100% das opções de vídeo desta execução na sessão aberta
            await EnsureAgentPanelOpenAsync(sess, ct);

            // CRÍTICO: Em lotes de 5 vídeos, o Google Flow exibe apenas 4 cards (2x2) por bolha e oculta o 5º vídeo atrás do botão "Ver tudo"!
            // Quando reutilizamos uma sessão já aberta, expandimos e coletamos apenas os itens posteriores a preBubbles.
            for (int expandPass = 0; expandPass < 3; expandPass++)
            {
                ct.ThrowIfCancellationRequested();
                string expandRes = await _cdp.EvalStringAsync(sess, string.Format(@"
(function(){{
    var panel = document.querySelector('flow-agent-panel');
    if (!panel) return '0';
    var preB = {0};
    var bubbles = Array.from(panel.querySelectorAll('flow-chat-bubble'));
    var anchorBubble = (preB > 0 && bubbles.length >= preB) ? bubbles[preB - 1] : null;
    var scroller = panel.querySelector('.scroll-viewport') ||
                   Array.from(panel.querySelectorAll('div')).find(el => el.scrollHeight > el.clientHeight + 40);
    var clickedNodes = [];
    function isAfterAnchor(node) {{
        if (!anchorBubble) return true;
        if (anchorBubble === node || anchorBubble.contains(node)) return false;
        return (anchorBubble.compareDocumentPosition(node) & Node.DOCUMENT_POSITION_FOLLOWING) !== 0;
    }}
    function clickExpandButtons() {{
        var btns = Array.from(panel.querySelectorAll('button')).filter(b => {{
            if (clickedNodes.indexOf(b) >= 0) return false;
            if (!isAfterAnchor(b)) return false;
            var t = ((b.innerText || '') + ' ' + (b.getAttribute('aria-label') || '')).trim();
            if (!t) return false;
            if (/racioc[ií]nio|thinking|menos|less/i.test(t)) return false;
            return /\b(ver tudo|ver mais|mostrar tudo|mostrar mais|view all|show all|see all)\b/i.test(t);
        }});
        btns.forEach(b => {{
            clickedNodes.push(b);
            try {{ b.click(); }} catch(e) {{}}
        }});
    }}
    clickExpandButtons();
    if (scroller && scroller.scrollHeight > scroller.clientHeight + 40) {{
        var startPos = anchorBubble ? Math.max(0, anchorBubble.offsetTop - 100) : 0;
        for (var pos = startPos; pos <= scroller.scrollHeight; pos += Math.max(800, scroller.clientHeight * 2)) {{
            scroller.scrollTop = pos;
            clickExpandButtons();
        }}
        scroller.scrollTop = scroller.scrollHeight;
        clickExpandButtons();
    }}
    return String(clickedNodes.length);
}})()", preBubbles), ct);

                int clickedCount;
                if (!int.TryParse(expandRes, out clickedCount) || clickedCount <= 0)
                    break;

                await Task.Delay(550, ct);
            }

            Dictionary<string, object> raw = null;
            for (int poll = 0; poll < 6; poll++)
            {
                ct.ThrowIfCancellationRequested();
                raw = await _cdp.EvalJsonAsync(sess, string.Format(@"
(function(){{
    var panel = document.querySelector('flow-agent-panel');
    if (!panel) return JSON.stringify({{ opts: [], missingAsb: 0 }});
    var preB = {0};
    var bubbles = Array.from(panel.querySelectorAll('flow-chat-bubble'));
    var anchorBubble = (preB > 0 && bubbles.length >= preB) ? bubbles[preB - 1] : null;
    var nodes = Array.from(panel.querySelectorAll('flow-a2ui-video-option')).filter(vo => {{
        if (!anchorBubble) return true;
        if (anchorBubble.contains(vo)) return false;
        return (anchorBubble.compareDocumentPosition(vo) & Node.DOCUMENT_POSITION_FOLLOWING) !== 0;
    }});
    var missingAsb = 0;
    var opts = nodes.map((vo, idx) => {{
        var img = vo.querySelector('img');
        var vid = vo.querySelector('video');
        var mediaUrl = (img ? (img.getAttribute('src') || '') : '') + ' ' +
                       (vid ? ((vid.getAttribute('poster') || '') + ' ' + (vid.getAttribute('src') || '')) : '');
        var m = mediaUrl.match(/\/asb\/([A-Za-z0-9_\-]{{25,80}})/);
        if (!m) {{
            missingAsb++;
            try {{ vo.scrollIntoView({{ block: 'center', inline: 'nearest' }}); }} catch(e) {{}}
        }}
        var alt = img ? (img.getAttribute('alt') || '') : '';
        if (!alt && vid) alt = (vid.getAttribute('aria-label') || '');
        return {{
            idx: idx,
            asb: m ? m[1] : '',
            alt: alt
        }};
    }});
    return JSON.stringify({{ opts: opts, missingAsb: missingAsb }});
}})()", preBubbles), ct);

                if (raw == null) break;
                int missingAsb = raw.ContainsKey("missingAsb") ? Convert.ToInt32(raw["missingAsb"]) : 0;
                if (missingAsb == 0) break;
                await Task.Delay(350, ct);
            }

            if (raw == null || !raw.ContainsKey("opts")) return result;
            IEnumerable arr = raw["opts"] as IEnumerable;
            if (arr == null) return result;

            foreach (object elem in arr)
            {
                Dictionary<string, object> d = elem as Dictionary<string, object>;
                if (d == null) continue;
                string asb = d.ContainsKey("asb") ? Convert.ToString(d["asb"] ?? "").Trim() : "";
                if (string.IsNullOrEmpty(asb)) continue;
                if (baseline != null && baseline.PreExistingAsbIds.Contains(asb)) continue;

                SessionCompletedVideoInfo info = new SessionCompletedVideoInfo();
                info.ChronologicalOrder = d.ContainsKey("idx") ? Convert.ToInt32(d["idx"]) : result.Count;
                info.AsbId = asb;
                info.AltPrompt = d.ContainsKey("alt") ? Convert.ToString(d["alt"] ?? "") : "";
                result.Add(info);
            }
            return result;
        }

        private async Task<List<string>> CollectSessionGridAsbIdsOldestFirstAsync(
            string sess,
            PreSessionGridBaseline baseline,
            CancellationToken ct)
        {
            List<string> newestFirst = new List<string>();
            HashSet<string> seen = new HashSet<string>(StringComparer.Ordinal);

            for (int page = 0; page <= 20; page++)
            {
                string scrollStatus = await _cdp.EvalStringAsync(sess, string.Format(@"
(function(){{
    var vp = document.querySelector('cdk-virtual-scroll-viewport.tiles-container') || document.querySelector('cdk-virtual-scroll-viewport');
    if (!vp) return 'NO_VP';
    var maxScroll = Math.max(0, vp.scrollHeight - vp.clientHeight);
    var nextTop = Math.min(maxScroll, {0});
    vp.scrollTop = nextTop;
    return (nextTop >= maxScroll && {0} > 0) ? 'AT_END' : 'OK';
}})()", page * 480), ct);
                await Task.Delay(320, ct);

                Dictionary<string, object> raw = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var list = Array.from(document.querySelectorAll('flow-video-tile')).map(t => {
        var vid = t.querySelector('video');
        var img = t.querySelector('img.thumbnail') || t.querySelector('img');
        var mediaUrl = (img ? (img.getAttribute('src') || '') : '') + ' ' +
                       (vid ? ((vid.getAttribute('poster') || '') + ' ' + (vid.getAttribute('src') || '')) : '');
        var m = mediaUrl.match(/\/asb\/([A-Za-z0-9_\-]{25,80})/);
        var txt = (t.innerText || '');
        var ok = !/\b\d{1,2}%\b/.test(txt) && (!!vid || !!img || !!t.querySelector('button[aria-label*=""Mais op""]'));
        return { asb: m ? m[1] : '', ok: ok };
    });
    return JSON.stringify({ list: list });
})()", ct);

                if (raw == null || !raw.ContainsKey("list")) break;
                IEnumerable arr = raw["list"] as IEnumerable;
                if (arr == null) break;

                bool hitPreExistingAnchor = false;
                int countInPage = 0;
                foreach (object elem in arr)
                {
                    countInPage++;
                    Dictionary<string, object> d = elem as Dictionary<string, object>;
                    if (d == null) continue;
                    string asb = d.ContainsKey("asb") ? Convert.ToString(d["asb"] ?? "").Trim() : "";
                    bool ok = d.ContainsKey("ok") && Convert.ToBoolean(d["ok"]);
                    if (string.IsNullOrEmpty(asb)) continue;

                    if (baseline != null && baseline.PreExistingAsbIds.Contains(asb))
                    {
                        hitPreExistingAnchor = true;
                        break;
                    }
                    if (ok && seen.Add(asb))
                        newestFirst.Add(asb);
                }

                if (hitPreExistingAnchor || scrollStatus == "AT_END" || scrollStatus == "NO_VP" ||
                    ((baseline == null || baseline.PreExistingAsbIds.Count == 0) && countInPage < 30 && scrollStatus == "AT_END"))
                    break;
            }

            await _cdp.EvalStringAsync(sess, @"
(function(){
    var vp = document.querySelector('cdk-virtual-scroll-viewport.tiles-container') || document.querySelector('cdk-virtual-scroll-viewport');
    if (vp) vp.scrollTop = 0;
    return 'OK';
})()", ct);
            await Task.Delay(250, ct);

            newestFirst.Reverse();
            return newestFirst;
        }

        private List<Tuple<FlowTakeSpec, string>> BuildChronologicalDownloadPlan(
            List<FlowTakeSpec> targetTakes,
            List<SessionCompletedVideoInfo> agentVideos,
            List<string> gridAsbIdsOldestFirst)
        {
            HashSet<string> validInGrid = new HashSet<string>(gridAsbIdsOldestFirst ?? new List<string>(), StringComparer.Ordinal);
            List<SessionCompletedVideoInfo> candidates = new List<SessionCompletedVideoInfo>();
            HashSet<string> knownAgentAsbs = new HashSet<string>(StringComparer.Ordinal);

            if (agentVideos != null)
            {
                for (int i = 0; i < agentVideos.Count; i++)
                {
                    SessionCompletedVideoInfo av = agentVideos[i];
                    if (av == null || string.IsNullOrEmpty(av.AsbId)) continue;
                    knownAgentAsbs.Add(av.AsbId);
                    if (validInGrid.Count == 0 || validInGrid.Contains(av.AsbId))
                        candidates.Add(av);
                }
            }

            string[] assignedAsbPerTake = new string[targetTakes.Count];
            HashSet<string> usedAsbIds = new HashSet<string>(StringComparer.Ordinal);

            // Passo 1: Casamento Global Best-First (1:1 por maior pontuação decrescente entre todos os pares Take x Vídeo).
            double[,] scoreMatrix = new double[targetTakes.Count, candidates.Count];
            int[] bestTakeForVideo = new int[candidates.Count];
            double[] bestScoreForVideo = new double[candidates.Count];

            List<TakeVideoMatchCandidate> highConfidencePairs = new List<TakeVideoMatchCandidate>();

            for (int v = 0; v < candidates.Count; v++)
            {
                bestTakeForVideo[v] = -1;
                bestScoreForVideo[v] = 0.0;
                SessionCompletedVideoInfo vid = candidates[v];
                if (string.IsNullOrWhiteSpace(vid.AltPrompt))
                    continue;

                for (int k = 0; k < targetTakes.Count; k++)
                {
                    double s = ComputeTakeToVideoMatchScore(targetTakes[k], vid.AltPrompt);
                    scoreMatrix[k, v] = s;
                    if (s > bestScoreForVideo[v])
                    {
                        bestScoreForVideo[v] = s;
                        bestTakeForVideo[v] = k;
                    }

                    if (s >= 0.62)
                    {
                        TakeVideoMatchCandidate pair = new TakeVideoMatchCandidate();
                        pair.TakeIndex = k;
                        pair.VideoIndex = v;
                        pair.AsbId = vid.AsbId;
                        pair.RawScore = s;
                        pair.ScoreBucket = s >= 0.93 ? 50 : (int)Math.Round(s * 50.0);
                        highConfidencePairs.Add(pair);
                    }
                }
            }

            highConfidencePairs.Sort(delegate(TakeVideoMatchCandidate a, TakeVideoMatchCandidate b)
            {
                int cmpBucket = b.ScoreBucket.CompareTo(a.ScoreBucket);
                if (cmpBucket != 0) return cmpBucket;
                int cmpVid = b.VideoIndex.CompareTo(a.VideoIndex);
                if (cmpVid != 0) return cmpVid;
                int cmpRaw = b.RawScore.CompareTo(a.RawScore);
                if (cmpRaw != 0) return cmpRaw;
                return a.TakeIndex.CompareTo(b.TakeIndex);
            });

            for (int p = 0; p < highConfidencePairs.Count; p++)
            {
                TakeVideoMatchCandidate pair = highConfidencePairs[p];
                if (!string.IsNullOrEmpty(assignedAsbPerTake[pair.TakeIndex]))
                    continue;
                if (usedAsbIds.Contains(pair.AsbId))
                    continue;

                assignedAsbPerTake[pair.TakeIndex] = pair.AsbId;
                usedAsbIds.Add(pair.AsbId);
            }

            // Passo 1.5: Descarta duplicatas antigas de takes já atribuídos e permite casamento secundário (>= 0.42)
            // SOMENTE se o melhor take daquele vídeo em TODO o episódio for justamente um take ainda não atribuído!
            List<TakeVideoMatchCandidate> secondaryPairs = new List<TakeVideoMatchCandidate>();
            for (int v = 0; v < candidates.Count; v++)
            {
                SessionCompletedVideoInfo vid = candidates[v];
                if (usedAsbIds.Contains(vid.AsbId) || string.IsNullOrWhiteSpace(vid.AltPrompt))
                    continue;

                int topTakeIdx = bestTakeForVideo[v];
                double topScore = bestScoreForVideo[v];
                if (topTakeIdx < 0) continue;

                if (!string.IsNullOrEmpty(assignedAsbPerTake[topTakeIdx]) && topScore >= 0.55)
                {
                    usedAsbIds.Add(vid.AsbId);
                    continue;
                }

                if (string.IsNullOrEmpty(assignedAsbPerTake[topTakeIdx]) && topScore >= 0.42)
                {
                    TakeVideoMatchCandidate sec = new TakeVideoMatchCandidate();
                    sec.TakeIndex = topTakeIdx;
                    sec.VideoIndex = v;
                    sec.AsbId = vid.AsbId;
                    sec.RawScore = topScore;
                    sec.ScoreBucket = (int)Math.Round(topScore * 50.0);
                    secondaryPairs.Add(sec);
                }
            }

            secondaryPairs.Sort(delegate(TakeVideoMatchCandidate a, TakeVideoMatchCandidate b)
            {
                int cmpRaw = b.RawScore.CompareTo(a.RawScore);
                if (cmpRaw != 0) return cmpRaw;
                return b.VideoIndex.CompareTo(a.VideoIndex);
            });

            for (int p = 0; p < secondaryPairs.Count; p++)
            {
                TakeVideoMatchCandidate sec = secondaryPairs[p];
                if (string.IsNullOrEmpty(assignedAsbPerTake[sec.TakeIndex]) && !usedAsbIds.Contains(sec.AsbId))
                {
                    assignedAsbPerTake[sec.TakeIndex] = sec.AsbId;
                    usedAsbIds.Add(sec.AsbId);
                }
            }

            // Passo 2: Fallback estritamente cronológico APENAS para vídeos sem prompt (alt vazio ou ausente no painel do Agente)
            List<string> unknownPromptChronologicalPool = new List<string>();
            for (int v = 0; v < candidates.Count; v++)
            {
                SessionCompletedVideoInfo av = candidates[v];
                if (!usedAsbIds.Contains(av.AsbId) && string.IsNullOrWhiteSpace(av.AltPrompt) &&
                    !unknownPromptChronologicalPool.Contains(av.AsbId))
                {
                    unknownPromptChronologicalPool.Add(av.AsbId);
                }
            }

            if (gridAsbIdsOldestFirst != null)
            {
                for (int g = 0; g < gridAsbIdsOldestFirst.Count; g++)
                {
                    string gAsb = gridAsbIdsOldestFirst[g];
                    if (!usedAsbIds.Contains(gAsb) && !knownAgentAsbs.Contains(gAsb) &&
                        !unknownPromptChronologicalPool.Contains(gAsb))
                    {
                        unknownPromptChronologicalPool.Add(gAsb);
                    }
                }
            }

            int poolCursor = 0;
            for (int k = 0; k < targetTakes.Count; k++)
            {
                if (string.IsNullOrEmpty(assignedAsbPerTake[k]) && poolCursor < unknownPromptChronologicalPool.Count)
                {
                    string fallbackAsb = unknownPromptChronologicalPool[poolCursor++];
                    assignedAsbPerTake[k] = fallbackAsb;
                    usedAsbIds.Add(fallbackAsb);
                }
            }

            Dictionary<string, string> promptByAsb = new Dictionary<string, string>(StringComparer.Ordinal);
            for (int v = 0; v < candidates.Count; v++)
            {
                if (!string.IsNullOrEmpty(candidates[v].AsbId) && !string.IsNullOrWhiteSpace(candidates[v].AltPrompt))
                    promptByAsb[candidates[v].AsbId] = candidates[v].AltPrompt;
            }

            int exactTagCount = 0;
            List<Tuple<FlowTakeSpec, string>> plan = new List<Tuple<FlowTakeSpec, string>>();
            for (int k = 0; k < targetTakes.Count; k++)
            {
                if (!string.IsNullOrEmpty(assignedAsbPerTake[k]))
                {
                    string chosenAsb = assignedAsbPerTake[k];
                    plan.Add(Tuple.Create(targetTakes[k], chosenAsb));
                    string matchedPrompt;
                    if (promptByAsb.TryGetValue(chosenAsb, out matchedPrompt) &&
                        TryExtractExplicitTakeTagNumber(matchedPrompt) == targetTakes[k].TakeNumber)
                    {
                        exactTagCount++;
                    }
                }
                else
                {
                    _log(string.Format("[Google Flow -> Grok] Take_{0:00} não gerou vídeo concluído no Google Flow -> será gerado no Grok Vídeo.", targetTakes[k].TakeNumber));
                }
            }

            if (plan.Count > 0)
            {
                _log(string.Format("[Google Flow] Identificação de takes: {0}/{1} confirmados por tag exata [TAKE_XX] ({2} por reserva de conteúdo).",
                    exactTagCount, plan.Count, plan.Count - exactTagCount));
            }

            return plan;
        }

        private async Task EnrichMissingVideoPromptsFromGridTilesAsync(
            string sess,
            List<SessionCompletedVideoInfo> agentVideos,
            List<string> gridAsbIdsOldestFirst,
            CancellationToken ct)
        {
            if (agentVideos == null || gridAsbIdsOldestFirst == null || gridAsbIdsOldestFirst.Count == 0)
                return;

            Dictionary<string, SessionCompletedVideoInfo> byAsb = new Dictionary<string, SessionCompletedVideoInfo>(StringComparer.Ordinal);
            for (int i = 0; i < agentVideos.Count; i++)
            {
                SessionCompletedVideoInfo info = agentVideos[i];
                if (info != null && !string.IsNullOrEmpty(info.AsbId))
                    byAsb[info.AsbId] = info;
            }

            List<string> missingAsbs = new List<string>();
            for (int g = 0; g < gridAsbIdsOldestFirst.Count; g++)
            {
                string gAsb = gridAsbIdsOldestFirst[g];
                if (string.IsNullOrEmpty(gAsb)) continue;
                SessionCompletedVideoInfo existing;
                if (!byAsb.TryGetValue(gAsb, out existing) || string.IsNullOrWhiteSpace(existing.AltPrompt))
                {
                    if (!missingAsbs.Contains(gAsb))
                        missingAsbs.Add(gAsb);
                }
            }

            if (missingAsbs.Count == 0)
                return;

            for (int m = 0; m < missingAsbs.Count; m++)
            {
                ct.ThrowIfCancellationRequested();
                string gAsb = missingAsbs[m];
                try
                {
                    Dictionary<string, object> cardCenter = await ScrollToAndLocateTileByAsbIdAsync(sess, gAsb, ct);
                    if (cardCenter == null) continue;

                    await _cdp.HoverAsync(sess, Convert.ToInt32(cardCenter["x"]), Convert.ToInt32(cardCenter["y"]), ct);
                    await Task.Delay(380, ct);

                    string b64Asb = Convert.ToBase64String(Encoding.UTF8.GetBytes(gAsb));
                    Dictionary<string, object> reusePt = await _cdp.EvalJsonAsync(sess, string.Format(@"
(function(){{
    var want = atob('{0}');
    var tile = Array.from(document.querySelectorAll('flow-video-tile')).find(t => {{
        var vid = t.querySelector('video');
        var img = t.querySelector('img');
        var u = (vid ? ((vid.getAttribute('src') || '') + ' ' + (vid.getAttribute('poster') || '')) : '') + ' ' +
                (img ? (img.getAttribute('src') || '') : '');
        return u.indexOf(want) >= 0;
    }});
    if (!tile) return null;
    var btn = tile.querySelector('button[aria-label*=""Reutilizar""], button[aria-label*=""Reuse""]') ||
              Array.from(tile.querySelectorAll('button')).find(b => {{
                  var al = (b.getAttribute('aria-label') || '');
                  var txt = (b.innerText || '').trim();
                  return al.indexOf('Reutilizar') >= 0 || al.indexOf('Reuse') >= 0 || txt === 'undo' || txt === 'replay';
              }});
    if (!btn) return null;
    var r = btn.getBoundingClientRect();
    if (r.width < 4) {{
        btn.click();
        return JSON.stringify({{ clickedNative: true, x: 0, y: 0 }});
    }}
    return JSON.stringify({{ clickedNative: false, x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) }});
}})()", b64Asb), ct);

                    if (reusePt == null) continue;
                    bool clickedNative = reusePt.ContainsKey("clickedNative") && Convert.ToBoolean(reusePt["clickedNative"]);
                    if (!clickedNative)
                    {
                        await _cdp.ClickAtAsync(sess, Convert.ToInt32(reusePt["x"]), Convert.ToInt32(reusePt["y"]), ct);
                    }

                    await Task.Delay(850, ct);
                    string recoveredPrompt = await ReadCurrentFlowTextboxAsync(sess, ct);
                    await InsertTextIntoFlowTextboxAsync(sess, "", true, ct);
                    await ClearAttachedPromptChipsAsync(sess, ct);

                    if (!string.IsNullOrWhiteSpace(recoveredPrompt))
                    {
                        SessionCompletedVideoInfo existing;
                        if (byAsb.TryGetValue(gAsb, out existing))
                        {
                            existing.AltPrompt = recoveredPrompt;
                        }
                        else
                        {
                            SessionCompletedVideoInfo added = new SessionCompletedVideoInfo();
                            added.AsbId = gAsb;
                            added.AltPrompt = recoveredPrompt;
                            agentVideos.Add(added);
                            byAsb[gAsb] = added;
                        }
                    }
                }
                catch (OperationCanceledException)
                {
                    throw;
                }
                catch
                {
                }
            }
        }

        private async Task<Dictionary<string, object>> ScrollToAndLocateTileByAsbIdAsync(
            string sess,
            string targetAsbId,
            CancellationToken ct)
        {
            string b64Asb = Convert.ToBase64String(Encoding.UTF8.GetBytes(targetAsbId));

            string locateAndCenterJs = string.Format(@"
(function(){{
    var want = atob('{0}');
    function findTile() {{
        return Array.from(document.querySelectorAll('flow-video-tile, flow-image-tile, flow-asset-tile, [data-asb-id]')).find(t => {{
            var host = t.closest('flow-video-tile, flow-image-tile, flow-asset-tile') || t;
            var vid = host.querySelector('video');
            var img = host.querySelector('img');
            var u = (vid ? ((vid.getAttribute('src') || '') + ' ' + (vid.getAttribute('poster') || '')) : '') + ' ' +
                    (img ? ((img.currentSrc || img.src || img.getAttribute('src') || '')) : '') + ' ' +
                    (host.getAttribute('data-asb-id') || '');
            return u.indexOf(want) >= 0;
        }});
    }}
    var tile = findTile();
    if (!tile) return null;
    tile.scrollIntoView({{ block: 'center', inline: 'nearest' }});
    var r = tile.getBoundingClientRect();
    return JSON.stringify({{ found: true, x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) }});
}})()", b64Asb);

            Dictionary<string, object> found = await _cdp.EvalJsonAsync(sess, locateAndCenterJs, ct);
            if (found == null)
            {
                // Varre o cdk-virtual-scroll-viewport desde scrollTop = 0 até montar o card com este targetAsbId
                for (int step = 0; step <= 20; step++)
                {
                    ct.ThrowIfCancellationRequested();
                    string stepRes = await _cdp.EvalStringAsync(sess, string.Format(@"
(function(){{
    var vp = document.querySelector('cdk-virtual-scroll-viewport.tiles-container') || document.querySelector('cdk-virtual-scroll-viewport');
    if (!vp) return 'NO_VP';
    var maxScroll = Math.max(0, vp.scrollHeight - vp.clientHeight);
    var nextTop = Math.min(maxScroll, {0});
    vp.scrollTop = nextTop;
    return nextTop >= maxScroll && {0} > 0 ? 'AT_END' : 'OK';
}})()", step * 420), ct);

                    await Task.Delay(340, ct);
                    found = await _cdp.EvalJsonAsync(sess, locateAndCenterJs, ct);
                    if (found != null) break;
                    if (stepRes == "AT_END" || stepRes == "NO_VP") break;
                }
            }

            if (found == null) return null;

            // Aguarda o virtual scroll estabilizar após scrollIntoView e RE-LOCALIZA pelo mesmo targetAsbId (imune a troca de índice DOM!)
            await Task.Delay(480, ct);

            Dictionary<string, object> settled = await _cdp.EvalJsonAsync(sess, string.Format(@"
(function(){{
    var want = atob('{0}');
    var tile = Array.from(document.querySelectorAll('flow-video-tile, flow-image-tile, flow-asset-tile, [data-asb-id]')).find(t => {{
        var host = t.closest('flow-video-tile, flow-image-tile, flow-asset-tile') || t;
        var vid = host.querySelector('video');
        var img = host.querySelector('img');
        var u = (vid ? ((vid.getAttribute('src') || '') + ' ' + (vid.getAttribute('poster') || '')) : '') + ' ' +
                (img ? ((img.currentSrc || img.src || img.getAttribute('src') || '')) : '') + ' ' +
                (host.getAttribute('data-asb-id') || '');
        return u.indexOf(want) >= 0;
    }});
    if (!tile) return null;
    var r = tile.getBoundingClientRect();
    if (r.top < 25 || r.bottom > window.innerHeight - 15) {{
        var vp = document.querySelector('cdk-virtual-scroll-viewport.tiles-container') || document.querySelector('cdk-virtual-scroll-viewport');
        if (vp) {{
            vp.scrollTop += (r.top + r.height/2) - (window.innerHeight / 2);
        }}
        r = tile.getBoundingClientRect();
    }}
    return JSON.stringify({{
        x: Math.round(r.left + r.width/2),
        y: Math.round(r.top + r.height/2),
        w: Math.round(r.width),
        h: Math.round(r.height)
    }});
}})()", b64Asb), ct);

            return settled ?? found;
        }

        private async Task DownloadSingleTileByAsbIdAsync(
            string sess,
            string targetAsbId,
            int targetTakeNumber,
            int progressIdx,
            int progressTotal,
            string stagingDl,
            string finalTakePath,
            CancellationToken ct)
        {
            _log(string.Format("[Google Flow] Baixando cena {0}/{1} -> Take_{2:00}.mp4 (720p)...",
                progressIdx, progressTotal, targetTakeNumber));

            string b64Asb = Convert.ToBase64String(Encoding.UTF8.GetBytes(targetAsbId));
            Dictionary<string, object> dlMenuPt = null;

            for (int menuAttempt = 1; menuAttempt <= 3; menuAttempt++)
            {
                ct.ThrowIfCancellationRequested();

                // Fecha eventual menu anterior residual
                string hasOpenMenu = await _cdp.EvalStringAsync(sess, @"
(function(){
    var open = Array.from(document.querySelectorAll('.cdk-overlay-container [role=""menuitem""]'))
        .some(el => el.getBoundingClientRect().width > 10);
    return open ? 'OPEN' : 'CLOSED';
})()", ct);
                if (hasOpenMenu == "OPEN")
                {
                    await _cdp.PressEscapeAsync(sess, ct);
                    await Task.Delay(260, ct);
                }

                Dictionary<string, object> cardCenter = await ScrollToAndLocateTileByAsbIdAsync(sess, targetAsbId, ct);
                if (cardCenter == null)
                    throw new InvalidOperationException(string.Format("Card de vídeo (ID {0}) do Take_{1:00} não foi localizado no grid do Google Flow.",
                        targetAsbId.Substring(0, Math.Min(12, targetAsbId.Length)), targetTakeNumber));

                await _cdp.HoverAsync(sess, Convert.ToInt32(cardCenter["x"]), Convert.ToInt32(cardCenter["y"]), ct);
                await Task.Delay(420, ct);

                // Re-localiza o botão 'Mais opções' (⋮) diretamente dentro do card com este targetAsbId
                Dictionary<string, object> morePt = await _cdp.EvalJsonAsync(sess, string.Format(@"
(function(){{
    var want = atob('{0}');
    var tile = Array.from(document.querySelectorAll('flow-video-tile')).find(t => {{
        var vid = t.querySelector('video');
        var img = t.querySelector('img');
        var u = (vid ? ((vid.getAttribute('src') || '') + ' ' + (vid.getAttribute('poster') || '')) : '') + ' ' +
                (img ? (img.getAttribute('src') || '') : '');
        return u.indexOf(want) >= 0;
    }});
    if (!tile) return null;
    var btn = tile.querySelector('button[aria-label*=""Mais op""], button[aria-label*=""More""]') ||
              Array.from(tile.querySelectorAll('button')).find(b => (b.innerText || '').trim() === 'more_vert');
    if (!btn) return null;
    var r = btn.getBoundingClientRect();
    if (r.width < 4) return null;
    return JSON.stringify({{ x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) }});
}})()", b64Asb), ct);

                if (morePt == null)
                {
                    if (menuAttempt < 3)
                    {
                        await Task.Delay(350, ct);
                        continue;
                    }
                    throw new InvalidOperationException(string.Format("Botão 'Mais opções' (⋮) não encontrado no card do Take_{0:00}.", targetTakeNumber));
                }

                if (menuAttempt == 3)
                {
                    // Fallback na 3ª tentativa: aciona .click() nativo direto no botão Mais opções do tile específico
                    await _cdp.EvalStringAsync(sess, string.Format(@"
(function(){{
    var want = atob('{0}');
    var tile = Array.from(document.querySelectorAll('flow-video-tile')).find(t => {{
        var vid = t.querySelector('video');
        var img = t.querySelector('img');
        var u = (vid ? ((vid.getAttribute('src') || '') + ' ' + (vid.getAttribute('poster') || '')) : '') + ' ' +
                (img ? (img.getAttribute('src') || '') : '');
        return u.indexOf(want) >= 0;
    }});
    if (!tile) return 'NO_TILE';
    var btn = tile.querySelector('button[aria-label*=""Mais op""], button[aria-label*=""More""]');
    if (btn) btn.click();
    return 'CLICKED';
}})()", b64Asb), ct);
                }
                else
                {
                    await _cdp.ClickAtAsync(sess, Convert.ToInt32(morePt["x"]), Convert.ToInt32(morePt["y"]), ct);
                }

                for (int poll = 0; poll < 4; poll++)
                {
                    await Task.Delay(320, ct);
                    dlMenuPt = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var items = Array.from(document.querySelectorAll('.cdk-overlay-container [role=""menuitem""], [role=""menuitem""]'))
        .filter(el => el.getBoundingClientRect().width > 10);
    var m = items.find(el => {
        var t = (el.innerText || '');
        return t.indexOf('Fazer o download') >= 0 || t.indexOf('Baixar') >= 0 || t.indexOf('Download') >= 0;
    });
    if (!m) return null;
    var r = m.getBoundingClientRect();
    return JSON.stringify({ x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) });
})()", ct);
                    if (dlMenuPt != null) break;
                }

                if (dlMenuPt != null) break;
            }

            if (dlMenuPt == null)
                throw new InvalidOperationException(string.Format("Opção 'Fazer o download' não apareceu no menu do card do Take_{0:00} no Google Flow.", targetTakeNumber));

            HashSet<string> beforeFiles = new HashSet<string>(Directory.GetFiles(stagingDl), StringComparer.OrdinalIgnoreCase);
            await _cdp.ClickAtAsync(sess, Convert.ToInt32(dlMenuPt["x"]), Convert.ToInt32(dlMenuPt["y"]), ct);

            // Aguarda submenu de resolução ("720p" / "Resolução original") abrir e clica
            Dictionary<string, object> res720Pt = null;
            for (int poll = 0; poll < 5; poll++)
            {
                await Task.Delay(300, ct);
                res720Pt = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var items = Array.from(document.querySelectorAll('.cdk-overlay-container [role=""menuitem""], [role=""menuitem""], .cdk-overlay-container button'))
        .filter(el => el.getBoundingClientRect().width > 10);
    var m = items.find(el => {
        var t = (el.innerText || '');
        return t.indexOf('720p') >= 0 || t.indexOf('original') >= 0 || t.indexOf('Original') >= 0;
    });
    if (!m) return null;
    var r = m.getBoundingClientRect();
    return JSON.stringify({ x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) });
})()", ct);
                if (res720Pt != null) break;
            }

            if (res720Pt != null)
            {
                await _cdp.ClickAtAsync(sess, Convert.ToInt32(res720Pt["x"]), Convert.ToInt32(res720Pt["y"]), ct);
            }

            // Regra 11: Aguardar 1:1 o término completo deste .mp4 antes de clicar no próximo card
            string downloadedMp4 = await _cdp.WaitForSingleDownloadAsync(stagingDl, beforeFiles, 80 * 1024, 90000, ct);
            if (string.IsNullOrEmpty(downloadedMp4))
                throw new IOException(string.Format("Timeout aguardando download 720p do Take_{0:00}.mp4 no Google Flow.", targetTakeNumber));

            if (File.Exists(finalTakePath))
                File.Delete(finalTakePath);
            File.Move(downloadedMp4, finalTakePath);

            _log(string.Format("[Google Flow] Salvo Take_{0:00}.mp4 ({1:0.0} MB).",
                targetTakeNumber, new FileInfo(finalTakePath).Length / (1024.0 * 1024.0)));
        }

        private async Task DownloadAllCompletedTakesIn720pAsync(
            string sess,
            PreSessionGridBaseline baseline,
            EpisodeWorkItem ep,
            List<FlowTakeSpec> targetTakes,
            CancellationToken ct)
        {
            // Regra 28 e 32: Mapear exclusivamente os vídeos gerados nesta Nova sessão em ordem cronológica (Take_01..Take_N) e baixar em 720p
            string stagingDl = Path.Combine(ep.TakesDir, "_flow_dl_" + DateTime.Now.ToString("HHmmss"));
            Directory.CreateDirectory(stagingDl);
            await _cdp.SetDownloadBehaviorAsync(stagingDl, ct);

            List<SessionCompletedVideoInfo> agentVideos = await CollectSessionVideosFromAgentPanelAsync(sess, baseline, ct);
            List<string> gridAsbIdsOldestFirst = await CollectSessionGridAsbIdsOldestFirstAsync(sess, baseline, ct);
            await EnrichMissingVideoPromptsFromGridTilesAsync(sess, agentVideos, gridAsbIdsOldestFirst, ct);

            List<Tuple<FlowTakeSpec, string>> downloadPlan = BuildChronologicalDownloadPlan(targetTakes, agentVideos, gridAsbIdsOldestFirst);

            _log(string.Format("[Google Flow] Passo 7: Iniciando download cronológico em 720p de {0}/{1} takes desta sessão...",
                downloadPlan.Count, targetTakes.Count));

            for (int i = 0; i < downloadPlan.Count; i++)
            {
                ct.ThrowIfCancellationRequested();
                FlowTakeSpec takeSpec = downloadPlan[i].Item1;
                string targetAsbId = downloadPlan[i].Item2;
                string finalTakePath = Path.Combine(ep.TakesDir, string.Format("Take_{0:00}.mp4", takeSpec.TakeNumber));

                try
                {
                    await DownloadSingleTileByAsbIdAsync(
                        sess,
                        targetAsbId,
                        takeSpec.TakeNumber,
                        i + 1,
                        downloadPlan.Count,
                        stagingDl,
                        finalTakePath,
                        ct);
                }
                catch (OperationCanceledException)
                {
                    throw;
                }
                catch (Exception ex)
                {
                    _log(string.Format("[Google Flow | Aviso] Falha ao baixar Take_{0:00}.mp4 no Flow ({1}). Será gerado via fallback no Grok Vídeo...",
                        takeSpec.TakeNumber, ex.Message));
                }
            }

            try { await _cdp.ResetDownloadBehaviorToDefaultAsync(); } catch { }
            try { Directory.Delete(stagingDl, true); } catch { }
        }
    }
}
