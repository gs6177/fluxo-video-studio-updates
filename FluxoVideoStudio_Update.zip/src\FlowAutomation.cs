using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace FluxoVideoStudio
{
    public class FlowAutomation
    {
        private readonly CdpController _cdp;
        private readonly PipelineConfig _config;
        private readonly GrokAutomation _grok;
        private readonly Action<string> _log;

        public FlowAutomation(CdpController cdp, PipelineConfig config, Action<string> logger)
            : this(cdp, config, new GrokAutomation(cdp, config, logger), logger)
        {
        }

        public FlowAutomation(CdpController cdp, PipelineConfig config, GrokAutomation grok, Action<string> logger)
        {
            _cdp = cdp;
            _config = config;
            _grok = grok ?? new GrokAutomation(cdp, config, logger);
            _log = logger ?? delegate { };
        }

        public static bool IsYouthCharacterTake(FlowTakeSpec take, EpisodeWorkItem ep)
        {
            if (take == null) return false;

            // Remove falas entre aspas ("...") para que expressões idiomáticas entre adultos ("meu filho", "minha filha") não gerem falso positivo
            string bodyWithoutQuotes = Regex.Replace(take.RawPromptBody ?? "", @"""[^""]*""", " ");
            StringBuilder sb = new StringBuilder();
            sb.Append(take.RawHeader ?? "").Append(' ');
            sb.Append(bodyWithoutQuotes).Append(' ');
            if (take.Ingredients != null)
            {
                for (int i = 0; i < take.Ingredients.Count; i++)
                    sb.Append(take.Ingredients[i]).Append(' ');
            }

            // Inspeciona também a definição dos personagens vinculados aos ingredientes deste take
            if (ep != null && ep.GrokSpecs != null && take.Ingredients != null && take.Ingredients.Count > 0)
            {
                HashSet<string> takeIngSet = new HashSet<string>(take.Ingredients, StringComparer.OrdinalIgnoreCase);
                for (int i = 0; i < ep.GrokSpecs.Count; i++)
                {
                    GrokAssetSpec gs = ep.GrokSpecs[i];
                    if (gs == null || string.IsNullOrEmpty(gs.TargetFileName)) continue;
                    if (!takeIngSet.Contains(gs.TargetFileName)) continue;

                    string normSpec = EpisodeParser.NormalizeForCompare((gs.DisplayTitle ?? "") + " " + (gs.RawPromptLine ?? ""));
                    bool explicitlyAdult = Regex.IsMatch(normSpec, @"\b(homem adulto|mulher adulta|adulto|adulta|idoso|idosa|senhor|senhora|velho|velha)\b");
                    if (!explicitlyAdult)
                    {
                        sb.Append(gs.DisplayTitle ?? "").Append(' ');
                        sb.Append(gs.RawPromptLine ?? "").Append(' ');
                    }
                }
            }

            string norm = EpisodeParser.NormalizeForCompare(sb.ToString());
            if (string.IsNullOrEmpty(norm)) return false;

            // Remove expressões negativas de estilo visual (ex.: "sem rosto ou aparencia de ...", "sem tracos ...", "zero ...")
            norm = Regex.Replace(norm, @"\b(sem|zero|nunca|jamais|nao)\s+(rosto\s+ou\s+aparencia\s+de\s+|aparencia\s+de\s+|rosto\s+de\s+|feicoes\s+de\s+|tracos\s+de\s+|corpo\s+de\s+|aspecto\s+de\s+|personagens?\s+)?\w+(\s+ou\s+\w+)?", " ");
            norm = Regex.Replace(norm, @"\b(realcam|realcando|destacam)\s+personagens\s+adultos\b", " ");

            if (Regex.IsMatch(norm,
                @"\b(crianca|criancas|bebe|bebes|nenem|nenens|recem nascido|recem nascida|menino|meninos|menininho|menininha|menina|meninas|garoto|garotos|garotinho|garotinha|garota|garotas|guri|guria|pivete|moleque|molequinho|infantil|infantis|berco|chupeta|mamadeira|filho pequeno|filha pequena|filhos pequenos|filhas pequenas|filhinho|filhinha|irmaozinho|irmazinha|netinho|netinha|bebe de colo|crianca de colo)\b"))
            {
                return true;
            }

            if (Regex.IsMatch(norm,
                @"\b(([1-9]|1[0-7])\s+anos\s+de\s+idade|(de|com)\s+([1-9]|1[0-7])\s+meses|(filho|filha|irmao|irma|neto|neta|sobrinho|sobrinha)\s+de\s+([1-9]|1[0-7])\s+anos)\b"))
            {
                return true;
            }

            return false;
        }

        public static int TryExtractExplicitTakeTagNumber(string promptText)
        {
            if (string.IsNullOrWhiteSpace(promptText))
                return 0;

            Match m = Regex.Match(
                promptText,
                @"\[\s*TAKE(?:[_\-\s]*ID)?[_\-\s]*0*(\d{1,3})\s*\]",
                RegexOptions.IgnoreCase);

            if (m.Success)
            {
                int num;
                if (int.TryParse(m.Groups[1].Value, out num) && num > 0)
                    return num;
            }

            return 0;
        }

        private static string InjectTakeTagIntoPromptBody(string rawBody, int takeNumber)
        {
            string cleanBody = Regex.Replace(rawBody ?? "", @"(\r?\n|\s)*---\s*$", "").Trim();
            if (string.IsNullOrEmpty(cleanBody) || takeNumber <= 0)
                return cleanBody;

            if (TryExtractExplicitTakeTagNumber(cleanBody) == takeNumber)
                return cleanBody;

            string tag = string.Format("[TAKE_{0:00}]", takeNumber);

            Match prefixMatch = Regex.Match(cleanBody, @"^(Prompt\s+de\s+V[ií]deo\s*:\s*)", RegexOptions.IgnoreCase);
            if (prefixMatch.Success)
            {
                string rest = cleanBody.Substring(prefixMatch.Length).TrimStart();
                return "Prompt de Vídeo:\r\n" + tag + " " + rest;
            }

            return tag + " " + cleanBody;
        }

        public static string BuildFlowPromptForTakes(string originalPromptText, List<FlowTakeSpec> takes)
        {
            if (takes == null || takes.Count == 0) return "";

            StringBuilder sb = new StringBuilder();

            // Instrução obrigatória ao Agente do Google Flow para preservar a tag [TAKE_XX] no texto final de cada vídeo gerado
            sb.AppendLine("[INSTRUÇÃO OBRIGATÓRIA DE RASTREAMENTO DE TAKES]:");
            sb.AppendLine("Ao enviar o prompt de cada cena para a ferramenta de geração de vídeo (tanto neste lote inicial quanto nos próximos lotes após \"continue\"), mantenha OBRIGATORIAMENTE e literalmente a tag [TAKE_01], [TAKE_02], [TAKE_03], etc. exatamente no início do texto do prompt de cada vídeo gerado (exemplo: \"[TAKE_01] [Estilo Visual] ...\"). NUNCA remova, omita, traduza ou altere a tag [TAKE_XX] em nenhum vídeo. Essa tag é apenas controle interno de identificação — não renderize nenhum texto, número ou legenda escrita na imagem do vídeo.");
            sb.AppendLine();

            // Preserva eventual cabeçalho global existente antes do primeiro "Take X |"
            if (!string.IsNullOrWhiteSpace(originalPromptText))
            {
                string[] lines = originalPromptText.Split(new[] { "\r\n", "\n" }, StringSplitOptions.None);
                List<string> preambleLines = new List<string>();
                for (int i = 0; i < lines.Length; i++)
                {
                    if (Regex.IsMatch(lines[i], @"Take\s*0*(\d+)\s*\|", RegexOptions.IgnoreCase))
                        break;
                    preambleLines.Add(lines[i]);
                }
                string preamble = string.Join("\r\n", preambleLines).Trim();
                if (!string.IsNullOrEmpty(preamble))
                {
                    sb.AppendLine(preamble);
                    sb.AppendLine();
                }
            }

            for (int i = 0; i < takes.Count; i++)
            {
                FlowTakeSpec t = takes[i];
                string taggedBody = InjectTakeTagIntoPromptBody(t.RawPromptBody, t.TakeNumber);
                sb.AppendLine((t.RawHeader ?? "").Trim());
                sb.AppendLine(taggedBody);
                if (i < takes.Count - 1)
                {
                    sb.AppendLine();
                    sb.AppendLine("---");
                    sb.AppendLine();
                }
            }

            return sb.ToString().Trim();
        }

        public async Task RunAsync(EpisodeWorkItem ep, CancellationToken ct)
        {
            if (string.IsNullOrWhiteSpace(ep.FlowPromptText) || ep.FlowTakes.Count == 0)
            {
                throw new InvalidOperationException("Arquivo prompt_flow_passo3.txt vazio ou não encontrado para este episódio.");
            }

            if (!Directory.Exists(ep.TakesDir))
                Directory.CreateDirectory(ep.TakesDir);

            // Regra 22: Reaproveitamento automático do Take_01.mp4 (Gancho oficial de 10s) nas Partes 2 e 3 quando aplicável
            int firstTakeNumberInPrompt = ep.FlowTakes[0].TakeNumber;
            if (ep.EpisodeNumber > 1 && _config.ReuseEp1HookTake01 && firstTakeNumberInPrompt >= 2)
            {
                string ep1Take01 = Path.Combine(ep.StoryRootPath, "EP.1", "takes", "Take_01.mp4");
                string destTake01 = Path.Combine(ep.TakesDir, "Take_01.mp4");
                if (File.Exists(ep1Take01) && (!File.Exists(destTake01) || new FileInfo(destTake01).Length < 50 * 1024))
                {
                    File.Copy(ep1Take01, destTake01, true);
                    _log(string.Format("[Google Flow] Regra 22: Take_01.mp4 (Gancho de 10s) reaproveitado automaticamente do EP.1 para {0}!", ep.EpisodeName));
                }
            }

            // Inspeção permanente de takes já existentes na pasta 'takes':
            // Só move para _backup se TODOS os takes do episódio já estiverem concluídos (refazer episódio completo).
            // Se o episódio estiver incompleto, preserva todos os Take_XX.mp4 já salvos e gera apenas os ausentes!
            HashSet<int> existingOnDisk = new HashSet<int>();
            for (int i = 0; i < ep.FlowTakes.Count; i++)
            {
                int tn = ep.FlowTakes[i].TakeNumber;
                string mp4Path = Path.Combine(ep.TakesDir, string.Format("Take_{0:00}.mp4", tn));
                if (File.Exists(mp4Path) && new FileInfo(mp4Path).Length >= 50 * 1024)
                    existingOnDisk.Add(tn);
            }

            if (_config.ArchiveOldTakesBeforeRemake && existingOnDisk.Count >= ep.FlowTakes.Count)
            {
                string[] existingMedia = Directory.GetFiles(ep.TakesDir)
                    .Where(f => Regex.IsMatch(Path.GetExtension(f), @"^\.(mp4|mov)$", RegexOptions.IgnoreCase))
                    .ToArray();
                if (existingMedia.Length > 0)
                {
                    string backupDir = Path.Combine(ep.TakesDir, "_backup_" + DateTime.Now.ToString("yyyyMMdd_HHmmss"));
                    Directory.CreateDirectory(backupDir);
                    foreach (string oldFile in existingMedia)
                    {
                        string dst = Path.Combine(backupDir, Path.GetFileName(oldFile));
                        File.Move(oldFile, dst);
                    }
                    existingOnDisk.Clear();
                    _log(string.Format("[Modo Refazer] Episódio estava 100% completo -> {0} takes antigos arquivados com segurança em '{1}'.", existingMedia.Length, backupDir));
                }
            }
            else if (existingOnDisk.Count > 0 && existingOnDisk.Count < ep.FlowTakes.Count)
            {
                string existingLabels = string.Join(", ", existingOnDisk.OrderBy(n => n).Select(n => string.Format("Take_{0:00}", n)));
                _log(string.Format("[Inspeção de Takes] {0}/{1} takes já existem na pasta 'takes' ({2}) -> preservando cenas prontas e processando apenas os {3} ausentes!",
                    existingOnDisk.Count, ep.FlowTakes.Count, existingLabels, ep.FlowTakes.Count - existingOnDisk.Count));
            }
            else if (existingOnDisk.Count >= ep.FlowTakes.Count)
            {
                _log(string.Format("[Inspeção de Takes] Todos os {0} takes já estão prontos em '{1}'! Pulando geração de vídeo.", ep.FlowTakes.Count, ep.TakesDir));
                EpisodeParser.RefreshDiskCounters(ep);
                return;
            }

            // Regra 6 + Regra 14: Sincronizar assets recorrentes/locais, alinhar nomes e espelhar 100% dos personagens e cenários para Temp\flow_assets
            List<string> allAssetFiles;
            Dictionary<string, string> ingredientToResolvedName;
            PrepareAndResolveEpisodeAssetsForFlow(ep, out allAssetFiles, out ingredientToResolvedName);

            List<FlowTakeSpec> effectiveTakes = EpisodeParser.GetEffectiveTakeSpecsForEpisode(ep);

            // Filtrar apenas os takes que ainda NÃO existem em disco e separar cenas com criança / motor Grok (direto Grok) das elegíveis ao Google Flow
            List<FlowTakeSpec> directGrokTakes = new List<FlowTakeSpec>();
            List<FlowTakeSpec> flowEligibleTakes = new List<FlowTakeSpec>();
            HashSet<int> directGrokTakeNumbers = new HashSet<int>();

            for (int i = 0; i < effectiveTakes.Count; i++)
            {
                FlowTakeSpec t = effectiveTakes[i];
                if (existingOnDisk.Contains(t.TakeNumber))
                    continue;

                bool forceGrokPref = string.Equals(t.PreferredEngine, "GrokVideo", StringComparison.OrdinalIgnoreCase);
                if (forceGrokPref || IsYouthCharacterTake(t, ep))
                {
                    directGrokTakes.Add(t);
                    directGrokTakeNumbers.Add(t.TakeNumber);
                }
                else
                {
                    flowEligibleTakes.Add(t);
                }
            }

            if (directGrokTakes.Count > 0)
            {
                string directLabels = string.Join(", ", directGrokTakes.Select(t => string.Format("Take_{0:00}", t.TakeNumber)));
                _log(string.Format("[Roteamento Direto -> Grok] {0} cena(s) com criança detectada(s) ({1}) -> pulando Google Flow e enviando direto para o Grok Vídeo!",
                    directGrokTakes.Count, directLabels));
            }

            if (flowEligibleTakes.Count > 0)
            {
                _log(string.Format("[Google Flow] Conectando ao projeto fixo no perfil '{0}' (GUILHERME)...", _config.FlowProfile));
                string sess = await _cdp.OpenOrAttachProfileTabAsync(
                    _config.FlowProfile,
                    _config.FlowProjectUrl,
                    "flow.google.com",
                    false,
                    ct);

                if ((await _cdp.EvalStringAsync(sess, "location.href", ct)).IndexOf("9b576f1d-9b0f-4103-ac8e-123edb00a1f0", StringComparison.OrdinalIgnoreCase) < 0)
                {
                    await _cdp.SendCommandAsync("Page.navigate", new Dictionary<string, object> { { "url", _config.FlowProjectUrl } }, sess, 25000, ct);
                }
                await _cdp.WaitForDocumentReadyAsync(sess, 25000, ct);
                await WaitForFlowPageLoadedAsync(sess, ct);

                // Regra 12: Limpar localStorage "flow-prompt-box-settings" caso esteja preso em VIDEO_FRAMES
                string fixedLs = await _cdp.EvalStringAsync(sess, @"
(function(){
    try {
        var v = localStorage.getItem('flow-prompt-box-settings') || '';
        if (v.indexOf('VIDEO_FRAMES') >= 0) {
            localStorage.removeItem('flow-prompt-box-settings');
            return 'RELOAD';
        }
    } catch(e) {}
    return 'OK';
})()", ct);

                if (fixedLs == "RELOAD")
                {
                    _log("[Google Flow] Regra 12: Removido 'VIDEO_FRAMES' do localStorage para restaurar múltiplos ingredientes. Recarregando...");
                    await _cdp.SendCommandAsync("Page.reload", null, sess, 20000, ct);
                    await _cdp.WaitForDocumentReadyAsync(sess, 25000, ct);
                    await WaitForFlowPageLoadedAsync(sess, ct);
                }

                // Regra 31: Garantir que o painel lateral do Agente esteja aberto (NUNCA clicar em close y~100)
                await EnsureAgentPanelOpenAsync(sess, ct);
                await Task.Delay(1000, ct);

                // Inspeção antes de criar 'Nova sessão': se já existirem takes concluídos deste episódio na tela aberta do Flow, baixa-os primeiro!
                HashSet<int> salvagedOrExhaustedInFlow = await TrySalvageCompletedTakesFromCurrentFlowScreenAsync(
                    sess,
                    ep,
                    flowEligibleTakes,
                    existingOnDisk,
                    ct);

                if (salvagedOrExhaustedInFlow.Count > 0)
                {
                    flowEligibleTakes = flowEligibleTakes
                        .Where(t => !salvagedOrExhaustedInFlow.Contains(t.TakeNumber))
                        .ToList();
                }

                if (flowEligibleTakes.Count > 0)
                {
                    // Garante que o painel lateral do Agente esteja aberto e expandido mesmo após a inspeção de takes
                    await EnsureAgentPanelOpenAsync(sess, ct);

                    // PASSO 2 OBRIGATÓRIO: Clicar em "Nova sessão" (edit_square) SEM scrollIntoView()
                    _log("[Google Flow] Passo 2: Abrindo 'Nova sessão' no painel do Agente...");
                    await ClickNewAgentSessionAsync(sess, ct);
                    await WaitForEmptyAgentSessionAsync(sess, ct);

                    // Garante caixa limpa caso existam chips residuais
                    await ClearAttachedPromptChipsAsync(sess, ct);

                    // Captura em memória C# os IDs de mídia (/asb/...) preexistentes no topo do grid virtualizado (NUNCA usar atributos DOM pois cdk-virtual-scroll-viewport recicla os nós!)
                    PreSessionGridBaseline gridBaseline = await CapturePreSessionBaselineAsync(sess, ct);

                    // PASSO 3 OBRIGATÓRIO: Upload das imagens em Temp\flow_assets + Anexar TODOS os personagens e cenários no '+' -> aba 'Imagens' -> busca -> 'Incluir no comando'
                    HashSet<string> attachedInSession = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                    if (allAssetFiles.Count > 0)
                    {
                        _log(string.Format("[Google Flow] Passo 3: Verificando/enviando {0} imagens de personagens e cenários na biblioteca do Flow...", allAssetFiles.Count));
                        await UploadAssetsToFlowProjectAsync(sess, allAssetFiles, ct);

                        List<string> orderedAllIngredients = BuildOrderedIngredientsForEpisode(ep, flowEligibleTakes, allAssetFiles, ingredientToResolvedName, 0, 5);
                        _log(string.Format("[Google Flow] Vinculando todos os {0} personagens e cenários na caixa de comando ('+' -> 'Imagens' -> Pesquisar -> 'Incluir no comando')...", orderedAllIngredients.Count));
                        int attachedCount = await AttachIngredientsViaMenuAsync(sess, orderedAllIngredients, attachedInSession, ct);

                        if (orderedAllIngredients.Count > 0 && attachedCount == 0)
                        {
                            _log("[Google Flow] Aguardando carregamento completo da biblioteca de imagens e repetindo vinculação dos personagens/cenários...");
                            await Task.Delay(4000, ct);
                            await AttachIngredientsViaMenuAsync(sess, orderedAllIngredients, attachedInSession, ct);
                        }

                        await WaitForAttachedPromptChipsImagesLoadedAsync(sess, ct);
                    }

                    // PASSO 4 OBRIGATÓRIO: Inserir o comando dos takes elegíveis ao Flow com tag [TAKE_XX] + instrução de rastreamento e clicar em Iniciar geração
                    int totalExpectedTakes = flowEligibleTakes.Count;
                    string flowPromptToSubmit = BuildFlowPromptForTakes(ep.FlowPromptText, flowEligibleTakes);

                    _log(string.Format("[Google Flow] Passo 4: Inserindo comando ({0} takes) e iniciando geração do Lote 1...", totalExpectedTakes));
                    await InsertTextIntoFlowTextboxAsync(sess, flowPromptToSubmit, false, ct);
                    await Task.Delay(1500, ct);
                    int baselineCardsBeforeSubmit = 0;
                    await ClickStartGenerationAsync(sess, ct);

                    // PASSO 5 OBRIGATÓRIO: Aguardar terminar os 5 takes (100%) e enviar 'continue' até terminar todos os takes
                    int batchNumber = 1;
                    int safetyMaxBatches = (totalExpectedTakes / 5) + 5;
                    int deletedMinorCardsTotal = 0;
                    int processedTakesBeforeCurrentBatch = 0;
                    bool flowAgentBlockedByUnusualActivity = false;
                    int lastKnownCompletedCards = 0;
                    HashSet<int> minorHandledTakeNumbers = new HashSet<int>();

                    while (batchNumber <= safetyMaxBatches)
                    {
                        ct.ThrowIfCancellationRequested();
                        _log(string.Format("[Google Flow] Aguardando conclusão 100% do Lote {0}...", batchNumber));
                        SessionPollSnapshot batchSnap = await WaitForCurrentBatchToFinishAsync(
                            sess,
                            gridBaseline,
                            batchNumber,
                            totalExpectedTakes,
                            baselineCardsBeforeSubmit,
                            deletedMinorCardsTotal,
                            ct);

                        if (batchSnap.AgentBlockedByUnusualActivity)
                        {
                            flowAgentBlockedByUnusualActivity = true;
                        }

                        int cardsCreatedInThisBatch = Math.Max(1, batchSnap.TotalSessionCards - baselineCardsBeforeSubmit);
                        int deletedMinorInBatch = 0;

                        // Sempre que uma cena não for gerada por problemas com menores de idade: gera a cena no Grok, deleta o erro no Flow e prossegue!
                        if (batchSnap.MinorFailedMountedIndices.Count > 0)
                        {
                            deletedMinorInBatch = await HandleMinorPolicyFailedTakesAsync(
                                sess,
                                gridBaseline,
                                ep,
                                flowEligibleTakes,
                                ingredientToResolvedName,
                                minorHandledTakeNumbers,
                                processedTakesBeforeCurrentBatch,
                                cardsCreatedInThisBatch,
                                ct);
                            deletedMinorCardsTotal += deletedMinorInBatch;
                            batchSnap = await InspectCurrentSessionStateAsync(sess, gridBaseline, ct);
                        }

                        int remainingGridCards = batchSnap.TotalSessionCards;
                        int processedTakesTotal = remainingGridCards + deletedMinorCardsTotal;
                        int completedCards = batchSnap.CompletedCards;
                        int failedCards = batchSnap.FailedCards;
                        lastKnownCompletedCards = completedCards;

                        if (flowAgentBlockedByUnusualActivity)
                        {
                            break;
                        }

                        if (deletedMinorCardsTotal > 0)
                        {
                            _log(string.Format("[Google Flow] Lote {0} finalizado! Takes processados: {1}/{2} (Concluídos no Flow: {3}, Gerados no Grok/menores: {4}, Outros erros: {5}).",
                                batchNumber, processedTakesTotal, totalExpectedTakes, completedCards, deletedMinorCardsTotal, failedCards));
                        }
                        else
                        {
                            _log(string.Format("[Google Flow] Lote {0} finalizado! Cards gerados nesta sessão: {1}/{2} (Concluídos: {3}, Com erro: {4}).",
                                batchNumber, remainingGridCards, totalExpectedTakes, completedCards, failedCards));
                        }

                        if (processedTakesTotal >= totalExpectedTakes)
                        {
                            break;
                        }

                        // Preparar próximo lote de 5 takes com 'continue'
                        batchNumber++;
                        processedTakesBeforeCurrentBatch = processedTakesTotal;
                        List<string> nextBatchRequired = GetRequiredIngredientsForRange(flowEligibleTakes, ingredientToResolvedName, processedTakesTotal, 5);
                        bool missingAnyFromSession = nextBatchRequired.Any(req => !attachedInSession.Contains(req));

                        if (missingAnyFromSession)
                        {
                            List<string> supplementBatch = BuildSupplementIngredientsForBatch(allAssetFiles, nextBatchRequired, attachedInSession);
                            _log(string.Format("[Google Flow] Anexando {0} personagens/cenários complementares para o Lote {1}...", supplementBatch.Count, batchNumber));
                            await ClearAttachedPromptChipsAsync(sess, ct);
                            await AttachIngredientsViaMenuAsync(sess, supplementBatch, attachedInSession, ct);
                            await WaitForAttachedPromptChipsImagesLoadedAsync(sess, ct);
                        }

                        baselineCardsBeforeSubmit = remainingGridCards;
                        string nextBatchCommand = "continue (mantendo obrigatoriamente a tag exata [TAKE_XX] no início do prompt de cada vídeo gerado)";
                        if (deletedMinorInBatch > 0 && processedTakesTotal < flowEligibleTakes.Count)
                        {
                            int nextStartTakeNum = flowEligibleTakes[processedTakesTotal].TakeNumber;
                            int nextEndTakeNum = flowEligibleTakes[Math.Min(flowEligibleTakes.Count - 1, processedTakesTotal + 4)].TakeNumber;
                            nextBatchCommand = string.Format(
                                "Ignore os vídeos bloqueados do lote anterior (eles já foram resolvidos externamente) e gere imediatamente o próximo lote de vídeos na sequência exata do roteiro (Take {0} até Take {1}), mantendo obrigatoriamente a tag exata [TAKE_XX] no início do prompt de cada vídeo gerado.",
                                nextStartTakeNum, nextEndTakeNum);
                        }

                        _log(string.Format("[Google Flow] Passo 5: Avançando para gerar o Lote {0} ({1}/{2} takes processados)...",
                            batchNumber, processedTakesTotal, totalExpectedTakes));
                        await InsertTextIntoFlowTextboxAsync(sess, nextBatchCommand, true, ct);
                        await Task.Delay(900, ct);
                        await ClickStartGenerationAsync(sess, ct);
                    }

                    // PASSO 6 OBRIGATÓRIO: Tratamento estrito de takes que derem erro (exclusivamente os desta sessão)
                    // Se houver erro de menores residual/novo, gera no Grok e deleta o erro no Flow sem retentar; demais erros seguem Regra 16 (1ª e 2ª tentativas).
                    if (!flowAgentBlockedByUnusualActivity)
                    {
                        await HandleFailedTakesStrictlyAsync(
                            sess,
                            gridBaseline,
                            ep,
                            flowEligibleTakes,
                            ingredientToResolvedName,
                            minorHandledTakeNumbers,
                            ct);
                    }

                    // PASSO 7 OBRIGATÓRIO: Após terminar as cenas no Flow -> Mapear ordem cronológica exata dos takes gerados no Flow e baixar em 720p
                    List<FlowTakeSpec> takesExpectedFromFlow = flowEligibleTakes
                        .Where(t => !minorHandledTakeNumbers.Contains(t.TakeNumber))
                        .ToList();
                    if (takesExpectedFromFlow.Count > 0 && (!flowAgentBlockedByUnusualActivity || lastKnownCompletedCards > 0))
                    {
                        await DownloadAllCompletedTakesIn720pAsync(sess, gridBaseline, ep, takesExpectedFromFlow, ct);
                    }
                }
            }

            // Verifica todos os takes do episódio que pularam direto (cenas com criança / motor Grok) OU falharam após as tentativas padrões no Google Flow -> gera o vídeo no Grok Imagine
            List<FlowTakeSpec> grokVideoTakes = new List<FlowTakeSpec>();
            List<string> flowFallbackLabels = new List<string>();

            for (int i = 0; i < effectiveTakes.Count; i++)
            {
                FlowTakeSpec takeSpec = effectiveTakes[i];
                string expectedMp4 = Path.Combine(ep.TakesDir, string.Format("Take_{0:00}.mp4", takeSpec.TakeNumber));
                bool hasValidMp4 = File.Exists(expectedMp4) && new FileInfo(expectedMp4).Length >= 50 * 1024;
                if (!hasValidMp4)
                {
                    grokVideoTakes.Add(takeSpec);
                    if (!directGrokTakeNumbers.Contains(takeSpec.TakeNumber))
                    {
                        flowFallbackLabels.Add(string.Format("Take_{0:00}", takeSpec.TakeNumber));
                    }
                }
            }

            if (flowFallbackLabels.Count > 0)
            {
                _log(string.Format("[Fallback Flow -> Grok] {0} take(s) falharam após as tentativas padrões no Google Flow ({1}) -> gerando vídeo no Grok Imagine!",
                    flowFallbackLabels.Count, string.Join(", ", flowFallbackLabels)));
            }

            if (grokVideoTakes.Count > 0)
            {
                await _grok.GenerateVideoTakesAsync(ep, grokVideoTakes, ingredientToResolvedName, ct);
            }

            EpisodeParser.RefreshDiskCounters(ep);
            _log(string.Format("[Vídeo Concluído] Todos os takes foram gerados, baixados e organizados em '{0}'!", ep.TakesDir));
        }

        public async Task RegenerateSelectedTakesAsync(
            EpisodeWorkItem ep,
            List<int> takeNumbers,
            bool forceGrokVideo,
            CancellationToken ct)
        {
            if (ep == null || takeNumbers == null || takeNumbers.Count == 0)
                return;

            if (!Directory.Exists(ep.TakesDir))
                Directory.CreateDirectory(ep.TakesDir);

            HashSet<int> selectedSet = new HashSet<int>(takeNumbers);
            string backupSubDir = Path.Combine(ep.TakesDir, "_backup_regerados_" + DateTime.Now.ToString("yyyyMMdd_HHmmss"));

            foreach (int tn in selectedSet)
            {
                string existingMp4 = Path.Combine(ep.TakesDir, string.Format("Take_{0:00}.mp4", tn));
                if (File.Exists(existingMp4))
                {
                    if (!Directory.Exists(backupSubDir))
                        Directory.CreateDirectory(backupSubDir);
                    string dst = Path.Combine(backupSubDir, Path.GetFileName(existingMp4));
                    if (File.Exists(dst)) File.Delete(dst);
                    File.Move(existingMp4, dst);
                    _log(string.Format("[Regerar Take] Take_{0:00}.mp4 anterior arquivado em '{1}'.", tn, backupSubDir));
                }
            }

            List<string> allAssetFiles;
            Dictionary<string, string> ingredientToResolvedName;
            PrepareAndResolveEpisodeAssetsForFlow(ep, out allAssetFiles, out ingredientToResolvedName);

            List<FlowTakeSpec> effectiveTakes = EpisodeParser.GetEffectiveTakeSpecsForEpisode(ep)
                .Where(t => selectedSet.Contains(t.TakeNumber))
                .OrderBy(t => t.TakeNumber)
                .ToList();

            if (effectiveTakes.Count == 0)
                return;

            // Logar se houver figurino customizado/automático aplicado nos takes selecionados
            foreach (FlowTakeSpec eff in effectiveTakes)
            {
                string ingList = string.Join(", ", eff.Ingredients);
                _log(string.Format("[Regerar Take] Take_{0:00} | Ingredientes ativos (com figurino): {1}", eff.TakeNumber, ingList));
            }

            if (forceGrokVideo)
            {
                await _grok.GenerateVideoTakesAsync(ep, effectiveTakes, ingredientToResolvedName, ct);
                EpisodeParser.RefreshDiskCounters(ep);
                _log(string.Format("[Regerar Take] {0} take(s) regerado(s) com sucesso via Grok Vídeo!", effectiveTakes.Count));
            }
            else
            {
                bool prevArchiveFlag = _config.ArchiveOldTakesBeforeRemake;
                _config.ArchiveOldTakesBeforeRemake = false;
                try
                {
                    await RunAsync(ep, ct);
                }
                finally
                {
                    _config.ArchiveOldTakesBeforeRemake = prevArchiveFlag;
                }
            }
        }

        private void PrepareAndResolveEpisodeAssetsForFlow(
            EpisodeWorkItem ep,
            out List<string> allTempAssetPaths,
            out Dictionary<string, string> ingredientToResolvedName)
        {
            allTempAssetPaths = new List<string>();
            ingredientToResolvedName = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

            EpisodeParser.SyncRecurringAssetsFromPreviousEpisodes(ep, _log);
            EpisodeParser.AutoAlignImportedAssetsOnDisk(ep, _log);

            if (!Directory.Exists(_config.TempFlowAssetsDir))
                Directory.CreateDirectory(_config.TempFlowAssetsDir);

            List<string> diskAssets = new List<string>();
            if (Directory.Exists(ep.AssetsDir))
            {
                diskAssets = Directory.GetFiles(ep.AssetsDir)
                    .Where(f => Regex.IsMatch(Path.GetExtension(f), @"^\.(jpg|jpeg|png)$", RegexOptions.IgnoreCase) && new FileInfo(f).Length > 1024)
                    .OrderBy(f => Path.GetFileName(f))
                    .ToList();
            }

            HashSet<string> addedTempPaths = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            HashSet<string> mappedDiskSources = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            // 1. Espelha 100% dos arquivos de imagem presentes na pasta assets\ do episódio
            foreach (string srcPath in diskAssets)
            {
                string fn = Path.GetFileName(srcPath);
                string dstTemp = Path.Combine(_config.TempFlowAssetsDir, fn);
                File.Copy(srcPath, dstTemp, true);
            }

            // 2. Resolve 100% dos ingredientes exigidos em prompt_flow_passo3.txt (incluindo mapeamento por similaridade quando o nome no prompt difere do disco)
            foreach (string reqIng in ep.AllRequiredFlowIngredients)
            {
                string exactDisk = diskAssets.FirstOrDefault(f =>
                    string.Equals(Path.GetFileName(f), reqIng, StringComparison.OrdinalIgnoreCase));

                if (!string.IsNullOrEmpty(exactDisk))
                {
                    mappedDiskSources.Add(exactDisk);
                    string actualName = Path.GetFileName(exactDisk);
                    string tempPath = Path.Combine(_config.TempFlowAssetsDir, actualName);
                    ingredientToResolvedName[reqIng] = actualName;
                    if (addedTempPaths.Add(tempPath))
                        allTempAssetPaths.Add(tempPath);
                }
                else
                {
                    string fuzzyDisk = EpisodeParser.FindMatchingDiskAssetFile(reqIng, diskAssets);
                    if (!string.IsNullOrEmpty(fuzzyDisk))
                    {
                        mappedDiskSources.Add(fuzzyDisk);
                        // Cria cópia com o nome exato esperado pelo prompt_flow_passo3.txt em Temp\flow_assets
                        string aliasTempPath = Path.Combine(_config.TempFlowAssetsDir, reqIng);
                        File.Copy(fuzzyDisk, aliasTempPath, true);
                        ingredientToResolvedName[reqIng] = reqIng;
                        if (addedTempPaths.Add(aliasTempPath))
                            allTempAssetPaths.Add(aliasTempPath);

                        _log(string.Format("[Google Flow | Assets] Mapeado asset equivalente do disco '{0}' -> '{1}'",
                            Path.GetFileName(fuzzyDisk), reqIng));
                    }
                    else
                    {
                        // Tenta verificar se já existe em Temp\flow_assets de execução anterior
                        string fallbackTemp = Path.Combine(_config.TempFlowAssetsDir, reqIng);
                        if (File.Exists(fallbackTemp) && new FileInfo(fallbackTemp).Length > 1024)
                        {
                            ingredientToResolvedName[reqIng] = reqIng;
                            if (addedTempPaths.Add(fallbackTemp))
                                allTempAssetPaths.Add(fallbackTemp);
                        }
                        else
                        {
                            _log(string.Format("[Google Flow | Aviso] Ingrediente '{0}' citado no roteiro não foi encontrado em '{1}'.",
                                reqIng, ep.AssetsDir));
                        }
                    }
                }
            }

            // 3. Inclui também quaisquer outros personagens e cenários presentes em ep.AssetsDir que ainda não tenham sido mapeados (garantindo que NENHUM personagem ou cenário da pasta fique de fora sem duplicar aliases)
            foreach (string srcPath in diskAssets)
            {
                if (mappedDiskSources.Contains(srcPath)) continue;
                string fn = Path.GetFileName(srcPath);
                string tempPath = Path.Combine(_config.TempFlowAssetsDir, fn);
                if (addedTempPaths.Add(tempPath))
                {
                    allTempAssetPaths.Add(tempPath);
                }
            }
        }

        private List<string> GetRequiredIngredientsForRange(
            List<FlowTakeSpec> targetTakes,
            Dictionary<string, string> ingredientToResolvedName,
            int startTakeIndex,
            int count)
        {
            List<string> list = new List<string>();
            HashSet<string> seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            int end = Math.Min(targetTakes.Count, startTakeIndex + count);
            for (int i = Math.Max(0, startTakeIndex); i < end; i++)
            {
                foreach (string rawIng in targetTakes[i].Ingredients)
                {
                    string resolved;
                    if (!ingredientToResolvedName.TryGetValue(rawIng, out resolved))
                        resolved = rawIng;

                    if (seen.Add(resolved))
                        list.Add(resolved);
                }
            }
            return list;
        }

        private List<string> BuildOrderedIngredientsForEpisode(
            EpisodeWorkItem ep,
            List<FlowTakeSpec> targetTakes,
            List<string> allTempAssetPaths,
            Dictionary<string, string> ingredientToResolvedName,
            int startTakeIndex,
            int batchSize)
        {
            List<string> ordered = new List<string>();
            HashSet<string> seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            List<string> allAvailableNames = allTempAssetPaths.Select(Path.GetFileName).ToList();
            HashSet<string> availableSet = new HashSet<string>(allAvailableNames, StringComparer.OrdinalIgnoreCase);

            // 1. TODOS os Personagens exigidos no episódio (prioridade máxima para consistência de elenco)
            foreach (string rawIng in ep.AllRequiredFlowIngredients)
            {
                string resolved;
                if (!ingredientToResolvedName.TryGetValue(rawIng, out resolved)) resolved = rawIng;
                if (!availableSet.Contains(resolved)) continue;
                if (!EpisodeParser.IsScenarioAssetName(resolved) && seen.Add(resolved))
                    ordered.Add(resolved);
            }

            // 2. Quaisquer outros Personagens existentes na pasta assets\ do episódio
            foreach (string fn in allAvailableNames)
            {
                if (!EpisodeParser.IsScenarioAssetName(fn) && seen.Add(fn))
                    ordered.Add(fn);
            }

            // 3. Cenários (e ingredientes) dos primeiros 5 takes (Lote inicial)
            foreach (string batchIng in GetRequiredIngredientsForRange(targetTakes, ingredientToResolvedName, startTakeIndex, batchSize))
            {
                if (availableSet.Contains(batchIng) && seen.Add(batchIng))
                    ordered.Add(batchIng);
            }

            // 4. TODOS os demais Cenários exigidos no restante do episódio (Takes 6..N)
            foreach (string rawIng in ep.AllRequiredFlowIngredients)
            {
                string resolved;
                if (!ingredientToResolvedName.TryGetValue(rawIng, out resolved)) resolved = rawIng;
                if (availableSet.Contains(resolved) && seen.Add(resolved))
                    ordered.Add(resolved);
            }

            // 5. Quaisquer outros Cenários presentes na pasta assets\ do episódio
            foreach (string fn in allAvailableNames)
            {
                if (seen.Add(fn))
                    ordered.Add(fn);
            }

            return ordered;
        }

        private List<string> BuildSupplementIngredientsForBatch(
            List<string> allTempAssetPaths,
            List<string> nextBatchRequired,
            HashSet<string> alreadyAttachedInSession)
        {
            List<string> ordered = new List<string>();
            HashSet<string> seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            List<string> allAvailableNames = allTempAssetPaths.Select(Path.GetFileName).ToList();

            // 1. Ingredientes inéditos obrigatórios neste lote que ainda não entraram na sessão
            foreach (string req in nextBatchRequired)
            {
                if (!alreadyAttachedInSession.Contains(req) && seen.Add(req))
                    ordered.Add(req);
            }

            // 2. Todos os ingredientes obrigatórios deste lote (personagens + cenários do lote)
            foreach (string req in nextBatchRequired)
            {
                if (seen.Add(req))
                    ordered.Add(req);
            }

            // 3. Demais personagens do episódio para manter consistência total
            foreach (string fn in allAvailableNames)
            {
                if (!EpisodeParser.IsScenarioAssetName(fn) && seen.Add(fn))
                    ordered.Add(fn);
            }

            return ordered;
        }

        private async Task EnsureAgentPanelOpenAsync(string sess, CancellationToken ct)
        {
            for (int attempt = 0; attempt < 4; attempt++)
            {
                ct.ThrowIfCancellationRequested();
                Dictionary<string, object> state = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var newSess = Array.from(document.querySelectorAll('button')).find(b => {
        var al = (b.getAttribute('aria-label') || '').toLowerCase();
        var txt = (b.innerText || '').trim().toLowerCase();
        var r = b.getBoundingClientRect();
        return r.width > 10 && r.height > 10 &&
               (al.indexOf('nova sess') >= 0 || al.indexOf('new session') >= 0 || txt === 'edit_square' || txt.indexOf('edit_square') >= 0);
    });
    if (newSess) return JSON.stringify({ step: 'OPEN' });

    var expBtn = Array.from(document.querySelectorAll('button')).find(x => {
        var al = (x.getAttribute('aria-label') || '').toLowerCase();
        var txt = (x.innerText || '').trim().toLowerCase();
        var r = x.getBoundingClientRect();
        return r.width > 10 && r.height > 10 &&
               (al === 'abrir' || al === 'expandir' || al === 'open' || al === 'expand' || txt.indexOf('expand_content') >= 0);
    });
    if (expBtn) {
        var re = expBtn.getBoundingClientRect();
        return JSON.stringify({ step: 'CLICK_EXPAND', x: Math.round(re.left + re.width/2), y: Math.round(re.top + re.height/2) });
    }

    var agBtn = document.querySelector('button.agent-mode-chip') ||
        Array.from(document.querySelectorAll('button')).find(b => {
            var al = (b.getAttribute('aria-label') || '');
            var txt = (b.innerText || '');
            var r = b.getBoundingClientRect();
            return r.width > 10 && r.height > 10 && (txt.indexOf('Agente') >= 0 || al.indexOf('Agente') >= 0 || txt.indexOf('Agent') >= 0);
        });
    if (agBtn) {
        var r = agBtn.getBoundingClientRect();
        var isChecked = agBtn.getAttribute('aria-pressed') === 'true' ||
                        ((agBtn.className || '').toString().indexOf('agent-mode-chip-checked') >= 0);
        if (!isChecked) {
            return JSON.stringify({ step: 'CLICK_AGENTE', x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) });
        }
        return JSON.stringify({ step: 'WAIT_EXPAND' });
    }
    return JSON.stringify({ step: 'OPEN' });
})()", ct);

                if (state == null) return;
                string step = Convert.ToString(state.ContainsKey("step") ? state["step"] : "OPEN");
                if (step == "OPEN")
                    return;

                if (step == "CLICK_AGENTE")
                {
                    if (attempt == 0)
                        _log("[Google Flow] Regra 31: Ativando modo Agente na barra de comando...");
                    await _cdp.ClickAtAsync(sess, Convert.ToInt32(state["x"]), Convert.ToInt32(state["y"]), ct);
                    await Task.Delay(850, ct);
                    continue;
                }

                if (step == "CLICK_EXPAND")
                {
                    _log("[Google Flow] Regra 31: Expandindo painel lateral do Agente ('Abrir' / expand_content)...");
                    await _cdp.ClickAtAsync(sess, Convert.ToInt32(state["x"]), Convert.ToInt32(state["y"]), ct);
                    await Task.Delay(1100, ct);
                    continue;
                }

                await Task.Delay(600, ct);
            }
        }

        private async Task ClickNewAgentSessionAsync(string sess, CancellationToken ct)
        {
            await EnsureAgentPanelOpenAsync(sess, ct);

            // Regra 25: NUNCA chamar scrollIntoView() em botões fixos do Google Flow!
            string findNewSessJs = @"
(function(){
    var b = Array.from(document.querySelectorAll('button')).find(x => {
        var al = (x.getAttribute('aria-label') || '').toLowerCase();
        var txt = (x.innerText || '').trim().toLowerCase();
        var r = x.getBoundingClientRect();
        return r.width > 10 && r.height > 10 &&
               (al.indexOf('nova sess') >= 0 || al.indexOf('new session') >= 0 || txt === 'edit_square' || txt.indexOf('edit_square') >= 0);
    });
    if (!b) return null;
    var r = b.getBoundingClientRect();
    return JSON.stringify({ x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) });
})()";

            Dictionary<string, object> pt = await _cdp.EvalJsonAsync(sess, findNewSessJs, ct);
            if (pt == null)
            {
                await EnsureAgentPanelOpenAsync(sess, ct);
                await Task.Delay(900, ct);
                pt = await _cdp.EvalJsonAsync(sess, findNewSessJs, ct);
            }

            if (pt == null)
                throw new InvalidOperationException("Botão 'Nova sessão' (edit_square) não encontrado no painel do Agente do Google Flow.");

            await _cdp.ClickAtAsync(sess, Convert.ToInt32(pt["x"]), Convert.ToInt32(pt["y"]), ct);
        }

        private class PreSessionGridBaseline
        {
            public HashSet<string> PreExistingAsbIds;
            public int PreExistingTopFailedCount;

            public PreSessionGridBaseline()
            {
                PreExistingAsbIds = new HashSet<string>(StringComparer.Ordinal);
                PreExistingTopFailedCount = 0;
            }
        }

        private class MountedGridTileState
        {
            public int MountedIndex;
            public string AsbId;
            public bool HasPct;
            public bool HasVideo;
            public bool HasMoreBtn;
            public bool HasErr;
            public bool IsMinorErr;
        }

        private class SessionPollSnapshot
        {
            public int TotalSessionCards;
            public int GeneratingCards;
            public int CompletedCards;
            public int FailedCards;
            public int SessionSliceEndIndex;
            public int AgentVideoOptionsCount;
            public int AgentChatBubblesCount;
            public bool AgentBusy;
            public bool AgentHasRetryButton;
            public int RetryButtonX;
            public int RetryButtonY;
            public bool AgentHasUnusualActivity;
            public bool AgentBlockedByUnusualActivity;
            public List<int> FailedMountedIndices;
            public List<int> MinorFailedMountedIndices;

            public SessionPollSnapshot()
            {
                FailedMountedIndices = new List<int>();
                MinorFailedMountedIndices = new List<int>();
            }
        }

        private class SessionCompletedVideoInfo
        {
            public int ChronologicalOrder;
            public string AsbId;
            public string AltPrompt;
        }

        private async Task WaitForFlowPageLoadedAsync(string sess, CancellationToken ct)
        {
            DateTime deadline = DateTime.UtcNow.AddSeconds(30);
            while (DateTime.UtcNow < deadline)
            {
                ct.ThrowIfCancellationRequested();
                string st = await _cdp.EvalStringAsync(sess, @"
(function(){
    var hasControls = !!Array.from(document.querySelectorAll('button')).find(b => {
        var al = (b.getAttribute('aria-label') || '');
        var txt = (b.innerText || '');
        var r = b.getBoundingClientRect();
        return r.width > 10 && r.height > 10 &&
               (al.indexOf('Adicionar elementos') >= 0 || al.indexOf('Add elements') >= 0 ||
                b.className.indexOf('add-menu-trigger') >= 0 || txt.indexOf('Agente') >= 0 ||
                al.indexOf('Nova sess') >= 0);
    });
    var hasWorkspace = !!document.querySelector('cdk-virtual-scroll-viewport, flow-agent-panel, div[role=""textbox""]');
    return (hasControls && hasWorkspace) ? 'READY' : 'WAIT';
})()", ct);

                if (st == "READY")
                {
                    await Task.Delay(4000, ct);
                    return;
                }
                await Task.Delay(600, ct);
            }
            await Task.Delay(3500, ct);
        }

        private async Task WaitForEmptyAgentSessionAsync(string sess, CancellationToken ct)
        {
            for (int i = 0; i < 10; i++)
            {
                await Task.Delay(i == 0 ? 1200 : 450, ct);
                string countStr = await _cdp.EvalStringAsync(sess, @"
(function(){
    var vids = document.querySelectorAll('flow-agent-panel flow-a2ui-video-option').length;
    var bubbles = document.querySelectorAll('flow-agent-panel flow-chat-bubble').length;
    return String(vids + bubbles);
})()", ct);
                int n;
                if (int.TryParse(countStr, out n) && n == 0)
                    return;
            }
        }

        private async Task WaitForOverlayImagesLibraryLoadedAsync(string sess, CancellationToken ct)
        {
            DateTime deadline = DateTime.UtcNow.AddSeconds(22);
            int stableReadyCount = 0;

            while (DateTime.UtcNow < deadline)
            {
                ct.ThrowIfCancellationRequested();
                string st = await _cdp.EvalStringAsync(sess, @"
(function(){
    var hasSearch = !!Array.from(document.querySelectorAll('.cdk-overlay-container input.search-input'))
        .find(el => el.getBoundingClientRect().width > 10);
    var hasUploadBtn = !!Array.from(document.querySelectorAll('.cdk-overlay-container .sidebar-upload-btn, .cdk-overlay-container button'))
        .find(el => {
            var t = (el.innerText || '') + ' ' + (el.getAttribute('aria-label') || '');
            return el.getBoundingClientRect().width > 10 &&
                   (el.className.indexOf('sidebar-upload-btn') >= 0 || t.indexOf('Enviar m') >= 0 || t.indexOf('Upload') >= 0);
        });
    if (!hasSearch && !hasUploadBtn) return 'WAIT';

    var spinners = Array.from(document.querySelectorAll(
        '.cdk-overlay-container mat-progress-spinner, .cdk-overlay-container mat-spinner, .cdk-overlay-container [role=""progressbar""], .cdk-overlay-container [class*=""uploading""]'
    )).filter(el => el.getBoundingClientRect().width > 4);
    if (spinners.length > 0) return 'SPINNING';

    var thumbs = Array.from(document.querySelectorAll('.cdk-overlay-container img.asset-thumbnail-image'))
        .filter(im => im.getBoundingClientRect().width > 10);
    if (thumbs.length > 0) {
        var loadingCount = thumbs.filter(im => !im.complete || (im.naturalWidth || 0) <= 0).length;
        if (loadingCount > 0) return 'LOADING_THUMBS';
    }
    return 'READY';
})()", ct);

                if (st == "READY")
                {
                    stableReadyCount++;
                    if (stableReadyCount >= 2)
                    {
                        await Task.Delay(1200, ct);
                        return;
                    }
                }
                else
                {
                    stableReadyCount = 0;
                }

                await Task.Delay(600, ct);
            }
            await Task.Delay(1200, ct);
        }

        private async Task WaitForAttachedPromptChipsImagesLoadedAsync(string sess, CancellationToken ct)
        {
            DateTime deadline = DateTime.UtcNow.AddSeconds(20);
            while (DateTime.UtcNow < deadline)
            {
                ct.ThrowIfCancellationRequested();
                string st = await _cdp.EvalStringAsync(sess, @"
(function(){
    var chips = Array.from(document.querySelectorAll('flow-image-ingredient-chip'))
        .filter(c => {
            if (c.closest('flow-chat-bubble')) return false;
            var r = c.getBoundingClientRect();
            return r.width > 10 && r.top > 100;
        });
    if (chips.length === 0) return 'EMPTY';
    var pending = chips.filter(c => {
        var im = c.querySelector('img');
        if (!im) return false;
        return !im.complete || (im.naturalWidth || 0) <= 0;
    }).length;
    return pending === 0 ? 'READY' : 'LOADING';
})()", ct);

                if (st == "READY" || st == "EMPTY")
                {
                    await Task.Delay(1500, ct);
                    return;
                }
                await Task.Delay(500, ct);
            }
            await Task.Delay(1500, ct);
        }

        private async Task<PreSessionGridBaseline> CapturePreSessionBaselineAsync(string sess, CancellationToken ct)
        {
            PreSessionGridBaseline baseline = new PreSessionGridBaseline();

            // 1. Vai para o topo do grid virtualizado (scrollTop = 0) e captura os primeiros ~36 cards preexistentes
            await _cdp.EvalStringAsync(sess, @"
(function(){
    var vp = document.querySelector('cdk-virtual-scroll-viewport.tiles-container') || document.querySelector('cdk-virtual-scroll-viewport');
    if (vp) vp.scrollTop = 0;
    return 'OK';
})()", ct);
            await Task.Delay(450, ct);

            Dictionary<string, object> topSnap = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var tiles = Array.from(document.querySelectorAll('flow-video-tile'));
    var asbs = [];
    var topFailedBeforeFirstAsb = 0;
    var seenFirstAsb = false;

    tiles.forEach(t => {
        var vid = t.querySelector('video');
        var img = t.querySelector('img.thumbnail') || t.querySelector('img');
        var mediaUrl = (img ? (img.getAttribute('src') || '') : '') + ' ' +
                       (vid ? ((vid.getAttribute('poster') || '') + ' ' + (vid.getAttribute('src') || '')) : '');
        var allMatches = mediaUrl.match(/\/asb\/([A-Za-z0-9_\-]{25,80})/g) || [];
        var hasMoreBtn = !!t.querySelector('button[aria-label*=""Mais op""], button[aria-label*=""More""]');
        var txt = (t.innerText || '');
        var hasErr = !vid && !hasMoreBtn && allMatches.length === 0 &&
                     /violar|pol[ií]ticas|falha|erro|n[aã]o foi poss[ií]vel|violate|failed/i.test(txt);

        if (allMatches.length > 0) {
            seenFirstAsb = true;
            allMatches.forEach(tok => asbs.push(tok.replace('/asb/', '')));
        } else if (!seenFirstAsb && hasErr) {
            topFailedBeforeFirstAsb++;
        }
    });

    return JSON.stringify({ asbs: asbs, topFailed: topFailedBeforeFirstAsb });
})()", ct);

            if (topSnap != null)
            {
                if (topSnap.ContainsKey("topFailed"))
                    baseline.PreExistingTopFailedCount = Convert.ToInt32(topSnap["topFailed"]);

                IEnumerable asbList = topSnap.ContainsKey("asbs") ? topSnap["asbs"] as IEnumerable : null;
                if (asbList != null)
                {
                    foreach (object item in asbList)
                    {
                        string id = Convert.ToString(item ?? "").Trim();
                        if (!string.IsNullOrEmpty(id))
                            baseline.PreExistingAsbIds.Add(id);
                    }
                }
            }

            // 2. Captura também uma segunda página (+550px) de âncoras preexistentes e volta para scrollTop = 0
            string page2Raw = await _cdp.EvalStringAsync(sess, @"
(function(){
    var vp = document.querySelector('cdk-virtual-scroll-viewport.tiles-container') || document.querySelector('cdk-virtual-scroll-viewport');
    if (!vp) return '';
    vp.scrollTop = 550;
    return 'SCROLLED';
})()", ct);

            if (page2Raw == "SCROLLED")
            {
                await Task.Delay(350, ct);
                Dictionary<string, object> p2Snap = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var tiles = Array.from(document.querySelectorAll('flow-video-tile'));
    var asbs = [];
    tiles.forEach(t => {
        var vid = t.querySelector('video');
        var img = t.querySelector('img.thumbnail') || t.querySelector('img');
        var mediaUrl = (img ? (img.getAttribute('src') || '') : '') + ' ' +
                       (vid ? ((vid.getAttribute('poster') || '') + ' ' + (vid.getAttribute('src') || '')) : '');
        var allMatches = mediaUrl.match(/\/asb\/([A-Za-z0-9_\-]{25,80})/g) || [];
        allMatches.forEach(tok => asbs.push(tok.replace('/asb/', '')));
    });
    var vp = document.querySelector('cdk-virtual-scroll-viewport.tiles-container') || document.querySelector('cdk-virtual-scroll-viewport');
    if (vp) vp.scrollTop = 0;
    return JSON.stringify({ asbs: asbs });
})()", ct);

                if (p2Snap != null && p2Snap.ContainsKey("asbs"))
                {
                    IEnumerable p2List = p2Snap["asbs"] as IEnumerable;
                    if (p2List != null)
                    {
                        foreach (object item in p2List)
                        {
                            string id = Convert.ToString(item ?? "").Trim();
                            if (!string.IsNullOrEmpty(id))
                                baseline.PreExistingAsbIds.Add(id);
                        }
                    }
                }
                await Task.Delay(250, ct);
            }

            return baseline;
        }

        private async Task UploadAssetsToFlowProjectAsync(string sess, List<string> tempAssetPaths, CancellationToken ct)
        {
            if (tempAssetPaths == null || tempAssetPaths.Count == 0) return;

            await ToggleAddElementsMenuAsync(sess, true, ct);
            await EnsureImagesTabInOverlayAsync(sess, ct);
            await WaitForOverlayImagesLibraryLoadedAsync(sess, ct);

            // Verifica individualmente cada personagem e cenário pelo campo "Pesquisar recursos" (a lista virtualizada só renderiza 15 itens por vez!)
            List<string> toUpload = new List<string>();
            foreach (string assetPath in tempAssetPaths)
            {
                ct.ThrowIfCancellationRequested();
                string fileName = Path.GetFileName(assetPath);
                string stem = Path.GetFileNameWithoutExtension(assetPath);

                Dictionary<string, object> existingMatch = await SearchOverlayAssetAsync(sess, stem, fileName, ct);
                if (existingMatch == null)
                {
                    toUpload.Add(assetPath);
                }
            }

            await ClearOverlaySearchInputAsync(sess, ct);

            if (toUpload.Count > 0)
            {
                string namesSummary = string.Join(", ", toUpload.Select(Path.GetFileName));
                _log(string.Format("[Google Flow] Fazendo upload de {0} novas imagens de personagens/cenários via 'Enviar mídia': {1}",
                    toUpload.Count, namesSummary));

                bool uploaded = await _cdp.UploadFilesViaFileChooserAsync(
                    sess,
                    async () => await ClickOverlayUploadButtonAsync(sess, ct),
                    toUpload,
                    ct);

                if (!uploaded)
                {
                    // Fallback: tenta input[type="file"] direto caso o DOM tenha anexado algum
                    uploaded = await _cdp.SetFileInputFilesAsync(sess, "input[type=\"file\"]", toUpload, ct);
                }

                if (uploaded)
                {
                    // Aguarda todas as imagens enviadas terminarem 100% o upload e carregarem suas miniaturas (/asb/ + img.complete) na aba "Imagens"
                    await Task.Delay(3500, ct);
                    DateTime uploadDeadline = DateTime.UtcNow.AddSeconds(Math.Min(120, 30 + (toUpload.Count * 7)));
                    List<string> pendingCheck = new List<string>(toUpload);
                    int lastReadyLogged = -1;

                    while (DateTime.UtcNow < uploadDeadline && pendingCheck.Count > 0)
                    {
                        ct.ThrowIfCancellationRequested();
                        await Task.Delay(1800, ct);
                        await ToggleAddElementsMenuAsync(sess, true, ct);
                        await EnsureImagesTabInOverlayAsync(sess, ct);

                        string overlayBusy = await _cdp.EvalStringAsync(sess, @"
(function(){
    var sp = Array.from(document.querySelectorAll(
        '.cdk-overlay-container mat-progress-spinner, .cdk-overlay-container mat-spinner, .cdk-overlay-container [role=""progressbar""], .cdk-overlay-container [class*=""uploading""]'
    )).filter(el => el.getBoundingClientRect().width > 4);
    return sp.length > 0 ? 'BUSY' : 'IDLE';
})()", ct);

                        if (overlayBusy == "BUSY")
                            continue;

                        List<string> stillPending = new List<string>();
                        foreach (string upFile in pendingCheck)
                        {
                            string fn = Path.GetFileName(upFile);
                            string st = Path.GetFileNameWithoutExtension(upFile);
                            Dictionary<string, object> found = await SearchOverlayAssetAsync(sess, st, fn, ct);
                            bool isImgReady = found != null && found.ContainsKey("imgReady") && Convert.ToBoolean(found["imgReady"]);
                            if (!isImgReady)
                            {
                                stillPending.Add(upFile);
                            }
                        }
                        pendingCheck = stillPending;

                        int readyNow = toUpload.Count - pendingCheck.Count;
                        if (readyNow != lastReadyLogged && pendingCheck.Count > 0)
                        {
                            lastReadyLogged = readyNow;
                            _log(string.Format("[Google Flow] Monitorando carregamento das imagens enviadas: {0}/{1} carregadas...",
                                readyNow, toUpload.Count));
                        }
                    }

                    await ClearOverlaySearchInputAsync(sess, ct);
                    await Task.Delay(3000, ct);
                    int indexedCount = toUpload.Count - pendingCheck.Count;
                    _log(string.Format("[Google Flow] Upload confirmado e imagens carregadas na aba Imagens: {0}/{1} novos arquivos prontos!",
                        indexedCount, toUpload.Count));
                }
                else
                {
                    _log("[Google Flow] Aviso: não foi possível acionar o seletor de upload ('Enviar mídia') no menu '+'.");
                }
            }
            else
            {
                _log(string.Format("[Google Flow] Todos os {0} personagens e cenários já estão presentes na aba 'Imagens' do projeto!", tempAssetPaths.Count));
            }
        }

        private async Task ClickOverlayUploadButtonAsync(string sess, CancellationToken ct)
        {
            await ToggleAddElementsMenuAsync(sess, true, ct);

            Dictionary<string, object> upPt = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var b = Array.from(document.querySelectorAll('.cdk-overlay-container .sidebar-upload-btn, .cdk-overlay-container button')).find(el => {
        var txt = (el.innerText || '');
        var al = (el.getAttribute('aria-label') || '');
        var r = el.getBoundingClientRect();
        return r.width > 10 && r.height > 10 &&
               (el.className.indexOf('sidebar-upload-btn') >= 0 || txt.indexOf('Enviar m') >= 0 || txt.indexOf('Upload') >= 0 || al.indexOf('Enviar m') >= 0);
    });
    if (!b) return null;
    var r = b.getBoundingClientRect();
    return JSON.stringify({ x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) });
})()", ct);

            if (upPt == null)
                throw new InvalidOperationException("Botão 'Enviar mídia' (.sidebar-upload-btn) não encontrado no menu '+' do Google Flow.");

            await _cdp.ClickAtAsync(sess, Convert.ToInt32(upPt["x"]), Convert.ToInt32(upPt["y"]), ct);
        }

        private async Task ToggleAddElementsMenuAsync(string sess, bool wantOpen, CancellationToken ct)
        {
            // Regra 25 e 31: NUNCA scrollIntoView() e NUNCA clicar em close (1499,100)
            Dictionary<string, object> info = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var isOpen = !!Array.from(document.querySelectorAll(
        '.cdk-overlay-container .side-nav-list-item, .cdk-overlay-container input.search-input, .cdk-overlay-container .detail-add-to-prompt-btn, .cdk-overlay-container .sidebar-upload-btn'
    )).find(el => el.getBoundingClientRect().width > 10);

    var plusBtn = Array.from(document.querySelectorAll('button')).find(b => {
        var al = (b.getAttribute('aria-label') || '');
        var r = b.getBoundingClientRect();
        return r.width > 10 && r.height > 10 &&
               (al.indexOf('Adicionar elementos') >= 0 || al.indexOf('Add elements') >= 0 || b.className.indexOf('add-menu-trigger') >= 0);
    });
    if (!plusBtn) return JSON.stringify({ isOpen: isOpen, found: false });
    var r = plusBtn.getBoundingClientRect();
    return JSON.stringify({
        isOpen: isOpen,
        found: true,
        x: Math.round(r.left + r.width/2),
        y: Math.round(r.top + r.height/2)
    });
})()", ct);

            if (info == null) return;
            bool isOpen = Convert.ToBoolean(info["isOpen"]);
            if (isOpen != wantOpen && Convert.ToBoolean(info["found"]))
            {
                await _cdp.ClickAtAsync(sess, Convert.ToInt32(info["x"]), Convert.ToInt32(info["y"]), ct);
                await Task.Delay(650, ct);
            }
        }

        private async Task EnsureImagesTabInOverlayAsync(string sess, CancellationToken ct)
        {
            // Importante: no menu '+' do Google Flow, o innerText da aba contém o ícone Material ("image\nImagens") dentro de .cdk-overlay-container
            Dictionary<string, object> tabInfo = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var tabs = Array.from(document.querySelectorAll('.cdk-overlay-container [role=""tab""], .cdk-overlay-container .side-nav-list-item, .cdk-overlay-container mat-list-item'));
    var t = tabs.find(el => {
        var txt = (el.innerText || '');
        var r = el.getBoundingClientRect();
        return r.width > 10 && r.height > 10 && (txt.indexOf('Imagens') >= 0 || txt.indexOf('Images') >= 0);
    });
    if (!t) return null;
    var hasSearch = !!Array.from(document.querySelectorAll('.cdk-overlay-container input.search-input')).find(i => i.getBoundingClientRect().width > 10);
    var selected = (t.getAttribute('aria-selected') === 'true') && hasSearch;
    var r = t.getBoundingClientRect();
    return JSON.stringify({
        selected: selected,
        x: Math.round(r.left + r.width/2),
        y: Math.round(r.top + r.height/2)
    });
})()", ct);

            if (tabInfo != null && !Convert.ToBoolean(tabInfo["selected"]))
            {
                await _cdp.ClickAtAsync(sess, Convert.ToInt32(tabInfo["x"]), Convert.ToInt32(tabInfo["y"]), ct);
                await Task.Delay(650, ct);
            }
        }

        private async Task ClearOverlaySearchInputAsync(string sess, CancellationToken ct)
        {
            string res = await _cdp.EvalStringAsync(sess, @"
(function(){
    var inp = document.querySelector('.cdk-overlay-container input.search-input');
    if (!inp) return 'NO_INPUT';
    if (!inp.value || inp.value.length === 0) return 'ALREADY_EMPTY';
    inp.focus();
    inp.select();
    document.execCommand('delete', false, null);
    if (inp.value && inp.value.length > 0) {
        var setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
        setter.call(inp, '');
        inp.dispatchEvent(new Event('input', { bubbles: true }));
    }
    return 'OK';
})()", ct);
            if (res == "OK")
                await Task.Delay(250, ct);
        }

        private async Task<Dictionary<string, object>> SearchOverlayAssetAsync(
            string sess,
            string searchStem,
            string fullFileName,
            CancellationToken ct)
        {
            string b64Stem = Convert.ToBase64String(Encoding.UTF8.GetBytes(searchStem ?? ""));
            string b64Full = Convert.ToBase64String(Encoding.UTF8.GetBytes(fullFileName ?? ""));

            string findAssetJs = string.Format(@"
(function(){{
    var wantStem = new TextDecoder('utf-8').decode(Uint8Array.from(atob('{0}'), c => c.charCodeAt(0))).trim().toLowerCase();
    var wantFull = new TextDecoder('utf-8').decode(Uint8Array.from(atob('{1}'), c => c.charCodeAt(0))).trim().toLowerCase();

    var items = Array.from(document.querySelectorAll('.cdk-overlay-container button.asset-item, .cdk-overlay-container [class*=""asset-item""]'))
        .filter(el => el.getBoundingClientRect().width > 12);
    if (items.length === 0) return null;

    var exact = items.find(el => {{
        var rawTxt = (el.innerText || '').trim().toLowerCase();
        var rawAria = (el.getAttribute('aria-label') || '').trim().toLowerCase();
        var lines = rawTxt.split(/\r?\n/).map(s => s.trim()).filter(s => s.length > 0);
        return rawTxt === wantFull || rawTxt === wantStem ||
               rawAria === wantFull || rawAria === wantStem ||
               lines.indexOf(wantFull) >= 0 || lines.indexOf(wantStem) >= 0;
    }});

    var chosen = exact || items.find(el => {{
        var combined = ((el.innerText || '') + ' ' + (el.getAttribute('aria-label') || '')).toLowerCase();
        return combined.indexOf(wantFull) >= 0;
    }});

    if (!chosen && items.length === 1) {{
        var onlyTxt = ((items[0].innerText || '') + ' ' + (items[0].getAttribute('aria-label') || '')).toLowerCase();
        if (onlyTxt.indexOf(wantStem) >= 0) chosen = items[0];
    }}

    if (!chosen) return null;
    var img = chosen.querySelector('img.asset-thumbnail-image') || chosen.querySelector('img');
    var imgSrc = img ? (img.getAttribute('src') || '') : '';
    var hasSpinner = !!chosen.querySelector('mat-progress-spinner, mat-spinner, [role=""progressbar""], [class*=""uploading""]');
    var imgReady = !hasSpinner && !!img && imgSrc.indexOf('/asb/') >= 0 && !!img.complete && (img.naturalWidth || 0) > 0;
    var r = chosen.getBoundingClientRect();
    return JSON.stringify({{
        matchedText: (chosen.innerText || '').trim(),
        imgReady: imgReady,
        x: Math.round(r.left + r.width/2),
        y: Math.round(r.top + r.height/2)
    }});
}})()", b64Stem, b64Full);

            // 1. Primeiro verifica se o item já está visível nos 15 cards atuais da biblioteca sem precisar digitar na busca (zero mutação de DOM!)
            Dictionary<string, object> directPt = await _cdp.EvalJsonAsync(sess, findAssetJs, ct);
            if (directPt != null && directPt.ContainsKey("imgReady") && Convert.ToBoolean(directPt["imgReady"]))
            {
                return directPt;
            }

            // 2. Caso não esteja visível na janela atual, pesquisa usando comando de edição nativo (execCommand insertText)
            string setRes = await _cdp.EvalStringAsync(sess, string.Format(@"
(function(){{
    var inp = document.querySelector('.cdk-overlay-container input.search-input');
    if (!inp) return 'NO_INPUT';
    var q = new TextDecoder('utf-8').decode(Uint8Array.from(atob('{0}'), c => c.charCodeAt(0)));
    inp.focus();
    inp.select();
    document.execCommand('insertText', false, q);
    if ((inp.value || '') !== q) {{
        var setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
        setter.call(inp, q);
        inp.dispatchEvent(new Event('input', {{ bubbles: true }}));
    }}
    return 'OK';
}})()", b64Stem), ct);

            if (setRes == "NO_INPUT")
                return directPt;

            // Aguarda filtragem da lista virtualizada e prioriza casamento EXATO do nome do arquivo
            for (int poll = 0; poll < 3; poll++)
            {
                await Task.Delay(poll == 0 ? 400 : 320, ct);

                Dictionary<string, object> matchPt = await _cdp.EvalJsonAsync(sess, findAssetJs, ct);
                if (matchPt != null)
                    return matchPt;
            }

            return null;
        }

        private async Task<int> AttachIngredientsViaMenuAsync(
            string sess,
            List<string> wantedFilenames,
            HashSet<string> attachedInSessionOut,
            CancellationToken ct)
        {
            if (wantedFilenames == null || wantedFilenames.Count == 0) return 0;

            await ToggleAddElementsMenuAsync(sess, true, ct);
            await EnsureImagesTabInOverlayAsync(sess, ct);
            await WaitForOverlayImagesLibraryLoadedAsync(sess, ct);

            int baselineChips = await CountAttachedPromptChipsAsync(sess, ct);
            int currentChips = baselineChips;
            int attachedNow = 0;

            for (int idx = 0; idx < wantedFilenames.Count; idx++)
            {
                ct.ThrowIfCancellationRequested();
                string fileName = wantedFilenames[idx];
                string stem = Path.GetFileNameWithoutExtension(fileName);
                bool itemAttached = false;
                bool capReached = false;

                for (int attempt = 1; attempt <= 3; attempt++)
                {
                    await ToggleAddElementsMenuAsync(sess, true, ct);
                    await EnsureImagesTabInOverlayAsync(sess, ct);

                    Dictionary<string, object> itemPt = await SearchOverlayAssetAsync(sess, stem, fileName, ct);
                    if (itemPt == null)
                    {
                        if (attempt < 3)
                        {
                            await Task.Delay(800, ct);
                            continue;
                        }
                        _log(string.Format("[Google Flow] Aviso: imagem '{0}' não localizada na busca da aba Imagens.", fileName));
                        break;
                    }

                    // Se a miniatura da imagem recém-enviada ainda estiver terminando de carregar, aguarda antes de clicar
                    if (itemPt.ContainsKey("imgReady") && !Convert.ToBoolean(itemPt["imgReady"]) && attempt < 3)
                    {
                        await Task.Delay(1200, ct);
                        continue;
                    }

                    await _cdp.ClickAtAsync(sess, Convert.ToInt32(itemPt["x"]), Convert.ToInt32(itemPt["y"]), ct);
                    await Task.Delay(550, ct);

                    // Regra 25: Clicar obrigatoriamente em "Incluir no comando" (aguardando habilitar se a imagem acabou de carregar)
                    Dictionary<string, object> incPt = null;
                    for (int pollInc = 0; pollInc < 6; pollInc++)
                    {
                        incPt = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var b = Array.from(document.querySelectorAll('.cdk-overlay-container button, button.detail-add-to-prompt-btn')).find(el => {
        var txt = (el.innerText || '').trim();
        var al = (el.getAttribute('aria-label') || '');
        var r = el.getBoundingClientRect();
        return r.width > 10 && r.height > 10 &&
               (txt.indexOf('Incluir no comando') >= 0 || al.indexOf('Incluir no comando') >= 0 ||
                txt.indexOf('Include in prompt') >= 0);
    });
    if (!b) return null;
    var r = b.getBoundingClientRect();
    return JSON.stringify({
        disabled: !!b.disabled || b.getAttribute('aria-disabled') === 'true',
        x: Math.round(r.left + r.width/2),
        y: Math.round(r.top + r.height/2)
    });
})()", ct);

                        if (incPt != null && !Convert.ToBoolean(incPt["disabled"]))
                            break;

                        if (incPt != null && Convert.ToBoolean(incPt["disabled"]) && currentChips >= 8)
                            break;

                        await Task.Delay(350, ct);
                    }

                    if (incPt != null)
                    {
                        if (Convert.ToBoolean(incPt["disabled"]))
                        {
                            if (currentChips >= 8)
                            {
                                capReached = true;
                                break;
                            }
                            await Task.Delay(900, ct);
                            continue;
                        }
                        await _cdp.ClickAtAsync(sess, Convert.ToInt32(incPt["x"]), Convert.ToInt32(incPt["y"]), ct);
                        await Task.Delay(600, ct);
                    }
                    else
                    {
                        await Task.Delay(500, ct);
                    }

                    int afterChips = currentChips;
                    for (int pollChip = 0; pollChip < 4; pollChip++)
                    {
                        afterChips = await CountAttachedPromptChipsAsync(sess, ct);
                        if (afterChips > currentChips)
                            break;
                        await Task.Delay(250, ct);
                    }

                    if (afterChips > currentChips)
                    {
                        currentChips = afterChips;
                        attachedNow++;
                        itemAttached = true;
                        if (attachedInSessionOut != null)
                            attachedInSessionOut.Add(fileName);

                        _log(string.Format("[Google Flow] ✔ Ingrediente vinculado ({0}/{1}): {2} (chips na caixa: {3})",
                            idx + 1, wantedFilenames.Count, fileName, currentChips));
                        break;
                    }
                }

                if (capReached)
                {
                    _log(string.Format("[Google Flow] Limite máximo de chips simultâneos por comando atingido ({0} chips). Os cenários restantes entrarão automaticamente no próximo lote 'continue'.",
                        currentChips));
                    break;
                }

                if (!itemAttached)
                {
                    _log(string.Format("[Google Flow] Aviso: não foi possível confirmar o chip de '{0}' na caixa de comando.", fileName));
                }
            }

            await ToggleAddElementsMenuAsync(sess, false, ct);
            _log(string.Format("[Google Flow] Resumo de Ingredientes: {0}/{1} personagens e cenários anexados na caixa de comando!",
                attachedNow, wantedFilenames.Count));
            return attachedNow;
        }

        private async Task<int> CountAttachedPromptChipsAsync(string sess, CancellationToken ct)
        {
            string s = await _cdp.EvalStringAsync(sess, @"
(function(){
    return Array.from(document.querySelectorAll('flow-image-ingredient-chip button.chip-container'))
        .filter(b => {
            if (b.closest('flow-chat-bubble')) return false;
            var r = b.getBoundingClientRect();
            return r.width > 10 && r.top > 100;
        }).length;
})()", ct);
            int n;
            return int.TryParse(s, out n) ? n : 0;
        }

        private async Task ClearAttachedPromptChipsAsync(string sess, CancellationToken ct)
        {
            for (int i = 0; i < 24; i++)
            {
                Dictionary<string, object> chipPt = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var chips = Array.from(document.querySelectorAll('flow-image-ingredient-chip button.chip-container'))
        .filter(b => {
            if (b.closest('flow-chat-bubble')) return false;
            var r = b.getBoundingClientRect();
            return r.width > 10 && r.top > 100;
        });
    if (chips.length === 0) return null;
    var r = chips[0].getBoundingClientRect();
    return JSON.stringify({ x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) });
})()", ct);

                if (chipPt == null) break;
                await _cdp.ClickAtAsync(sess, Convert.ToInt32(chipPt["x"]), Convert.ToInt32(chipPt["y"]), ct);
                await Task.Delay(200, ct);
            }
        }

        private async Task InsertTextIntoFlowTextboxAsync(string sess, string text, bool clearExistingText, CancellationToken ct)
        {
            string b64 = Convert.ToBase64String(Encoding.UTF8.GetBytes(text));
            string clearFlag = clearExistingText ? "true" : "false";

            string len = await _cdp.EvalStringAsync(sess, string.Format(@"
(function(){{
    var bytes = Uint8Array.from(atob('{0}'), c => c.charCodeAt(0));
    var text = new TextDecoder('utf-8').decode(bytes);
    var agentBoxes = Array.from(document.querySelectorAll('flow-agent-panel div[role=""textbox""], flow-agent-panel [contenteditable=""true""]'))
        .filter(el => el.getBoundingClientRect().width > 80);
    var allBoxes = Array.from(document.querySelectorAll('div[role=""textbox""], [contenteditable=""true""]'))
        .filter(el => el.getBoundingClientRect().width > 80);
    var boxes = agentBoxes.length > 0 ? agentBoxes : allBoxes;
    var tb = boxes[boxes.length - 1];
    if (!tb) return '-1';
    if ({1} && text.length === 0) {{
        for (var k = 0; k < allBoxes.length; k++) {{
            if (((allBoxes[k].innerText || '').trim()).length > 0) {{
                allBoxes[k].focus();
                document.execCommand('selectAll', false, null);
                document.execCommand('insertText', false, '');
            }}
        }}
        return String((tb.innerText || '').trim().length);
    }}
    tb.focus();
    if ({1}) {{
        document.execCommand('selectAll', false, null);
    }}
    document.execCommand('insertText', false, text);
    return String((tb.innerText || '').length);
}})()", b64, clearFlag), ct);

            if (len == "-1")
                throw new InvalidOperationException("Caixa de comando 'O que você quer criar?' não encontrada no Google Flow.");
        }

        private async Task<string> ReadCurrentFlowTextboxAsync(string sess, CancellationToken ct)
        {
            string txt = await _cdp.EvalStringAsync(sess, @"
(function(){
    var agentBoxes = Array.from(document.querySelectorAll('flow-agent-panel div[role=""textbox""], flow-agent-panel [contenteditable=""true""]'))
        .filter(el => el.getBoundingClientRect().width > 80);
    var allBoxes = Array.from(document.querySelectorAll('div[role=""textbox""], [contenteditable=""true""]'))
        .filter(el => el.getBoundingClientRect().width > 80);
    for (var i = agentBoxes.length - 1; i >= 0; i--) {
        var t = (agentBoxes[i].innerText || '').trim();
        if (t.length > 0) return t;
    }
    for (var j = allBoxes.length - 1; j >= 0; j--) {
        var t2 = (allBoxes[j].innerText || '').trim();
        if (t2.length > 0) return t2;
    }
    return '';
})()", ct);
            return txt ?? "";
        }

        private async Task ClickStartGenerationAsync(string sess, CancellationToken ct)
        {
            // Regra 25: NUNCA scrollIntoView() e usar Input.dispatchMouseEvent confiável
            Dictionary<string, object> sendPt = await _cdp.EvalJsonAsync(sess, @"
(function(){
    function findSend(root) {
        return Array.from(root.querySelectorAll('button')).filter(x => {
            var txt = (x.innerText || '');
            var al = (x.getAttribute('aria-label') || '');
            var r = x.getBoundingClientRect();
            return r.width > 10 && r.height > 10 && !x.disabled && x.getAttribute('aria-disabled') !== 'true' &&
                   (txt.indexOf('arrow_forward') >= 0 || txt.indexOf('send') >= 0 || al.indexOf('Iniciar') >= 0 || al.indexOf('Enviar') >= 0);
        });
    }
    var panel = document.querySelector('flow-agent-panel');
    var btns = panel ? findSend(panel) : [];
    if (btns.length === 0) btns = findSend(document);
    if (btns.length === 0) return null;
    var b = btns[btns.length - 1];
    var r = b.getBoundingClientRect();
    return JSON.stringify({ x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) });
})()", ct);

            if (sendPt == null)
                throw new InvalidOperationException("Botão 'Iniciar geração' (→) não encontrado ou desabilitado no Google Flow.");

            await _cdp.ClickAtAsync(sess, Convert.ToInt32(sendPt["x"]), Convert.ToInt32(sendPt["y"]), ct);
        }

        private List<MountedGridTileState> ParseMountedTilesFromEval(Dictionary<string, object> rawObj)
        {
            List<MountedGridTileState> list = new List<MountedGridTileState>();
            if (rawObj == null || !rawObj.ContainsKey("tiles")) return list;
            IEnumerable arr = rawObj["tiles"] as IEnumerable;
            if (arr == null) return list;

            foreach (object elem in arr)
            {
                Dictionary<string, object> d = elem as Dictionary<string, object>;
                if (d == null) continue;
                MountedGridTileState st = new MountedGridTileState();
                st.MountedIndex = d.ContainsKey("idx") ? Convert.ToInt32(d["idx"]) : list.Count;
                st.AsbId = d.ContainsKey("asb") ? Convert.ToString(d["asb"] ?? "") : "";
                st.HasPct = d.ContainsKey("hasPct") && Convert.ToBoolean(d["hasPct"]);
                st.HasVideo = d.ContainsKey("hasVideo") && Convert.ToBoolean(d["hasVideo"]);
                st.HasMoreBtn = d.ContainsKey("hasMoreBtn") && Convert.ToBoolean(d["hasMoreBtn"]);
                st.HasErr = d.ContainsKey("hasErr") && Convert.ToBoolean(d["hasErr"]);
                st.IsMinorErr = d.ContainsKey("isMinorErr") && Convert.ToBoolean(d["isMinorErr"]);
                list.Add(st);
            }
            return list;
        }

        private async Task<SessionPollSnapshot> InspectCurrentSessionStateAsync(
            string sess,
            PreSessionGridBaseline baseline,
            CancellationToken ct)
        {
            // Garante que o virtual scroll esteja em scrollTop = 0 para inspecionar os cards recém-criados no topo
            string scrolledReset = await _cdp.EvalStringAsync(sess, @"
(function(){
    var vp = document.querySelector('cdk-virtual-scroll-viewport.tiles-container') || document.querySelector('cdk-virtual-scroll-viewport');
    if (vp && vp.scrollTop > 8) {
        vp.scrollTop = 0;
        return 'RESET';
    }
    return 'AT_TOP';
})()", ct);

            if (scrolledReset == "RESET")
                await Task.Delay(380, ct);

            string inspectJs = @"
(function(){
    var tiles = Array.from(document.querySelectorAll('flow-video-tile')).map((t, idx) => {
        var vid = t.querySelector('video');
        var img = t.querySelector('img.thumbnail') || t.querySelector('img');
        var mediaUrl = (img ? (img.getAttribute('src') || '') : '') + ' ' +
                       (vid ? ((vid.getAttribute('poster') || '') + ' ' + (vid.getAttribute('src') || '')) : '');
        var m = mediaUrl.match(/\/asb\/([A-Za-z0-9_\-]{25,80})/);
        var asb = m ? m[1] : '';
        var txt = (t.innerText || '');
        var hasPct = /\b\d{1,2}%\b/.test(txt);
        var hasMoreBtn = !!t.querySelector('button[aria-label*=""Mais op""], button[aria-label*=""More""]');
        var hasVideo = !!vid || (!!img && asb.length > 0);
        var hasErr = !hasVideo && !hasMoreBtn && !asb &&
                     /violar|pol[ií]ticas|falha|erro|n[aã]o foi poss[ií]vel|violate|failed/i.test(txt);
        var isMinorErr = hasErr &&
                     /\b(menores\s+de\s+idade|menor\s+de\s+idade|relacionado\s+a\s+menores|menores|crian[cç]as?|minors?|children|child|underage)\b/i.test(txt);
        return {
            idx: idx,
            asb: asb,
            hasPct: hasPct,
            hasVideo: hasVideo,
            hasMoreBtn: hasMoreBtn,
            hasErr: hasErr,
            isMinorErr: isMinorErr
        };
    });

    var panel = document.querySelector('flow-agent-panel');
    var vidOptCount = panel ? panel.querySelectorAll('flow-a2ui-video-option').length : 0;
    var bubbleCount = panel ? panel.querySelectorAll('flow-chat-bubble').length : 0;

    var agentStopBtn = !!Array.from(document.querySelectorAll('flow-agent-panel button, button')).find(b => {
        var al = (b.getAttribute('aria-label') || '');
        var txt = (b.innerText || '').trim();
        var r = b.getBoundingClientRect();
        return r.width > 10 && (al.indexOf('Parar') >= 0 || al.indexOf('Stop') >= 0 || txt === 'stop' || txt === 'stop_circle');
    });

    var agentSpinner = !!(panel && Array.from(panel.querySelectorAll('mat-progress-spinner, [role=""progressbar""], .thinking-indicator'))
        .find(el => el.getBoundingClientRect().width > 6));

    var panelTxt = panel ? (panel.innerText || '').toLowerCase() : '';
    var hasUnusualActivity = panelTxt.indexOf('atividade incomum') >= 0 ||
                             panelTxt.indexOf('extensões do navegador') >= 0 ||
                             panelTxt.indexOf('extensoes do navegador') >= 0 ||
                             panelTxt.indexOf('unusual activity') >= 0;

    var retryBtn = panel ? Array.from(panel.querySelectorAll('button')).find(b => {
        var al = (b.getAttribute('aria-label') || '').trim().toLowerCase();
        var txt = (b.innerText || '').trim().toLowerCase();
        var r = b.getBoundingClientRect();
        return r.width > 20 && r.height > 14 && !b.disabled &&
               (txt === 'tentar de novo' || txt === 'tentar novamente' || txt === 'try again' ||
                txt.indexOf('tentar de novo') >= 0 || al.indexOf('tentar de novo') >= 0 || al.indexOf('try again') >= 0);
    }) : null;

    var retryRect = retryBtn ? retryBtn.getBoundingClientRect() : null;

    return JSON.stringify({
        tiles: tiles,
        vidOptCount: vidOptCount,
        bubbleCount: bubbleCount,
        agentBusy: agentStopBtn || agentSpinner,
        hasUnusualActivity: hasUnusualActivity,
        hasRetryBtn: !!retryRect,
        retryX: retryRect ? Math.round(retryRect.left + retryRect.width / 2) : 0,
        retryY: retryRect ? Math.round(retryRect.top + retryRect.height / 2) : 0
    });
})()";

            Dictionary<string, object> raw = await _cdp.EvalJsonAsync(sess, inspectJs, ct);
            SessionPollSnapshot snap = new SessionPollSnapshot();
            if (raw == null) return snap;

            snap.AgentVideoOptionsCount = raw.ContainsKey("vidOptCount") ? Convert.ToInt32(raw["vidOptCount"]) : 0;
            snap.AgentChatBubblesCount = raw.ContainsKey("bubbleCount") ? Convert.ToInt32(raw["bubbleCount"]) : 0;
            snap.AgentBusy = raw.ContainsKey("agentBusy") && Convert.ToBoolean(raw["agentBusy"]);
            snap.AgentHasUnusualActivity = raw.ContainsKey("hasUnusualActivity") && Convert.ToBoolean(raw["hasUnusualActivity"]);
            snap.AgentHasRetryButton = raw.ContainsKey("hasRetryBtn") && Convert.ToBoolean(raw["hasRetryBtn"]);
            snap.RetryButtonX = raw.ContainsKey("retryX") ? Convert.ToInt32(raw["retryX"]) : 0;
            snap.RetryButtonY = raw.ContainsKey("retryY") ? Convert.ToInt32(raw["retryY"]) : 0;

            List<MountedGridTileState> topTiles = ParseMountedTilesFromEval(raw);

            int anchorIdx = -1;
            for (int i = 0; i < topTiles.Count; i++)
            {
                string id = topTiles[i].AsbId;
                if (!string.IsNullOrEmpty(id) && baseline.PreExistingAsbIds.Contains(id))
                {
                    anchorIdx = i;
                    break;
                }
            }

            if (anchorIdx >= 0 || baseline.PreExistingAsbIds.Count == 0 || topTiles.Count < 30)
            {
                int rawEnd = anchorIdx >= 0 ? anchorIdx : topTiles.Count;
                int sessionEnd = Math.Max(0, rawEnd - baseline.PreExistingTopFailedCount);
                snap.SessionSliceEndIndex = sessionEnd;

                for (int i = 0; i < sessionEnd; i++)
                {
                    MountedGridTileState t = topTiles[i];
                    if (t.HasPct)
                    {
                        snap.GeneratingCards++;
                    }
                    else if (t.HasErr && !t.HasVideo)
                    {
                        snap.FailedCards++;
                        snap.FailedMountedIndices.Add(t.MountedIndex);
                        if (t.IsMinorErr)
                        {
                            snap.MinorFailedMountedIndices.Add(t.MountedIndex);
                        }
                    }
                    else if (t.HasVideo || t.HasMoreBtn || !string.IsNullOrEmpty(t.AsbId))
                    {
                        snap.CompletedCards++;
                    }
                    else
                    {
                        snap.GeneratingCards++;
                    }
                }
            }
            else
            {
                // Caso raro de episódio longo (>35 takes na mesma sessão) onde a âncora preexistente desceu além da 1ª janela virtualizada
                snap.SessionSliceEndIndex = topTiles.Count;
                HashSet<string> seenSessionCompletedAsbs = new HashSet<string>(StringComparer.Ordinal);
                int totalGenerating = 0;
                int totalFailed = 0;

                for (int i = 0; i < topTiles.Count; i++)
                {
                    MountedGridTileState t = topTiles[i];
                    if (t.HasPct) totalGenerating++;
                    else if (t.HasErr && !t.HasVideo)
                    {
                        totalFailed++;
                        snap.FailedMountedIndices.Add(t.MountedIndex);
                        if (t.IsMinorErr)
                            snap.MinorFailedMountedIndices.Add(t.MountedIndex);
                    }
                    else if (!string.IsNullOrEmpty(t.AsbId)) seenSessionCompletedAsbs.Add(t.AsbId);
                }

                for (int page = 1; page <= 4; page++)
                {
                    await _cdp.EvalStringAsync(sess, string.Format(@"
(function(){{
    var vp = document.querySelector('cdk-virtual-scroll-viewport.tiles-container') || document.querySelector('cdk-virtual-scroll-viewport');
    if (vp) vp.scrollTop = {0};
    return 'OK';
}})()", page * 520), ct);
                    await Task.Delay(320, ct);

                    Dictionary<string, object> pageRaw = await _cdp.EvalJsonAsync(sess, inspectJs, ct);
                    List<MountedGridTileState> pageTiles = ParseMountedTilesFromEval(pageRaw);
                    bool hitAnchor = false;
                    for (int i = 0; i < pageTiles.Count; i++)
                    {
                        MountedGridTileState pt = pageTiles[i];
                        if (!string.IsNullOrEmpty(pt.AsbId) && baseline.PreExistingAsbIds.Contains(pt.AsbId))
                        {
                            hitAnchor = true;
                            break;
                        }
                        if (!string.IsNullOrEmpty(pt.AsbId))
                            seenSessionCompletedAsbs.Add(pt.AsbId);
                    }
                    if (hitAnchor) break;
                }

                await _cdp.EvalStringAsync(sess, @"
(function(){
    var vp = document.querySelector('cdk-virtual-scroll-viewport.tiles-container') || document.querySelector('cdk-virtual-scroll-viewport');
    if (vp) vp.scrollTop = 0;
    return 'OK';
})()", ct);
                await Task.Delay(250, ct);

                snap.GeneratingCards = totalGenerating;
                snap.FailedCards = Math.Max(0, totalFailed - baseline.PreExistingTopFailedCount);
                snap.CompletedCards = Math.Max(seenSessionCompletedAsbs.Count, snap.AgentVideoOptionsCount);
            }

            snap.TotalSessionCards = snap.GeneratingCards + snap.CompletedCards + snap.FailedCards;
            return snap;
        }

        private async Task<HashSet<int>> TrySalvageCompletedTakesFromCurrentFlowScreenAsync(
            string sess,
            EpisodeWorkItem ep,
            List<FlowTakeSpec> missingFlowTakes,
            HashSet<int> existingOnDisk,
            CancellationToken ct)
        {
            HashSet<int> handledTakeNumbers = new HashSet<int>();
            if (missingFlowTakes == null || missingFlowTakes.Count == 0)
                return handledTakeNumbers;

            // Garante scroll no topo do grid
            await _cdp.EvalStringAsync(sess, @"
(function(){
    var vp = document.querySelector('cdk-virtual-scroll-viewport.tiles-container') || document.querySelector('cdk-virtual-scroll-viewport');
    if (vp && vp.scrollTop > 8) vp.scrollTop = 0;
    return 'OK';
})()", ct);
            await Task.Delay(300, ct);

            int maxInspectTiles = Math.Max(15, ep.FlowTakes.Count + 4);
            Dictionary<string, object> rawTop = await _cdp.EvalJsonAsync(sess, string.Format(@"
(function(){{
    var tiles = Array.from(document.querySelectorAll('flow-video-tile')).slice(0, {0}).map((t, idx) => {{
        var vid = t.querySelector('video');
        var img = t.querySelector('img.thumbnail') || t.querySelector('img');
        var mediaUrl = (img ? (img.getAttribute('src') || '') : '') + ' ' +
                       (vid ? ((vid.getAttribute('poster') || '') + ' ' + (vid.getAttribute('src') || '')) : '');
        var m = mediaUrl.match(/\/asb\/([A-Za-z0-9_\-]{{25,80}})/);
        var asb = m ? m[1] : '';
        var txt = (t.innerText || '');
        var hasPct = /\b\d{{1,2}}%\b/.test(txt);
        var hasMoreBtn = !!t.querySelector('button[aria-label*=""Mais op""], button[aria-label*=""More""]');
        var hasVideo = !!vid || (!!img && asb.length > 0);
        var hasErr = !hasVideo && !hasMoreBtn && !asb &&
                     /violar|pol[ií]ticas|falha|erro|n[aã]o foi poss[ií]vel|violate|failed/i.test(txt);
        return {{
            idx: idx,
            asb: asb,
            hasPct: hasPct,
            hasVideo: hasVideo,
            hasMoreBtn: hasMoreBtn,
            hasErr: hasErr
        }};
    }});
    return JSON.stringify({{ tiles: tiles }});
}})()", maxInspectTiles), ct);

            List<MountedGridTileState> topTiles = ParseMountedTilesFromEval(rawTop);
            List<MountedGridTileState> completedTiles = new List<MountedGridTileState>();
            for (int i = 0; i < topTiles.Count; i++)
            {
                MountedGridTileState st = topTiles[i];
                if (!st.HasPct && !st.HasErr && !string.IsNullOrEmpty(st.AsbId))
                    completedTiles.Add(st);
            }

            if (completedTiles.Count == 0)
                return handledTakeNumbers;

            Dictionary<int, string> salvagedAsbByTake = new Dictionary<int, string>();
            bool foundAnyFromThisEpisode = false;
            int maxTakeSeenInEpisode = 0;
            int consecutiveUnrelatedTiles = 0;

            for (int i = 0; i < completedTiles.Count; i++)
            {
                ct.ThrowIfCancellationRequested();
                MountedGridTileState st = completedTiles[i];
                string b64Asb = Convert.ToBase64String(Encoding.UTF8.GetBytes(st.AsbId));

                Dictionary<string, object> tileCenter = await ScrollToAndLocateTileByAsbIdAsync(sess, st.AsbId, ct);
                if (tileCenter != null)
                {
                    await _cdp.HoverAsync(sess, Convert.ToInt32(tileCenter["x"]), Convert.ToInt32(tileCenter["y"]), ct);
                    await Task.Delay(320, ct);
                }

                Dictionary<string, object> reuseBtnPt = await _cdp.EvalJsonAsync(sess, string.Format(@"
(function(){{
    var want = atob('{0}');
    var tile = Array.from(document.querySelectorAll('flow-video-tile')).find(t => {{
        var vid = t.querySelector('video');
        var img = t.querySelector('img');
        var u = (vid ? ((vid.getAttribute('src') || '') + ' ' + (vid.getAttribute('poster') || '')) : '') + ' ' +
                (img ? (img.getAttribute('src') || '') : '');
        return u.indexOf(want) >= 0;
    }});
    if (!tile) return null;
    var btn = tile.querySelector('button[aria-label*=""Reutilizar""], button[aria-label*=""Reuse""]') ||
              Array.from(tile.querySelectorAll('button')).find(b => {{
                  var al = (b.getAttribute('aria-label') || '');
                  var txt = (b.innerText || '').trim();
                  return al.indexOf('Reutilizar') >= 0 || al.indexOf('Reuse') >= 0 || txt === 'undo' || txt === 'replay';
              }});
    if (!btn) return null;
    var r = btn.getBoundingClientRect();
    if (r.width < 4) return null;
    return JSON.stringify({{ x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) }});
}})()", b64Asb), ct);

                if (reuseBtnPt == null)
                    continue;

                await _cdp.ClickAtAsync(sess, Convert.ToInt32(reuseBtnPt["x"]), Convert.ToInt32(reuseBtnPt["y"]), ct);

                await Task.Delay(650, ct);
                string prompt = await ReadCurrentFlowTextboxAsync(sess, ct);
                if (string.IsNullOrWhiteSpace(prompt))
                    continue;

                FlowTakeSpec matchedSpec = null;
                int explicitTag = TryExtractExplicitTakeTagNumber(prompt);
                if (explicitTag > 0)
                {
                    for (int k = 0; k < ep.FlowTakes.Count; k++)
                    {
                        if (ep.FlowTakes[k].TakeNumber == explicitTag)
                        {
                            double bodySim = ComputeContentWordBigramSimilarity(
                                ExtractDistinctiveTakeBody(ep.FlowTakes[k].RawPromptBody),
                                ExtractDistinctiveTakeBody(prompt));
                            if (bodySim >= 0.30)
                            {
                                matchedSpec = ep.FlowTakes[k];
                            }
                            break;
                        }
                    }
                }

                if (matchedSpec == null)
                {
                    double bestScore = 0.0;
                    for (int k = 0; k < ep.FlowTakes.Count; k++)
                    {
                        double bodySim = ComputeContentWordBigramSimilarity(
                            ExtractDistinctiveTakeBody(ep.FlowTakes[k].RawPromptBody),
                            ExtractDistinctiveTakeBody(prompt));
                        if (bodySim > bestScore)
                        {
                            bestScore = bodySim;
                            matchedSpec = ep.FlowTakes[k];
                        }
                    }
                    if (bestScore < 0.55)
                        matchedSpec = null;
                }

                if (matchedSpec != null)
                {
                    foundAnyFromThisEpisode = true;
                    consecutiveUnrelatedTiles = 0;
                    if (matchedSpec.TakeNumber > maxTakeSeenInEpisode)
                        maxTakeSeenInEpisode = matchedSpec.TakeNumber;

                    if (!existingOnDisk.Contains(matchedSpec.TakeNumber) && !salvagedAsbByTake.ContainsKey(matchedSpec.TakeNumber))
                    {
                        salvagedAsbByTake[matchedSpec.TakeNumber] = st.AsbId;
                    }
                }
                else
                {
                    consecutiveUnrelatedTiles++;
                    if (!foundAnyFromThisEpisode && consecutiveUnrelatedTiles >= 2)
                        break;
                    if (foundAnyFromThisEpisode && consecutiveUnrelatedTiles >= 3)
                        break;
                }
            }

            try
            {
                await InsertTextIntoFlowTextboxAsync(sess, "", true, ct);
                await ClearAttachedPromptChipsAsync(sess, ct);
            }
            catch { }

            if (salvagedAsbByTake.Count > 0)
            {
                List<FlowTakeSpec> toDownload = missingFlowTakes
                    .Where(t => salvagedAsbByTake.ContainsKey(t.TakeNumber))
                    .OrderBy(t => t.TakeNumber)
                    .ToList();

                string labels = string.Join(", ", toDownload.Select(t => string.Format("Take_{0:00}", t.TakeNumber)));
                _log(string.Format("[Inspeção de Takes | Google Flow] Encontrados {0} vídeos deste episódio já concluídos na tela aberta do Flow ({1}) -> baixando em 720p sem precisar regerar...",
                    toDownload.Count, labels));

                string stagingDl = Path.Combine(ep.TakesDir, "_flow_salvage_" + DateTime.Now.ToString("HHmmss"));
                Directory.CreateDirectory(stagingDl);
                await _cdp.SetDownloadBehaviorAsync(stagingDl, ct);

                for (int i = 0; i < toDownload.Count; i++)
                {
                    ct.ThrowIfCancellationRequested();
                    FlowTakeSpec spec = toDownload[i];
                    string asbId = salvagedAsbByTake[spec.TakeNumber];
                    string finalTakePath = Path.Combine(ep.TakesDir, string.Format("Take_{0:00}.mp4", spec.TakeNumber));
                    try
                    {
                        await DownloadSingleTileByAsbIdAsync(
                            sess,
                            asbId,
                            spec.TakeNumber,
                            i + 1,
                            toDownload.Count,
                            stagingDl,
                            finalTakePath,
                            ct);
                        handledTakeNumbers.Add(spec.TakeNumber);
                        existingOnDisk.Add(spec.TakeNumber);
                    }
                    catch (OperationCanceledException)
                    {
                        throw;
                    }
                    catch (Exception ex)
                    {
                        _log(string.Format("[Google Flow | Aviso] Falha ao baixar Take_{0:00}.mp4 da sessão aberta ({1}).", spec.TakeNumber, ex.Message));
                    }
                }

                try { await _cdp.ResetDownloadBehaviorToDefaultAsync(); } catch { }
                try { Directory.Delete(stagingDl, true); } catch { }
            }

            if (foundAnyFromThisEpisode)
            {
                int maxReachedTake = maxTakeSeenInEpisode;
                foreach (int dNum in existingOnDisk)
                {
                    if (dNum > maxReachedTake)
                        maxReachedTake = dNum;
                }

                List<int> alreadyAttemptedAndFailedInFlow = new List<int>();
                for (int i = 0; i < missingFlowTakes.Count; i++)
                {
                    int tn = missingFlowTakes[i].TakeNumber;
                    if (!existingOnDisk.Contains(tn) && tn <= maxReachedTake)
                    {
                        handledTakeNumbers.Add(tn);
                        alreadyAttemptedAndFailedInFlow.Add(tn);
                    }
                }

                if (alreadyAttemptedAndFailedInFlow.Count > 0)
                {
                    string failedLabels = string.Join(", ", alreadyAttemptedAndFailedInFlow.OrderBy(n => n).Select(n => string.Format("Take_{0:00}", n)));
                    _log(string.Format("[Inspeção de Takes] {0} take(s) desta sessão já foram tentados no Google Flow sem vídeo concluído ({1}) -> enviando direto para o Grok Vídeo!",
                        alreadyAttemptedAndFailedInFlow.Count, failedLabels));
                }
            }

            return handledTakeNumbers;
        }

        private async Task<SessionPollSnapshot> WaitForCurrentBatchToFinishAsync(
            string sess,
            PreSessionGridBaseline baseline,
            int batchNumber,
            int totalExpectedTakes,
            int baselineCardsBeforeSubmit,
            int deletedMinorCardsTotal,
            CancellationToken ct)
        {
            DateTime start = DateTime.UtcNow;
            DateTime deadline = start.AddMinutes(12);
            int consecutiveIdleAfterCards = 0;
            bool nudgedContinueOnce = false;
            int retryBtnClicks = 0;

            int initialBubblesAfterSubmit = -1;
            string initBubblesStr = await _cdp.EvalStringAsync(sess, @"
(function(){
    var panel = document.querySelector('flow-agent-panel');
    return panel ? String(panel.querySelectorAll('flow-chat-bubble').length) : '-1';
})()", ct);
            int parsedBubbles;
            if (int.TryParse(initBubblesStr, out parsedBubbles) && parsedBubbles >= 0)
                initialBubblesAfterSubmit = parsedBubbles;

            while (DateTime.UtcNow < deadline)
            {
                ct.ThrowIfCancellationRequested();
                await Task.Delay(6500, ct);

                SessionPollSnapshot snap = await InspectCurrentSessionStateAsync(sess, baseline, ct);

                if (deletedMinorCardsTotal > 0)
                {
                    _log(string.Format("[Google Flow | Lote {0}] Takes na sessão: {1}/{2} (no Flow: {3} | Grok/menores: {4}) | Em geração: {5} | Concluídos (100%): {6} | Erros: {7}",
                        batchNumber, snap.TotalSessionCards + deletedMinorCardsTotal, totalExpectedTakes, snap.TotalSessionCards, deletedMinorCardsTotal, snap.GeneratingCards, snap.CompletedCards, snap.FailedCards));
                }
                else
                {
                    _log(string.Format("[Google Flow | Lote {0}] Cards na sessão: {1}/{2} | Em geração: {3} | Concluídos (100%): {4} | Erros: {5}",
                        batchNumber, snap.TotalSessionCards, totalExpectedTakes, snap.GeneratingCards, snap.CompletedCards, snap.FailedCards));
                }

                bool newCardsAppeared = snap.TotalSessionCards > baselineCardsBeforeSubmit;
                if (newCardsAppeared && snap.GeneratingCards == 0 && !snap.AgentBusy)
                {
                    consecutiveIdleAfterCards++;
                    if (consecutiveIdleAfterCards >= 2)
                    {
                        return snap;
                    }
                }
                else
                {
                    consecutiveIdleAfterCards = 0;

                    // Detecção automática do aviso "Notamos uma atividade incomum... [Tentar de novo]" no painel do Agente
                    if (!newCardsAppeared && snap.GeneratingCards == 0 && !snap.AgentBusy &&
                        (snap.AgentHasRetryButton || snap.AgentHasUnusualActivity))
                    {
                        if (snap.AgentHasRetryButton && retryBtnClicks < 2 && snap.RetryButtonX > 0 && snap.RetryButtonY > 0)
                        {
                            retryBtnClicks++;
                            _log(string.Format("[Google Flow | Lote {0}] Aviso de 'atividade incomum' detectado no Agente -> aguardando 4s e clicando em 'Tentar de novo' (tentativa {1}/2)...",
                                batchNumber, retryBtnClicks));
                            await Task.Delay(4000, ct);
                            await _cdp.ClickAtAsync(sess, snap.RetryButtonX, snap.RetryButtonY, ct);
                            await Task.Delay(2500, ct);
                            continue;
                        }
                        else
                        {
                            snap.AgentBlockedByUnusualActivity = true;
                            _log("[Google Flow -> Grok] O painel do Agente do Google Flow permaneceu com aviso de 'atividade incomum' após tentar novamente -> transferindo automaticamente os takes restantes para o Grok Vídeo (9:16)!");
                            return snap;
                        }
                    }

                    double elapsedSec = (DateTime.UtcNow - start).TotalSeconds;
                    bool agentRepliedOnlyText = initialBubblesAfterSubmit >= 0 &&
                                                snap.AgentChatBubblesCount > initialBubblesAfterSubmit &&
                                                elapsedSec >= 20;

                    // Nos lotes de reciclagem (Lote 91 / Lote 92), se nenhum card novo surgiu e o Agente já ficou ocioso (ex.: erro 'Media not found' no chat), encerra imediatamente sem travar!
                    if (!newCardsAppeared && snap.GeneratingCards == 0 && !snap.AgentBusy &&
                        batchNumber >= 90 && (agentRepliedOnlyText || elapsedSec >= 25))
                    {
                        _log(string.Format("[Google Flow | Lote {0}] Tentativa encerrada sem novo card em geração ({1:0}s) -> prosseguindo...", batchNumber, elapsedSec));
                        return snap;
                    }

                    // Se em um lote 'continue' o Agente respondeu apenas em texto (ex.: 'Como deseja proceder?') ou não iniciou cards após 95s, envia reforço único
                    if (!newCardsAppeared && !snap.AgentBusy && !nudgedContinueOnce &&
                        batchNumber >= 2 && batchNumber < 90 &&
                        (agentRepliedOnlyText || elapsedSec >= 95))
                    {
                        nudgedContinueOnce = true;
                        _log(string.Format("[Google Flow | Lote {0}] Agente aguardando confirmação sem iniciar cards -> reforçando avanço imediato dos próximos takes...", batchNumber));
                        await InsertTextIntoFlowTextboxAsync(sess, "Ignore quaisquer falhas anteriores (já resolvidas) e inicie imediatamente a geração em vídeo dos próximos takes pendentes na sequência exata do roteiro, mantendo obrigatoriamente a tag exata [TAKE_XX] no início do prompt de cada vídeo.", true, ct);
                        await Task.Delay(500, ct);
                        await ClickStartGenerationAsync(sess, ct);
                    }
                }
            }

            throw new TimeoutException(string.Format("Timeout aguardando término do Lote {0} no Google Flow.", batchNumber));
        }

        private async Task<FlowTakeSpec> ResolveMinorFailedTakeSpecAsync(
            string sess,
            PreSessionGridBaseline baseline,
            EpisodeWorkItem ep,
            string reusedPrompt,
            List<FlowTakeSpec> flowEligibleTakes,
            HashSet<int> minorHandledTakeNumbers,
            int batchStartTakeIndex,
            int batchExpectedCount,
            CancellationToken ct)
        {
            if (flowEligibleTakes == null || flowEligibleTakes.Count == 0)
                return null;

            int batchEndExclusive = Math.Min(flowEligibleTakes.Count, Math.Max(0, batchStartTakeIndex) + Math.Max(1, batchExpectedCount));

            if (!string.IsNullOrWhiteSpace(reusedPrompt))
            {
                FlowTakeSpec bestSpec = null;
                double bestScore = 0.0;

                for (int i = 0; i < flowEligibleTakes.Count; i++)
                {
                    FlowTakeSpec candidate = flowEligibleTakes[i];
                    if (minorHandledTakeNumbers != null && minorHandledTakeNumbers.Contains(candidate.TakeNumber))
                        continue;

                    double s = ComputeTakeToVideoMatchScore(candidate, reusedPrompt);
                    // Em caso de empate técnico muito próximo, prioriza take pertencente à janela do lote atual
                    bool inBatchWindow = (i >= batchStartTakeIndex && i < batchEndExclusive);
                    double effectiveScore = inBatchWindow ? (s + 0.015) : s;

                    if (effectiveScore > bestScore)
                    {
                        bestScore = effectiveScore;
                        bestSpec = candidate;
                    }
                }

                if (bestSpec != null && bestScore >= 0.36)
                    return bestSpec;
            }

            // Fallback: identifica quais takes da janela do lote atual ainda não têm vídeo concluído no painel do Agente nem .mp4 salvo em disco
            List<SessionCompletedVideoInfo> completedVids = await CollectSessionVideosFromAgentPanelAsync(sess, baseline, ct);
            HashSet<int> completedTakeNums = new HashSet<int>();
            for (int v = 0; v < completedVids.Count; v++)
            {
                int tNum = IdentifyTakeNumberFromPrompt(completedVids[v].AltPrompt, flowEligibleTakes);
                if (tNum > 0)
                    completedTakeNums.Add(tNum);
            }

            for (int i = Math.Max(0, batchStartTakeIndex); i < batchEndExclusive; i++)
            {
                FlowTakeSpec candidate = flowEligibleTakes[i];
                if (minorHandledTakeNumbers != null && minorHandledTakeNumbers.Contains(candidate.TakeNumber))
                    continue;
                if (completedTakeNums.Contains(candidate.TakeNumber))
                    continue;

                string mp4Path = Path.Combine(ep.TakesDir, string.Format("Take_{0:00}.mp4", candidate.TakeNumber));
                if (File.Exists(mp4Path) && new FileInfo(mp4Path).Length >= 50 * 1024)
                    continue;

                return candidate;
            }

            return null;
        }

        private async Task<bool> DeleteMinorErrorCardInFlowAsync(
            string sess,
            PreSessionGridBaseline baseline,
            int preferredMountedIdx,
            CancellationToken ct)
        {
            SessionPollSnapshot beforeSnap = await InspectCurrentSessionStateAsync(sess, baseline, ct);
            int beforeMinorCount = beforeSnap.MinorFailedMountedIndices.Count;
            if (beforeMinorCount == 0)
                return true;

            int targetIdx = beforeSnap.MinorFailedMountedIndices.Contains(preferredMountedIdx)
                ? preferredMountedIdx
                : beforeSnap.MinorFailedMountedIndices[0];

            // 1ª tentativa: clique via coordenadas CDP no botão 'Excluir' (delete_forever) do card de menores
            await ClickFailedTileActionButtonAsync(sess, targetIdx, beforeSnap.SessionSliceEndIndex, true, true, ct);
            await Task.Delay(850, ct);

            // Se aparecer algum diálogo de confirmação no overlay, confirma imediatamente
            await _cdp.EvalStringAsync(sess, @"
(function(){
    var dlgBtns = Array.from(document.querySelectorAll('mat-dialog-container button, [role=""dialog""] button, [role=""alertdialog""] button'));
    var confirmBtn = dlgBtns.find(b => {
        var t = ((b.innerText || '') + ' ' + (b.getAttribute('aria-label') || '')).toLowerCase();
        return t.indexOf('excluir') >= 0 || t.indexOf('delete') >= 0 || t.indexOf('confirm') >= 0 || t.indexOf('remover') >= 0;
    });
    if (confirmBtn) { confirmBtn.click(); return 'CONFIRMED'; }
    return 'NONE';
})()", ct);

            SessionPollSnapshot afterSnap = await InspectCurrentSessionStateAsync(sess, baseline, ct);
            if (afterSnap.MinorFailedMountedIndices.Count < beforeMinorCount)
                return true;

            // 2ª tentativa (fallback): aciona .click() nativo direto no botão 'Excluir' (delete_forever) do card de menores
            int fallbackTargetIdx = afterSnap.MinorFailedMountedIndices.Contains(preferredMountedIdx)
                ? preferredMountedIdx
                : (afterSnap.MinorFailedMountedIndices.Count > 0 ? afterSnap.MinorFailedMountedIndices[0] : 0);

            await _cdp.EvalStringAsync(sess, string.Format(@"
(function(){{
    var tiles = Array.from(document.querySelectorAll('flow-video-tile'));
    var limit = Math.min(tiles.length, {1});
    function isMinorErr(el) {{
        if (!el) return false;
        var hasMore = !!el.querySelector('button[aria-label*=""Mais op""], button[aria-label*=""More""]');
        var hasThumb = !!(el.querySelector('img.thumbnail') || el.querySelector('video'));
        if (hasMore || hasThumb) return false;
        var txt = (el.innerText || '');
        return /violar|pol[ií]ticas|falha|erro|n[aã]o foi poss[ií]vel|violate|failed/i.test(txt) &&
               /\b(menores\s+de\s+idade|menor\s+de\s+idade|relacionado\s+a\s+menores|menores|crian[cç]as?|minors?|children|child|underage)\b/i.test(txt);
    }}
    var t = ({0} < limit && isMinorErr(tiles[{0}])) ? tiles[{0}] : null;
    if (!t) {{
        for (var i = 0; i < limit; i++) {{
            if (isMinorErr(tiles[i])) {{ t = tiles[i]; break; }}
        }}
    }}
    if (!t) return 'NO_TILE';
    var btn = Array.from(t.querySelectorAll('button')).find(b => {{
        var al = (b.getAttribute('aria-label') || '');
        var txt = (b.innerText || '').trim();
        return al.indexOf('Excluir') >= 0 || al.indexOf('Delete') >= 0 || txt.indexOf('delete') >= 0;
    }});
    if (!btn) return 'NO_BTN';
    btn.click();
    return 'CLICKED';
}})()", fallbackTargetIdx, Math.Max(1, afterSnap.SessionSliceEndIndex)), ct);

            await Task.Delay(850, ct);
            SessionPollSnapshot afterFallbackSnap = await InspectCurrentSessionStateAsync(sess, baseline, ct);
            return afterFallbackSnap.MinorFailedMountedIndices.Count < beforeMinorCount;
        }

        private async Task<int> HandleMinorPolicyFailedTakesAsync(
            string sess,
            PreSessionGridBaseline baseline,
            EpisodeWorkItem ep,
            List<FlowTakeSpec> flowEligibleTakes,
            Dictionary<string, string> ingredientToResolvedName,
            HashSet<int> minorHandledTakeNumbers,
            int batchStartTakeIndex,
            int batchExpectedCount,
            CancellationToken ct)
        {
            int deletedCount = 0;
            int safetyLimit = Math.Max(6, (flowEligibleTakes != null ? flowEligibleTakes.Count : 6) + 4);

            for (int guard = 0; guard < safetyLimit; guard++)
            {
                ct.ThrowIfCancellationRequested();
                SessionPollSnapshot snap = await InspectCurrentSessionStateAsync(sess, baseline, ct);
                if (snap.MinorFailedMountedIndices.Count == 0)
                    break;

                int minorMountedIdx = snap.MinorFailedMountedIndices[0];
                int sessionSliceLimit = snap.SessionSliceEndIndex;

                // 1. Lê o comando exato do card bloqueado por menores clicando em 'Reutilizar comando' (↩) e limpa a caixa do Flow logo em seguida
                string reusedPrompt = "";
                bool clickedReuse = await ClickFailedTileActionButtonAsync(sess, minorMountedIdx, sessionSliceLimit, false, true, ct);
                if (clickedReuse)
                {
                    await Task.Delay(900, ct);
                    reusedPrompt = await ReadCurrentFlowTextboxAsync(sess, ct);
                    await InsertTextIntoFlowTextboxAsync(sess, "", true, ct);
                    await ClearAttachedPromptChipsAsync(sess, ct);
                }

                FlowTakeSpec matchedTake = await ResolveMinorFailedTakeSpecAsync(
                    sess,
                    baseline,
                    ep,
                    reusedPrompt,
                    flowEligibleTakes,
                    minorHandledTakeNumbers,
                    batchStartTakeIndex,
                    batchExpectedCount,
                    ct);

                // 2. Gera imediatamente a cena no Grok Vídeo
                if (matchedTake != null)
                {
                    string expectedMp4 = Path.Combine(ep.TakesDir, string.Format("Take_{0:00}.mp4", matchedTake.TakeNumber));
                    bool alreadyHasValidMp4 = File.Exists(expectedMp4) && new FileInfo(expectedMp4).Length >= 50 * 1024;
                    if (!alreadyHasValidMp4)
                    {
                        _log(string.Format("[Flow -> Grok | Menores] Take_{0:00} não foi gerado no Google Flow por política de menores de idade -> gerando cena no Grok Vídeo...",
                            matchedTake.TakeNumber));
                        await _grok.GenerateVideoTakesAsync(
                            ep,
                            new List<FlowTakeSpec> { matchedTake },
                            ingredientToResolvedName,
                            ct);
                    }

                    if (minorHandledTakeNumbers != null)
                        minorHandledTakeNumbers.Add(matchedTake.TakeNumber);

                    try { await _cdp.SendCommandAsync("Page.bringToFront", null, sess, 10000, ct); } catch { }
                    await Task.Delay(500, ct);
                }
                else
                {
                    _log(string.Format("[Flow -> Grok | Menores] Card #{0} bloqueado por política de menores de idade -> será gerado no Grok Vídeo.",
                        minorMountedIdx + 1));
                }

                // 3. Deleta o card de erro no Google Flow e prossegue
                bool deletedOk = await DeleteMinorErrorCardInFlowAsync(sess, baseline, minorMountedIdx, ct);
                if (deletedOk)
                {
                    deletedCount++;
                    _log(string.Format("[Google Flow | Menores] Erro de menores excluído no Google Flow{0}. Prosseguindo...",
                        matchedTake != null ? string.Format(" (Take_{0:00})", matchedTake.TakeNumber) : ""));
                }
                else
                {
                    _log("[Google Flow | Aviso] Não foi possível confirmar a exclusão do card de erro de menores no Google Flow. Prosseguindo...");
                    break;
                }
            }

            return deletedCount;
        }

        private async Task HandleFailedTakesStrictlyAsync(
            string sess,
            PreSessionGridBaseline baseline,
            EpisodeWorkItem ep,
            List<FlowTakeSpec> targetTakes,
            Dictionary<string, string> ingredientToResolvedName,
            HashSet<int> minorHandledTakeNumbers,
            CancellationToken ct)
        {
            // Regra 16 (somente nos cards desta Nova sessão!):
            // Se houver card com erro de menores de idade, gera direto no Grok e deleta o erro no Flow sem retentar!
            // Demais erros: 1ª TENTATIVA OBRIGATÓRIA sem alterar o texto; 2ª TENTATIVA com suavização anti-bloqueio.
            Dictionary<string, int> promptRetryCounts = new Dictionary<string, int>(StringComparer.Ordinal);
            int maxOperations = Math.Max(6, targetTakes.Count * 2 + 2);

            for (int op = 0; op < maxOperations; op++)
            {
                ct.ThrowIfCancellationRequested();
                SessionPollSnapshot snap = await InspectCurrentSessionStateAsync(sess, baseline, ct);
                if (snap.FailedCards == 0 || snap.FailedMountedIndices.Count == 0)
                    return;

                if (snap.MinorFailedMountedIndices.Count > 0)
                {
                    int delMinor = await HandleMinorPolicyFailedTakesAsync(
                        sess,
                        baseline,
                        ep,
                        targetTakes,
                        ingredientToResolvedName,
                        minorHandledTakeNumbers,
                        0,
                        targetTakes.Count,
                        ct);
                    if (delMinor > 0)
                        continue;
                }

                int failedMountedIdx = snap.FailedMountedIndices[0];
                int sessionSliceLimit = snap.SessionSliceEndIndex;

                bool clickedReuse = await ClickFailedTileActionButtonAsync(sess, failedMountedIdx, sessionSliceLimit, false, false, ct);
                if (!clickedReuse)
                {
                    _log(string.Format("[Google Flow] Aviso: botão 'Reutilizar comando' não localizado no card com erro (idx {0}).", failedMountedIdx));
                    break;
                }

                await Task.Delay(950, ct);
                string reusedPrompt = await ReadCurrentFlowTextboxAsync(sess, ct);
                int explicitFailedTag = TryExtractExplicitTakeTagNumber(reusedPrompt);
                int matchedTakeNum = explicitFailedTag > 0
                    ? explicitFailedTag
                    : IdentifyTakeNumberFromPrompt(reusedPrompt, targetTakes);
                string distinctiveKey = matchedTakeNum > 0
                    ? ("take_num_" + matchedTakeNum)
                    : EpisodeParser.NormalizeForCompare(ExtractDistinctiveTakeBody(reusedPrompt));
                if (string.IsNullOrEmpty(distinctiveKey))
                    distinctiveKey = "card_slot_" + failedMountedIdx;

                string takeLabel = matchedTakeNum > 0
                    ? string.Format("Take {0:00}", matchedTakeNum)
                    : string.Format("Card #{0}", failedMountedIdx + 1);

                int prevRetries;
                if (!promptRetryCounts.TryGetValue(distinctiveKey, out prevRetries))
                    prevRetries = 0;

                if (prevRetries >= 2)
                {
                    _log(string.Format("[Google Flow -> Grok] {0} falhou após as 2 tentativas padrões no Google Flow. Limpando card com erro residual para gerar no Grok Vídeo...", takeLabel));
                    await InsertTextIntoFlowTextboxAsync(sess, "", true, ct);
                    await ClearAttachedPromptChipsAsync(sess, ct);
                    await ClickFailedTileActionButtonAsync(sess, failedMountedIdx, sessionSliceLimit, true, false, ct);
                    await Task.Delay(500, ct);
                    continue;
                }

                int currentAttemptNumber = prevRetries + 1;
                promptRetryCounts[distinctiveKey] = currentAttemptNumber;

                if (currentAttemptNumber == 1)
                {
                    _log(string.Format("[Google Flow | Regra 16] {0} apresentou erro -> 1ª TENTATIVA OBRIGATÓRIA: 'Reutilizar comando' (↩) e regerando SEM ALTERAR O TEXTO!", takeLabel));
                    if (explicitFailedTag == 0 && matchedTakeNum > 0)
                    {
                        string taggedRetry1 = InjectTakeTagIntoPromptBody(reusedPrompt, matchedTakeNum);
                        await InsertTextIntoFlowTextboxAsync(sess, taggedRetry1, true, ct);
                        await Task.Delay(400, ct);
                    }
                }
                else
                {
                    _log(string.Format("[Google Flow | Regra 16] {0} falhou novamente após 1ª regeneração -> 2ª TENTATIVA: 'Reutilizar comando' (↩) com suavização anti-bloqueio...", takeLabel));
                    string softened = SoftenPromptForSecondAttempt(reusedPrompt);
                    if (matchedTakeNum > 0)
                    {
                        softened = InjectTakeTagIntoPromptBody(softened, matchedTakeNum);
                        promptRetryCounts["take_num_" + matchedTakeNum] = 2;
                    }
                    string softenedKey = EpisodeParser.NormalizeForCompare(ExtractDistinctiveTakeBody(softened));
                    if (!string.IsNullOrEmpty(softenedKey))
                        promptRetryCounts[softenedKey] = 2;

                    await InsertTextIntoFlowTextboxAsync(sess, softened, true, ct);
                    await Task.Delay(550, ct);
                }

                // IMPORTANTE (Opção 2): NÃO excluir o card antes do envio da tentativa (excluir antes apaga a referência de mídia e causa 'Media not found'!).
                int baselineBeforeRetrySubmit = snap.TotalSessionCards;
                int minorDeletedSoFar = minorHandledTakeNumbers != null ? minorHandledTakeNumbers.Count : 0;

                await ClickStartGenerationAsync(sess, ct);
                try
                {
                    SessionPollSnapshot afterRetrySnap = await WaitForCurrentBatchToFinishAsync(
                        sess,
                        baseline,
                        90 + currentAttemptNumber,
                        targetTakes.Count,
                        baselineBeforeRetrySubmit,
                        minorDeletedSoFar,
                        ct);

                    // Se a tentativa criou um novo card no grid (concluído ou novo erro), remove o card de erro antigo para não duplicar
                    if (afterRetrySnap.TotalSessionCards > baselineBeforeRetrySubmit && afterRetrySnap.FailedMountedIndices.Count > 0)
                    {
                        int oldErrorIdx = afterRetrySnap.FailedMountedIndices.Count > 1
                            ? afterRetrySnap.FailedMountedIndices[1]
                            : afterRetrySnap.FailedMountedIndices[0];
                        await ClickFailedTileActionButtonAsync(sess, oldErrorIdx, afterRetrySnap.SessionSliceEndIndex, true, false, ct);
                        await Task.Delay(500, ct);
                    }
                }
                catch (OperationCanceledException)
                {
                    throw;
                }
                catch (Exception ex)
                {
                    _log(string.Format("[Google Flow | Aviso] Falha ao aguardar regeneração de {0} ({1}). Prosseguindo para fallback no Grok...", takeLabel, ex.Message));
                    break;
                }
            }
        }

        private async Task<bool> ClickFailedTileActionButtonAsync(
            string sess,
            int preferredMountedIdx,
            int sessionSliceLimit,
            bool clickDeleteInsteadOfReuse,
            bool requireMinorError,
            CancellationToken ct)
        {
            string wantDeleteJs = clickDeleteInsteadOfReuse ? "true" : "false";
            string requireMinorJs = requireMinorError ? "true" : "false";

            // Garante scrollTop = 0 para que o índice dentro da fatia da sessão seja exato
            await _cdp.EvalStringAsync(sess, @"
(function(){
    var vp = document.querySelector('cdk-virtual-scroll-viewport.tiles-container') || document.querySelector('cdk-virtual-scroll-viewport');
    if (vp && vp.scrollTop > 8) vp.scrollTop = 0;
    return 'OK';
})()", ct);
            await Task.Delay(250, ct);

            Dictionary<string, object> tileCenter = await _cdp.EvalJsonAsync(sess, string.Format(@"
(function(){{
    var requireMinor = {2};
    var tiles = Array.from(document.querySelectorAll('flow-video-tile'));
    var limit = Math.min(tiles.length, {1});
    var t = ({0} < limit) ? tiles[{0}] : null;
    function isErr(el) {{
        if (!el) return false;
        var hasMore = !!el.querySelector('button[aria-label*=""Mais op""], button[aria-label*=""More""]');
        var hasThumb = !!(el.querySelector('img.thumbnail') || el.querySelector('video'));
        if (hasMore || hasThumb) return false;
        var txt = (el.innerText || '');
        if (!/violar|pol[ií]ticas|falha|erro|n[aã]o foi poss[ií]vel|violate|failed/i.test(txt)) return false;
        if (requireMinor) {{
            return /\b(menores\s+de\s+idade|menor\s+de\s+idade|relacionado\s+a\s+menores|menores|crian[cç]as?|minors?|children|child|underage)\b/i.test(txt);
        }}
        return true;
    }}
    if (!isErr(t)) {{
        t = null;
        for (var i = 0; i < limit; i++) {{
            if (isErr(tiles[i])) {{ t = tiles[i]; break; }}
        }}
    }}
    if (!t) return null;
    var r = t.getBoundingClientRect();
    if (r.top < 40 || r.bottom > window.innerHeight - 20) {{
        t.scrollIntoView({{ block: 'center' }});
        r = t.getBoundingClientRect();
    }}
    return JSON.stringify({{ x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) }});
}})()", preferredMountedIdx, Math.Max(1, sessionSliceLimit), requireMinorJs), ct);

            if (tileCenter == null) return false;

            await Task.Delay(350, ct);
            await _cdp.HoverAsync(sess, Convert.ToInt32(tileCenter["x"]), Convert.ToInt32(tileCenter["y"]), ct);
            await Task.Delay(350, ct);

            Dictionary<string, object> btnPt = await _cdp.EvalJsonAsync(sess, string.Format(@"
(function(){{
    var wantDelete = {2};
    var requireMinor = {3};
    var tiles = Array.from(document.querySelectorAll('flow-video-tile'));
    var limit = Math.min(tiles.length, {1});
    function isErr(el) {{
        if (!el) return false;
        var hasMore = !!el.querySelector('button[aria-label*=""Mais op""], button[aria-label*=""More""]');
        var hasThumb = !!(el.querySelector('img.thumbnail') || el.querySelector('video'));
        if (hasMore || hasThumb) return false;
        var txt = (el.innerText || '');
        if (!/violar|pol[ií]ticas|falha|erro|n[aã]o foi poss[ií]vel|violate|failed/i.test(txt)) return false;
        if (requireMinor) {{
            return /\b(menores\s+de\s+idade|menor\s+de\s+idade|relacionado\s+a\s+menores|menores|crian[cç]as?|minors?|children|child|underage)\b/i.test(txt);
        }}
        return true;
    }}
    var t = ({0} < limit && isErr(tiles[{0}])) ? tiles[{0}] : null;
    if (!t) {{
        for (var i = 0; i < limit; i++) {{
            if (isErr(tiles[i])) {{ t = tiles[i]; break; }}
        }}
    }}
    if (!t) return null;
    var btn = Array.from(t.querySelectorAll('button')).find(b => {{
        var al = (b.getAttribute('aria-label') || '');
        var txt = (b.innerText || '').trim();
        if (wantDelete) {{
            return al.indexOf('Excluir') >= 0 || al.indexOf('Delete') >= 0 || txt.indexOf('delete') >= 0;
        }}
        return al.indexOf('Reutilizar comando') >= 0 || al.indexOf('Reuse') >= 0 || txt === 'replay' || txt === 'undo';
    }});
    if (!btn) return null;
    var r = btn.getBoundingClientRect();
    if (r.width < 5) return null;
    return JSON.stringify({{ x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) }});
}})()", preferredMountedIdx, Math.Max(1, sessionSliceLimit), wantDeleteJs, requireMinorJs), ct);

            if (btnPt == null) return false;
            await _cdp.ClickAtAsync(sess, Convert.ToInt32(btnPt["x"]), Convert.ToInt32(btnPt["y"]), ct);
            return true;
        }

        private string SoftenPromptForSecondAttempt(string text)
        {
            if (string.IsNullOrEmpty(text)) return text;
            string s = text;
            var replacements = new Tuple<string, string>[]
            {
                Tuple.Create("proporções corporais adultas", "proporções corporais de adultos maduros (acima de 30 anos)"),
                Tuple.Create("derruba uma cadeira", "se afasta da mesa apontando para a porta"),
                Tuple.Create("arremessa a cadeira", "aponta a mão com firmeza para a porta"),
                Tuple.Create("bate com força na mesa", "apoia as mãos com firmeza na mesa"),
                Tuple.Create("vender uma cria", "negociar um animal dessa sua linhagem"),
                Tuple.Create("comprar uma cria", "negociar um cavalo forte dessa sua fazenda"),
                Tuple.Create("agiota", "cobrador"),
                Tuple.Create("prestamista", "cobrador"),
                Tuple.Create("ameaçou", "disse que perderemos"),
                Tuple.Create("amenazó", "dijo que perderemos"),
                Tuple.Create("sua alma será só minha", "cobrarei a promessa combinada"),
                Tuple.Create("olhos faiscando de exaustão e revolta", "olhar expressivo de cansaço e indignação"),
                Tuple.Create("olhar fulminante", "olhar sério e firme"),
                Tuple.Create("choque e raiva", "espanto e indignação"),
                Tuple.Create("camisola modesta", "roupa caseira comprida"),
                Tuple.Create("em pânico sutil", "com nervosismo visível"),
                Tuple.Create("fúria", "indignação intensa")
            };

            foreach (var rep in replacements)
            {
                s = Regex.Replace(s, Regex.Escape(rep.Item1), rep.Item2, RegexOptions.IgnoreCase);
            }
            return s;
        }

        private sealed class TakeVideoMatchCandidate
        {
            public int TakeIndex;
            public int VideoIndex;
            public string AsbId;
            public double RawScore;
            public int ScoreBucket;
        }

        private static readonly HashSet<string> PtStopWords = new HashSet<string>(StringComparer.Ordinal)
        {
            "de", "da", "do", "das", "dos", "em", "no", "na", "nos", "nas",
            "um", "uma", "uns", "umas", "com", "por", "pro", "pra", "para",
            "que", "ao", "aos", "as", "os", "se", "ou", "mas", "seu", "sua",
            "seus", "suas", "ele", "ela", "eles", "elas", "sob", "ate", "sem",
            "esta", "estao", "homem", "mulher", "adulto", "adulta", "idoso", "idosa"
        };

        private static string ExtractDistinctiveTakeBody(string rawPrompt)
        {
            if (string.IsNullOrWhiteSpace(rawPrompt)) return "";
            string s = rawPrompt.Trim();
            s = Regex.Replace(s, @"^\[\s*TAKE(?:[_\-\s]*ID)?[_\-\s]*\d{1,3}\s*\]\s*", "", RegexOptions.IgnoreCase).Trim();
            s = Regex.Replace(s, @"^Prompt\s+de\s+V[ií]deo\s*:\s*", "", RegexOptions.IgnoreCase).Trim();
            s = Regex.Replace(s, @"^\[\s*TAKE(?:[_\-\s]*ID)?[_\-\s]*\d{1,3}\s*\]\s*", "", RegexOptions.IgnoreCase).Trim();
            s = Regex.Replace(s, @"(\r?\n)*---\s*$", "").Trim();

            // 1. Novela: remove tudo até o fechamento de "[Ação...]"
            Match actionTag = Regex.Match(s, @"\[A[cç][aã]o[^\]]*\]\s*", RegexOptions.IgnoreCase);
            if (actionTag.Success)
            {
                s = s.Substring(actionTag.Index + actionTag.Length).Trim();
            }
            else
            {
                // 2. Terror / variantes sem "[Ação...]": remove cabeçalho "[Estilo Visual]... Apenas som ambiente... ."
                string stripped = Regex.Replace(
                    s,
                    @"^\[Estilo\s+Visual\][\s\S]*?(?:Apenas\s+som\s+ambiente[^\.\r\n]*\.|\(sem\s+m[uú]sica\)\.|sem\s+voz\s+em\s+off\.|e\s+vozes\.)\s*",
                    "",
                    RegexOptions.IgnoreCase).Trim();

                if (stripped.Length > 20 && stripped.Length < s.Length)
                {
                    s = stripped;
                }
                else
                {
                    s = Regex.Replace(s, @"^\[Estilo\s+Visual\][^\.\r\n]*\.\s*", "", RegexOptions.IgnoreCase).Trim();
                }
            }

            // 3. Remove conectores de template repetidos em todos os takes para isolar 100% a ação exclusiva da cena
            s = Regex.Replace(
                s,
                @"IMEDIATAMENTE\s+(?:ele|ela)\s+fala\s+em\s+portugu[eê]s,\s*mesclando\s+o\s+movimento\s+do\s+corpo\s+com\s+a\s+fala\s+para\s+n[aã]o\s+perder\s+tempo\s+de\s+tela\s*:",
                " ",
                RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"IMEDIATAMENTE\s+o\s+[aá]udio\s+entra\s*:", " ", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"Em\s+total\s+sil[eê]ncio\s+e\s+de\s+boca\s+fechada\s*,?", " ", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"\[C[aâ]mera\s+e\s+Detalhes\]", " ", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"A\s+atua[cç][aã]o\s+facial\s+[eé]\s+[^\.]{3,70}?com\s+lip-sync\s+preciso\.", " ", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"Lip-sync\s+preciso\.", " ", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"\bSEM\s+DIALOGO\b", " ", RegexOptions.IgnoreCase);

            return s.Trim();
        }

        private static string ExtractFoleyClause(string rawPrompt)
        {
            if (string.IsNullOrWhiteSpace(rawPrompt)) return "";
            Match m = Regex.Match(rawPrompt, @"Foley\s*:\s*([^\r\n]+)", RegexOptions.IgnoreCase);
            return m.Success ? m.Groups[1].Value.Trim() : "";
        }

        private static HashSet<string> ExtractEmbeddedAssetNames(string rawPrompt)
        {
            HashSet<string> set = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            if (string.IsNullOrWhiteSpace(rawPrompt)) return set;
            MatchCollection matches = Regex.Matches(rawPrompt, @"\b([A-Za-z0-9_\-]{3,80}\.(?:jpg|jpeg|png|webp))\b", RegexOptions.IgnoreCase);
            foreach (Match m in matches)
            {
                string fn = m.Groups[1].Value.Trim();
                if (!string.IsNullOrEmpty(fn))
                    set.Add(fn);
            }
            return set;
        }

        private static string ExtractFirstQuotedDialogue(string rawPrompt)
        {
            if (string.IsNullOrWhiteSpace(rawPrompt)) return "";
            MatchCollection matches = Regex.Matches(rawPrompt, @"""([^""]{12,})""");
            string longest = "";
            foreach (Match m in matches)
            {
                string val = m.Groups[1].Value.Trim();
                if (val.Length > longest.Length)
                    longest = val;
            }
            return longest;
        }

        private static double ComputeContentWordBigramSimilarity(string textA, string textB)
        {
            string na = EpisodeParser.NormalizeForCompare(textA);
            string nb = EpisodeParser.NormalizeForCompare(textB);
            if (string.IsNullOrEmpty(na) || string.IsNullOrEmpty(nb)) return 0.0;
            if (na == nb) return 1.0;

            string[] rawA = na.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            string[] rawB = nb.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

            List<string> seqA = new List<string>(rawA.Length);
            HashSet<string> setA = new HashSet<string>(StringComparer.Ordinal);
            for (int i = 0; i < rawA.Length; i++)
            {
                string w = rawA[i];
                if (w.Length >= 3 && !PtStopWords.Contains(w))
                {
                    seqA.Add(w);
                    setA.Add(w);
                }
            }

            List<string> seqB = new List<string>(rawB.Length);
            HashSet<string> setB = new HashSet<string>(StringComparer.Ordinal);
            for (int i = 0; i < rawB.Length; i++)
            {
                string w = rawB[i];
                if (w.Length >= 3 && !PtStopWords.Contains(w))
                {
                    seqB.Add(w);
                    setB.Add(w);
                }
            }

            if (setA.Count == 0 || setB.Count == 0) return 0.0;

            int uniInter = 0;
            foreach (string w in setA)
            {
                if (setB.Contains(w)) uniInter++;
            }
            double uniDice = (2.0 * uniInter) / (setA.Count + setB.Count);

            if (seqA.Count < 2 || seqB.Count < 2)
                return uniDice;

            HashSet<string> biA = new HashSet<string>(StringComparer.Ordinal);
            for (int i = 0; i < seqA.Count - 1; i++)
                biA.Add(seqA[i] + "_" + seqA[i + 1]);

            HashSet<string> biB = new HashSet<string>(StringComparer.Ordinal);
            for (int i = 0; i < seqB.Count - 1; i++)
                biB.Add(seqB[i] + "_" + seqB[i + 1]);

            int biInter = 0;
            foreach (string bg in biA)
            {
                if (biB.Contains(bg)) biInter++;
            }
            double biDice = (biA.Count + biB.Count) > 0
                ? (2.0 * biInter) / (biA.Count + biB.Count)
                : uniDice;

            return (0.45 * uniDice) + (0.55 * biDice);
        }

        private static double ComputeTakeToVideoMatchScore(FlowTakeSpec spec, string candidatePrompt)
        {
            if (spec == null || string.IsNullOrWhiteSpace(spec.RawPromptBody) || string.IsNullOrWhiteSpace(candidatePrompt))
                return 0.0;

            int explicitTag = TryExtractExplicitTakeTagNumber(candidatePrompt);
            if (explicitTag > 0)
            {
                return explicitTag == spec.TakeNumber ? 1.0 : 0.0;
            }

            string wantBody = ExtractDistinctiveTakeBody(spec.RawPromptBody);
            string gotBody = ExtractDistinctiveTakeBody(candidatePrompt);
            double bodySim = ComputeContentWordBigramSimilarity(wantBody, gotBody);

            string wantFoley = ExtractFoleyClause(spec.RawPromptBody);
            string gotFoley = ExtractFoleyClause(candidatePrompt);
            double actionAndFoleySim = (!string.IsNullOrEmpty(wantFoley) && !string.IsNullOrEmpty(gotFoley))
                ? (0.72 * bodySim) + (0.28 * ComputeContentWordBigramSimilarity(wantFoley, gotFoley))
                : bodySim;

            string wantQuote = ExtractFirstQuotedDialogue(spec.RawPromptBody);
            string gotQuote = ExtractFirstQuotedDialogue(candidatePrompt);
            string normWantQuote = EpisodeParser.NormalizeForCompare(wantQuote);
            string normGotQuote = EpisodeParser.NormalizeForCompare(gotQuote);
            string normCandidateFull = EpisodeParser.NormalizeForCompare(candidatePrompt);

            double score = actionAndFoleySim;

            bool wantHasQuote = normWantQuote.Length >= 12;
            bool gotHasQuote = normGotQuote.Length >= 12;

            if (wantHasQuote && normCandidateFull.IndexOf(normWantQuote, StringComparison.Ordinal) >= 0)
            {
                score = Math.Max(actionAndFoleySim, 0.72 + (0.28 * actionAndFoleySim));
                if (actionAndFoleySim >= 0.72)
                    score = Math.Max(score, 0.94 + (0.06 * actionAndFoleySim));
            }
            else if (wantHasQuote && gotHasQuote)
            {
                double quoteSim = ComputeContentWordBigramSimilarity(normWantQuote, normGotQuote);
                if (quoteSim >= 0.78)
                {
                    score = (0.52 * quoteSim) + (0.48 * actionAndFoleySim);
                }
                else if (quoteSim < 0.35)
                {
                    score = actionAndFoleySim * 0.28;
                }
                else
                {
                    score = (0.50 * quoteSim) + (0.50 * actionAndFoleySim);
                }
            }
            else if (wantHasQuote != gotHasQuote)
            {
                score = actionAndFoleySim * 0.32;
            }

            HashSet<string> wantAssets = ExtractEmbeddedAssetNames(spec.RawPromptBody);
            if (wantAssets.Count == 0 && spec.Ingredients != null)
            {
                for (int i = 0; i < spec.Ingredients.Count; i++)
                {
                    if (!string.IsNullOrWhiteSpace(spec.Ingredients[i]))
                        wantAssets.Add(spec.Ingredients[i].Trim());
                }
            }

            HashSet<string> gotAssets = ExtractEmbeddedAssetNames(candidatePrompt);
            if (wantAssets.Count > 0 && gotAssets.Count > 0)
            {
                int inter = 0;
                HashSet<string> union = new HashSet<string>(wantAssets, StringComparer.OrdinalIgnoreCase);
                foreach (string ga in gotAssets)
                {
                    if (wantAssets.Contains(ga)) inter++;
                    union.Add(ga);
                }
                double assetJaccard = union.Count > 0 ? ((double)inter / union.Count) : 1.0;
                score = score * (0.65 + (0.35 * assetJaccard));
            }

            return Math.Max(0.0, Math.Min(1.0, score));
        }

        private static int IdentifyTakeNumberFromPrompt(string promptText, List<FlowTakeSpec> targetTakes)
        {
            if (string.IsNullOrWhiteSpace(promptText) || targetTakes == null || targetTakes.Count == 0)
                return 0;

            int bestTakeNum = 0;
            double bestScore = 0.0;

            for (int i = 0; i < targetTakes.Count; i++)
            {
                FlowTakeSpec spec = targetTakes[i];
                double score = ComputeTakeToVideoMatchScore(spec, promptText);
                if (score > bestScore)
                {
                    bestScore = score;
                    bestTakeNum = spec.TakeNumber;
                }
            }

            return bestScore >= 0.62 ? bestTakeNum : 0;
        }

        private async Task<List<SessionCompletedVideoInfo>> CollectSessionVideosFromAgentPanelAsync(
            string sess,
            PreSessionGridBaseline baseline,
            CancellationToken ct)
        {
            List<SessionCompletedVideoInfo> result = new List<SessionCompletedVideoInfo>();

            // Garante que o painel lateral do Agente esteja visível para ler 100% das opções de vídeo desta sessão
            await EnsureAgentPanelOpenAsync(sess, ct);

            // CRÍTICO: Em lotes de 5 vídeos, o Google Flow exibe apenas 4 cards (2x2) por bolha e oculta o 5º vídeo atrás do botão "Ver tudo"!
            for (int expandPass = 0; expandPass < 3; expandPass++)
            {
                ct.ThrowIfCancellationRequested();
                string expandRes = await _cdp.EvalStringAsync(sess, @"
(function(){
    var panel = document.querySelector('flow-agent-panel');
    if (!panel) return '0';
    var scroller = panel.querySelector('.scroll-viewport') ||
                   Array.from(panel.querySelectorAll('div')).find(el => el.scrollHeight > el.clientHeight + 40);
    var clickedNodes = [];
    function clickExpandButtons() {
        var btns = Array.from(panel.querySelectorAll('button')).filter(b => {
            if (clickedNodes.indexOf(b) >= 0) return false;
            var t = ((b.innerText || '') + ' ' + (b.getAttribute('aria-label') || '')).trim();
            if (!t) return false;
            if (/racioc[ií]nio|thinking|menos|less/i.test(t)) return false;
            return /\b(ver tudo|ver mais|mostrar tudo|mostrar mais|view all|show all|see all)\b/i.test(t);
        });
        btns.forEach(b => {
            clickedNodes.push(b);
            try { b.click(); } catch(e) {}
        });
    }
    clickExpandButtons();
    if (scroller && scroller.scrollHeight > scroller.clientHeight + 40) {
        for (var pos = 0; pos <= scroller.scrollHeight; pos += Math.max(800, scroller.clientHeight * 2)) {
            scroller.scrollTop = pos;
            clickExpandButtons();
        }
        scroller.scrollTop = scroller.scrollHeight;
        clickExpandButtons();
    }
    return String(clickedNodes.length);
})()", ct);

                int clickedCount;
                if (!int.TryParse(expandRes, out clickedCount) || clickedCount <= 0)
                    break;

                await Task.Delay(550, ct);
            }

            Dictionary<string, object> raw = null;
            for (int poll = 0; poll < 6; poll++)
            {
                ct.ThrowIfCancellationRequested();
                raw = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var panel = document.querySelector('flow-agent-panel');
    if (!panel) return JSON.stringify({ opts: [], missingAsb: 0 });
    var nodes = Array.from(panel.querySelectorAll('flow-a2ui-video-option'));
    var missingAsb = 0;
    var opts = nodes.map((vo, idx) => {
        var img = vo.querySelector('img');
        var vid = vo.querySelector('video');
        var mediaUrl = (img ? (img.getAttribute('src') || '') : '') + ' ' +
                       (vid ? ((vid.getAttribute('poster') || '') + ' ' + (vid.getAttribute('src') || '')) : '');
        var m = mediaUrl.match(/\/asb\/([A-Za-z0-9_\-]{25,80})/);
        if (!m) {
            missingAsb++;
            try { vo.scrollIntoView({ block: 'center', inline: 'nearest' }); } catch(e) {}
        }
        var alt = img ? (img.getAttribute('alt') || '') : '';
        if (!alt && vid) alt = (vid.getAttribute('aria-label') || '');
        return {
            idx: idx,
            asb: m ? m[1] : '',
            alt: alt
        };
    });
    return JSON.stringify({ opts: opts, missingAsb: missingAsb });
})()", ct);

                if (raw == null) break;
                int missingAsb = raw.ContainsKey("missingAsb") ? Convert.ToInt32(raw["missingAsb"]) : 0;
                if (missingAsb == 0) break;
                await Task.Delay(350, ct);
            }

            if (raw == null || !raw.ContainsKey("opts")) return result;
            IEnumerable arr = raw["opts"] as IEnumerable;
            if (arr == null) return result;

            foreach (object elem in arr)
            {
                Dictionary<string, object> d = elem as Dictionary<string, object>;
                if (d == null) continue;
                string asb = d.ContainsKey("asb") ? Convert.ToString(d["asb"] ?? "").Trim() : "";
                if (string.IsNullOrEmpty(asb)) continue;
                if (baseline != null && baseline.PreExistingAsbIds.Contains(asb)) continue;

                SessionCompletedVideoInfo info = new SessionCompletedVideoInfo();
                info.ChronologicalOrder = d.ContainsKey("idx") ? Convert.ToInt32(d["idx"]) : result.Count;
                info.AsbId = asb;
                info.AltPrompt = d.ContainsKey("alt") ? Convert.ToString(d["alt"] ?? "") : "";
                result.Add(info);
            }
            return result;
        }

        private async Task<List<string>> CollectSessionGridAsbIdsOldestFirstAsync(
            string sess,
            PreSessionGridBaseline baseline,
            CancellationToken ct)
        {
            List<string> newestFirst = new List<string>();
            HashSet<string> seen = new HashSet<string>(StringComparer.Ordinal);

            for (int page = 0; page <= 20; page++)
            {
                string scrollStatus = await _cdp.EvalStringAsync(sess, string.Format(@"
(function(){{
    var vp = document.querySelector('cdk-virtual-scroll-viewport.tiles-container') || document.querySelector('cdk-virtual-scroll-viewport');
    if (!vp) return 'NO_VP';
    var maxScroll = Math.max(0, vp.scrollHeight - vp.clientHeight);
    var nextTop = Math.min(maxScroll, {0});
    vp.scrollTop = nextTop;
    return (nextTop >= maxScroll && {0} > 0) ? 'AT_END' : 'OK';
}})()", page * 480), ct);
                await Task.Delay(320, ct);

                Dictionary<string, object> raw = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var list = Array.from(document.querySelectorAll('flow-video-tile')).map(t => {
        var vid = t.querySelector('video');
        var img = t.querySelector('img.thumbnail') || t.querySelector('img');
        var mediaUrl = (img ? (img.getAttribute('src') || '') : '') + ' ' +
                       (vid ? ((vid.getAttribute('poster') || '') + ' ' + (vid.getAttribute('src') || '')) : '');
        var m = mediaUrl.match(/\/asb\/([A-Za-z0-9_\-]{25,80})/);
        var txt = (t.innerText || '');
        var ok = !/\b\d{1,2}%\b/.test(txt) && (!!vid || !!img || !!t.querySelector('button[aria-label*=""Mais op""]'));
        return { asb: m ? m[1] : '', ok: ok };
    });
    return JSON.stringify({ list: list });
})()", ct);

                if (raw == null || !raw.ContainsKey("list")) break;
                IEnumerable arr = raw["list"] as IEnumerable;
                if (arr == null) break;

                bool hitPreExistingAnchor = false;
                int countInPage = 0;
                foreach (object elem in arr)
                {
                    countInPage++;
                    Dictionary<string, object> d = elem as Dictionary<string, object>;
                    if (d == null) continue;
                    string asb = d.ContainsKey("asb") ? Convert.ToString(d["asb"] ?? "").Trim() : "";
                    bool ok = d.ContainsKey("ok") && Convert.ToBoolean(d["ok"]);
                    if (string.IsNullOrEmpty(asb)) continue;

                    if (baseline != null && baseline.PreExistingAsbIds.Contains(asb))
                    {
                        hitPreExistingAnchor = true;
                        break;
                    }
                    if (ok && seen.Add(asb))
                        newestFirst.Add(asb);
                }

                if (hitPreExistingAnchor || scrollStatus == "AT_END" || scrollStatus == "NO_VP" ||
                    ((baseline == null || baseline.PreExistingAsbIds.Count == 0) && countInPage < 30 && scrollStatus == "AT_END"))
                    break;
            }

            await _cdp.EvalStringAsync(sess, @"
(function(){
    var vp = document.querySelector('cdk-virtual-scroll-viewport.tiles-container') || document.querySelector('cdk-virtual-scroll-viewport');
    if (vp) vp.scrollTop = 0;
    return 'OK';
})()", ct);
            await Task.Delay(250, ct);

            newestFirst.Reverse();
            return newestFirst;
        }

        private List<Tuple<FlowTakeSpec, string>> BuildChronologicalDownloadPlan(
            List<FlowTakeSpec> targetTakes,
            List<SessionCompletedVideoInfo> agentVideos,
            List<string> gridAsbIdsOldestFirst)
        {
            HashSet<string> validInGrid = new HashSet<string>(gridAsbIdsOldestFirst ?? new List<string>(), StringComparer.Ordinal);
            List<SessionCompletedVideoInfo> candidates = new List<SessionCompletedVideoInfo>();
            HashSet<string> knownAgentAsbs = new HashSet<string>(StringComparer.Ordinal);

            if (agentVideos != null)
            {
                for (int i = 0; i < agentVideos.Count; i++)
                {
                    SessionCompletedVideoInfo av = agentVideos[i];
                    if (av == null || string.IsNullOrEmpty(av.AsbId)) continue;
                    knownAgentAsbs.Add(av.AsbId);
                    if (validInGrid.Count == 0 || validInGrid.Contains(av.AsbId))
                        candidates.Add(av);
                }
            }

            string[] assignedAsbPerTake = new string[targetTakes.Count];
            HashSet<string> usedAsbIds = new HashSet<string>(StringComparer.Ordinal);

            // Passo 1: Casamento Global Best-First (1:1 por maior pontuação decrescente entre todos os pares Take x Vídeo).
            double[,] scoreMatrix = new double[targetTakes.Count, candidates.Count];
            int[] bestTakeForVideo = new int[candidates.Count];
            double[] bestScoreForVideo = new double[candidates.Count];

            List<TakeVideoMatchCandidate> highConfidencePairs = new List<TakeVideoMatchCandidate>();

            for (int v = 0; v < candidates.Count; v++)
            {
                bestTakeForVideo[v] = -1;
                bestScoreForVideo[v] = 0.0;
                SessionCompletedVideoInfo vid = candidates[v];
                if (string.IsNullOrWhiteSpace(vid.AltPrompt))
                    continue;

                for (int k = 0; k < targetTakes.Count; k++)
                {
                    double s = ComputeTakeToVideoMatchScore(targetTakes[k], vid.AltPrompt);
                    scoreMatrix[k, v] = s;
                    if (s > bestScoreForVideo[v])
                    {
                        bestScoreForVideo[v] = s;
                        bestTakeForVideo[v] = k;
                    }

                    if (s >= 0.62)
                    {
                        TakeVideoMatchCandidate pair = new TakeVideoMatchCandidate();
                        pair.TakeIndex = k;
                        pair.VideoIndex = v;
                        pair.AsbId = vid.AsbId;
                        pair.RawScore = s;
                        pair.ScoreBucket = s >= 0.93 ? 50 : (int)Math.Round(s * 50.0);
                        highConfidencePairs.Add(pair);
                    }
                }
            }

            highConfidencePairs.Sort(delegate(TakeVideoMatchCandidate a, TakeVideoMatchCandidate b)
            {
                int cmpBucket = b.ScoreBucket.CompareTo(a.ScoreBucket);
                if (cmpBucket != 0) return cmpBucket;
                int cmpVid = b.VideoIndex.CompareTo(a.VideoIndex);
                if (cmpVid != 0) return cmpVid;
                int cmpRaw = b.RawScore.CompareTo(a.RawScore);
                if (cmpRaw != 0) return cmpRaw;
                return a.TakeIndex.CompareTo(b.TakeIndex);
            });

            for (int p = 0; p < highConfidencePairs.Count; p++)
            {
                TakeVideoMatchCandidate pair = highConfidencePairs[p];
                if (!string.IsNullOrEmpty(assignedAsbPerTake[pair.TakeIndex]))
                    continue;
                if (usedAsbIds.Contains(pair.AsbId))
                    continue;

                assignedAsbPerTake[pair.TakeIndex] = pair.AsbId;
                usedAsbIds.Add(pair.AsbId);
            }

            // Passo 1.5: Descarta duplicatas antigas de takes já atribuídos e permite casamento secundário (>= 0.42)
            // SOMENTE se o melhor take daquele vídeo em TODO o episódio for justamente um take ainda não atribuído!
            List<TakeVideoMatchCandidate> secondaryPairs = new List<TakeVideoMatchCandidate>();
            for (int v = 0; v < candidates.Count; v++)
            {
                SessionCompletedVideoInfo vid = candidates[v];
                if (usedAsbIds.Contains(vid.AsbId) || string.IsNullOrWhiteSpace(vid.AltPrompt))
                    continue;

                int topTakeIdx = bestTakeForVideo[v];
                double topScore = bestScoreForVideo[v];
                if (topTakeIdx < 0) continue;

                if (!string.IsNullOrEmpty(assignedAsbPerTake[topTakeIdx]) && topScore >= 0.55)
                {
                    usedAsbIds.Add(vid.AsbId);
                    continue;
                }

                if (string.IsNullOrEmpty(assignedAsbPerTake[topTakeIdx]) && topScore >= 0.42)
                {
                    TakeVideoMatchCandidate sec = new TakeVideoMatchCandidate();
                    sec.TakeIndex = topTakeIdx;
                    sec.VideoIndex = v;
                    sec.AsbId = vid.AsbId;
                    sec.RawScore = topScore;
                    sec.ScoreBucket = (int)Math.Round(topScore * 50.0);
                    secondaryPairs.Add(sec);
                }
            }

            secondaryPairs.Sort(delegate(TakeVideoMatchCandidate a, TakeVideoMatchCandidate b)
            {
                int cmpRaw = b.RawScore.CompareTo(a.RawScore);
                if (cmpRaw != 0) return cmpRaw;
                return b.VideoIndex.CompareTo(a.VideoIndex);
            });

            for (int p = 0; p < secondaryPairs.Count; p++)
            {
                TakeVideoMatchCandidate sec = secondaryPairs[p];
                if (string.IsNullOrEmpty(assignedAsbPerTake[sec.TakeIndex]) && !usedAsbIds.Contains(sec.AsbId))
                {
                    assignedAsbPerTake[sec.TakeIndex] = sec.AsbId;
                    usedAsbIds.Add(sec.AsbId);
                }
            }

            // Passo 2: Fallback estritamente cronológico APENAS para vídeos sem prompt (alt vazio ou ausente no painel do Agente)
            List<string> unknownPromptChronologicalPool = new List<string>();
            for (int v = 0; v < candidates.Count; v++)
            {
                SessionCompletedVideoInfo av = candidates[v];
                if (!usedAsbIds.Contains(av.AsbId) && string.IsNullOrWhiteSpace(av.AltPrompt) &&
                    !unknownPromptChronologicalPool.Contains(av.AsbId))
                {
                    unknownPromptChronologicalPool.Add(av.AsbId);
                }
            }

            if (gridAsbIdsOldestFirst != null)
            {
                for (int g = 0; g < gridAsbIdsOldestFirst.Count; g++)
                {
                    string gAsb = gridAsbIdsOldestFirst[g];
                    if (!usedAsbIds.Contains(gAsb) && !knownAgentAsbs.Contains(gAsb) &&
                        !unknownPromptChronologicalPool.Contains(gAsb))
                    {
                        unknownPromptChronologicalPool.Add(gAsb);
                    }
                }
            }

            int poolCursor = 0;
            for (int k = 0; k < targetTakes.Count; k++)
            {
                if (string.IsNullOrEmpty(assignedAsbPerTake[k]) && poolCursor < unknownPromptChronologicalPool.Count)
                {
                    string fallbackAsb = unknownPromptChronologicalPool[poolCursor++];
                    assignedAsbPerTake[k] = fallbackAsb;
                    usedAsbIds.Add(fallbackAsb);
                }
            }

            Dictionary<string, string> promptByAsb = new Dictionary<string, string>(StringComparer.Ordinal);
            for (int v = 0; v < candidates.Count; v++)
            {
                if (!string.IsNullOrEmpty(candidates[v].AsbId) && !string.IsNullOrWhiteSpace(candidates[v].AltPrompt))
                    promptByAsb[candidates[v].AsbId] = candidates[v].AltPrompt;
            }

            int exactTagCount = 0;
            List<Tuple<FlowTakeSpec, string>> plan = new List<Tuple<FlowTakeSpec, string>>();
            for (int k = 0; k < targetTakes.Count; k++)
            {
                if (!string.IsNullOrEmpty(assignedAsbPerTake[k]))
                {
                    string chosenAsb = assignedAsbPerTake[k];
                    plan.Add(Tuple.Create(targetTakes[k], chosenAsb));
                    string matchedPrompt;
                    if (promptByAsb.TryGetValue(chosenAsb, out matchedPrompt) &&
                        TryExtractExplicitTakeTagNumber(matchedPrompt) == targetTakes[k].TakeNumber)
                    {
                        exactTagCount++;
                    }
                }
                else
                {
                    _log(string.Format("[Google Flow -> Grok] Take_{0:00} não gerou vídeo concluído no Google Flow -> será gerado no Grok Vídeo.", targetTakes[k].TakeNumber));
                }
            }

            if (plan.Count > 0)
            {
                _log(string.Format("[Google Flow] Identificação de takes: {0}/{1} confirmados por tag exata [TAKE_XX] ({2} por reserva de conteúdo).",
                    exactTagCount, plan.Count, plan.Count - exactTagCount));
            }

            return plan;
        }

        private async Task EnrichMissingVideoPromptsFromGridTilesAsync(
            string sess,
            List<SessionCompletedVideoInfo> agentVideos,
            List<string> gridAsbIdsOldestFirst,
            CancellationToken ct)
        {
            if (agentVideos == null || gridAsbIdsOldestFirst == null || gridAsbIdsOldestFirst.Count == 0)
                return;

            Dictionary<string, SessionCompletedVideoInfo> byAsb = new Dictionary<string, SessionCompletedVideoInfo>(StringComparer.Ordinal);
            for (int i = 0; i < agentVideos.Count; i++)
            {
                SessionCompletedVideoInfo info = agentVideos[i];
                if (info != null && !string.IsNullOrEmpty(info.AsbId))
                    byAsb[info.AsbId] = info;
            }

            List<string> missingAsbs = new List<string>();
            for (int g = 0; g < gridAsbIdsOldestFirst.Count; g++)
            {
                string gAsb = gridAsbIdsOldestFirst[g];
                if (string.IsNullOrEmpty(gAsb)) continue;
                SessionCompletedVideoInfo existing;
                if (!byAsb.TryGetValue(gAsb, out existing) || string.IsNullOrWhiteSpace(existing.AltPrompt))
                {
                    if (!missingAsbs.Contains(gAsb))
                        missingAsbs.Add(gAsb);
                }
            }

            if (missingAsbs.Count == 0)
                return;

            for (int m = 0; m < missingAsbs.Count; m++)
            {
                ct.ThrowIfCancellationRequested();
                string gAsb = missingAsbs[m];
                try
                {
                    Dictionary<string, object> cardCenter = await ScrollToAndLocateTileByAsbIdAsync(sess, gAsb, ct);
                    if (cardCenter == null) continue;

                    await _cdp.HoverAsync(sess, Convert.ToInt32(cardCenter["x"]), Convert.ToInt32(cardCenter["y"]), ct);
                    await Task.Delay(380, ct);

                    string b64Asb = Convert.ToBase64String(Encoding.UTF8.GetBytes(gAsb));
                    Dictionary<string, object> reusePt = await _cdp.EvalJsonAsync(sess, string.Format(@"
(function(){{
    var want = atob('{0}');
    var tile = Array.from(document.querySelectorAll('flow-video-tile')).find(t => {{
        var vid = t.querySelector('video');
        var img = t.querySelector('img');
        var u = (vid ? ((vid.getAttribute('src') || '') + ' ' + (vid.getAttribute('poster') || '')) : '') + ' ' +
                (img ? (img.getAttribute('src') || '') : '');
        return u.indexOf(want) >= 0;
    }});
    if (!tile) return null;
    var btn = tile.querySelector('button[aria-label*=""Reutilizar""], button[aria-label*=""Reuse""]') ||
              Array.from(tile.querySelectorAll('button')).find(b => {{
                  var al = (b.getAttribute('aria-label') || '');
                  var txt = (b.innerText || '').trim();
                  return al.indexOf('Reutilizar') >= 0 || al.indexOf('Reuse') >= 0 || txt === 'undo' || txt === 'replay';
              }});
    if (!btn) return null;
    var r = btn.getBoundingClientRect();
    if (r.width < 4) {{
        btn.click();
        return JSON.stringify({{ clickedNative: true, x: 0, y: 0 }});
    }}
    return JSON.stringify({{ clickedNative: false, x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) }});
}})()", b64Asb), ct);

                    if (reusePt == null) continue;
                    bool clickedNative = reusePt.ContainsKey("clickedNative") && Convert.ToBoolean(reusePt["clickedNative"]);
                    if (!clickedNative)
                    {
                        await _cdp.ClickAtAsync(sess, Convert.ToInt32(reusePt["x"]), Convert.ToInt32(reusePt["y"]), ct);
                    }

                    await Task.Delay(850, ct);
                    string recoveredPrompt = await ReadCurrentFlowTextboxAsync(sess, ct);
                    await InsertTextIntoFlowTextboxAsync(sess, "", true, ct);
                    await ClearAttachedPromptChipsAsync(sess, ct);

                    if (!string.IsNullOrWhiteSpace(recoveredPrompt))
                    {
                        SessionCompletedVideoInfo existing;
                        if (byAsb.TryGetValue(gAsb, out existing))
                        {
                            existing.AltPrompt = recoveredPrompt;
                        }
                        else
                        {
                            SessionCompletedVideoInfo added = new SessionCompletedVideoInfo();
                            added.AsbId = gAsb;
                            added.AltPrompt = recoveredPrompt;
                            agentVideos.Add(added);
                            byAsb[gAsb] = added;
                        }
                    }
                }
                catch (OperationCanceledException)
                {
                    throw;
                }
                catch
                {
                }
            }
        }

        private async Task<Dictionary<string, object>> ScrollToAndLocateTileByAsbIdAsync(
            string sess,
            string targetAsbId,
            CancellationToken ct)
        {
            string b64Asb = Convert.ToBase64String(Encoding.UTF8.GetBytes(targetAsbId));

            string locateAndCenterJs = string.Format(@"
(function(){{
    var want = atob('{0}');
    function findTile() {{
        return Array.from(document.querySelectorAll('flow-video-tile')).find(t => {{
            var vid = t.querySelector('video');
            var img = t.querySelector('img');
            var u = (vid ? ((vid.getAttribute('src') || '') + ' ' + (vid.getAttribute('poster') || '')) : '') + ' ' +
                    (img ? (img.getAttribute('src') || '') : '');
            return u.indexOf(want) >= 0;
        }});
    }}
    var tile = findTile();
    if (!tile) return null;
    tile.scrollIntoView({{ block: 'center', inline: 'nearest' }});
    var r = tile.getBoundingClientRect();
    return JSON.stringify({{ found: true, x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) }});
}})()", b64Asb);

            Dictionary<string, object> found = await _cdp.EvalJsonAsync(sess, locateAndCenterJs, ct);
            if (found == null)
            {
                // Varre o cdk-virtual-scroll-viewport desde scrollTop = 0 até montar o card com este targetAsbId
                for (int step = 0; step <= 20; step++)
                {
                    ct.ThrowIfCancellationRequested();
                    string stepRes = await _cdp.EvalStringAsync(sess, string.Format(@"
(function(){{
    var vp = document.querySelector('cdk-virtual-scroll-viewport.tiles-container') || document.querySelector('cdk-virtual-scroll-viewport');
    if (!vp) return 'NO_VP';
    var maxScroll = Math.max(0, vp.scrollHeight - vp.clientHeight);
    var nextTop = Math.min(maxScroll, {0});
    vp.scrollTop = nextTop;
    return nextTop >= maxScroll && {0} > 0 ? 'AT_END' : 'OK';
}})()", step * 420), ct);

                    await Task.Delay(340, ct);
                    found = await _cdp.EvalJsonAsync(sess, locateAndCenterJs, ct);
                    if (found != null) break;
                    if (stepRes == "AT_END" || stepRes == "NO_VP") break;
                }
            }

            if (found == null) return null;

            // Aguarda o virtual scroll estabilizar após scrollIntoView e RE-LOCALIZA pelo mesmo targetAsbId (imune a troca de índice DOM!)
            await Task.Delay(480, ct);

            Dictionary<string, object> settled = await _cdp.EvalJsonAsync(sess, string.Format(@"
(function(){{
    var want = atob('{0}');
    var tile = Array.from(document.querySelectorAll('flow-video-tile')).find(t => {{
        var vid = t.querySelector('video');
        var img = t.querySelector('img');
        var u = (vid ? ((vid.getAttribute('src') || '') + ' ' + (vid.getAttribute('poster') || '')) : '') + ' ' +
                (img ? (img.getAttribute('src') || '') : '');
        return u.indexOf(want) >= 0;
    }});
    if (!tile) return null;
    var r = tile.getBoundingClientRect();
    if (r.top < 25 || r.bottom > window.innerHeight - 15) {{
        var vp = document.querySelector('cdk-virtual-scroll-viewport.tiles-container') || document.querySelector('cdk-virtual-scroll-viewport');
        if (vp) {{
            vp.scrollTop += (r.top + r.height/2) - (window.innerHeight / 2);
        }}
        r = tile.getBoundingClientRect();
    }}
    return JSON.stringify({{
        x: Math.round(r.left + r.width/2),
        y: Math.round(r.top + r.height/2),
        w: Math.round(r.width),
        h: Math.round(r.height)
    }});
}})()", b64Asb), ct);

            return settled ?? found;
        }

        private async Task DownloadSingleTileByAsbIdAsync(
            string sess,
            string targetAsbId,
            int targetTakeNumber,
            int progressIdx,
            int progressTotal,
            string stagingDl,
            string finalTakePath,
            CancellationToken ct)
        {
            _log(string.Format("[Google Flow] Baixando cena {0}/{1} -> Take_{2:00}.mp4 (720p)...",
                progressIdx, progressTotal, targetTakeNumber));

            string b64Asb = Convert.ToBase64String(Encoding.UTF8.GetBytes(targetAsbId));
            Dictionary<string, object> dlMenuPt = null;

            for (int menuAttempt = 1; menuAttempt <= 3; menuAttempt++)
            {
                ct.ThrowIfCancellationRequested();

                // Fecha eventual menu anterior residual
                string hasOpenMenu = await _cdp.EvalStringAsync(sess, @"
(function(){
    var open = Array.from(document.querySelectorAll('.cdk-overlay-container [role=""menuitem""]'))
        .some(el => el.getBoundingClientRect().width > 10);
    return open ? 'OPEN' : 'CLOSED';
})()", ct);
                if (hasOpenMenu == "OPEN")
                {
                    await _cdp.PressEscapeAsync(sess, ct);
                    await Task.Delay(260, ct);
                }

                Dictionary<string, object> cardCenter = await ScrollToAndLocateTileByAsbIdAsync(sess, targetAsbId, ct);
                if (cardCenter == null)
                    throw new InvalidOperationException(string.Format("Card de vídeo (ID {0}) do Take_{1:00} não foi localizado no grid do Google Flow.",
                        targetAsbId.Substring(0, Math.Min(12, targetAsbId.Length)), targetTakeNumber));

                await _cdp.HoverAsync(sess, Convert.ToInt32(cardCenter["x"]), Convert.ToInt32(cardCenter["y"]), ct);
                await Task.Delay(420, ct);

                // Re-localiza o botão 'Mais opções' (⋮) diretamente dentro do card com este targetAsbId
                Dictionary<string, object> morePt = await _cdp.EvalJsonAsync(sess, string.Format(@"
(function(){{
    var want = atob('{0}');
    var tile = Array.from(document.querySelectorAll('flow-video-tile')).find(t => {{
        var vid = t.querySelector('video');
        var img = t.querySelector('img');
        var u = (vid ? ((vid.getAttribute('src') || '') + ' ' + (vid.getAttribute('poster') || '')) : '') + ' ' +
                (img ? (img.getAttribute('src') || '') : '');
        return u.indexOf(want) >= 0;
    }});
    if (!tile) return null;
    var btn = tile.querySelector('button[aria-label*=""Mais op""], button[aria-label*=""More""]') ||
              Array.from(tile.querySelectorAll('button')).find(b => (b.innerText || '').trim() === 'more_vert');
    if (!btn) return null;
    var r = btn.getBoundingClientRect();
    if (r.width < 4) return null;
    return JSON.stringify({{ x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) }});
}})()", b64Asb), ct);

                if (morePt == null)
                {
                    if (menuAttempt < 3)
                    {
                        await Task.Delay(350, ct);
                        continue;
                    }
                    throw new InvalidOperationException(string.Format("Botão 'Mais opções' (⋮) não encontrado no card do Take_{0:00}.", targetTakeNumber));
                }

                if (menuAttempt == 3)
                {
                    // Fallback na 3ª tentativa: aciona .click() nativo direto no botão Mais opções do tile específico
                    await _cdp.EvalStringAsync(sess, string.Format(@"
(function(){{
    var want = atob('{0}');
    var tile = Array.from(document.querySelectorAll('flow-video-tile')).find(t => {{
        var vid = t.querySelector('video');
        var img = t.querySelector('img');
        var u = (vid ? ((vid.getAttribute('src') || '') + ' ' + (vid.getAttribute('poster') || '')) : '') + ' ' +
                (img ? (img.getAttribute('src') || '') : '');
        return u.indexOf(want) >= 0;
    }});
    if (!tile) return 'NO_TILE';
    var btn = tile.querySelector('button[aria-label*=""Mais op""], button[aria-label*=""More""]');
    if (btn) btn.click();
    return 'CLICKED';
}})()", b64Asb), ct);
                }
                else
                {
                    await _cdp.ClickAtAsync(sess, Convert.ToInt32(morePt["x"]), Convert.ToInt32(morePt["y"]), ct);
                }

                for (int poll = 0; poll < 4; poll++)
                {
                    await Task.Delay(320, ct);
                    dlMenuPt = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var items = Array.from(document.querySelectorAll('.cdk-overlay-container [role=""menuitem""], [role=""menuitem""]'))
        .filter(el => el.getBoundingClientRect().width > 10);
    var m = items.find(el => {
        var t = (el.innerText || '');
        return t.indexOf('Fazer o download') >= 0 || t.indexOf('Baixar') >= 0 || t.indexOf('Download') >= 0;
    });
    if (!m) return null;
    var r = m.getBoundingClientRect();
    return JSON.stringify({ x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) });
})()", ct);
                    if (dlMenuPt != null) break;
                }

                if (dlMenuPt != null) break;
            }

            if (dlMenuPt == null)
                throw new InvalidOperationException(string.Format("Opção 'Fazer o download' não apareceu no menu do card do Take_{0:00} no Google Flow.", targetTakeNumber));

            HashSet<string> beforeFiles = new HashSet<string>(Directory.GetFiles(stagingDl), StringComparer.OrdinalIgnoreCase);
            await _cdp.ClickAtAsync(sess, Convert.ToInt32(dlMenuPt["x"]), Convert.ToInt32(dlMenuPt["y"]), ct);

            // Aguarda submenu de resolução ("720p" / "Resolução original") abrir e clica
            Dictionary<string, object> res720Pt = null;
            for (int poll = 0; poll < 5; poll++)
            {
                await Task.Delay(300, ct);
                res720Pt = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var items = Array.from(document.querySelectorAll('.cdk-overlay-container [role=""menuitem""], [role=""menuitem""], .cdk-overlay-container button'))
        .filter(el => el.getBoundingClientRect().width > 10);
    var m = items.find(el => {
        var t = (el.innerText || '');
        return t.indexOf('720p') >= 0 || t.indexOf('original') >= 0 || t.indexOf('Original') >= 0;
    });
    if (!m) return null;
    var r = m.getBoundingClientRect();
    return JSON.stringify({ x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) });
})()", ct);
                if (res720Pt != null) break;
            }

            if (res720Pt != null)
            {
                await _cdp.ClickAtAsync(sess, Convert.ToInt32(res720Pt["x"]), Convert.ToInt32(res720Pt["y"]), ct);
            }

            // Regra 11: Aguardar 1:1 o término completo deste .mp4 antes de clicar no próximo card
            string downloadedMp4 = await _cdp.WaitForSingleDownloadAsync(stagingDl, beforeFiles, 80 * 1024, 90000, ct);
            if (string.IsNullOrEmpty(downloadedMp4))
                throw new IOException(string.Format("Timeout aguardando download 720p do Take_{0:00}.mp4 no Google Flow.", targetTakeNumber));

            if (File.Exists(finalTakePath))
                File.Delete(finalTakePath);
            File.Move(downloadedMp4, finalTakePath);

            _log(string.Format("[Google Flow] Salvo Take_{0:00}.mp4 ({1:0.0} MB).",
                targetTakeNumber, new FileInfo(finalTakePath).Length / (1024.0 * 1024.0)));
        }

        private async Task DownloadAllCompletedTakesIn720pAsync(
            string sess,
            PreSessionGridBaseline baseline,
            EpisodeWorkItem ep,
            List<FlowTakeSpec> targetTakes,
            CancellationToken ct)
        {
            // Regra 28 e 32: Mapear exclusivamente os vídeos gerados nesta Nova sessão em ordem cronológica (Take_01..Take_N) e baixar em 720p
            string stagingDl = Path.Combine(ep.TakesDir, "_flow_dl_" + DateTime.Now.ToString("HHmmss"));
            Directory.CreateDirectory(stagingDl);
            await _cdp.SetDownloadBehaviorAsync(stagingDl, ct);

            List<SessionCompletedVideoInfo> agentVideos = await CollectSessionVideosFromAgentPanelAsync(sess, baseline, ct);
            List<string> gridAsbIdsOldestFirst = await CollectSessionGridAsbIdsOldestFirstAsync(sess, baseline, ct);
            await EnrichMissingVideoPromptsFromGridTilesAsync(sess, agentVideos, gridAsbIdsOldestFirst, ct);

            List<Tuple<FlowTakeSpec, string>> downloadPlan = BuildChronologicalDownloadPlan(targetTakes, agentVideos, gridAsbIdsOldestFirst);

            _log(string.Format("[Google Flow] Passo 7: Iniciando download cronológico em 720p de {0}/{1} takes desta sessão...",
                downloadPlan.Count, targetTakes.Count));

            for (int i = 0; i < downloadPlan.Count; i++)
            {
                ct.ThrowIfCancellationRequested();
                FlowTakeSpec takeSpec = downloadPlan[i].Item1;
                string targetAsbId = downloadPlan[i].Item2;
                string finalTakePath = Path.Combine(ep.TakesDir, string.Format("Take_{0:00}.mp4", takeSpec.TakeNumber));

                try
                {
                    await DownloadSingleTileByAsbIdAsync(
                        sess,
                        targetAsbId,
                        takeSpec.TakeNumber,
                        i + 1,
                        downloadPlan.Count,
                        stagingDl,
                        finalTakePath,
                        ct);
                }
                catch (OperationCanceledException)
                {
                    throw;
                }
                catch (Exception ex)
                {
                    _log(string.Format("[Google Flow | Aviso] Falha ao baixar Take_{0:00}.mp4 no Flow ({1}). Será gerado via fallback no Grok Vídeo...",
                        takeSpec.TakeNumber, ex.Message));
                }
            }

            try { await _cdp.ResetDownloadBehaviorToDefaultAsync(); } catch { }
            try { Directory.Delete(stagingDl, true); } catch { }
        }
    }
}
