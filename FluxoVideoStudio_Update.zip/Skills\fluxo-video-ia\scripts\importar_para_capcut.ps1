param(
    [Parameter(Mandatory=$true)]
    [string]$TakesFolder,

    [Parameter(Mandatory=$true)]
    [string]$ProjectName,

    [switch]$NoLaunchCapCut
)

$ErrorActionPreference = "Stop"
$utf8NoBom = New-Object System.Text.UTF8Encoding($false)

$draftsRoot = Join-Path $env:LOCALAPPDATA "CapCut\User Data\Projects\com.lveditor.draft"
$rootMetaPath = Join-Path $draftsRoot "root_meta_info.json"

if (-not (Test-Path $TakesFolder)) {
    throw "Pasta de takes não encontrada: $TakesFolder"
}

$mediaFiles = Get-ChildItem -Path $TakesFolder -File | Where-Object { $_.Extension -match '^\.(mp4|mov|mp3|wav|m4a)$' } | Sort-Object Name
if ($mediaFiles.Count -eq 0) {
    throw "Nenhum arquivo de vídeo ou áudio encontrado em: $TakesFolder"
}

# Fechar CapCut antes de editar root_meta_info.json e a pasta do projeto para evitar conflito de lock/cache em memória
Get-Process -Name "CapCut*" -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
Start-Sleep -Seconds 2

# Encontrar um rascunho existente válido (diferente do próprio ProjectName) para usar como estrutura base
$templateDraft = Get-ChildItem -Path $draftsRoot -Directory | Where-Object { $_.Name -ne $ProjectName -and (Test-Path (Join-Path $_.FullName "Timelines\project.json")) } | Sort-Object LastWriteTime -Descending | Select-Object -First 1
if (-not $templateDraft) {
    $templateDraft = Get-ChildItem -Path $draftsRoot -Directory | Where-Object { $_.Name -ne $ProjectName } | Sort-Object LastWriteTime -Descending | Select-Object -First 1
}
if (-not $templateDraft) {
    throw "Nenhum projeto base encontrado em $draftsRoot"
}

$targetFolder = Join-Path $draftsRoot $ProjectName
if (Test-Path $targetFolder) {
    Remove-Item -Path $targetFolder -Recurse -Force
}

New-Item -ItemType Directory -Force -Path $targetFolder | Out-Null

# Copiar arquivos base de configuração
foreach ($file in @("draft_content.json", "draft_meta_info.json", "draft_virtual_store.json", "draft_agency_config.json", "draft_biz_config.json", "draft_settings", "timeline_layout.json", "attachment_pc_common.json", "attachment_editing.json", "performance_opt_info.json")) {
    $src = Join-Path $templateDraft.FullName $file
    if (Test-Path $src) {
        Copy-Item $src (Join-Path $targetFolder $file) -Force
    }
}

# Criar pastas padrão do projeto CapCut
foreach ($dir in @("adjust_mask", "common_attachment", "loudness", "matting", "qr_upload", "Resources", "smart_crop", "subdraft", "Timelines")) {
    New-Item -ItemType Directory -Force -Path (Join-Path $targetFolder $dir) | Out-Null
}

$newDraftId    = [guid]::NewGuid().ToString().ToUpper()
$newTimelineId = [guid]::NewGuid().ToString().ToUpper()
$nowSec = [int64]([DateTimeOffset]::UtcNow.ToUnixTimeSeconds())
$nowUs  = $nowSec * 1000000

# Localizar ffmpeg do CapCut para capa e medição exata de duração de áudio/vídeo
$capcutAppsDir = Join-Path $env:LOCALAPPDATA "CapCut\Apps"
$ffmpegItem = Get-ChildItem -Path $capcutAppsDir -Filter "ffmpeg.exe" -Recurse -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1
$ffmpegExe = if ($ffmpegItem) { $ffmpegItem.FullName } else { "" }

function Get-MediaDurationUs {
    param([string]$FilePath, [int64]$DefaultUs = 10000000)
    if ($ffmpegExe -and (Test-Path $ffmpegExe)) {
        $prevPref = $ErrorActionPreference
        $ErrorActionPreference = "Continue"
        $out = (& $ffmpegExe -i $FilePath 2>&1) -join "`n"
        $ErrorActionPreference = $prevPref
        if ($out -match "Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)") {
            $h = [double]$matches[1]
            $m = [double]$matches[2]
            $s = [double]::Parse($matches[3], [System.Globalization.CultureInfo]::InvariantCulture)
            $totalSec = ($h * 3600.0) + ($m * 60.0) + $s
            if ($totalSec -gt 0.1) {
                return [int64][Math]::Round($totalSec * 1000000.0)
            }
        }
    }
    return $DefaultUs
}

$videoFiles = @($mediaFiles | Where-Object { $_.Extension -match '^\.(mp4|mov)$' } | Sort-Object Name)
$audioFiles = @($mediaFiles | Where-Object { $_.Extension -match '^\.(mp3|wav|m4a)$' } | Sort-Object Name)

$coverPath = Join-Path $targetFolder "draft_cover.jpg"
if ($ffmpegExe -and (Test-Path $ffmpegExe) -and ($videoFiles.Count -gt 0)) {
    $ErrorActionPreference = "Continue"
    & $ffmpegExe -y -loglevel quiet -i $videoFiles[0].FullName -frames:v 1 -q:v 2 $coverPath
    $ErrorActionPreference = "Stop"
}
if (-not (Test-Path $coverPath)) {
    $srcCover = Join-Path $templateDraft.FullName "draft_cover.jpg"
    if (Test-Path $srcCover) {
        Copy-Item $srcCover $coverPath -Force
    }
}

# Preparar listas para a aba de Mídia (draft_meta_info.json) e para a Timeline em ordem cronológica (draft_content.json)
$materialEntries      = @()
$virtualStoreChildren = @()
$timelineVideos       = @()
$timelineAudios       = @()
$timelineSpeeds       = @()
$timelinePlaceholders = @()
$timelineCanvases     = @()
$timelineSoundMaps    = @()
$timelineMatColors    = @()
$timelineVocalSeps    = @()
$timelineBeats        = @()
$videoTrackSegments   = @()
$audioTrackSegments   = @()

$idx = 0
$currentTimelineUs = [int64]0
$takeStartMap = @{} # Mapeia número do Take (int) -> timestamp inicial em microssegundos na timeline

# 1. Processar todos os arquivos de VÍDEO primeiro em ordem cronológica
foreach ($file in $videoFiles) {
    $idx++
    $matId = [guid]::NewGuid().ToString().ToLower()
    $durationUs = [int64]10000000 # 10s padrão do Flow
    $normPath = $file.FullName.Replace('\', '/')

    if ($file.BaseName -match '(\d+)') {
        $takeNum = [int]$matches[1]
        $takeStartMap[$takeNum] = $currentTimelineUs
    }

    # Entrada para a biblioteca de mídia do projeto (draft_meta_info.json)
    $entry = [ordered]@{
        ai_group_type       = ""
        create_time         = $nowSec
        duration            = $durationUs
        enter_from          = 0
        extra_info          = $file.Name
        file_Path           = $normPath
        height              = 1280
        id                  = $matId
        import_time         = $nowSec + $idx
        import_time_ms      = ($nowSec * 1000000) + ($idx * 1000)
        item_source         = 1
        material_color_tag  = ""
        md5                 = ""
        metetype            = "video"
        roughcut_time_range = [ordered]@{ duration = $durationUs; start = 0 }
        sub_time_range      = [ordered]@{ duration = -1; start = -1 }
        type                = 0
        width               = 720
    }
    $materialEntries += $entry
    $virtualStoreChildren += [ordered]@{
        child_id  = $matId
        parent_id = ""
    }

    $vidMatId = [guid]::NewGuid().ToString().ToUpper()
    $speedId  = [guid]::NewGuid().ToString().ToUpper()
    $phId     = [guid]::NewGuid().ToString().ToUpper()
    $canvasId = [guid]::NewGuid().ToString().ToUpper()
    $scmId    = [guid]::NewGuid().ToString().ToUpper()
    $mcId     = [guid]::NewGuid().ToString().ToUpper()
    $vsId     = [guid]::NewGuid().ToString().ToUpper()
    $segId    = [guid]::NewGuid().ToString().ToUpper()

    $timelineVideos += [ordered]@{
        aigc_history_id               = ""
        aigc_item_id                  = ""
        aigc_type                     = "none"
        audio_fade                    = $null
        beauty_body_auto_preset       = $null
        beauty_body_preset_id         = ""
        beauty_face_auto_preset       = [ordered]@{ name = ""; preset_id = ""; rate_map = ""; scene = "" }
        beauty_face_auto_preset_infos = @()
        beauty_face_preset_infos      = @()
        cartoon_path                  = ""
        category_id                   = ""
        category_name                 = "local"
        check_flag                    = 62978047
        content_feature_info          = $null
        corner_pin                    = $null
        crop                          = [ordered]@{
            lower_left_x  = 0.0
            lower_left_y  = 1.0
            lower_right_x = 1.0
            lower_right_y = 1.0
            upper_left_x  = 0.0
            upper_left_y  = 0.0
            upper_right_x = 1.0
            upper_right_y = 0.0
        }
        crop_ratio                    = "free"
        crop_scale                    = 1.0
        duration                      = $durationUs
        extra_type_option             = 0
        formula_id                    = ""
        freeze                        = $null
        has_audio                     = $true
        has_sound_separated           = $false
        height                        = 1280
        id                            = $vidMatId
        intensifies_audio_path        = ""
        intensifies_path              = ""
        is_ai_generate_content        = $false
        is_copyright                  = $false
        is_set_beauty_mode            = $false
        is_text_edit_overdub          = $false
        is_unified_beauty_mode        = $false
        is_video_copilot_aigc_content = $false
        live_photo_cover_path         = ""
        live_photo_timestamp          = -1
        local_id                      = ""
        local_material_from           = ""
        local_material_id             = $matId
        material_id                   = ""
        material_name                 = $file.Name
        material_url                  = ""
        matting                       = [ordered]@{
            cloud_product_fps     = 0.0
            custom_matting_id     = ""
            enable_matting_stroke = $false
            expansion             = 0
            feather               = 0
            flag                  = 0
            has_use_quick_brush   = $false
            has_use_quick_eraser  = $false
            interactiveTime       = @()
            is_clould             = $false
            mask_video_path       = ""
            path                  = ""
            reverse               = $false
            strokes               = @()
        }
        media_path                    = ""
        multi_camera_info             = $null
        object_locked                 = $null
        origin_material_id            = ""
        path                          = $normPath
        picture_from                  = "none"
        picture_set_category_id       = ""
        picture_set_category_name     = ""
        pre_applied_vip_materials     = @()
        request_id                    = ""
        reverse_intensifies_path      = ""
        reverse_path                  = ""
        smart_match_info              = $null
        smart_motion                  = $null
        source                        = 0
        source_platform               = 0
        stable                        = [ordered]@{
            matrix_path  = ""
            stable_level = 0
            time_range   = [ordered]@{ duration = 0; start = 0 }
        }
        surface_trackings             = @()
        team_id                       = ""
        type                          = "video"
        unique_id                     = ""
        video_algorithm               = [ordered]@{
            ai_background_configs           = @()
            ai_expression_driven            = $null
            ai_in_painting_config           = @()
            ai_motion_driven                = $null
            aigc_generate                   = $null
            aigc_generate_list              = @()
            algorithms                      = @()
            complement_frame_config         = $null
            deflicker                       = $null
            gameplay_configs                = @()
            image_interpretation            = $null
            motion_blur_config              = $null
            mouth_shape_driver              = $null
            noise_reduction                 = $null
            path                            = ""
            quality_enhance                 = $null
            skip_algorithm_index            = @()
            smart_complement_frame          = $null
            story_video_modify_video_config = [ordered]@{
                generate_card_id        = ""
                generate_id             = ""
                is_overwrite_last_video = $false
                task_id                 = ""
                tracker_task_id         = ""
            }
            super_resolution                = $null
            time_range                      = $null
        }
        video_mask_shadow             = [ordered]@{
            alpha       = 0.0
            angle       = 0.0
            blur        = 0.0
            color       = ""
            distance    = 0.0
            path        = ""
            resource_id = ""
        }
        video_mask_stroke             = [ordered]@{
            alpha            = 0.0
            color            = ""
            distance         = 0.0
            horizontal_shift = 0.0
            path             = ""
            resource_id      = ""
            size             = 0.0
            texture          = 0.0
            type             = ""
            vertical_shift   = 0.0
        }
        width                         = 720
        workflow_node_id              = ""
    }

    $timelineSpeeds += [ordered]@{
        curve_speed = $null
        id          = $speedId
        mode        = 0
        speed       = 1.0
        type        = "speed"
    }
    $timelinePlaceholders += [ordered]@{
        error_path = ""
        error_text = ""
        id         = $phId
        meta_type  = "none"
        res_path   = ""
        res_text   = ""
        type       = "placeholder_info"
    }
    $timelineCanvases += [ordered]@{
        album_image     = ""
        blur            = 0.0
        color           = ""
        id              = $canvasId
        image           = ""
        image_id        = ""
        image_name      = ""
        source_platform = 0
        team_id         = ""
        type            = "canvas_color"
    }
    $timelineSoundMaps += [ordered]@{
        audio_channel_mapping = 0
        id                    = $scmId
        is_config_open        = $false
        type                  = ""
    }
    $timelineMatColors += [ordered]@{
        gradient_angle    = 90.0
        gradient_colors   = @()
        gradient_percents = @()
        height            = 0.0
        id                = $mcId
        is_color_clip     = $false
        is_gradient       = $false
        solid_color       = ""
        width             = 0.0
    }
    $timelineVocalSeps += [ordered]@{
        choice          = 0
        enter_from      = ""
        final_algorithm = ""
        id              = $vsId
        production_path = ""
        removed_sounds  = @()
        time_range      = $null
        type            = "vocal_separation"
    }

    $videoTrackSegments += [ordered]@{
        caption_info                    = $null
        cartoon                         = $false
        clip                            = [ordered]@{
            alpha     = 1.0
            flip      = [ordered]@{ horizontal = $false; vertical = $false }
            rotation  = 0.0
            scale     = [ordered]@{ x = 1.0; y = 1.0 }
            transform = [ordered]@{ x = 0.0; y = 0.0 }
        }
        color_correct_alg_result        = ""
        common_keyframes                = @()
        desc                            = ""
        digital_human_template_group_id = ""
        enable_adjust                   = $true
        enable_adjust_mask              = $false
        enable_color_adjust_pro         = $false
        enable_color_correct_adjust     = $false
        enable_color_curves             = $true
        enable_color_match_adjust       = $false
        enable_color_wheels             = $true
        enable_hsl                      = $false
        enable_hsl_curves               = $true
        enable_lut                      = $true
        enable_mask_shadow              = $false
        enable_mask_stroke              = $false
        enable_smart_color_adjust       = $false
        enable_video_mask               = $true
        extra_material_refs             = @($speedId, $phId, $canvasId, $scmId, $mcId, $vsId)
        group_id                        = ""
        hdr_settings                    = [ordered]@{ intensity = 1.0; mode = 1; nits = 1000 }
        hdr_vivid_settings              = $null
        id                              = $segId
        intensifies_audio               = $false
        is_loop                         = $false
        is_placeholder                  = $false
        is_tone_modify                  = $false
        keyframe_refs                   = @()
        last_nonzero_volume             = 1.0
        lyric_keyframes                 = $null
        material_id                     = $vidMatId
        raw_segment_id                  = ""
        render_index                    = 0
        render_timerange                = [ordered]@{ duration = 0; start = 0 }
        responsive_layout               = [ordered]@{
            enable                = $false
            horizontal_pos_layout = 0
            size_layout           = 0
            target_follow         = ""
            vertical_pos_layout   = 0
        }
        reverse                         = $false
        segment_color_tag               = ""
        source                          = "segmentsourcenormal"
        source_timerange                = [ordered]@{ duration = $durationUs; start = 0 }
        speed                           = 1.0
        state                           = 0
        target_timerange                = [ordered]@{ duration = $durationUs; start = $currentTimelineUs }
        template_id                     = ""
        template_scene                  = "default"
        track_attribute                 = 0
        track_render_index              = 0
        uniform_scale                   = [ordered]@{ on = $true; value = 1.0 }
        visible                         = $true
        volume                          = 1.0
    }

    $currentTimelineUs += $durationUs
}

# 2. Processar arquivos de ÁUDIO (ex: Narrador_Take_11.mp3) posicionando-os na trilha de áudio abaixo do Take correspondente!
foreach ($file in $audioFiles) {
    $idx++
    $matId = [guid]::NewGuid().ToString().ToLower()
    $durationUs = Get-MediaDurationUs -FilePath $file.FullName -DefaultUs 8000000
    $normPath = $file.FullName.Replace('\', '/')

    # Determinar em qual timestamp da timeline posicionar o áudio:
    # Se o nome do arquivo contiver o número do Take (ex: Narrador_Take_11.mp3), alinha exatamente no início do Take 11!
    $audioStartUs = [int64]0
    if ($file.BaseName -match '(\d+)') {
        $takeNum = [int]$matches[1]
        if ($takeStartMap.ContainsKey($takeNum)) {
            $audioStartUs = $takeStartMap[$takeNum]
        } else {
            $audioStartUs = [int64](($takeNum - 1) * 10000000)
        }
    }

    $entry = [ordered]@{
        ai_group_type       = ""
        create_time         = $nowSec
        duration            = $durationUs
        enter_from          = 0
        extra_info          = $file.Name
        file_Path           = $normPath
        height              = 0
        id                  = $matId
        import_time         = $nowSec + $idx
        import_time_ms      = ($nowSec * 1000000) + ($idx * 1000)
        item_source         = 1
        material_color_tag  = ""
        md5                 = ""
        metetype            = "music"
        roughcut_time_range = [ordered]@{ duration = $durationUs; start = 0 }
        sub_time_range      = [ordered]@{ duration = -1; start = -1 }
        type                = 0
        width               = 0
    }
    $materialEntries += $entry
    $virtualStoreChildren += [ordered]@{
        child_id  = $matId
        parent_id = ""
    }

    $audMatId = [guid]::NewGuid().ToString().ToUpper()
    $speedId  = [guid]::NewGuid().ToString().ToUpper()
    $phId     = [guid]::NewGuid().ToString().ToUpper()
    $beatId   = [guid]::NewGuid().ToString().ToUpper()
    $scmId    = [guid]::NewGuid().ToString().ToUpper()
    $vsId     = [guid]::NewGuid().ToString().ToUpper()
    $segId    = [guid]::NewGuid().ToString().ToUpper()
    $musicId  = [guid]::NewGuid().ToString().ToLower()

    $timelineAudios += [ordered]@{
        ai_music_enter_from      = ""
        ai_music_generate_scene  = 0
        ai_music_type            = 0
        aigc_history_id          = ""
        aigc_item_id             = ""
        app_id                   = 0
        category_id              = ""
        category_name            = "local"
        check_flag               = 1
        cloned_model_type        = ""
        copyright_limit_type     = "none"
        duration                 = $durationUs
        effect_id                = ""
        formula_id               = ""
        id                       = $audMatId
        intensifies_path         = ""
        is_ai_clone_tone         = $false
        is_ai_clone_tone_post    = $false
        is_text_edit_overdub     = $false
        is_ugc                   = $false
        local_material_id        = $matId
        lyric_type               = 0
        mock_tone_speaker        = ""
        moyin_emotion            = ""
        music_id                 = $musicId
        music_source             = ""
        name                     = $file.Name
        path                     = $normPath
        pgc_id                   = ""
        pgc_name                 = ""
        query                    = ""
        request_id               = ""
        resource_id              = ""
        search_id                = ""
        similiar_music_info      = [ordered]@{
            original_song_id   = ""
            original_song_name = ""
        }
        sound_separate_type      = ""
        source_from              = ""
        source_platform          = 0
        team_id                  = ""
        text_id                  = ""
        third_resource_id        = ""
        tone_category_id         = ""
        tone_category_name       = ""
        tone_effect_id           = ""
        tone_effect_name         = ""
        tone_emotion_name_key    = ""
        tone_emotion_role        = ""
        tone_emotion_scale       = 0.0
        tone_emotion_selection   = ""
        tone_emotion_style       = ""
        tone_platform            = ""
        tone_second_category_id  = ""
        tone_second_category_name = ""
        tone_speaker             = ""
        tone_type                = ""
        tts_generate_scene       = ""
        tts_task_id              = ""
        type                     = "extract_music"
        video_id                 = ""
        wave_points              = @()
    }

    $timelineSpeeds += [ordered]@{
        curve_speed = $null
        id          = $speedId
        mode        = 0
        speed       = 1.0
        type        = "speed"
    }
    $timelinePlaceholders += [ordered]@{
        error_path = ""
        error_text = ""
        id         = $phId
        meta_type  = "none"
        res_path   = ""
        res_text   = ""
        type       = "placeholder_info"
    }
    $timelineBeats += [ordered]@{
        ai_beats = [ordered]@{
            beat_speed_infos = @()
            beats_path       = ""
            beats_url        = ""
            melody_path      = ""
            melody_percents  = @(0.0)
            melody_url       = ""
        }
        enable_ai_beats      = $false
        gear                 = 404
        gear_count           = 0
        id                   = $beatId
        mode                 = 404
        type                 = "beats"
        user_beats           = @()
        user_delete_ai_beats = $null
    }
    $timelineSoundMaps += [ordered]@{
        audio_channel_mapping = 0
        id                    = $scmId
        is_config_open        = $false
        type                  = "none"
    }
    $timelineVocalSeps += [ordered]@{
        choice          = 0
        enter_from      = ""
        final_algorithm = ""
        id              = $vsId
        production_path = ""
        removed_sounds  = @()
        time_range      = $null
        type            = "vocal_separation"
    }

    $audioTrackSegments += [ordered]@{
        caption_info                    = $null
        cartoon                         = $false
        clip                            = $null
        color_correct_alg_result        = ""
        common_keyframes                = @()
        desc                            = ""
        digital_human_template_group_id = ""
        enable_adjust                   = $false
        enable_adjust_mask              = $false
        enable_color_correct_adjust     = $false
        enable_color_curves             = $true
        enable_color_match_adjust       = $false
        enable_color_wheels             = $true
        enable_hsl                      = $false
        enable_hsl_curves               = $true
        enable_lut                      = $false
        enable_mask_shadow              = $false
        enable_mask_stroke              = $false
        enable_smart_color_adjust       = $false
        enable_video_mask               = $true
        extra_material_refs             = @($speedId, $phId, $beatId, $scmId, $vsId)
        group_id                        = ""
        hdr_settings                    = $null
        id                              = $segId
        intensifies_audio               = $false
        is_loop                         = $false
        is_placeholder                  = $false
        is_tone_modify                  = $false
        keyframe_refs                   = @()
        last_nonzero_volume             = 1.0
        lyric_keyframes                 = $null
        material_id                     = $audMatId
        raw_segment_id                  = ""
        render_index                    = 0
        render_timerange                = [ordered]@{ duration = 0; start = 0 }
        responsive_layout               = [ordered]@{
            enable                = $false
            horizontal_pos_layout = 0
            size_layout           = 0
            target_follow         = ""
            vertical_pos_layout   = 0
        }
        reverse                         = $false
        source                          = "segmentsourcenormal"
        source_timerange                = [ordered]@{ duration = $durationUs; start = 0 }
        speed                           = 1.0
        state                           = 0
        target_timerange                = [ordered]@{ duration = $durationUs; start = $audioStartUs }
        template_id                     = ""
        template_scene                  = "default"
        track_attribute                 = 0
        track_render_index              = 1
        uniform_scale                   = $null
        visible                         = $true
        volume                          = 1.0
    }
}

# Preencher draft_content.json com os takes em ordem cronológica na timeline e faixa de áudio do Narrador (SEM BOM!)
$contentPath = Join-Path $targetFolder "draft_content.json"
$contentJson = Get-Content $contentPath -Raw -Encoding UTF8 | ConvertFrom-Json
$contentJson.id = $newTimelineId
$contentJson.name = ""
$contentJson.duration = $currentTimelineUs
$contentJson.create_time = $nowSec
$contentJson.update_time = $nowSec
$contentJson.canvas_config.ratio = "9:16"
$contentJson.canvas_config.width = 1080
$contentJson.canvas_config.height = 1920

foreach ($prop in $contentJson.materials.PSObject.Properties) {
    if ($prop.Value -is [System.Array]) {
        $contentJson.materials.($prop.Name) = @()
    }
}
$contentJson.materials.videos                 = $timelineVideos
$contentJson.materials.audios                 = $timelineAudios
$contentJson.materials.speeds                 = $timelineSpeeds
$contentJson.materials.placeholder_infos      = $timelinePlaceholders
$contentJson.materials.canvases               = $timelineCanvases
$contentJson.materials.sound_channel_mappings = $timelineSoundMaps
$contentJson.materials.material_colors        = $timelineMatColors
$contentJson.materials.vocal_separations      = $timelineVocalSeps
$contentJson.materials.beats                  = $timelineBeats

$mainVideoTrack = [ordered]@{
    attribute       = 0
    flag            = 0
    id              = [guid]::NewGuid().ToString().ToUpper()
    is_default_name = $true
    name            = ""
    segments        = $videoTrackSegments
    type            = "video"
}

if ($audioTrackSegments.Count -gt 0) {
    $mainAudioTrack = [ordered]@{
        attribute       = 0
        flag            = 0
        id              = [guid]::NewGuid().ToString().ToUpper()
        is_default_name = $true
        name            = ""
        segments        = $audioTrackSegments
        type            = "audio"
    }
    $contentJson.tracks = @($mainVideoTrack, $mainAudioTrack)
} else {
    $contentJson.tracks = @($mainVideoTrack)
}

foreach ($prop in $contentJson.keyframes.PSObject.Properties) {
    if ($prop.Value -is [System.Array]) {
        $contentJson.keyframes.($prop.Name) = @()
    }
}
$contentJson.relationships = @()

$contentStr = $contentJson | ConvertTo-Json -Depth 30 -Compress
[System.IO.File]::WriteAllText($contentPath, $contentStr, $utf8NoBom)
[System.IO.File]::WriteAllText("$contentPath.bak", $contentStr, $utf8NoBom)
[System.IO.File]::WriteAllText((Join-Path $targetFolder "template-2.tmp"), $contentStr, $utf8NoBom)

# Criar a estrutura obrigatória do CapCut 9.6+: Timelines\project.json e Timelines\<newTimelineId>\draft_content.json
$timelineDir = Join-Path $targetFolder "Timelines\$newTimelineId"
New-Item -ItemType Directory -Force -Path $timelineDir | Out-Null
New-Item -ItemType Directory -Force -Path (Join-Path $timelineDir "attachment") | Out-Null
New-Item -ItemType Directory -Force -Path (Join-Path $timelineDir "common_attachment") | Out-Null

[System.IO.File]::WriteAllText((Join-Path $timelineDir "draft_content.json"), $contentStr, $utf8NoBom)
[System.IO.File]::WriteAllText((Join-Path $timelineDir "draft_content.json.bak"), $contentStr, $utf8NoBom)
[System.IO.File]::WriteAllText((Join-Path $timelineDir "template-2.tmp"), $contentStr, $utf8NoBom)
[System.IO.File]::WriteAllText((Join-Path $timelineDir "template.tmp"), $contentStr, $utf8NoBom)
if (Test-Path $coverPath) {
    Copy-Item $coverPath (Join-Path $timelineDir "draft_cover.jpg") -Force
}
foreach ($f in @("attachment_pc_common.json", "attachment_editing.json")) {
    $srcF = Join-Path $targetFolder $f
    if (Test-Path $srcF) {
        Copy-Item $srcF (Join-Path $timelineDir $f) -Force
    }
}

$projectJsonObj = [ordered]@{
    config = [ordered]@{
        color_space               = -1
        hdr_vivid                 = $false
        mixed_track_mode_on       = $false
        render_index_track_mode_on = $false
        use_float_render          = $false
    }
    create_time      = $nowUs
    id               = [guid]::NewGuid().ToString().ToUpper()
    main_timeline_id = $newTimelineId
    timelines        = @(
        [ordered]@{
            create_time      = $nowUs
            id               = $newTimelineId
            is_marked_delete = $false
            name             = "Linha do tempo 01"
            update_time      = $nowUs
        }
    )
    update_time      = $nowUs
    version          = 0
}
$projectJsonStr = $projectJsonObj | ConvertTo-Json -Depth 10 -Compress
$timelinesProjectPath = Join-Path $targetFolder "Timelines\project.json"
[System.IO.File]::WriteAllText($timelinesProjectPath, $projectJsonStr, $utf8NoBom)
[System.IO.File]::WriteAllText("$timelinesProjectPath.bak", $projectJsonStr, $utf8NoBom)

# Montar a lista de materiais em draft_meta_info.json e draft_virtual_store.json (SEM BOM!)
$metaPath = Join-Path $targetFolder "draft_meta_info.json"
$metaJson = Get-Content $metaPath -Raw -Encoding UTF8 | ConvertFrom-Json
$metaJson.draft_id = $newDraftId
$metaJson.draft_name = $ProjectName
$metaJson.draft_cover = "draft_cover.jpg"
$metaJson.draft_fold_path = $targetFolder.Replace('\', '/')
$metaJson.draft_root_path = $draftsRoot
$metaJson.tm_draft_create = $nowUs
$metaJson.tm_draft_modified = $nowUs
$metaJson.tm_duration = $currentTimelineUs
$totalSize = [int64](($mediaFiles | Measure-Object -Property Length -Sum).Sum)
if ($metaJson.PSObject.Properties["draft_timeline_materials_size_"]) {
    $metaJson.draft_timeline_materials_size_ = $totalSize
}

for ($i = 0; $i -lt $metaJson.draft_materials.Count; $i++) {
    if ($metaJson.draft_materials[$i].type -eq 0) {
        $metaJson.draft_materials[$i].value = $materialEntries
    } else {
        $metaJson.draft_materials[$i].value = @()
    }
}
$metaStr = $metaJson | ConvertTo-Json -Depth 20 -Compress
[System.IO.File]::WriteAllText($metaPath, $metaStr, $utf8NoBom)

# Atualizar draft_virtual_store.json (SEM BOM!)
$vstorePath = Join-Path $targetFolder "draft_virtual_store.json"
$vstoreJson = Get-Content $vstorePath -Raw -Encoding UTF8 | ConvertFrom-Json
$vstoreJson.draft_materials = @()
$vstoreJson.draft_virtual_store[1].value = $virtualStoreChildren
$vstoreStr = $vstoreJson | ConvertTo-Json -Depth 20 -Compress
[System.IO.File]::WriteAllText($vstorePath, $vstoreStr, $utf8NoBom)

# Registrar no root_meta_info.json do CapCut (SEM BOM e removendo entradas antigas de mesmo nome!)
if (Test-Path $rootMetaPath) {
    Copy-Item $rootMetaPath "$rootMetaPath.bak" -Force
    $rootJson = Get-Content $rootMetaPath -Raw -Encoding UTF8 | ConvertFrom-Json
    $existing = @($rootJson.all_draft_store | Where-Object { $_.draft_name -ne $ProjectName })
    $newRootEntry = [ordered]@{
        cloud_draft_cover                  = $false
        cloud_draft_sync                   = $false
        draft_cloud_last_action_download   = $false
        draft_cloud_purchase_info          = ""
        draft_cloud_template_id            = ""
        draft_cloud_tutorial_info          = ""
        draft_cloud_videocut_purchase_info = ""
        draft_cover                        = "$($targetFolder.Replace('\', '/'))\draft_cover.jpg"
        draft_fold_path                    = $targetFolder.Replace('\', '/')
        draft_id                           = $newDraftId
        draft_is_ai_shorts                 = $false
        draft_is_cloud_temp_draft          = $false
        draft_is_infinite_canvas_draft     = $false
        draft_is_invisible                 = $false
        draft_is_pippit_draft              = $false
        draft_is_web_article_video         = $false
        draft_json_file                    = "$($targetFolder.Replace('\', '/'))\draft_content.json"
        draft_name                         = $ProjectName
        draft_new_version                  = ""
        draft_root_path                    = $draftsRoot.Replace('\', '/')
        draft_timeline_materials_size      = $totalSize
        draft_type                         = ""
        draft_web_article_video_enter_from = ""
        pippit_avatar_url                  = ""
        pippit_extra_info                  = ""
        pippit_id                          = ""
        pippit_user_name                   = ""
        streaming_edit_draft_ready         = $true
        tm_draft_cloud_completed           = ""
        tm_draft_cloud_entry_id            = -1
        tm_draft_cloud_modified            = 0
        tm_draft_cloud_parent_entry_id     = -1
        tm_draft_cloud_space_id            = -1
        tm_draft_cloud_user_id             = -1
        tm_draft_create                    = $nowUs
        tm_draft_modified                  = $nowUs
        tm_draft_removed                   = 0
        tm_duration                        = $currentTimelineUs
    }
    $rootJson.all_draft_store = @($newRootEntry) + $existing
    $rootStr = $rootJson | ConvertTo-Json -Depth 20 -Compress
    [System.IO.File]::WriteAllText($rootMetaPath, $rootStr, $utf8NoBom)
}

Write-Host "Projeto CapCut '$ProjectName' criado com sucesso com $($videoTrackSegments.Count) takes de vídeo e $($audioTrackSegments.Count) áudio(s) do Narrador posicionados abaixo da cena correspondente na Timeline (duração total: $([math]::Round($currentTimelineUs / 1000000, 1))s)!"

# Iniciar CapCut Desktop via WMI (a menos que -NoLaunchCapCut seja passado em lotes)
$capcutExe = Join-Path $env:LOCALAPPDATA "CapCut\Apps\CapCut.exe"
if ((-not $NoLaunchCapCut) -and (Test-Path $capcutExe)) {
    Invoke-CimMethod -ClassName Win32_Process -MethodName Create -Arguments @{
        CommandLine = "`"$capcutExe`""
    } | Out-Null
}
