using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Web.Script.Serialization;

namespace FluxoVideoStudio
{
    public static class EpisodeParser
    {
        public static string CustomNovelaRoot { get; set; }
        public static string CustomTerrorRoot { get; set; }

        private static List<string> GetCandidateDesktopFolders()
        {
            List<string> dirs = new List<string>();
            string d1 = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
            if (!string.IsNullOrEmpty(d1)) dirs.Add(d1);

            string userProf = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
            if (!string.IsNullOrEmpty(userProf))
            {
                string d2 = Path.Combine(userProf, "Desktop");
                string d3 = Path.Combine(userProf, @"OneDrive\Desktop");
                if (!dirs.Contains(d2, StringComparer.OrdinalIgnoreCase)) dirs.Add(d2);
                if (!dirs.Contains(d3, StringComparer.OrdinalIgnoreCase)) dirs.Add(d3);
            }

            try
            {
                string appDir = PipelineConfig.GetAppRootDir();
                DirectoryInfo cur = new DirectoryInfo(appDir);
                for (int i = 0; i < 4 && cur != null; i++)
                {
                    if (!dirs.Contains(cur.FullName, StringComparer.OrdinalIgnoreCase))
                        dirs.Add(cur.FullName);
                    cur = cur.Parent;
                }
            }
            catch { }

            return dirs;
        }

        public static string GetNovelaRoot()
        {
            if (!string.IsNullOrWhiteSpace(CustomNovelaRoot))
                return CustomNovelaRoot.Trim();

            foreach (string d in GetCandidateDesktopFolders())
            {
                string p = Path.Combine(d, @"MEU TRABALHO\_videos de reflexão");
                if (Directory.Exists(p)) return p;
                string pDirect = Path.Combine(d, "_videos de reflexão");
                if (Directory.Exists(pDirect)) return pDirect;
            }
            string desktop = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
            return Path.Combine(desktop, @"MEU TRABALHO\_videos de reflexão");
        }

        public static string GetTerrorRoot()
        {
            if (!string.IsNullOrWhiteSpace(CustomTerrorRoot))
                return CustomTerrorRoot.Trim();

            foreach (string d in GetCandidateDesktopFolders())
            {
                string p = Path.Combine(d, @"MEU TRABALHO\_Videos terror");
                if (Directory.Exists(p)) return p;
                string pDirect = Path.Combine(d, "_Videos terror");
                if (Directory.Exists(pDirect)) return pDirect;
            }
            string desktop = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
            return Path.Combine(desktop, @"MEU TRABALHO\_Videos terror");
        }

        public static List<StoryProject> DiscoverAllStories()
        {
            List<StoryProject> list = new List<StoryProject>();
            ScanGenreRoot(GetNovelaRoot(), GenreType.NovelaReflexao, list);
            ScanGenreRoot(GetTerrorRoot(), GenreType.Terror, list);
            return list.OrderByDescending(s => s.LastModified).ToList();
        }

        private static void ScanGenreRoot(string rootDir, GenreType genre, List<StoryProject> output)
        {
            if (!Directory.Exists(rootDir)) return;
            foreach (string dir in Directory.GetDirectories(rootDir))
            {
                StoryProject proj = LoadStoryFolder(dir, genre);
                if (proj != null && proj.Episodes.Count > 0)
                {
                    output.Add(proj);
                }
            }
        }

        public static StoryProject LoadStoryFolder(string storyFolder, GenreType genre)
        {
            if (!Directory.Exists(storyFolder)) return null;
            DirectoryInfo di = new DirectoryInfo(storyFolder);

            StoryProject proj = new StoryProject();
            proj.Name = di.Name;
            proj.Genre = genre;
            proj.FolderPath = di.FullName;
            proj.LastModified = di.LastWriteTime;

            string[] subDirs = Directory.GetDirectories(storyFolder);
            List<string> epDirs = subDirs
                .Where(d => Regex.IsMatch(Path.GetFileName(d), @"^EP\.?\s*\d+$", RegexOptions.IgnoreCase))
                .OrderBy(d => Path.GetFileName(d))
                .ToList();

            if (epDirs.Count > 0)
            {
                foreach (string epDir in epDirs)
                {
                    EpisodeWorkItem ep = ParseEpisodeFolder(epDir, proj.Name, genre, storyFolder);
                    if (ep != null)
                    {
                        proj.Episodes.Add(ep);
                        DateTime lw = Directory.GetLastWriteTime(epDir);
                        if (lw > proj.LastModified) proj.LastModified = lw;
                    }
                }
            }
            else
            {
                // Caso seja uma pasta única direta com prompt_flow / prompt_grok
                bool hasPrompt = Directory.GetFiles(storyFolder, "*.txt", SearchOption.TopDirectoryOnly)
                    .Any(f => Path.GetFileName(f).IndexOf("prompt_", StringComparison.OrdinalIgnoreCase) >= 0 ||
                              Path.GetFileName(f).IndexOf("passo3", StringComparison.OrdinalIgnoreCase) >= 0);
                if (hasPrompt)
                {
                    EpisodeWorkItem ep = ParseEpisodeFolder(storyFolder, proj.Name, genre, storyFolder);
                    if (ep != null)
                    {
                        ep.EpisodeName = "EP.1";
                        proj.Episodes.Add(ep);
                    }
                }
            }

            return proj;
        }

        public static EpisodeWorkItem ParseEpisodeFolder(string epDir, string storyName, GenreType genre, string storyRoot)
        {
            if (!Directory.Exists(epDir)) return null;

            EpisodeWorkItem item = new EpisodeWorkItem();
            item.StoryName = storyName;
            item.Genre = genre;
            item.StoryRootPath = storyRoot;
            item.EpisodePath = epDir;
            item.EpisodeName = Path.GetFileName(epDir);

            Match epNumMatch = Regex.Match(item.EpisodeName, @"(\d+)");
            int epNum;
            if (epNumMatch.Success && int.TryParse(epNumMatch.Groups[1].Value, out epNum))
            {
                item.EpisodeNumber = epNum;
            }

            item.AssetsDir = Path.Combine(epDir, "assets");
            item.TakesDir = Path.Combine(epDir, "takes");

            string[] txtFiles = Directory.GetFiles(epDir, "*.txt", SearchOption.TopDirectoryOnly);

            item.GrokPromptPath = FindBestFile(txtFiles, new[] { "prompt_grok_passo1_e_2.txt", "prompt_grok", "comandos_gemini_completos" });
            item.FlowPromptPath = FindBestFile(txtFiles, new[] { "prompt_flow_passo3.txt", "prompt_flow", "passo3_takes" });
            item.NarradorTxtPath = FindBestFile(txtFiles, new[] { "narrador_unificado", "narrador" });
            item.RoteiroPath = FindBestFile(txtFiles, new[] { "roteiro.txt", "roteiro_camaleao", "roteiro_parte", "roteiro" },
                excludeSubstrings: new[] { "decupado", "gem_" });

            if (!string.IsNullOrEmpty(item.GrokPromptPath) && File.Exists(item.GrokPromptPath))
                item.GrokPromptText = ReadUtf8(item.GrokPromptPath);

            if (!string.IsNullOrEmpty(item.FlowPromptPath) && File.Exists(item.FlowPromptPath))
                item.FlowPromptText = ReadUtf8(item.FlowPromptPath);

            if (!string.IsNullOrEmpty(item.RoteiroPath) && File.Exists(item.RoteiroPath))
                item.RoteiroText = ReadUtf8(item.RoteiroPath);

            // 1. Parse Flow Takes + Title->Filename map
            Dictionary<string, string> titleToFilenameMap = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            ParseFlowTakes(item.FlowPromptText, item.FlowTakes, item.AllRequiredFlowIngredients, titleToFilenameMap);

            // 2. Parse Grok Specs (correlating with Flow Title->Filename map & required ingredient filenames)
            ParseGrokSpecs(item.GrokPromptText, titleToFilenameMap, item.AllRequiredFlowIngredients, item.GrokSpecs);

            // 3. Parse Narrator Speech
            if (!string.IsNullOrEmpty(item.NarradorTxtPath) && File.Exists(item.NarradorTxtPath))
            {
                string rawNar = ReadUtf8(item.NarradorTxtPath).Trim();
                item.UnifiedNarratorText = rawNar;
                item.NarratorSegmentsCount = string.IsNullOrWhiteSpace(rawNar)
                    ? 0
                    : Regex.Split(rawNar, @"(\r?\n){2,}").Count(p => !string.IsNullOrWhiteSpace(p));
            }
            else
            {
                int segCount;
                item.UnifiedNarratorText = ExtractNarratorFromRoteiro(item.RoteiroText, out segCount);
                item.NarratorSegmentsCount = segCount;
            }

            LoadEpisodeCustomTakesConfig(item);
            RefreshDiskCounters(item);
            return item;
        }

        public static bool IsScenarioAssetName(string fileName)
        {
            if (string.IsNullOrEmpty(fileName)) return false;
            return Regex.IsMatch(
                fileName,
                @"(^|_)(Cenario|Quarto|Sala|Cozinha|Rua|Casa|Sitio|Curral|Feira|Cabana|Encruzilhada|Casarao|Estabulo|Barraca|Calcada|Lanchonete|Deposito|Fazenda|Praca|Igreja|Hospital|Escritorio|Obra|Quintal)(_|\.)",
                RegexOptions.IgnoreCase);
        }

        public static string CleanAssetStem(string fileName)
        {
            if (string.IsNullOrEmpty(fileName)) return "";
            string stem = Path.GetFileNameWithoutExtension(fileName);
            stem = Regex.Replace(stem, @"^(\d+_)?(Personagem_\d+_|Cenario_(?:[A-Za-z]|\d{1,2})_|Cenario_)", "", RegexOptions.IgnoreCase);
            return stem.Replace("_", " ").Trim();
        }

        public static int SyncLocalSubfolderAssets(EpisodeWorkItem item, Action<string> log)
        {
            if (item == null || string.IsNullOrEmpty(item.EpisodePath) || !Directory.Exists(item.EpisodePath))
                return 0;

            int copied = 0;
            string[] legacySubfolders = new[] { "personagens", "cenarios" };
            foreach (string sub in legacySubfolders)
            {
                string subDir = Path.Combine(item.EpisodePath, sub);
                if (!Directory.Exists(subDir)) continue;

                foreach (string src in Directory.GetFiles(subDir))
                {
                    if (!Regex.IsMatch(Path.GetExtension(src), @"^\.(jpg|jpeg|png)$", RegexOptions.IgnoreCase))
                        continue;
                    if (new FileInfo(src).Length <= 10 * 1024) continue;

                    if (!Directory.Exists(item.AssetsDir))
                        Directory.CreateDirectory(item.AssetsDir);

                    string fn = Path.GetFileName(src);
                    string dst = Path.Combine(item.AssetsDir, fn);
                    if (!File.Exists(dst))
                    {
                        File.Copy(src, dst, false);
                        copied++;
                        if (log != null)
                            log(string.Format("[Assets] Imagem recuperada de '{0}\\': {1}", sub, fn));
                    }
                }
            }
            return copied;
        }

        public static string FindMatchingDiskAssetFile(string wantedFileName, IEnumerable<string> diskFilePaths)
        {
            if (string.IsNullOrEmpty(wantedFileName) || diskFilePaths == null) return "";
            List<string> files = diskFilePaths.ToList();

            // 1. Exact case-insensitive filename match
            string exact = files.FirstOrDefault(f =>
                string.Equals(Path.GetFileName(f), wantedFileName, StringComparison.OrdinalIgnoreCase));
            if (!string.IsNullOrEmpty(exact)) return exact;

            // 2. Fuzzy stem match respecting Character vs Scenario category
            bool wantedIsScen = IsScenarioAssetName(wantedFileName);
            string wantedStem = CleanAssetStem(wantedFileName);
            string bestPath = "";
            double bestScore = 0.0;

            foreach (string f in files)
            {
                string fn = Path.GetFileName(f);
                bool candIsScen = IsScenarioAssetName(fn);
                if (wantedIsScen != candIsScen) continue;

                double score = ComputeTextSimilarity(wantedStem, CleanAssetStem(fn));
                if (score > bestScore)
                {
                    bestScore = score;
                    bestPath = f;
                }
            }

            double minThreshold = wantedIsScen ? 0.50 : 0.72;
            return bestScore >= minThreshold ? bestPath : "";
        }

        public static int AutoAlignImportedAssetsOnDisk(EpisodeWorkItem item, Action<string> log)
        {
            if (item == null || !Directory.Exists(item.AssetsDir)) return 0;

            List<string> diskFiles = Directory.GetFiles(item.AssetsDir)
                .Where(f => Regex.IsMatch(Path.GetExtension(f), @"^\.(jpg|jpeg|png)$", RegexOptions.IgnoreCase) && new FileInfo(f).Length > 10 * 1024)
                .ToList();
            if (diskFiles.Count == 0) return 0;

            HashSet<string> allTargets = new HashSet<string>(item.AllRequiredFlowIngredients, StringComparer.OrdinalIgnoreCase);
            foreach (GrokAssetSpec gs in item.GrokSpecs)
            {
                if (!string.IsNullOrEmpty(gs.TargetFileName))
                    allTargets.Add(gs.TargetFileName);
            }

            // Alinha em disco somente Personagens importados com prefixo diferente (ex: 01_Personagem_1_O_Marido.jpg -> O_Marido.jpg)
            // Cenários equivalentes são mapeados exclusivamente em Temp\flow_assets para manter a pasta EP.X\assets\ limpa.
            HashSet<string> usedSources = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            int aligned = 0;
            foreach (string targetName in allTargets)
            {
                if (IsScenarioAssetName(targetName)) continue;

                string exactPath = Path.Combine(item.AssetsDir, targetName);
                if (File.Exists(exactPath) && new FileInfo(exactPath).Length > 10 * 1024)
                    continue;

                List<string> availableChars = diskFiles
                    .Where(f => !usedSources.Contains(f) && !IsScenarioAssetName(Path.GetFileName(f)) && !allTargets.Contains(Path.GetFileName(f)))
                    .ToList();

                string bestMatch = "";
                double bestScore = 0.0;
                string wantStem = CleanAssetStem(targetName);
                foreach (string cand in availableChars)
                {
                    double sc = ComputeTextSimilarity(wantStem, CleanAssetStem(Path.GetFileName(cand)));
                    if (sc > bestScore)
                    {
                        bestScore = sc;
                        bestMatch = cand;
                    }
                }

                if (bestScore >= 0.80 && !string.IsNullOrEmpty(bestMatch) && File.Exists(bestMatch))
                {
                    File.Copy(bestMatch, exactPath, false);
                    usedSources.Add(bestMatch);
                    diskFiles.Add(exactPath);
                    aligned++;
                    if (log != null)
                    {
                        log(string.Format("[Assets] Personagem importado alinhado: '{0}' -> '{1}'",
                            Path.GetFileName(bestMatch), targetName));
                    }
                }
            }
            return aligned;
        }

        public static void RefreshDiskCounters(EpisodeWorkItem item)
        {
            if (Directory.Exists(item.AssetsDir))
            {
                string[] assetFiles = Directory.GetFiles(item.AssetsDir)
                    .Where(f => Regex.IsMatch(Path.GetExtension(f), @"^\.(jpg|jpeg|png)$", RegexOptions.IgnoreCase) && new FileInfo(f).Length > 1024)
                    .ToArray();

                if (item.AllRequiredFlowIngredients.Count > 0)
                {
                    int matched = 0;
                    foreach (string req in item.AllRequiredFlowIngredients)
                    {
                        if (!string.IsNullOrEmpty(FindMatchingDiskAssetFile(req, assetFiles)))
                            matched++;
                    }
                    item.ExistingAssetsCount = matched;
                }
                else
                {
                    item.ExistingAssetsCount = assetFiles.Length;
                }
            }
            else
            {
                item.ExistingAssetsCount = 0;
            }

            if (Directory.Exists(item.TakesDir))
            {
                item.ExistingTakesCount = Directory.GetFiles(item.TakesDir, "Take_*.mp4", SearchOption.TopDirectoryOnly)
                    .Count(f => new FileInfo(f).Length > 20 * 1024);
                string wavPath = Path.Combine(item.TakesDir, "Narrador_Take_01.wav");
                item.HasProcessedNarratorWav = File.Exists(wavPath) && new FileInfo(wavPath).Length > 1024;
            }
            else
            {
                item.ExistingTakesCount = 0;
                item.HasProcessedNarratorWav = false;
            }
        }

        public static int SyncRecurringAssetsFromPreviousEpisodes(EpisodeWorkItem item, Action<string> log)
        {
            if (item == null) return 0;
            int copied = SyncLocalSubfolderAssets(item, log);

            if (item.EpisodeNumber <= 1 || string.IsNullOrEmpty(item.StoryRootPath))
            {
                RefreshDiskCounters(item);
                return copied;
            }

            if (!Directory.Exists(item.AssetsDir)) Directory.CreateDirectory(item.AssetsDir);

            List<string> prevEpisodeNames = new List<string>();
            for (int i = 1; i < item.EpisodeNumber; i++)
            {
                prevEpisodeNames.Add("EP." + i);
                prevEpisodeNames.Add("EP" + i);
            }

            List<string> candidateAssetDirs = new List<string>();
            foreach (string epName in prevEpisodeNames)
            {
                string d = Path.Combine(item.StoryRootPath, epName, "assets");
                if (Directory.Exists(d)) candidateAssetDirs.Add(d);
            }

            HashSet<string> wanted = new HashSet<string>(item.AllRequiredFlowIngredients, StringComparer.OrdinalIgnoreCase);
            foreach (GrokAssetSpec gs in item.GrokSpecs)
            {
                if (!string.IsNullOrEmpty(gs.TargetFileName))
                    wanted.Add(gs.TargetFileName);
            }

            foreach (string reqFile in wanted)
            {
                string dest = Path.Combine(item.AssetsDir, reqFile);
                if (File.Exists(dest) && new FileInfo(dest).Length > 10 * 1024) continue;

                foreach (string srcDir in candidateAssetDirs)
                {
                    string[] prevFiles = Directory.GetFiles(srcDir)
                        .Where(f => Regex.IsMatch(Path.GetExtension(f), @"^\.(jpg|jpeg|png)$", RegexOptions.IgnoreCase))
                        .ToArray();

                    string candidate = prevFiles.FirstOrDefault(f => string.Equals(Path.GetFileName(f), reqFile, StringComparison.OrdinalIgnoreCase));
                    if (!string.IsNullOrEmpty(candidate) && new FileInfo(candidate).Length > 10 * 1024)
                    {
                        File.Copy(candidate, dest, true);
                        copied++;
                        if (log != null) log(string.Format("[Continuidade] Asset recorrente reaproveitado para {0}: {1}", item.EpisodeName, reqFile));
                        break;
                    }
                }
            }

            // Sincronizar também todas as variantes de figurino (*__Roupa_*.jpg) entre os episódios da história
            foreach (string srcDir in candidateAssetDirs)
            {
                foreach (string f in Directory.GetFiles(srcDir))
                {
                    string fn = Path.GetFileName(f);
                    if (fn.IndexOf("__Roupa_", StringComparison.OrdinalIgnoreCase) < 0)
                        continue;
                    if (!Regex.IsMatch(Path.GetExtension(f), @"^\.(jpg|jpeg|png)$", RegexOptions.IgnoreCase))
                        continue;
                    if (new FileInfo(f).Length <= 5 * 1024)
                        continue;

                    string dst = Path.Combine(item.AssetsDir, fn);
                    if (!File.Exists(dst))
                    {
                        File.Copy(f, dst, true);
                        copied++;
                        if (log != null) log(string.Format("[Continuidade] Variante de roupa sincronizada para {0}: {1}", item.EpisodeName, fn));
                    }
                }
            }

            RefreshDiskCounters(item);
            return copied;
        }

        private static string FindBestFile(string[] files, string[] patterns, string[] excludeSubstrings = null)
        {
            foreach (string pat in patterns)
            {
                foreach (string f in files)
                {
                    string name = Path.GetFileName(f);
                    if (excludeSubstrings != null && excludeSubstrings.Any(ex => name.IndexOf(ex, StringComparison.OrdinalIgnoreCase) >= 0))
                        continue;

                    if (string.Equals(name, pat, StringComparison.OrdinalIgnoreCase) ||
                        name.IndexOf(pat, StringComparison.OrdinalIgnoreCase) >= 0)
                    {
                        return f;
                    }
                }
            }
            return "";
        }

        private static string ReadUtf8(string path)
        {
            return File.ReadAllText(path, Encoding.UTF8);
        }

        public static void ParseFlowTakes(
            string flowText,
            List<FlowTakeSpec> takesOut,
            List<string> uniqueIngredientsOut,
            Dictionary<string, string> titleToFileOut)
        {
            takesOut.Clear();
            uniqueIngredientsOut.Clear();
            titleToFileOut.Clear();

            if (string.IsNullOrWhiteSpace(flowText)) return;

            // Map inline patterns like: O Vaqueiro Pobre (01_Personagem_1_O_Vaqueiro_Pobre.jpg) OR A Esposa ([A_Esposa.jpg])
            MatchCollection inlineRefs = Regex.Matches(flowText, @"([A-ZÀ-Úa-zà-ú0-9][A-ZÀ-Úa-zà-ú0-9\s'\-]{1,48}?)\s*\(\[?([A-Za-z0-9_\-\.]+\.(?:jpg|jpeg|png))\]?\)", RegexOptions.CultureInvariant);
            foreach (Match m in inlineRefs)
            {
                string rawTitle = CleanArchetypeTitle(m.Groups[1].Value);
                string fname = m.Groups[2].Value.Trim();
                if (!string.IsNullOrEmpty(rawTitle) && !titleToFileOut.ContainsKey(rawTitle))
                {
                    titleToFileOut[rawTitle] = fname;
                }
            }

            string[] lines = flowText.Split(new[] { "\r\n", "\n" }, StringSplitOptions.None);
            FlowTakeSpec current = null;
            StringBuilder bodyBuilder = new StringBuilder();
            HashSet<string> seenIng = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            for (int i = 0; i < lines.Length; i++)
            {
                string line = lines[i];
                Match headerMatch = Regex.Match(line, @"Take\s*0*(\d+)\s*\|", RegexOptions.IgnoreCase);
                if (headerMatch.Success)
                {
                    if (current != null)
                    {
                        current.RawPromptBody = bodyBuilder.ToString().Trim();
                        takesOut.Add(current);
                    }

                    current = new FlowTakeSpec();
                    int tNum;
                    int.TryParse(headerMatch.Groups[1].Value, out tNum);
                    current.TakeNumber = tNum;
                    current.RawHeader = line.Trim();
                    current.HasSpeech = line.IndexOf("Sem Fala", StringComparison.OrdinalIgnoreCase) < 0;
                    bodyBuilder.Clear();

                    Match scenMatch = Regex.Match(line, @"Cen[aá]rio:\s*([^|]+)", RegexOptions.IgnoreCase);
                    if (scenMatch.Success) current.ScenarioName = scenMatch.Groups[1].Value.Trim();

                    Match ingMatch = Regex.Match(line, @"Ingredientes\s*Obrigat[oó]rios:\s*([^|]+)", RegexOptions.IgnoreCase);
                    if (ingMatch.Success)
                    {
                        MatchCollection files = Regex.Matches(ingMatch.Groups[1].Value, @"[A-Za-z0-9_\-\.]+\.(?:jpg|jpeg|png)", RegexOptions.IgnoreCase);
                        foreach (Match fm in files)
                        {
                            string fn = fm.Value.Trim();
                            if (!current.Ingredients.Contains(fn, StringComparer.OrdinalIgnoreCase))
                                current.Ingredients.Add(fn);
                            if (seenIng.Add(fn))
                                uniqueIngredientsOut.Add(fn);
                        }

                        // Map ScenarioName -> last ingredient file (usually scenario)
                        if (!string.IsNullOrEmpty(current.ScenarioName) && current.Ingredients.Count > 0)
                        {
                            string lastIng = current.Ingredients[current.Ingredients.Count - 1];
                            if (!titleToFileOut.ContainsKey(current.ScenarioName))
                                titleToFileOut[current.ScenarioName] = lastIng;
                        }
                    }
                }
                else if (current != null)
                {
                    bodyBuilder.AppendLine(line);
                }
            }

            if (current != null)
            {
                current.RawPromptBody = bodyBuilder.ToString().Trim();
                takesOut.Add(current);
            }
        }

        private static string CleanArchetypeTitle(string raw)
        {
            if (string.IsNullOrWhiteSpace(raw)) return "";
            string s = raw.Trim();
            string[] prefixes = new[]
            {
                "O homem adulto ", "o homem adulto ",
                "A mulher adulta ", "a mulher adulta ",
                "estão na ", "estão no ", "está na ", "está no ",
                "caminham pela ", "caminham pelo ", "em ", "na ", "no ", "e "
            };
            bool changed = true;
            while (changed)
            {
                changed = false;
                foreach (string p in prefixes)
                {
                    if (s.StartsWith(p, StringComparison.OrdinalIgnoreCase) && s.Length > p.Length + 2)
                    {
                        s = s.Substring(p.Length).Trim();
                        changed = true;
                    }
                }
            }
            return s;
        }

        public static void ParseGrokSpecs(
            string grokText,
            Dictionary<string, string> flowTitleMap,
            List<string> requiredFlowIngredients,
            List<GrokAssetSpec> specsOut)
        {
            specsOut.Clear();
            if (string.IsNullOrWhiteSpace(grokText)) return;

            string[] lines = grokText.Split(new[] { "\r\n", "\n" }, StringSplitOptions.RemoveEmptyEntries);
            int idx = 0;

            foreach (string rawLine in lines)
            {
                string line = rawLine.Trim();
                Match itemMatch = Regex.Match(line, @"^-\s*(Personagem\s*\d+[A-Za-z]?|Cen[aá]rio\s*[A-Z0-9]+)\s*:\s*(.+)$", RegexOptions.IgnoreCase);
                if (!itemMatch.Success) continue;

                idx++;
                GrokAssetSpec spec = new GrokAssetSpec();
                spec.OrderIndex = idx;
                spec.LabelPrefix = itemMatch.Groups[1].Value.Trim();
                spec.IsScenario = spec.LabelPrefix.StartsWith("Cen", StringComparison.OrdinalIgnoreCase);
                spec.RawPromptLine = line;

                string rest = itemMatch.Groups[2].Value.Trim();

                // 1. Check explicit filename in parentheses/brackets e.g. O Marido (O_Marido.jpg) or ([O_Marido.jpg])
                string explicitFile = "";
                Match fileParenMatch = Regex.Match(rest, @"[\(\[]+([A-Za-z0-9_\-\.]+\.(?:jpg|jpeg|png))[\)\]]+", RegexOptions.IgnoreCase);
                if (fileParenMatch.Success)
                {
                    explicitFile = fileParenMatch.Groups[1].Value.Trim();
                }

                // 2. Extract DisplayTitle written on top of image
                string displayTitle = "";
                Match quotedTitle = Regex.Match(line, @"(?:Escrito|Nome)\s+""([^""]+)""", RegexOptions.IgnoreCase);
                if (quotedTitle.Success)
                {
                    displayTitle = quotedTitle.Groups[1].Value.Trim();
                }
                else
                {
                    int dashIdx = rest.IndexOf(" - ");
                    string beforeDash = dashIdx > 0 ? rest.Substring(0, dashIdx).Trim() : rest;
                    beforeDash = Regex.Replace(beforeDash, @"[\(\[]+[A-Za-z0-9_\-\.]+\.(?:jpg|jpeg|png)[\)\]]+", "", RegexOptions.IgnoreCase).Trim();
                    beforeDash = Regex.Replace(beforeDash, @"^em\s+cima\s+da\s+cabe[cç]a\s+", "", RegexOptions.IgnoreCase).Trim();
                    displayTitle = beforeDash;
                }
                spec.DisplayTitle = displayTitle;

                // 3. Resolve TargetFileName
                if (!string.IsNullOrEmpty(explicitFile))
                {
                    spec.TargetFileName = explicitFile;
                }
                else
                {
                    string mapped = FindBestMappedFilename(displayTitle, spec.IsScenario, flowTitleMap, requiredFlowIngredients);
                    if (!string.IsNullOrEmpty(mapped))
                    {
                        spec.TargetFileName = mapped;
                    }
                    else
                    {
                        string prefixSlug = Slugify(spec.LabelPrefix);
                        string titleSlug = Slugify(displayTitle);
                        spec.TargetFileName = string.Format("{0:00}_{1}_{2}.jpg", idx, prefixSlug, titleSlug);
                    }
                }

                specsOut.Add(spec);
            }
        }

        private static string FindBestMappedFilename(
            string displayTitle,
            bool isScenario,
            Dictionary<string, string> flowTitleMap,
            List<string> requiredFlowIngredients)
        {
            if (string.IsNullOrWhiteSpace(displayTitle)) return "";

            if (flowTitleMap != null && flowTitleMap.Count > 0)
            {
                string exact;
                if (flowTitleMap.TryGetValue(displayTitle, out exact)) return exact;
            }

            string normTarget = NormalizeForCompare(displayTitle);
            string bestFile = "";
            double bestScore = 0.0;

            if (flowTitleMap != null)
            {
                foreach (KeyValuePair<string, string> kv in flowTitleMap)
                {
                    double score = ComputeTextSimilarity(normTarget, NormalizeForCompare(kv.Key));
                    double fileScore = ComputeTextSimilarity(normTarget, NormalizeForCompare(Path.GetFileNameWithoutExtension(kv.Value).Replace("_", " ")));
                    double max = Math.Max(score, fileScore);
                    if (max > bestScore)
                    {
                        bestScore = max;
                        bestFile = kv.Value;
                    }
                }
            }

            if (requiredFlowIngredients != null)
            {
                foreach (string ingFile in requiredFlowIngredients)
                {
                    string cleanedStem = CleanAssetStem(ingFile);
                    double score = ComputeTextSimilarity(normTarget, NormalizeForCompare(cleanedStem));
                    bool typeMatches = isScenario
                        ? ingFile.IndexOf("Cenario", StringComparison.OrdinalIgnoreCase) >= 0 || bestScore < 0.5
                        : ingFile.IndexOf("Cenario", StringComparison.OrdinalIgnoreCase) < 0;
                    if (typeMatches && score > bestScore)
                    {
                        bestScore = score;
                        bestFile = ingFile;
                    }
                }
            }

            return bestScore >= 0.52 ? bestFile : "";
        }

        public static string ExtractNarratorFromRoteiro(string roteiroText, out int segmentCount)
        {
            segmentCount = 0;
            if (string.IsNullOrWhiteSpace(roteiroText)) return "";

            List<string> paragraphs = new List<string>();
            string[] lines = roteiroText.Split(new[] { "\r\n", "\n" }, StringSplitOptions.RemoveEmptyEntries);

            foreach (string rawLine in lines)
            {
                string line = rawLine.Trim();
                Match narMatch = Regex.Match(line, @"(?:O\s+Narrador|Narrador)\s*:\s*(.+)$", RegexOptions.IgnoreCase);
                if (!narMatch.Success) continue;

                string speechPart = narMatch.Groups[1].Value.Trim();

                // Extract quoted speech if enclosed in quotes
                Match quoted = Regex.Match(speechPart, @"""([^""]+)""");
                string cleanSpeech;
                if (quoted.Success)
                {
                    cleanSpeech = quoted.Groups[1].Value.Trim();
                }
                else
                {
                    // Remove trailing (ação) and {148 caracteres}
                    cleanSpeech = Regex.Replace(speechPart, @"\{\s*\d+\s*caracteres[^}]*\}", "", RegexOptions.IgnoreCase);
                    cleanSpeech = Regex.Replace(cleanSpeech, @"\([^)]*\)\s*$", "").Trim();
                    cleanSpeech = cleanSpeech.Trim('"');
                }

                if (!string.IsNullOrWhiteSpace(cleanSpeech))
                {
                    paragraphs.Add(cleanSpeech);
                }
            }

            segmentCount = paragraphs.Count;
            return string.Join("\n\n", paragraphs);
        }

        public static string NormalizeForCompare(string input)
        {
            if (string.IsNullOrWhiteSpace(input)) return "";
            string formD = input.Normalize(NormalizationForm.FormD);
            StringBuilder sb = new StringBuilder();
            foreach (char ch in formD)
            {
                UnicodeCategory uc = CharUnicodeInfo.GetUnicodeCategory(ch);
                if (uc != UnicodeCategory.NonSpacingMark)
                {
                    if (char.IsLetterOrDigit(ch))
                        sb.Append(char.ToLowerInvariant(ch));
                    else
                        sb.Append(' ');
                }
            }
            return Regex.Replace(sb.ToString(), @"\s+", " ").Trim();
        }

        public static double ComputeTextSimilarity(string a, string b)
        {
            string na = NormalizeForCompare(a);
            string nb = NormalizeForCompare(b);
            if (string.IsNullOrEmpty(na) || string.IsNullOrEmpty(nb)) return 0.0;
            if (na == nb) return 1.0;
            if (na.Contains(nb) || nb.Contains(na))
            {
                int minLen = Math.Min(na.Length, nb.Length);
                int maxLen = Math.Max(na.Length, nb.Length);
                return 0.75 + (0.25 * minLen / Math.Max(1, maxLen));
            }

            string[] tokA = na.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries).Where(t => t.Length > 1).ToArray();
            string[] tokB = nb.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries).Where(t => t.Length > 1).ToArray();
            double tokenScore = 0.0;
            if (tokA.Length > 0 && tokB.Length > 0)
            {
                int matches = tokA.Count(ta => tokB.Any(tb => tb == ta || (ta.Length >= 4 && tb.StartsWith(ta.Substring(0, 4)))));
                tokenScore = (2.0 * matches) / (tokA.Length + tokB.Length);
            }

            int dist = LevenshteinDistance(na, nb);
            double editScore = 1.0 - ((double)dist / Math.Max(na.Length, nb.Length));
            return Math.Max(tokenScore, editScore);
        }

        private static int LevenshteinDistance(string s, string t)
        {
            int n = s.Length;
            int m = t.Length;
            int[,] d = new int[n + 1, m + 1];
            for (int i = 0; i <= n; i++) d[i, 0] = i;
            for (int j = 0; j <= m; j++) d[0, j] = j;
            for (int i = 1; i <= n; i++)
            {
                for (int j = 1; j <= m; j++)
                {
                    int cost = (t[j - 1] == s[i - 1]) ? 0 : 1;
                    d[i, j] = Math.Min(
                        Math.Min(d[i - 1, j] + 1, d[i, j - 1] + 1),
                        d[i - 1, j - 1] + cost);
                }
            }
            return d[n, m];
        }

        public static string Slugify(string text)
        {
            string norm = NormalizeForCompare(text);
            if (string.IsNullOrEmpty(norm)) return "Item";
            string[] parts = norm.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            for (int i = 0; i < parts.Length; i++)
            {
                if (parts[i].Length > 1)
                    parts[i] = char.ToUpperInvariant(parts[i][0]) + parts[i].Substring(1);
                else
                    parts[i] = parts[i].ToUpperInvariant();
            }
            return string.Join("_", parts);
        }

        public static string GetBaseCharacterFileName(string fileName)
        {
            if (string.IsNullOrEmpty(fileName)) return "";
            string fn = Path.GetFileName(fileName);
            int idx = fn.IndexOf("__Roupa_", StringComparison.OrdinalIgnoreCase);
            if (idx > 0)
            {
                string ext = Path.GetExtension(fn);
                return fn.Substring(0, idx) + ext;
            }
            return fn;
        }

        public static string ExtractOutfitOccasionLabel(string variantFileName)
        {
            if (string.IsNullOrEmpty(variantFileName)) return "";
            string stem = Path.GetFileNameWithoutExtension(variantFileName);
            int idx = stem.IndexOf("__Roupa_", StringComparison.OrdinalIgnoreCase);
            if (idx < 0) return "";
            return stem.Substring(idx + "__Roupa_".Length).Replace("_", " ").Trim();
        }

        public static string NormalizeStandardWardrobeCategory(string categoryOrOccasion)
        {
            string norm = NormalizeForCompare(categoryOrOccasion ?? "");
            if (string.IsNullOrEmpty(norm)) return "Simples";

            if (Regex.IsMatch(norm, @"\b(trabalho|obra|engenheiro|construcao|escritorio|empresa|uniforme|avental|servico|profissional)\b"))
                return "Trabalho";
            if (Regex.IsMatch(norm, @"\b(lazer|passeio|parque|praia|encontro|fim de semana|esporte|descanso)\b"))
                return "Lazer";
            if (Regex.IsMatch(norm, @"\b(formal|formatura|beca|baile|festa|gala|casamento|smoking|terno|luxo|chique|elegante)\b"))
                return "Formal";
            if (Regex.IsMatch(norm, @"\b(simples|casual|dia a dia|cotidiano|casa|caseira|humilde|rotina|padrao)\b"))
                return "Simples";

            return Slugify(categoryOrOccasion);
        }

        public static string FormatOutfitDisplayLabel(string variantFileOrOccasion)
        {
            if (string.IsNullOrEmpty(variantFileOrOccasion)) return "Roupa Padrão";
            string rawOcc = variantFileOrOccasion.IndexOf("__Roupa_", StringComparison.OrdinalIgnoreCase) >= 0
                ? ExtractOutfitOccasionLabel(variantFileOrOccasion)
                : variantFileOrOccasion;

            string norm = NormalizeForCompare(rawOcc);
            if (norm == "trabalho") return "Roupa de Trabalho";
            if (norm == "lazer") return "Roupa de Lazer";
            if (norm == "formal") return "Roupa Formal";
            if (norm == "simples") return "Roupa Simples";

            if (rawOcc.StartsWith("Roupa ", StringComparison.OrdinalIgnoreCase))
                return rawOcc;
            return "Roupa " + rawOcc;
        }

        public static string BuildOutfitVariantFileName(string baseCharFileName, string occasionLabel)
        {
            string cleanBase = GetBaseCharacterFileName(baseCharFileName);
            string baseStem = Path.GetFileNameWithoutExtension(cleanBase);
            string stdCat = NormalizeStandardWardrobeCategory(occasionLabel);
            string occSlug = Slugify(stdCat);
            return string.Format("{0}__Roupa_{1}.jpg", baseStem, occSlug);
        }

        public static string DetectBaseCharacterOutfitCategory(string rawPromptLine, string charFileName)
        {
            string norm = NormalizeForCompare((rawPromptLine ?? "") + " " + (charFileName ?? ""));
            if (string.IsNullOrEmpty(norm)) return "Padrao";

            // 1. Roupa Formal / Formatura / Gala / Festa / Alfaiataria de Luxo
            if (Regex.IsMatch(norm, @"\b(formatura|beca|capelo|baile|smoking|vestido de festa|vestido de gala|vestido longo de luxo|noiva|noivo|terno de gala|casamento|alfaiataria branco de luxo)\b"))
                return "Formal";

            // 2. Roupa de Trabalho / Obra / Uniforme / Avental de Serviço
            if (Regex.IsMatch(norm, @"\b(avental|capacete|colete refletivo|botina de obra|macacao de trabalho|uniforme|jaleco|farda)\b"))
                return "Trabalho";

            // 3. Roupa de Lazer / Passeio
            if (Regex.IsMatch(norm, @"\b(roupa de lazer|roupa de passeio|bermuda de passeio|roupa de praia|roupa esportiva)\b"))
                return "Lazer";

            // 4. Roupa Simples / Caseira / Humilde
            if (Regex.IsMatch(norm, @"\b(roupa simples|vestido simples|camiseta surrada|chinelo|humilde|roupa caseira|descalco|remendad)\b"))
                return "Simples";

            return "Padrao";
        }

        public static string GetCharacterBasePromptFromStory(EpisodeWorkItem ep, string baseCharFileName)
        {
            if (ep == null || string.IsNullOrEmpty(baseCharFileName))
                return "";

            string cleanBase = GetBaseCharacterFileName(baseCharFileName);
            string charTitle = CleanAssetStem(cleanBase);

            if (ep.GrokSpecs != null)
            {
                GrokAssetSpec spec = ep.GrokSpecs.FirstOrDefault(s =>
                    string.Equals(GetBaseCharacterFileName(s.TargetFileName), cleanBase, StringComparison.OrdinalIgnoreCase) ||
                    (!string.IsNullOrEmpty(charTitle) && string.Equals(s.DisplayTitle, charTitle, StringComparison.OrdinalIgnoreCase)));
                if (spec != null && !string.IsNullOrWhiteSpace(spec.RawPromptLine))
                    return spec.RawPromptLine;
            }

            if (!string.IsNullOrEmpty(ep.StoryRootPath) && Directory.Exists(ep.StoryRootPath))
            {
                foreach (string sub in Directory.GetDirectories(ep.StoryRootPath).OrderBy(d => d))
                {
                    if (!Regex.IsMatch(Path.GetFileName(sub), @"^EP\.?\s*\d+$", RegexOptions.IgnoreCase))
                        continue;

                    string[] txts = Directory.GetFiles(sub, "*.txt", SearchOption.TopDirectoryOnly);
                    string grokPath = FindBestFile(txts, new[] { "prompt_grok_passo1_e_2.txt", "prompt_grok", "comandos_gemini_completos" });
                    if (string.IsNullOrEmpty(grokPath) || !File.Exists(grokPath))
                        continue;

                    string grokText = ReadUtf8(grokPath);
                    if (string.IsNullOrEmpty(grokText))
                        continue;

                    foreach (string rawLine in grokText.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries))
                    {
                        string line = rawLine.Trim();
                        if (!line.StartsWith("- Personagem", StringComparison.OrdinalIgnoreCase) &&
                            line.IndexOf("Personagem", StringComparison.OrdinalIgnoreCase) < 0)
                            continue;

                        if (!string.IsNullOrEmpty(charTitle) &&
                            NormalizeForCompare(line).IndexOf(NormalizeForCompare(charTitle), StringComparison.OrdinalIgnoreCase) >= 0)
                        {
                            return line;
                        }
                    }
                }
            }

            return "";
        }

        public static string GetFullStoryNarrativeContext(EpisodeWorkItem ep)
        {
            if (ep == null) return "";
            StringBuilder sb = new StringBuilder();
            if (!string.IsNullOrEmpty(ep.RoteiroText)) sb.AppendLine(ep.RoteiroText);
            if (!string.IsNullOrEmpty(ep.FlowPromptText)) sb.AppendLine(ep.FlowPromptText);

            if (!string.IsNullOrEmpty(ep.StoryRootPath) && Directory.Exists(ep.StoryRootPath))
            {
                foreach (string sub in Directory.GetDirectories(ep.StoryRootPath).OrderBy(d => d))
                {
                    if (string.Equals(sub, ep.EpisodePath, StringComparison.OrdinalIgnoreCase))
                        continue;
                    if (!Regex.IsMatch(Path.GetFileName(sub), @"^EP\.?\s*\d+$", RegexOptions.IgnoreCase))
                        continue;

                    try
                    {
                        string[] txts = Directory.GetFiles(sub, "*.txt", SearchOption.TopDirectoryOnly);
                        string rot = FindBestFile(txts, new[] { "roteiro.txt", "roteiro_camaleao", "roteiro_parte", "roteiro" },
                            excludeSubstrings: new[] { "decupado", "gem_" });
                        if (!string.IsNullOrEmpty(rot) && File.Exists(rot))
                            sb.AppendLine(ReadUtf8(rot));
                        string flw = FindBestFile(txts, new[] { "prompt_flow_passo3.txt", "prompt_flow", "passo3_takes" });
                        if (!string.IsNullOrEmpty(flw) && File.Exists(flw))
                            sb.AppendLine(ReadUtf8(flw));
                    }
                    catch { }
                }
            }

            return NormalizeForCompare(sb.ToString());
        }

        public static string ExtractCharacterSpecificClauseInTake(FlowTakeSpec take, string baseCharFileName)
        {
            if (take == null || string.IsNullOrEmpty(take.RawPromptBody) || string.IsNullOrEmpty(baseCharFileName))
                return "";

            string cleanBase = GetBaseCharacterFileName(baseCharFileName);
            string body = take.RawPromptBody;
            int idx = body.IndexOf(cleanBase, StringComparison.OrdinalIgnoreCase);
            if (idx < 0)
            {
                string title = CleanAssetStem(cleanBase);
                if (!string.IsNullOrEmpty(title))
                    idx = body.IndexOf(title, StringComparison.OrdinalIgnoreCase);
            }
            if (idx < 0) return "";

            // Começa exatamente no nome/arquivo do personagem (pois a descrição da roupa e ação dele vem SEMPRE após o nome, evitando capturar o nome do Cenário antes dele)
            int start = idx;
            int afterRef = idx + cleanBase.Length;
            int maxLen = Math.Min(body.Length - start, 200);
            string sub = body.Substring(start, maxLen);

            // Corta imediatamente se começar a descrever outro personagem ou outro arquivo .jpg de personagem
            int offsetAfterRef = Math.Min(sub.Length, Math.Max(10, afterRef - start));
            string tail = sub.Substring(offsetAfterRef);
            Match nextChar = Regex.Match(
                tail,
                @"(\(\d{2}_Personagem_|[\.,;]\s*(?:e\s+|enquanto\s+|ao\s+lado[^,]*,\s*|a\s+frente[^,]*,\s*|atras[^,]*,\s*|diante[^,]*,\s*)?(?:o\s+homem|a\s+mulher|o\s+jovem|a\s+jovem|o\s+idoso|a\s+idosa)\b|,\s*(?:e\s+|enquanto\s+)?(?:o\s+homem|a\s+mulher|o\s+jovem|a\s+jovem|o\s+idoso|a\s+idosa)\b|\benquanto\s+(?:ao\s+fundo\s+|ao\s+lado\s+)?(?:o\s+homem|a\s+mulher|o\s+jovem|a\s+jovem|o\s+idoso|a\s+idosa)\b)",
                RegexOptions.IgnoreCase);
            if (nextChar.Success)
            {
                sub = sub.Substring(0, offsetAfterRef + nextChar.Index);
            }
            return NormalizeForCompare(sub);
        }

        public static string DetectCharacterRequiredOutfitInTake(
            FlowTakeSpec take,
            string baseCharFileName,
            string rawBasePrompt,
            string baseCategory)
        {
            if (take == null) return "Padrao";

            string normBase = NormalizeForCompare((rawBasePrompt ?? "") + " " + (baseCharFileName ?? ""));
            bool baseHasApron = Regex.IsMatch(normBase, @"\b(avental)\b");
            bool baseHasBeca = Regex.IsMatch(normBase, @"\b(beca|capelo|canudo.*diploma)\b");

            // 1. Analisa primeiro a descrição específica daquele personagem dentro do Take
            string charClause = ExtractCharacterSpecificClauseInTake(take, baseCharFileName);
            if (!string.IsNullOrEmpty(charClause))
            {
                // Se o Take menciona explicitamente "sem o avental", "vestido simples", "roupa simples" ou "roupa velha" para este personagem
                if (Regex.IsMatch(charClause, @"\b(sem o avental|sem avental|vestido simples|roupa simples|roupa velha|camiseta simples|chinelo)\b"))
                    return "Simples";

                if (Regex.IsMatch(charClause, @"\b(com seu avental|com avental|avental creme|de avental|sovando massa|preparando salgados|capacete|uniforme|jaleco)\b"))
                    return "Trabalho";

                if (!baseHasApron && Regex.IsMatch(charClause, @"\b(beca|capelo|terno de gala|smoking|vestido de festa|vestido de gala|alfaiataria branco de luxo)\b"))
                    return "Formal";

                if (Regex.IsMatch(charClause, @"\b(camisa social|terno executivo|blazer|pasta executiva|roupa de escritorio)\b"))
                    return "Trabalho";
            }

            string scenarioNorm = NormalizeForCompare(take.ScenarioName ?? "");
            string contextText = NormalizeForCompare((take.ScenarioName ?? "") + " " + (take.RawHeader ?? "") + " " + (take.RawPromptBody ?? ""));

            // 2. Regras de Contexto da Cena específicas para personagens cuja Roupa Padrão tem Avental (ex: A Salgadeira)
            if (baseHasApron)
            {
                // Na cozinha ou entregando encomendas de salgados na chuva, usa sua Roupa Padrão de trabalho (com avental)
                if (Regex.IsMatch(scenarioNorm, @"\b(cozinha|lanchonete)\b") ||
                    Regex.IsMatch(contextText, @"\b(sovando massa|preparando salgados|caixas de salgados|forno|fogao)\b"))
                {
                    return "Trabalho";
                }
                // Quando sai para ir à formatura do marido, ao escritório da construtora ou à joalheria na cidade,
                // tira o avental e vai com sua roupa simples, porém limpa e arrumadinha ("Simples")!
                return "Simples";
            }

            // 3. Regras de Contexto da Cena específicas para personagens cuja Roupa Padrão é Beca de Formatura (ex: O Engenheiro)
            if (baseHasBeca)
            {
                bool isGradScene = Regex.IsMatch(scenarioNorm, @"\b(formatura|baile)\b") ||
                                   Regex.IsMatch(contextText, @"\b(salao de baile|colacao de grau|baile de formatura)\b");
                if (isGradScene)
                    return "Formal";

                // Se já está trabalhando na construtora/escritório ou chegando do trabalho/jantar com a diretoria / pedindo divórcio (EP.2)
                if (Regex.IsMatch(scenarioNorm, @"\b(escritorio|construtora|obra|empresa)\b") ||
                    Regex.IsMatch(contextText, @"\b(construtora|escritorio|diretoria|reuniao de negocios|mala de viagem|quero o divorcio)\b"))
                {
                    return "Trabalho";
                }

                // Em casa estudando cadernos e boletos da faculdade antes de se formar -> Roupa Simples de estudante em casa
                return "Simples";
            }

            // 4. Caso geral: analisa o contexto do Cenário/Cena
            return DetectTakeRequiredOutfitCategory(take, baseCategory);
        }

        public static string DetectTakeRequiredOutfitCategory(FlowTakeSpec take, string baseCategory)
        {
            if (take == null) return "Padrao";
            string contextText = NormalizeForCompare((take.ScenarioName ?? "") + " " + (take.RawHeader ?? "") + " " + (take.RawPromptBody ?? ""));
            if (string.IsNullOrEmpty(contextText)) return "Padrao";

            string scenarioNorm = NormalizeForCompare(take.ScenarioName ?? "");

            // 1. Verifica se o Cenário principal é Formal (Formatura / Baile / Casamento / Festa de Gala)
            bool isFormalScene = Regex.IsMatch(scenarioNorm, @"\b(formatura|baile|casamento|gala|festa|salao nobre|recepcao de luxo)\b") ||
                                 (!Regex.IsMatch(scenarioNorm, @"\b(cozinha|casinha|rua|joalheria|quarto|sala simples|obra)\b") &&
                                  Regex.IsMatch(contextText, @"\b(salao de baile|colacao de grau|baile de formatura|festa de gala|altar da igreja)\b"));
            if (isFormalScene)
            {
                // Se a roupa base do personagem era de Trabalho (ex: avental de cozinha) e ele foi ao baile/formatura, usa Roupa Simples (sem avental, arrumadinha)
                if (string.Equals(baseCategory, "Trabalho", StringComparison.OrdinalIgnoreCase))
                    return "Simples";
                return "Formal";
            }

            // 2. Verifica se o Cenário é de Trabalho (Obra / Construção / Escritório / Construtora / Lavoura / Oficina)
            bool isWorkScene = Regex.IsMatch(scenarioNorm, @"\b(obra|construcao|canteiro|escritorio|construtora|empresa|oficina|lavoura|roca|consultorio)\b") ||
                               Regex.IsMatch(contextText, @"\b(canteiro de obra|capacete de obra|sala na nossa construtora|reuniao de negocios|trabalhando na obra)\b");
            if (isWorkScene)
                return "Trabalho";

            // 3. Verifica se o Cenário é de Lazer (Passeio / Parque / Praça / Praia / Encontro / Barzinho / Cafeteria / Fim de semana)
            bool isLeisureScene = Regex.IsMatch(scenarioNorm, @"\b(lazer|passeio|parque|praca|praia|barzinho|shopping|jardim|piscina|cafeteria)\b");
            if (isLeisureScene)
                return "Lazer";

            // 4. Verifica se o Cenário é de Casa / Cotidiano Simples (Cozinha / Casinha / Quarto / Sala / Quintal)
            bool isSimpleScene = Regex.IsMatch(scenarioNorm, @"\b(casa|casinha|cozinha|quarto|sala|quintal|varanda|alpendre)\b") ||
                                 Regex.IsMatch(contextText, @"\b(casa simples|casinha|cozinha|fogao|mesa de madeira|boletos da minha faculdade)\b");
            if (isSimpleScene)
            {
                // Se a base do personagem já é Trabalho doméstico (ex: A Salgadeira com avental na cozinha), na cozinha ela usa a própria Roupa Padrão!
                if (string.Equals(baseCategory, "Trabalho", StringComparison.OrdinalIgnoreCase))
                    return "Trabalho";
                return "Simples";
            }

            // 5. Regra Inteligente Pós-Ocasião Especial:
            // Se a Roupa Padrão original do personagem era de Formatura/Festa ("Formal") e este Take NÃO é mais na formatura/festa,
            // troca automaticamente para "Simples" para o personagem não ficar de beca/vestido de gala fora da festa!
            if (string.Equals(baseCategory, "Formal", StringComparison.OrdinalIgnoreCase) && !isFormalScene)
                return "Simples";

            return "Padrao";
        }

        public static string GetStandardWardrobePresetDescription(EpisodeWorkItem ep, string baseCharFileName, string categoryKey)
        {
            string cleanBase = GetBaseCharacterFileName(baseCharFileName);
            string charTitle = CleanAssetStem(cleanBase);
            string rawBasePrompt = GetCharacterBasePromptFromStory(ep, cleanBase);
            string fullStoryNorm = GetFullStoryNarrativeContext(ep);

            string normChar = NormalizeForCompare(charTitle + " " + rawBasePrompt);
            bool hasMaleWord = Regex.IsMatch(normChar, @"\b(homem|senhor|rapaz|menino|pai|marido|noivo|filho|irmao|engenheiro|arquiteto|pedreiro|servente|lavrador|campones|patrao|chefe|doutor|medico|advogado|garoto|velho|idoso)\b");
            bool hasFemaleWord = Regex.IsMatch(normChar, @"\b(mulher|senhora|moca|menina|mae|esposa|noiva|filha|irma|dona|tia|sobrinha|salgadeira|faxineira|cozinheira|professora|secretaria|camponesa|garota|velha|idosa|vendedora)\b");
            bool isFemale = hasFemaleWord && !hasMaleWord;
            bool isElderly = Regex.IsMatch(normChar, @"\b(idosa|idoso|senhora|senhor|avo|velho|velha|grisalh\w*|60 anos|65 anos|70 anos)\b");
            bool isEngineerOrExec = Regex.IsMatch(normChar, @"\b(engenheir\w*|arquiteto\w*|advogad\w*|empresari\w*|executiv\w*|diretor\w*|chefe|patrao|doutor\w*|medic\w*|gerente)\b");
            bool isRuralOrWorker = Regex.IsMatch(normChar, @"\b(pedreiro|servente|lavrador\w*|campones\w*|roceir\w*|operari\w*|mecanic\w*|carpinteir\w*|salgadeir\w*|faxineir\w*|cozinheir\w*)\b");
            bool hasApronInBase = Regex.IsMatch(normChar, @"\b(avental)\b");
            bool hasBecaInBase = Regex.IsMatch(normChar, @"\b(beca|capelo|canudo.*diploma)\b");
            bool isHumbleCharacter = Regex.IsMatch(normChar, @"\b(humilde|simples|salgadeir\w*|faxineir\w*|cozinheir\w*|servente|pedreiro|lavrador\w*|campones\w*|roceir\w*|diarista)\b");
            bool isDespisedForSimpleClothesInStory = isHumbleCharacter &&
                Regex.IsMatch(fullStoryNorm, @"\b(vergonha de voce|vergonha de mim|roupa velha|vestido melhor|so uma vizinha|nao combina mais com a minha vida|humilhad\w*)\b");

            // Extrai o vestido/roupa original sem avental quando o personagem humilde já tem um vestido descrito no PASSO 1
            string baseDressWithoutApron = "";
            if (!string.IsNullOrEmpty(rawBasePrompt))
            {
                Match mBaseDress = Regex.Match(rawBasePrompt, @"Veste\s+([^\.]+)", RegexOptions.IgnoreCase);
                if (mBaseDress.Success)
                {
                    string rawCloth = mBaseDress.Groups[1].Value;
                    rawCloth = Regex.Replace(rawCloth, @"\s*(com\s+um\s+avental|com\s+avental|e\s+avental)[^,\.]*", "", RegexOptions.IgnoreCase);
                    rawCloth = Regex.Replace(rawCloth, @"\s*segurando\s+[^,\.]*", "", RegexOptions.IgnoreCase);
                    baseDressWithoutApron = rawCloth.Trim().TrimEnd(',', ';');
                }
            }

            string std = NormalizeStandardWardrobeCategory(categoryKey);

            // Coleta pistas extras EXCLUSIVAMENTE da oração daquele personagem (nunca do texto de outros personagens no mesmo Take!)
            string takeHints = "";
            if (ep != null && ep.FlowTakes != null)
            {
                string baseCat = DetectBaseCharacterOutfitCategory(rawBasePrompt, cleanBase);
                foreach (FlowTakeSpec t in ep.FlowTakes)
                {
                    bool hasChar = t.Ingredients != null && t.Ingredients.Any(i =>
                        string.Equals(GetBaseCharacterFileName(i), cleanBase, StringComparison.OrdinalIgnoreCase));
                    if (!hasChar) continue;

                    string reqCat = DetectCharacterRequiredOutfitInTake(t, cleanBase, rawBasePrompt, baseCat);
                    if (string.Equals(reqCat, std, StringComparison.OrdinalIgnoreCase))
                    {
                        string charClause = ExtractCharacterSpecificClauseInTake(t, cleanBase);
                        if (string.IsNullOrEmpty(charClause)) continue;

                        Match mCloth = Regex.Match(charClause, @"\b(vestindo|usando|com seu vestido|em seu vestido|com camisa|com vestido|com terno|com avental|com capacete|sem o avental|de camisa|de calca|de blusa)[^,\.;]{3,65}", RegexOptions.IgnoreCase);
                        if (mCloth.Success)
                        {
                            string candidate = mCloth.Value.Trim();
                            if (std != "Trabalho" && Regex.IsMatch(candidate, @"\b(avental|capacete)\b", RegexOptions.IgnoreCase))
                                continue;
                            if (std != "Formal" && Regex.IsMatch(candidate, @"\b(beca|capelo)\b", RegexOptions.IgnoreCase))
                                continue;
                            takeHints = candidate;
                            break;
                        }
                    }
                }
            }

            string noPropsSuffix = " Mãos totalmente livres e vazias ao lado do corpo (sem canudo de diploma, sem pastas e sem objetos nas mãos), sem adicionar óculos.";

            if (std == "Trabalho")
            {
                if (isFemale)
                {
                    if (isEngineerOrExec)
                        return "Roupa de trabalho profissional: camisa social feminina bem cortada, blazer estruturado, calça de alfaiataria e sapatos fechados de trabalho." + noPropsSuffix;
                    if (isRuralOrWorker)
                        return "Roupa de trabalho humilde e prática: vestido ou blusa modesta de algodão com avental de serviço amarrado na cintura e calçado baixo fechado de trabalho." + noPropsSuffix;
                    return "Roupa de trabalho cotidiana: blusa social discreta de mangas curtas, calça comprida de trabalho e sapatos baixos confortáveis." + noPropsSuffix;
                }
                else
                {
                    if (isEngineerOrExec)
                    {
                        bool hasOfficeInStory = Regex.IsMatch(fullStoryNorm, @"\b(escritorio moderno|construtora|diretoria|sala na nossa construtora)\b");
                        if (hasOfficeInStory)
                            return "Contexto da história: engenheiro recém-formado e ambicioso trabalhando no escritório moderno de uma construtora (TOTALMENTE SEM BECA DE FORMATURA E SEM CANUDO DE DIPLOMA NAS MÃOS). Veste camisa social elegante bem alinhada por dentro da calça, calça social de alfaiataria escura com cinto de couro e sapatos sociais de couro lustrados." + noPropsSuffix;
                        return "Roupa de trabalho de engenheiro/profissional (TOTALMENTE SEM BECA DE FORMATURA E SEM CANUDO DE DIPLOMA): camisa social azul-clara bem alinhada com mangas dobradas até o cotovelo, calça social ou jeans escura de ótimo caimento e sapatos/botas de couro." + noPropsSuffix;
                    }
                    if (isRuralOrWorker)
                        return "Roupa de trabalho pesado: camisa de algodão resistente levemente gasta pelo serviço, calça jeans grossa de trabalho e botinas de couro." + noPropsSuffix;
                    return "Roupa de trabalho: camisa social ou camisa polo de serviço, calça comprida escura com cinto de couro e sapatos de trabalho." + noPropsSuffix;
                }
            }
            else if (std == "Lazer")
            {
                if (isFemale)
                {
                    if (isHumbleCharacter)
                        return "Roupa de passeio modesta e simples: vestido casual leve de algodão sem avental ou blusinha limpa de fim de semana com saia/calça simples e sandálias baixas confortáveis." + noPropsSuffix;
                    return "Roupa de lazer e passeio: vestido casual leve de passeio ou blusa bonita de fim de semana com calça jeans clara e sandálias confortáveis." + noPropsSuffix;
                }
                else
                {
                    return "Roupa de lazer e passeio (sem beca e sem terno): camiseta polo ou camisa casual aberta no colarinho, calça jeans confortável e tênis casual de passeio." + noPropsSuffix;
                }
            }
            else if (std == "Formal")
            {
                if (isFemale)
                {
                    // Se o contexto da história diz que ela é humilde e o marido tem vergonha da roupa simples dela na festa/formatura:
                    if (isDespisedForSimpleClothesInStory || (isHumbleCharacter && hasApronInBase))
                    {
                        string dressDesc = !string.IsNullOrEmpty(baseDressWithoutApron)
                            ? baseDressWithoutApron
                            : "vestido simples rosa-claro modesto de algodão até abaixo dos joelhos e sapatilhas baixas simples";
                        return string.Format(
                            "Contexto da cena: esposa humilde que vai à formatura do marido usando sua melhor roupinha simples, limpa e arrumadinha de cidade pequena (TOTALMENTE SEM AVENTAL, sem brilho de cetim e sem luxo, motivo pelo qual o marido vaidoso sente vergonha dela diante dos convidados ricos). Veste {0}, bem limpo e passado, com um casaquinho leve modesto sobre os ombros, TOTALMENTE SEM AVENTAL.{1}",
                            dressDesc,
                            noPropsSuffix);
                    }
                    if (isElderly)
                        return "Roupa formal modesta e digna: vestido discreto de ocasião especial até abaixo dos joelhos com casaquinho de tricô leve sobre os ombros e sapatos baixos." + noPropsSuffix;
                    return "Roupa formal de ocasião especial: vestido social elegante de festa/cerimônia, tecido refinado com caimento impecável e sapatos sociais." + noPropsSuffix;
                }
                else
                {
                    return "Roupa formal completa: terno social escuro bem alinhado, camisa social branca impecável, gravata elegante e sapatos sociais de couro lustrado." + noPropsSuffix;
                }
            }
            else // "Simples"
            {
                if (isFemale)
                {
                    if (hasApronInBase || isDespisedForSimpleClothesInStory || isHumbleCharacter)
                    {
                        string dressDesc = !string.IsNullOrEmpty(baseDressWithoutApron)
                            ? baseDressWithoutApron
                            : "vestido simples rosa-claro modesto de algodão até abaixo dos joelhos e sapatilhas baixas simples";
                        return string.Format(
                            "Contexto da cena: mulher humilde e batalhadora fora da cozinha (indo à formatura do marido e à cidade) usando roupa simples, porém limpa, modesta e arrumadinha (o que faz o marido vaidoso fingir que não a conhece na formatura). Veste {0}, limpo, bem passado e arrumadinho, TOTALMENTE SEM O AVENTAL DE COZINHA e sem manchas de farinha, sem luxo e sem brilho.{1}",
                            dressDesc,
                            noPropsSuffix);
                    }
                    if (isElderly)
                        return "Roupa simples e humilde do dia a dia: vestido modesto de algodão ou saia midi simples com blusa de malha confortável e sandálias baixas." + noPropsSuffix;
                    return "Roupa simples do dia a dia: blusa básica de algodão, calça jeans simples ou saia modesta caseira e calçado simples confortável." + noPropsSuffix;
                }
                else
                {
                    if (hasBecaInBase)
                    {
                        return "Contexto da cena: jovem marido estudante universitário em casa na cozinha simples estudando cadernos e boletos antes de se formar (TOTALMENTE SEM BECA DE FORMATURA, SEM FAIXA AZUL E SEM CANUDO DE DIPLOMA NAS MÃOS, E SEM AVENTAL). Veste camiseta básica ou camisa polo simples de algodão de ficar em casa, calça jeans comum e tênis simples." + noPropsSuffix;
                    }
                    if (isElderly)
                        return "Roupa simples e humilde do dia a dia: camisa de botão simples de algodão, calça de tecido modesta e sapatos simples." + noPropsSuffix;
                    return "Roupa simples e casual do dia a dia (sem beca e sem terno): camiseta básica de algodão ou camisa simples, calça jeans comum e tênis simples." + noPropsSuffix;
                }
            }
        }

        public static List<CharacterWardrobeSpec> DetectRequiredCharacterOutfitsFromText(EpisodeWorkItem ep)
        {
            List<CharacterWardrobeSpec> results = new List<CharacterWardrobeSpec>();
            if (ep == null) return results;

            // Coleta todos os Takes de todos os episódios da mesma história (EP.1, EP.2, EP.3) para detectar o guarda-roupa completo da história
            List<FlowTakeSpec> allStoryTakes = new List<FlowTakeSpec>();
            List<GrokAssetSpec> allStoryGrokSpecs = new List<GrokAssetSpec>();

            if (!string.IsNullOrEmpty(ep.StoryRootPath) && Directory.Exists(ep.StoryRootPath))
            {
                foreach (string sub in Directory.GetDirectories(ep.StoryRootPath).OrderBy(d => d))
                {
                    if (!Regex.IsMatch(Path.GetFileName(sub), @"^EP\.?\s*\d+$", RegexOptions.IgnoreCase))
                        continue;

                    if (string.Equals(sub, ep.EpisodePath, StringComparison.OrdinalIgnoreCase))
                    {
                        if (ep.FlowTakes != null) allStoryTakes.AddRange(ep.FlowTakes);
                        if (ep.GrokSpecs != null) allStoryGrokSpecs.AddRange(ep.GrokSpecs);
                    }
                    else
                    {
                        try
                        {
                            EpisodeWorkItem sibling = ParseEpisodeFolder(sub, ep.StoryName, ep.Genre, ep.StoryRootPath);
                            if (sibling != null)
                            {
                                if (sibling.FlowTakes != null) allStoryTakes.AddRange(sibling.FlowTakes);
                                if (sibling.GrokSpecs != null) allStoryGrokSpecs.AddRange(sibling.GrokSpecs);
                            }
                        }
                        catch { }
                    }
                }
            }

            if (allStoryTakes.Count == 0 && ep.FlowTakes != null)
                allStoryTakes.AddRange(ep.FlowTakes);
            if (allStoryGrokSpecs.Count == 0 && ep.GrokSpecs != null)
                allStoryGrokSpecs.AddRange(ep.GrokSpecs);

            // Lista única de personagens do episódio/história
            List<string> charFiles = new List<string>();
            if (ep.AllRequiredFlowIngredients != null)
            {
                foreach (string ing in ep.AllRequiredFlowIngredients)
                {
                    string cleanBase = GetBaseCharacterFileName(ing);
                    if (!IsScenarioAssetName(cleanBase) && !charFiles.Contains(cleanBase, StringComparer.OrdinalIgnoreCase))
                        charFiles.Add(cleanBase);
                }
            }
            if (ep.GrokSpecs != null)
            {
                foreach (GrokAssetSpec gs in ep.GrokSpecs)
                {
                    if (!gs.IsScenario && !string.IsNullOrEmpty(gs.TargetFileName))
                    {
                        string cleanBase = GetBaseCharacterFileName(gs.TargetFileName);
                        if (!charFiles.Contains(cleanBase, StringComparer.OrdinalIgnoreCase))
                            charFiles.Add(cleanBase);
                    }
                }
            }

            foreach (string baseCharFile in charFiles)
            {
                GrokAssetSpec charSpec = allStoryGrokSpecs.FirstOrDefault(s =>
                    string.Equals(GetBaseCharacterFileName(s.TargetFileName), baseCharFile, StringComparison.OrdinalIgnoreCase));

                string rawBasePrompt = charSpec != null && !string.IsNullOrEmpty(charSpec.RawPromptLine)
                    ? charSpec.RawPromptLine
                    : GetCharacterBasePromptFromStory(ep, baseCharFile);
                string baseCat = DetectBaseCharacterOutfitCategory(rawBasePrompt, baseCharFile);

                Dictionary<string, List<int>> allAppearingCategories = new Dictionary<string, List<int>>(StringComparer.OrdinalIgnoreCase);

                foreach (FlowTakeSpec take in allStoryTakes)
                {
                    if (take.Ingredients == null) continue;
                    bool appearsInTake = take.Ingredients.Any(ing =>
                        string.Equals(GetBaseCharacterFileName(ing), baseCharFile, StringComparison.OrdinalIgnoreCase));
                    if (!appearsInTake) continue;

                    string reqCat = DetectCharacterRequiredOutfitInTake(take, baseCharFile, rawBasePrompt, baseCat);
                    if (string.IsNullOrEmpty(reqCat) || string.Equals(reqCat, "Padrao", StringComparison.OrdinalIgnoreCase))
                        continue;

                    List<int> takeNums;
                    if (!allAppearingCategories.TryGetValue(reqCat, out takeNums))
                    {
                        takeNums = new List<int>();
                        allAppearingCategories[reqCat] = takeNums;
                    }
                    if (!takeNums.Contains(take.TakeNumber))
                        takeNums.Add(take.TakeNumber);
                }

                // Se o personagem secundário tem baseCat == "Padrao" (ex: O Sogro, A Sogra, O Joalheiro, O Empresário)
                // e aparece em apenas 1 único tipo de ocasião na história inteira, a Roupa Padrão do PASSO 1 já foi desenhada exatamente para essa cena!
                if (string.Equals(baseCat, "Padrao", StringComparison.OrdinalIgnoreCase) && allAppearingCategories.Count <= 1)
                    continue;

                // Ordena nas 4 categorias padronizadas: Trabalho, Lazer, Formal, Simples
                string[] standardOrder = new[] { "Trabalho", "Lazer", "Formal", "Simples" };
                foreach (string catKey in standardOrder)
                {
                    if (string.Equals(catKey, baseCat, StringComparison.OrdinalIgnoreCase))
                        continue;

                    List<int> takeNums;
                    if (!allAppearingCategories.TryGetValue(catKey, out takeNums))
                        continue;

                    string varFile = BuildOutfitVariantFileName(baseCharFile, catKey);
                    string displayLbl = FormatOutfitDisplayLabel(catKey);
                    string desc = GetStandardWardrobePresetDescription(ep, baseCharFile, catKey);
                    string reason = string.Format("Detectado no contexto ({0})",
                        string.Join(", ", takeNums.Take(5).Select(n => string.Format("Take {0:00}", n))));

                    results.Add(new CharacterWardrobeSpec
                    {
                        BaseCharacterFileName = baseCharFile,
                        CharacterDisplayName = CleanAssetStem(baseCharFile),
                        CategoryKey = catKey,
                        DisplayLabel = displayLbl,
                        VariantFileName = varFile,
                        OutfitPromptDescription = desc,
                        ReasonFromText = reason
                    });
                }
            }

            return results;
        }

        public static List<string> GetCharacterOutfitVariantsOnDisk(EpisodeWorkItem ep, string baseCharFileName)
        {
            List<string> results = new List<string>();
            if (ep == null || string.IsNullOrEmpty(baseCharFileName)) return results;

            string cleanBase = GetBaseCharacterFileName(baseCharFileName);
            string baseStem = Path.GetFileNameWithoutExtension(cleanBase);
            string prefix = baseStem + "__Roupa_";

            HashSet<string> seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            List<string> searchDirs = new List<string>();
            if (!string.IsNullOrEmpty(ep.AssetsDir) && Directory.Exists(ep.AssetsDir))
                searchDirs.Add(ep.AssetsDir);

            if (!string.IsNullOrEmpty(ep.StoryRootPath) && Directory.Exists(ep.StoryRootPath))
            {
                foreach (string sub in Directory.GetDirectories(ep.StoryRootPath))
                {
                    string ad = Path.Combine(sub, "assets");
                    if (Directory.Exists(ad) && !searchDirs.Contains(ad, StringComparer.OrdinalIgnoreCase))
                        searchDirs.Add(ad);
                }
            }

            foreach (string dir in searchDirs)
            {
                foreach (string f in Directory.GetFiles(dir))
                {
                    string fn = Path.GetFileName(f);
                    if (!fn.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
                        continue;
                    if (!Regex.IsMatch(Path.GetExtension(f), @"^\.(jpg|jpeg|png)$", RegexOptions.IgnoreCase))
                        continue;
                    if (new FileInfo(f).Length <= 5 * 1024)
                        continue;

                    if (seen.Add(fn))
                    {
                        results.Add(fn);
                        // Garante que a variante exista também na pasta assets\ deste episódio
                        if (!string.IsNullOrEmpty(ep.AssetsDir))
                        {
                            if (!Directory.Exists(ep.AssetsDir)) Directory.CreateDirectory(ep.AssetsDir);
                            string localCopy = Path.Combine(ep.AssetsDir, fn);
                            if (!File.Exists(localCopy))
                            {
                                try { File.Copy(f, localCopy, true); } catch { }
                            }
                        }
                    }
                }
            }

            return results.OrderBy(x => x).ToList();
        }

        public static string ResolveAutomaticOutfitForTake(
            EpisodeWorkItem ep,
            FlowTakeSpec take,
            string baseCharFileName,
            List<string> availableVariants)
        {
            if (take == null || string.IsNullOrEmpty(baseCharFileName))
                return baseCharFileName;

            string cleanBase = GetBaseCharacterFileName(baseCharFileName);
            string rawBasePrompt = GetCharacterBasePromptFromStory(ep, cleanBase);

            string baseCat = DetectBaseCharacterOutfitCategory(rawBasePrompt, cleanBase);
            string reqCat = DetectCharacterRequiredOutfitInTake(take, cleanBase, rawBasePrompt, baseCat);

            // Se o texto pede a própria categoria da Roupa Padrão original, usa a Roupa Padrão
            if (string.Equals(reqCat, "Padrao", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(reqCat, baseCat, StringComparison.OrdinalIgnoreCase))
            {
                return cleanBase;
            }

            // 1. Se a variante já existir em disco, retorna o nome exato do arquivo em disco
            if (availableVariants != null)
            {
                foreach (string varFile in availableVariants)
                {
                    string varCat = NormalizeStandardWardrobeCategory(ExtractOutfitOccasionLabel(varFile));
                    if (string.Equals(varCat, reqCat, StringComparison.OrdinalIgnoreCase))
                        return varFile;
                }
            }

            // 2. Se o personagem tem baseCat == "Padrao" (personagem secundário como O Sogro, A Sogra, O Joalheiro, O Empresário)
            // verifica se ele realmente muda de ocasião na história antes de exigir uma roupa nova
            if (string.Equals(baseCat, "Padrao", StringComparison.OrdinalIgnoreCase) && ep != null)
            {
                List<CharacterWardrobeSpec> storyOutfits = DetectRequiredCharacterOutfitsFromText(ep);
                bool needsOutfitInStory = storyOutfits.Any(o =>
                    string.Equals(o.BaseCharacterFileName, cleanBase, StringComparison.OrdinalIgnoreCase) &&
                    string.Equals(o.CategoryKey, reqCat, StringComparison.OrdinalIgnoreCase));
                if (!needsOutfitInStory)
                    return cleanBase;
            }

            // 3. Retorna o nome padronizado da roupa exigida pelo texto (para que seja gerada automaticamente antes do vídeo caso ainda não exista em disco)
            return BuildOutfitVariantFileName(cleanBase, reqCat);
        }

        public static string FindExistingBaseCharacterPathForVariantSpec(EpisodeWorkItem ep, GrokAssetSpec spec)
        {
            if (ep == null || spec == null || spec.IsScenario) return "";
            string specStem = NormalizeForCompare(CleanAssetStem(spec.TargetFileName));
            if (string.IsNullOrEmpty(specStem))
                specStem = NormalizeForCompare(spec.DisplayTitle ?? "");
            if (string.IsNullOrEmpty(specStem)) return "";

            List<string> searchDirs = new List<string>();
            if (!string.IsNullOrEmpty(ep.AssetsDir) && Directory.Exists(ep.AssetsDir))
                searchDirs.Add(ep.AssetsDir);
            if (!string.IsNullOrEmpty(ep.StoryRootPath) && Directory.Exists(ep.StoryRootPath))
            {
                foreach (string sub in Directory.GetDirectories(ep.StoryRootPath).OrderBy(d => d))
                {
                    string ad = Path.Combine(sub, "assets");
                    if (Directory.Exists(ad) && !searchDirs.Contains(ad, StringComparer.OrdinalIgnoreCase))
                        searchDirs.Add(ad);
                }
            }

            string bestPath = "";
            int bestLen = 0;

            foreach (string dir in searchDirs)
            {
                foreach (string f in Directory.GetFiles(dir))
                {
                    string fn = Path.GetFileName(f);
                    if (string.Equals(fn, spec.TargetFileName, StringComparison.OrdinalIgnoreCase))
                        continue;
                    if (IsScenarioAssetName(fn))
                        continue;
                    if (!Regex.IsMatch(Path.GetExtension(f), @"^\.(jpg|jpeg|png)$", RegexOptions.IgnoreCase))
                        continue;
                    if (new FileInfo(f).Length <= 10 * 1024)
                        continue;

                    string candStem = NormalizeForCompare(CleanAssetStem(fn));
                    if (string.IsNullOrEmpty(candStem) || candStem.Length < 4)
                        continue;

                    // Ex: "a salgadeira arrumada" começa com "a salgadeira", ou "o engenheiro estudante" começa com "o engenheiro"
                    if (specStem.StartsWith(candStem + " ", StringComparison.OrdinalIgnoreCase) && candStem.Length > bestLen)
                    {
                        bestLen = candStem.Length;
                        bestPath = f;
                    }
                }
            }

            return bestPath;
        }

        public static GrokAssetSpec FindBaseCharacterSpecInEpisode(EpisodeWorkItem ep, GrokAssetSpec spec)
        {
            if (ep == null || spec == null || spec.IsScenario || ep.GrokSpecs == null) return null;
            string specStem = NormalizeForCompare(CleanAssetStem(spec.TargetFileName));
            if (string.IsNullOrEmpty(specStem))
                specStem = NormalizeForCompare(spec.DisplayTitle ?? "");
            if (string.IsNullOrEmpty(specStem)) return null;

            GrokAssetSpec bestSpec = null;
            int bestLen = 0;

            foreach (GrokAssetSpec cand in ep.GrokSpecs)
            {
                if (cand == null || cand.IsScenario) continue;
                if (string.Equals(cand.TargetFileName, spec.TargetFileName, StringComparison.OrdinalIgnoreCase))
                    continue;

                string candStem = NormalizeForCompare(CleanAssetStem(cand.TargetFileName));
                if (string.IsNullOrEmpty(candStem))
                    candStem = NormalizeForCompare(cand.DisplayTitle ?? "");
                if (string.IsNullOrEmpty(candStem) || candStem.Length < 4)
                    continue;

                if (specStem.StartsWith(candStem + " ", StringComparison.OrdinalIgnoreCase) && candStem.Length > bestLen)
                {
                    bestLen = candStem.Length;
                    bestSpec = cand;
                }
            }

            return bestSpec;
        }

        public static string ResolveEffectiveIngredientForTake(EpisodeWorkItem ep, FlowTakeSpec take, string baseIngredient)
        {
            if (ep == null || take == null || string.IsNullOrEmpty(baseIngredient))
                return baseIngredient;

            if (IsScenarioAssetName(baseIngredient))
                return baseIngredient;

            // As roupas de cada ocasião são definidas diretamente no roteiro / pré-definição (PASSO 1 e PASSO 3).
            // Portanto, o programa usa diretamente o arquivo .jpg indicado no Take (ou eventual escolha manual no painel de Regerar Takes).
            if (take.CharacterOutfitOverrides != null)
            {
                string cleanBase = GetBaseCharacterFileName(baseIngredient);
                string manualChoice;
                if (take.CharacterOutfitOverrides.TryGetValue(cleanBase, out manualChoice) && !string.IsNullOrEmpty(manualChoice))
                {
                    if (!string.Equals(manualChoice, "BASE", StringComparison.OrdinalIgnoreCase) &&
                        !string.Equals(manualChoice, "AUTO", StringComparison.OrdinalIgnoreCase))
                    {
                        return manualChoice;
                    }
                }
            }

            return baseIngredient;
        }

        public static FlowTakeSpec GetEffectiveTakeSpec(EpisodeWorkItem ep, FlowTakeSpec take)
        {
            if (take == null) return null;
            FlowTakeSpec eff = take.Clone();
            if (ep == null || eff.Ingredients == null || eff.Ingredients.Count == 0)
                return eff;

            for (int i = 0; i < eff.Ingredients.Count; i++)
            {
                string origIng = eff.Ingredients[i];
                if (IsScenarioAssetName(origIng)) continue;

                string chosenIng = ResolveEffectiveIngredientForTake(ep, eff, origIng);
                if (!string.IsNullOrEmpty(chosenIng) && !string.Equals(origIng, chosenIng, StringComparison.OrdinalIgnoreCase))
                {
                    eff.Ingredients[i] = chosenIng;
                    if (!string.IsNullOrEmpty(eff.RawHeader))
                    {
                        eff.RawHeader = Regex.Replace(eff.RawHeader, Regex.Escape(origIng), chosenIng, RegexOptions.IgnoreCase);
                    }
                    if (!string.IsNullOrEmpty(eff.RawPromptBody))
                    {
                        eff.RawPromptBody = Regex.Replace(eff.RawPromptBody, Regex.Escape(origIng), chosenIng, RegexOptions.IgnoreCase);
                    }
                }
            }

            return eff;
        }

        public static List<FlowTakeSpec> GetEffectiveTakeSpecsForEpisode(EpisodeWorkItem ep)
        {
            List<FlowTakeSpec> list = new List<FlowTakeSpec>();
            if (ep == null || ep.FlowTakes == null) return list;
            for (int i = 0; i < ep.FlowTakes.Count; i++)
            {
                list.Add(GetEffectiveTakeSpec(ep, ep.FlowTakes[i]));
            }
            return list;
        }

        public static string GetCustomTakesConfigPath(EpisodeWorkItem ep)
        {
            if (ep == null || string.IsNullOrEmpty(ep.EpisodePath)) return "";
            return Path.Combine(ep.EpisodePath, "custom_takes_config.json");
        }

        public static void SaveEpisodeCustomTakesConfig(EpisodeWorkItem ep)
        {
            if (ep == null || string.IsNullOrEmpty(ep.EpisodePath) || ep.FlowTakes == null) return;
            try
            {
                Dictionary<string, object> root = new Dictionary<string, object>();
                List<Dictionary<string, object>> takesList = new List<Dictionary<string, object>>();

                foreach (FlowTakeSpec t in ep.FlowTakes)
                {
                    Dictionary<string, object> td = new Dictionary<string, object>();
                    td["TakeNumber"] = t.TakeNumber;
                    td["PreferredEngine"] = t.PreferredEngine ?? "Auto";
                    td["RawPromptBody"] = t.RawPromptBody ?? "";
                    td["CharacterOutfitOverrides"] = t.CharacterOutfitOverrides ?? new Dictionary<string, string>();
                    takesList.Add(td);
                }

                root["Takes"] = takesList;
                JavaScriptSerializer ser = new JavaScriptSerializer();
                ser.MaxJsonLength = int.MaxValue;
                string json = ser.Serialize(root);
                File.WriteAllText(GetCustomTakesConfigPath(ep), json, new UTF8Encoding(false));
            }
            catch { }
        }

        public static void LoadEpisodeCustomTakesConfig(EpisodeWorkItem ep)
        {
            if (ep == null || string.IsNullOrEmpty(ep.EpisodePath) || ep.FlowTakes == null) return;
            try
            {
                string path = GetCustomTakesConfigPath(ep);
                if (!File.Exists(path)) return;

                string json = File.ReadAllText(path, Encoding.UTF8);
                JavaScriptSerializer ser = new JavaScriptSerializer();
                ser.MaxJsonLength = int.MaxValue;
                Dictionary<string, object> root = ser.Deserialize<Dictionary<string, object>>(json);
                if (root == null || !root.ContainsKey("Takes")) return;

                IEnumerable takesArr = root["Takes"] as IEnumerable;
                if (takesArr == null) return;

                foreach (object item in takesArr)
                {
                    Dictionary<string, object> td = item as Dictionary<string, object>;
                    if (td == null || !td.ContainsKey("TakeNumber")) continue;
                    int tNum = Convert.ToInt32(td["TakeNumber"]);

                    FlowTakeSpec target = ep.FlowTakes.FirstOrDefault(x => x.TakeNumber == tNum);
                    if (target == null) continue;

                    if (td.ContainsKey("PreferredEngine"))
                        target.PreferredEngine = Convert.ToString(td["PreferredEngine"] ?? "Auto");

                    if (td.ContainsKey("RawPromptBody"))
                    {
                        string customBody = Convert.ToString(td["RawPromptBody"] ?? "").Trim();
                        if (!string.IsNullOrEmpty(customBody))
                            target.RawPromptBody = customBody;
                    }

                    if (td.ContainsKey("CharacterOutfitOverrides") && td["CharacterOutfitOverrides"] is Dictionary<string, object>)
                    {
                        Dictionary<string, object> ov = (Dictionary<string, object>)td["CharacterOutfitOverrides"];
                        foreach (KeyValuePair<string, object> kv in ov)
                        {
                            string val = Convert.ToString(kv.Value ?? "").Trim();
                            if (!string.IsNullOrEmpty(kv.Key) && !string.IsNullOrEmpty(val))
                                target.CharacterOutfitOverrides[kv.Key] = val;
                        }
                    }
                }
            }
            catch { }
        }
    }
}
