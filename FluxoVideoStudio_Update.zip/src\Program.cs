using System;
using System.IO;
using System.Windows;

namespace FluxoVideoStudio
{
    public static class Program
    {
        [STAThread]
        public static void Main(string[] args)
        {
            string logPath = Path.Combine(PipelineConfig.GetAppRootDir(), "studio_runtime.log");
            try
            {
                File.WriteAllText(logPath, string.Format("[{0:yyyy-MM-dd HH:mm:ss}] Iniciando FluxoVideoStudio...\r\n", DateTime.Now));

                string startupEpisodePath = "";
                bool autoRun = false;

                if (args != null)
                {
                    for (int i = 0; i < args.Length; i++)
                    {
                        string a = args[i] ?? "";
                        if (string.Equals(a, "--episode", StringComparison.OrdinalIgnoreCase) && i + 1 < args.Length)
                        {
                            startupEpisodePath = args[++i];
                        }
                        else if (string.Equals(a, "--auto-run", StringComparison.OrdinalIgnoreCase))
                        {
                            autoRun = true;
                        }
                    }
                }

                Application app = Application.Current ?? new Application();
                app.ShutdownMode = ShutdownMode.OnMainWindowClose;
                app.DispatcherUnhandledException += (s, e) =>
                {
                    File.AppendAllText(logPath, "[DispatcherUnhandledException] " + e.Exception + "\r\n");
                    MessageBox.Show(e.Exception.ToString(), "Erro Inesperado", MessageBoxButton.OK, MessageBoxImage.Error);
                    e.Handled = true;
                };

                MainWindow win = new MainWindow(startupEpisodePath, autoRun);
                win.Loaded += (s, e) =>
                {
                    File.AppendAllText(logPath, string.Format("[{0:HH:mm:ss}] MainWindow carregada com sucesso! Título: {1}\r\n", DateTime.Now, win.Title));
                };
                app.Run(win);
            }
            catch (Exception ex)
            {
                try { File.AppendAllText(logPath, "[Fatal] " + ex + "\r\n"); } catch { }
                MessageBox.Show(ex.ToString(), "Erro Fatal ao Iniciar FluxoVideoStudio", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
