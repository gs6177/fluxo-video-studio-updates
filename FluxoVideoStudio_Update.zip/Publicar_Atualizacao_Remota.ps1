param(
    [string]$Token = "",
    [string]$Repo = ""
)

$ErrorActionPreference = "Stop"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
Add-Type -AssemblyName System.Web.Extensions

$studioDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$settingsFile = Join-Path $studioDir "studio_user_settings.json"
$ser = New-Object System.Web.Script.Serialization.JavaScriptSerializer
$ser.MaxJsonLength = [int]::MaxValue

$settings = @{}
if (Test-Path $settingsFile) {
    try {
        $settings = $ser.DeserializeObject([System.IO.File]::ReadAllText($settingsFile, [System.Text.Encoding]::UTF8))
    } catch {}
}

if ([string]::IsNullOrWhiteSpace($Token) -and $settings.ContainsKey("RemoteUpdateToken")) {
    $Token = ("" + $settings["RemoteUpdateToken"]).Trim()
}
if ([string]::IsNullOrWhiteSpace($Repo) -and $settings.ContainsKey("RemoteUpdateRepo")) {
    $Repo = ("" + $settings["RemoteUpdateRepo"]).Trim()
}

if ([string]::IsNullOrWhiteSpace($Token)) {
    throw "Token do GitHub não informado. Configure o Token na janela 'Atualização Remota via GitHub'."
}

$headers = @{
    "Authorization" = "token $Token"
    "Accept"        = "application/vnd.github.v3+json"
    "User-Agent"    = "FluxoVideoStudio-Updater"
}

Write-Host "[GitHub] Autenticando conta no GitHub..."
$userResp = Invoke-RestMethod -Uri "https://api.github.com/user" -Headers $headers -Method Get
$ghUser = $userResp.login
if ([string]::IsNullOrWhiteSpace($ghUser)) {
    throw "Não foi possível obter o usuário do GitHub com o Token informado."
}

$repoName = "fluxo-video-studio-updates"
if (-not [string]::IsNullOrWhiteSpace($Repo)) {
    $cleanRepo = $Repo -replace "^https?://github\.com/", "" -replace "\.git$", ""
    $parts = $cleanRepo.Split('/', [System.StringSplitOptions]::RemoveEmptyEntries)
    if ($parts.Length -ge 2) {
        $ghUser = $parts[0]
        $repoName = $parts[1]
    } elseif ($parts.Length -eq 1) {
        $repoName = $parts[0]
    }
}
$fullRepo = "$ghUser/$repoName"

# Verificar se o repositório já existe; se não existir, criar automaticamente
$repoExists = $false
try {
    $rCheck = Invoke-RestMethod -Uri "https://api.github.com/repos/$fullRepo" -Headers $headers -Method Get
    if ($rCheck -ne $null) { $repoExists = $true }
} catch {
    $repoExists = $false
}

if (-not $repoExists) {
    Write-Host "[GitHub] Criando repositório '$fullRepo' automaticamente..."
    $createBody = $ser.Serialize(@{
        name        = $repoName
        description = "Canal oficial de atualizacao automatica do FluxoVideoStudio + Skills"
        private     = $false
        auto_init   = $true
    })
    Invoke-RestMethod -Uri "https://api.github.com/user/repos" -Headers $headers -Method Post -Body ([System.Text.Encoding]::UTF8.GetBytes($createBody)) -ContentType "application/json; charset=utf-8" | Out-Null
    Start-Sleep -Seconds 2
}

# Salvar RemoteUpdateRepo em remote_update_config.json e studio_user_settings.json
$utf8NoBom = New-Object System.Text.UTF8Encoding($false)
$remoteCfgPath = Join-Path $studioDir "remote_update_config.json"
$versionId = (Get-Date).ToString("yyyy.MM.dd.HHmmss")
$remoteCfgJson = $ser.Serialize(@{
    RemoteUpdateRepo = $fullRepo
    Version          = $versionId
    UpdatedAt        = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
})
[System.IO.File]::WriteAllText($remoteCfgPath, $remoteCfgJson, $utf8NoBom)

if ($settings -ne $null) {
    $settings["RemoteUpdateRepo"] = $fullRepo
    $settings["RemoteUpdateToken"] = $Token
    [System.IO.File]::WriteAllText($settingsFile, $ser.Serialize($settings), $utf8NoBom)
}

# Empacotar FluxoVideoStudio + 6 Skills em FluxoVideoStudio_Update.zip
Write-Host "[GitHub] Empacotando código-fonte, executável e as 6 Skills..."
$stageDir = Join-Path $env:TEMP "fvs_gh_publish_stage"
if (Test-Path $stageDir) { Remove-Item $stageDir -Recurse -Force }
$pkgRoot = Join-Path $stageDir "FluxoVideoStudio"
New-Item -ItemType Directory -Path $pkgRoot -Force | Out-Null

foreach ($fn in @("FluxoVideoStudio.exe", "Iniciar_FluxoVideoStudio.bat", "Iniciar_Sem_Bloqueio.ps1", "INSTALAR_TUDO_1_CLIQUE.bat", "Instalar_Tudo_Outro_PC.ps1", "Publicar_Atualizacao_Remota.ps1", "Baixar_Atualizacao_Remota.ps1", "build.ps1", "backup.ps1", "README.md", "AGENTS.md", "remote_update_config.json")) {
    $p = Join-Path $studioDir $fn
    if (Test-Path $p) { Copy-Item $p "$pkgRoot\" -Force }
}
if (Test-Path (Join-Path $studioDir "src")) { Copy-Item (Join-Path $studioDir "src") "$pkgRoot\src" -Recurse -Force }
if (Test-Path (Join-Path $studioDir "scripts")) { Copy-Item (Join-Path $studioDir "scripts") "$pkgRoot\scripts" -Recurse -Force }

$skillsSrc = Join-Path $env:USERPROFILE ".gemini\config\skills"
$pkgSkills = Join-Path $pkgRoot "Skills"
New-Item -ItemType Directory -Path $pkgSkills -Force | Out-Null
foreach ($sk in @("fluxo-video-studio", "fluxo-video-ia", "gem-novela", "gem-terror", "gem 3D Pixar-Disney", "Camaleão part 1,2 e 3")) {
    $sPath = Join-Path $skillsSrc $sk
    if (Test-Path $sPath) {
        Copy-Item -Path $sPath -Destination (Join-Path $pkgSkills $sk) -Recurse -Force
    }
}

$updateZipPath = Join-Path $env:TEMP "FluxoVideoStudio_Update.zip"
if (Test-Path $updateZipPath) { Remove-Item $updateZipPath -Force }
Compress-Archive -Path "$pkgRoot\*" -DestinationPath $updateZipPath -Force
Remove-Item $stageDir -Recurse -Force

function Publish-GitHubFile([string]$repoPath, [byte[]]$fileBytes, [string]$commitMsg) {
    $uri = "https://api.github.com/repos/$fullRepo/contents/$repoPath"
    $sha = ""
    try {
        $existing = Invoke-RestMethod -Uri $uri -Headers $headers -Method Get
        if ($existing -ne $null -and $existing.sha) { $sha = $existing.sha }
    } catch {}

    $payload = @{
        message = $commitMsg
        content = [Convert]::ToBase64String($fileBytes)
    }
    if (-not [string]::IsNullOrEmpty($sha)) {
        $payload["sha"] = $sha
    }
    $bodyJson = $ser.Serialize($payload)
    Invoke-RestMethod -Uri $uri -Headers $headers -Method Put -Body ([System.Text.Encoding]::UTF8.GetBytes($bodyJson)) -ContentType "application/json; charset=utf-8" | Out-Null
}

Write-Host "[GitHub] Enviando FluxoVideoStudio_Update.zip para https://github.com/$fullRepo ..."
$zipBytes = [System.IO.File]::ReadAllBytes($updateZipPath)
Publish-GitHubFile "FluxoVideoStudio_Update.zip" $zipBytes "Update FluxoVideoStudio + Skills ($versionId)"

$verBytes = [System.Text.Encoding]::UTF8.GetBytes($remoteCfgJson)
Publish-GitHubFile "version.json" $verBytes "Version $versionId"

Write-Host "PUBLICADO_OK|$fullRepo|$versionId"
