using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Web.Script.Serialization;

namespace FluxoVideoStudio
{
    public static partial class EpisodeParser
    {
        public static string GetBaseCharacterFileName(string fileName)
        {
            if (string.IsNullOrEmpty(fileName)) return "";
            string fn = Path.GetFileName(fileName);
            int idx = fn.IndexOf("__Roupa_", StringComparison.OrdinalIgnoreCase);
            if (idx > 0)
            {
                string ext = Path.GetExtension(fn);
                return fn.Substring(0, idx) + ext;
            }
            return fn;
        }

        public static string ExtractOutfitOccasionLabel(string variantFileName)
        {
            if (string.IsNullOrEmpty(variantFileName)) return "";
            string stem = Path.GetFileNameWithoutExtension(variantFileName);
            int idx = stem.IndexOf("__Roupa_", StringComparison.OrdinalIgnoreCase);
            if (idx < 0) return "";
            return stem.Substring(idx + "__Roupa_".Length).Replace("_", " ").Trim();
        }

        public static string NormalizeStandardWardrobeCategory(string categoryOrOccasion)
        {
            string norm = NormalizeForCompare(categoryOrOccasion ?? "");
            if (string.IsNullOrEmpty(norm)) return "Simples";

            if (Regex.IsMatch(norm, @"\b(trabalho|obra|engenheiro|construcao|escritorio|empresa|uniforme|avental|servico|profissional)\b"))
                return "Trabalho";
            if (Regex.IsMatch(norm, @"\b(lazer|passeio|parque|praia|encontro|fim de semana|esporte|descanso)\b"))
                return "Lazer";
            if (Regex.IsMatch(norm, @"\b(formal|formatura|beca|baile|festa|gala|casamento|smoking|terno|luxo|chique|elegante)\b"))
                return "Formal";
            if (Regex.IsMatch(norm, @"\b(simples|casual|dia a dia|cotidiano|casa|caseira|humilde|rotina|padrao)\b"))
                return "Simples";

            return Slugify(categoryOrOccasion);
        }

        public static string FormatOutfitDisplayLabel(string variantFileOrOccasion)
        {
            if (string.IsNullOrEmpty(variantFileOrOccasion)) return "Roupa Padrão";
            string rawOcc = variantFileOrOccasion.IndexOf("__Roupa_", StringComparison.OrdinalIgnoreCase) >= 0
                ? ExtractOutfitOccasionLabel(variantFileOrOccasion)
                : variantFileOrOccasion;

            string norm = NormalizeForCompare(rawOcc);
            if (norm == "trabalho") return "Roupa de Trabalho";
            if (norm == "lazer") return "Roupa de Lazer";
            if (norm == "formal") return "Roupa Formal";
            if (norm == "simples") return "Roupa Simples";

            if (rawOcc.StartsWith("Roupa ", StringComparison.OrdinalIgnoreCase))
                return rawOcc;
            return "Roupa " + rawOcc;
        }

        public static string BuildOutfitVariantFileName(string baseCharFileName, string occasionLabel)
        {
            string cleanBase = GetBaseCharacterFileName(baseCharFileName);
            string baseStem = Path.GetFileNameWithoutExtension(cleanBase);
            string stdCat = NormalizeStandardWardrobeCategory(occasionLabel);
            string occSlug = Slugify(stdCat);
            return string.Format("{0}__Roupa_{1}.jpg", baseStem, occSlug);
        }

        public static string DetectBaseCharacterOutfitCategory(string rawPromptLine, string charFileName)
        {
            string norm = NormalizeForCompare((rawPromptLine ?? "") + " " + (charFileName ?? ""));
            if (string.IsNullOrEmpty(norm)) return "Padrao";

            // 1. Roupa Formal / Formatura / Gala / Festa / Alfaiataria de Luxo
            if (Regex.IsMatch(norm, @"\b(formatura|beca|capelo|baile|smoking|vestido de festa|vestido de gala|vestido longo de luxo|noiva|noivo|terno de gala|casamento|alfaiataria branco de luxo)\b"))
                return "Formal";

            // 2. Roupa de Trabalho / Obra / Uniforme / Avental de Serviço
            if (Regex.IsMatch(norm, @"\b(avental|capacete|colete refletivo|botina de obra|macacao de trabalho|uniforme|jaleco|farda)\b"))
                return "Trabalho";

            // 3. Roupa de Lazer / Passeio
            if (Regex.IsMatch(norm, @"\b(roupa de lazer|roupa de passeio|bermuda de passeio|roupa de praia|roupa esportiva)\b"))
                return "Lazer";

            // 4. Roupa Simples / Caseira / Humilde
            if (Regex.IsMatch(norm, @"\b(roupa simples|vestido simples|camiseta surrada|chinelo|humilde|roupa caseira|descalco|remendad)\b"))
                return "Simples";

            return "Padrao";
        }

        public static string GetCharacterBasePromptFromStory(EpisodeWorkItem ep, string baseCharFileName)
        {
            if (ep == null || string.IsNullOrEmpty(baseCharFileName))
                return "";

            string cleanBase = GetBaseCharacterFileName(baseCharFileName);
            string charTitle = CleanAssetStem(cleanBase);

            if (ep.GrokSpecs != null)
            {
                GrokAssetSpec spec = ep.GrokSpecs.FirstOrDefault(s =>
                    string.Equals(GetBaseCharacterFileName(s.TargetFileName), cleanBase, StringComparison.OrdinalIgnoreCase) ||
                    (!string.IsNullOrEmpty(charTitle) && string.Equals(s.DisplayTitle, charTitle, StringComparison.OrdinalIgnoreCase)));
                if (spec != null && !string.IsNullOrWhiteSpace(spec.RawPromptLine))
                    return spec.RawPromptLine;
            }

            if (!string.IsNullOrEmpty(ep.StoryRootPath) && Directory.Exists(ep.StoryRootPath))
            {
                foreach (string sub in Directory.GetDirectories(ep.StoryRootPath).OrderBy(d => d))
                {
                    if (!Regex.IsMatch(Path.GetFileName(sub), @"^EP\.?\s*\d+$", RegexOptions.IgnoreCase))
                        continue;

                    string[] txts = Directory.GetFiles(sub, "*.txt", SearchOption.TopDirectoryOnly);
                    string grokPath = FindBestFile(txts, new[] { "prompt_grok_passo1_e_2.txt", "prompt_grok", "comandos_gemini_completos" });
                    if (string.IsNullOrEmpty(grokPath) || !File.Exists(grokPath))
                        continue;

                    string grokText = ReadUtf8(grokPath);
                    if (string.IsNullOrEmpty(grokText))
                        continue;

                    foreach (string rawLine in grokText.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries))
                    {
                        string line = rawLine.Trim();
                        if (!line.StartsWith("- Personagem", StringComparison.OrdinalIgnoreCase) &&
                            line.IndexOf("Personagem", StringComparison.OrdinalIgnoreCase) < 0)
                            continue;

                        if (!string.IsNullOrEmpty(charTitle) &&
                            NormalizeForCompare(line).IndexOf(NormalizeForCompare(charTitle), StringComparison.OrdinalIgnoreCase) >= 0)
                        {
                            return line;
                        }
                    }
                }
            }

            return "";
        }

        public static string GetFullStoryNarrativeContext(EpisodeWorkItem ep)
        {
            if (ep == null) return "";
            StringBuilder sb = new StringBuilder();
            if (!string.IsNullOrEmpty(ep.RoteiroText)) sb.AppendLine(ep.RoteiroText);
            if (!string.IsNullOrEmpty(ep.FlowPromptText)) sb.AppendLine(ep.FlowPromptText);

            if (!string.IsNullOrEmpty(ep.StoryRootPath) && Directory.Exists(ep.StoryRootPath))
            {
                foreach (string sub in Directory.GetDirectories(ep.StoryRootPath).OrderBy(d => d))
                {
                    if (string.Equals(sub, ep.EpisodePath, StringComparison.OrdinalIgnoreCase))
                        continue;
                    if (!Regex.IsMatch(Path.GetFileName(sub), @"^EP\.?\s*\d+$", RegexOptions.IgnoreCase))
                        continue;

                    try
                    {
                        string[] txts = Directory.GetFiles(sub, "*.txt", SearchOption.TopDirectoryOnly);
                        string rot = FindBestFile(txts, new[] { "roteiro.txt", "roteiro_camaleao", "roteiro_parte", "roteiro" },
                            excludeSubstrings: new[] { "decupado", "gem_" });
                        if (!string.IsNullOrEmpty(rot) && File.Exists(rot))
                            sb.AppendLine(ReadUtf8(rot));
                        string flw = FindBestFile(txts, new[] { "prompt_flow_passo3.txt", "prompt_flow", "passo3_takes" });
                        if (!string.IsNullOrEmpty(flw) && File.Exists(flw))
                            sb.AppendLine(ReadUtf8(flw));
                    }
                    catch { }
                }
            }

            return NormalizeForCompare(sb.ToString());
        }

        public static string ExtractCharacterSpecificClauseInTake(FlowTakeSpec take, string baseCharFileName)
        {
            if (take == null || string.IsNullOrEmpty(take.RawPromptBody) || string.IsNullOrEmpty(baseCharFileName))
                return "";

            string cleanBase = GetBaseCharacterFileName(baseCharFileName);
            string body = take.RawPromptBody;
            int idx = body.IndexOf(cleanBase, StringComparison.OrdinalIgnoreCase);
            if (idx < 0)
            {
                string title = CleanAssetStem(cleanBase);
                if (!string.IsNullOrEmpty(title))
                    idx = body.IndexOf(title, StringComparison.OrdinalIgnoreCase);
            }
            if (idx < 0) return "";

            // Começa exatamente no nome/arquivo do personagem (pois a descrição da roupa e ação dele vem SEMPRE após o nome, evitando capturar o nome do Cenário antes dele)
            int start = idx;
            int afterRef = idx + cleanBase.Length;
            int maxLen = Math.Min(body.Length - start, 200);
            string sub = body.Substring(start, maxLen);

            // Corta imediatamente se começar a descrever outro personagem ou outro arquivo .jpg de personagem
            int offsetAfterRef = Math.Min(sub.Length, Math.Max(10, afterRef - start));
            string tail = sub.Substring(offsetAfterRef);
            Match nextChar = Regex.Match(
                tail,
                @"(\(\d{2}_Personagem_|[\.,;]\s*(?:e\s+|enquanto\s+|ao\s+lado[^,]*,\s*|a\s+frente[^,]*,\s*|atras[^,]*,\s*|diante[^,]*,\s*)?(?:o\s+homem|a\s+mulher|o\s+jovem|a\s+jovem|o\s+idoso|a\s+idosa)\b|,\s*(?:e\s+|enquanto\s+)?(?:o\s+homem|a\s+mulher|o\s+jovem|a\s+jovem|o\s+idoso|a\s+idosa)\b|\benquanto\s+(?:ao\s+fundo\s+|ao\s+lado\s+)?(?:o\s+homem|a\s+mulher|o\s+jovem|a\s+jovem|o\s+idoso|a\s+idosa)\b)",
                RegexOptions.IgnoreCase);
            if (nextChar.Success)
            {
                sub = sub.Substring(0, offsetAfterRef + nextChar.Index);
            }
            return NormalizeForCompare(sub);
        }

        public static string DetectCharacterRequiredOutfitInTake(
            FlowTakeSpec take,
            string baseCharFileName,
            string rawBasePrompt,
            string baseCategory)
        {
            if (take == null) return "Padrao";

            string normBase = NormalizeForCompare((rawBasePrompt ?? "") + " " + (baseCharFileName ?? ""));
            bool baseHasApron = Regex.IsMatch(normBase, @"\b(avental)\b");
            bool baseHasBeca = Regex.IsMatch(normBase, @"\b(beca|capelo|canudo.*diploma)\b");

            // 1. Analisa primeiro a descrição específica daquele personagem dentro do Take
            string charClause = ExtractCharacterSpecificClauseInTake(take, baseCharFileName);
            if (!string.IsNullOrEmpty(charClause))
            {
                // Se o Take menciona explicitamente "sem o avental", "vestido simples", "roupa simples" ou "roupa velha" para este personagem
                if (Regex.IsMatch(charClause, @"\b(sem o avental|sem avental|vestido simples|roupa simples|roupa velha|camiseta simples|chinelo)\b"))
                    return "Simples";

                if (Regex.IsMatch(charClause, @"\b(com seu avental|com avental|avental creme|de avental|sovando massa|preparando salgados|capacete|uniforme|jaleco)\b"))
                    return "Trabalho";

                if (!baseHasApron && Regex.IsMatch(charClause, @"\b(beca|capelo|terno de gala|smoking|vestido de festa|vestido de gala|alfaiataria branco de luxo)\b"))
                    return "Formal";

                if (Regex.IsMatch(charClause, @"\b(camisa social|terno executivo|blazer|pasta executiva|roupa de escritorio)\b"))
                    return "Trabalho";
            }

            string scenarioNorm = NormalizeForCompare(take.ScenarioName ?? "");
            string contextText = NormalizeForCompare((take.ScenarioName ?? "") + " " + (take.RawHeader ?? "") + " " + (take.RawPromptBody ?? ""));

            // 2. Regras de Contexto da Cena específicas para personagens cuja Roupa Padrão tem Avental (ex: A Salgadeira)
            if (baseHasApron)
            {
                // Na cozinha ou entregando encomendas de salgados na chuva, usa sua Roupa Padrão de trabalho (com avental)
                if (Regex.IsMatch(scenarioNorm, @"\b(cozinha|lanchonete)\b") ||
                    Regex.IsMatch(contextText, @"\b(sovando massa|preparando salgados|caixas de salgados|forno|fogao)\b"))
                {
                    return "Trabalho";
                }
                // Quando sai para ir à formatura do marido, ao escritório da construtora ou à joalheria na cidade,
                // tira o avental e vai com sua roupa simples, porém limpa e arrumadinha ("Simples")!
                return "Simples";
            }

            // 3. Regras de Contexto da Cena específicas para personagens cuja Roupa Padrão é Beca de Formatura (ex: O Engenheiro)
            if (baseHasBeca)
            {
                bool isGradScene = Regex.IsMatch(scenarioNorm, @"\b(formatura|baile)\b") ||
                                   Regex.IsMatch(contextText, @"\b(salao de baile|colacao de grau|baile de formatura)\b");
                if (isGradScene)
                    return "Formal";

                // Se já está trabalhando na construtora/escritório ou chegando do trabalho/jantar com a diretoria / pedindo divórcio (EP.2)
                if (Regex.IsMatch(scenarioNorm, @"\b(escritorio|construtora|obra|empresa)\b") ||
                    Regex.IsMatch(contextText, @"\b(construtora|escritorio|diretoria|reuniao de negocios|mala de viagem|quero o divorcio)\b"))
                {
                    return "Trabalho";
                }

                // Em casa estudando cadernos e boletos da faculdade antes de se formar -> Roupa Simples de estudante em casa
                return "Simples";
            }

            // 4. Caso geral: analisa o contexto do Cenário/Cena
            return DetectTakeRequiredOutfitCategory(take, baseCategory);
        }

        public static string DetectTakeRequiredOutfitCategory(FlowTakeSpec take, string baseCategory)
        {
            if (take == null) return "Padrao";
            string contextText = NormalizeForCompare((take.ScenarioName ?? "") + " " + (take.RawHeader ?? "") + " " + (take.RawPromptBody ?? ""));
            if (string.IsNullOrEmpty(contextText)) return "Padrao";

            string scenarioNorm = NormalizeForCompare(take.ScenarioName ?? "");

            // 1. Verifica se o Cenário principal é Formal (Formatura / Baile / Casamento / Festa de Gala)
            bool isFormalScene = Regex.IsMatch(scenarioNorm, @"\b(formatura|baile|casamento|gala|festa|salao nobre|recepcao de luxo)\b") ||
                                 (!Regex.IsMatch(scenarioNorm, @"\b(cozinha|casinha|rua|joalheria|quarto|sala simples|obra)\b") &&
                                  Regex.IsMatch(contextText, @"\b(salao de baile|colacao de grau|baile de formatura|festa de gala|altar da igreja)\b"));
            if (isFormalScene)
            {
                // Se a roupa base do personagem era de Trabalho (ex: avental de cozinha) e ele foi ao baile/formatura, usa Roupa Simples (sem avental, arrumadinha)
                if (string.Equals(baseCategory, "Trabalho", StringComparison.OrdinalIgnoreCase))
                    return "Simples";
                return "Formal";
            }

            // 2. Verifica se o Cenário é de Trabalho (Obra / Construção / Escritório / Construtora / Lavoura / Oficina)
            bool isWorkScene = Regex.IsMatch(scenarioNorm, @"\b(obra|construcao|canteiro|escritorio|construtora|empresa|oficina|lavoura|roca|consultorio)\b") ||
                               Regex.IsMatch(contextText, @"\b(canteiro de obra|capacete de obra|sala na nossa construtora|reuniao de negocios|trabalhando na obra)\b");
            if (isWorkScene)
                return "Trabalho";

            // 3. Verifica se o Cenário é de Lazer (Passeio / Parque / Praça / Praia / Encontro / Barzinho / Cafeteria / Fim de semana)
            bool isLeisureScene = Regex.IsMatch(scenarioNorm, @"\b(lazer|passeio|parque|praca|praia|barzinho|shopping|jardim|piscina|cafeteria)\b");
            if (isLeisureScene)
                return "Lazer";

            // 4. Verifica se o Cenário é de Casa / Cotidiano Simples (Cozinha / Casinha / Quarto / Sala / Quintal)
            bool isSimpleScene = Regex.IsMatch(scenarioNorm, @"\b(casa|casinha|cozinha|quarto|sala|quintal|varanda|alpendre)\b") ||
                                 Regex.IsMatch(contextText, @"\b(casa simples|casinha|cozinha|fogao|mesa de madeira|boletos da minha faculdade)\b");
            if (isSimpleScene)
            {
                // Se a base do personagem já é Trabalho doméstico (ex: A Salgadeira com avental na cozinha), na cozinha ela usa a própria Roupa Padrão!
                if (string.Equals(baseCategory, "Trabalho", StringComparison.OrdinalIgnoreCase))
                    return "Trabalho";
                return "Simples";
            }

            // 5. Regra Inteligente Pós-Ocasião Especial:
            // Se a Roupa Padrão original do personagem era de Formatura/Festa ("Formal") e este Take NÃO é mais na formatura/festa,
            // troca automaticamente para "Simples" para o personagem não ficar de beca/vestido de gala fora da festa!
            if (string.Equals(baseCategory, "Formal", StringComparison.OrdinalIgnoreCase) && !isFormalScene)
                return "Simples";

            return "Padrao";
        }

        public static string GetStandardWardrobePresetDescription(EpisodeWorkItem ep, string baseCharFileName, string categoryKey)
        {
            string cleanBase = GetBaseCharacterFileName(baseCharFileName);
            string charTitle = CleanAssetStem(cleanBase);
            string rawBasePrompt = GetCharacterBasePromptFromStory(ep, cleanBase);
            string fullStoryNorm = GetFullStoryNarrativeContext(ep);

            string normChar = NormalizeForCompare(charTitle + " " + rawBasePrompt);
            bool hasMaleWord = Regex.IsMatch(normChar, @"\b(homem|senhor|rapaz|menino|pai|marido|noivo|filho|irmao|engenheiro|arquiteto|pedreiro|servente|lavrador|campones|patrao|chefe|doutor|medico|advogado|garoto|velho|idoso)\b");
            bool hasFemaleWord = Regex.IsMatch(normChar, @"\b(mulher|senhora|moca|menina|mae|esposa|noiva|filha|irma|dona|tia|sobrinha|salgadeira|faxineira|cozinheira|professora|secretaria|camponesa|garota|velha|idosa|vendedora)\b");
            bool isFemale = hasFemaleWord && !hasMaleWord;
            bool isElderly = Regex.IsMatch(normChar, @"\b(idosa|idoso|senhora|senhor|avo|velho|velha|grisalh\w*|60 anos|65 anos|70 anos)\b");
            bool isEngineerOrExec = Regex.IsMatch(normChar, @"\b(engenheir\w*|arquiteto\w*|advogad\w*|empresari\w*|executiv\w*|diretor\w*|chefe|patrao|doutor\w*|medic\w*|gerente)\b");
            bool isRuralOrWorker = Regex.IsMatch(normChar, @"\b(pedreiro|servente|lavrador\w*|campones\w*|roceir\w*|operari\w*|mecanic\w*|carpinteir\w*|salgadeir\w*|faxineir\w*|cozinheir\w*)\b");
            bool hasApronInBase = Regex.IsMatch(normChar, @"\b(avental)\b");
            bool hasBecaInBase = Regex.IsMatch(normChar, @"\b(beca|capelo|canudo.*diploma)\b");
            bool isHumbleCharacter = Regex.IsMatch(normChar, @"\b(humilde|simples|salgadeir\w*|faxineir\w*|cozinheir\w*|servente|pedreiro|lavrador\w*|campones\w*|roceir\w*|diarista)\b");
            bool isDespisedForSimpleClothesInStory = isHumbleCharacter &&
                Regex.IsMatch(fullStoryNorm, @"\b(vergonha de voce|vergonha de mim|roupa velha|vestido melhor|so uma vizinha|nao combina mais com a minha vida|humilhad\w*)\b");

            // Extrai o vestido/roupa original sem avental quando o personagem humilde já tem um vestido descrito no PASSO 1
            string baseDressWithoutApron = "";
            if (!string.IsNullOrEmpty(rawBasePrompt))
            {
                Match mBaseDress = Regex.Match(rawBasePrompt, @"Veste\s+([^\.]+)", RegexOptions.IgnoreCase);
                if (mBaseDress.Success)
                {
                    string rawCloth = mBaseDress.Groups[1].Value;
                    rawCloth = Regex.Replace(rawCloth, @"\s*(com\s+um\s+avental|com\s+avental|e\s+avental)[^,\.]*", "", RegexOptions.IgnoreCase);
                    rawCloth = Regex.Replace(rawCloth, @"\s*segurando\s+[^,\.]*", "", RegexOptions.IgnoreCase);
                    baseDressWithoutApron = rawCloth.Trim().TrimEnd(',', ';');
                }
            }

            string std = NormalizeStandardWardrobeCategory(categoryKey);

            // Coleta pistas extras EXCLUSIVAMENTE da oração daquele personagem (nunca do texto de outros personagens no mesmo Take!)
            string takeHints = "";
            if (ep != null && ep.FlowTakes != null)
            {
                string baseCat = DetectBaseCharacterOutfitCategory(rawBasePrompt, cleanBase);
                foreach (FlowTakeSpec t in ep.FlowTakes)
                {
                    bool hasChar = t.Ingredients != null && t.Ingredients.Any(i =>
                        string.Equals(GetBaseCharacterFileName(i), cleanBase, StringComparison.OrdinalIgnoreCase));
                    if (!hasChar) continue;

                    string reqCat = DetectCharacterRequiredOutfitInTake(t, cleanBase, rawBasePrompt, baseCat);
                    if (string.Equals(reqCat, std, StringComparison.OrdinalIgnoreCase))
                    {
                        string charClause = ExtractCharacterSpecificClauseInTake(t, cleanBase);
                        if (string.IsNullOrEmpty(charClause)) continue;

                        Match mCloth = Regex.Match(charClause, @"\b(vestindo|usando|com seu vestido|em seu vestido|com camisa|com vestido|com terno|com avental|com capacete|sem o avental|de camisa|de calca|de blusa)[^,\.;]{3,65}", RegexOptions.IgnoreCase);
                        if (mCloth.Success)
                        {
                            string candidate = mCloth.Value.Trim();
                            if (std != "Trabalho" && Regex.IsMatch(candidate, @"\b(avental|capacete)\b", RegexOptions.IgnoreCase))
                                continue;
                            if (std != "Formal" && Regex.IsMatch(candidate, @"\b(beca|capelo)\b", RegexOptions.IgnoreCase))
                                continue;
                            takeHints = candidate;
                            break;
                        }
                    }
                }
            }

            string noPropsSuffix = " Mãos totalmente livres e vazias ao lado do corpo (sem canudo de diploma, sem pastas e sem objetos nas mãos), sem adicionar óculos.";

            if (std == "Trabalho")
            {
                if (isFemale)
                {
                    if (isEngineerOrExec)
                        return "Roupa de trabalho profissional: camisa social feminina bem cortada, blazer estruturado, calça de alfaiataria e sapatos fechados de trabalho." + noPropsSuffix;
                    if (isRuralOrWorker)
                        return "Roupa de trabalho humilde e prática: vestido ou blusa modesta de algodão com avental de serviço amarrado na cintura e calçado baixo fechado de trabalho." + noPropsSuffix;
                    return "Roupa de trabalho cotidiana: blusa social discreta de mangas curtas, calça comprida de trabalho e sapatos baixos confortáveis." + noPropsSuffix;
                }
                else
                {
                    if (isEngineerOrExec)
                    {
                        bool hasOfficeInStory = Regex.IsMatch(fullStoryNorm, @"\b(escritorio moderno|construtora|diretoria|sala na nossa construtora)\b");
                        if (hasOfficeInStory)
                            return "Contexto da história: engenheiro recém-formado e ambicioso trabalhando no escritório moderno de uma construtora (TOTALMENTE SEM BECA DE FORMATURA E SEM CANUDO DE DIPLOMA NAS MÃOS). Veste camisa social elegante bem alinhada por dentro da calça, calça social de alfaiataria escura com cinto de couro e sapatos sociais de couro lustrados." + noPropsSuffix;
                        return "Roupa de trabalho de engenheiro/profissional (TOTALMENTE SEM BECA DE FORMATURA E SEM CANUDO DE DIPLOMA): camisa social azul-clara bem alinhada com mangas dobradas até o cotovelo, calça social ou jeans escura de ótimo caimento e sapatos/botas de couro." + noPropsSuffix;
                    }
                    if (isRuralOrWorker)
                        return "Roupa de trabalho pesado: camisa de algodão resistente levemente gasta pelo serviço, calça jeans grossa de trabalho e botinas de couro." + noPropsSuffix;
                    return "Roupa de trabalho: camisa social ou camisa polo de serviço, calça comprida escura com cinto de couro e sapatos de trabalho." + noPropsSuffix;
                }
            }
            else if (std == "Lazer")
            {
                if (isFemale)
                {
                    if (isHumbleCharacter)
                        return "Roupa de passeio modesta e simples: vestido casual leve de algodão sem avental ou blusinha limpa de fim de semana com saia/calça simples e sandálias baixas confortáveis." + noPropsSuffix;
                    return "Roupa de lazer e passeio: vestido casual leve de passeio ou blusa bonita de fim de semana com calça jeans clara e sandálias confortáveis." + noPropsSuffix;
                }
                else
                {
                    return "Roupa de lazer e passeio (sem beca e sem terno): camiseta polo ou camisa casual aberta no colarinho, calça jeans confortável e tênis casual de passeio." + noPropsSuffix;
                }
            }
            else if (std == "Formal")
            {
                if (isFemale)
                {
                    // Se o contexto da história diz que ela é humilde e o marido tem vergonha da roupa simples dela na festa/formatura:
                    if (isDespisedForSimpleClothesInStory || (isHumbleCharacter && hasApronInBase))
                    {
                        string dressDesc = !string.IsNullOrEmpty(baseDressWithoutApron)
                            ? baseDressWithoutApron
                            : "vestido simples rosa-claro modesto de algodão até abaixo dos joelhos e sapatilhas baixas simples";
                        return string.Format(
                            "Contexto da cena: esposa humilde que vai à formatura do marido usando sua melhor roupinha simples, limpa e arrumadinha de cidade pequena (TOTALMENTE SEM AVENTAL, sem brilho de cetim e sem luxo, motivo pelo qual o marido vaidoso sente vergonha dela diante dos convidados ricos). Veste {0}, bem limpo e passado, com um casaquinho leve modesto sobre os ombros, TOTALMENTE SEM AVENTAL.{1}",
                            dressDesc,
                            noPropsSuffix);
                    }
                    if (isElderly)
                        return "Roupa formal modesta e digna: vestido discreto de ocasião especial até abaixo dos joelhos com casaquinho de tricô leve sobre os ombros e sapatos baixos." + noPropsSuffix;
                    return "Roupa formal de ocasião especial: vestido social elegante de festa/cerimônia, tecido refinado com caimento impecável e sapatos sociais." + noPropsSuffix;
                }
                else
                {
                    return "Roupa formal completa: terno social escuro bem alinhado, camisa social branca impecável, gravata elegante e sapatos sociais de couro lustrado." + noPropsSuffix;
                }
            }
            else // "Simples"
            {
                if (isFemale)
                {
                    if (hasApronInBase || isDespisedForSimpleClothesInStory || isHumbleCharacter)
                    {
                        string dressDesc = !string.IsNullOrEmpty(baseDressWithoutApron)
                            ? baseDressWithoutApron
                            : "vestido simples rosa-claro modesto de algodão até abaixo dos joelhos e sapatilhas baixas simples";
                        return string.Format(
                            "Contexto da cena: mulher humilde e batalhadora fora da cozinha (indo à formatura do marido e à cidade) usando roupa simples, porém limpa, modesta e arrumadinha (o que faz o marido vaidoso fingir que não a conhece na formatura). Veste {0}, limpo, bem passado e arrumadinho, TOTALMENTE SEM O AVENTAL DE COZINHA e sem manchas de farinha, sem luxo e sem brilho.{1}",
                            dressDesc,
                            noPropsSuffix);
                    }
                    if (isElderly)
                        return "Roupa simples e humilde do dia a dia: vestido modesto de algodão ou saia midi simples com blusa de malha confortável e sandálias baixas." + noPropsSuffix;
                    return "Roupa simples do dia a dia: blusa básica de algodão, calça jeans simples ou saia modesta caseira e calçado simples confortável." + noPropsSuffix;
                }
                else
                {
                    if (hasBecaInBase)
                    {
                        return "Contexto da cena: jovem marido estudante universitário em casa na cozinha simples estudando cadernos e boletos antes de se formar (TOTALMENTE SEM BECA DE FORMATURA, SEM FAIXA AZUL E SEM CANUDO DE DIPLOMA NAS MÃOS, E SEM AVENTAL). Veste camiseta básica ou camisa polo simples de algodão de ficar em casa, calça jeans comum e tênis simples." + noPropsSuffix;
                    }
                    if (isElderly)
                        return "Roupa simples e humilde do dia a dia: camisa de botão simples de algodão, calça de tecido modesta e sapatos simples." + noPropsSuffix;
                    return "Roupa simples e casual do dia a dia (sem beca e sem terno): camiseta básica de algodão ou camisa simples, calça jeans comum e tênis simples." + noPropsSuffix;
                }
            }
        }

        public static List<CharacterWardrobeSpec> DetectRequiredCharacterOutfitsFromText(EpisodeWorkItem ep)
        {
            List<CharacterWardrobeSpec> results = new List<CharacterWardrobeSpec>();
            if (ep == null) return results;

            // Coleta todos os Takes de todos os episódios da mesma história (EP.1, EP.2, EP.3) para detectar o guarda-roupa completo da história
            List<FlowTakeSpec> allStoryTakes = new List<FlowTakeSpec>();
            List<GrokAssetSpec> allStoryGrokSpecs = new List<GrokAssetSpec>();

            if (!string.IsNullOrEmpty(ep.StoryRootPath) && Directory.Exists(ep.StoryRootPath))
            {
                foreach (string sub in Directory.GetDirectories(ep.StoryRootPath).OrderBy(d => d))
                {
                    if (!Regex.IsMatch(Path.GetFileName(sub), @"^EP\.?\s*\d+$", RegexOptions.IgnoreCase))
                        continue;

                    if (string.Equals(sub, ep.EpisodePath, StringComparison.OrdinalIgnoreCase))
                    {
                        if (ep.FlowTakes != null) allStoryTakes.AddRange(ep.FlowTakes);
                        if (ep.GrokSpecs != null) allStoryGrokSpecs.AddRange(ep.GrokSpecs);
                    }
                    else
                    {
                        try
                        {
                            EpisodeWorkItem sibling = ParseEpisodeFolder(sub, ep.StoryName, ep.Genre, ep.StoryRootPath);
                            if (sibling != null)
                            {
                                if (sibling.FlowTakes != null) allStoryTakes.AddRange(sibling.FlowTakes);
                                if (sibling.GrokSpecs != null) allStoryGrokSpecs.AddRange(sibling.GrokSpecs);
                            }
                        }
                        catch { }
                    }
                }
            }

            if (allStoryTakes.Count == 0 && ep.FlowTakes != null)
                allStoryTakes.AddRange(ep.FlowTakes);
            if (allStoryGrokSpecs.Count == 0 && ep.GrokSpecs != null)
                allStoryGrokSpecs.AddRange(ep.GrokSpecs);

            // Lista única de personagens do episódio/história
            List<string> charFiles = new List<string>();
            if (ep.AllRequiredFlowIngredients != null)
            {
                foreach (string ing in ep.AllRequiredFlowIngredients)
                {
                    string cleanBase = GetBaseCharacterFileName(ing);
                    if (!IsScenarioAssetName(cleanBase) && !charFiles.Contains(cleanBase, StringComparer.OrdinalIgnoreCase))
                        charFiles.Add(cleanBase);
                }
            }
            if (ep.GrokSpecs != null)
            {
                foreach (GrokAssetSpec gs in ep.GrokSpecs)
                {
                    if (!gs.IsScenario && !string.IsNullOrEmpty(gs.TargetFileName))
                    {
                        string cleanBase = GetBaseCharacterFileName(gs.TargetFileName);
                        if (!charFiles.Contains(cleanBase, StringComparer.OrdinalIgnoreCase))
                            charFiles.Add(cleanBase);
                    }
                }
            }

            foreach (string baseCharFile in charFiles)
            {
                GrokAssetSpec charSpec = allStoryGrokSpecs.FirstOrDefault(s =>
                    string.Equals(GetBaseCharacterFileName(s.TargetFileName), baseCharFile, StringComparison.OrdinalIgnoreCase));

                string rawBasePrompt = charSpec != null && !string.IsNullOrEmpty(charSpec.RawPromptLine)
                    ? charSpec.RawPromptLine
                    : GetCharacterBasePromptFromStory(ep, baseCharFile);
                string baseCat = DetectBaseCharacterOutfitCategory(rawBasePrompt, baseCharFile);

                Dictionary<string, List<int>> allAppearingCategories = new Dictionary<string, List<int>>(StringComparer.OrdinalIgnoreCase);

                foreach (FlowTakeSpec take in allStoryTakes)
                {
                    if (take.Ingredients == null) continue;
                    bool appearsInTake = take.Ingredients.Any(ing =>
                        string.Equals(GetBaseCharacterFileName(ing), baseCharFile, StringComparison.OrdinalIgnoreCase));
                    if (!appearsInTake) continue;

                    string reqCat = DetectCharacterRequiredOutfitInTake(take, baseCharFile, rawBasePrompt, baseCat);
                    if (string.IsNullOrEmpty(reqCat) || string.Equals(reqCat, "Padrao", StringComparison.OrdinalIgnoreCase))
                        continue;

                    List<int> takeNums;
                    if (!allAppearingCategories.TryGetValue(reqCat, out takeNums))
                    {
                        takeNums = new List<int>();
                        allAppearingCategories[reqCat] = takeNums;
                    }
                    if (!takeNums.Contains(take.TakeNumber))
                        takeNums.Add(take.TakeNumber);
                }

                // Se o personagem secundário tem baseCat == "Padrao" (ex: O Sogro, A Sogra, O Joalheiro, O Empresário)
                // e aparece em apenas 1 único tipo de ocasião na história inteira, a Roupa Padrão do PASSO 1 já foi desenhada exatamente para essa cena!
                if (string.Equals(baseCat, "Padrao", StringComparison.OrdinalIgnoreCase) && allAppearingCategories.Count <= 1)
                    continue;

                // Ordena nas 4 categorias padronizadas: Trabalho, Lazer, Formal, Simples
                string[] standardOrder = new[] { "Trabalho", "Lazer", "Formal", "Simples" };
                foreach (string catKey in standardOrder)
                {
                    if (string.Equals(catKey, baseCat, StringComparison.OrdinalIgnoreCase))
                        continue;

                    List<int> takeNums;
                    if (!allAppearingCategories.TryGetValue(catKey, out takeNums))
                        continue;

                    string varFile = BuildOutfitVariantFileName(baseCharFile, catKey);
                    string displayLbl = FormatOutfitDisplayLabel(catKey);
                    string desc = GetStandardWardrobePresetDescription(ep, baseCharFile, catKey);
                    string reason = string.Format("Detectado no contexto ({0})",
                        string.Join(", ", takeNums.Take(5).Select(n => string.Format("Take {0:00}", n))));

                    results.Add(new CharacterWardrobeSpec
                    {
                        BaseCharacterFileName = baseCharFile,
                        CharacterDisplayName = CleanAssetStem(baseCharFile),
                        CategoryKey = catKey,
                        DisplayLabel = displayLbl,
                        VariantFileName = varFile,
                        OutfitPromptDescription = desc,
                        ReasonFromText = reason
                    });
                }
            }

            return results;
        }

        public static List<string> GetCharacterOutfitVariantsOnDisk(EpisodeWorkItem ep, string baseCharFileName)
        {
            List<string> results = new List<string>();
            if (ep == null || string.IsNullOrEmpty(baseCharFileName)) return results;

            string cleanBase = GetBaseCharacterFileName(baseCharFileName);
            string baseStem = Path.GetFileNameWithoutExtension(cleanBase);
            string prefix = baseStem + "__Roupa_";

            HashSet<string> seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            List<string> searchDirs = new List<string>();
            if (!string.IsNullOrEmpty(ep.AssetsDir) && Directory.Exists(ep.AssetsDir))
                searchDirs.Add(ep.AssetsDir);

            if (!string.IsNullOrEmpty(ep.StoryRootPath) && Directory.Exists(ep.StoryRootPath))
            {
                foreach (string sub in Directory.GetDirectories(ep.StoryRootPath))
                {
                    string ad = Path.Combine(sub, "assets");
                    if (Directory.Exists(ad) && !searchDirs.Contains(ad, StringComparer.OrdinalIgnoreCase))
                        searchDirs.Add(ad);
                }
            }

            foreach (string dir in searchDirs)
            {
                foreach (string f in Directory.GetFiles(dir))
                {
                    string fn = Path.GetFileName(f);
                    if (!fn.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
                        continue;
                    if (!Regex.IsMatch(Path.GetExtension(f), @"^\.(jpg|jpeg|png)$", RegexOptions.IgnoreCase))
                        continue;
                    if (new FileInfo(f).Length <= 5 * 1024)
                        continue;

                    if (seen.Add(fn))
                    {
                        results.Add(fn);
                        // Garante que a variante exista também na pasta assets\ deste episódio
                        if (!string.IsNullOrEmpty(ep.AssetsDir))
                        {
                            if (!Directory.Exists(ep.AssetsDir)) Directory.CreateDirectory(ep.AssetsDir);
                            string localCopy = Path.Combine(ep.AssetsDir, fn);
                            if (!File.Exists(localCopy))
                            {
                                try { File.Copy(f, localCopy, true); } catch { }
                            }
                        }
                    }
                }
            }

            return results.OrderBy(x => x).ToList();
        }

        public static string ResolveAutomaticOutfitForTake(
            EpisodeWorkItem ep,
            FlowTakeSpec take,
            string baseCharFileName,
            List<string> availableVariants)
        {
            if (take == null || string.IsNullOrEmpty(baseCharFileName))
                return baseCharFileName;

            string cleanBase = GetBaseCharacterFileName(baseCharFileName);
            string rawBasePrompt = GetCharacterBasePromptFromStory(ep, cleanBase);

            string baseCat = DetectBaseCharacterOutfitCategory(rawBasePrompt, cleanBase);
            string reqCat = DetectCharacterRequiredOutfitInTake(take, cleanBase, rawBasePrompt, baseCat);

            // Se o texto pede a própria categoria da Roupa Padrão original, usa a Roupa Padrão
            if (string.Equals(reqCat, "Padrao", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(reqCat, baseCat, StringComparison.OrdinalIgnoreCase))
            {
                return cleanBase;
            }

            // 1. Se a variante já existir em disco, retorna o nome exato do arquivo em disco
            if (availableVariants != null)
            {
                foreach (string varFile in availableVariants)
                {
                    string varCat = NormalizeStandardWardrobeCategory(ExtractOutfitOccasionLabel(varFile));
                    if (string.Equals(varCat, reqCat, StringComparison.OrdinalIgnoreCase))
                        return varFile;
                }
            }

            // 2. Se o personagem tem baseCat == "Padrao" (personagem secundário como O Sogro, A Sogra, O Joalheiro, O Empresário)
            // verifica se ele realmente muda de ocasião na história antes de exigir uma roupa nova
            if (string.Equals(baseCat, "Padrao", StringComparison.OrdinalIgnoreCase) && ep != null)
            {
                List<CharacterWardrobeSpec> storyOutfits = DetectRequiredCharacterOutfitsFromText(ep);
                bool needsOutfitInStory = storyOutfits.Any(o =>
                    string.Equals(o.BaseCharacterFileName, cleanBase, StringComparison.OrdinalIgnoreCase) &&
                    string.Equals(o.CategoryKey, reqCat, StringComparison.OrdinalIgnoreCase));
                if (!needsOutfitInStory)
                    return cleanBase;
            }

            // 3. Retorna o nome padronizado da roupa exigida pelo texto (para que seja gerada automaticamente antes do vídeo caso ainda não exista em disco)
            return BuildOutfitVariantFileName(cleanBase, reqCat);
        }

        private class StoryCharacterCandidate
        {
            public int EpisodeNum;
            public bool IsPreviousEpisode;
            public int SpecOrderIndex;
            public GrokAssetSpec SpecRef;
            public string CharacterLabelId;
            public string NormTitle;
            public string FileName;
            public string NormStem;
            public string NormPromptLine;
            public string DiskPath;
            public bool IsAutoOutfitFile;
        }

        private static int ParseEpisodeNumOrDefault(string nameOrPath, int fallback)
        {
            if (string.IsNullOrEmpty(nameOrPath)) return fallback;
            string fn = Path.GetFileName(nameOrPath.TrimEnd('\\', '/'));
            Match m = Regex.Match(fn, @"^EP\.?\s*0*(\d+)$", RegexOptions.IgnoreCase);
            int n;
            if (m.Success && int.TryParse(m.Groups[1].Value, out n) && n > 0)
                return n;
            return fallback;
        }

        private static string ExtractCharacterLabelId(string labelPrefix, string fileName)
        {
            if (!string.IsNullOrEmpty(labelPrefix))
            {
                Match mLbl = Regex.Match(labelPrefix, @"Personagem\s*0*(\d+[A-Za-z]?)\b", RegexOptions.IgnoreCase);
                if (mLbl.Success) return mLbl.Groups[1].Value.ToLowerInvariant();
            }
            if (!string.IsNullOrEmpty(fileName))
            {
                Match mFn = Regex.Match(fileName, @"(?:^|_)Personagem_0*(\d+[A-Za-z]?)(?:_|\.)", RegexOptions.IgnoreCase);
                if (mFn.Success) return mFn.Groups[1].Value.ToLowerInvariant();
            }
            return "";
        }

        private static string CleanDisplayTitleForContinuity(string rawTitle)
        {
            if (string.IsNullOrWhiteSpace(rawTitle)) return "";
            string s = rawTitle.Trim();
            s = Regex.Replace(s, @"^(Personagem\s*\d+[A-Za-z]?)\s*:\s*", "", RegexOptions.IgnoreCase).Trim();
            s = Regex.Replace(s, @"^em\s+cima\s+da\s+cabe[cç]a\s+", "", RegexOptions.IgnoreCase).Trim();
            return s.Trim('"').Trim();
        }

        private static string StripTrailingVariantQualifiers(string normName)
        {
            if (string.IsNullOrWhiteSpace(normName)) return "";
            string cur = normName.Trim();

            string pattern = @"\s+(?:" +
                @"roupa\s+poeira|traje\s+rico|refugiado\s+exausto|sem\s+bigode|sem\s+chapeu|sem\s+avental|sem\s+beca|" +
                @"com\s+flores|com\s+buque|com\s+mala|com\s+caixa|de\s+camisa\s+branca|de\s+terno|de\s+vestido|de\s+noiva|de\s+noivo|" +
                @"em\s+casa|no\s+trabalho|na\s+festa|na\s+rua|na\s+formatura|" +
                @"simples|arrumada|arrumado|casa|rua|trabalho|festa|jantar|almoco|gala|formal|lazer|passeio|" +
                @"noiva|noivo|executivo|executiva|gerente|demitido|demitida|premiado|premiada|costurando|diarista|" +
                @"estudante|fantasma|espectral|rico|rica|prospero|prospera|milionario|milionaria|" +
                @"bigodudo|barbeado|lavrador|campones|camponesa|exausto|exausta|ferido|ferida|sujo|suja|limpo|limpa" +
                @")$";

            for (int pass = 0; pass < 3; pass++)
            {
                string stripped = Regex.Replace(cur, pattern, "", RegexOptions.IgnoreCase).Trim();
                if (stripped == cur || stripped.Length < 4)
                    break;
                cur = stripped;
            }
            return cur;
        }

        private static string ExtractLeadingSubstantiveHead(string normText)
        {
            if (string.IsNullOrWhiteSpace(normText)) return "";
            string[] tokens = normText.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            if (tokens.Length == 0) return "";

            int idx = 0;
            if (Regex.IsMatch(tokens[0], @"^(o|a|os|as|um|uma|el|la|los|las)$"))
                idx = 1;
            if (idx >= tokens.Length) return "";

            string firstNoun = tokens[idx];
            // Substantivos genéricos demais exigem pelo menos 2 palavras substantivas (ex: "a filha da rendeira", "o vendedor soberbo")
            bool isGenericFirstWord = Regex.IsMatch(
                firstNoun,
                @"^(homem|mulher|jovem|moca|rapaz|senhor|senhora|idoso|idosa|velho|velha|menino|menina|garoto|garota|filho|filha|pai|mae|irmao|irma|amigo|amiga|vizinho|vizinha|vendedor)$");

            if (!isGenericFirstWord && firstNoun.Length >= 5)
            {
                return idx == 1 ? (tokens[0] + " " + firstNoun) : firstNoun;
            }

            int takeEnd = Math.Min(tokens.Length, idx + 3);
            if (takeEnd - idx >= 2)
            {
                return string.Join(" ", tokens.Take(takeEnd).ToArray());
            }
            return "";
        }

        private static bool HasIncompatibleCharacterGender(string normSpecAll, string normCandAll)
        {
            if (string.IsNullOrEmpty(normSpecAll) || string.IsNullOrEmpty(normCandAll))
                return false;

            bool specFem = Regex.IsMatch(normSpecAll, @"^(a\s+|la\s+)|\b(mulher\s+adulta|mulher\s+idosa|mesma\s+mulher)\b");
            bool specMale = Regex.IsMatch(normSpecAll, @"^(o\s+|el\s+)|\b(homem\s+adulto|homem\s+idoso|mesmo\s+homem)\b");
            bool candFem = Regex.IsMatch(normCandAll, @"^(a\s+|la\s+)|\b(mulher\s+adulta|mulher\s+idosa)\b");
            bool candMale = Regex.IsMatch(normCandAll, @"^(o\s+|el\s+)|\b(homem\s+adulto|homem\s+idoso)\b");

            if (specFem && !specMale && candMale && !candFem) return true;
            if (specMale && !specFem && candFem && !candMale) return true;
            return false;
        }

        private static List<StoryCharacterCandidate> CollectStoryCharacterCandidates(EpisodeWorkItem ep)
        {
            List<StoryCharacterCandidate> list = new List<StoryCharacterCandidate>();
            if (ep == null) return list;

            int currentEpNum = ep.EpisodeNumber > 0
                ? ep.EpisodeNumber
                : ParseEpisodeNumOrDefault(ep.EpisodeName, ParseEpisodeNumOrDefault(ep.EpisodePath, 1));

            List<string> episodeDirs = new List<string>();
            if (!string.IsNullOrEmpty(ep.StoryRootPath) && Directory.Exists(ep.StoryRootPath))
            {
                foreach (string sub in Directory.GetDirectories(ep.StoryRootPath))
                {
                    string subName = Path.GetFileName(sub);
                    if (!Regex.IsMatch(subName, @"^EP\.?\s*\d+$", RegexOptions.IgnoreCase))
                        continue;
                    int subNum = ParseEpisodeNumOrDefault(subName, 999);
                    if (subNum <= currentEpNum)
                        episodeDirs.Add(sub);
                }
                episodeDirs = episodeDirs
                    .OrderBy(d => ParseEpisodeNumOrDefault(d, 999))
                    .ThenBy(d => d, StringComparer.OrdinalIgnoreCase)
                    .ToList();
            }

            if (!string.IsNullOrEmpty(ep.EpisodePath) &&
                Directory.Exists(ep.EpisodePath) &&
                !episodeDirs.Contains(ep.EpisodePath, StringComparer.OrdinalIgnoreCase))
            {
                episodeDirs.Add(ep.EpisodePath);
            }

            List<string> currentEpAssets = new List<string>();
            if (!string.IsNullOrEmpty(ep.AssetsDir) && Directory.Exists(ep.AssetsDir))
            {
                currentEpAssets = Directory.GetFiles(ep.AssetsDir)
                    .Where(f => Regex.IsMatch(Path.GetExtension(f), @"^\.(jpg|jpeg|png)$", RegexOptions.IgnoreCase) &&
                                new FileInfo(f).Length > 4 * 1024 &&
                                !IsScenarioAssetName(Path.GetFileName(f)))
                    .ToList();
            }

            foreach (string subDir in episodeDirs)
            {
                bool isSameEp = !string.IsNullOrEmpty(ep.EpisodePath) &&
                                string.Equals(subDir, ep.EpisodePath, StringComparison.OrdinalIgnoreCase);
                int subEpNum = isSameEp
                    ? currentEpNum
                    : ParseEpisodeNumOrDefault(subDir, 1);
                bool isPrevEp = subEpNum < currentEpNum && !isSameEp;

                string subAssetsDir = Path.Combine(subDir, "assets");
                List<string> subDiskChars = new List<string>();
                if (Directory.Exists(subAssetsDir))
                {
                    subDiskChars = Directory.GetFiles(subAssetsDir)
                        .Where(f => Regex.IsMatch(Path.GetExtension(f), @"^\.(jpg|jpeg|png)$", RegexOptions.IgnoreCase) &&
                                    new FileInfo(f).Length > 4 * 1024 &&
                                    !IsScenarioAssetName(Path.GetFileName(f)))
                        .ToList();
                }

                List<GrokAssetSpec> subSpecs = new List<GrokAssetSpec>();
                if (isSameEp && ep.GrokSpecs != null && ep.GrokSpecs.Count > 0)
                {
                    subSpecs.AddRange(ep.GrokSpecs);
                }
                else if (Directory.Exists(subDir))
                {
                    try
                    {
                        string[] txts = Directory.GetFiles(subDir, "*.txt", SearchOption.TopDirectoryOnly);
                        string grokPath = FindBestFile(txts, new[] { "prompt_grok_passo1_e_2.txt", "prompt_grok", "comandos_gemini_completos" });
                        string flowPath = FindBestFile(txts, new[] { "prompt_flow_passo3.txt", "prompt_flow", "passo3_takes" });

                        if (!string.IsNullOrEmpty(grokPath) && File.Exists(grokPath))
                        {
                            List<FlowTakeSpec> tmpTakes = new List<FlowTakeSpec>();
                            List<string> tmpReqIngs = new List<string>();
                            Dictionary<string, string> tmpTitleMap = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                            if (!string.IsNullOrEmpty(flowPath) && File.Exists(flowPath))
                            {
                                ParseFlowTakes(ReadUtf8(flowPath), tmpTakes, tmpReqIngs, tmpTitleMap);
                            }
                            ParseGrokSpecs(ReadUtf8(grokPath), tmpTitleMap, tmpReqIngs, subSpecs);
                        }
                    }
                    catch { }
                }

                HashSet<string> coveredDiskPaths = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                List<string> nonAutoDiskChars = subDiskChars
                    .Where(f => Path.GetFileName(f).IndexOf("__Roupa_", StringComparison.OrdinalIgnoreCase) < 0)
                    .ToList();

                foreach (GrokAssetSpec gs in subSpecs)
                {
                    if (gs == null || gs.IsScenario || IsScenarioAssetName(gs.TargetFileName))
                        continue;

                    string charId = ExtractCharacterLabelId(gs.LabelPrefix, gs.TargetFileName);
                    string resolvedDisk = "";

                    // 1. Nome exato na pasta do próprio episódio (ou já copiado na pasta do episódio atual)
                    resolvedDisk = subDiskChars.FirstOrDefault(f =>
                        string.Equals(Path.GetFileName(f), gs.TargetFileName, StringComparison.OrdinalIgnoreCase)) ?? "";
                    if (string.IsNullOrEmpty(resolvedDisk))
                    {
                        resolvedDisk = currentEpAssets.FirstOrDefault(f =>
                            string.Equals(Path.GetFileName(f), gs.TargetFileName, StringComparison.OrdinalIgnoreCase)) ?? "";
                    }

                    // 2. Índice exato _Personagem_X_ dentro daquele mesmo episódio (excluindo variantes __Roupa_)
                    if (string.IsNullOrEmpty(resolvedDisk) && !string.IsNullOrEmpty(charId))
                    {
                        resolvedDisk = nonAutoDiskChars.FirstOrDefault(f =>
                            string.Equals(ExtractCharacterLabelId("", Path.GetFileName(f)), charId, StringComparison.OrdinalIgnoreCase)) ?? "";
                    }

                    // 3. Similaridade de stem dentro daquele mesmo episódio
                    if (string.IsNullOrEmpty(resolvedDisk) && nonAutoDiskChars.Count > 0)
                    {
                        resolvedDisk = FindMatchingDiskAssetFile(gs.TargetFileName, nonAutoDiskChars);
                    }

                    if (!string.IsNullOrEmpty(resolvedDisk))
                        coveredDiskPaths.Add(resolvedDisk);

                    StoryCharacterCandidate cand = new StoryCharacterCandidate();
                    cand.EpisodeNum = subEpNum;
                    cand.IsPreviousEpisode = isPrevEp;
                    cand.SpecOrderIndex = gs.OrderIndex > 0 ? gs.OrderIndex : 999;
                    cand.SpecRef = gs;
                    cand.CharacterLabelId = charId;
                    cand.NormTitle = NormalizeForCompare(CleanDisplayTitleForContinuity(gs.DisplayTitle));
                    cand.FileName = gs.TargetFileName ?? "";
                    cand.NormStem = NormalizeForCompare(CleanAssetStem(GetBaseCharacterFileName(gs.TargetFileName)));
                    cand.NormPromptLine = NormalizeForCompare(gs.RawPromptLine ?? "");
                    cand.DiskPath = resolvedDisk ?? "";
                    cand.IsAutoOutfitFile = false;
                    list.Add(cand);
                }

                // Adiciona quaisquer arquivos de personagens em disco que não estavam mapeados em prompt_grok
                foreach (string diskFile in subDiskChars)
                {
                    if (coveredDiskPaths.Contains(diskFile))
                        continue;

                    string fn = Path.GetFileName(diskFile);
                    // Se este arquivo de disco pertence ao prompt_grok do episódio atual (ex.: copiado retroativamente em execução antiga),
                    // não tratá-lo como personagem nativo de episódio anterior!
                    if (isPrevEp && ep.GrokSpecs != null &&
                        ep.GrokSpecs.Any(s => s != null && string.Equals(s.TargetFileName, fn, StringComparison.OrdinalIgnoreCase)))
                    {
                        continue;
                    }

                    StoryCharacterCandidate diskCand = new StoryCharacterCandidate();
                    diskCand.EpisodeNum = subEpNum;
                    diskCand.IsPreviousEpisode = isPrevEp;
                    diskCand.SpecOrderIndex = 999;
                    diskCand.SpecRef = null;
                    diskCand.CharacterLabelId = ExtractCharacterLabelId("", fn);
                    diskCand.NormTitle = "";
                    diskCand.FileName = fn;
                    diskCand.NormStem = NormalizeForCompare(CleanAssetStem(GetBaseCharacterFileName(fn)));
                    diskCand.NormPromptLine = "";
                    diskCand.DiskPath = diskFile;
                    diskCand.IsAutoOutfitFile = fn.IndexOf("__Roupa_", StringComparison.OrdinalIgnoreCase) >= 0;
                    list.Add(diskCand);
                }
            }

            return list;
        }

        private static int ScoreCharacterContinuityMatch(GrokAssetSpec spec, int effectiveSpecOrderIndex, StoryCharacterCandidate cand)
        {
            if (spec == null || cand == null || spec.IsScenario)
                return 0;

            if (!string.IsNullOrEmpty(spec.TargetFileName))
            {
                if (string.Equals(cand.FileName, spec.TargetFileName, StringComparison.OrdinalIgnoreCase))
                    return 0;
                if (!string.IsNullOrEmpty(cand.DiskPath) &&
                    string.Equals(Path.GetFileName(cand.DiskPath), spec.TargetFileName, StringComparison.OrdinalIgnoreCase))
                {
                    return 0;
                }
            }

            string specTitle = NormalizeForCompare(CleanDisplayTitleForContinuity(spec.DisplayTitle));
            string specStem = NormalizeForCompare(CleanAssetStem(GetBaseCharacterFileName(spec.TargetFileName)));

            // No mesmo episódio, o personagem base vem SEMPRE antes da variante
            if (!cand.IsPreviousEpisode)
            {
                if (effectiveSpecOrderIndex > 0 && cand.SpecOrderIndex < 999)
                {
                    if (cand.SpecOrderIndex >= effectiveSpecOrderIndex)
                        return 0;
                }
                else
                {
                    if (cand.IsAutoOutfitFile)
                        return 0;
                    bool candIsStrictPrefix = !string.IsNullOrEmpty(cand.NormStem) &&
                                              cand.NormStem.Length >= 4 &&
                                              specStem.StartsWith(cand.NormStem + " ", StringComparison.OrdinalIgnoreCase);
                    if (!candIsStrictPrefix)
                        return 0;
                }
            }

            string rawLine = spec.RawPromptLine ?? "";
            string promptBody = rawLine;
            Match mBody = Regex.Match(rawLine, @"^-\s*Personagem\s*\d+[A-Za-z]?\s*:\s*[^\-]*-\s*(.+)$", RegexOptions.IgnoreCase);
            if (mBody.Success)
            {
                promptBody = mBody.Groups[1].Value;
            }
            else
            {
                int colonIdx = rawLine.IndexOf(':');
                if (colonIdx >= 0 && colonIdx + 1 < rawLine.Length)
                    promptBody = rawLine.Substring(colonIdx + 1);
            }

            string normBody = NormalizeForCompare(promptBody);
            string normSpecAll = ((specTitle.Length > 0 ? specTitle : specStem) + " " + normBody).Trim();
            string normCandAll = ((cand.NormTitle.Length > 0 ? cand.NormTitle : cand.NormStem) + " " + cand.NormPromptLine).Trim();

            bool hasContinuityCue = Regex.IsMatch(
                normBody,
                @"\b(mesmo rosto|mesma estrutura|mesmo personagem|mesma personagem|mesma mulher|mesmo homem|mesmo senhor|mesma senhora|mesmo jovem|mesma jovem|mesmo idoso|mesma idosa|mesmo menino|mesma menina|mesmo garoto|mesma garota|mesmo bode|mesmo cavalo|mesmo cachorro|exatamente o mesmo|exatamente a mesma|exatamente do mesmo|exatamente da mesma|mantendo 100|mantendo exatamente|do ep\s*0*\d+|do episodio anterior|da parte\s*0*\d+|mismo rostro|misma mujer|mismo hombre)\b");

            // 1. Referência explícita a "Personagem X" (ex.: "do EP.1 (Personagem 5)", "do Personagem 1")
            if (!string.IsNullOrEmpty(cand.CharacterLabelId) && !string.IsNullOrEmpty(promptBody))
            {
                int explicitRefEp = 0;
                string explicitRefChar = "";

                Match mEpChar = Regex.Match(
                    promptBody,
                    @"\bEP\.?\s*0*(\d+)(?:\s*e\s*EP\.?\s*0*\d+)?\s*\(\s*Personagem\s*0*(\d+[A-Za-z]?)\s*\)",
                    RegexOptions.IgnoreCase);
                if (mEpChar.Success)
                {
                    int.TryParse(mEpChar.Groups[1].Value, out explicitRefEp);
                    explicitRefChar = mEpChar.Groups[2].Value.ToLowerInvariant();
                }
                else
                {
                    Match mCharEp = Regex.Match(
                        promptBody,
                        @"\bPersonagem\s*0*(\d+[A-Za-z]?)\s+do\s+EP\.?\s*0*(\d+)\b",
                        RegexOptions.IgnoreCase);
                    if (mCharEp.Success)
                    {
                        explicitRefChar = mCharEp.Groups[1].Value.ToLowerInvariant();
                        int.TryParse(mCharEp.Groups[2].Value, out explicitRefEp);
                    }
                    else
                    {
                        Match mCharOnly = Regex.Match(
                            promptBody,
                            @"(?:do|da|de|\()\s*Personagem\s*0*(\d+[A-Za-z]?)\b",
                            RegexOptions.IgnoreCase);
                        if (mCharOnly.Success)
                        {
                            explicitRefChar = mCharOnly.Groups[1].Value.ToLowerInvariant();
                            Match mAnyEp = Regex.Match(promptBody, @"\bdo\s+EP\.?\s*0*(\d+)\b", RegexOptions.IgnoreCase);
                            if (mAnyEp.Success)
                                int.TryParse(mAnyEp.Groups[1].Value, out explicitRefEp);
                        }
                    }
                }

                if (!string.IsNullOrEmpty(explicitRefChar) &&
                    string.Equals(cand.CharacterLabelId, explicitRefChar, StringComparison.OrdinalIgnoreCase) &&
                    !HasIncompatibleCharacterGender(normSpecAll, normCandAll))
                {
                    if (explicitRefEp > 0)
                    {
                        if (cand.EpisodeNum == explicitRefEp)
                            return 1060;
                    }
                    else
                    {
                        return cand.EpisodeNum == 1 ? 1040 : 1010;
                    }
                }
            }

            if (HasIncompatibleCharacterGender(normSpecAll, normCandAll))
                return 0;

            // 2. Menção explícita do título/nome completo do personagem anterior dentro do prompt com pista de continuidade
            // (ex.: "mantendo exatamente o mesmo rosto e corpo d'O Motorista do Leite", "porte físico de El Joven Campesino")
            if (hasContinuityCue && !string.IsNullOrEmpty(normBody))
            {
                if (!string.IsNullOrEmpty(cand.NormTitle) && cand.NormTitle.Length >= 5 &&
                    Regex.IsMatch(normBody, @"\b" + Regex.Escape(cand.NormTitle) + @"\b"))
                {
                    return 930 + Math.Min(30, cand.NormTitle.Length);
                }
                if (!string.IsNullOrEmpty(cand.NormStem) && cand.NormStem.Length >= 5 &&
                    Regex.IsMatch(normBody, @"\b" + Regex.Escape(cand.NormStem) + @"\b"))
                {
                    return 910 + Math.Min(30, cand.NormStem.Length);
                }
            }

            // 3. Igualdade exata ou prefixo por palavra inteira no DisplayTitle ou CleanAssetStem
            // (ex.: "A Filha da Rendeira" -> "A Filha da Rendeira Costurando" / "A Filha da Rendeira Noiva", "O Tropeiro Vigarista" -> "O Tropeiro Vigarista")
            if (!string.IsNullOrEmpty(cand.NormTitle) && cand.NormTitle.Length >= 4)
            {
                if ((!string.IsNullOrEmpty(specTitle) && string.Equals(specTitle, cand.NormTitle, StringComparison.Ordinal)) ||
                    (!string.IsNullOrEmpty(specStem) && string.Equals(specStem, cand.NormTitle, StringComparison.Ordinal)))
                {
                    return 880 + Math.Min(25, cand.NormTitle.Length);
                }
                if ((!string.IsNullOrEmpty(specTitle) && specTitle.StartsWith(cand.NormTitle + " ", StringComparison.Ordinal)) ||
                    (!string.IsNullOrEmpty(specStem) && specStem.StartsWith(cand.NormTitle + " ", StringComparison.Ordinal)))
                {
                    return 850 + Math.Min(25, cand.NormTitle.Length);
                }
            }

            if (!string.IsNullOrEmpty(cand.NormStem) && cand.NormStem.Length >= 4)
            {
                if ((!string.IsNullOrEmpty(specStem) && string.Equals(specStem, cand.NormStem, StringComparison.Ordinal)) ||
                    (!string.IsNullOrEmpty(specTitle) && string.Equals(specTitle, cand.NormStem, StringComparison.Ordinal)))
                {
                    return 860 + Math.Min(25, cand.NormStem.Length);
                }
                if ((!string.IsNullOrEmpty(specStem) && specStem.StartsWith(cand.NormStem + " ", StringComparison.Ordinal)) ||
                    (!string.IsNullOrEmpty(specTitle) && specTitle.StartsWith(cand.NormStem + " ", StringComparison.Ordinal)))
                {
                    return 830 + Math.Min(25, cand.NormStem.Length);
                }
            }

            // 4. Núcleo do arquétipo após remover sufixos de roupa/ocasião (para pastas onde só existem os .jpg com sufixo, ex.: "_Simples" vs "_Costurando")
            string coreCand = StripTrailingVariantQualifiers(!string.IsNullOrEmpty(cand.NormTitle) ? cand.NormTitle : cand.NormStem);
            string coreCandFromStem = StripTrailingVariantQualifiers(cand.NormStem);
            string coreSpecTitle = StripTrailingVariantQualifiers(specTitle);
            string coreSpecStem = StripTrailingVariantQualifiers(specStem);

            string[] candCores = new[] { coreCand, coreCandFromStem };
            for (int i = 0; i < candCores.Length; i++)
            {
                string cc = candCores[i];
                if (string.IsNullOrEmpty(cc) || cc.Length < 5) continue;

                // Evita casar núcleos curtos puramente genéricos sem qualificador
                if (Regex.IsMatch(cc, @"^(o homem|a mulher|o jovem|a jovem|o rapaz|a moca|o senhor|a senhora|o idoso|a idosa|o amigo|a amiga|la amiga|o vizinho|a vizinha|o vendedor)$"))
                    continue;

                if ((!string.IsNullOrEmpty(coreSpecTitle) && (coreSpecTitle == cc || coreSpecTitle.StartsWith(cc + " ", StringComparison.Ordinal))) ||
                    (!string.IsNullOrEmpty(coreSpecStem) && (coreSpecStem == cc || coreSpecStem.StartsWith(cc + " ", StringComparison.Ordinal))))
                {
                    return 760 + Math.Min(25, cc.Length);
                }
            }

            // 5. Pista explícita de continuidade ("mesmo rosto" / "do EP.1") + mesmo substantivo principal de arquétipo (ex.: "O Motorista do Leite" -> "O Motorista de Camisa Branca")
            if (hasContinuityCue)
            {
                string headSpec = ExtractLeadingSubstantiveHead(!string.IsNullOrEmpty(specTitle) ? specTitle : specStem);
                string headCand = ExtractLeadingSubstantiveHead(!string.IsNullOrEmpty(cand.NormTitle) ? cand.NormTitle : cand.NormStem);
                if (!string.IsNullOrEmpty(headSpec) && headSpec.Length >= 5 && string.Equals(headSpec, headCand, StringComparison.Ordinal))
                {
                    return 730 + Math.Min(20, headSpec.Length);
                }
            }

            return 0;
        }

        public static string FindExistingBaseCharacterPathForVariantSpec(EpisodeWorkItem ep, GrokAssetSpec spec)
        {
            if (ep == null || spec == null || spec.IsScenario) return "";

            int effectiveOrder = spec.OrderIndex;
            if (effectiveOrder <= 1 && ep.GrokSpecs != null && !string.IsNullOrEmpty(spec.TargetFileName))
            {
                GrokAssetSpec foundInEp = ep.GrokSpecs.FirstOrDefault(x =>
                    x != null && string.Equals(x.TargetFileName, spec.TargetFileName, StringComparison.OrdinalIgnoreCase));
                if (foundInEp != null && foundInEp.OrderIndex > 0)
                    effectiveOrder = foundInEp.OrderIndex;
            }

            List<StoryCharacterCandidate> candidates = CollectStoryCharacterCandidates(ep);
            StoryCharacterCandidate best = null;
            int bestScore = 0;

            for (int i = 0; i < candidates.Count; i++)
            {
                StoryCharacterCandidate cand = candidates[i];
                if (string.IsNullOrEmpty(cand.DiskPath) || !File.Exists(cand.DiskPath))
                    continue;

                int sc = ScoreCharacterContinuityMatch(spec, effectiveOrder, cand);
                if (sc <= 0)
                    continue;

                if (best == null)
                {
                    best = cand;
                    bestScore = sc;
                    continue;
                }

                // Sempre preferir arquivo base original sobre variante automática (__Roupa_)
                if (cand.IsAutoOutfitFile != best.IsAutoOutfitFile)
                {
                    if (!cand.IsAutoOutfitFile)
                    {
                        best = cand;
                        bestScore = sc;
                    }
                    continue;
                }

                // Se um deles teve referência explícita de Personagem/EP (score >= 1000), respeita o maior score explícito
                int candTier = sc / 100;
                int bestTier = bestScore / 100;
                if (candTier != bestTier)
                {
                    if (candTier > bestTier)
                    {
                        best = cand;
                        bestScore = sc;
                    }
                    continue;
                }

                if (candTier >= 10 && sc != bestScore)
                {
                    if (sc > bestScore)
                    {
                        best = cand;
                        bestScore = sc;
                    }
                    continue;
                }

                // Dentro do mesmo nível de confiança, prioriza o episódio mais antigo (original do EP.1) e menor índice de personagem
                if (cand.EpisodeNum != best.EpisodeNum)
                {
                    if (cand.EpisodeNum < best.EpisodeNum)
                    {
                        best = cand;
                        bestScore = sc;
                    }
                    continue;
                }

                if (cand.SpecOrderIndex != best.SpecOrderIndex)
                {
                    if (cand.SpecOrderIndex < best.SpecOrderIndex)
                    {
                        best = cand;
                        bestScore = sc;
                    }
                    continue;
                }

                if (sc > bestScore)
                {
                    best = cand;
                    bestScore = sc;
                }
            }

            return best != null ? best.DiskPath : "";
        }

        public static GrokAssetSpec FindBaseCharacterSpecInEpisode(EpisodeWorkItem ep, GrokAssetSpec spec)
        {
            if (ep == null || spec == null || spec.IsScenario || ep.GrokSpecs == null) return null;

            int effectiveOrder = spec.OrderIndex;
            if (effectiveOrder <= 0 && !string.IsNullOrEmpty(spec.TargetFileName))
            {
                GrokAssetSpec self = ep.GrokSpecs.FirstOrDefault(x =>
                    x != null && string.Equals(x.TargetFileName, spec.TargetFileName, StringComparison.OrdinalIgnoreCase));
                if (self != null) effectiveOrder = self.OrderIndex;
            }

            int curEpNum = ep.EpisodeNumber > 0 ? ep.EpisodeNumber : ParseEpisodeNumOrDefault(ep.EpisodeName, 1);
            GrokAssetSpec bestSpec = null;
            int bestScore = 0;

            foreach (GrokAssetSpec candSpec in ep.GrokSpecs)
            {
                if (candSpec == null || candSpec.IsScenario) continue;
                if (string.Equals(candSpec.TargetFileName, spec.TargetFileName, StringComparison.OrdinalIgnoreCase))
                    continue;
                if (effectiveOrder > 0 && candSpec.OrderIndex >= effectiveOrder)
                    continue;

                StoryCharacterCandidate cand = new StoryCharacterCandidate();
                cand.EpisodeNum = curEpNum;
                cand.IsPreviousEpisode = false;
                cand.SpecOrderIndex = candSpec.OrderIndex;
                cand.SpecRef = candSpec;
                cand.CharacterLabelId = ExtractCharacterLabelId(candSpec.LabelPrefix, candSpec.TargetFileName);
                cand.NormTitle = NormalizeForCompare(CleanDisplayTitleForContinuity(candSpec.DisplayTitle));
                cand.FileName = candSpec.TargetFileName ?? "";
                cand.NormStem = NormalizeForCompare(CleanAssetStem(GetBaseCharacterFileName(candSpec.TargetFileName)));
                cand.NormPromptLine = NormalizeForCompare(candSpec.RawPromptLine ?? "");
                cand.DiskPath = "";
                cand.IsAutoOutfitFile = false;

                int sc = ScoreCharacterContinuityMatch(spec, effectiveOrder, cand);
                if (sc > bestScore)
                {
                    bestScore = sc;
                    bestSpec = candSpec;
                }
            }

            return bestSpec;
        }

        public static string FindExistingBaseCharacterPathByNameInStory(EpisodeWorkItem ep, string charFileName)
        {
            if (ep == null || string.IsNullOrEmpty(charFileName)) return "";
            string cleanBase = GetBaseCharacterFileName(charFileName);

            if (!string.IsNullOrEmpty(ep.AssetsDir) && Directory.Exists(ep.AssetsDir))
            {
                string direct = Path.Combine(ep.AssetsDir, cleanBase);
                if (File.Exists(direct) && new FileInfo(direct).Length > 4 * 1024)
                    return direct;
            }

            List<StoryCharacterCandidate> candidates = CollectStoryCharacterCandidates(ep);
            StoryCharacterCandidate exact = candidates.FirstOrDefault(c =>
                !string.IsNullOrEmpty(c.DiskPath) &&
                File.Exists(c.DiskPath) &&
                string.Equals(Path.GetFileName(c.DiskPath), cleanBase, StringComparison.OrdinalIgnoreCase));
            if (exact != null)
                return exact.DiskPath;

            GrokAssetSpec synthetic = new GrokAssetSpec
            {
                OrderIndex = 999,
                IsScenario = IsScenarioAssetName(cleanBase),
                LabelPrefix = "Personagem",
                DisplayTitle = CleanAssetStem(cleanBase),
                TargetFileName = cleanBase,
                RawPromptLine = ""
            };
            return FindExistingBaseCharacterPathForVariantSpec(ep, synthetic);
        }

        public static string ResolveEffectiveIngredientForTake(EpisodeWorkItem ep, FlowTakeSpec take, string baseIngredient)
        {
            if (ep == null || take == null || string.IsNullOrEmpty(baseIngredient))
                return baseIngredient;

            if (IsScenarioAssetName(baseIngredient))
                return baseIngredient;

            // As roupas de cada ocasião são definidas diretamente no roteiro / pré-definição (PASSO 1 e PASSO 3).
            // Portanto, o programa usa diretamente o arquivo .jpg indicado no Take (ou eventual escolha manual no painel de Regerar Takes).
            if (take.CharacterOutfitOverrides != null)
            {
                string cleanBase = GetBaseCharacterFileName(baseIngredient);
                string manualChoice;
                if (take.CharacterOutfitOverrides.TryGetValue(cleanBase, out manualChoice) && !string.IsNullOrEmpty(manualChoice))
                {
                    if (!string.Equals(manualChoice, "BASE", StringComparison.OrdinalIgnoreCase) &&
                        !string.Equals(manualChoice, "AUTO", StringComparison.OrdinalIgnoreCase))
                    {
                        return manualChoice;
                    }
                }
            }

            return baseIngredient;
        }

        public static FlowTakeSpec GetEffectiveTakeSpec(EpisodeWorkItem ep, FlowTakeSpec take)
        {
            if (take == null) return null;
            FlowTakeSpec eff = take.Clone();
            if (ep == null || eff.Ingredients == null || eff.Ingredients.Count == 0)
                return eff;

            for (int i = 0; i < eff.Ingredients.Count; i++)
            {
                string origIng = eff.Ingredients[i];
                if (IsScenarioAssetName(origIng)) continue;

                string chosenIng = ResolveEffectiveIngredientForTake(ep, eff, origIng);
                if (!string.IsNullOrEmpty(chosenIng) && !string.Equals(origIng, chosenIng, StringComparison.OrdinalIgnoreCase))
                {
                    eff.Ingredients[i] = chosenIng;
                    if (!string.IsNullOrEmpty(eff.RawHeader))
                    {
                        eff.RawHeader = Regex.Replace(eff.RawHeader, Regex.Escape(origIng), chosenIng, RegexOptions.IgnoreCase);
                    }
                    if (!string.IsNullOrEmpty(eff.RawPromptBody))
                    {
                        eff.RawPromptBody = Regex.Replace(eff.RawPromptBody, Regex.Escape(origIng), chosenIng, RegexOptions.IgnoreCase);
                    }
                }
            }

            return eff;
        }

        public static List<FlowTakeSpec> GetEffectiveTakeSpecsForEpisode(EpisodeWorkItem ep)
        {
            List<FlowTakeSpec> list = new List<FlowTakeSpec>();
            if (ep == null || ep.FlowTakes == null) return list;
            for (int i = 0; i < ep.FlowTakes.Count; i++)
            {
                list.Add(GetEffectiveTakeSpec(ep, ep.FlowTakes[i]));
            }
            return list;
        }

        public static string GetCustomTakesConfigPath(EpisodeWorkItem ep)
        {
            if (ep == null || string.IsNullOrEmpty(ep.EpisodePath)) return "";
            return Path.Combine(ep.EpisodePath, "custom_takes_config.json");
        }

        public static void SaveEpisodeCustomTakesConfig(EpisodeWorkItem ep)
        {
            if (ep == null || string.IsNullOrEmpty(ep.EpisodePath) || ep.FlowTakes == null) return;
            try
            {
                Dictionary<string, object> root = new Dictionary<string, object>();
                List<Dictionary<string, object>> takesList = new List<Dictionary<string, object>>();

                foreach (FlowTakeSpec t in ep.FlowTakes)
                {
                    Dictionary<string, object> td = new Dictionary<string, object>();
                    td["TakeNumber"] = t.TakeNumber;
                    td["PreferredEngine"] = t.PreferredEngine ?? "Auto";
                    td["DurationText"] = string.IsNullOrWhiteSpace(t.DurationText) ? "10s" : t.DurationText.Trim();
                    td["RawPromptBody"] = t.RawPromptBody ?? "";
                    td["CharacterOutfitOverrides"] = t.CharacterOutfitOverrides ?? new Dictionary<string, string>();
                    takesList.Add(td);
                }

                root["Takes"] = takesList;
                JavaScriptSerializer ser = new JavaScriptSerializer();
                ser.MaxJsonLength = int.MaxValue;
                string json = ser.Serialize(root);
                File.WriteAllText(GetCustomTakesConfigPath(ep), json, new UTF8Encoding(false));
            }
            catch { }
        }

        public static void LoadEpisodeCustomTakesConfig(EpisodeWorkItem ep)
        {
            if (ep == null || string.IsNullOrEmpty(ep.EpisodePath) || ep.FlowTakes == null) return;
            try
            {
                string path = GetCustomTakesConfigPath(ep);
                if (!File.Exists(path)) return;

                string json = File.ReadAllText(path, Encoding.UTF8);
                JavaScriptSerializer ser = new JavaScriptSerializer();
                ser.MaxJsonLength = int.MaxValue;
                Dictionary<string, object> root = ser.Deserialize<Dictionary<string, object>>(json);
                if (root == null || !root.ContainsKey("Takes")) return;

                IEnumerable takesArr = root["Takes"] as IEnumerable;
                if (takesArr == null) return;

                foreach (object item in takesArr)
                {
                    Dictionary<string, object> td = item as Dictionary<string, object>;
                    if (td == null || !td.ContainsKey("TakeNumber")) continue;
                    int tNum = Convert.ToInt32(td["TakeNumber"]);

                    FlowTakeSpec target = ep.FlowTakes.FirstOrDefault(x => x.TakeNumber == tNum);
                    if (target == null) continue;

                    if (td.ContainsKey("PreferredEngine"))
                        target.PreferredEngine = Convert.ToString(td["PreferredEngine"] ?? "Auto");

                    if (td.ContainsKey("DurationText"))
                    {
                        string customDur = Convert.ToString(td["DurationText"] ?? "").Trim();
                        if (!string.IsNullOrEmpty(customDur))
                            target.DurationText = customDur;
                    }

                    if (td.ContainsKey("RawPromptBody"))
                    {
                        string customBody = Convert.ToString(td["RawPromptBody"] ?? "").Trim();
                        if (!string.IsNullOrEmpty(customBody))
                            target.RawPromptBody = customBody;
                    }

                    if (td.ContainsKey("CharacterOutfitOverrides") && td["CharacterOutfitOverrides"] is Dictionary<string, object>)
                    {
                        Dictionary<string, object> ov = (Dictionary<string, object>)td["CharacterOutfitOverrides"];
                        foreach (KeyValuePair<string, object> kv in ov)
                        {
                            string val = Convert.ToString(kv.Value ?? "").Trim();
                            if (!string.IsNullOrEmpty(kv.Key) && !string.IsNullOrEmpty(val))
                                target.CharacterOutfitOverrides[kv.Key] = val;
                        }
                    }
                }
            }
            catch { }
        }
    }
}
