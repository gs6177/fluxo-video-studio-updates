param(
    [Parameter(Mandatory=$true)]
    [string]$FolderPath,

    [double]$TopCropRatio = 0.26
)

$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Runtime.WindowsRuntime
Add-Type -AssemblyName System.Drawing

$null = [Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType = WindowsRuntime]
$null = [Windows.Graphics.Imaging.BitmapDecoder, Windows.Foundation, ContentType = WindowsRuntime]
$null = [Windows.Graphics.Imaging.SoftwareBitmap, Windows.Foundation, ContentType = WindowsRuntime]
$null = [Windows.Storage.StorageFile, Windows.Foundation, ContentType = WindowsRuntime]
$null = [Windows.Storage.FileAccessMode, Windows.Foundation, ContentType = WindowsRuntime]
$null = [Windows.Globalization.Language, Windows.Foundation, ContentType = WindowsRuntime]

$asTaskMethods = [System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
    $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1'
}
$asTaskGeneric = $asTaskMethods | Select-Object -First 1

function Await-WinRT($WinRtTask, [Type]$ResultType) {
    $netTask = $asTaskGeneric.MakeGenericMethod($ResultType).Invoke($null, @($WinRtTask))
    $netTask.Wait() | Out-Null
    return $netTask.Result
}

$lang = New-Object Windows.Globalization.Language("pt-BR")
$engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage($lang)
if ($null -eq $engine) {
    $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages()
}

$tempCropDir = Join-Path $env:TEMP ("grok_ocr_crops_" + [guid]::NewGuid().ToString("N").Substring(0, 8))
New-Item -ItemType Directory -Force -Path $tempCropDir | Out-Null

$results = @()

try {
    $files = Get-ChildItem -Path $FolderPath -File | Where-Object { $_.Extension -match '^\.(jpg|jpeg|png|webp)$' } | Sort-Object LastWriteTime, Name
    foreach ($f in $files) {
        $detected = ""
        try {
            $cropPath = Join-Path $tempCropDir ($f.BaseName + "_top.png")
            $srcImg = [System.Drawing.Image]::FromFile($f.FullName)
            try {
                $cropH = [Math]::Max(60, [int]([Math]::Round($srcImg.Height * $TopCropRatio)))
                $cropW = $srcImg.Width
                $bmp = New-Object System.Drawing.Bitmap($cropW, $cropH)
                try {
                    $g = [System.Drawing.Graphics]::FromImage($bmp)
                    try {
                        $srcRect = New-Object System.Drawing.Rectangle(0, 0, $cropW, $cropH)
                        $dstRect = New-Object System.Drawing.Rectangle(0, 0, $cropW, $cropH)
                        $g.DrawImage($srcImg, $dstRect, $srcRect, [System.Drawing.GraphicsUnit]::Pixel)
                    } finally {
                        $g.Dispose()
                    }
                    $bmp.Save($cropPath, [System.Drawing.Imaging.ImageFormat]::Png)
                } finally {
                    $bmp.Dispose()
                }
            } finally {
                $srcImg.Dispose()
            }

            $storageFile = Await-WinRT ([Windows.Storage.StorageFile]::GetFileFromPathAsync($cropPath)) ([Windows.Storage.StorageFile])
            $stream = Await-WinRT ($storageFile.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
            try {
                $decoder = Await-WinRT ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
                $softBmp = Await-WinRT ($decoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
                $ocrRes = Await-WinRT ($engine.RecognizeAsync($softBmp)) ([Windows.Media.Ocr.OcrResult])
                if ($null -ne $ocrRes -and $null -ne $ocrRes.Text) {
                    $detected = $ocrRes.Text.Trim()
                }
            } finally {
                $stream.Dispose()
            }
        } catch {
            $detected = ""
        }

        $results += [PSCustomObject]@{
            FileName = $f.Name
            FullPath = $f.FullName
            OcrText  = $detected
        }
    }
} finally {
    Remove-Item -Path $tempCropDir -Recurse -Force -ErrorAction SilentlyContinue
}

$json = $results | ConvertTo-Json -Depth 4 -Compress
if ($results.Count -eq 1) {
    $json = "[$json]"
} elseif ($results.Count -eq 0) {
    $json = "[]"
}
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
Write-Output $json
