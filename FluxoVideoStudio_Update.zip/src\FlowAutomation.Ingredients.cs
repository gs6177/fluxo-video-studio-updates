using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace FluxoVideoStudio
{
    public partial class FlowAutomation
    {
        private async Task TryGenerateRemainingTakesInFlowWithRetryAndSkipAsync(
            EpisodeWorkItem ep,
            List<FlowTakeSpec> remainingTakes,
            List<string> allAssetFiles,
            Dictionary<string, string> ingredientToResolvedName,
            HashSet<int> skippedTakeNumbersOut,
            CancellationToken ct)
        {
            if (remainingTakes == null || remainingTakes.Count == 0)
                return;

            string sess = await OpenAndPrepareFlowProjectTabAsync(ct);
            await EnsureAgentPanelOpenAsync(sess, ct);
            await ScrollAgentPanelToBottomAsync(sess, ct);

            List<string> neededRemAssets = FilterAssetFilesForTakes(allAssetFiles, remainingTakes, ingredientToResolvedName);
            await UploadAssetsToFlowProjectAsync(sess, neededRemAssets.Count > 0 ? neededRemAssets : allAssetFiles, ct);

            string stagingDl = Path.Combine(Path.GetTempPath(), "fluxo_dl_rem_" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(stagingDl);
            await _cdp.SetDownloadBehaviorAsync(stagingDl, ct);

            try
            {
                for (int i = 0; i < remainingTakes.Count; i++)
                {
                    ct.ThrowIfCancellationRequested();
                    FlowTakeSpec spec = remainingTakes[i];
                    string dstMp4 = Path.Combine(ep.TakesDir, string.Format("Take_{0:00}.mp4", spec.TakeNumber));
                    if (File.Exists(dstMp4) && new FileInfo(dstMp4).Length >= 50 * 1024)
                        continue;

                    bool generated = false;
                    for (int attempt = 1; attempt <= 2; attempt++)
                    {
                        ct.ThrowIfCancellationRequested();

                        await ClearAttachedPromptChipsAsync(sess, ct);
                        string curTxt = await ReadCurrentFlowTextboxAsync(sess, ct);
                        if (!string.IsNullOrWhiteSpace(curTxt))
                        {
                            await InsertTextIntoFlowTextboxAsync(sess, "", true, ct);
                            await Task.Delay(350, ct);
                        }

                        List<string> resolvedTakeIngs = new List<string>();
                        foreach (string rawIng in spec.Ingredients)
                        {
                            string resName;
                            if (!ingredientToResolvedName.TryGetValue(rawIng, out resName))
                                resName = rawIng;
                            if (!resolvedTakeIngs.Contains(resName, StringComparer.OrdinalIgnoreCase))
                                resolvedTakeIngs.Add(resName);
                        }

                        if (resolvedTakeIngs.Count > 0)
                        {
                            HashSet<string> attachedTmp = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                            await AttachIngredientsViaMenuAsync(sess, resolvedTakeIngs, attachedTmp, ct);
                            await WaitForAttachedPromptChipsImagesLoadedAsync(sess, ct);
                        }

                        string singleBlock = BuildFlowPromptForTakes("", new List<FlowTakeSpec> { spec });
                        if (attempt == 2)
                        {
                            singleBlock = SoftenPromptForSecondAttempt(singleBlock);
                        }

                        string singleCmd =
                            "Gere imediatamente em vídeo 9:16 o take abaixo usando os ingredientes anexados. " +
                            "Mantenha obrigatoriamente a tag [TAKE_" + spec.TakeNumber.ToString("00") + "] no início do prompt do vídeo:\n\n" +
                            singleBlock;

                        if (attempt == 1)
                            _log(string.Format("[Google Flow | Sem Créditos Grok] Tentando gerar Take_{0:00} no Google Flow (1ª tentativa)...", spec.TakeNumber));
                        else
                            _log(string.Format("[Google Flow | Sem Créditos Grok] Take_{0:00} falhou na 1ª tentativa -> 2ª tentativa com suavização anti-bloqueio...", spec.TakeNumber));

                        PreSessionGridBaseline singleBase = await CapturePreSessionBaselineAsync(sess, ct);
                        await InsertTextIntoFlowTextboxAsync(sess, singleCmd, false, ct);
                        await WaitRandomFlowActionDelayAsync(string.Format("após colar comando do Take_{0:00}", spec.TakeNumber), ct);
                        await ClickStartGenerationAsync(sess, ct);

                        try
                        {
                            SessionPollSnapshot snap = await WaitForCurrentBatchToFinishAsync(
                                sess,
                                singleBase,
                                92 + attempt,
                                1,
                                0,
                                0,
                                ct);

                            if (snap.CompletedCards > 0)
                            {
                                await DownloadAllCompletedTakesIn720pAsync(sess, singleBase, ep, new List<FlowTakeSpec> { spec }, ct);
                            }
                            else if (snap.FailedCards > 0)
                            {
                                await ClickFailedTileActionButtonAsync(sess, 0, Math.Max(4, snap.SessionSliceEndIndex), true, false, ct);
                                await Task.Delay(400, ct);
                            }
                        }
                        catch (OperationCanceledException)
                        {
                            throw;
                        }
                        catch (Exception ex)
                        {
                            _log(string.Format("[Google Flow | Aviso] Falha ao aguardar tentativa {0} do Take_{1:00} ({2}).", attempt, spec.TakeNumber, ex.Message));
                        }

                        if (File.Exists(dstMp4) && new FileInfo(dstMp4).Length >= 50 * 1024)
                        {
                            generated = true;
                            _log(string.Format("[Google Flow | Sem Créditos Grok] ✔ Take_{0:00}.mp4 gerado e salvo com sucesso no Google Flow!", spec.TakeNumber));
                            break;
                        }
                    }

                    if (!generated)
                    {
                        if (skippedTakeNumbersOut != null)
                            skippedTakeNumbersOut.Add(spec.TakeNumber);
                        _log(string.Format("[Google Flow | Cena Pulada] Take_{0:00} não foi gerado após 1ª tentativa e 2ª tentativa suavizada (e todas as contas Grok estão sem créditos) -> pulando cena e continuando!", spec.TakeNumber));
                    }
                }
            }
            finally
            {
                Task ignoredCleanup = Task.Run(async () =>
                {
                    try { await _cdp.ResetDownloadBehaviorToDefaultAsync(); } catch { }
                    try { Directory.Delete(stagingDl, true); } catch { }
                });
            }
        }

        private void PrepareAndResolveEpisodeAssetsForFlow(
            EpisodeWorkItem ep,
            out List<string> allTempAssetPaths,
            out Dictionary<string, string> ingredientToResolvedName)
        {
            allTempAssetPaths = new List<string>();
            ingredientToResolvedName = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

            EpisodeParser.SyncRecurringAssetsFromPreviousEpisodes(ep, _log);
            EpisodeParser.AutoAlignImportedAssetsOnDisk(ep, _log);

            if (!Directory.Exists(_config.TempFlowAssetsDir))
                Directory.CreateDirectory(_config.TempFlowAssetsDir);

            List<string> diskAssets = new List<string>();
            if (Directory.Exists(ep.AssetsDir))
            {
                diskAssets = Directory.GetFiles(ep.AssetsDir)
                    .Where(f => Regex.IsMatch(Path.GetExtension(f), @"^\.(jpg|jpeg|png)$", RegexOptions.IgnoreCase) && new FileInfo(f).Length > 1024)
                    .OrderBy(f => Path.GetFileName(f))
                    .ToList();
            }

            HashSet<string> addedTempPaths = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            HashSet<string> mappedDiskSources = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            // 1. Espelha 100% dos arquivos de imagem presentes na pasta assets\ do episódio
            foreach (string srcPath in diskAssets)
            {
                string fn = Path.GetFileName(srcPath);
                string dstTemp = Path.Combine(_config.TempFlowAssetsDir, fn);
                File.Copy(srcPath, dstTemp, true);
            }

            // 2. Resolve 100% dos ingredientes exigidos em prompt_flow_passo3.txt (incluindo mapeamento por similaridade quando o nome no prompt difere do disco)
            foreach (string reqIng in ep.AllRequiredFlowIngredients)
            {
                string exactDisk = diskAssets.FirstOrDefault(f =>
                    string.Equals(Path.GetFileName(f), reqIng, StringComparison.OrdinalIgnoreCase));

                if (!string.IsNullOrEmpty(exactDisk))
                {
                    mappedDiskSources.Add(exactDisk);
                    string actualName = Path.GetFileName(exactDisk);
                    string tempPath = Path.Combine(_config.TempFlowAssetsDir, actualName);
                    ingredientToResolvedName[reqIng] = actualName;
                    if (addedTempPaths.Add(tempPath))
                        allTempAssetPaths.Add(tempPath);
                }
                else
                {
                    string fuzzyDisk = EpisodeParser.FindMatchingDiskAssetFile(reqIng, diskAssets);
                    if (!string.IsNullOrEmpty(fuzzyDisk))
                    {
                        mappedDiskSources.Add(fuzzyDisk);
                        // Cria cópia com o nome exato esperado pelo prompt_flow_passo3.txt em Temp\flow_assets
                        string aliasTempPath = Path.Combine(_config.TempFlowAssetsDir, reqIng);
                        File.Copy(fuzzyDisk, aliasTempPath, true);
                        ingredientToResolvedName[reqIng] = reqIng;
                        if (addedTempPaths.Add(aliasTempPath))
                            allTempAssetPaths.Add(aliasTempPath);

                        _log(string.Format("[Google Flow | Assets] Mapeado asset equivalente do disco '{0}' -> '{1}'",
                            Path.GetFileName(fuzzyDisk), reqIng));
                    }
                    else
                    {
                        // Tenta verificar se já existe em Temp\flow_assets de execução anterior
                        string fallbackTemp = Path.Combine(_config.TempFlowAssetsDir, reqIng);
                        if (File.Exists(fallbackTemp) && new FileInfo(fallbackTemp).Length > 1024)
                        {
                            ingredientToResolvedName[reqIng] = reqIng;
                            if (addedTempPaths.Add(fallbackTemp))
                                allTempAssetPaths.Add(fallbackTemp);
                        }
                        else
                        {
                            _log(string.Format("[Google Flow | Aviso] Ingrediente '{0}' citado no roteiro não foi encontrado em '{1}'.",
                                reqIng, ep.AssetsDir));
                        }
                    }
                }
            }

            // 3. Inclui também quaisquer outros personagens e cenários presentes em ep.AssetsDir que ainda não tenham sido mapeados (garantindo que NENHUM personagem ou cenário da pasta fique de fora sem duplicar aliases)
            foreach (string srcPath in diskAssets)
            {
                if (mappedDiskSources.Contains(srcPath)) continue;
                string fn = Path.GetFileName(srcPath);
                string tempPath = Path.Combine(_config.TempFlowAssetsDir, fn);
                if (addedTempPaths.Add(tempPath))
                {
                    allTempAssetPaths.Add(tempPath);
                }
            }
        }

        private List<string> GetRequiredIngredientsForRange(
            List<FlowTakeSpec> targetTakes,
            Dictionary<string, string> ingredientToResolvedName,
            int startTakeIndex,
            int count)
        {
            List<string> list = new List<string>();
            HashSet<string> seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            int end = Math.Min(targetTakes.Count, startTakeIndex + count);
            for (int i = Math.Max(0, startTakeIndex); i < end; i++)
            {
                foreach (string rawIng in targetTakes[i].Ingredients)
                {
                    string resolved;
                    if (!ingredientToResolvedName.TryGetValue(rawIng, out resolved))
                        resolved = rawIng;

                    if (seen.Add(resolved))
                        list.Add(resolved);
                }
            }
            return list;
        }

        private List<string> ResolveStrictIngredientsForSingleTake(
            FlowTakeSpec spec,
            List<string> allTempAssetPaths,
            Dictionary<string, string> ingredientToResolvedName)
        {
            List<string> result = new List<string>();
            if (spec == null || spec.Ingredients == null || spec.Ingredients.Count == 0)
                return result;

            HashSet<string> availableSet = new HashSet<string>(
                (allTempAssetPaths ?? new List<string>()).Select(Path.GetFileName),
                StringComparer.OrdinalIgnoreCase);
            HashSet<string> seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            // Personagens da cena primeiro, depois cenários da cena
            for (int pass = 0; pass < 2; pass++)
            {
                for (int i = 0; i < spec.Ingredients.Count; i++)
                {
                    string rawIng = spec.Ingredients[i];
                    string resolved;
                    if (ingredientToResolvedName == null || !ingredientToResolvedName.TryGetValue(rawIng, out resolved) || string.IsNullOrEmpty(resolved))
                        resolved = rawIng;

                    if (availableSet.Count > 0 && !availableSet.Contains(resolved))
                        continue;

                    bool isScenario = EpisodeParser.IsScenarioAssetName(resolved);
                    if ((pass == 0 && !isScenario) || (pass == 1 && isScenario))
                    {
                        if (seen.Add(resolved))
                            result.Add(resolved);
                    }
                }
            }

            return result;
        }

        private List<string> FilterAssetFilesForTakes(
            List<string> allTempAssetPaths,
            List<FlowTakeSpec> targetTakes,
            Dictionary<string, string> ingredientToResolvedName)
        {
            List<string> filtered = new List<string>();
            if (allTempAssetPaths == null || allTempAssetPaths.Count == 0 || targetTakes == null || targetTakes.Count == 0)
                return filtered;

            List<string> reqNames = GetRequiredIngredientsForRange(targetTakes, ingredientToResolvedName ?? new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase), 0, targetTakes.Count);
            HashSet<string> reqSet = new HashSet<string>(reqNames, StringComparer.OrdinalIgnoreCase);

            for (int i = 0; i < allTempAssetPaths.Count; i++)
            {
                string p = allTempAssetPaths[i];
                string fn = Path.GetFileName(p);
                if (reqSet.Contains(fn))
                    filtered.Add(p);
            }

            return filtered;
        }

        private List<string> BuildOrderedIngredientsForEpisode(
            EpisodeWorkItem ep,
            List<FlowTakeSpec> targetTakes,
            List<string> allTempAssetPaths,
            Dictionary<string, string> ingredientToResolvedName,
            int startTakeIndex,
            int batchSize)
        {
            List<string> ordered = new List<string>();
            HashSet<string> seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            List<string> allAvailableNames = allTempAssetPaths.Select(Path.GetFileName).ToList();
            HashSet<string> availableSet = new HashSet<string>(allAvailableNames, StringComparer.OrdinalIgnoreCase);

            // Considera EXCLUSIVAMENTE os elementos usados nos takes que realmente serão gerados (targetTakes),
            // para que ao regerar/retomar 1 cena (ou um subconjunto de cenas) nunca sejam anexados elementos de cenas já concluídas!
            List<string> allTargetRequired = GetRequiredIngredientsForRange(targetTakes, ingredientToResolvedName, 0, targetTakes.Count);
            if (allTargetRequired.Count == 0 && targetTakes.Count >= ep.FlowTakes.Count)
            {
                allTargetRequired = new List<string>(ep.AllRequiredFlowIngredients);
            }

            // 1. Personagens efetivamente usados nos takes alvo
            foreach (string resolved in allTargetRequired)
            {
                if (!availableSet.Contains(resolved)) continue;
                if (!EpisodeParser.IsScenarioAssetName(resolved) && seen.Add(resolved))
                    ordered.Add(resolved);
            }

            // 2. Cenários (e ingredientes) dos primeiros takes do lote atual
            foreach (string batchIng in GetRequiredIngredientsForRange(targetTakes, ingredientToResolvedName, startTakeIndex, batchSize))
            {
                if (availableSet.Contains(batchIng) && seen.Add(batchIng))
                    ordered.Add(batchIng);
            }

            // 3. Demais cenários exigidos nos demais takes alvo desta execução (apenas se houver múltiplos lotes)
            foreach (string resolved in allTargetRequired)
            {
                if (availableSet.Contains(resolved) && seen.Add(resolved))
                    ordered.Add(resolved);
            }

            return ordered;
        }

        private List<string> BuildSupplementIngredientsForBatch(
            List<string> allTempAssetPaths,
            List<string> nextBatchRequired,
            HashSet<string> alreadyAttachedInSession)
        {
            List<string> ordered = new List<string>();
            HashSet<string> seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            HashSet<string> availableSet = new HashSet<string>(
                (allTempAssetPaths ?? new List<string>()).Select(Path.GetFileName),
                StringComparer.OrdinalIgnoreCase);

            // 1. Ingredientes inéditos obrigatórios neste lote que ainda não entraram na sessão
            foreach (string req in nextBatchRequired)
            {
                if (availableSet.Contains(req) && !alreadyAttachedInSession.Contains(req) && seen.Add(req))
                    ordered.Add(req);
            }

            // 2. Todos os elementos efetivamente usados neste lote (personagens + cenários do lote)
            foreach (string req in nextBatchRequired)
            {
                if (availableSet.Contains(req) && seen.Add(req))
                    ordered.Add(req);
            }

            return ordered;
        }


        private async Task<Dictionary<string, object>> QuickCheckAssetInSearchFieldAsync(
            string sess,
            string searchStem,
            string fullFileName,
            CancellationToken ct)
        {
            string query = !string.IsNullOrWhiteSpace(searchStem) ? searchStem.Trim() : (fullFileName ?? "").Trim();
            if (string.IsNullOrEmpty(query))
                return null;

            string b64Stem = Convert.ToBase64String(Encoding.UTF8.GetBytes(searchStem ?? ""));
            string b64Full = Convert.ToBase64String(Encoding.UTF8.GetBytes(fullFileName ?? ""));

            string checkJs = string.Format(@"
(function(){{
    var wantStem = new TextDecoder('utf-8').decode(Uint8Array.from(atob('{0}'), c => c.charCodeAt(0))).trim().toLowerCase();
    var wantFull = new TextDecoder('utf-8').decode(Uint8Array.from(atob('{1}'), c => c.charCodeAt(0))).trim().toLowerCase();
    var inp = document.querySelector('.cdk-overlay-container input.search-input');
    var curQueryLen = inp ? (inp.value || '').trim().length : 0;

    var items = Array.from(document.querySelectorAll('.cdk-overlay-container button.asset-item, .cdk-overlay-container [class*=""asset-item""]'))
        .filter(el => el.tagName === 'BUTTON' || el.getAttribute('role') === 'option')
        .filter(el => el.getBoundingClientRect().width > 12);

    var chosen = items.find(el => {{
        var rawTxt = (el.innerText || '').trim().toLowerCase();
        var rawAria = (el.getAttribute('aria-label') || '').trim().toLowerCase();
        var combined = rawTxt + ' ' + rawAria;
        return rawTxt === wantFull || rawTxt === wantStem ||
               rawAria === wantFull || rawAria === wantStem ||
               (wantFull.length > 0 && combined.indexOf(wantFull) >= 0) ||
               (wantStem.length > 0 && combined.indexOf(wantStem) >= 0);
    }});

    if (!chosen) {{
        return JSON.stringify({{ found: false, itemCount: items.length, curQueryLen: curQueryLen }});
    }}

    var img = chosen.querySelector('img.asset-thumbnail-image') || chosen.querySelector('img');
    var imgSrc = img ? ((img.currentSrc || img.src || img.getAttribute('src') || '')) : '';
    var hasSpinner = !!chosen.querySelector('mat-progress-spinner, mat-spinner, [role=""progressbar""], [class*=""uploading""]');
    var imgReady = !hasSpinner && !!img && imgSrc.length > 12 && !!img.complete && (img.naturalWidth || 0) > 0;

    return JSON.stringify({{
        found: true,
        imgReady: imgReady,
        hasSpinner: hasSpinner,
        curQueryLen: curQueryLen,
        matchedText: (chosen.innerText || '').trim()
    }});
}})()", b64Stem, b64Full);

            // 1. Se o campo de busca estiver vazio e a imagem já estiver visível nos 15 itens recentes, retorna sem nenhuma mutação de DOM!
            Dictionary<string, object> directRes = await _cdp.EvalJsonAsync(sess, checkJs, ct);
            if (directRes != null &&
                directRes.ContainsKey("found") && Convert.ToBoolean(directRes["found"]) &&
                Convert.ToInt32(directRes.ContainsKey("curQueryLen") ? directRes["curQueryLen"] : 0) == 0)
            {
                return directRes;
            }

            // 2. Caso não esteja nos recentes visíveis, pesquisa no campo "Pesquisar recursos" usando execCommand('insertText') nativo
            string setRes = await SetOverlaySearchQueryAsync(sess, query, ct);
            if (setRes == "NO_INPUT")
                return null;

            for (int poll = 0; poll < 3; poll++)
            {
                await Task.Delay(poll == 0 ? 350 : 250, ct);
                Dictionary<string, object> res = await _cdp.EvalJsonAsync(sess, checkJs, ct);
                if (res != null && res.ContainsKey("found") && Convert.ToBoolean(res["found"]))
                {
                    return res;
                }
                if (poll == 0 && res != null && res.ContainsKey("itemCount") && Convert.ToInt32(res["itemCount"]) == 0)
                {
                    break;
                }
            }

            return null;
        }

        private async Task UploadAssetsToFlowProjectAsync(string sess, List<string> tempAssetPaths, CancellationToken ct)
        {
            if (tempAssetPaths == null || tempAssetPaths.Count == 0) return;

            await ToggleAddElementsMenuAsync(sess, true, ct);
            await EnsureImagesTabInOverlayAsync(sess, ct);
            await WaitForOverlayImagesLibraryLoadedAsync(sess, ct);

            // Verifica rápida e diretamente cada imagem digitando no campo "Pesquisar recursos" da aba "Imagens" (sem rolar lista nem trocar de aba!)
            List<string> toUpload = new List<string>();
            for (int chkIdx = 0; chkIdx < tempAssetPaths.Count; chkIdx++)
            {
                ct.ThrowIfCancellationRequested();
                if (chkIdx > 0)
                {
                    await WaitRandomFlowActionDelayAsync(string.Format("entre pesquisas de imagem ({0}/{1})", chkIdx + 1, tempAssetPaths.Count), ct);
                    await ToggleAddElementsMenuAsync(sess, true, ct);
                    await EnsureImagesTabInOverlayAsync(sess, ct);
                }

                string assetPath = tempAssetPaths[chkIdx];
                string fileName = Path.GetFileName(assetPath);
                string stem = Path.GetFileNameWithoutExtension(assetPath);

                Dictionary<string, object> existingMatch = await QuickCheckAssetInSearchFieldAsync(sess, stem, fileName, ct);
                if (existingMatch == null)
                {
                    toUpload.Add(assetPath);
                }
            }

            await ClearOverlaySearchInputAsync(sess, ct);

            if (toUpload.Count > 0)
            {
                string namesSummary = string.Join(", ", toUpload.Select(Path.GetFileName));
                _log(string.Format("[Google Flow] Fazendo upload de {0} novas imagens de personagens/cenários via 'Enviar mídia': {1}",
                    toUpload.Count, namesSummary));

                bool uploaded = await _cdp.UploadFilesViaFileChooserAsync(
                    sess,
                    async () => await ClickOverlayUploadButtonAsync(sess, ct),
                    toUpload,
                    ct);

                if (!uploaded)
                {
                    // Fallback: tenta input[type="file"] direto caso o DOM tenha anexado algum
                    uploaded = await _cdp.SetFileInputFilesAsync(sess, "input[type=\"file\"]", toUpload, ct);
                }

                if (uploaded)
                {
                    // Aguarda todas as imagens enviadas terminarem 100% o upload e confirma rapidamente pelo campo "Pesquisar recursos" na aba "Imagens"
                    await Task.Delay(3000, ct);
                    DateTime uploadDeadline = DateTime.UtcNow.AddSeconds(Math.Min(600, 60 + (toUpload.Count * 35)));
                    List<string> pendingCheck = new List<string>(toUpload);
                    int lastReadyLogged = -1;

                    while (DateTime.UtcNow < uploadDeadline && pendingCheck.Count > 0)
                    {
                        ct.ThrowIfCancellationRequested();
                        await Task.Delay(1500, ct);
                        await ToggleAddElementsMenuAsync(sess, true, ct);
                        await EnsureImagesTabInOverlayAsync(sess, ct);

                        string overlayBusy = await _cdp.EvalStringAsync(sess, @"
(function(){
    var sp = Array.from(document.querySelectorAll(
        '.cdk-overlay-container mat-progress-spinner, .cdk-overlay-container mat-spinner, .cdk-overlay-container [role=""progressbar""], .cdk-overlay-container [class*=""uploading""]'
    )).filter(el => el.getBoundingClientRect().width > 4);
    return sp.length > 0 ? 'BUSY' : 'IDLE';
})()", ct);

                        if (overlayBusy == "BUSY")
                            continue;

                        List<string> stillPending = new List<string>();
                        for (int upIdx = 0; upIdx < pendingCheck.Count; upIdx++)
                        {
                            if (upIdx > 0)
                            {
                                await WaitRandomFlowActionDelayAsync(string.Format("entre pesquisas de confirmação ({0}/{1})", upIdx + 1, pendingCheck.Count), ct);
                                await ToggleAddElementsMenuAsync(sess, true, ct);
                                await EnsureImagesTabInOverlayAsync(sess, ct);
                            }

                            string upFile = pendingCheck[upIdx];
                            string fn = Path.GetFileName(upFile);
                            string st = Path.GetFileNameWithoutExtension(upFile);
                            Dictionary<string, object> found = await QuickCheckAssetInSearchFieldAsync(sess, st, fn, ct);
                            bool isImgReady = found != null && found.ContainsKey("imgReady") && Convert.ToBoolean(found["imgReady"]);
                            if (!isImgReady)
                            {
                                stillPending.Add(upFile);
                            }
                        }
                        pendingCheck = stillPending;

                        int readyNow = toUpload.Count - pendingCheck.Count;
                        if (readyNow != lastReadyLogged && pendingCheck.Count > 0)
                        {
                            lastReadyLogged = readyNow;
                            _log(string.Format("[Google Flow] Monitorando carregamento das imagens enviadas: {0}/{1} carregadas...",
                                readyNow, toUpload.Count));
                        }
                    }

                    await ClearOverlaySearchInputAsync(sess, ct);
                    await Task.Delay(1500, ct);
                    int indexedCount = toUpload.Count - pendingCheck.Count;
                    _log(string.Format("[Google Flow] Upload confirmado e imagens carregadas na aba Imagens: {0}/{1} novos arquivos prontos!",
                        indexedCount, toUpload.Count));
                }
                else
                {
                    _log("[Google Flow] Aviso: não foi possível acionar o seletor de upload ('Enviar mídia') no menu '+'.");
                }
            }
            else
            {
                _log(string.Format("[Google Flow] Todos os {0} personagens e cenários já estão presentes na aba 'Imagens' do projeto!", tempAssetPaths.Count));
            }

            await WaitRandomFlowActionDelayAsync("após verificar imagens na biblioteca", ct);
        }

        private async Task ClickOverlayUploadButtonAsync(string sess, CancellationToken ct)
        {
            await ToggleAddElementsMenuAsync(sess, true, ct);

            Dictionary<string, object> upPt = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var b = Array.from(document.querySelectorAll('.cdk-overlay-container .sidebar-upload-btn, .cdk-overlay-container button')).find(el => {
        var txt = (el.innerText || '');
        var al = (el.getAttribute('aria-label') || '');
        var r = el.getBoundingClientRect();
        return r.width > 10 && r.height > 10 &&
               (el.className.indexOf('sidebar-upload-btn') >= 0 || txt.indexOf('Enviar m') >= 0 || txt.indexOf('Upload') >= 0 || al.indexOf('Enviar m') >= 0);
    });
    if (!b) return null;
    var r = b.getBoundingClientRect();
    return JSON.stringify({ x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) });
})()", ct);

            if (upPt == null)
                throw new InvalidOperationException("Botão 'Enviar mídia' (.sidebar-upload-btn) não encontrado no menu '+' do Google Flow.");

            await _cdp.ClickAtAsync(sess, Convert.ToInt32(upPt["x"]), Convert.ToInt32(upPt["y"]), ct);
        }

        private async Task ToggleAddElementsMenuAsync(string sess, bool wantOpen, CancellationToken ct)
        {
            // Regra 25 e 31: NUNCA scrollIntoView() e NUNCA clicar em close (1499,100)
            Dictionary<string, object> info = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var isOpen = !!Array.from(document.querySelectorAll(
        '.cdk-overlay-container .side-nav-list-item, .cdk-overlay-container input.search-input, .cdk-overlay-container .detail-add-to-prompt-btn, .cdk-overlay-container .sidebar-upload-btn'
    )).find(el => el.getBoundingClientRect().width > 10);

    function findPlus(root) {
        return Array.from(root.querySelectorAll('button')).filter(b => {
            var al = (b.getAttribute('aria-label') || '');
            var r = b.getBoundingClientRect();
            return r.width > 10 && r.height > 10 &&
                   (al.indexOf('Adicionar elementos') >= 0 || al.indexOf('Add elements') >= 0 || b.className.indexOf('add-menu-trigger') >= 0);
        });
    }

    var panel = document.querySelector('flow-agent-panel');
    var btns = panel ? findPlus(panel) : [];
    if (btns.length === 0) btns = findPlus(document);
    if (btns.length === 0) return JSON.stringify({ isOpen: isOpen, found: false });

    var plusBtn = btns[btns.length - 1];
    var r = plusBtn.getBoundingClientRect();
    return JSON.stringify({
        isOpen: isOpen,
        found: true,
        x: Math.round(r.left + r.width/2),
        y: Math.round(r.top + r.height/2)
    });
})()", ct);

            if (info == null) return;
            bool isOpen = Convert.ToBoolean(info["isOpen"]);
            if (isOpen != wantOpen && Convert.ToBoolean(info["found"]))
            {
                await _cdp.ClickAtAsync(sess, Convert.ToInt32(info["x"]), Convert.ToInt32(info["y"]), ct);
                await Task.Delay(650, ct);
            }
        }

        private async Task EnsureImagesTabInOverlayAsync(string sess, CancellationToken ct)
        {
            // Importante: no menu '+' do Google Flow, o innerText da aba contém o ícone Material ("image\nImagens") dentro de .cdk-overlay-container
            Dictionary<string, object> tabInfo = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var tabs = Array.from(document.querySelectorAll('.cdk-overlay-container [role=""tab""], .cdk-overlay-container .side-nav-list-item, .cdk-overlay-container mat-list-item'));
    var t = tabs.find(el => {
        var txt = (el.innerText || '');
        var r = el.getBoundingClientRect();
        return r.width > 10 && r.height > 10 && (txt.indexOf('Imagens') >= 0 || txt.indexOf('Images') >= 0);
    });
    if (!t) return null;
    var hasSearch = !!Array.from(document.querySelectorAll('.cdk-overlay-container input.search-input')).find(i => i.getBoundingClientRect().width > 10);
    var selected = (t.getAttribute('aria-selected') === 'true') && hasSearch;
    var r = t.getBoundingClientRect();
    return JSON.stringify({
        selected: selected,
        x: Math.round(r.left + r.width/2),
        y: Math.round(r.top + r.height/2)
    });
})()", ct);

            if (tabInfo != null && !Convert.ToBoolean(tabInfo["selected"]))
            {
                await _cdp.ClickAtAsync(sess, Convert.ToInt32(tabInfo["x"]), Convert.ToInt32(tabInfo["y"]), ct);
                await Task.Delay(650, ct);
            }
        }

        private async Task<bool> EnsureUploadsTabInOverlayAsync(string sess, CancellationToken ct)
        {
            Dictionary<string, object> tabInfo = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var tabs = Array.from(document.querySelectorAll('.cdk-overlay-container [role=""tab""], .cdk-overlay-container .side-nav-list-item, .cdk-overlay-container mat-list-item'));
    var t = tabs.find(el => {
        var txt = (el.innerText || '');
        var r = el.getBoundingClientRect();
        return r.width > 10 && r.height > 10 &&
               (txt.indexOf('Envios') >= 0 || txt.indexOf('Uploads') >= 0 || txt.indexOf('drive_folder_upload') >= 0);
    });
    if (!t) return null;
    var selected = (t.getAttribute('aria-selected') === 'true');
    var r = t.getBoundingClientRect();
    return JSON.stringify({
        selected: selected,
        x: Math.round(r.left + r.width/2),
        y: Math.round(r.top + r.height/2)
    });
})()", ct);

            if (tabInfo == null) return false;
            if (!Convert.ToBoolean(tabInfo["selected"]))
            {
                await _cdp.ClickAtAsync(sess, Convert.ToInt32(tabInfo["x"]), Convert.ToInt32(tabInfo["y"]), ct);
                await Task.Delay(600, ct);
            }
            return true;
        }

        private async Task<string> SetOverlaySearchQueryAsync(string sess, string query, CancellationToken ct)
        {
            string b64Query = Convert.ToBase64String(Encoding.UTF8.GetBytes(query ?? ""));
            return await _cdp.EvalStringAsync(sess, string.Format(@"
(function(){{
    var inp = document.querySelector('.cdk-overlay-container input.search-input') ||
              Array.from(document.querySelectorAll('.cdk-overlay-container input')).find(el => el.getBoundingClientRect().width > 30);
    if (!inp) return 'NO_INPUT';
    var q = new TextDecoder('utf-8').decode(Uint8Array.from(atob('{0}'), c => c.charCodeAt(0)));
    if ((inp.value || '') === q) return 'OK';
    inp.focus();
    inp.select();
    document.execCommand('insertText', false, q);

    var vps = Array.from(document.querySelectorAll('.cdk-overlay-container cdk-virtual-scroll-viewport, .cdk-overlay-container .asset-list-viewport'));
    vps.forEach(vp => {{
        try {{
            if (vp.scrollTop > 0) vp.scrollTop = 0;
        }} catch(e) {{}}
    }});
    return 'OK';
}})()", b64Query), ct);
        }

        private async Task ClearOverlaySearchInputAsync(string sess, CancellationToken ct)
        {
            string res = await _cdp.EvalStringAsync(sess, @"
(function(){
    var inp = document.querySelector('.cdk-overlay-container input.search-input') ||
              Array.from(document.querySelectorAll('.cdk-overlay-container input')).find(el => el.getBoundingClientRect().width > 30);
    if (!inp) return 'NO_INPUT';
    if (!inp.value || inp.value.length === 0) return 'ALREADY_EMPTY';
    inp.focus();
    inp.select();
    document.execCommand('delete', false, null);
    var vps = Array.from(document.querySelectorAll('.cdk-overlay-container cdk-virtual-scroll-viewport, .cdk-overlay-container .asset-list-viewport'));
    vps.forEach(vp => {
        try {
            if (vp.scrollTop > 0) vp.scrollTop = 0;
        } catch(e) {}
    });
    return 'OK';
})()", ct);
            if (res == "OK")
                await Task.Delay(250, ct);
        }

        private async Task<Dictionary<string, object>> EvaluateOverlayAssetMatchAsync(
            string sess,
            string b64Stem,
            string b64Full,
            CancellationToken ct)
        {
            string findAssetJs = string.Format(@"
(function(){{
    var wantStem = new TextDecoder('utf-8').decode(Uint8Array.from(atob('{0}'), c => c.charCodeAt(0))).trim().toLowerCase();
    var wantFull = new TextDecoder('utf-8').decode(Uint8Array.from(atob('{1}'), c => c.charCodeAt(0))).trim().toLowerCase();

    var inp = document.querySelector('.cdk-overlay-container input.search-input') ||
              Array.from(document.querySelectorAll('.cdk-overlay-container input')).find(el => el.getBoundingClientRect().width > 30);
    var curQuery = inp ? (inp.value || '').trim() : '';

    var items = Array.from(document.querySelectorAll('.cdk-overlay-container button.asset-item, .cdk-overlay-container [class*=""asset-item""]'))
        .filter(el => el.tagName === 'BUTTON' || el.getAttribute('role') === 'option')
        .filter(el => el.getBoundingClientRect().width > 12);
    if (items.length === 0) return null;

    var exact = items.find(el => {{
        var rawTxt = (el.innerText || '').trim().toLowerCase();
        var rawAria = (el.getAttribute('aria-label') || '').trim().toLowerCase();
        var lines = rawTxt.split(/\r?\n/).map(s => s.trim()).filter(s => s.length > 0);
        return rawTxt === wantFull || rawTxt === wantStem ||
               rawAria === wantFull || rawAria === wantStem ||
               lines.indexOf(wantFull) >= 0 || lines.indexOf(wantStem) >= 0;
    }});

    var chosen = exact || items.find(el => {{
        var combined = ((el.innerText || '') + ' ' + (el.getAttribute('aria-label') || '')).toLowerCase();
        return combined.indexOf(wantFull) >= 0 || combined.indexOf(wantStem) >= 0;
    }});

    if (!chosen) return null;

    var vp = chosen.closest('cdk-virtual-scroll-viewport') ||
             document.querySelector('.cdk-overlay-container cdk-virtual-scroll-viewport.asset-list-viewport') ||
             document.querySelector('.cdk-overlay-container cdk-virtual-scroll-viewport');
    var vpRect = vp ? vp.getBoundingClientRect() : null;
    var pane = chosen.closest('.cdk-overlay-pane') || document.querySelector('.cdk-overlay-container .cdk-overlay-pane');
    var paneRect = pane ? pane.getBoundingClientRect() : null;

    var r = chosen.getBoundingClientRect();
    var cx = Math.round(r.left + Math.min(r.width / 2, 110));
    var cy = Math.round(r.top + r.height / 2);

    var minTop = vpRect ? (vpRect.top + 8) : (paneRect ? paneRect.top + 45 : 45);
    var maxBottom = vpRect ? (vpRect.bottom - 8) : (paneRect ? paneRect.bottom - 12 : (window.innerHeight - 20));
    var inBounds = r.width > 20 && r.height > 12 &&
                   cy >= minTop && cy <= maxBottom &&
                   (!paneRect || (cx >= paneRect.left + 8 && cx <= paneRect.right - 8));

    var scrolled = false;
    if (!inBounds && vp && vpRect && vp.scrollHeight > vp.clientHeight + 4) {{
        var targetScroll = Math.max(0, vp.scrollTop + (cy - (vpRect.top + vpRect.height / 2)));
        if (Math.abs(targetScroll - vp.scrollTop) > 4) {{
            vp.scrollTop = targetScroll;
            scrolled = true;
        }}
    }}

    var img = chosen.querySelector('img.asset-thumbnail-image') || chosen.querySelector('img');
    var imgSrc = img ? ((img.currentSrc || img.src || img.getAttribute('src') || '')) : '';
    var hasSpinner = !!chosen.querySelector('mat-progress-spinner, mat-spinner, [role=""progressbar""], [class*=""uploading""]');
    var imgReady = !hasSpinner && !!img && imgSrc.length > 12 && !!img.complete && (img.naturalWidth || 0) > 0;
    var isActive = chosen.classList.contains('asset-item-active') || chosen.getAttribute('aria-selected') === 'true';

    var hit = (inBounds && cx > 0 && cy > 0 && cy < window.innerHeight) ? document.elementFromPoint(cx, cy) : null;
    var hitOk = !!hit && (chosen.contains(hit) || hit.contains(chosen));

    return JSON.stringify({{
        matchedText: (chosen.innerText || '').trim(),
        isExact: !!exact,
        isActive: isActive,
        imgReady: imgReady,
        hasSpinner: hasSpinner,
        inBounds: inBounds,
        hitOk: hitOk,
        scrolled: scrolled,
        curQueryLen: curQuery.length,
        x: cx,
        y: cy
    }});
}})()", b64Stem, b64Full);

            return await _cdp.EvalJsonAsync(sess, findAssetJs, ct);
        }

        private async Task<Dictionary<string, object>> SweepOverlayVirtualListForAssetAsync(
            string sess,
            string b64Stem,
            string b64Full,
            CancellationToken ct)
        {
            await ClearOverlaySearchInputAsync(sess, ct);

            for (int page = 0; page < 18; page++)
            {
                ct.ThrowIfCancellationRequested();
                Dictionary<string, object> matchPt = await EvaluateOverlayAssetMatchAsync(sess, b64Stem, b64Full, ct);
                if (matchPt != null)
                {
                    bool inBounds = matchPt.ContainsKey("inBounds") && Convert.ToBoolean(matchPt["inBounds"]);
                    if (!inBounds && matchPt.ContainsKey("scrolled") && Convert.ToBoolean(matchPt["scrolled"]))
                    {
                        await Task.Delay(260, ct);
                        Dictionary<string, object> rescrolled = await EvaluateOverlayAssetMatchAsync(sess, b64Stem, b64Full, ct);
                        if (rescrolled != null)
                            matchPt = rescrolled;
                    }
                    return matchPt;
                }

                string nextStep = await _cdp.EvalStringAsync(sess, @"
(function(){
    var vp = document.querySelector('.cdk-overlay-container cdk-virtual-scroll-viewport.asset-list-viewport') ||
             document.querySelector('.cdk-overlay-container cdk-virtual-scroll-viewport');
    if (!vp) return 'NO_VP';
    if (vp.scrollTop + vp.clientHeight >= vp.scrollHeight - 6) return 'END';
    var nextTop = Math.min(vp.scrollHeight - vp.clientHeight, vp.scrollTop + 380);
    if (nextTop <= vp.scrollTop + 2) return 'END';
    vp.scrollTop = nextTop;
    return 'MOVED';
})()", ct);

                if (nextStep != "MOVED")
                    break;

                await Task.Delay(230, ct);
            }

            return null;
        }

        private async Task<Dictionary<string, object>> SearchOverlayAssetAsync(
            string sess,
            string searchStem,
            string fullFileName,
            CancellationToken ct)
        {
            string b64Stem = Convert.ToBase64String(Encoding.UTF8.GetBytes(searchStem ?? ""));
            string b64Full = Convert.ToBase64String(Encoding.UTF8.GetBytes(fullFileName ?? ""));

            // 1. Verifica primeiro se já está visível dentro da janela útil do cdk-virtual-scroll-viewport (sem texto residual de busca anterior)
            Dictionary<string, object> directPt = await EvaluateOverlayAssetMatchAsync(sess, b64Stem, b64Full, ct);
            if (directPt != null &&
                Convert.ToInt32(directPt.ContainsKey("curQueryLen") ? directPt["curQueryLen"] : 0) == 0 &&
                directPt.ContainsKey("isExact") && Convert.ToBoolean(directPt["isExact"]))
            {
                bool directInBounds = directPt.ContainsKey("inBounds") && Convert.ToBoolean(directPt["inBounds"]);
                bool directHitOk = directPt.ContainsKey("hitOk") && Convert.ToBoolean(directPt["hitOk"]);
                bool directImgReady = directPt.ContainsKey("imgReady") && Convert.ToBoolean(directPt["imgReady"]);

                if (directInBounds && directHitOk && directImgReady)
                {
                    return directPt;
                }

                // Se estava montado no final dos 15 recentes (ex.: 9º+ item em y > 560), EvaluateOverlayAssetMatchAsync já rolou o viewport interno: aguarda renderização!
                if (!directInBounds && directPt.ContainsKey("scrolled") && Convert.ToBoolean(directPt["scrolled"]))
                {
                    await Task.Delay(260, ct);
                    Dictionary<string, object> afterScrollPt = await EvaluateOverlayAssetMatchAsync(sess, b64Stem, b64Full, ct);
                    if (afterScrollPt != null &&
                        afterScrollPt.ContainsKey("inBounds") && Convert.ToBoolean(afterScrollPt["inBounds"]) &&
                        afterScrollPt.ContainsKey("hitOk") && Convert.ToBoolean(afterScrollPt["hitOk"]) &&
                        afterScrollPt.ContainsKey("imgReady") && Convert.ToBoolean(afterScrollPt["imgReady"]))
                    {
                        return afterScrollPt;
                    }
                }
            }

            // 2. Busca na biblioteca COMPLETA do projeto via input.search-input (encontra imagens antigas mesmo após dezenas de cenas geradas!)
            List<string> candidateQueries = new List<string>();
            if (!string.IsNullOrWhiteSpace(searchStem))
                candidateQueries.Add(searchStem.Trim());

            Match prefixMatch = Regex.Match(searchStem ?? "", @"^(\d+_[A-Za-z]+_[A-Za-z0-9]+)");
            if (prefixMatch.Success)
            {
                string shortPrefix = prefixMatch.Groups[1].Value;
                if (!string.Equals(shortPrefix, searchStem, StringComparison.OrdinalIgnoreCase))
                    candidateQueries.Add(shortPrefix);
            }

            Dictionary<string, object> lastMatch = null;
            for (int qIdx = 0; qIdx < candidateQueries.Count; qIdx++)
            {
                string query = candidateQueries[qIdx];
                string setRes = await SetOverlaySearchQueryAsync(sess, query, ct);
                if (setRes == "NO_INPUT")
                    break;

                int maxPolls = (qIdx == 0) ? 5 : 4;
                for (int poll = 0; poll < maxPolls; poll++)
                {
                    await Task.Delay(poll == 0 ? 340 : 260, ct);

                    Dictionary<string, object> matchPt = await EvaluateOverlayAssetMatchAsync(sess, b64Stem, b64Full, ct);
                    if (matchPt != null)
                    {
                        lastMatch = matchPt;
                        bool inBounds = matchPt.ContainsKey("inBounds") && Convert.ToBoolean(matchPt["inBounds"]);
                        if (!inBounds && matchPt.ContainsKey("scrolled") && Convert.ToBoolean(matchPt["scrolled"]))
                        {
                            await Task.Delay(260, ct);
                            Dictionary<string, object> rescrolled = await EvaluateOverlayAssetMatchAsync(sess, b64Stem, b64Full, ct);
                            if (rescrolled != null)
                            {
                                matchPt = rescrolled;
                                lastMatch = rescrolled;
                                inBounds = rescrolled.ContainsKey("inBounds") && Convert.ToBoolean(rescrolled["inBounds"]);
                            }
                        }

                        if (inBounds)
                            return matchPt;
                    }
                }

                if (lastMatch != null)
                    return lastMatch;
            }

            // 3. Fallback de varredura completa da lista virtualizada além de 'Mais recentes' (rola página por página até o fim da aba Imagens)
            Dictionary<string, object> sweptInImages = await SweepOverlayVirtualListForAssetAsync(sess, b64Stem, b64Full, ct);
            if (sweptInImages != null)
                return sweptInImages;

            // 4. Fallback na aba 'Envios' (Uploads), onde ficam exclusivamente os arquivos enviados sem mistura com cenas geradas
            if (await EnsureUploadsTabInOverlayAsync(sess, ct))
            {
                if (!string.IsNullOrWhiteSpace(searchStem))
                {
                    string upSet = await SetOverlaySearchQueryAsync(sess, searchStem.Trim(), ct);
                    if (upSet == "OK")
                    {
                        await Task.Delay(360, ct);
                        Dictionary<string, object> upMatch = await EvaluateOverlayAssetMatchAsync(sess, b64Stem, b64Full, ct);
                        if (upMatch != null)
                        {
                            bool inBounds = upMatch.ContainsKey("inBounds") && Convert.ToBoolean(upMatch["inBounds"]);
                            if (!inBounds && upMatch.ContainsKey("scrolled") && Convert.ToBoolean(upMatch["scrolled"]))
                            {
                                await Task.Delay(260, ct);
                                upMatch = await EvaluateOverlayAssetMatchAsync(sess, b64Stem, b64Full, ct) ?? upMatch;
                            }
                            return upMatch;
                        }
                    }
                }

                Dictionary<string, object> sweptInUploads = await SweepOverlayVirtualListForAssetAsync(sess, b64Stem, b64Full, ct);
                if (sweptInUploads != null)
                    return sweptInUploads;

                await EnsureImagesTabInOverlayAsync(sess, ct);
            }

            return null;
        }

        private async Task<int> AttachIngredientsViaMenuAsync(
            string sess,
            List<string> wantedFilenames,
            HashSet<string> attachedInSessionOut,
            CancellationToken ct)
        {
            if (wantedFilenames == null || wantedFilenames.Count == 0) return 0;

            await ToggleAddElementsMenuAsync(sess, true, ct);
            await EnsureImagesTabInOverlayAsync(sess, ct);
            await WaitForOverlayImagesLibraryLoadedAsync(sess, ct);

            int baselineChips = await CountAttachedPromptChipsAsync(sess, ct);
            int currentChips = baselineChips;
            int attachedNow = 0;

            for (int idx = 0; idx < wantedFilenames.Count; idx++)
            {
                ct.ThrowIfCancellationRequested();
                if (idx > 0)
                {
                    await WaitRandomFlowActionDelayAsync(string.Format("entre anexações ({0}/{1})", idx + 1, wantedFilenames.Count), ct);
                }

                string fileName = wantedFilenames[idx];
                string stem = Path.GetFileNameWithoutExtension(fileName);
                bool itemAttached = false;
                bool capReached = false;

                for (int attempt = 1; attempt <= 3; attempt++)
                {
                    await ToggleAddElementsMenuAsync(sess, true, ct);
                    await EnsureImagesTabInOverlayAsync(sess, ct);

                    Dictionary<string, object> itemPt = await SearchOverlayAssetAsync(sess, stem, fileName, ct);
                    if (itemPt == null)
                    {
                        if (attempt < 3)
                        {
                            await Task.Delay(800, ct);
                            continue;
                        }
                        _log(string.Format("[Google Flow] Aviso: imagem '{0}' não localizada na biblioteca do projeto (abas Imagens/Envios).", fileName));
                        break;
                    }

                    bool hasSpinner = itemPt.ContainsKey("hasSpinner") && Convert.ToBoolean(itemPt["hasSpinner"]);
                    bool imgReady = !itemPt.ContainsKey("imgReady") || Convert.ToBoolean(itemPt["imgReady"]);
                    if ((hasSpinner || !imgReady) && attempt < 3)
                    {
                        await Task.Delay(1200, ct);
                        continue;
                    }

                    // Exclusivamente clique real de mouse via CDP (ZERO .click() sintético para não acionar bloqueio do Flow!)
                    await _cdp.ClickAtAsync(sess, Convert.ToInt32(itemPt["x"]), Convert.ToInt32(itemPt["y"]), ct);
                    await Task.Delay(550, ct);

                    // Regra 25: Clicar obrigatoriamente em "Incluir no comando" via CDP ClickAtAsync
                    Dictionary<string, object> incPt = null;
                    for (int pollInc = 0; pollInc < 6; pollInc++)
                    {
                        incPt = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var b = Array.from(document.querySelectorAll('.cdk-overlay-container button, button.detail-add-to-prompt-btn')).find(el => {
        var txt = (el.innerText || '').trim();
        var al = (el.getAttribute('aria-label') || '');
        var r = el.getBoundingClientRect();
        return r.width > 10 && r.height > 10 &&
               (txt.indexOf('Incluir no comando') >= 0 || al.indexOf('Incluir no comando') >= 0 ||
                txt.indexOf('Include in prompt') >= 0);
    });
    if (!b) return null;
    var r = b.getBoundingClientRect();
    return JSON.stringify({
        disabled: !!b.disabled || b.getAttribute('aria-disabled') === 'true',
        x: Math.round(r.left + r.width/2),
        y: Math.round(r.top + r.height/2)
    });
})()", ct);

                        if (incPt != null && !Convert.ToBoolean(incPt["disabled"]))
                            break;

                        if (incPt != null && Convert.ToBoolean(incPt["disabled"]) && currentChips >= 8)
                            break;

                        await Task.Delay(350, ct);
                    }

                    if (incPt != null)
                    {
                        if (Convert.ToBoolean(incPt["disabled"]))
                        {
                            if (currentChips >= 8)
                            {
                                capReached = true;
                                break;
                            }
                            await Task.Delay(900, ct);
                            continue;
                        }
                        await _cdp.ClickAtAsync(sess, Convert.ToInt32(incPt["x"]), Convert.ToInt32(incPt["y"]), ct);
                        await Task.Delay(600, ct);
                    }
                    else
                    {
                        await Task.Delay(500, ct);
                    }

                    int afterChips = currentChips;
                    for (int pollChip = 0; pollChip < 4; pollChip++)
                    {
                        afterChips = await CountAttachedPromptChipsAsync(sess, ct);
                        if (afterChips > currentChips)
                            break;
                        await Task.Delay(250, ct);
                    }

                    if (afterChips > currentChips)
                    {
                        currentChips = afterChips;
                        attachedNow++;
                        itemAttached = true;
                        if (attachedInSessionOut != null)
                            attachedInSessionOut.Add(fileName);

                        _log(string.Format("[Google Flow] ✔ Ingrediente vinculado ({0}/{1}): {2} (chips na caixa: {3})",
                            idx + 1, wantedFilenames.Count, fileName, currentChips));
                        break;
                    }
                }

                if (capReached)
                {
                    _log(string.Format("[Google Flow] Limite máximo de chips simultâneos por comando atingido ({0} chips). Os cenários restantes entrarão automaticamente no próximo lote 'continue'.",
                        currentChips));
                    break;
                }

                if (!itemAttached)
                {
                    _log(string.Format("[Google Flow] Aviso: não foi possível confirmar o chip de '{0}' na caixa de comando.", fileName));
                }
            }

            await ClearOverlaySearchInputAsync(sess, ct);
            await ToggleAddElementsMenuAsync(sess, false, ct);
            _log(string.Format("[Google Flow] Resumo de Ingredientes: {0}/{1} personagens e cenários anexados na caixa de comando!",
                attachedNow, wantedFilenames.Count));
            return attachedNow;
        }

    }
}
