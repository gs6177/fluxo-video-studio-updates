using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace FluxoVideoStudio
{
    public partial class GrokAutomation
    {
        public async Task GenerateStoryCoversAsync(
            StoryProject story,
            EpisodeWorkItem currentEp,
            StoryCoverConfig coverCfg,
            bool remakeAll,
            CoverGenerationItem singleItemOnly,
            Action onEachCoverSavedUiRefresh,
            CancellationToken ct)
        {
            EpisodeWorkItem ep1 = CoverGenerator.ResolveEp1Episode(story, currentEp);
            if (ep1 == null)
                throw new InvalidOperationException("Episódio EP.1 não localizado para extrair os personagens da capa.");

            if (coverCfg == null || coverCfg.ReferenceModels == null || coverCfg.ReferenceModels.Count == 0)
            {
                _log("[Capas 9:16] Nenhuma imagem de referência selecionada para gerar capas.");
                return;
            }

            string coversDir = CoverGenerator.GetStoryCoversDir(ep1);
            Directory.CreateDirectory(coversDir);
            CoverGenerator.SaveStoryCoverConfigAndPrompts(ep1, coverCfg);

            List<CoverGenerationItem> allItems = CoverGenerator.BuildCoverGenerationItems(ep1, coverCfg);
            List<CoverGenerationItem> pendingItems = new List<CoverGenerationItem>();

            if (singleItemOnly != null)
            {
                pendingItems.Add(singleItemOnly);
            }
            else
            {
                foreach (CoverGenerationItem item in allItems)
                {
                    string dst = Path.Combine(coversDir, item.TargetFileName);
                    bool existsOk = File.Exists(dst) && new FileInfo(dst).Length >= 10 * 1024;
                    if (!remakeAll && _config.PreserveExistingAssets && existsOk)
                        continue;
                    pendingItems.Add(item);
                }
            }

            if (pendingItems.Count == 0)
            {
                _log(string.Format("[Capas 9:16] Todas as {0} opções de capa desta história já existem em '{1}' — preservando arquivos prontos!",
                    allItems.Count, coversDir));
                return;
            }

            // CRÍTICO: Ao refazer ou regerar capa(s) que já existiam em disco, arquiva e remove o arquivo antigo ANTES de iniciar,
            // pois o coletor do Google Flow ignora vagas cujo arquivo de destino já exista em disco!
            string oldBackupDir = Path.Combine(coversDir, "_historico_antigas");
            bool archivedAny = false;
            foreach (CoverGenerationItem pi in pendingItems)
            {
                string existingDst = Path.Combine(coversDir, pi.TargetFileName);
                if (File.Exists(existingDst))
                {
                    try
                    {
                        Directory.CreateDirectory(oldBackupDir);
                        string bakName = DateTime.Now.ToString("yyyyMMdd_HHmmss_") + pi.TargetFileName;
                        File.Copy(existingDst, Path.Combine(oldBackupDir, bakName), true);
                    }
                    catch { }

                    try
                    {
                        File.Delete(existingDst);
                        archivedAny = true;
                    }
                    catch { }
                }
            }
            if (archivedAny && onEachCoverSavedUiRefresh != null)
            {
                try { onEachCoverSavedUiRefresh(); } catch { }
            }

            List<string> rawRefCharPaths = CoverGenerator.ResolveSelectedCharacterPathsOnDisk(
                ep1,
                currentEp,
                coverCfg.SelectedCharacterFiles);

            if (rawRefCharPaths.Count == 0)
            {
                List<string> autoChars = CoverGenerator.AutoSelectFocalCharacterFileNames(ep1);
                rawRefCharPaths = CoverGenerator.ResolveSelectedCharacterPathsOnDisk(ep1, currentEp, autoChars);
            }

            string prepTempDir = Path.Combine(Path.GetTempPath(), "fvs_cov_prep_" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(prepTempDir);

            try
            {
                // 1. Limpa automaticamente os textos escritos acima da cabeça dos personagens de EP.1\assets (sem alterar os originais!)
                //    para não contaminar o estilo da fonte da capa com a fonte lisa/gótica dos nomes dos personagens!
                List<string> cleanCharPaths = new List<string>();
                foreach (string cp in rawRefCharPaths)
                {
                    string cleaned = CoverGenerator.CreateCleanCharacterCopyWithoutTopLabel(cp, prepTempDir);
                    if (!string.IsNullOrEmpty(cleaned) && File.Exists(cleaned))
                        cleanCharPaths.Add(cleaned);
                }

                // 2. Extrai para cada modelo de referência apenas a faixa superior limpa da escrita (sem personagens da referência!)
                Dictionary<int, string> modelBannerByIdx = new Dictionary<int, string>();
                for (int m = 0; m < coverCfg.ReferenceModels.Count; m++)
                {
                    CoverReferenceModelSpec mod = coverCfg.ReferenceModels[m];
                    int mNum = m + 1;
                    if (!string.IsNullOrEmpty(mod.SourceImagePath) && File.Exists(mod.SourceImagePath))
                    {
                        string banner = CoverGenerator.CreateCleanTypographySampleBanner(mod.SourceImagePath, mNum, prepTempDir);
                        if (!string.IsNullOrEmpty(banner) && File.Exists(banner))
                            modelBannerByIdx[mNum] = banner;
                    }
                }

                _log(string.Format(
                    "[Capas 9:16] Gerando {0} opção(ões) de capa para \"{1}\" (personagens limpos sem texto no topo: {2} + amostra limpa da escrita de cada modelo)...",
                    pendingItems.Count,
                    coverCfg.CoverTitle,
                    cleanCharPaths.Count));

                if (_config.AreAllGrokProfilesMarkedExhausted() && _flowFallback != null)
                {
                    _log("[Capas 9:16 | Fallback Flow] Todas as contas do Grok estão com LIMITE ATINGIDO -> gerando capas automaticamente no Google Flow!");
                    await _flowFallback.GenerateCoversInFlowAsync(ep1, coversDir, pendingItems, cleanCharPaths, modelBannerByIdx, onEachCoverSavedUiRefresh, ct);
                    return;
                }

                for (int i = 0; i < pendingItems.Count; i++)
                {
                    ct.ThrowIfCancellationRequested();
                    CoverGenerationItem item = pendingItems[i];

                    List<string> attachmentsForItem = new List<string>(cleanCharPaths);
                    string bannerPath;
                    if (modelBannerByIdx.TryGetValue(item.ModelIndex, out bannerPath) &&
                        !string.IsNullOrEmpty(bannerPath) &&
                        File.Exists(bannerPath))
                    {
                        attachmentsForItem.Add(bannerPath);
                    }

                    bool generatedInGrok = await TryGenerateSingleCoverInGrokAsync(
                        ep1,
                        coversDir,
                        item,
                        attachmentsForItem,
                        ct);

                    if (generatedInGrok)
                    {
                        if (onEachCoverSavedUiRefresh != null)
                        {
                            try { onEachCoverSavedUiRefresh(); } catch { }
                        }
                        continue;
                    }

                    if (_config.AreAllGrokProfilesMarkedExhausted() && _flowFallback != null)
                    {
                        List<CoverGenerationItem> remainingForFlow = pendingItems.Skip(i).ToList();
                        _log(string.Format(
                            "[Capas 9:16 | Fallback Flow] Contas do Grok esgotaram os créditos -> transferindo {0} capa(s) restante(s) para o Google Flow...",
                            remainingForFlow.Count));
                        await _flowFallback.GenerateCoversInFlowAsync(ep1, coversDir, remainingForFlow, cleanCharPaths, modelBannerByIdx, onEachCoverSavedUiRefresh, ct);
                        return;
                    }
                }
            }
            finally
            {
                Task ignoredCleanup = Task.Run(() =>
                {
                    try { Directory.Delete(prepTempDir, true); } catch { }
                });
            }
        }

        private async Task<bool> TryGenerateSingleCoverInGrokAsync(
            EpisodeWorkItem ep1,
            string coversDir,
            CoverGenerationItem item,
            List<string> attachmentPaths,
            CancellationToken ct)
        {
            string targetFullPath = Path.Combine(coversDir, item.TargetFileName);
            List<string> activeProfiles = _config.GetAvailableGrokProfiles(_log);
            if (activeProfiles.Count == 0)
                return false;

            Exception lastErr = null;
            foreach (string profile in activeProfiles)
            {
                ct.ThrowIfCancellationRequested();
                string stagingDir = "";
                bool needsErrorReset = false;
                bool quotaHitInCatch = false;
                try
                {
                    _log(string.Format("[Grok Imagine | Capas 9:16] Abrindo perfil '{0}' para gerar '{1}' ({2})...",
                        profile, item.TargetFileName, item.DisplayLabel));

                    string sess = await _cdp.OpenOrAttachProfileTabAsync(profile, _config.GrokUrl, "grok.com", false, ct);
                    await WaitForGrokInteractiveReadyAsync(sess, ct);

                    if (await HasQuotaExhaustedBannerAsync(sess, ct))
                    {
                        _config.SetProfileStatus(profile, "LIMITE ATINGIDO");
                        _log(string.Format("[Grok Imagine | Capas 9:16] Limite atingido no perfil '{0}'. Alternando para o próximo perfil...", profile));
                        continue;
                    }

                    await EnsureCleanGrokImagineHomeAsync(sess, profile, ct);

                    if (await HasQuotaExhaustedBannerAsync(sess, ct))
                    {
                        _config.SetProfileStatus(profile, "LIMITE ATINGIDO");
                        _log(string.Format("[Grok Imagine | Capas 9:16] Limite atingido no perfil '{0}'. Alternando para o próximo perfil...", profile));
                        continue;
                    }

                    // 1. Modo Imagem + Proporção 9:16 ANTES de anexar
                    await EnsureGrokImageModeAnd9x16Async(sess, ct);

                    // 2. Anexar personagens limpos (sem nome acima da cabeça) + faixa limpa da amostra de escrita
                    if (attachmentPaths != null && attachmentPaths.Count > 0)
                    {
                        bool attached = await _cdp.SetFileInputFilesByObjectIdAsync(
                            sess,
                            "document.querySelector('input[type=\"file\"][multiple]') || document.querySelector('input[type=\"file\"]')",
                            attachmentPaths,
                            ct);

                        await Task.Delay(1600, ct);
                        string attachCountStr = await _cdp.EvalStringAsync(sess, @"
(function(){
    return Array.from(document.querySelectorAll('button[aria-label*=""Remover imagem""], button[aria-label*=""Remove image""], button[aria-label*=""Remover anexo""], button[aria-label*=""Remove attachment""]')).length.toString();
})()", ct);

                        if (!attached || attachCountStr == "0")
                        {
                            await _cdp.UploadFilesViaFileChooserAsync(
                                sess,
                                async () =>
                                {
                                    Dictionary<string, object> trPt = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var b = Array.from(document.querySelectorAll('button')).find(el => {
        var al = (el.getAttribute('aria-label') || '');
        var r = el.getBoundingClientRect();
        return r.left > 245 && !el.closest('[data-sidebar], nav, aside') && r.width > 10 &&
               (al.indexOf('Transferir') >= 0 || al.indexOf('Upload') >= 0 || al.indexOf('Anexar') >= 0 || al.indexOf('Attach') >= 0);
    });
    if (!b) return null;
    var r = b.getBoundingClientRect();
    return JSON.stringify({ x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) });
})()", ct);
                                    if (trPt != null)
                                        await _cdp.ClickAtAsync(sess, Convert.ToInt32(trPt["x"]), Convert.ToInt32(trPt["y"]), ct);
                                },
                                attachmentPaths,
                                ct);
                            await Task.Delay(1800, ct);
                        }

                        // Reafirmar proporção 9:16 após anexar múltiplos arquivos
                        await EnsureGrokDropdownOptionAsync(sess, "Aspecto de proporção", "Aspect ratio", "9:16", ct);
                    }

                    // 3. Registrar baseline de URLs de imagens antes de enviar
                    await _cdp.EvalStringAsync(sess, @"
(function(){
    window.__fvsBaselineGenUrls = Array.from(document.querySelectorAll('img'))
        .map(i => i.currentSrc || i.src || '')
        .filter(Boolean);
    return 'OK';
})()", ct);

                    bool inserted = await InjectPromptIntoGrokBoxAsync(sess, item.FullPrompt, ct);
                    if (!inserted)
                        throw new InvalidOperationException("Caixa de prompt não encontrada no Grok Imagine.");

                    await Task.Delay(550, ct);
                    string curPageUrl = await _cdp.EvalStringAsync(sess, "location.href || ''", ct);
                    LastActionHistoryStore.RecordAction(
                        ep1,
                        "Grok Capas 9:16",
                        string.Format("Gerando capa '{0}' ({1})", item.TargetFileName, item.DisplayLabel),
                        profile,
                        sess,
                        curPageUrl,
                        item.TargetFileName,
                        0,
                        1,
                        item.FullPrompt,
                        attachmentPaths ?? new List<string>(),
                        "SUBMITTED");

                    await SubmitGrokPromptAsync(sess, ct);

                    // 4. Aguardar conclusão da imagem 9:16 gerada (com suporte a Watchdog + Recarregar e Continuar)
                    DateTime deadline = DateTime.UtcNow.AddMinutes(5);
                    DateTime lastProgressUtc = DateTime.UtcNow;
                    string lastFingerprint = "";
                    int reloadAttempts = 0;
                    int stable = 0;
                    string generatedImgUrl = "";

                    while (DateTime.UtcNow < deadline)
                    {
                        ct.ThrowIfCancellationRequested();
                        await _cdp.WaitOrWakeOnReloadSignalAsync(3500, ct);

                        if (await HasQuotaExhaustedBannerAsync(sess, ct))
                        {
                            _config.SetProfileStatus(profile, "LIMITE ATINGIDO");
                            throw new InvalidOperationException("QUOTA_EXHAUSTED");
                        }

                        Dictionary<string, object> st = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var baseList = window.__fvsBaselineGenUrls || [];
    var body = (document.body && document.body.innerText) ? document.body.innerText : '';
    var genImgs = Array.from(document.querySelectorAll('img')).filter(img => {
        var s = (img.currentSrc || img.src || '');
        var r = img.getBoundingClientRect();
        if (r.width < 120 || r.height < 160 || !img.complete || img.naturalWidth < 300) return false;
        if (s.indexOf('media.x.ai') >= 0 || s.indexOf('agent-skills') >= 0 || s.indexOf('grok-web') >= 0 || s.indexOf('/website/') >= 0) return false;
        if (baseList.indexOf(s) >= 0) return false;
        return s.indexOf('/generated/') >= 0 || s.indexOf('assets.grok.com/users/') >= 0;
    });
    var spinners = Array.from(document.querySelectorAll('[role=""progressbar""], .animate-spin, svg.animate-spin')).filter(el => {
        var r = el.getBoundingClientRect();
        return r.width > 4 && r.height > 4;
    }).length;
    var pctMatch = body.match(/\b\d{1,2}%\b/);
    var pctStr = pctMatch ? pctMatch[0] : '';
    var hasPct = !!pctMatch;
    var genText = hasPct || /\b(Generating|Imaginando|Criando imagens|Gerando)\b/i.test(body);
    var latestSrc = genImgs.length > 0 ? (genImgs[genImgs.length - 1].currentSrc || genImgs[genImgs.length - 1].src || '') : '';
    return JSON.stringify({ count: genImgs.length, spinners: spinners, genText: genText, pctStr: pctStr, latestSrc: latestSrc });
})()", ct);

                        if (st != null)
                        {
                            int count = Convert.ToInt32(st["count"]);
                            int spinners = Convert.ToInt32(st["spinners"]);
                            bool genText = Convert.ToBoolean(st["genText"]);
                            string pctStr = st.ContainsKey("pctStr") ? Convert.ToString(st["pctStr"] ?? "") : "";
                            string latestSrc = Convert.ToString(st["latestSrc"] ?? "");

                            string fp = string.Format("{0}|{1}|{2}", count, pctStr, latestSrc);
                            if (fp != lastFingerprint)
                            {
                                lastFingerprint = fp;
                                lastProgressUtc = DateTime.UtcNow;
                            }

                            _log(string.Format("[Grok Imagine | Capas 9:16] Aguardando '{0}': {1}/1 capa gerada{2}...",
                                item.TargetFileName, count > 0 ? 1 : 0, !string.IsNullOrEmpty(pctStr) ? (" [" + pctStr + "]") : ""));

                            if (count > 0 && spinners == 0 && !genText)
                            {
                                generatedImgUrl = latestSrc;
                                stable++;
                                if (stable >= 2) break;
                            }
                            else
                            {
                                stable = 0;
                            }
                        }

                        string manualReason;
                        bool manualReload = _cdp.ConsumeReloadAndResumeRequest(out manualReason);
                        double stalledSec = (DateTime.UtcNow - lastProgressUtc).TotalSeconds;

                        if (manualReload || (stalledSec >= 85 && reloadAttempts < 2))
                        {
                            reloadAttempts++;
                            await _cdp.ReloadPageAndWaitReadyAsync(sess, 25000, ct);
                            await WaitForGrokInteractiveReadyAsync(sess, ct);

                            Dictionary<string, object> afterReload = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var baseList = window.__fvsBaselineGenUrls || [];
    var genImgs = Array.from(document.querySelectorAll('img')).filter(img => {
        var s = (img.currentSrc || img.src || '');
        var r = img.getBoundingClientRect();
        if (r.width < 120 || r.height < 160 || !img.complete || img.naturalWidth < 300) return false;
        if (s.indexOf('media.x.ai') >= 0 || s.indexOf('agent-skills') >= 0 || s.indexOf('grok-web') >= 0 || s.indexOf('/website/') >= 0) return false;
        if (baseList.indexOf(s) >= 0) return false;
        return s.indexOf('/generated/') >= 0 || s.indexOf('assets.grok.com/users/') >= 0;
    });
    var latestSrc = genImgs.length > 0 ? (genImgs[genImgs.length - 1].currentSrc || genImgs[genImgs.length - 1].src || '') : '';
    return JSON.stringify({ count: genImgs.length, latestSrc: latestSrc });
})()", ct);

                            if (afterReload != null && Convert.ToInt32(afterReload["count"]) > 0)
                            {
                                generatedImgUrl = Convert.ToString(afterReload["latestSrc"] ?? "");
                                break;
                            }

                            await EnsureCleanGrokImagineHomeAsync(sess, profile, ct);
                            await EnsureGrokImageModeAnd9x16Async(sess, ct);
                            if (attachmentPaths != null && attachmentPaths.Count > 0)
                            {
                                await _cdp.SetFileInputFilesByObjectIdAsync(
                                    sess,
                                    "document.querySelector('input[type=\"file\"][multiple]') || document.querySelector('input[type=\"file\"]')",
                                    attachmentPaths,
                                    ct);
                                await Task.Delay(1500, ct);
                                await EnsureGrokDropdownOptionAsync(sess, "Aspecto de proporção", "Aspect ratio", "9:16", ct);
                            }
                            await InjectPromptIntoGrokBoxAsync(sess, item.FullPrompt, ct);
                            await Task.Delay(500, ct);
                            await SubmitGrokPromptAsync(sess, ct);
                            lastProgressUtc = DateTime.UtcNow;
                            lastFingerprint = "";
                        }
                    }

                    if (string.IsNullOrEmpty(generatedImgUrl))
                        throw new TimeoutException(string.Format("Timeout aguardando geração da capa '{0}' no Grok Imagine.", item.TargetFileName));

                    // 5. Selecionar a miniatura recém-gerada (ignorando miniaturas das imagens base anexadas)
                    Dictionary<string, object> genThumbPt = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var thumbBtns = Array.from(document.querySelectorAll('button[aria-label^=""Thumbnail ""]')).filter(b => b.getBoundingClientRect().width > 10);
    if (thumbBtns.length <= 1) return null;
    var genBtn = thumbBtns.find(b => {
        var img = b.querySelector('img');
        var s = img ? (img.currentSrc || img.src || '') : '';
        return s.indexOf('/generated/') >= 0 || s.indexOf('assets.grok.com/users/') >= 0;
    }) || thumbBtns[thumbBtns.length - 1];
    if (!genBtn) return null;
    var r = genBtn.getBoundingClientRect();
    return JSON.stringify({ x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) });
})()", ct);

                    if (genThumbPt != null)
                    {
                        await _cdp.ClickAtAsync(sess, Convert.ToInt32(genThumbPt["x"]), Convert.ToInt32(genThumbPt["y"]), ct);
                        await Task.Delay(650, ct);
                    }

                    // 6. Baixar a capa gerada e restaurar imediatamente a pasta Downloads do Chrome
                    stagingDir = Path.Combine(coversDir, "_grok_cov_" + DateTime.Now.ToString("HHmmssfff"));
                    Directory.CreateDirectory(stagingDir);
                    await _cdp.SetDownloadBehaviorAsync(stagingDir, ct);

                    Dictionary<string, object> dlPt = await FindGrokDownloadButtonPointAsync(sess, ct);
                    if (dlPt == null)
                    {
                        await EnsureThumbnailViewerOpenAsync(sess, 1, ct);
                        dlPt = await FindGrokDownloadButtonPointAsync(sess, ct);
                    }

                    HashSet<string> beforeFiles = new HashSet<string>(Directory.GetFiles(stagingDir), StringComparer.OrdinalIgnoreCase);
                    string savedFile = "";

                    if (dlPt != null)
                    {
                        await _cdp.ClickAtAsync(sess, Convert.ToInt32(dlPt["x"]), Convert.ToInt32(dlPt["y"]), ct);
                        savedFile = await _cdp.WaitForSingleDownloadAsync(stagingDir, beforeFiles, 20 * 1024, 35000, ct);
                    }

                    if (string.IsNullOrEmpty(savedFile) && !string.IsNullOrEmpty(generatedImgUrl))
                    {
                        beforeFiles = new HashSet<string>(Directory.GetFiles(stagingDir), StringComparer.OrdinalIgnoreCase);
                        string b64Url = Convert.ToBase64String(Encoding.UTF8.GetBytes(generatedImgUrl));
                        await _cdp.EvalStringAsync(sess, string.Format(@"
(function(){{
    var u = atob('{0}');
    fetch(u, {{ credentials: 'include' }})
        .then(r => r.blob())
        .then(b => {{
            var burl = URL.createObjectURL(b);
            var a = document.createElement('a');
            a.href = burl;
            a.download = '{1}';
            document.body.appendChild(a);
            a.click();
            setTimeout(() => {{ a.remove(); URL.revokeObjectURL(burl); }}, 4000);
        }});
    return 'FETCH_IMG';
}})()", b64Url, item.TargetFileName), ct);
                        savedFile = await _cdp.WaitForSingleDownloadAsync(stagingDir, beforeFiles, 20 * 1024, 35000, ct);
                    }

                    await _cdp.ResetDownloadBehaviorToDefaultAsync();

                    if (string.IsNullOrEmpty(savedFile) || !File.Exists(savedFile))
                        throw new IOException(string.Format("Timeout aguardando download da capa '{0}'.", item.TargetFileName));

                    File.Copy(savedFile, targetFullPath, true);
                    try { Directory.Delete(stagingDir, true); } catch { }

                    string dimInfo = "";
                    try
                    {
                        using (System.Drawing.Image imgInfo = System.Drawing.Image.FromFile(targetFullPath))
                        {
                            long kb = Math.Max(1, new FileInfo(targetFullPath).Length / 1024);
                            dimInfo = string.Format(" ({0}x{1} | {2} KB)", imgInfo.Width, imgInfo.Height, kb);
                        }
                    }
                    catch { }

                    _config.SetProfileStatus(profile, "OK");
                    _log(string.Format("[Grok Imagine | Capas 9:16] ✔ Capa '{0}' salva{1} em '{2}'!", item.TargetFileName, dimInfo, coversDir));
                    return true;
                }
                catch (OperationCanceledException)
                {
                    Task ignoredReset = Task.Run(async () =>
                    {
                        try { await _cdp.ResetDownloadBehaviorToDefaultAsync(); } catch { }
                        if (!string.IsNullOrEmpty(stagingDir))
                        {
                            try { Directory.Delete(stagingDir, true); } catch { }
                        }
                    });
                    throw;
                }
                catch (Exception ex)
                {
                    lastErr = ex;
                    needsErrorReset = true;

                    if (ex.Message.IndexOf("QUOTA_EXHAUSTED", StringComparison.OrdinalIgnoreCase) >= 0)
                    {
                        quotaHitInCatch = true;
                        _log(string.Format("[Grok Imagine | Capas 9:16] Limite atingido no perfil '{0}'. Tentando próximo perfil...", profile));
                    }
                    else
                    {
                        _log(string.Format("[Grok Imagine | Capas 9:16] Aviso no perfil '{0}' ao gerar '{1}': {2}",
                            profile, item.TargetFileName, ex.Message));
                    }
                }

                if (needsErrorReset)
                {
                    try { await _cdp.ResetDownloadBehaviorToDefaultAsync(); } catch { }
                    if (!string.IsNullOrEmpty(stagingDir))
                    {
                        try { Directory.Delete(stagingDir, true); } catch { }
                    }
                    if (quotaHitInCatch)
                        continue;
                }
            }

            if (_config.AreAllGrokProfilesMarkedExhausted())
                return false;

            if (lastErr != null)
                _log(string.Format("[Grok Imagine | Capas 9:16] Falha ao gerar '{0}': {1}", item.TargetFileName, lastErr.Message));

            return false;
        }
    }
}
