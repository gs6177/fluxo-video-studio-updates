using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Microsoft.Win32;

namespace FluxoVideoStudio
{
    public partial class MainWindow : Window
    {
        private void RefreshGrokProfileBadges()
        {
            if (_wrapGrokProfileBadges == null) return;
            _wrapGrokProfileBadges.Children.Clear();

            foreach (string prof in _config.GrokProfiles.ToList())
            {
                string st = _config.GetProfileStatus(prof);
                bool isExhausted = st.IndexOf("LIMITE", StringComparison.OrdinalIgnoreCase) >= 0;
                bool isAvailable = st.IndexOf("DISPONÍVEL", StringComparison.OrdinalIgnoreCase) >= 0;

                Brush borderBrush = isExhausted ? AccentRed : (isAvailable ? AccentGreen : BorderSubtle);
                Brush bgBrush = isExhausted ? BrushFromHex("#450A0A") : (isAvailable ? BrushFromHex("#064E3B") : BgInput);
                Brush fgBrush = isExhausted ? BrushFromHex("#FCA5A5") : (isAvailable ? BrushFromHex("#A7F3D0") : TextSecondary);

                Border pill = new Border
                {
                    Background = bgBrush,
                    BorderBrush = borderBrush,
                    BorderThickness = new Thickness(1.5),
                    CornerRadius = new CornerRadius(6),
                    Padding = new Thickness(10, 5, 10, 5),
                    Margin = new Thickness(0, 0, 8, 6)
                };

                StackPanel row = new StackPanel { Orientation = Orientation.Horizontal };
                string capturedProfForToggle = prof;
                TextBlock lblProfStatus = new TextBlock
                {
                    Text = string.Format("● {0}: {1}", prof, st),
                    FontSize = 11.5,
                    FontWeight = FontWeights.Bold,
                    Foreground = fgBrush,
                    VerticalAlignment = VerticalAlignment.Center,
                    Cursor = Cursors.Hand,
                    ToolTip = "Clique para alternar manualmente entre DISPONÍVEL e LIMITE ATINGIDO"
                };
                lblProfStatus.MouseLeftButtonUp += (s, e) =>
                {
                    string cur = _config.GetProfileStatus(capturedProfForToggle);
                    string next = cur.IndexOf("LIMITE", StringComparison.OrdinalIgnoreCase) >= 0 ? "DISPONÍVEL" : "LIMITE ATINGIDO";
                    _config.SetProfileStatus(capturedProfForToggle, next);
                    AppendLog(string.Format("[Contas Grok] Status do perfil '{0}' alterado manualmente para: {1}", capturedProfForToggle, next));
                };
                row.Children.Add(lblProfStatus);

                if (_config.GrokProfiles.Count > 1)
                {
                    string capturedProf = prof;
                    Button btnRemove = CreateStyledButton("✕", Brushes.Transparent, fgBrush, new Thickness(5, 0, 2, 0));
                    btnRemove.BorderThickness = new Thickness(0);
                    btnRemove.FontSize = 10.5;
                    btnRemove.Margin = new Thickness(6, 0, 0, 0);
                    btnRemove.ToolTip = "Remover este perfil da lista de fallback";
                    btnRemove.Click += (s, e) =>
                    {
                        _config.GrokProfiles.RemoveAll(p => string.Equals(p, capturedProf, StringComparison.OrdinalIgnoreCase));
                        if (_txtGrokProfiles != null)
                            _txtGrokProfiles.Text = string.Join(", ", _config.GrokProfiles);
                        _config.SaveUserSettings();
                        RefreshGrokProfileBadges();
                    };
                    row.Children.Add(btnRemove);
                }

                pill.Child = row;
                _wrapGrokProfileBadges.Children.Add(pill);
            }
        }

        private async Task CheckGrokAccountsStatusFromUiAsync()
        {
            if (_isRunning) return;
            SyncSettingsFromUi();
            AppendLog("[Contas Grok] Verificando status de limite de uso nos perfis configurados...");
            try
            {
                using (CancellationTokenSource cts = new CancellationTokenSource(45000))
                {
                    await _grok.CheckAllGrokProfilesStatusAsync(cts.Token);
                }
                RefreshGrokProfileBadges();
            }
            catch (Exception ex)
            {
                AppendLog("[Contas Grok] Erro ao verificar perfis: " + ex.Message);
            }
        }

        private void OnAddGrokProfileClick(object sender, RoutedEventArgs e)
        {
            string newProf = (_txtNewGrokProfile != null ? _txtNewGrokProfile.Text : "").Trim();
            if (string.IsNullOrEmpty(newProf))
            {
                MessageBox.Show("Digite o nome da pasta do perfil do Chrome (ex: Profile 68).", "Adicionar Perfil Grok", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            if (!_config.GrokProfiles.Contains(newProf, StringComparer.OrdinalIgnoreCase))
            {
                _config.GrokProfiles.Add(newProf);
                _config.SetProfileStatus(newProf, "NÃO VERIFICADO");
                if (_txtGrokProfiles != null)
                    _txtGrokProfiles.Text = string.Join(", ", _config.GrokProfiles);
                _config.SaveUserSettings();
                RefreshGrokProfileBadges();
                AppendLog(string.Format("[Contas Grok] Novo perfil adicionado e salvo: '{0}'.", newProf));
            }

            if (_txtNewGrokProfile != null)
                _txtNewGrokProfile.Text = "";
        }

        // =================================================================================================
        // SUGESTÃO E: SELETOR DE VOZES FAVORITAS DO ELEVENLABS COM 1 CLIQUE
        // =================================================================================================

        private bool _updatingVoiceCombos;

        private void RefreshElevenVoicePresetCombos()
        {
            _updatingVoiceCombos = true;
            try
            {
                ComboBox[] combos = new[] { _cmbElevenVoiceQuick, _cmbElevenVoiceSettings };
                foreach (ComboBox cmb in combos)
                {
                    if (cmb == null) continue;
                    cmb.Items.Clear();

                    int selectedIndex = 0;
                    for (int i = 0; i < _config.VoicePresets.Count; i++)
                    {
                        ElevenLabsVoicePreset vp = _config.VoicePresets[i];
                        cmb.Items.Add(new ComboBoxItem { Content = vp.ToString(), Tag = vp });
                        if (!string.IsNullOrEmpty(_config.ElevenLabsUrl) &&
                            _config.ElevenLabsUrl.IndexOf(vp.VoiceId ?? "", StringComparison.OrdinalIgnoreCase) >= 0)
                        {
                            selectedIndex = i;
                        }
                    }

                    if (cmb.Items.Count > 0)
                        cmb.SelectedIndex = selectedIndex;
                }
            }
            finally
            {
                _updatingVoiceCombos = false;
            }
        }

        private void OnQuickVoiceSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (_updatingVoiceCombos || _cmbElevenVoiceQuick == null) return;
            ComboBoxItem item = _cmbElevenVoiceQuick.SelectedItem as ComboBoxItem;
            if (item == null || !(item.Tag is ElevenLabsVoicePreset)) return;
            ApplySelectedVoicePreset((ElevenLabsVoicePreset)item.Tag);
        }

        private void OnSettingsVoiceSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (_updatingVoiceCombos || _cmbElevenVoiceSettings == null) return;
            ComboBoxItem item = _cmbElevenVoiceSettings.SelectedItem as ComboBoxItem;
            if (item == null || !(item.Tag is ElevenLabsVoicePreset)) return;
            ApplySelectedVoicePreset((ElevenLabsVoicePreset)item.Tag);
        }

        private void ApplySelectedVoicePreset(ElevenLabsVoicePreset preset)
        {
            if (preset == null) return;
            _config.ElevenLabsUrl = preset.BuildUrl();
            if (_txtElevenUrl != null)
                _txtElevenUrl.Text = _config.ElevenLabsUrl;
            _config.SaveUserSettings();
            RefreshElevenVoicePresetCombos();
            AppendLog(string.Format("[ElevenLabs Voz] Voz ativa alterada para: {0} -> {1}", preset.Name, _config.ElevenLabsUrl));
        }

        private void ShowAddElevenLabsVoiceDialog()
        {
            Window dlg = new Window
            {
                Title = "🎙 Cadastrar Nova Voz Favorita do ElevenLabs",
                Width = 520,
                Height = 310,
                WindowStartupLocation = WindowStartupLocation.CenterOwner,
                Owner = this,
                Background = BgPanel,
                Foreground = TextPrimary,
                ResizeMode = ResizeMode.NoResize
            };

            StackPanel sp = new StackPanel { Margin = new Thickness(18) };

            sp.Children.Add(new TextBlock { Text = "Nome da Voz (ex: Voz Feminina Novela, Voz Terror Grave):", FontSize = 12, Foreground = TextPrimary, Margin = new Thickness(0, 0, 0, 4) });
            TextBox txtName = CreateStyledTextBox("Ex: Narrador Misterioso");
            txtName.Margin = new Thickness(0, 0, 0, 10);
            sp.Children.Add(txtName);

            sp.Children.Add(new TextBlock { Text = "Categoria / Estilo (ex: Novela / Reflexão, Terror):", FontSize = 12, Foreground = TextPrimary, Margin = new Thickness(0, 0, 0, 4) });
            TextBox txtCat = CreateStyledTextBox("Novela / Reflexão");
            txtCat.Text = "Novela / Reflexão";
            txtCat.Margin = new Thickness(0, 0, 0, 10);
            sp.Children.Add(txtCat);

            sp.Children.Add(new TextBlock { Text = "Voice ID ou URL completa do ElevenLabs:", FontSize = 12, Foreground = TextPrimary, Margin = new Thickness(0, 0, 0, 4) });
            TextBox txtVoiceId = CreateStyledTextBox("Ex: ppLqTilh7rH7fbUVlXsf ou https://elevenlabs.io/app/...?voiceId=...");
            txtVoiceId.Margin = new Thickness(0, 0, 0, 16);
            sp.Children.Add(txtVoiceId);

            StackPanel btns = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };
            Button btnCancel = CreateStyledButton("Cancelar", BgCard, TextPrimary, new Thickness(12, 6, 12, 6));
            btnCancel.Margin = new Thickness(0, 0, 10, 0);
            btnCancel.Click += (s, e) => dlg.DialogResult = false;
            btns.Children.Add(btnCancel);

            Button btnSave = CreateStyledButton("💾 Salvar e Selecionar Voz", AccentGreen, Brushes.White, new Thickness(14, 6, 14, 6));
            btnSave.FontWeight = FontWeights.Bold;
            btnSave.Click += (s, e) => dlg.DialogResult = true;
            btns.Children.Add(btnSave);

            sp.Children.Add(btns);
            dlg.Content = sp;

            if (dlg.ShowDialog() == true)
            {
                string name = (txtName.Text ?? "").Trim();
                string cat = (txtCat.Text ?? "Novela").Trim();
                string rawVid = (txtVoiceId.Text ?? "").Trim();
                if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(rawVid)) return;

                Match m = Regex.Match(rawVid, @"voiceId=([A-Za-z0-9]+)", RegexOptions.IgnoreCase);
                string cleanVid = m.Success ? m.Groups[1].Value : rawVid;

                ElevenLabsVoicePreset newPreset = new ElevenLabsVoicePreset
                {
                    Name = name,
                    Category = cat,
                    VoiceId = cleanVid
                };
                _config.VoicePresets.Add(newPreset);
                ApplySelectedVoicePreset(newPreset);
            }
        }

        private class ChromeLocalProfileItem
        {
            public string DirName;
            public string DisplayName;
            public string Email;
            public CheckBox ChkGrok;
            public RadioButton RbFlow;
            public CheckBox ChkEleven;
        }

        private List<ChromeLocalProfileItem> DiscoverLocalChromeProfiles()
        {
            List<ChromeLocalProfileItem> result = new List<ChromeLocalProfileItem>();
            string localAppData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            string userDataDir = Path.Combine(localAppData, @"Google\Chrome\User Data");
            string localStatePath = Path.Combine(userDataDir, "Local State");

            Dictionary<string, ChromeLocalProfileItem> byDir = new Dictionary<string, ChromeLocalProfileItem>(StringComparer.OrdinalIgnoreCase);

            try
            {
                if (File.Exists(localStatePath))
                {
                    string json = File.ReadAllText(localStatePath, Encoding.UTF8);
                    System.Web.Script.Serialization.JavaScriptSerializer ser = new System.Web.Script.Serialization.JavaScriptSerializer();
                    ser.MaxJsonLength = int.MaxValue;
                    Dictionary<string, object> root = ser.Deserialize<Dictionary<string, object>>(json);
                    if (root != null && root.ContainsKey("profile") && root["profile"] is Dictionary<string, object>)
                    {
                        Dictionary<string, object> profObj = (Dictionary<string, object>)root["profile"];
                        if (profObj.ContainsKey("info_cache") && profObj["info_cache"] is Dictionary<string, object>)
                        {
                            Dictionary<string, object> cache = (Dictionary<string, object>)profObj["info_cache"];
                            foreach (KeyValuePair<string, object> kv in cache)
                            {
                                Dictionary<string, object> info = kv.Value as Dictionary<string, object>;
                                if (info == null) continue;
                                string name = info.ContainsKey("name") ? Convert.ToString(info["name"] ?? "").Trim() : "";
                                string email = info.ContainsKey("user_name") ? Convert.ToString(info["user_name"] ?? "").Trim() : "";
                                byDir[kv.Key] = new ChromeLocalProfileItem
                                {
                                    DirName = kv.Key,
                                    DisplayName = string.IsNullOrEmpty(name) ? kv.Key : name,
                                    Email = email
                                };
                            }
                        }
                    }
                }
            }
            catch { }

            try
            {
                if (Directory.Exists(userDataDir))
                {
                    foreach (string sub in Directory.GetDirectories(userDataDir))
                    {
                        string dn = Path.GetFileName(sub);
                        if (string.Equals(dn, "Default", StringComparison.OrdinalIgnoreCase) ||
                            dn.StartsWith("Profile ", StringComparison.OrdinalIgnoreCase))
                        {
                            if (!byDir.ContainsKey(dn))
                            {
                                byDir[dn] = new ChromeLocalProfileItem
                                {
                                    DirName = dn,
                                    DisplayName = dn,
                                    Email = ""
                                };
                            }
                        }
                    }
                }
            }
            catch { }

            if (byDir.Count == 0)
            {
                byDir["Default"] = new ChromeLocalProfileItem { DirName = "Default", DisplayName = "Perfil Padrão", Email = "" };
                byDir["Profile 1"] = new ChromeLocalProfileItem { DirName = "Profile 1", DisplayName = "Profile 1", Email = "" };
                byDir["Profile 2"] = new ChromeLocalProfileItem { DirName = "Profile 2", DisplayName = "Profile 2", Email = "" };
            }

            result = byDir.Values
                .OrderBy(p => string.Equals(p.DirName, "Default", StringComparison.OrdinalIgnoreCase) ? 0 : 1)
                .ThenBy(p =>
                {
                    int num;
                    if (p.DirName.StartsWith("Profile ", StringComparison.OrdinalIgnoreCase) &&
                        int.TryParse(p.DirName.Substring(8).Trim(), out num))
                        return num;
                    return 9999;
                })
                .ToList();

            return result;
        }

        private void ShowChromeProfileSelectorDialog()
        {
            SyncSettingsFromUi();
            List<ChromeLocalProfileItem> profiles = DiscoverLocalChromeProfiles();

            Window dlg = new Window
            {
                Title = "Configurar Contas do Chrome neste PC (Grok Imagine / Google Flow / ElevenLabs)",
                Width = 860,
                Height = 620,
                WindowStartupLocation = WindowStartupLocation.CenterOwner,
                Owner = this,
                Background = BgPanel,
                Foreground = TextPrimary
            };

            Grid root = new Grid { Margin = new Thickness(16) };
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

            StackPanel header = new StackPanel { Margin = new Thickness(0, 0, 0, 12) };
            header.Children.Add(new TextBlock
            {
                Text = "Perfis do Google Chrome encontrados neste computador:",
                FontSize = 14,
                FontWeight = FontWeights.Bold,
                Foreground = TextPrimary
            });
            header.Children.Add(new TextBlock
            {
                Text = "Marque quais perfis deste PC você usa para o Grok Imagine, qual usa para o Google Flow e quais usa para o ElevenLabs. Use os botões 'Abrir' para fazer login se ainda não estiver logado.",
                FontSize = 11.5,
                Foreground = TextSecondary,
                TextWrapping = TextWrapping.Wrap,
                Margin = new Thickness(0, 4, 0, 0)
            });
            Grid.SetRow(header, 0);
            root.Children.Add(header);

            ScrollViewer sv = new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto };
            StackPanel listStack = new StackPanel();

            foreach (ChromeLocalProfileItem item in profiles)
            {
                Border card = new Border
                {
                    Background = BgCard,
                    BorderBrush = BorderSubtle,
                    BorderThickness = new Thickness(1),
                    CornerRadius = new CornerRadius(6),
                    Padding = new Thickness(10, 8, 10, 8),
                    Margin = new Thickness(0, 0, 0, 6)
                };

                Grid row = new Grid();
                row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
                row.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
                row.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

                StackPanel infoCol = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
                infoCol.Children.Add(new TextBlock
                {
                    Text = string.Format("{0}  —  {1}", item.DirName, item.DisplayName),
                    FontSize = 12.5,
                    FontWeight = FontWeights.Bold,
                    Foreground = TextPrimary
                });
                infoCol.Children.Add(new TextBlock
                {
                    Text = string.IsNullOrEmpty(item.Email) ? "(Sem e-mail Google sincronizado)" : item.Email,
                    FontSize = 11,
                    Foreground = TextSecondary
                });
                Grid.SetColumn(infoCol, 0);
                row.Children.Add(infoCol);

                StackPanel checksCol = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(12, 0, 12, 0) };
                item.ChkGrok = new CheckBox
                {
                    Content = "Grok",
                    Foreground = TextPrimary,
                    IsChecked = _config.GrokProfiles.Any(p => string.Equals(p, item.DirName, StringComparison.OrdinalIgnoreCase)),
                    Margin = new Thickness(0, 0, 12, 0),
                    VerticalAlignment = VerticalAlignment.Center
                };
                checksCol.Children.Add(item.ChkGrok);

                item.RbFlow = new RadioButton
                {
                    GroupName = "FlowProfGroup",
                    Content = "Flow",
                    Foreground = TextPrimary,
                    IsChecked = string.Equals(_config.FlowProfile, item.DirName, StringComparison.OrdinalIgnoreCase),
                    Margin = new Thickness(0, 0, 12, 0),
                    VerticalAlignment = VerticalAlignment.Center
                };
                checksCol.Children.Add(item.RbFlow);

                item.ChkEleven = new CheckBox
                {
                    Content = "ElevenLabs",
                    Foreground = TextPrimary,
                    IsChecked = _config.ElevenLabsProfiles.Any(p => string.Equals(p, item.DirName, StringComparison.OrdinalIgnoreCase)),
                    VerticalAlignment = VerticalAlignment.Center
                };
                checksCol.Children.Add(item.ChkEleven);
                Grid.SetColumn(checksCol, 1);
                row.Children.Add(checksCol);

                StackPanel openBtns = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };
                string capDir = item.DirName;

                Button bGrok = CreateStyledButton("Abrir Grok", BgInput, TextPrimary, new Thickness(8, 4, 8, 4));
                bGrok.FontSize = 10.5;
                bGrok.Margin = new Thickness(0, 0, 4, 0);
                bGrok.Click += (s, e) => _cdp.LaunchChromeProfileWindow(capDir, "https://grok.com/imagine");
                openBtns.Children.Add(bGrok);

                Button bFlow = CreateStyledButton("Abrir Flow", BgInput, TextPrimary, new Thickness(8, 4, 8, 4));
                bFlow.FontSize = 10.5;
                bFlow.Margin = new Thickness(0, 0, 4, 0);
                bFlow.Click += (s, e) => _cdp.LaunchChromeProfileWindow(capDir, _config.FlowProjectUrl);
                openBtns.Children.Add(bFlow);

                Button bEl = CreateStyledButton("Abrir Eleven", BgInput, TextPrimary, new Thickness(8, 4, 8, 4));
                bEl.FontSize = 10.5;
                bEl.Click += (s, e) => _cdp.LaunchChromeProfileWindow(capDir, _config.ElevenLabsUrl);
                openBtns.Children.Add(bEl);

                Grid.SetColumn(openBtns, 2);
                row.Children.Add(openBtns);

                card.Child = row;
                listStack.Children.Add(card);
            }

            sv.Content = listStack;
            Grid.SetRow(sv, 1);
            root.Children.Add(sv);

            StackPanel footer = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(0, 12, 0, 0) };

            Button btnCancel = CreateStyledButton("Cancelar", BgCard, TextPrimary, new Thickness(14, 7, 14, 7));
            btnCancel.Margin = new Thickness(0, 0, 10, 0);
            btnCancel.Click += (s, e) => dlg.DialogResult = false;
            footer.Children.Add(btnCancel);

            Button btnSave = CreateStyledButton("💾 Salvar e Aplicar Perfis neste PC", AccentGreen, Brushes.White, new Thickness(16, 7, 16, 7));
            btnSave.FontWeight = FontWeights.Bold;
            btnSave.Click += (s, e) => dlg.DialogResult = true;
            footer.Children.Add(btnSave);

            Grid.SetRow(footer, 2);
            root.Children.Add(footer);
            dlg.Content = root;

            if (dlg.ShowDialog() == true)
            {
                List<string> newGrok = profiles.Where(p => p.ChkGrok.IsChecked == true).Select(p => p.DirName).ToList();
                ChromeLocalProfileItem flowSel = profiles.FirstOrDefault(p => p.RbFlow.IsChecked == true);
                List<string> newEleven = profiles.Where(p => p.ChkEleven.IsChecked == true).Select(p => p.DirName).ToList();

                if (newGrok.Count > 0)
                {
                    _config.GrokProfiles = newGrok;
                    if (_txtGrokProfiles != null) _txtGrokProfiles.Text = string.Join(", ", newGrok);
                }
                if (flowSel != null)
                {
                    _config.FlowProfile = flowSel.DirName;
                    if (_txtFlowProfile != null) _txtFlowProfile.Text = flowSel.DirName;
                }
                if (newEleven.Count > 0)
                {
                    _config.ElevenLabsProfiles = newEleven;
                    if (_txtElevenProfiles != null) _txtElevenProfiles.Text = string.Join(", ", newEleven);
                }

                _config.SaveUserSettings();
                RefreshGrokProfileBadges();
                AppendLog(string.Format("[Configurações] Perfis do Chrome atualizados neste PC -> Grok: [{0}] | Flow: {1} | ElevenLabs: [{2}]",
                    string.Join(", ", _config.GrokProfiles), _config.FlowProfile, string.Join(", ", _config.ElevenLabsProfiles)));
            }
        }

        private string _lastDismissedUpdateVersion = "";
        private bool _isUpdatePromptOpen = false;

        private async Task MonitorAndPromptRemoteUpdateOnOtherPcAsync()
        {
            await Task.Delay(2500);
            while (true)
            {
                try
                {
                    if (!_isRunning && !_isUpdatePromptOpen)
                    {
                        _config.LoadSharedRemoteUpdateConfig();
                        string repo = (_config.RemoteUpdateRepo ?? "").Trim();
                        if (string.IsNullOrEmpty(repo))
                            repo = "gs6177/fluxo-video-studio-updates";

                        if (!repo.StartsWith("http", StringComparison.OrdinalIgnoreCase))
                        {
                            System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072; // Tls12
                            string cleanRepo = repo.Replace("https://github.com/", "").Replace(".git", "").Trim('/');
                            string apiUrl = string.Format("https://api.github.com/repos/{0}/contents/version.json?t={1}",
                                cleanRepo, DateTime.UtcNow.Ticks);
                            string rawUrl = string.Format("https://raw.githubusercontent.com/{0}/main/version.json?t={1}",
                                cleanRepo, DateTime.UtcNow.Ticks);

                            string json = await Task.Run(() =>
                            {
                                try
                                {
                                    using (System.Net.WebClient wc = new System.Net.WebClient())
                                    {
                                        wc.Encoding = Encoding.UTF8;
                                        wc.Headers.Add("User-Agent", "FluxoVideoStudio-AutoUpdater");
                                        wc.Headers.Add("Accept", "application/vnd.github.v3.raw");
                                        wc.Headers.Add("Cache-Control", "no-cache");
                                        return wc.DownloadString(apiUrl);
                                    }
                                }
                                catch
                                {
                                    using (System.Net.WebClient wc = new System.Net.WebClient())
                                    {
                                        wc.Encoding = Encoding.UTF8;
                                        wc.Headers.Add("User-Agent", "FluxoVideoStudio-AutoUpdater");
                                        wc.Headers.Add("Cache-Control", "no-cache");
                                        return wc.DownloadString(rawUrl);
                                    }
                                }
                            });

                            if (!string.IsNullOrWhiteSpace(json))
                            {
                                System.Web.Script.Serialization.JavaScriptSerializer ser = new System.Web.Script.Serialization.JavaScriptSerializer();
                                Dictionary<string, object> d = ser.Deserialize<Dictionary<string, object>>(json);
                                if (d != null && d.ContainsKey("Version"))
                                {
                                    string remoteVer = Convert.ToString(d["Version"] ?? "").Trim();
                                    string updatedAt = d.ContainsKey("UpdatedAt") ? Convert.ToString(d["UpdatedAt"] ?? "").Trim() : remoteVer;
                                    string localVer = (_config.LocalInstalledVersion ?? "").Trim();

                                    if (!string.IsNullOrEmpty(remoteVer) &&
                                        !string.Equals(remoteVer, localVer, StringComparison.OrdinalIgnoreCase) &&
                                        !string.Equals(remoteVer, _lastDismissedUpdateVersion, StringComparison.OrdinalIgnoreCase))
                                    {
                                        string pullScript = Path.Combine(PipelineConfig.GetAppRootDir(), "Baixar_Atualizacao_Remota.ps1");
                                        if (File.Exists(pullScript))
                                        {
                                            Dispatcher.Invoke(() =>
                                            {
                                                PromptOtherPcForUpdateDialog(cleanRepo, remoteVer, updatedAt, pullScript);
                                            });
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                catch { }

                await Task.Delay(20000);
            }
        }

        private void PromptOtherPcForUpdateDialog(string cleanRepo, string remoteVer, string updatedAt, string pullScript)
        {
            if (_isUpdatePromptOpen) return;
            _isUpdatePromptOpen = true;
            try
            {
                try { System.Media.SystemSounds.Asterisk.Play(); } catch { }

                AppendLog(string.Format("[Atualização Disponível] Nova versão ({0}) liberada pelo PC Principal!", remoteVer));

                Window notif = new Window
                {
                    Title = "🔔 Nova Atualização Disponível — Fluxo Vídeo IA Studio",
                    Width = 520,
                    Height = 250,
                    WindowStartupLocation = WindowStartupLocation.CenterScreen,
                    Topmost = true,
                    Background = BgPanel,
                    Foreground = TextPrimary,
                    ResizeMode = ResizeMode.NoResize
                };

                StackPanel sp = new StackPanel { Margin = new Thickness(20) };

                sp.Children.Add(new TextBlock
                {
                    Text = "🔔 Nova Atualização Disponível!",
                    FontSize = 16,
                    FontWeight = FontWeights.Bold,
                    Foreground = AccentGreen,
                    Margin = new Thickness(0, 0, 0, 8)
                });

                sp.Children.Add(new TextBlock
                {
                    Text = string.Format(
                        "Uma nova atualização do programa e das 5 Skills foi liberada pelo PC Principal ({0}).\n\nDeseja baixar e instalar a atualização agora?\n(Suas contas do Chrome e pastas configuradas neste PC serão mantidas).",
                        updatedAt),
                    FontSize = 12.5,
                    Foreground = TextPrimary,
                    TextWrapping = TextWrapping.Wrap,
                    Margin = new Thickness(0, 0, 0, 20)
                });

                StackPanel btnRow = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };

                Button btnLater = CreateStyledButton("Mais Tarde", BgCard, TextSecondary, new Thickness(14, 8, 14, 8));
                btnLater.Margin = new Thickness(0, 0, 10, 0);
                btnLater.Click += (s, e) =>
                {
                    _lastDismissedUpdateVersion = remoteVer;
                    notif.DialogResult = false;
                };
                btnRow.Children.Add(btnLater);

                Button btnNow = CreateStyledButton("🔄 Sim, Atualizar Agora", AccentGreen, Brushes.White, new Thickness(16, 8, 16, 8));
                btnNow.FontWeight = FontWeights.Bold;
                btnNow.Click += (s, e) => notif.DialogResult = true;
                btnRow.Children.Add(btnNow);

                sp.Children.Add(btnRow);
                notif.Content = sp;

                if (notif.ShowDialog() == true)
                {
                    int curPid = Process.GetCurrentProcess().Id;
                    ProcessStartInfo psi = new ProcessStartInfo
                    {
                        FileName = "powershell.exe",
                        Arguments = string.Format("-NoProfile -ExecutionPolicy Bypass -File \"{0}\" -RepoOrUrl \"{1}\" -WaitPid {2} -RestartApp",
                            pullScript, cleanRepo, curPid),
                        UseShellExecute = true,
                        WorkingDirectory = PipelineConfig.GetAppRootDir()
                    };
                    Process.Start(psi);
                    Application.Current.Shutdown();
                }
            }
            finally
            {
                _isUpdatePromptOpen = false;
            }
        }

        private void ShowRemoteUpdateDialog()
        {
            if (!PipelineConfig.IsMasterDeveloperPc())
                return;

            Window dlg = new Window
            {
                Title = "☁️ Publicar Atualização Remota (Exclusivo deste PC Principal)",
                Width = 680,
                Height = 470,
                WindowStartupLocation = WindowStartupLocation.CenterOwner,
                Owner = this,
                Background = BgPanel,
                Foreground = TextPrimary,
                ResizeMode = ResizeMode.NoResize
            };

            StackPanel sp = new StackPanel { Margin = new Thickness(18) };

            sp.Children.Add(new TextBlock
            {
                Text = "Publicação Remota via GitHub (Exclusivo do seu PC Principal)",
                FontSize = 14,
                FontWeight = FontWeights.Bold,
                Foreground = TextPrimary,
                Margin = new Thickness(0, 0, 0, 6)
            });

            sp.Children.Add(new TextBlock
            {
                Text = "• Este botão aparece SOMENTE no seu PC principal.\n• Quando você clicar em 'Publicar Atualização no GitHub', os outros PCs atualizarão sozinhos automaticamente ao abrirem o programa!",
                FontSize = 11.5,
                Foreground = TextSecondary,
                TextWrapping = TextWrapping.Wrap,
                Margin = new Thickness(0, 0, 0, 14)
            });

            sp.Children.Add(new TextBlock
            {
                Text = "Repositório GitHub (ex: seu-usuario/fluxo-video-studio-updates) ou Link Direto (.zip):",
                FontSize = 12,
                FontWeight = FontWeights.SemiBold,
                Foreground = TextPrimary,
                Margin = new Thickness(0, 0, 0, 4)
            });
            TextBox txtRepo = CreateStyledTextBox("Deixe em branco na 1ª publicação para criar 'fluxo-video-studio-updates' automaticamente");
            txtRepo.Text = _config.RemoteUpdateRepo ?? "";
            txtRepo.Margin = new Thickness(0, 0, 0, 12);
            sp.Children.Add(txtRepo);

            Grid tokenHeader = new Grid { Margin = new Thickness(0, 0, 0, 4) };
            tokenHeader.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            tokenHeader.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            tokenHeader.Children.Add(new TextBlock
            {
                Text = "Token do GitHub (Necessário APENAS neste PC principal para enviar atualizações):",
                FontSize = 12,
                FontWeight = FontWeights.SemiBold,
                Foreground = TextPrimary,
                VerticalAlignment = VerticalAlignment.Center
            });

            Button btnGenToken = CreateStyledButton("🔑 Abrir GitHub para Gerar Token (1 Clique)", BgCard, AccentBlue, new Thickness(10, 4, 10, 4));
            btnGenToken.FontSize = 11;
            btnGenToken.Click += (s, e) =>
            {
                try
                {
                    Process.Start("https://github.com/settings/tokens/new?description=FluxoVideoStudio&scopes=repo");
                }
                catch { }
            };
            Grid.SetColumn(btnGenToken, 1);
            tokenHeader.Children.Add(btnGenToken);
            sp.Children.Add(tokenHeader);

            TextBox txtToken = CreateStyledTextBox("Cole aqui seu Personal Access Token do GitHub (ghp_...)");
            txtToken.Text = _config.RemoteUpdateToken ?? "";
            txtToken.Margin = new Thickness(0, 0, 0, 14);
            sp.Children.Add(txtToken);

            TextBlock lblStatus = new TextBlock
            {
                Text = "Pronto.",
                FontSize = 12,
                FontWeight = FontWeights.SemiBold,
                Foreground = AccentAmber,
                TextWrapping = TextWrapping.Wrap,
                Margin = new Thickness(0, 0, 0, 14)
            };
            sp.Children.Add(lblStatus);

            StackPanel actionRow = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 0, 0, 14) };

            Button btnPull = CreateStyledButton("🔄 Baixar e Instalar Atualização Agora (Outro PC)", AccentGreen, Brushes.White, new Thickness(14, 9, 14, 9));
            btnPull.FontWeight = FontWeights.Bold;
            btnPull.Margin = new Thickness(0, 0, 10, 0);

            Button btnPush = CreateStyledButton("☁️ Publicar Atualização no GitHub (PC Principal)", BrushFromHex("#0284C7"), Brushes.White, new Thickness(14, 9, 14, 9));
            btnPush.FontWeight = FontWeights.Bold;

            btnPush.Click += async (s, e) =>
            {
                string repoVal = (txtRepo.Text ?? "").Trim();
                string tokenVal = (txtToken.Text ?? "").Trim();
                if (string.IsNullOrEmpty(tokenVal))
                {
                    MessageBox.Show("Para publicar a partir deste PC, clique em '🔑 Abrir GitHub para Gerar Token (1 Clique)', role até o final da página do GitHub, clique no botão verde 'Generate token' e cole o código aqui.", "Token do GitHub Necessário", MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }

                _config.RemoteUpdateRepo = repoVal;
                _config.RemoteUpdateToken = tokenVal;
                _config.SaveUserSettings();

                btnPush.IsEnabled = false;
                btnPull.IsEnabled = false;
                lblStatus.Foreground = AccentAmber;
                lblStatus.Text = "⏳ Empacotando Programa + 6 Skills (incluindo gem 3D Pixar/Disney) e enviando para o GitHub...";

                try
                {
                    string scriptPath = Path.Combine(PipelineConfig.GetAppRootDir(), "Publicar_Atualizacao_Remota.ps1");
                    string output = await Task.Run(() =>
                    {
                        ProcessStartInfo psi = new ProcessStartInfo
                        {
                            FileName = "powershell.exe",
                            Arguments = string.Format("-NoProfile -ExecutionPolicy Bypass -File \"{0}\" -Token \"{1}\" -Repo \"{2}\"",
                                scriptPath, tokenVal, repoVal),
                            UseShellExecute = false,
                            RedirectStandardOutput = true,
                            RedirectStandardError = true,
                            CreateNoWindow = true,
                            StandardOutputEncoding = Encoding.UTF8,
                            StandardErrorEncoding = Encoding.UTF8
                        };
                        using (Process p = Process.Start(psi))
                        {
                            string stdOut = p.StandardOutput.ReadToEnd();
                            string stdErr = p.StandardError.ReadToEnd();
                            p.WaitForExit();
                            if (p.ExitCode != 0)
                                throw new InvalidOperationException((stdErr + "\n" + stdOut).Trim());
                            return stdOut;
                        }
                    });

                    _config.LoadUserSettings();
                    txtRepo.Text = _config.RemoteUpdateRepo;
                    lblStatus.Foreground = AccentGreen;
                    lblStatus.Text = string.Format("✅ Publicado com sucesso em '{0}'! Agora no outro PC basta clicar em 'Baixar e Instalar Atualização Agora'.", _config.RemoteUpdateRepo);
                    AppendLog(string.Format("[Atualização Remota] Publicada com sucesso no GitHub: https://github.com/{0}", _config.RemoteUpdateRepo));
                }
                catch (Exception ex)
                {
                    lblStatus.Foreground = AccentRed;
                    lblStatus.Text = "❌ Erro ao publicar: " + ex.Message;
                }
                finally
                {
                    btnPush.IsEnabled = true;
                    btnPull.IsEnabled = true;
                }
            };

            btnPull.Click += (s, e) =>
            {
                string repoVal = (txtRepo.Text ?? "").Trim();
                string tokenVal = (txtToken.Text ?? "").Trim();
                if (string.IsNullOrEmpty(repoVal))
                {
                    MessageBox.Show("Informe o nome do Repositório GitHub (ex: usuario/fluxo-video-studio-updates) ou link direto do .zip.", "Repositório Necessário", MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }

                _config.RemoteUpdateRepo = repoVal;
                _config.RemoteUpdateToken = tokenVal;
                _config.SaveUserSettings();

                string pullScript = Path.Combine(PipelineConfig.GetAppRootDir(), "Baixar_Atualizacao_Remota.ps1");
                if (!File.Exists(pullScript))
                {
                    MessageBox.Show("Script Baixar_Atualizacao_Remota.ps1 não encontrado na pasta do programa.", "Erro", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                int curPid = Process.GetCurrentProcess().Id;
                ProcessStartInfo psi = new ProcessStartInfo
                {
                    FileName = "powershell.exe",
                    Arguments = string.Format("-NoProfile -ExecutionPolicy Bypass -File \"{0}\" -RepoOrUrl \"{1}\" -Token \"{2}\" -WaitPid {3} -RestartApp",
                        pullScript, repoVal, tokenVal, curPid),
                    UseShellExecute = true,
                    WorkingDirectory = PipelineConfig.GetAppRootDir()
                };
                Process.Start(psi);
                Application.Current.Shutdown();
            };

            actionRow.Children.Add(btnPull);
            actionRow.Children.Add(btnPush);
            sp.Children.Add(actionRow);

            StackPanel bottomRow = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };
            Button btnClose = CreateStyledButton("Salvar e Fechar", BgCard, TextPrimary, new Thickness(14, 7, 14, 7));
            btnClose.Click += (s, e) =>
            {
                _config.RemoteUpdateRepo = (txtRepo.Text ?? "").Trim();
                _config.RemoteUpdateToken = (txtToken.Text ?? "").Trim();
                _config.SaveUserSettings();
                dlg.Close();
            };
            bottomRow.Children.Add(btnClose);
            sp.Children.Add(bottomRow);

            dlg.Content = sp;
            dlg.ShowDialog();
        }
    }
}
