using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace FluxoVideoStudio
{
    public class ElevenLabsAutomation
    {
        private readonly CdpController _cdp;
        private readonly PipelineConfig _config;
        private readonly Action<string> _log;

        public ElevenLabsAutomation(CdpController cdp, PipelineConfig config, Action<string> logger)
        {
            _cdp = cdp;
            _config = config;
            _log = logger ?? delegate { };
        }

        public async Task<bool> RunAsync(EpisodeWorkItem ep, CancellationToken ct)
        {
            if (string.IsNullOrWhiteSpace(ep.UnifiedNarratorText))
            {
                _log("[ElevenLabs] Este episódio não possui falas de 'O Narrador:' (100% diálogo de personagens). Pulando ElevenLabs!");
                return false;
            }

            if (!Directory.Exists(ep.TakesDir))
                Directory.CreateDirectory(ep.TakesDir);

            // Salva cópia do texto unificado do narrador na pasta do episódio para registro
            string narTxtOut = Path.Combine(ep.EpisodePath, "narrador_unificado.txt");
            File.WriteAllText(narTxtOut, ep.UnifiedNarratorText, new UTF8Encoding(false));

            _log(string.Format("[ElevenLabs] Iniciando síntese do Narrador ({0} caracteres, voz 'David - Documentary' ppLqTilh7rH7fbUVlXsf)...",
                ep.UnifiedNarratorText.Length));

            string rawMp3Dest = Path.Combine(ep.EpisodePath, "Narrador_Completo.mp3");
            bool generated = false;
            Exception lastErr = null;

            foreach (string profile in _config.ElevenLabsProfiles)
            {
                ct.ThrowIfCancellationRequested();
                try
                {
                    _log(string.Format("[ElevenLabs] Abrindo link oficial no perfil autorizado '{0}'...", profile));
                    bool outOfCredits = await TrySynthesizeWithProfileAsync(ep, profile, ep.UnifiedNarratorText, ep.TakesDir, rawMp3Dest, ct);
                    if (outOfCredits)
                    {
                        _log(string.Format("[ElevenLabs | Regra 21] Créditos insuficientes ou bloqueio de plano no perfil '{0}'. Alternando automaticamente para perfil fallback...", profile));
                        continue;
                    }
                    generated = true;
                    break;
                }
                catch (OperationCanceledException)
                {
                    throw;
                }
                catch (Exception ex)
                {
                    lastErr = ex;
                    _log(string.Format("[ElevenLabs] Aviso no perfil '{0}': {1}. Tentando próximo perfil...", profile, ex.Message));
                }
            }

            if (!generated || !File.Exists(rawMp3Dest))
            {
                throw new InvalidOperationException(
                    "Não foi possível gerar o áudio do Narrador no ElevenLabs nos perfis autorizados." +
                    (lastErr != null ? " Último erro: " + lastErr.Message : ""));
            }

            // PASSO 3 OBRIGATÓRIO: Travar Silêncio (-40 dB / 0,3s -> 0,3s / início + meio + fim) e salvar em .wav PCM
            string wavInTakes = Path.Combine(ep.TakesDir, "Narrador_Take_01.wav");
            string wavInEpRoot = Path.Combine(ep.EpisodePath, "Narrador_Completo.wav");
            RunSilenceTruncationToWav(_config, _log, rawMp3Dest, wavInTakes);
            File.Copy(wavInTakes, wavInEpRoot, true);

            EpisodeParser.RefreshDiskCounters(ep);
            _log(string.Format("[ElevenLabs + FFmpeg] Áudio do Narrador finalizado e silêncio truncado (-40dB / 0,3s): '{0}'", wavInTakes));
            return true;
        }

        private async Task WaitForElevenLabsEditorReadyAsync(string sess, CancellationToken ct)
        {
            DateTime deadline = DateTime.UtcNow.AddSeconds(30);
            while (DateTime.UtcNow < deadline)
            {
                ct.ThrowIfCancellationRequested();
                string st = await _cdp.EvalStringAsync(sess, @"
(function(){
    var hasEditor = !!Array.from(document.querySelectorAll('textarea, div[contenteditable=""true""], [role=""textbox""]'))
        .find(el => {
            var r = el.getBoundingClientRect();
            return r.width > 200 && r.height > 60;
        });
    var hasBtn = !!Array.from(document.querySelectorAll('button'))
        .find(b => {
            var al = (b.getAttribute('aria-label') || '');
            var txt = (b.innerText || '').trim();
            return b.getBoundingClientRect().width > 20 &&
                   (al.indexOf('Gerar fala') >= 0 || al.indexOf('Generate speech') >= 0 ||
                    txt.indexOf('Gerar fala') >= 0 || txt.indexOf('Generate speech') >= 0);
        });
    return (hasEditor && hasBtn) ? 'READY' : 'WAIT';
})()", ct);
                if (st == "READY")
                {
                    await Task.Delay(1500, ct);
                    return;
                }

                await Task.Delay(500, ct);
            }
        }

        private async Task<bool> TrySynthesizeWithProfileAsync(
            EpisodeWorkItem ep,
            string profile,
            string unifiedText,
            string takesDir,
            string destMp3Path,
            CancellationToken ct)
        {
            string sess = await _cdp.OpenOrAttachProfileTabAsync(
                profile,
                _config.ElevenLabsUrl,
                "elevenlabs.io",
                true,
                ct);

            await WaitForElevenLabsEditorReadyAsync(sess, ct);
            await DismissPromoModalsAsync(sess, ct);

            if (await HasCreditOrPlanBlockAsync(sess, unifiedText.Length, ct))
                return true;

            LastActionHistoryStore.RecordAction(
                ep,
                "ElevenLabs",
                "Inserindo texto do Narrador e sintetizando áudio no ElevenLabs",
                profile,
                sess,
                _config.ElevenLabsUrl,
                "Narrador_Completo.mp3",
                1,
                1,
                unifiedText,
                null,
                "EmExecucao");

            // 1. Inserir texto completo do Narrador no campo central do Text to Speech
            _log("[ElevenLabs] Inserindo texto unificado do Narrador no editor Text to Speech...");
            bool inserted = await InjectNarratorTextAsync(sess, unifiedText, ct);
            if (!inserted)
                throw new InvalidOperationException("Área de texto central do Text to Speech não encontrada no ElevenLabs.");

            await Task.Delay(800, ct);

            if (await HasCreditOrPlanBlockAsync(sess, unifiedText.Length, ct))
                return true;

            // 2. Capturar estado inicial do player/botão Baixar e localizar botão preto "Gerar fala" / "Generate speech"
            Dictionary<string, object> preState = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var aud = document.querySelector('audio');
    var prevSrc = aud ? (aud.currentSrc || aud.src || '') : '';
    var dlSelectors = [
        'button[aria-label=""Baixar o mais recente""]',
        'button[aria-label=""Download latest""]',
        'button[aria-label=""Baixar áudio""]',
        'button[aria-label=""Download audio""]',
        'button[aria-label*=""Baixar"" i]',
        'button[aria-label*=""Download"" i]',
        'button[title*=""Baixar"" i]',
        'button[title*=""Download"" i]'
    ];
    var dlBtn = null;
    for (var s = 0; s < dlSelectors.length; s++) {
        var found = Array.from(document.querySelectorAll(dlSelectors[s])).find(b => {
            var r = b.getBoundingClientRect();
            return r.width > 10 && r.height > 10 && !b.disabled && b.getAttribute('aria-disabled') !== 'true';
        });
        if (found) { dlBtn = found; break; }
    }

    var btns = Array.from(document.querySelectorAll('button')).filter(b => {
        var al = (b.getAttribute('aria-label') || '');
        var txt = (b.innerText || '').trim();
        var r = b.getBoundingClientRect();
        return r.width > 20 && r.height > 20 && !b.disabled &&
               (al.indexOf('Gerar fala') >= 0 || al.indexOf('Generate speech') >= 0 ||
                txt === 'Gerar fala' || txt === 'Generate speech' || txt.indexOf('Gerar fala') >= 0);
    });
    if (btns.length === 0) return null;
    var b = btns[btns.length - 1];
    var r = b.getBoundingClientRect();
    return JSON.stringify({
        x: Math.round(r.left + r.width/2),
        y: Math.round(r.top + r.height/2),
        prevSrc: prevSrc,
        prevDlEnabled: !!dlBtn
    });
})()", ct);

            if (preState == null)
                throw new InvalidOperationException("Botão 'Gerar fala' não encontrado ou desabilitado no ElevenLabs.");

            string prevAudioSrc = preState.ContainsKey("prevSrc") ? Convert.ToString(preState["prevSrc"] ?? "") : "";
            bool prevDlEnabled = preState.ContainsKey("prevDlEnabled") && Convert.ToBoolean(preState["prevDlEnabled"]);

            string stagingDir = Path.Combine(takesDir, "_eleven_dl_" + DateTime.Now.ToString("HHmmss"));
            Directory.CreateDirectory(stagingDir);
            await _cdp.SetDownloadBehaviorAsync(stagingDir, ct);

            _log("[ElevenLabs] Clicando em 'Gerar fala' e monitorando botão 'Baixar' para download imediato...");
            DateTime clickUtc = DateTime.UtcNow;
            await _cdp.ClickAtAsync(sess, Convert.ToInt32(preState["x"]), Convert.ToInt32(preState["y"]), ct);

            // 3. Assim que o botão Baixar ficar clicável (e não estiver gerando), clicar imediatamente!
            DateTime deadline = DateTime.UtcNow.AddSeconds(120);
            bool sawTransition = !prevDlEnabled;
            Dictionary<string, object> dlPt = null;
            int reloadRetries = 0;

            await Task.Delay(1200, ct);

            while (DateTime.UtcNow < deadline)
            {
                ct.ThrowIfCancellationRequested();
                bool manualReload = await _cdp.WaitOrWakeOnReloadSignalAsync(350, ct);

                if (await HasCreditOrPlanBlockAsync(sess, 0, ct))
                {
                    await _cdp.ResetDownloadBehaviorToDefaultAsync();
                    try { Directory.Delete(stagingDir, true); } catch { }
                    return true;
                }

                Dictionary<string, object> st = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var activeGenerating = Array.from(document.querySelectorAll('button')).some(b => {
        var al = (b.getAttribute('aria-label') || '').toLowerCase();
        var txt = (b.innerText || '').trim().toLowerCase();
        var r = b.getBoundingClientRect();
        if (r.width < 16 || r.height < 16) return false;
        if (b.getAttribute('aria-busy') === 'true') return true;
        if (txt.indexOf('gerando') >= 0 || txt.indexOf('generating') >= 0 ||
            al.indexOf('gerando') >= 0 || al.indexOf('generating') >= 0 ||
            al.indexOf('stop generating') >= 0 || al.indexOf('cancelar gera') >= 0) {
            return true;
        }
        if ((al.indexOf('gerar fala') >= 0 || al.indexOf('generate speech') >= 0 || txt.indexOf('gerar fala') >= 0 || txt.indexOf('generate speech') >= 0) &&
            !!b.querySelector('svg.animate-spin, [class*=""animate-spin""], [role=""progressbar""]')) {
            return true;
        }
        return false;
    });

    var dlSelectors = [
        'button[aria-label=""Baixar o mais recente""]',
        'button[aria-label=""Download latest""]',
        'button[aria-label=""Baixar áudio""]',
        'button[aria-label=""Download audio""]',
        'button[aria-label*=""Baixar"" i]',
        'button[aria-label*=""Download"" i]',
        'button[title*=""Baixar"" i]',
        'button[title*=""Download"" i]'
    ];
    var dlBtn = null;
    for (var s = 0; s < dlSelectors.length; s++) {
        var candidates = Array.from(document.querySelectorAll(dlSelectors[s])).filter(b => {
            var r = b.getBoundingClientRect();
            return r.width > 10 && r.height > 10 && !b.disabled && b.getAttribute('aria-disabled') !== 'true';
        });
        if (candidates.length > 0) {
            dlBtn = candidates[0];
            break;
        }
    }

    var aud = document.querySelector('audio');
    var audSrc = aud ? (aud.currentSrc || aud.src || '') : '';
    var dlRect = dlBtn ? dlBtn.getBoundingClientRect() : null;

    return JSON.stringify({
        generating: activeGenerating,
        hasDl: !!dlBtn,
        dlX: dlRect ? Math.round(dlRect.left + dlRect.width/2) : 0,
        dlY: dlRect ? Math.round(dlRect.top + dlRect.height/2) : 0,
        audSrc: audSrc
    });
})()", ct);

                if (st == null) continue;
                bool generating = Convert.ToBoolean(st["generating"]);
                bool hasDl = Convert.ToBoolean(st["hasDl"]);
                string audSrc = st.ContainsKey("audSrc") ? Convert.ToString(st["audSrc"] ?? "") : "";
                double elapsedSec = (DateTime.UtcNow - clickUtc).TotalSeconds;

                if (generating || !hasDl || (!string.IsNullOrEmpty(audSrc) && !string.Equals(audSrc, prevAudioSrc, StringComparison.Ordinal)))
                {
                    sawTransition = true;
                }

                if (!generating && hasDl && (sawTransition || elapsedSec >= 2.2))
                {
                    dlPt = new Dictionary<string, object>
                    {
                        { "x", Convert.ToInt32(st["dlX"]) },
                        { "y", Convert.ToInt32(st["dlY"]) }
                    };
                    break;
                }

                string manualReason;
                bool reloadRequested = manualReload || _cdp.ConsumeReloadAndResumeRequest(out manualReason);
                bool stalled = elapsedSec >= 55.0 && reloadRetries < 2;
                if (reloadRequested || stalled)
                {
                    reloadRetries++;
                    _log(string.Format("[Recuperação | Histórico] {0} no ElevenLabs -> recarregando página e retomando síntese a partir da última ação (tentativa {1}/2)...",
                        reloadRequested ? "Recarregamento manual solicitado" : "Síntese sem resposta há 55s", reloadRetries));
                    LastActionHistoryStore.UpdateStatus(ep, "RecarregandoPagina", "ElevenLabs recarregado para retomar síntese");

                    await _cdp.ReloadPageAndWaitReadyAsync(sess, 25000, ct);
                    await WaitForElevenLabsEditorReadyAsync(sess, ct);
                    await DismissPromoModalsAsync(sess, ct);
                    await _cdp.SetDownloadBehaviorAsync(stagingDir, ct);

                    string textToRestore = (LastActionHistoryStore.Current != null && !string.IsNullOrWhiteSpace(LastActionHistoryStore.Current.PromptSent))
                        ? LastActionHistoryStore.Current.PromptSent
                        : unifiedText;
                    await InjectNarratorTextAsync(sess, textToRestore, ct);
                    await Task.Delay(800, ct);

                    Dictionary<string, object> reBtn = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var btns = Array.from(document.querySelectorAll('button')).filter(b => {
        var al = (b.getAttribute('aria-label') || '');
        var txt = (b.innerText || '').trim();
        var r = b.getBoundingClientRect();
        return r.width > 20 && r.height > 20 && !b.disabled &&
               (al.indexOf('Gerar fala') >= 0 || al.indexOf('Generate speech') >= 0 ||
                txt === 'Gerar fala' || txt === 'Generate speech' || txt.indexOf('Gerar fala') >= 0);
    });
    if (btns.length === 0) return null;
    var b = btns[btns.length - 1];
    var r = b.getBoundingClientRect();
    return JSON.stringify({ x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) });
})()", ct);
                    if (reBtn != null)
                    {
                        clickUtc = DateTime.UtcNow;
                        deadline = DateTime.UtcNow.AddSeconds(90);
                        sawTransition = true;
                        await _cdp.ClickAtAsync(sess, Convert.ToInt32(reBtn["x"]), Convert.ToInt32(reBtn["y"]), ct);
                        await Task.Delay(1200, ct);
                    }
                }
            }

            // 4. Fallback caso o loop tenha encerrado sem preencher dlPt
            if (dlPt == null)
            {
                dlPt = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var priority = [
        'button[aria-label=""Baixar o mais recente""]',
        'button[aria-label=""Download latest""]',
        'button[aria-label=""Baixar áudio""]',
        'button[aria-label=""Download audio""]',
        'button[aria-label*=""Baixar"" i]',
        'button[aria-label*=""Download"" i]',
        'button[title*=""Baixar"" i]',
        'button[title*=""Download"" i]'
    ];
    for (var i = 0; i < priority.length; i++) {
        var btns = Array.from(document.querySelectorAll(priority[i])).filter(b => {
            var r = b.getBoundingClientRect();
            return r.width > 10 && r.height > 10 && !b.disabled && b.getAttribute('aria-disabled') !== 'true';
        });
        if (btns.length > 0) {
            var b = btns[0];
            var r = b.getBoundingClientRect();
            return JSON.stringify({ x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) });
        }
    }
    return null;
})()", ct);
            }

            if (dlPt == null)
            {
                await _cdp.ResetDownloadBehaviorToDefaultAsync();
                try { Directory.Delete(stagingDir, true); } catch { }
                throw new InvalidOperationException("Botão 'Baixar' (↓) não apareceu após a síntese no ElevenLabs.");
            }

            HashSet<string> beforeFiles = new HashSet<string>(Directory.GetFiles(stagingDir), StringComparer.OrdinalIgnoreCase);
            _log("[ElevenLabs] Síntese concluída! Baixando áudio (↓)...");
            await _cdp.ClickAtAsync(sess, Convert.ToInt32(dlPt["x"]), Convert.ToInt32(dlPt["y"]), ct);

            string downloadedMp3 = await _cdp.WaitForSingleDownloadAsync(stagingDir, beforeFiles, 8 * 1024, 45000, ct);
            await _cdp.ResetDownloadBehaviorToDefaultAsync();
            if (string.IsNullOrEmpty(downloadedMp3))
            {
                try { Directory.Delete(stagingDir, true); } catch { }
                throw new IOException("Timeout aguardando o download do arquivo .mp3 do ElevenLabs.");
            }

            // Pausa o preview automático do navegador para não continuar falando em segundo plano
            await _cdp.EvalStringAsync(sess, @"
(function(){
    var aud = document.querySelector('audio');
    if (aud && !aud.paused) { try { aud.pause(); } catch(e) {} }
    return 'OK';
})()", ct);

            File.Copy(downloadedMp3, destMp3Path, true);
            try { Directory.Delete(stagingDir, true); } catch { }
            return false;
        }

        private async Task DismissPromoModalsAsync(string sess, CancellationToken ct)
        {
            await _cdp.EvalStringAsync(sess, @"
(function(){
    var dialogs = Array.from(document.querySelectorAll('[role=""dialog""]'));
    dialogs.forEach(d => {
        var txt = (d.innerText || '');
        if (/Explore ElevenLabs|What's new|Novidades|Upgrade/i.test(txt) && !/cr[eé]ditos|credits/i.test(txt)) {
            var closeBtn = d.querySelector('button[aria-label*=""Close"" i], button[aria-label*=""Fechar"" i]');
            if (closeBtn) closeBtn.click();
        }
    });
    return 'OK';
})()", ct);
        }

        private async Task<bool> HasCreditOrPlanBlockAsync(string sess, int requiredChars, CancellationToken ct)
        {
            string res = await _cdp.EvalStringAsync(sess, @"
(function(){
    var t = (document.body && document.body.innerText) ? document.body.innerText : '';
    if (/ficou sem cr[eé]ditos/i.test(t) ||
        /You have run out of credits/i.test(t) ||
        /insufficient credits/i.test(t) ||
        /quota exceeded/i.test(t) ||
        /Instantly cloned voices are not available/i.test(t)) {
        return 'BLOCKED';
    }
    return 'OK';
})()", ct);
            return res == "BLOCKED";
        }

        private async Task<bool> InjectNarratorTextAsync(string sess, string text, CancellationToken ct)
        {
            string b64 = Convert.ToBase64String(Encoding.UTF8.GetBytes(text));
            string res = await _cdp.EvalStringAsync(sess, string.Format(@"
(function(){{
    var bytes = Uint8Array.from(atob('{0}'), c => c.charCodeAt(0));
    var text = new TextDecoder('utf-8').decode(bytes);

    var ta = Array.from(document.querySelectorAll('textarea')).find(el => {{
        var r = el.getBoundingClientRect();
        return r.width > 200 && r.height > 60;
    }});
    if (ta) {{
        ta.focus();
        var setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value').set;
        setter.call(ta, text);
        ta.dispatchEvent(new Event('input', {{ bubbles: true }}));
        ta.dispatchEvent(new Event('change', {{ bubbles: true }}));
        return 'TA:' + ta.value.length;
    }}

    var ce = Array.from(document.querySelectorAll('div[contenteditable=""true""], [role=""textbox""]')).find(el => {{
        var r = el.getBoundingClientRect();
        return r.width > 200 && r.height > 60;
    }});
    if (ce) {{
        ce.focus();
        document.execCommand('selectAll', false, null);
        document.execCommand('delete', false, null);
        document.execCommand('insertText', false, text);
        return 'CE:' + (ce.innerText || '').length;
    }}
    return '';
}})()", b64), ct);

            return !string.IsNullOrEmpty(res);
        }

        public void RunSilenceTruncationToWav(string inputMp3Path, string outputWavPath)
        {
            RunSilenceTruncationToWav(_config, _log, inputMp3Path, outputWavPath);
        }

        public static void RunSilenceTruncationToWav(
            PipelineConfig config,
            Action<string> log,
            string inputMp3Path,
            string outputWavPath)
        {
            string scriptPath = Path.Combine(config.SkillScriptsDir, "processar_audio_narrador.ps1");
            if (!File.Exists(scriptPath))
                throw new FileNotFoundException("Script processar_audio_narrador.ps1 não encontrado.", scriptPath);

            if (log != null)
                log("[Travar Silêncio] Executando processar_audio_narrador.ps1 (Limiar: -40 dB | Duração: 0,3s | Descartar para: 0,3s | Início/Meio/Fim)...");

            ProcessStartInfo psi = new ProcessStartInfo
            {
                FileName = "powershell.exe",
                Arguments = string.Format(
                    "-NoProfile -ExecutionPolicy Bypass -File \"{0}\" -InputAudioPath \"{1}\" -OutputAudioPath \"{2}\" -ThresholdDb -40 -MinSilenceDurationSec 0.3 -TruncateToSec 0.3",
                    scriptPath, inputMp3Path, outputWavPath),
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                CreateNoWindow = true
            };

            using (Process p = Process.Start(psi))
            {
                string stdout = p.StandardOutput.ReadToEnd();
                string stderr = p.StandardError.ReadToEnd();
                p.WaitForExit();

                if (!string.IsNullOrWhiteSpace(stdout) && log != null)
                    log("[FFmpeg] " + stdout.Trim());

                if (p.ExitCode != 0 || !File.Exists(outputWavPath))
                {
                    throw new InvalidOperationException(
                        string.Format("Falha em processar_audio_narrador.ps1 (ExitCode {0}): {1}", p.ExitCode, stderr));
                }
            }
        }
    }

    public class CapCutAutomation
    {
        private readonly PipelineConfig _config;
        private readonly Action<string> _log;

        public CapCutAutomation(PipelineConfig config, Action<string> logger)
        {
            _config = config;
            _log = logger ?? delegate { };
        }

        private void EnsureNarratorAudioInTakesDir(EpisodeWorkItem ep)
        {
            if (ep == null || !Directory.Exists(ep.TakesDir)) return;

            string[] existingAudioInTakes = Directory.GetFiles(ep.TakesDir)
                .Where(f => Regex.IsMatch(Path.GetExtension(f), @"^\.(wav|mp3|m4a)$", RegexOptions.IgnoreCase) && new FileInfo(f).Length > 1024)
                .ToArray();

            if (existingAudioInTakes.Length > 0)
            {
                return;
            }

            string targetWavInTakes = Path.Combine(ep.TakesDir, "Narrador_Take_01.wav");

            // 1. Verifica Narrador_Completo.wav (ou qualquer *narrador*.wav) na raiz do episódio (EP.X\)
            if (!string.IsNullOrEmpty(ep.EpisodePath) && Directory.Exists(ep.EpisodePath))
            {
                string rootWav = Path.Combine(ep.EpisodePath, "Narrador_Completo.wav");
                if (!File.Exists(rootWav) || new FileInfo(rootWav).Length <= 1024)
                {
                    rootWav = Directory.GetFiles(ep.EpisodePath, "*.wav", SearchOption.TopDirectoryOnly)
                        .FirstOrDefault(f => Path.GetFileName(f).IndexOf("narrador", StringComparison.OrdinalIgnoreCase) >= 0 && new FileInfo(f).Length > 1024);
                }

                if (!string.IsNullOrEmpty(rootWav) && File.Exists(rootWav))
                {
                    File.Copy(rootWav, targetWavInTakes, true);
                    _log(string.Format("[CapCut | Áudio] Restaurado '{0}' para a pasta takes\\ a partir de '{1}'!",
                        Path.GetFileName(targetWavInTakes), Path.GetFileName(rootWav)));
                    return;
                }

                // 2. Se houver apenas Narrador_Completo.mp3 na raiz do episódio, processa automaticamente o Travar Silêncio (-40dB / 0,3s) para .wav
                string rootMp3 = Path.Combine(ep.EpisodePath, "Narrador_Completo.mp3");
                if (!File.Exists(rootMp3) || new FileInfo(rootMp3).Length <= 1024)
                {
                    rootMp3 = Directory.GetFiles(ep.EpisodePath, "*.mp3", SearchOption.TopDirectoryOnly)
                        .FirstOrDefault(f => Path.GetFileName(f).IndexOf("narrador", StringComparison.OrdinalIgnoreCase) >= 0 && new FileInfo(f).Length > 1024);
                }

                if (!string.IsNullOrEmpty(rootMp3) && File.Exists(rootMp3))
                {
                    _log(string.Format("[CapCut | Áudio] Encontrado '{0}' na pasta do episódio -> gerando 'Narrador_Take_01.wav' (-40dB / 0,3s) para a Timeline...",
                        Path.GetFileName(rootMp3)));
                    ElevenLabsAutomation.RunSilenceTruncationToWav(_config, _log, rootMp3, targetWavInTakes);
                    string wavBackupRoot = Path.Combine(ep.EpisodePath, "Narrador_Completo.wav");
                    File.Copy(targetWavInTakes, wavBackupRoot, true);
                    return;
                }
            }

            // 3. Verifica subpastas _backup_* dentro de takes\ (caso um Modo Refazer anterior tenha movido o áudio)
            string[] backupDirs = Directory.GetDirectories(ep.TakesDir, "_backup_*", SearchOption.TopDirectoryOnly)
                .OrderByDescending(d => d)
                .ToArray();

            foreach (string bDir in backupDirs)
            {
                string backupAudio = Directory.GetFiles(bDir)
                    .FirstOrDefault(f => Regex.IsMatch(Path.GetExtension(f), @"^\.(wav|mp3|m4a)$", RegexOptions.IgnoreCase) && new FileInfo(f).Length > 1024);
                if (!string.IsNullOrEmpty(backupAudio))
                {
                    string destPath = Path.Combine(ep.TakesDir, Path.GetFileName(backupAudio));
                    File.Copy(backupAudio, destPath, true);
                    _log(string.Format("[CapCut | Áudio] Restaurado '{0}' de '{1}' para a Timeline!",
                        Path.GetFileName(backupAudio), Path.GetFileName(bDir)));
                    return;
                }
            }
        }

        public Task RunAsync(EpisodeWorkItem ep, string customProjectName, bool launchCapCut, CancellationToken ct)
        {
            return Task.Run(() =>
            {
                ct.ThrowIfCancellationRequested();

                if (!Directory.Exists(ep.TakesDir))
                    throw new DirectoryNotFoundException("Pasta takes não encontrada: " + ep.TakesDir);

                string[] videos = Directory.GetFiles(ep.TakesDir, "*.mp4", SearchOption.TopDirectoryOnly);
                if (videos.Length == 0)
                    throw new InvalidOperationException("Nenhum vídeo .mp4 encontrado em: " + ep.TakesDir);

                // Garante que o áudio do Narrador esteja presente em ep.TakesDir antes de montar o projeto CapCut
                EnsureNarratorAudioInTakesDir(ep);
                EpisodeParser.RefreshDiskCounters(ep);

                string[] audiosInTakes = Directory.GetFiles(ep.TakesDir)
                    .Where(f => Regex.IsMatch(Path.GetExtension(f), @"^\.(wav|mp3|m4a)$", RegexOptions.IgnoreCase) && new FileInfo(f).Length > 1024)
                    .OrderBy(f => Path.GetFileName(f))
                    .ToArray();

                if (!string.IsNullOrWhiteSpace(ep.UnifiedNarratorText) && audiosInTakes.Length == 0)
                {
                    _log("[CapCut | Aviso] Este episódio possui falas de Narrador no roteiro, mas o áudio ainda não foi gerado no ElevenLabs (Etapa 3).");
                }
                else if (audiosInTakes.Length > 0)
                {
                    _log(string.Format("[CapCut Desktop] Áudio(s) do Narrador confirmado(s) para a Faixa 2: {0}",
                        string.Join(", ", audiosInTakes.Select(Path.GetFileName))));
                }

                string scriptPath = Path.Combine(_config.SkillScriptsDir, "importar_para_capcut.ps1");
                if (!File.Exists(scriptPath))
                    throw new FileNotFoundException("Script importar_para_capcut.ps1 não encontrado.", scriptPath);

                string projName = string.IsNullOrWhiteSpace(customProjectName) ? ep.CapCutProjectName : customProjectName.Trim();
                string noLaunchSwitch = launchCapCut ? "" : " -NoLaunchCapCut";

                _log(string.Format("[CapCut Desktop] Montando projeto '{0}' com {1} takes de vídeo e {2} áudio(s) na Timeline (9:16)...",
                    projName, videos.Length, audiosInTakes.Length));

                ProcessStartInfo psi = new ProcessStartInfo
                {
                    FileName = "powershell.exe",
                    Arguments = string.Format(
                        "-NoProfile -ExecutionPolicy Bypass -File \"{0}\" -TakesFolder \"{1}\" -ProjectName \"{2}\"{3}",
                        scriptPath, ep.TakesDir, projName, noLaunchSwitch),
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    CreateNoWindow = true
                };

                using (Process p = Process.Start(psi))
                {
                    string stdout = p.StandardOutput.ReadToEnd();
                    string stderr = p.StandardError.ReadToEnd();
                    p.WaitForExit();

                    if (!string.IsNullOrWhiteSpace(stdout))
                        _log("[CapCut] " + stdout.Trim());

                    if (p.ExitCode != 0)
                    {
                        throw new InvalidOperationException(
                            string.Format("Erro ao montar projeto no CapCut Desktop (ExitCode {0}): {1}", p.ExitCode, stderr));
                    }
                }

                if (audiosInTakes.Length > 0)
                {
                    _log(string.Format("[CapCut Desktop] Projeto '{0}' montado com sucesso na Timeline (Faixa 1: {1} Vídeos | Faixa 2: {2} Áudio(s) do Narrador)!",
                        projName, videos.Length, audiosInTakes.Length));
                }
                else
                {
                    _log(string.Format("[CapCut Desktop] Projeto '{0}' montado com sucesso na Timeline (Faixa 1: {1} Vídeos | Sem Narrador)!",
                        projName, videos.Length));
                }
            }, ct);
        }
    }
}
