param(
    [int]$DurationSeconds = 20
)
Add-Type -AssemblyName UIAutomationClient
Add-Type -AssemblyName UIAutomationTypes

$root = [System.Windows.Automation.AutomationElement]::RootElement
$walker = [System.Windows.Automation.TreeWalker]::ControlViewWalker
$script:foundThisPass = $false
$script:clickedAny = $false

function Search-NonWeb($el, [int]$depth) {
    if ($depth -gt 12 -or $null -eq $el) { return }
    try {
        $ct = $el.Current.ControlType
        if ($ct -eq [System.Windows.Automation.ControlType]::Document) { return }
        if ($ct -eq [System.Windows.Automation.ControlType]::Button) {
            $n = $el.Current.Name
            if ($n -eq "Permitir" -or $n -eq "Allow") {
                $script:foundThisPass = $true
                try {
                    $inv = $el.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern)
                    if ($null -ne $inv) {
                        $inv.Invoke()
                        $script:clickedAny = $true
                        return
                    }
                } catch {}
            }
        }
        $child = $walker.GetFirstChild($el)
        while ($null -ne $child) {
            Search-NonWeb $child ($depth + 1)
            $child = $walker.GetNextSibling($child)
        }
    } catch {}
}

$endTime = (Get-Date).AddSeconds($DurationSeconds)
while ((Get-Date) -lt $endTime) {
    $script:foundThisPass = $false
    try {
        $w = $walker.GetFirstChild($root)
        while ($null -ne $w) {
            try {
                if ($w.Current.ClassName -eq "Chrome_WidgetWin_1") {
                    Search-NonWeb $w 0
                }
            } catch {}
            $w = $walker.GetNextSibling($w)
        }
    } catch {}

    if ($script:clickedAny -and (-not $script:foundThisPass)) {
        exit 0
    }
    Start-Sleep -Milliseconds 250
}
