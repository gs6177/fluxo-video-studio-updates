# Regras Obrigatórias do Projeto — Fluxo Vídeo IA Studio

## Backup Obrigatório Antes de Qualquer Alteração
- **SEMPRE antes de realizar qualquer alteração** em arquivos de código-fonte (`src\*.cs`), scripts (`*.ps1`) ou executáveis do projeto, crie obrigatoriamente um backup completo com data e hora em `backups\backup_<yyyyMMdd_HHmmss>\` (executando `.\backup.ps1` ou copiando previamente todos os arquivos que serão modificados) para evitar qualquer perda ou regressão.
- Nunca sobrescreva ou apague backups anteriores sem solicitação explícita do usuário.

## Fluxo de Alterações e Publicação Remota (Sempre Testar Localmente Primeiro)
- **Todas as alterações devem ser feitas e compiladas primeiro exclusivamente neste PC principal (`C:\Users\Best Option Notebook\.gemini\antigravity\scratch\fluxo-video-studio`)**.
- **NUNCA publique atualizações remotas automaticamente**: após compilar localmente, aguarde o usuário testar no PC principal. Quando o usuário aprovar, ele próprio clicará manualmente no botão **`☁️ Publicar Atualização no GitHub (PC Principal)`** dentro do programa (ou solicitará explicitamente a publicação).
