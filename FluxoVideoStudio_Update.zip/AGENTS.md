# Regras Obrigatórias do Projeto — Fluxo Vídeo IA Studio

## Backup Obrigatório Antes de Qualquer Alteração
- **SEMPRE antes de realizar qualquer alteração** em arquivos de código-fonte (`src\*.cs`), scripts (`*.ps1`) ou executáveis do projeto, crie obrigatoriamente um backup completo com data e hora em `backups\backup_<yyyyMMdd_HHmmss>\` (executando `.\backup.ps1` ou copiando previamente todos os arquivos que serão modificados) para evitar qualquer perda ou regressão.
- Nunca sobrescreva ou apague backups anteriores sem solicitação explícita do usuário.
