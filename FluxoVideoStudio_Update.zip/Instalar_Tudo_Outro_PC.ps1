$ErrorActionPreference = "Continue"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

Write-Host "==================================================================" -ForegroundColor Cyan
Write-Host "   INSTALADOR E CONFIGURADOR 1-CLIQUE - FLUXO VIDEO IA STUDIO     " -ForegroundColor Cyan
Write-Host "==================================================================" -ForegroundColor Cyan
Write-Host ""

$installerRoot = Split-Path -Parent $MyInvocation.MyCommand.Path

# 1. Desbloquear todos os arquivos extraídos (evita bloqueio do Controle Inteligente de Aplicativos do Windows 11)
Write-Host "[1/6] Removendo bloqueio de segurança do Windows (Unblock-File)..." -ForegroundColor Yellow
try {
    Get-ChildItem -Path $installerRoot -Recurse -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue
} catch {}

# 2. Detectar Área de Trabalho real deste PC (suporta Desktop padrão e OneDrive\Desktop)
$realDesktop = [Environment]::GetFolderPath("DesktopDirectory")
if ([string]::IsNullOrWhiteSpace($realDesktop) -or -not (Test-Path $realDesktop)) {
    $oneDriveDesktop = Join-Path $env:USERPROFILE "OneDrive\Desktop"
    if (Test-Path $oneDriveDesktop) {
        $realDesktop = $oneDriveDesktop
    } else {
        $realDesktop = Join-Path $env:USERPROFILE "Desktop"
    }
}

$meuTrabalhoDir = Join-Path $realDesktop "MEU TRABALHO"
$novelaDir      = Join-Path $meuTrabalhoDir "_videos de reflexão"
$terrorDir      = Join-Path $meuTrabalhoDir "_Videos terror"
$refVideosDir   = Join-Path $meuTrabalhoDir "Videos_Referencia"
$targetStudio   = Join-Path $meuTrabalhoDir "FluxoVideoStudio"

Write-Host "[2/6] Criando estrutura de pastas na Área de Trabalho ($meuTrabalhoDir)..." -ForegroundColor Yellow
New-Item -ItemType Directory -Path $meuTrabalhoDir -Force | Out-Null
New-Item -ItemType Directory -Path $novelaDir -Force | Out-Null
New-Item -ItemType Directory -Path $terrorDir -Force | Out-Null
New-Item -ItemType Directory -Path $refVideosDir -Force | Out-Null
New-Item -ItemType Directory -Path $targetStudio -Force | Out-Null
Write-Host "      -> Pasta Novela/Reflexão: $novelaDir" -ForegroundColor Green
Write-Host "      -> Pasta Terror:          $terrorDir" -ForegroundColor Green
Write-Host "      -> Pasta Referências:     $refVideosDir" -ForegroundColor Green

# 3. Instalar/Atualizar as 4 Skills em ~/.gemini/config/skills adaptando o caminho deste PC
$skillsSourceDir = Join-Path $installerRoot "Skills"
if (-not (Test-Path $skillsSourceDir)) {
    $altSkills = Join-Path (Split-Path -Parent $installerRoot) "Skills"
    if (Test-Path $altSkills) { $skillsSourceDir = $altSkills }
}

$skillsTargetRoot = Join-Path $env:USERPROFILE ".gemini\config\skills"
New-Item -ItemType Directory -Path $skillsTargetRoot -Force | Out-Null

if (Test-Path $skillsSourceDir) {
    Write-Host "[3/6] Instalando e atualizando as 6 Skills (fluxo-video-studio, fluxo-video-ia, gem-novela, gem-terror, gem 3D Pixar/Disney, Camaleão)..." -ForegroundColor Yellow
    Copy-Item -Path (Join-Path $skillsSourceDir "*") -Destination $skillsTargetRoot -Recurse -Force

    # Adaptar automaticamente caminhos de 'C:\Users\Best Option Notebook\Desktop' e 'C:\Users\Best Option Notebook' para este PC
    $skillFiles = Get-ChildItem -Path $skillsTargetRoot -Recurse -Include "*.md", "*.ps1" -ErrorAction SilentlyContinue
    foreach ($sf in $skillFiles) {
        try {
            $raw = [System.IO.File]::ReadAllText($sf.FullName, [System.Text.Encoding]::UTF8)
            $updated = $raw.Replace("C:\Users\Best Option Notebook\Desktop", $realDesktop)
            $updated = $updated.Replace("C:\Users\Best Option Notebook", $env:USERPROFILE)
            if ($updated -ne $raw) {
                $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
                [System.IO.File]::WriteAllText($sf.FullName, $updated, $utf8NoBom)
            }
        } catch {}
    }
    Get-ChildItem -Path $skillsTargetRoot -Recurse -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue
    Write-Host "      -> 6 Skills instaladas e configuradas em: $skillsTargetRoot" -ForegroundColor Green
} else {
    Write-Host "[3/6] Pasta 'Skills' já integrada ou mantida em: $skillsTargetRoot" -ForegroundColor DarkGray
}

# 4. Instalar FluxoVideoStudio em MEU TRABALHO\FluxoVideoStudio e compilar localmente neste PC
$studioSourceDir = $installerRoot
if (Test-Path (Join-Path $installerRoot "FluxoVideoStudio\src")) {
    $studioSourceDir = Join-Path $installerRoot "FluxoVideoStudio"
}

Write-Host "[4/6] Instalando FluxoVideoStudio em $targetStudio ..." -ForegroundColor Yellow
if ($studioSourceDir.TrimEnd('\') -ne $targetStudio.TrimEnd('\')) {
    Copy-Item -Path (Join-Path $studioSourceDir "*") -Destination $targetStudio -Recurse -Force
}
Get-ChildItem -Path $targetStudio -Recurse -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue

$buildScript = Join-Path $targetStudio "build.ps1"
if (Test-Path $buildScript) {
    try {
        & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $buildScript | Out-Null
        Write-Host "      -> Executável compilado localmente para este PC com sucesso!" -ForegroundColor Green
    } catch {
        Write-Host "      -> Aviso: O modo de execução em memória (Iniciar_Sem_Bloqueio.ps1) será utilizado." -ForegroundColor Yellow
    }
}

# 5. Detectar automaticamente perfis do Chrome deste PC (Grok, Flow, ElevenLabs) e salvar studio_user_settings.json
Write-Host "[5/6] Detectando perfis do Google Chrome neste PC e configurando contas..." -ForegroundColor Yellow
$grokProfs   = New-Object System.Collections.Generic.List[string]
$flowProf    = ""
$elevenProfs = New-Object System.Collections.Generic.List[string]

$localStatePath = Join-Path $env:LOCALAPPDATA "Google\Chrome\User Data\Local State"
if (Test-Path $localStatePath) {
    try {
        Add-Type -AssemblyName System.Web.Extensions
        $ser = New-Object System.Web.Script.Serialization.JavaScriptSerializer
        $ser.MaxJsonLength = [int]::MaxValue
        $lsJson = [System.IO.File]::ReadAllText($localStatePath, [System.Text.Encoding]::UTF8)
        $lsObj = $ser.DeserializeObject($lsJson)
        $cache = $lsObj["profile"]["info_cache"]
        if ($cache -ne $null) {
            foreach ($dirKey in $cache.Keys) {
                $info = $cache[$dirKey]
                $pName  = ("" + $info["name"]).ToLowerInvariant()
                $pEmail = ("" + $info["user_name"]).ToLowerInvariant()
                Write-Host "      Perfil encontrado: [$dirKey] Nome='$($info["name"])' Email='$($info["user_name"])'" -ForegroundColor Gray

                if ($pEmail -match "isabellamuniz|macabrasbr|facecast" -or $pName -match "grok") {
                    if (-not $grokProfs.Contains($dirKey)) { $grokProfs.Add($dirKey) }
                }
                if ($pEmail -match "midjorneyguie" -or $pName -match "guilherme|flow") {
                    if ([string]::IsNullOrEmpty($flowProf)) { $flowProf = $dirKey }
                }
                if ($pEmail -match "contadordehistorias|contosemocionantes" -or $pName -match "contador|eleven") {
                    if (-not $elevenProfs.Contains($dirKey)) { $elevenProfs.Add($dirKey) }
                }
            }
        }
    } catch {}
}

if ($grokProfs.Count -eq 0)   { $grokProfs.AddRange([string[]]@("Default", "Profile 1", "Profile 2")) }
if ([string]::IsNullOrEmpty($flowProf)) { $flowProf = "Default" }
if ($elevenProfs.Count -eq 0) { $elevenProfs.Add("Default") }

$settingsPath = Join-Path $targetStudio "studio_user_settings.json"
if (-not (Test-Path $settingsPath)) {
    $settingsObj = @{
        GrokProfiles     = $grokProfs.ToArray()
        FlowProfile      = $flowProf
        FlowProjectUrl   = "https://flow.google.com/project/9b576f1d-9b0f-4103-ac8e-123edb00a1f0"
        ElevenLabsProfiles = $elevenProfs.ToArray()
        ElevenLabsUrl    = "https://elevenlabs.io/app/speech-synthesis/text-to-speech?voiceId=ppLqTilh7rH7fbUVlXsf"
        NovelaRootDir    = $novelaDir
        TerrorRootDir    = $terrorDir
    }
    Add-Type -AssemblyName System.Web.Extensions
    $ser2 = New-Object System.Web.Script.Serialization.JavaScriptSerializer
    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText($settingsPath, $ser2.Serialize($settingsObj), $utf8NoBom)
} else {
    try {
        Add-Type -AssemblyName System.Web.Extensions
        $ser2 = New-Object System.Web.Script.Serialization.JavaScriptSerializer
        $existing = $ser2.DeserializeObject([System.IO.File]::ReadAllText($settingsPath, [System.Text.Encoding]::UTF8))
        $existing["NovelaRootDir"] = $novelaDir
        $existing["TerrorRootDir"] = $terrorDir
        $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
        [System.IO.File]::WriteAllText($settingsPath, $ser2.Serialize($existing), $utf8NoBom)
    } catch {}
}

# 6. Criar Atalho na Área de Trabalho (usando o lançador sem bloqueio do Windows 11)
Write-Host "[6/6] Criando atalho 'Fluxo Video Studio' na Área de Trabalho..." -ForegroundColor Yellow
try {
    $wsh = New-Object -ComObject WScript.Shell
    $shortcutPath = Join-Path $realDesktop "Fluxo Video Studio.lnk"
    $sc = $wsh.CreateShortcut($shortcutPath)
    $sc.TargetPath = "powershell.exe"
    $launcherPs1 = Join-Path $targetStudio "Iniciar_Sem_Bloqueio.ps1"
    $sc.Arguments = "-NoProfile -STA -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$launcherPs1`""
    $sc.WorkingDirectory = $targetStudio
    $sc.Description = "Iniciar Fluxo Video IA Studio (Sem Bloqueio)"
    $sc.Save()
    Write-Host "      -> Atalho criado em: $shortcutPath" -ForegroundColor Green
} catch {}

Write-Host ""
Write-Host "==================================================================" -ForegroundColor Green
Write-Host "   INSTALAÇÃO CONCLUÍDA COM SUCESSO! ABRINDO FLUXO VIDEO STUDIO   " -ForegroundColor Green
Write-Host "==================================================================" -ForegroundColor Green
Write-Host "DICA: Na aba 'Contas, Vozes & Pastas' do programa, clique no botão roxo:" -ForegroundColor Cyan
Write-Host "      'Detectar e Selecionar Perfis do Chrome deste PC'" -ForegroundColor Cyan
Write-Host "      para marcar suas contas do Grok, Google Flow e ElevenLabs!" -ForegroundColor Cyan
Write-Host ""

$launcherBat = Join-Path $targetStudio "Iniciar_FluxoVideoStudio.bat"
if (Test-Path $launcherBat) {
    Start-Process -FilePath $launcherBat -WorkingDirectory $targetStudio
}
