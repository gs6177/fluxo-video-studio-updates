using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace FluxoVideoStudio
{
    public partial class GrokAutomation
    {
        private async Task EnhanceGrokVideoPromptAsync(string sess, int takeNumber, string originalPrompt, CancellationToken ct)
        {
            string initialNorm = (originalPrompt ?? "").Trim();
            int initialLen = initialNorm.Length;

            Dictionary<string, object> wandBtn = null;
            for (int attempt = 0; attempt < 5; attempt++)
            {
                wandBtn = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var ce = Array.from(document.querySelectorAll('div[contenteditable=""true""], [role=""textbox""], textarea')).find(el => {
        var r = el.getBoundingClientRect();
        return r.width > 100 && r.height > 20 && r.left > 245;
    });
    var currentTxt = ce ? (ce.value !== undefined ? ce.value : (ce.innerText || '')).trim() : '';

    var b = Array.from(document.querySelectorAll('button, [role=""button""]')).find(el => {
        var r = el.getBoundingClientRect();
        if (r.left <= 245 || r.width <= 10 || r.height <= 10 || el.disabled) return false;
        if (el.closest('[data-sidebar], nav, aside')) return false;
        var al = (el.getAttribute('aria-label') || '').toLowerCase();
        var title = (el.getAttribute('title') || '').toLowerCase();
        var hasEnhanceIcon = !!el.querySelector('g[id=""name=enhance""], svg[id*=""enhance""], g[id*=""magic""], g[id*=""wand""]');
        return al.indexOf('aprimorar o prompt') >= 0 ||
               al.indexOf('enhance prompt') >= 0 ||
               al === 'aprimorar' ||
               al === 'enhance' ||
               title.indexOf('aprimorar') >= 0 ||
               title.indexOf('enhance') >= 0 ||
               hasEnhanceIcon;
    });
    if (!b) return JSON.stringify({ found: false, currentTxt: currentTxt });
    var br = b.getBoundingClientRect();
    b.click();
    return JSON.stringify({
        found: true,
        x: Math.round(br.left + br.width / 2),
        y: Math.round(br.top + br.height / 2),
        currentTxt: currentTxt
    });
})()", ct);

                if (wandBtn != null && wandBtn.ContainsKey("found") && Convert.ToBoolean(wandBtn["found"]))
                {
                    if (wandBtn.ContainsKey("currentTxt"))
                    {
                        string domTxt = Convert.ToString(wandBtn["currentTxt"] ?? "").Trim();
                        if (!string.IsNullOrEmpty(domTxt))
                        {
                            initialNorm = domTxt;
                            initialLen = domTxt.Length;
                        }
                    }
                    break;
                }

                await Task.Delay(400, ct);
            }

            if (wandBtn == null || !wandBtn.ContainsKey("found") || !Convert.ToBoolean(wandBtn["found"]))
            {
                _log(string.Format("[Grok Vídeo] Botão 'Aprimorar o prompt' não localizado para o Take_{0:00}; enviando prompt original.", takeNumber));
                return;
            }

            _log(string.Format("[Grok Vídeo] Acionando 'Aprimorar o prompt' (varinha mágica) para deixar o Take_{0:00} no padrão Grok...", takeNumber));

            DateTime enhanceDeadline = DateTime.UtcNow.AddSeconds(25);
            string lastTxt = initialNorm;
            int stableChangedPolls = 0;
            bool fallbackClickedCoords = false;
            DateTime startWait = DateTime.UtcNow;

            while (DateTime.UtcNow < enhanceDeadline)
            {
                ct.ThrowIfCancellationRequested();
                await Task.Delay(600, ct);

                Dictionary<string, object> poll = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var ce = Array.from(document.querySelectorAll('div[contenteditable=""true""], [role=""textbox""], textarea')).find(el => {
        var r = el.getBoundingClientRect();
        return r.width > 100 && r.height > 20;
    });
    var txt = ce ? (ce.value !== undefined ? ce.value : (ce.innerText || '')).trim() : '';
    var wandStillThere = !!Array.from(document.querySelectorAll('button, [role=""button""]')).find(el => {
        var r = el.getBoundingClientRect();
        if (r.width <= 10 || r.height <= 10) return false;
        var al = (el.getAttribute('aria-label') || '').toLowerCase();
        var hasEnhanceIcon = !!el.querySelector('g[id=""name=enhance""], svg[id*=""enhance""]');
        return al.indexOf('aprimorar') >= 0 || al.indexOf('enhance') >= 0 || hasEnhanceIcon;
    });
    return JSON.stringify({ txt: txt, wandStillThere: wandStillThere });
})()", ct);

                if (poll == null)
                    continue;

                string curTxt = poll.ContainsKey("txt") ? Convert.ToString(poll["txt"] ?? "").Trim() : "";
                bool wandStillThere = poll.ContainsKey("wandStillThere") && Convert.ToBoolean(poll["wandStillThere"]);

                if (!fallbackClickedCoords && wandStillThere && string.Equals(curTxt, initialNorm, StringComparison.Ordinal) &&
                    (DateTime.UtcNow - startWait).TotalMilliseconds >= 1600)
                {
                    fallbackClickedCoords = true;
                    await _cdp.ClickAtAsync(sess, Convert.ToInt32(wandBtn["x"]), Convert.ToInt32(wandBtn["y"]), ct);
                    continue;
                }

                if (!string.IsNullOrEmpty(curTxt) && !string.Equals(curTxt, initialNorm, StringComparison.Ordinal) && curTxt.Length >= 25)
                {
                    if (string.Equals(curTxt, lastTxt, StringComparison.Ordinal))
                    {
                        stableChangedPolls++;
                        if (stableChangedPolls >= 3)
                        {
                            _log(string.Format("[Grok Vídeo] Prompt do Take_{0:00} aprimorado com sucesso para o padrão Grok ({1} -> {2} caracteres).",
                                takeNumber, initialLen, curTxt.Length));
                            return;
                        }
                    }
                    else
                    {
                        stableChangedPolls = 0;
                    }
                }

                lastTxt = curTxt;
            }

            _log(string.Format("[Grok Vídeo] Tempo limite aguardando aprimoramento do prompt do Take_{0:00}; prosseguindo com o texto atual da caixa.", takeNumber));
        }


        public async Task GenerateVideoTakesAsync(
            EpisodeWorkItem ep,
            List<FlowTakeSpec> takesToGenerate,
            Dictionary<string, string> ingredientToResolvedName,
            CancellationToken ct)
        {
            if (takesToGenerate == null || takesToGenerate.Count == 0)
                return;

            if (!Directory.Exists(ep.TakesDir))
                Directory.CreateDirectory(ep.TakesDir);

            List<FlowTakeSpec> orderedTakes = takesToGenerate
                .OrderBy(t => t.TakeNumber)
                .ToList();

            _log(string.Format("[Grok Vídeo] Iniciando geração em vídeo (9:16 | 10s | 720p | com áudio) de {0} take(s) no Grok Imagine...",
                orderedTakes.Count));

            List<string> activeProfiles = _config.GetAvailableGrokProfiles(_log);
            int currentProfileIdx = 0;

            for (int tIdx = 0; tIdx < orderedTakes.Count; tIdx++)
            {
                ct.ThrowIfCancellationRequested();
                FlowTakeSpec take = orderedTakes[tIdx];
                string finalTakePath = Path.Combine(ep.TakesDir, string.Format("Take_{0:00}.mp4", take.TakeNumber));
                List<string> ingredientFiles = ResolveIngredientFilePathsForTake(ep, take, ingredientToResolvedName);

                bool takeDone = false;
                Exception lastErr = null;

                while (currentProfileIdx < activeProfiles.Count)
                {
                    ct.ThrowIfCancellationRequested();
                    string profile = activeProfiles[currentProfileIdx];
                    try
                    {
                        _log(string.Format("[Grok Vídeo] Gerando Take_{0:00}.mp4 ({1}/{2}) no perfil '{3}' com {4} imagem(ns) de referência...",
                            take.TakeNumber, tIdx + 1, orderedTakes.Count, profile, ingredientFiles.Count));

                        bool quotaExhausted = await TryGenerateSingleVideoTakeWithProfileAsync(
                            profile,
                            ep,
                            take,
                            ingredientFiles,
                            finalTakePath,
                            ct);

                        if (quotaExhausted)
                        {
                            _config.SetProfileStatus(profile, "LIMITE ATINGIDO");
                            _log(string.Format("[Grok Vídeo] Limite atingido no perfil '{0}'. Alternando para o próximo perfil autorizado...", profile));
                            currentProfileIdx++;
                            continue;
                        }

                        _config.SetProfileStatus(profile, "DISPONÍVEL");
                        takeDone = true;
                        break;
                    }
                    catch (OperationCanceledException)
                    {
                        throw;
                    }
                    catch (Exception ex)
                    {
                        lastErr = ex;
                        _log(string.Format("[Grok Vídeo] Aviso ao gerar Take_{0:00} no perfil '{1}': {2}. Tentando próximo perfil...",
                            take.TakeNumber, profile, ex.Message));
                        currentProfileIdx++;
                    }
                }

                if (!takeDone)
                {
                    if (_config.AreAllGrokProfilesMarkedExhausted())
                    {
                        _log(string.Format("[Grok Vídeo -> Google Flow | Sem Créditos] Todas as contas do Grok estão sem créditos! Cena Take_{0:00} e restantes serão tratadas no Google Flow (1ª tentativa -> 2ª suavizada -> pular se não gerar).",
                            take.TakeNumber));
                        return;
                    }

                    throw new InvalidOperationException(
                        string.Format("Não foi possível concluir a geração do vídeo Take_{0:00}.mp4 no Grok Imagine em nenhum dos perfis autorizados.", take.TakeNumber) +
                        (lastErr != null ? " Último erro: " + lastErr.Message : ""));
                }
            }
        }

        private List<string> ResolveIngredientFilePathsForTake(
            EpisodeWorkItem ep,
            FlowTakeSpec take,
            Dictionary<string, string> ingredientToResolvedName)
        {
            List<string> resolvedPaths = new List<string>();
            HashSet<string> seenNames = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            List<string> diskAssets = new List<string>();
            if (Directory.Exists(ep.AssetsDir))
            {
                diskAssets = Directory.GetFiles(ep.AssetsDir)
                    .Where(f => Regex.IsMatch(Path.GetExtension(f), @"^\.(jpg|jpeg|png)$", RegexOptions.IgnoreCase) && new FileInfo(f).Length > 1024)
                    .ToList();
            }

            foreach (string rawIng in take.Ingredients)
            {
                string targetName = rawIng;
                if (ingredientToResolvedName != null)
                {
                    string mapped;
                    if (ingredientToResolvedName.TryGetValue(rawIng, out mapped) && !string.IsNullOrEmpty(mapped))
                        targetName = mapped;
                }

                string candidateTemp = Path.Combine(_config.TempFlowAssetsDir, targetName);
                string candidateRawTemp = Path.Combine(_config.TempFlowAssetsDir, rawIng);
                string candidateAssets = Path.Combine(ep.AssetsDir, targetName);

                string chosen = "";
                if (File.Exists(candidateTemp) && new FileInfo(candidateTemp).Length > 1024)
                    chosen = candidateTemp;
                else if (File.Exists(candidateRawTemp) && new FileInfo(candidateRawTemp).Length > 1024)
                    chosen = candidateRawTemp;
                else if (File.Exists(candidateAssets) && new FileInfo(candidateAssets).Length > 1024)
                    chosen = candidateAssets;
                else
                    chosen = EpisodeParser.FindMatchingDiskAssetFile(rawIng, diskAssets);

                if (!string.IsNullOrEmpty(chosen) && File.Exists(chosen) && seenNames.Add(Path.GetFileName(chosen)))
                {
                    resolvedPaths.Add(chosen);
                }
            }

            return resolvedPaths;
        }

        private static string CleanTakePromptForGrokVideo(FlowTakeSpec take)
        {
            string body = (take.RawPromptBody ?? "").Trim();
            body = Regex.Replace(body, @"^Prompt\s+de\s+V[ií]deo\s*:\s*", "", RegexOptions.IgnoreCase).Trim();
            body = Regex.Replace(body, @"(\r?\n)*---\s*$", "").Trim();
            return body;
        }

        private async Task<bool> TryGenerateSingleVideoTakeWithProfileAsync(
            string profile,
            EpisodeWorkItem ep,
            FlowTakeSpec take,
            List<string> ingredientFiles,
            string finalTakePath,
            CancellationToken ct)
        {
            string savedBaseUrl = "https://grok.com/imagine/saved";
            string sess = await _cdp.OpenOrAttachProfileTabAsync(profile, savedBaseUrl, "grok.com", false, ct);
            await WaitForGrokInteractiveReadyAsync(sess, ct);

            // Se a aba já estiver na tela de 'Limite de uso atingido' / 'Adicione créditos', alterna de conta imediatamente
            if (await HasQuotaExhaustedBannerAsync(sess, ct))
                return true;

            string navUrl = savedBaseUrl;
            await _cdp.SendCommandAsync("Page.navigate", new Dictionary<string, object> { { "url", navUrl } }, sess, 20000, ct);
            await _cdp.WaitForDocumentReadyAsync(sess, 30000, ct);
            await WaitForGrokInteractiveReadyAsync(sess, ct);

            if (await HasQuotaExhaustedBannerAsync(sess, ct))
                return true;

            // 1. Configurar modo Vídeo + Áudio ligado + 720p + 10s + 9:16
            await EnsureGrokVideoModeAndOptionsAsync(sess, take.DurationText, ct);

            // 2. Limpar eventuais miniaturas anexadas anteriormente e anexar os personagens + cenário deste take
            await _cdp.EvalStringAsync(sess, @"
(function(){
    Array.from(document.querySelectorAll('button[aria-label*=""Remover imagem""], button[aria-label*=""Remove image""]')).forEach(b => b.click());
    return 'OK';
})()", ct);
            await Task.Delay(350, ct);

            if (ingredientFiles != null && ingredientFiles.Count > 0)
            {
                bool attached = await _cdp.SetFileInputFilesByObjectIdAsync(
                    sess,
                    "document.querySelector('input[type=\"file\"][multiple]') || document.querySelector('input[type=\"file\"]')",
                    ingredientFiles,
                    ct);

                if (!attached)
                {
                    // Fallback via interceptação de FileChooser clicando em 'Transferir'
                    await _cdp.UploadFilesViaFileChooserAsync(
                        sess,
                        async () =>
                        {
                            Dictionary<string, object> trPt = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var b = Array.from(document.querySelectorAll('button')).find(el => {
        var r = el.getBoundingClientRect();
        if (r.left <= 245 || r.width <= 10 || el.closest('[data-sidebar], nav, aside')) return false;
        var al = (el.getAttribute('aria-label') || '');
        return (al.indexOf('Transferir') >= 0 || al.indexOf('Upload') >= 0 || al.indexOf('Anexar') >= 0 || al.indexOf('Attach') >= 0);
    });
    if (!b) return null;
    var r = b.getBoundingClientRect();
    return JSON.stringify({ x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) });
})()", ct);
                            if (trPt != null)
                                await _cdp.ClickAtAsync(sess, Convert.ToInt32(trPt["x"]), Convert.ToInt32(trPt["y"]), ct);
                        },
                        ingredientFiles,
                        ct);
                }

                await Task.Delay(1800, ct);

                // Ao anexar múltiplas imagens de referência no modo Vídeo, o Grok reseta o Aspecto de proporção para 1:1 -> reafirmar 9:16 + 720p + 10s!
                await EnsureGrokVideoModeAndOptionsAsync(sess, take.DurationText, ct);
            }

            // 3. Capturar vídeos preexistentes na tela do /imagine/saved para ignorá-los
            HashSet<string> preExistingVideoUrls = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            Dictionary<string, object> preVidsObj = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var urls = Array.from(document.querySelectorAll('video')).map(v => {
        var s = v.currentSrc || v.src || '';
        if (!s) {
            var srcEl = v.querySelector('source');
            if (srcEl) s = srcEl.src || '';
        }
        return s;
    }).filter(s => s.length > 0);
    return JSON.stringify({ urls: urls });
})()", ct);

            if (preVidsObj != null && preVidsObj.ContainsKey("urls"))
            {
                IEnumerable uList = preVidsObj["urls"] as IEnumerable;
                if (uList != null)
                {
                    foreach (object u in uList)
                    {
                        string us = Convert.ToString(u ?? "").Trim();
                        if (!string.IsNullOrEmpty(us))
                        {
                            preExistingVideoUrls.Add(us);
                            preExistingVideoUrls.Add(us.Split('?')[0]);
                        }
                    }
                }
            }

            // 4. Inserir prompt completo do take, aprimorar para o padrão Grok (varinha mágica) e enviar geração
            string takePrompt = CleanTakePromptForGrokVideo(take);
            bool inserted = await InjectPromptIntoGrokBoxAsync(sess, takePrompt, ct);
            if (!inserted)
                throw new InvalidOperationException("Campo de texto do Grok Imagine não encontrado no modo Vídeo.");

            await Task.Delay(750, ct);
            await EnhanceGrokVideoPromptAsync(sess, take.TakeNumber, takePrompt, ct);
            await Task.Delay(350, ct);

            // Lê o prompt já aprimorado pela varinha mágica para salvar no histórico da última ação
            string enhancedPromptInBox = await ReadGrokBoxTextAsync(sess, ct);
            string savedPromptForHistory = (!string.IsNullOrWhiteSpace(enhancedPromptInBox) && enhancedPromptInBox.Length >= takePrompt.Length / 2)
                ? enhancedPromptInBox
                : takePrompt;

            // Garantia final obrigatória de que a proporção continua em 9:16 imediatamente antes de enviar
            await EnsureGrokDropdownOptionAsync(sess, "Aspecto de proporção", "Aspect ratio", "9:16", ct);
            await Task.Delay(300, ct);

            string preSubmitUrl = await _cdp.EvalStringAsync(sess, "location.href || ''", ct);
            LastActionHistoryStore.RecordAction(
                ep,
                "Grok Vídeo",
                string.Format("Gerando vídeo Take_{0:00}.mp4 em 9:16 (10s | 720p)", take.TakeNumber),
                profile,
                sess,
                preSubmitUrl,
                string.Format("Take_{0:00}.mp4", take.TakeNumber),
                take.TakeNumber,
                1,
                savedPromptForHistory,
                ingredientFiles,
                "SUBMITTED");

            await SubmitGrokPromptAsync(sess, ct);

            // 5. Aguardar geração completa do vídeo .mp4 (com Watchdog de Recarregamento + Retomada pelo Histórico da Última Ação)
            DateTime deadline = DateTime.UtcNow.AddMinutes(8);
            DateTime lastProgressUtc = DateTime.UtcNow;
            string lastFingerprint = "";
            string lastLoggedPct = "";
            int reloadAttempts = 0;
            int stableReadyPolls = 0;
            string generatedVideoUrl = "";

            while (DateTime.UtcNow < deadline)
            {
                ct.ThrowIfCancellationRequested();
                await _cdp.WaitOrWakeOnReloadSignalAsync(4500, ct);

                if (await HasQuotaExhaustedBannerAsync(sess, ct))
                    return true;

                Dictionary<string, object> st = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var body = (document.body && document.body.innerText) ? document.body.innerText : '';
    var vids = Array.from(document.querySelectorAll('video')).map(v => {
        var s = v.currentSrc || v.src || '';
        if (!s) {
            var srcEl = v.querySelector('source');
            if (srcEl) s = srcEl.src || '';
        }
        var r = v.getBoundingClientRect();
        return {
            src: s,
            w: Math.round(r.width),
            h: Math.round(r.height),
            x: Math.round(r.left + r.width/2),
            y: Math.round(r.top + r.height/2),
            ready: v.readyState || 0
        };
    }).filter(v => v.w >= 110 && v.h >= 140 &&
                   v.src.indexOf('/v1/grok-web/') < 0 &&
                   v.src.indexOf('/v1/website/') < 0);

    var spinners = Array.from(document.querySelectorAll('[role=""progressbar""], .animate-spin, svg.animate-spin')).filter(el => {
        var r = el.getBoundingClientRect();
        return r.width > 4 && r.height > 4;
    }).length;

    var pctMatch = body.match(/\b\d{1,2}%\b/);
    var pctStr = pctMatch ? pctMatch[0] : '';
    var hasPct = !!pctMatch;
    var genText = hasPct || /\b(Generating|Imaginando|Criando|Gerando v[ií]deo|Gerando)\b/i.test(body);
    var dlBtn = Array.from(document.querySelectorAll('button[aria-label=""Baixar""], button[aria-label=""Download""]'))
        .some(b => b.getBoundingClientRect().width > 10);

    return JSON.stringify({ vids: vids, spinners: spinners, pctStr: pctStr, genText: genText, hasDlBtn: dlBtn });
})()", ct);

                if (st != null)
                {
                    int spinners = Convert.ToInt32(st["spinners"]);
                    string pctStr = st.ContainsKey("pctStr") ? Convert.ToString(st["pctStr"] ?? "") : "";
                    bool genText = Convert.ToBoolean(st["genText"]);
                    string candidateUrl = "";

                    IEnumerable vidArr = st.ContainsKey("vids") ? st["vids"] as IEnumerable : null;
                    if (vidArr != null)
                    {
                        foreach (object item in vidArr)
                        {
                            Dictionary<string, object> vd = item as Dictionary<string, object>;
                            if (vd == null) continue;
                            string vSrc = vd.ContainsKey("src") ? Convert.ToString(vd["src"] ?? "").Trim() : "";
                            string vClean = vSrc.Split('?')[0];
                            if (!string.IsNullOrEmpty(vSrc) && !preExistingVideoUrls.Contains(vSrc) && !preExistingVideoUrls.Contains(vClean))
                            {
                                candidateUrl = vSrc;
                                break;
                            }
                        }
                    }

                    if (!string.IsNullOrEmpty(pctStr) && pctStr != lastLoggedPct)
                    {
                        lastLoggedPct = pctStr;
                        _log(string.Format("[Grok Vídeo | Take_{0:00}] Progresso de geração: {1}...", take.TakeNumber, pctStr));
                    }

                    string fp = string.Format("{0}|{1}|{2}", candidateUrl, pctStr, spinners);
                    if (fp != lastFingerprint)
                    {
                        lastFingerprint = fp;
                        lastProgressUtc = DateTime.UtcNow;
                    }

                    if (!string.IsNullOrEmpty(candidateUrl) && spinners == 0 && !genText)
                    {
                        generatedVideoUrl = candidateUrl;
                        stableReadyPolls++;
                        if (stableReadyPolls >= 2)
                            break;
                    }
                    else
                    {
                        stableReadyPolls = 0;
                    }
                }

                string manualReason;
                bool manualReload = _cdp.ConsumeReloadAndResumeRequest(out manualReason);
                double stalledSec = (DateTime.UtcNow - lastProgressUtc).TotalSeconds;

                if (manualReload || (stalledSec >= 90 && reloadAttempts < 2))
                {
                    reloadAttempts++;
                    string why = manualReload
                        ? manualReason
                        : string.Format("parado{0} por {1:0}s", !string.IsNullOrEmpty(lastLoggedPct) ? (" em " + lastLoggedPct) : "", stalledSec);

                    _log(string.Format("[Recuperação | Histórico] Travamento detectado no Grok Vídeo Take_{0:00} ({1}). Recarregando a página e retomando com base no histórico da última ação (tentativa {2}/2)...",
                        take.TakeNumber, why, reloadAttempts));

                    await _cdp.ReloadPageAndWaitReadyAsync(sess, 25000, ct);
                    await WaitForGrokInteractiveReadyAsync(sess, ct);

                    if (await HasQuotaExhaustedBannerAsync(sess, ct))
                        return true;

                    // 1. Verifica se após o F5 na página do post o vídeo já apareceu 100% pronto!
                    Dictionary<string, object> postReloadSt = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var body = (document.body && document.body.innerText) ? document.body.innerText : '';
    var vids = Array.from(document.querySelectorAll('video')).map(v => {
        var s = v.currentSrc || v.src || '';
        if (!s) { var se = v.querySelector('source'); if (se) s = se.src || ''; }
        var r = v.getBoundingClientRect();
        return { src: s, w: Math.round(r.width), h: Math.round(r.height) };
    }).filter(v => v.w >= 110 && v.h >= 140 && v.src.indexOf('/v1/grok-web/') < 0 && v.src.indexOf('/v1/website/') < 0);
    var hasPct = /\b\d{1,2}%\b/.test(body);
    return JSON.stringify({ vids: vids, hasPct: hasPct });
})()", ct);

                    string readyVidAfterReload = "";
                    if (postReloadSt != null && !Convert.ToBoolean(postReloadSt["hasPct"]))
                    {
                        IEnumerable rVids = postReloadSt.ContainsKey("vids") ? postReloadSt["vids"] as IEnumerable : null;
                        if (rVids != null)
                        {
                            foreach (object rv in rVids)
                            {
                                Dictionary<string, object> rvd = rv as Dictionary<string, object>;
                                if (rvd == null) continue;
                                string rSrc = rvd.ContainsKey("src") ? Convert.ToString(rvd["src"] ?? "").Trim() : "";
                                string rClean = rSrc.Split('?')[0];
                                if (!string.IsNullOrEmpty(rSrc) && !preExistingVideoUrls.Contains(rSrc) && !preExistingVideoUrls.Contains(rClean))
                                {
                                    readyVidAfterReload = rSrc;
                                    break;
                                }
                            }
                        }
                    }

                    if (!string.IsNullOrEmpty(readyVidAfterReload))
                    {
                        generatedVideoUrl = readyVidAfterReload;
                        _log(string.Format("[Recuperação | Histórico] O vídeo do Take_{0:00} já estava pronto no servidor após recarregar a página -> baixando imediatamente!",
                            take.TakeNumber));
                        break;
                    }

                    // 2. Caso o vídeo não tenha sido gerado após o F5, usa o histórico da última ação (prompt aprimorado salvo + imagens de referência) para reenviar o Take_XX!
                    LastActionCheckpoint cp = LastActionHistoryStore.Current;
                    string promptToResend = (cp != null && cp.TargetTakeNumber == take.TakeNumber && !string.IsNullOrWhiteSpace(cp.PromptSent))
                        ? cp.PromptSent
                        : savedPromptForHistory;

                    _log(string.Format("[Recuperação | Histórico] Retomando geração do Take_{0:00} a partir do histórico da última ação (9:16 | 10s | 720p)...",
                        take.TakeNumber));

                    await _cdp.SendCommandAsync("Page.navigate", new Dictionary<string, object> { { "url", navUrl } }, sess, 20000, ct);
                    await _cdp.WaitForDocumentReadyAsync(sess, 25000, ct);
                    await WaitForGrokInteractiveReadyAsync(sess, ct);

                    await EnsureGrokVideoModeAndOptionsAsync(sess, take.DurationText, ct);

                    if (ingredientFiles != null && ingredientFiles.Count > 0)
                    {
                        await _cdp.SetFileInputFilesByObjectIdAsync(
                            sess,
                            "document.querySelector('input[type=\"file\"][multiple]') || document.querySelector('input[type=\"file\"]')",
                            ingredientFiles,
                            ct);
                        await Task.Delay(1800, ct);
                        await EnsureGrokVideoModeAndOptionsAsync(sess, take.DurationText, ct);
                    }

                    await InjectPromptIntoGrokBoxAsync(sess, promptToResend, ct);
                    await Task.Delay(400, ct);
                    await EnsureGrokDropdownOptionAsync(sess, "Aspecto de proporção", "Aspect ratio", "9:16", ct);
                    await Task.Delay(300, ct);
                    await SubmitGrokPromptAsync(sess, ct);

                    lastProgressUtc = DateTime.UtcNow;
                    lastFingerprint = "";
                    lastLoggedPct = "";
                }
            }

            if (string.IsNullOrEmpty(generatedVideoUrl))
            {
                throw new TimeoutException(string.Format("Timeout aguardando geração do vídeo Take_{0:00} no Grok Imagine.", take.TakeNumber));
            }

            // 6. Baixar o vídeo gerado via botão 'Baixar' (↓) ou download direto autenticado do stream .mp4
            string stagingDir = Path.Combine(ep.TakesDir, "_grok_vid_" + DateTime.Now.ToString("HHmmss"));
            Directory.CreateDirectory(stagingDir);
            await _cdp.SetDownloadBehaviorAsync(stagingDir, ct);

            Dictionary<string, object> dlPt = await FindGrokDownloadButtonPointAsync(sess, ct);
            if (dlPt == null)
            {
                // Clica no card de vídeo recém-gerado na área principal (ignorando miniaturas da barra lateral) para abrir o visualizador onde fica o botão 'Baixar'
                string b64VidUrl = Convert.ToBase64String(Encoding.UTF8.GetBytes(generatedVideoUrl));
                Dictionary<string, object> vidCardPt = await _cdp.EvalJsonAsync(sess, string.Format(@"
(function(){{
    var want = atob('{0}');
    var wantBase = want.split('?')[0];
    var v = Array.from(document.querySelectorAll('video')).find(el => {{
        var r = el.getBoundingClientRect();
        if (r.left <= 245 || r.width < 100) return false;
        var s = el.currentSrc || el.src || '';
        if (!s) {{ var se = el.querySelector('source'); if (se) s = se.src || ''; }}
        var sBase = s.split('?')[0];
        return s === want || sBase === wantBase || (wantBase.length > 20 && sBase.indexOf(wantBase.substring(0, 20)) >= 0);
    }});
    if (!v) return null;
    v.scrollIntoView({{ block: 'center' }});
    var r = v.getBoundingClientRect();
    return JSON.stringify({{ x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) }});
}})()", b64VidUrl), ct);

                if (vidCardPt != null)
                {
                    await _cdp.ClickAtAsync(sess, Convert.ToInt32(vidCardPt["x"]), Convert.ToInt32(vidCardPt["y"]), ct);
                    await Task.Delay(1400, ct);
                    dlPt = await FindGrokDownloadButtonPointAsync(sess, ct);
                }
            }

            HashSet<string> beforeFiles = new HashSet<string>(Directory.GetFiles(stagingDir), StringComparer.OrdinalIgnoreCase);
            string downloadedFile = "";

            if (dlPt != null)
            {
                await _cdp.ClickAtAsync(sess, Convert.ToInt32(dlPt["x"]), Convert.ToInt32(dlPt["y"]), ct);
                downloadedFile = await _cdp.WaitForSingleDownloadAsync(stagingDir, beforeFiles, 80 * 1024, 35000, ct);
            }

            // Fallback: se o botão Baixar não disparou arquivo .mp4, baixa diretamente via fetch autenticado do <video src>
            if (string.IsNullOrEmpty(downloadedFile) ||
                (!downloadedFile.EndsWith(".mp4", StringComparison.OrdinalIgnoreCase) && !downloadedFile.EndsWith(".mov", StringComparison.OrdinalIgnoreCase)))
            {
                beforeFiles = new HashSet<string>(Directory.GetFiles(stagingDir), StringComparer.OrdinalIgnoreCase);
                string b64Url = Convert.ToBase64String(Encoding.UTF8.GetBytes(generatedVideoUrl));
                string targetFn = string.Format("Take_{0:00}.mp4", take.TakeNumber);

                await _cdp.EvalStringAsync(sess, string.Format(@"
(function(){{
    var u = atob('{0}');
    fetch(u, {{ credentials: 'include' }})
        .then(r => r.blob())
        .then(b => {{
            var burl = URL.createObjectURL(b);
            var a = document.createElement('a');
            a.href = burl;
            a.download = '{1}';
            document.body.appendChild(a);
            a.click();
            setTimeout(() => {{ a.remove(); URL.revokeObjectURL(burl); }}, 4000);
        }});
    return 'FETCH_TRIGGERED';
}})()", b64Url, targetFn), ct);

                downloadedFile = await _cdp.WaitForSingleDownloadAsync(stagingDir, beforeFiles, 80 * 1024, 45000, ct);
            }

            await _cdp.ResetDownloadBehaviorToDefaultAsync();
            if (string.IsNullOrEmpty(downloadedFile))
            {
                try { Directory.Delete(stagingDir, true); } catch { }
                throw new IOException(string.Format("Timeout aguardando download do vídeo Take_{0:00}.mp4 gerado no Grok Imagine.", take.TakeNumber));
            }

            if (File.Exists(finalTakePath))
                File.Delete(finalTakePath);
            File.Move(downloadedFile, finalTakePath);

            try { Directory.Delete(stagingDir, true); } catch { }

            _log(string.Format("[Grok Vídeo] Salvo Take_{0:00}.mp4 ({1:0.0} MB).",
                take.TakeNumber, new FileInfo(finalTakePath).Length / (1024.0 * 1024.0)));

            return false;
        }


        private async Task EnsureGrokVideoModeAndOptionsAsync(string sess, string wantedDuration, CancellationToken ct)
        {
            // 1. Ativar modo 'Vídeo' (e garantir que não esteja preso em 'Imagem' ou 'Agente')
            Dictionary<string, object> vidBtn = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var els = Array.from(document.querySelectorAll('button, [role=""button""], [role=""radio""], [role=""tab""]'));
    var btn = els.find(el => {
        var t = (el.innerText || '').trim();
        var al = (el.getAttribute('aria-label') || '').trim();
        var r = el.getBoundingClientRect();
        return r.left > 245 && !el.closest('[data-sidebar], nav, aside') &&
               r.width > 12 && r.height > 12 &&
               (al === 'Vídeo' || al === 'Video' || t === 'Vídeo' || t === 'Video');
    });
    if (!btn) return null;
    var active = btn.getAttribute('aria-pressed') === 'true' ||
                 btn.getAttribute('aria-checked') === 'true' ||
                 btn.getAttribute('aria-selected') === 'true' ||
                 btn.getAttribute('data-state') === 'active' ||
                 btn.getAttribute('data-active') === 'true';
    var r = btn.getBoundingClientRect();
    return JSON.stringify({ active: active, x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) });
})()", ct);

            if (vidBtn != null && !Convert.ToBoolean(vidBtn["active"]))
            {
                await _cdp.ClickAtAsync(sess, Convert.ToInt32(vidBtn["x"]), Convert.ToInt32(vidBtn["y"]), ct);
                await Task.Delay(800, ct);
            }

            // 2. Garantir 'Áudio do vídeo' ativado
            Dictionary<string, object> audBtn = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var b = Array.from(document.querySelectorAll('button')).find(el => {
        var r = el.getBoundingClientRect();
        if (r.left <= 245 || r.width <= 10 || el.closest('[data-sidebar], nav, aside')) return false;
        var al = (el.getAttribute('aria-label') || '');
        return (al.indexOf('Áudio do vídeo') >= 0 || al.indexOf('Video audio') >= 0);
    });
    if (!b) return null;
    var state = (b.getAttribute('aria-pressed') || b.getAttribute('aria-checked') || b.getAttribute('data-state') || '');
    var isOn = (state === 'true' || state === 'active' || state === 'checked');
    var r = b.getBoundingClientRect();
    return JSON.stringify({ isOn: isOn, state: state, x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) });
})()", ct);

            if (audBtn != null && Convert.ToString(audBtn["state"] ?? "") == "false")
            {
                await _cdp.ClickAtAsync(sess, Convert.ToInt32(audBtn["x"]), Convert.ToInt32(audBtn["y"]), ct);
                await Task.Delay(350, ct);
            }

            // 3. Garantir Resolução '720p', Duração ('10s') e Proporção ('9:16')
            await EnsureGrokDropdownOptionAsync(sess, "Resolução do vídeo", "Video resolution", "720p", ct);
            string dur = string.IsNullOrWhiteSpace(wantedDuration) ? "10s" : wantedDuration.Trim();
            if (!dur.EndsWith("s", StringComparison.OrdinalIgnoreCase)) dur = "10s";
            await EnsureGrokDropdownOptionAsync(sess, "Duração do vídeo", "Video duration", dur, ct);
            await EnsureGrokDropdownOptionAsync(sess, "Aspecto de proporção", "Aspect ratio", "9:16", ct);
        }

    }
}
