# Fluxo Vídeo IA Studio — Aplicativo Nativo Windows (`.exe`)

Aplicativo desktop nativo Windows (WPF / C# `.NET Framework 4.8`) que controla o PC localmente via **WMI + Chrome DevTools Protocol (CDP WebSocket Persistente) + Windows UIAutomation + Windows WinRT OCR (`pt-BR`) + FFmpeg + CapCut Desktop**, executando 100% da esteira mecânica do `/fluxo-video-ia` sem gastar tokens do LLM.

## Divisão do Fluxo (Antigravity + App Nativo)

1. **No Antigravity**:
   - Criação/clonagem do roteiro (`Camaleão part 1, 2 e 3`) e decupagem local (`gem-novela` ou `gem-terror`) salvando `roteiro.txt`, `prompt_grok_passo1_e_2.txt` e `prompt_flow_passo3.txt` dentro de `<Pasta_Do_Genero>\<Nome_Da_Historia>\EP.1`, `EP.2` e `EP.3`.
2. **Neste App Nativo (`FluxoVideoStudio.exe`)**:
   - **Etapa 1 — Grok Imagine**: Abre os perfis autorizados (`Profile 62` -> `Profile 1` -> `Profile 67`) via WMI com fallback automático de cota semanal, marca **`Agente`**, envia os personagens e cenários em `9:16`, aguarda concluir, clica em cada miniatura (`Thumbnail 1..N`) e no botão **`Baixar` (`↓`)**, lê o título no topo via **Windows OCR `pt-BR`** para evitar troca de nomes, salva em `EP.X\assets\` e espelha em `%LOCALAPPDATA%\Temp\flow_assets\`. (Pula automaticamente se todos os assets recorrentes já existirem!).
   - **Etapa 2 — Google Flow**: Abre o projeto fixo `9b576f1d-9b0f-4103-ac8e-123edb00a1f0` no `Profile 2` (`GUILHERME`), abre **`Nova sessão`**, verifica individualmente cada personagem e cenário pelo campo **`Pesquisar recursos`** na aba **`Imagens`** (contornando a lista virtualizada de 15 itens), envia arquivos inéditos silenciosamente via interceptação CDP `Page.fileChooserOpened` + `DOM.setFileInputFiles`, vincula **100% dos personagens e cenários** do episódio (`+` -> `Imagens` -> Busca exata -> `Incluir no comando`), envia os takes e digita **`continue`** de 5 em 5 cenas até `100%`, aplica recuperação estrita de erro (`1º Reutilizar comando sem alterar texto` -> `2º Adaptar se persistir`) e baixa todas as cenas sequencialmente em **`720p`** (`Take_01.mp4 .. Take_NN.mp4`).
   - **Etapa 3 — ElevenLabs + Travar Silêncio (`.wav`)**: Extrai todas as falas de `"O Narrador:"` unificadas por `\n\n` (ou pula se o episódio for 100% diálogo), gera na voz **`David - Documentary` (`ppLqTilh7rH7fbUVlXsf`)** (`Profile 4` -> fallback `Profile 63`), baixa o áudio e executa `processar_audio_narrador.ps1` (`-40 dB` / `0,3s` -> `0,3s`, início/meio/fim) gerando `takes\Narrador_Take_01.wav`.
   - **Etapa 4 — CapCut Desktop**: Executa `importar_para_capcut.ps1` (UTF-8 sem BOM, CapCut 9.6+/9.7+), posicionando todos os `Take_01.mp4 .. Take_NN.mp4` em `tracks[0]` e `Narrador_Take_01.wav` em `tracks[1]`.

## Como Executar

- **Modo Interface Gráfica (Duplo Clique)**:
  Execute `FluxoVideoStudio.exe` (ou `Iniciar_FluxoVideoStudio.bat`).

- **Modo Acionamento Direto por Linha de Comando (ex: disparado pelo Antigravity após gerar os prompts)**:
  ```powershell
  "C:\Users\Best Option Notebook\.gemini\antigravity\scratch\fluxo-video-studio\FluxoVideoStudio.exe" --episode "C:\Users\Best Option Notebook\Desktop\MEU TRABALHO\_Videos terror\Minha_Historia\EP.1" --auto-run
  ```

- **Recompilar (se editar `src\*.cs`)**:
  ```powershell
  powershell -NoProfile -ExecutionPolicy Bypass -File .\build.ps1
  ```
