param(
    [string]$Label = ""
)

$ErrorActionPreference = "Stop"
$projectDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$folderName = if ([string]::IsNullOrWhiteSpace($Label)) { "backup_$timestamp" } else { "backup_${timestamp}_$Label" }
$destDir = Join-Path (Join-Path $projectDir "backups") $folderName

New-Item -ItemType Directory -Path (Join-Path $destDir "src") -Force | Out-Null

Copy-Item -Path (Join-Path $projectDir "src\*") -Destination (Join-Path $destDir "src") -Recurse -Force
foreach ($rootFile in @("build.ps1", "backup.ps1", "AGENTS.md", "FluxoVideoStudio.exe")) {
    $full = Join-Path $projectDir $rootFile
    if (Test-Path $full) {
        Copy-Item -Path $full -Destination $destDir -Force
    }
}

Write-Host "BACKUP CRIADO COM SUCESSO: $destDir" -ForegroundColor Green
