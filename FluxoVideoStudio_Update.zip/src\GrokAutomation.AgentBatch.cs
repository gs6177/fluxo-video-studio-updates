using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace FluxoVideoStudio
{
    public partial class GrokAutomation
    {
        private string BuildTaggedGrokAgentBatchPrompt(List<GrokAssetSpec> specsToGenerate)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Faça cada imagem isolada e em 9:16, nome em cima da cabeça nos personagens (e cenários vazios sem texto).");
            sb.AppendLine("REGRA DE RASTREAMENTO INTERNO: Ao chamar a ferramenta de geração de cada imagem (imagine_text_to_image), inclua obrigatoriamente a tag [IMG_01], [IMG_02], etc. no início do prompt interno da ferramenta para identificarmos cada cena, mas NÃO escreva o código [IMG_XX] dentro da arte visível da imagem:");
            sb.AppendLine();

            bool addedCharHeader = false;
            bool addedScenHeader = false;

            for (int i = 0; i < specsToGenerate.Count; i++)
            {
                GrokAssetSpec ms = specsToGenerate[i];
                if (!ms.IsScenario && !addedCharHeader)
                {
                    sb.AppendLine("📦 PASSO 1: PRÉ-DEFINIÇÃO DE PERSONAGENS (ASSETS BASE)");
                    sb.AppendLine();
                    addedCharHeader = true;
                }
                else if (ms.IsScenario && !addedScenHeader)
                {
                    sb.AppendLine("🏠 PASSO 2: PRÉ-DEFINIÇÃO DE CENÁRIOS (ASSETS DE AMBIENTE)");
                    sb.AppendLine();
                    addedScenHeader = true;
                }

                string rawLine = (ms.RawPromptLine ?? "").Trim();
                if (rawLine.StartsWith("-"))
                    rawLine = rawLine.Substring(1).Trim();

                sb.AppendLine(string.Format("- [IMG_{0:00}] ({1}) {2}", i + 1, ms.TargetFileName, rawLine));
                sb.AppendLine();
            }

            return sb.ToString().Trim();
        }

        private async Task GenerateBaseSpecsBatchInAgentModeAsync(
            EpisodeWorkItem ep,
            List<GrokAssetSpec> specsToGenerate,
            CancellationToken ct)
        {
            string promptToSend = BuildTaggedGrokAgentBatchPrompt(specsToGenerate);

            int expectedCount = specsToGenerate.Count;
            _log(string.Format("[Grok Imagine] Iniciando geração de {0} imagens base em 9:16 para {1} ({2})...",
                expectedCount, ep.StoryName, ep.EpisodeName));

            Exception lastErr = null;
            List<string> activeProfiles = _config.GetAvailableGrokProfiles(_log);
            foreach (string profile in activeProfiles)
            {
                ct.ThrowIfCancellationRequested();
                try
                {
                    _log(string.Format("[Grok Imagine] Tentando perfil autorizado '{0}'...", profile));
                    bool quotaExhausted = await TryGenerateAndDownloadWithProfileAsync(profile, promptToSend, ep, specsToGenerate, ct);
                    if (quotaExhausted)
                    {
                        _config.SetProfileStatus(profile, "LIMITE ATINGIDO");
                        _log(string.Format("[Grok Imagine] Limite semanal atingido no perfil '{0}'. Alternando automaticamente para o próximo perfil autorizado...", profile));
                        continue;
                    }

                    _config.SetProfileStatus(profile, "DISPONÍVEL");

                    List<GrokAssetSpec> stillMissingAfterBatch = specsToGenerate.Where(s =>
                    {
                        string p = Path.Combine(ep.AssetsDir, s.TargetFileName);
                        return !File.Exists(p) || new FileInfo(p).Length < 20 * 1024;
                    }).ToList();

                    if (stillMissingAfterBatch.Count > 0 && stillMissingAfterBatch.Count < specsToGenerate.Count)
                    {
                        _log(string.Format("[Recuperação | Histórico] Continuando geração exatamente dos {0} personagens/cenários restantes após retomada: {1}",
                            stillMissingAfterBatch.Count,
                            string.Join(", ", stillMissingAfterBatch.Select(x => x.TargetFileName))));
                        await GenerateBaseSpecsBatchInAgentModeAsync(ep, stillMissingAfterBatch, ct);
                    }
                    return;
                }
                catch (OperationCanceledException)
                {
                    throw;
                }
                catch (Exception ex)
                {
                    lastErr = ex;
                    _log(string.Format("[Grok Imagine] Aviso no perfil '{0}': {1}. Tentando próximo perfil...", profile, ex.Message));
                }
            }

            if (_flowFallback != null && _config.AreAllGrokProfilesMarkedExhausted())
            {
                List<GrokAssetSpec> stillMissing = specsToGenerate.Where(s =>
                {
                    string p = Path.Combine(ep.AssetsDir, s.TargetFileName);
                    return !File.Exists(p) || new FileInfo(p).Length < 20 * 1024;
                }).ToList();

                if (stillMissing.Count > 0)
                {
                    _log(string.Format("[Grok -> Google Flow | Sem Créditos] Todas as contas do Grok atingiram o limite de créditos -> gerando {0} imagem(ns) base restante(s) em 9:16 no Google Flow!",
                        stillMissing.Count));
                    await _flowFallback.GenerateMissingAssetsInFlowAsync(ep, stillMissing, ct);
                }
                return;
            }

            throw new InvalidOperationException(
                "Não foi possível concluir a geração no Grok Imagine em nenhum dos perfis autorizados." +
                (lastErr != null ? " Último erro: " + lastErr.Message : ""));
        }


        private async Task<bool> TryGenerateAndDownloadWithProfileAsync(
            string profile,
            string fullPrompt,
            EpisodeWorkItem ep,
            List<GrokAssetSpec> activeSpecs,
            CancellationToken ct)
        {
            string sess = await _cdp.OpenOrAttachProfileTabAsync(profile, _config.GrokUrl, "grok.com", false, ct);
            await WaitForGrokInteractiveReadyAsync(sess, ct);

            // Verifica cota antes de enviar
            if (await HasQuotaExhaustedBannerAsync(sess, ct))
                return true;

            await EnsureCleanGrokImagineHomeAsync(sess, profile, ct);

            if (await HasQuotaExhaustedBannerAsync(sess, ct))
                return true;

            // PASSO 1 OBRIGATÓRIO: Travar proporção 9:16 no modo Imagem e depois marcar o botão "Agente"
            _log("[Grok Imagine] Passo 1: Configurando proporção 9:16 e ativando função 'Agente'...");
            await EnsureGrokImageModeAnd9x16Async(sess, ct);
            await EnsureAgenteModeSelectedAsync(sess, ct);
            await EnsureGrokDropdownOptionAsync(sess, "Aspecto de proporção", "Aspect ratio", "9:16", ct);

            // Registrar URLs de imagens geradas preexistentes na página (ignorando templates estáticos do Grok)
            await _cdp.EvalStringAsync(sess, @"
(function(){
    window.__fvsBaselineBatchUrls = Array.from(document.querySelectorAll('img'))
        .map(i => i.currentSrc || i.src || '')
        .filter(Boolean);
    return 'OK';
})()", ct);

            // PASSO 2 OBRIGATÓRIO: Inserir texto completo e enviar
            _log("[Grok Imagine] Passo 2: Enviando comando completo (Personagens + Cenários em 9:16)...");
            bool inserted = await InjectPromptIntoGrokBoxAsync(sess, fullPrompt, ct);
            if (!inserted)
                throw new InvalidOperationException("Campo 'O que você gostaria de criar?' não encontrado na tela do Grok Imagine.");

            await Task.Delay(600, ct);
            string batchUrl = await _cdp.EvalStringAsync(sess, "location.href || ''", ct);
            LastActionHistoryStore.RecordAction(
                ep,
                "Grok Imagens",
                string.Format("Gerando lote de {0} imagens base em 9:16 no modo Agente", activeSpecs.Count),
                profile,
                sess,
                batchUrl,
                string.Join(", ", activeSpecs.Select(s => s.TargetFileName)),
                0,
                1,
                fullPrompt,
                null,
                "SUBMITTED");

            await SubmitGrokPromptAsync(sess, ct);

            // Aguardar geração de todas as imagens solicitadas (com Watchdog de Recarregamento + Retomada pelo Histórico)
            int expectedCount = activeSpecs.Count;
            _log(string.Format("[Grok Imagine] Aguardando geração completa das {0} imagens...", expectedCount));

            DateTime startWait = DateTime.UtcNow;
            DateTime maxDeadline = startWait.AddMinutes(9);
            DateTime lastProgressUtc = DateTime.UtcNow;
            string lastFingerprint = "";
            int reloadAttempts = 0;
            int stableReadyPolls = 0;

            while (DateTime.UtcNow < maxDeadline)
            {
                ct.ThrowIfCancellationRequested();
                await _cdp.WaitOrWakeOnReloadSignalAsync(4000, ct);

                if (await HasQuotaExhaustedBannerAsync(sess, ct))
                    return true;

                Dictionary<string, object> st = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var baseList = window.__fvsBaselineBatchUrls || [];
    var body = (document.body.innerText || '');
    var thumbs = Array.from(document.querySelectorAll('button[aria-label^=""Thumbnail ""]')).filter(b => b.getBoundingClientRect().width > 10).length;
    var grokImgs = Array.from(document.querySelectorAll('img')).filter(img => {
        var s = (img.currentSrc || img.src || '');
        var r = img.getBoundingClientRect();
        if (r.width < 90 || r.height < 120 || !img.complete || img.naturalWidth < 200) return false;
        if (s.indexOf('media.x.ai') >= 0 || s.indexOf('agent-skills') >= 0 || s.indexOf('grok-web') >= 0 || s.indexOf('/website/') >= 0) return false;
        if (baseList.indexOf(s) >= 0) return false;
        return s.indexOf('/generated/') >= 0 || s.indexOf('assets.grok.com/users/') >= 0 || s.indexOf('blob:') >= 0;
    }).length;
    var spinners = Array.from(document.querySelectorAll('[role=""progressbar""], .animate-spin, svg.animate-spin')).filter(el => {
        var r = el.getBoundingClientRect();
        return r.width > 4 && r.height > 4;
    }).length;
    var pctMatch = body.match(/\b\d{1,2}%\b/);
    var pctStr = pctMatch ? pctMatch[0] : '';
    var hasPct = !!pctMatch;
    var genText = hasPct || /\b(Generating|Imaginando|Criando imagens|Gerando)\b/i.test(body);
    return JSON.stringify({ thumbs: thumbs, imgs: grokImgs, spinners: spinners, pctStr: pctStr, genText: genText });
})()", ct);

                if (st != null)
                {
                    int thumbs = Convert.ToInt32(st["thumbs"]);
                    int imgs = Convert.ToInt32(st["imgs"]);
                    int spinners = Convert.ToInt32(st["spinners"]);
                    string pctStr = st.ContainsKey("pctStr") ? Convert.ToString(st["pctStr"] ?? "") : "";
                    bool genText = Convert.ToBoolean(st["genText"]);
                    int effectiveCount = Math.Max(thumbs, imgs);

                    string fp = string.Format("{0}|{1}|{2}", effectiveCount, pctStr, spinners);
                    if (fp != lastFingerprint)
                    {
                        lastFingerprint = fp;
                        lastProgressUtc = DateTime.UtcNow;
                    }

                    _log(string.Format("[Grok Imagine] Progresso: {0}/{1} imagens detectadas{2} (miniaturas: {3}, spinners: {4})...",
                        effectiveCount, expectedCount, !string.IsNullOrEmpty(pctStr) ? (" [" + pctStr + "]") : "", thumbs, spinners));

                    if (effectiveCount >= expectedCount && spinners == 0 && !genText)
                    {
                        stableReadyPolls++;
                        if (stableReadyPolls >= 2)
                            break;
                    }
                    else
                    {
                        stableReadyPolls = 0;
                    }
                }

                string manualReason;
                bool manualReload = _cdp.ConsumeReloadAndResumeRequest(out manualReason);
                double stalledSec = (DateTime.UtcNow - lastProgressUtc).TotalSeconds;

                if (manualReload || (stalledSec >= 90 && reloadAttempts < 2))
                {
                    reloadAttempts++;
                    string why = manualReload
                        ? manualReason
                        : string.Format("sem avanço por {0:0}s", stalledSec);
                    _log(string.Format("[Recuperação | Histórico] Travamento detectado no Grok Imagens ({0}). Recarregando a página e retomando com base no histórico da última ação (tentativa {1}/2)...",
                        why, reloadAttempts));

                    await _cdp.ReloadPageAndWaitReadyAsync(sess, 25000, ct);
                    await WaitForGrokInteractiveReadyAsync(sess, ct);

                    int afterThumbs = await GetVisibleThumbnailCountAsync(sess, ct);
                    if (afterThumbs >= expectedCount)
                    {
                        _log(string.Format("[Recuperação | Histórico] Todas as {0} miniaturas já estavam prontas após recarregar a página -> prosseguindo para download!",
                            afterThumbs));
                        break;
                    }
                    else if (afterThumbs == 0)
                    {
                        _log("[Recuperação | Histórico] Nenhuma miniatura concluída após recarregar -> reenviando comando a partir do histórico da última ação...");
                        await EnsureCleanGrokImagineHomeAsync(sess, profile, ct);
                        await EnsureGrokImageModeAnd9x16Async(sess, ct);
                        await EnsureAgenteModeSelectedAsync(sess, ct);
                        await EnsureGrokDropdownOptionAsync(sess, "Aspecto de proporção", "Aspect ratio", "9:16", ct);
                        await InjectPromptIntoGrokBoxAsync(sess, fullPrompt, ct);
                        await Task.Delay(500, ct);
                        await SubmitGrokPromptAsync(sess, ct);
                        lastProgressUtc = DateTime.UtcNow;
                        lastFingerprint = "";
                    }
                    else
                    {
                        _log(string.Format("[Recuperação | Histórico] {0}/{1} miniaturas já estão prontas após recarregar a página -> salvando as concluídas e continuando do ponto onde parou!",
                            afterThumbs, expectedCount));
                        break;
                    }
                }
            }

            // PASSO 3 OBRIGATÓRIO: Abrir visualização com coluna de miniaturas à esquerda (se ainda estiver na grade)
            await EnsureThumbnailViewerOpenAsync(sess, expectedCount, ct);

            int totalThumbs = await GetVisibleThumbnailCountAsync(sess, ct);
            string stagingDir = Path.Combine(ep.AssetsDir, "_grok_staging_" + DateTime.Now.ToString("HHmmss"));
            Directory.CreateDirectory(stagingDir);
            await _cdp.SetDownloadBehaviorAsync(stagingDir, ct);

            List<string> downloadedRawPaths = new List<string>();

            if (totalThumbs <= 0)
            {
                // Quando expectedCount == 1, o Grok abre o visualizador do post sem coluna lateral de miniaturas e exibe o botão 'Baixar' diretamente
                Dictionary<string, object> singleDlPt = await FindGrokDownloadButtonPointAsync(sess, ct);
                if (singleDlPt == null)
                {
                    try { Directory.Delete(stagingDir, true); } catch { }
                    throw new InvalidOperationException("Coluna de miniaturas ('Thumbnail 1..N') ou botão 'Baixar' não apareceu após a geração no Grok Imagine.");
                }

                HashSet<string> beforeSingle = new HashSet<string>(Directory.GetFiles(stagingDir), StringComparer.OrdinalIgnoreCase);
                await _cdp.ClickAtAsync(sess, Convert.ToInt32(singleDlPt["x"]), Convert.ToInt32(singleDlPt["y"]), ct);
                string singleSaved = await _cdp.WaitForSingleDownloadAsync(stagingDir, beforeSingle, 50 * 1024, 35000, ct);
                if (string.IsNullOrEmpty(singleSaved))
                    throw new IOException("Timeout aguardando download da imagem única no Grok Imagine.");

                downloadedRawPaths.Add(singleSaved);
                _log(string.Format("[Grok Imagine] Imagem 1/1 salva ({0} KB).", new FileInfo(singleSaved).Length / 1024));
            }
            else
            {
                // Para CADA miniatura na coluna esquerda -> Clicar na miniatura -> Clicar no botão Baixar (↓)
                for (int idx = 1; idx <= totalThumbs; idx++)
                {
                    ct.ThrowIfCancellationRequested();
                    _log(string.Format("[Grok Imagine] Baixando imagem {0}/{1}: clicando em 'Thumbnail {0}' e depois no botão 'Baixar' (↓)...",
                        idx, totalThumbs));

                    Dictionary<string, object> thumbPt = await _cdp.EvalJsonAsync(sess, string.Format(@"
(function(){{
    var btns = Array.from(document.querySelectorAll('button[aria-label=""Thumbnail {0}""]'));
    var b = btns.find(x => x.getBoundingClientRect().width > 10) || btns[0];
    if (!b) return null;
    b.scrollIntoView({{ block: 'center' }});
    var r = b.getBoundingClientRect();
    return JSON.stringify({{ x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) }});
}})()", idx), ct);

                    if (thumbPt == null)
                    {
                        _log(string.Format("[Grok Imagine] Aviso: 'Thumbnail {0}' não encontrada na coluna esquerda.", idx));
                        continue;
                    }

                    await _cdp.ClickAtAsync(sess, Convert.ToInt32(thumbPt["x"]), Convert.ToInt32(thumbPt["y"]), ct);
                    await Task.Delay(750, ct);

                    Dictionary<string, object> dlPt = await FindGrokDownloadButtonPointAsync(sess, ct);
                    if (dlPt == null)
                        throw new InvalidOperationException("Botão 'Baixar' (↓) visível não foi encontrado na visualização do Grok Imagine.");

                    HashSet<string> beforeFiles = new HashSet<string>(Directory.GetFiles(stagingDir), StringComparer.OrdinalIgnoreCase);
                    await _cdp.ClickAtAsync(sess, Convert.ToInt32(dlPt["x"]), Convert.ToInt32(dlPt["y"]), ct);

                    // Regra 13: Aguardar download individual concluir e validar tamanho > 50 KB antes da próxima miniatura
                    string savedFile = await _cdp.WaitForSingleDownloadAsync(stagingDir, beforeFiles, 50 * 1024, 35000, ct);
                    if (string.IsNullOrEmpty(savedFile))
                    {
                        _log(string.Format("[Grok Imagine] Retentando clique no botão 'Baixar' para Thumbnail {0}...", idx));
                        await _cdp.ClickAtAsync(sess, Convert.ToInt32(dlPt["x"]), Convert.ToInt32(dlPt["y"]), ct);
                        savedFile = await _cdp.WaitForSingleDownloadAsync(stagingDir, beforeFiles, 50 * 1024, 35000, ct);
                    }

                    if (string.IsNullOrEmpty(savedFile))
                        throw new IOException(string.Format("Timeout aguardando download da imagem Thumbnail {0} no Grok Imagine.", idx));

                    downloadedRawPaths.Add(savedFile);
                    _log(string.Format("[Grok Imagine] Imagem {0}/{1} salva ({2} KB).",
                        idx, totalThumbs, new FileInfo(savedFile).Length / 1024));
                }
            }

            // PASSO 4 OBRIGATÓRIO (Regra 20): Extrair prompts reais por UUID no React Fiber do Grok Agente + Windows OCR pt-BR para casamento 1:1 imune a fora-de-sequência
            await _cdp.ResetDownloadBehaviorToDefaultAsync();
            GrokPostMetadata postMeta = await ExtractGrokPostMetadataByUuidAsync(sess, ct);
            MatchAndRenameGrokDownloadsWithOcr(stagingDir, downloadedRawPaths, activeSpecs, ep.AssetsDir, postMeta);

            try { Directory.Delete(stagingDir, true); } catch { }
            return false;
        }

    }
}
