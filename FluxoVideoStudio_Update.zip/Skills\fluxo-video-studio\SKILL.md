---
name: fluxo-video-studio
description: >-
  Skill oficial de arquitetura, manutenção, evolução, diagnóstico e instalação em 1 clique do programa desktop nativo FluxoVideoStudio (C# WPF .NET Framework 4.0) que automatiza a esteira [1] Grok Imagine -> [2] Google Flow -> [3] ElevenLabs (WAV -40dB) -> [4] CapCut Desktop. Contém todo o aprendizado acumulado sobre CDP WebSocket (porta 9222), trava de elenco, geração de figurinos mantendo o mesmo rosto, proporção obrigatória 9:16 no Grok, download imediato no ElevenLabs, restauração automática da pasta Downloads do Chrome, bypass do Controle Inteligente de Aplicativos do Windows 11 e configuração multi-PC.
---

# Skill Oficial do Programa `FluxoVideoStudio` (Arquitetura, Regras, Aprendizados e Instalação Multi-PC)

Use esta skill sempre que o usuário pedir para instalar, configurar, dar manutenção, corrigir bugs, adicionar funções ou atualizar o aplicativo desktop **`FluxoVideoStudio`** em qualquer computador.

---

## 1. Localização do Projeto, Compilação e Regra Obrigatória de Backup

- **Diretório Principal de Desenvolvimento**:
  - `C:\Users\Best Option Notebook\.gemini\antigravity\scratch\fluxo-video-studio` (ou `<Desktop>\MEU TRABALHO\FluxoVideoStudio` em outros PCs).
- **Regra Inegociável de Backup Antes de Qualquer Alteração (`backup.ps1`)**:
  - **SEMPRE** execute o script `backup.ps1` antes de editar qualquer arquivo em `src\`:
    ```powershell
    powershell.exe -ExecutionPolicy Bypass -File "<Pasta_Do_Studio>\backup.ps1"
    ```
- **Compilação Nativa Sem Dependências Externas (`build.ps1`)**:
  - O projeto usa **C# 5** compatível com o compilador nativo do Windows (`C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe`).
  - **Proibido** usar sintaxes exclusivas do C# 6+ (como interpolação `$"..."`, `?.`, `nameof`, *out variables inline* `out int x` ou *tuples* `(a, b)`) para garantir compilação 100% limpa em qualquer Windows 10/11 via:
    ```powershell
    powershell.exe -ExecutionPolicy Bypass -File "<Pasta_Do_Studio>\build.ps1"
    ```
- **Regra de Fluxo de Atualizações (Local Primeiro -> Publicação Manual pelo Usuário)**:
  - Todas as alterações devem ser aplicadas e compiladas **primeiro apenas localmente no PC principal**.
  - **Nunca** execute `Publicar_Atualizacao_Remota.ps1` automaticamente sem ordem explícita: o usuário testa primeiro no PC principal e, quando aprovar, clica manualmente no botão **`☁️ Publicar Atualização no GitHub (PC Principal)`** na barra superior do programa (`🔄 Atualização Remota (GitHub)`).

---

## 2. Solução Definitiva Contra Bloqueio do Windows 11 (*Controle Inteligente de Aplicativos / Smart App Control*)

Quando arquivos `.zip` ou `.exe` são transferidos via WhatsApp/Drive para outro PC com Windows 11, o **Controle Inteligente de Aplicativos** bloqueia executáveis sem assinatura digital que contenham *Mark of the Web* (`Zone.Identifier`).
- **Como o `FluxoVideoStudio` resolve isso de forma definitiva**:
  1. `Unblock-File` recursivo em toda a pasta do programa;
  2. Compilação local via `build.ps1` no computador de destino;
  3. **`Iniciar_Sem_Bloqueio.ps1` + `Iniciar_FluxoVideoStudio.bat`**: Carrega e compila os arquivos `src\*.cs` diretamente em memória (`Add-Type`) dentro do processo `powershell.exe -STA` (que possui assinatura digital oficial da Microsoft), definindo `$env:FVS_BASE_DIR` para a pasta do programa e chamando `[FluxoVideoStudio.Program]::Main(@())`. Assim, o programa abre sem nunca ser bloqueado pelo Windows 11.

---

## 3. Aprendizados Críticos e Regras de Ouro Implementadas no Código (`src\`)

### A. `CdpController.cs` — Conexão Chrome CDP (Porta `9222`), Espera de Guias e Pasta `Downloads`
1. **Conexão Persistente, Prevenção de `403 Proibido` e Auto-Allow (`BringAnyChromeWindowToFront` + `DismissStaleRemoteDebugPopupIfPresent`)**:
   - Lê `%LOCALAPPDATA%\Google\Chrome\User Data\DevToolsActivePort` e mantém um único `ClientWebSocket` ativo.
   - **Problema resolvido (`403 Proibido` / `Connection rejected`)**: No Chrome 156+, se nenhuma janela do Chrome estiver ativa em primeiro plano (por exemplo, quando o foco está no `FluxoVideoStudio.exe`) ou se um popup `"Permitir depuração remota?"` de tentativa anterior tiver ficado aberto, o Chrome rejeita a conexão WebSocket em `21ms` com `HTTP 403 Forbidden (Connection rejected)` antes mesmo de exibir o popup.
   - **Regra atual**: Antes de abrir o WebSocket (e também no retry de `403`), `EnsureConnectedAsync` limpa qualquer popup pendente (`DismissStaleRemoteDebugPopupIfPresent()`), traz uma janela do Google Chrome para frente (`BringAnyChromeWindowToFront()` via `ShowWindow` + `SetForegroundWindow`) e dispara `TriggerSingleAutoAllow` para autorizar silenciosamente o popup `"Permitir depuração remota?"`.
2. **Tempo de Espera Reforçado ao Abrir Novas Guias/Janelas (`WaitForDocumentReadyAsync` + `OpenOrAttachProfileTabAsync`)**:
   - **Problema resolvido**: Antes, o programa iniciava cliques assim que `document.readyState` ficava `"interactive"` (`700ms`), antes do React/Next.js renderizar os botões e inputs de arquivo, gerando erros de anexo (`0 imagem(ns) na caixa`).
   - **Regra atual**: `WaitForDocumentReadyAsync` exige `document.readyState === 'complete'` + URL diferente de `about:blank` + `document.body.innerHTML.length > 200` (`COMPLETE_READY`), seguido de `2200ms` de hidratação e mais `2500ms` a `3200ms` ao abrir novas janelas/guias.
3. **Restauração Obrigatória da Pasta `Downloads` do Usuário (`ResetDownloadBehaviorToDefaultAsync`)**:
   - **Problema resolvido**: Ao usar `Browser.setDownloadBehavior` apontando para pastas temporárias (`_grok_staging_*`, `_grok_vid_*`, `_flow_dl_*`, `_eleven_dl_*`), o Chrome continuava salvando os downloads manuais do usuário dentro dessas subpastas ocultas após o uso do programa.
   - **Regra atual**: Imediatamente após cada download automático no Grok, Flow ou ElevenLabs — e também em `MainWindow.SetRunningUiState(false)` (inclusive quando o usuário clica em `⏹ Parar`) — o programa chama `ResetDownloadBehaviorToDefaultAsync()`, que restaura o `Browser.setDownloadBehavior` para `C:\Users\<Usuario>\Downloads` (`behavior: "allow"` seguido de `behavior: "default"`).

### B. `GrokAutomation.cs` — Imagens `9:16`, Figurinos com Mesmo Rosto, Contas e Vídeos
1. **Garantia Estrita da Proporção `9:16` (`EnsureGrokImageModeAnd9x16Async` + `EnsureGrokDropdownOptionAsync`)**:
   - **Problemas resolvidos**:
     1. No Grok Imagine, o item `9:16` dentro do menu `Aspecto de proporção` (`[role="menuitemradio"]`) tem `innerText = "9:16\nVertical"` (duas linhas). Incluir `[data-radix-popper-content-wrapper] div` no `querySelectorAll` fazia o fallback `.indexOf('9:16') >= 0` casar primeiro com a `div` container externa do menu (que tem `children.length <= 4`), cujo centro vertical `(y ~ 507..523)` caía exatamente em cima da opção **`1:1\nQuadrado`**!
     2. No modo **Vídeo**, anexar 2 ou mais imagens de referência muda o Grok para o modo *Ingredients to Video* e reseta o `Aspecto de proporção` para `1:1`.
     3. Na barra lateral esquerda do Grok (`"Ver todos"` em `x=19..204, y=601`), as miniaturas das últimas cenas geradas são `<button aria-label="3D CGI ... Video Generation Prompt">`. Buscar `al.toLowerCase().indexOf('ratio') >= 0` casava com a palavra **`"Generation"`** (`Gene` + **`ratio`** + `n`) na primeira miniatura de `"Ver todos"`, fazendo o programa clicar no ícone da última cena gerada e ficar alternando entre a última cena e a tela de criação!
   - **Regra atual**:
     - `EnsureGrokDropdownOptionAsync` e todos os seletores da barra de comando do Grok exigem `r.left > 245 && !el.closest('[data-sidebar], nav, aside')` (bloqueando 100% qualquer clique na barra lateral esquerda `"Ver todos"`) e verificam `'aspect ratio'` / `'aspecto de propor'` / `'proporção'` (nunca `'ratio'` isolado).
     - `EnsureGrokDropdownOptionAsync` busca exclusivamente `[role="menuitemradio"], [role="option"], [role="menuitem"], [data-radix-popper-content-wrapper] button` (sem `div` container pai), comparando a 1ª linha (`raw.split(/\r?\n/)[0].trim() === '9:16'`) ou `<span>` filho exato, e confere em loop se o botão realmente mudou para `9:16`.
     - No modo **Vídeo** (`TryGenerateSingleVideoTakeWithProfileAsync`), a geração de cenas é feita pela página `https://grok.com/imagine/saved`, e `EnsureGrokVideoModeAndOptionsAsync` (`720p`, `10s`, `9:16`) é chamado antes de anexar, **imediatamente após anexar as imagens de referência** e **novamente após `Aprimorar o prompt` (imediatamente antes de enviar)**.
2. **Espera Interativa do Grok (`WaitForGrokInteractiveReadyAsync`)**:
   - Aguarda até que a caixa de texto (`textarea` / `[contenteditable="true"]`) e os botões de modo (`Imagem`, `Vídeo`, `Agente`) estejam visíveis no DOM + `1800ms` extras antes de interagir.
3. **Conferência de Elenco e Geração de Novos Figurinos Anexando o Personagem Base (`GenerateVariantSpecWithBaseCharacterAsync`)**:
   - Ao clicar em Gerar Imagens Grok, o programa primeiro confere todos os arquivos já existentes em `EP.X\assets\` (e também em `EP.1\assets\` da mesma história).
   - Se um item ausente do `PASSO 1` for uma **nova pré-definição de roupa/figurino de um personagem que já existe** (detectado por `EpisodeParser.FindExistingBaseCharacterPathForVariantSpec`), ele **NÃO** envia esse item solto no modo `Agente`; em vez disso, anexa a imagem `.jpg` do personagem base no modo `Imagem` (`9:16`) com retry automático de anexo (`attachCountStr != "0"`) e pede ao Grok para manter 100% o mesmo rosto/fisionomia trocando apenas a roupa de acordo com o contexto da cena.
4. **Pulo Automático de Perfis com Limite Atingido (`GetAvailableGrokProfiles`)**:
   - Perfis marcados como `LIMITE ATINGIDO` em `studio_user_settings.json` são pulados imediatamente, tanto na geração de imagens em lote quanto na regeração de takes individuais.
5. **Geração de Vídeo no Grok com Varinha Mágica (`TryGenerateSingleVideoTakeWithProfileAsync` + `EnhanceGrokVideoPromptAsync`)**:
   - No modo `Vídeo` (`9:16`, `10s`, `720p`, áudio ativado), anexa os ingredientes do take (já respeitando o figurino escolhido para aquele take), insere o prompt e clica em `"Aprimorar o prompt"` (varinha mágica 🪄) antes de enviar.

### C. `ElevenLabsCapCutAutomation.cs` — Download Imediato do Áudio e Travar Silêncio
1. **Download Imediato Assim que o Botão `Baixar` Fica Clicável (`TrySynthesizeWithProfileAsync`)**:
   - **Problema resolvido**: Antes, o loop só checava 4 strings fixas de `aria-label` e confundia o botão `"Parar"`/`"Stop"` do player de áudio (que toca a prévia automaticamente após a síntese) com `"ainda gerando"`, fazendo o programa esperar 120 segundos até o timeout antes de clicar em Baixar.
   - **Regra atual**: O loop verifica a cada `350ms` todos os seletores (`button[aria-label="Baixar o mais recente"]`, `button[aria-label*="Baixar" i]`, `button[aria-label*="Download" i]`, etc.), ignora o botão `"Parar"` do player de áudio e clica em **Baixar** imediatamente no primeiro instante em que `!generating && hasDl`, pausando em seguida o player e restaurando a pasta `Downloads`.
2. **Processamento de Áudio (`processar_audio_narrador.ps1`) e CapCut (`montar_capcut.ps1`)**:
   - Trunca pausas/silêncios maiores que `0,3s` (`-40dB`) para exatos `0,3s`, salva em `.wav` PCM e monta na timeline do CapCut Desktop.

### D. `EpisodeParser.cs` e `FlowAutomation.cs` — Falsos Positivos de Criança, Painel do Agente e Pastas Dinâmicas
1. **Abertura Confiável do Painel Lateral do Agente (`EnsureAgentPanelOpenAsync` + `ClickNewAgentSessionAsync`)**:
   - **Problema resolvido**: No Google Flow, o chip `button.agent-mode-chip` (`Agente`) possui `aria-pressed="true"` (`agent-mode-chip-checked`) quando o modo Agente já está selecionado na barra inferior colapsada (onde o botão `expand_content` / `aria-label="Abrir"` fica visível em `1019, 570`). Clicar cegamente em `Agente` quando ele já está `aria-pressed="true"` **desativa** o modo Agente (`aria-pressed="false"`) e faz o botão `expand_content` sumir. Além disso, `TrySalvageCompletedTakesFromCurrentFlowScreenAsync` clica em `Reutilizar comando` nos cards do grid, o que fecha o `<flow-agent-panel>` de volta para a barra inferior, e o `aria-label` do botão `edit_square` no Flow é `"Iniciar nova sessão"` (com `'nova sessão'` em minúsculas).
   - **Regra atual**: `EnsureAgentPanelOpenAsync` verifica primeiro (case-insensitive) se `edit_square` / `nova sess` já está visível; se não estiver e `expand_content` (`aria-label="Abrir"`) estiver visível, clica direto em `expand_content` sem tocar no chip `Agente`; e só clica em `button.agent-mode-chip` se `aria-pressed !== 'true'`, expandindo em seguida `expand_content`. Também é chamado obrigatoriamente após `TrySalvageCompletedTakesFromCurrentFlowScreenAsync` e dentro de `ClickNewAgentSessionAsync`.
2. **Prevenção e Recuperação Automática de `"Notamos uma atividade incomum"` + Botão `Tentar de novo` (`CdpController.cs` + `FlowAutomation.cs`)**:
   - **Problema resolvido**: No Google Flow, injetar `#fvs_<Perfil>` na URL ou alterar `window.name = 'fvs_...'` em `flow.google.com`, aliado a 20 mutações seguidas de `HTMLInputElement.prototype.value.set` + `new Event('input')` (`isTrusted: false`) no campo `input.search-input` e cliques sintéticos `btn.click()`, acionava o bloqueio anti-extensão do Agente (`"Notamos uma atividade incomum. As extensões do navegador que modificam a página podem causar problemas."` + botão **`Tentar de novo`**), deixando `WaitForCurrentBatchToFinishAsync` preso por 12 minutos em `0/10`.
   - **Regra atual**:
     - Em `CdpController.OpenOrAttachProfileTabAsync`, URLs de `flow.google.com` nunca recebem `#fvs_` no hash e nunca alteram `window.name`.
     - Em `SearchOverlayAssetAsync`, o programa verifica primeiro se o arquivo já está visível nos 15 cards atuais da aba `Imagens` sem tocar na caixa de busca (zero mutação de DOM quando os 10 assets já estão no topo), e usa `document.execCommand('insertText')` quando precisa filtrar.
     - Em `InspectCurrentSessionStateAsync` e `WaitForCurrentBatchToFinishAsync`, se o painel do Agente exibir `"atividade incomum"` / botão **`Tentar de novo`**, o programa aguarda `4s` e clica automaticamente em **`Tentar de novo`** via CDP (`_cdp.ClickAtAsync`, até 2 tentativas); se o bloqueio persistir na 3ª verificação, encerra imediatamente a espera no Flow e transfere automaticamente os takes restantes para o **Grok Vídeo (`9:16`)**.
3. **Detecção Precisa de Criança/Bebê (`TakeLikelyContainsChildOrBaby`)**:
   - **Problema resolvido**: Palavras como *"cria"* (animal), *"filha"* / *"filho"* (quando adultos), *"criança interior"* ou *"desde criança"* causavam falsos positivos de takes com criança.
   - **Regra atual**: Verifica se os ingredientes da cena possuem marcadores explícitos de adulto (`homem adulto`, `mulher adulta`, `idoso`, `idosa`) e só classifica como take de criança quando há termos inequívocos de personagem infantil físico em cena (`bebê de colo`, `recém-nascido`, `menininho`, `menininha`, `garotinho`, `garotinha`).
4. **Descoberta Dinâmica de Pastas (`GetNovelaRoot` / `GetTerrorRoot`)**:
   - Busca primeiro os caminhos personalizados salvos em `studio_user_settings.json` (`NovelaRootDir` e `TerrorRootDir`) e, se vazios, detecta automaticamente tanto `C:\Users\<Usuario>\Desktop\MEU TRABALHO` quanto `C:\Users\<Usuario>\OneDrive\Desktop\MEU TRABALHO`.

### E. `MainWindow.cs` — Seletor Visual de Contas do Chrome e Gerenciamento de Pastas
- Na aba **`⚙ Contas, Vozes & Pastas`**:
  - Botão **`🔍 Detectar e Selecionar Perfis do Chrome deste PC (Grok / Flow / ElevenLabs)`** (`ShowChromeProfileSelectorDialog`): lê `%LOCALAPPDATA%\Google\Chrome\User Data\Local State`, exibe todos os perfis (`Default`, `Profile 1`, `Profile 2`, ...) com Nome e E-mail Google e permite marcar quais são usados para **Grok**, **Google Flow** e **ElevenLabs**, além de abrir qualquer perfil com 1 clique para login.
  - Botão **`🔧 Abrir chrome://inspect (Ativar Depuração Remota)`**: abre `chrome://inspect/#remote-debugging` para marcar `Discover network targets`.
  - Campos e botões para definir e abrir as pastas raiz de **Novela / Reflexão** (`_videos de reflexão`) e **Terror** (`_Videos terror`).

### F. `Models.cs`, `CdpController.cs`, `GrokAutomation.cs`, `FlowAutomation.cs` e `ElevenLabsCapCutAutomation.cs` — Recuperação de Travamento (Watchdog Automático + Botão `🔄 Recarregar e Continuar` + Histórico da Última Ação)
- **Histórico Persistente (`LastActionCheckpoint` + `LastActionHistoryStore` em `src/Models.cs`)**:
  - Salva em tempo real a ação em andamento (`StageName`, `SubActionDescription`, `ChromeProfile`, `SessionId`, `PageUrl`, `TargetItemName`, `TargetTakeNumber`, `BatchNumber`, `PromptSent`, `AttachedFiles`, `Status`) e as últimas 30 ações em `last_action_history.json` (na raiz do programa e em `<Episodio>\last_action_history.json`).
- **Sinal e Recarregamento CDP (`ReloadPageAndWaitReadyAsync` + `WaitOrWakeOnReloadSignalAsync` em `src/CdpController.cs`)**:
  - Acorda imediatamente qualquer espera de polling quando o usuário clica em **`🔄 Recarregar e Continuar`** e executa `Page.reload` aguardando `document.readyState === 'complete'`.
- **Retomada Inteligente por Etapa**:
  - **Grok Vídeo (`TryGenerateSingleVideoTakeWithProfileAsync`)**: salva o prompt já aprimorado pela varinha mágica no histórico antes de enviar; se a porcentagem travar por `85s` (ex.: `Gerando 16%`) ou o botão manual for clicado, recarrega a página do post (`Page.reload`), verifica primeiro se o vídeo já terminou no servidor durante o reload (baixando na hora se sim) ou reenvia em `9:16 | 10s | 720p` usando o prompt e imagens salvas no histórico da última ação.
  - **Grok Imagens e Figurinos (`TryGenerateAndDownloadWithProfileAsync` / `GenerateVariantSpecWithBaseCharacterAsync`)**: se a geração travar por `90s` ou o botão manual for clicado, recarrega a aba, baixa quaisquer miniaturas que já ficaram prontas e continua gerando somente os personagens/cenários que ainda faltam em `assets\`.
  - **Google Flow (`WaitForCurrentBatchToFinishAsync` + `RunAsync`)**: monitora a evolução dos cards e porcentagens; se ficar sem progresso por `105s` ou o botão manual for clicado, recarrega o projeto Flow, salva/baixa todos os takes já concluídos (`100%`) visíveis na grade, filtra `flowEligibleTakes` mantendo apenas os takes que ainda não estão em `takes\`, abre nova sessão, reanexa os ingredientes e retoma do exato próximo take pendente.
  - **ElevenLabs (`TrySynthesizeWithProfileAsync`)**: se a síntese ficar sem resposta por `55s` ou o botão manual for clicado, recarrega o ElevenLabs, restaura o texto do narrador salvo no histórico da última ação e retoma a síntese e download imediato.

---

## 4. Procedimento Padrão para Instalar e Configurar Tudo em Outro PC (1 Clique)

Sempre que o usuário pedir para instalar ou atualizar o programa e as skills em outro PC:

1. **Executar o Instalador Unificado (`Instalar_Tudo_Outro_PC.ps1` / `INSTALAR_TUDO_1_CLIQUE.bat`)**:
   - Desbloqueia todos os arquivos (`Unblock-File`);
   - Detecta a Área de Trabalho real do PC (`[Environment]::GetFolderPath('DesktopDirectory')`, incluindo suporte a `OneDrive\Desktop`);
   - Cria automaticamente na Área de Trabalho:
     - `MEU TRABALHO\_videos de reflexão`
     - `MEU TRABALHO\_Videos terror`
     - `MEU TRABALHO\Videos_Referencia`
     - `MEU TRABALHO\FluxoVideoStudio`
   - Instala/atualiza todas as 6 skills em `$env:USERPROFILE\.gemini\config\skills\` (`fluxo-video-studio`, `fluxo-video-ia`, `gem-novela`, `gem-terror`, `gem 3D Pixar-Disney` e `Camaleão part 1,2 e 3`), substituindo automaticamente `C:\Users\Best Option Notebook\Desktop` pela Área de Trabalho real daquele PC e `C:\Users\Best Option Notebook` por `$env:USERPROFILE`;
   - Compila `FluxoVideoStudio.exe` localmente via `build.ps1` e cria o atalho **`Fluxo Video Studio.lnk`** na Área de Trabalho apontando para `Iniciar_Sem_Bloqueio.ps1`;
   - Lê `%LOCALAPPDATA%\Google\Chrome\User Data\Local State` para mapear automaticamente os perfis do Chrome daquele PC em `studio_user_settings.json`.
