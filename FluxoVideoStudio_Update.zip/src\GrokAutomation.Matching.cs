using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace FluxoVideoStudio
{
    public partial class GrokAutomation
    {
        public Dictionary<string, string> RunWindowsOcrOnFolder(string folderPath)
        {
            Dictionary<string, string> map = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            string ocrScript = Path.Combine(_config.StudioScriptsDir, "ocr_grok_headers.ps1");
            if (!File.Exists(ocrScript) || !Directory.Exists(folderPath)) return map;

            try
            {
                ProcessStartInfo psi = new ProcessStartInfo
                {
                    FileName = "powershell.exe",
                    Arguments = string.Format("-NoProfile -ExecutionPolicy Bypass -File \"{0}\" -FolderPath \"{1}\"", ocrScript, folderPath),
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    CreateNoWindow = true,
                    StandardOutputEncoding = Encoding.UTF8
                };

                using (Process p = Process.Start(psi))
                {
                    string stdout = p.StandardOutput.ReadToEnd();
                    p.WaitForExit(30000);

                    if (!string.IsNullOrWhiteSpace(stdout))
                    {
                        JavaScriptSerializer ser = new JavaScriptSerializer();
                        IEnumerable arr = ser.DeserializeObject(stdout.Trim()) as IEnumerable;
                        if (arr != null)
                        {
                            foreach (object item in arr)
                            {
                                Dictionary<string, object> d = item as Dictionary<string, object>;
                                if (d == null) continue;
                                string fullPath = d.ContainsKey("FullPath") ? Convert.ToString(d["FullPath"]) : "";
                                string ocrText = d.ContainsKey("OcrText") ? Convert.ToString(d["OcrText"]) : "";
                                if (!string.IsNullOrEmpty(fullPath))
                                {
                                    map[fullPath] = ocrText;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _log("[OCR] Aviso ao executar OCR local: " + ex.Message);
            }
            return map;
        }

        private class GrokPostMetadata
        {
            public List<string> ThumbUuids = new List<string>();
            public Dictionary<string, string> UuidToPrompt = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            public List<string> RenderedOrderUuids = new List<string>();
            public List<string> GeneratedOrderUuids = new List<string>();
        }

        private const string JsExtractGrokPostMetadata = @"
(function(){
    var thumbUuids = [];
    var uuidToPrompt = {};
    var renderedOrderUuids = [];
    var generatedOrderUuids = [];

    function extractUuidFromUrl(u) {
        if (!u) return '';
        var m = String(u).match(/\/generated\/([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})/);
        if (m) return m[1].toLowerCase();
        var m2 = String(u).match(/([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})/);
        return m2 ? m2[1].toLowerCase() : '';
    }

    function addUnique(arr, val) {
        if (!val) return;
        var v = String(val).toLowerCase();
        if (arr.indexOf(v) < 0) arr.push(v);
    }

    // 1. Filmstrip Thumbnail 1..N React Fiber (up2.item / up5.items)
    var thumbBtns = Array.from(document.querySelectorAll('button[aria-label^=""Thumbnail ""]'));
    for (var i = 0; i < thumbBtns.length; i++) {
        var b = thumbBtns[i];
        var keys = Object.keys(b);
        var fk = keys.find(k => k.indexOf('__reactFiber') === 0 || k.indexOf('__reactProps') === 0);
        if (!fk) continue;
        var f = b[fk];
        for (var up = 0; up < 10 && f; up++) {
            var mp = f.memoizedProps || f.pendingProps || f;
            if (mp && mp.item && mp.item.id) {
                var tid = String(mp.item.id).toLowerCase();
                thumbUuids.push(tid);
                if (mp.item.prompt && !uuidToPrompt[tid]) {
                    uuidToPrompt[tid] = String(mp.item.prompt);
                }
                break;
            }
            f = f.return;
        }
    }

    // 2. Scan DOM React Fiber for assistant message.cardAttachments & cardAttachmentsJson
    var foundMessageWithCards = false;
    var allEls = document.querySelectorAll('div, section, article, main, aside');
    for (var eIdx = 0; eIdx < allEls.length; eIdx++) {
        var el = allEls[eIdx];
        var eKeys = Object.keys(el);
        var rKey = '';
        for (var k = 0; k < eKeys.length; k++) {
            if (eKeys[k].indexOf('__reactFiber') === 0 || eKeys[k].indexOf('__reactProps') === 0) {
                rKey = eKeys[k];
                break;
            }
        }
        if (!rKey) continue;
        var node = el[rKey];
        for (var depth = 0; depth < 12 && node; depth++) {
            var p = node.memoizedProps || node.pendingProps;
            if (p && p.message && (Array.isArray(p.message.cardAttachments) || Array.isArray(p.message.cardAttachmentsJson))) {
                foundMessageWithCards = true;
                var msg = p.message;
                var attachments = Array.isArray(msg.cardAttachments) ? msg.cardAttachments : [];
                for (var aIdx = 0; aIdx < attachments.length; aIdx++) {
                    var att = attachments[aIdx];
                    if (!att) continue;
                    var rawJson = att.latestJson || (Array.isArray(att.allJson) && att.allJson.length > 0 ? att.allJson[att.allJson.length - 1] : '');
                    var parsed = null;
                    if (rawJson && typeof rawJson === 'string') {
                        try { parsed = JSON.parse(rawJson); } catch (e) {}
                    }
                    var attType = att.type || (parsed && parsed.type) || '';
                    var cardType = att.cardType || (parsed && parsed.cardType) || '';

                    if (attType === 'imagine_text_to_image' || cardType === 'generated_image_card') {
                        var chunk = parsed && parsed.image_chunk ? parsed.image_chunk : null;
                        var uid = chunk && chunk.imageUuid ? String(chunk.imageUuid).toLowerCase() : extractUuidFromUrl(chunk && chunk.imageUrl ? chunk.imageUrl : '');
                        var prm = '';
                        if (chunk && chunk.imagePrompt && chunk.imagePrompt.prompt) {
                            prm = String(chunk.imagePrompt.prompt);
                        } else if (parsed && parsed.prompt) {
                            prm = String(parsed.prompt);
                        }
                        if (uid) {
                            addUnique(generatedOrderUuids, uid);
                            if (prm) uuidToPrompt[uid] = prm;
                        }
                    } else if (attType === 'render_imagine_media' || cardType === 'rendered_file_card') {
                        var rUrl = (parsed && (parsed.url || parsed.imageUrl)) || att.url || att.imageUrl || '';
                        var rUid = extractUuidFromUrl(rUrl) || (att.assetId ? String(att.assetId).toLowerCase() : '');
                        if (rUid) {
                            addUnique(renderedOrderUuids, rUid);
                        }
                    }
                }

                var jsonArr = Array.isArray(msg.cardAttachmentsJson) ? msg.cardAttachmentsJson : [];
                for (var jIdx = 0; jIdx < jsonArr.length; jIdx++) {
                    var jsStr = jsonArr[jIdx];
                    if (!jsStr || typeof jsStr !== 'string') continue;
                    try {
                        var jObj = JSON.parse(jsStr);
                        var jType = jObj.type || '';
                        var jCardType = jObj.cardType || '';
                        if (jType === 'imagine_text_to_image' || jCardType === 'generated_image_card') {
                            var jChunk = jObj.image_chunk;
                            var jUid = jChunk && jChunk.imageUuid ? String(jChunk.imageUuid).toLowerCase() : extractUuidFromUrl(jChunk && jChunk.imageUrl ? jChunk.imageUrl : '');
                            var jPrm = (jChunk && jChunk.imagePrompt && jChunk.imagePrompt.prompt) ? String(jChunk.imagePrompt.prompt) : '';
                            if (jUid) {
                                addUnique(generatedOrderUuids, jUid);
                                if (jPrm) uuidToPrompt[jUid] = jPrm;
                            }
                        } else if (jType === 'render_imagine_media' || jCardType === 'rendered_file_card') {
                            var jrUid = extractUuidFromUrl(jObj.url || jObj.imageUrl || '');
                            if (jrUid) addUnique(renderedOrderUuids, jrUid);
                        }
                    } catch (e2) {}
                }
            }
            node = node.return;
        }
    }

    var clickedAgentBtn = false;
    if (!foundMessageWithCards && Object.keys(uuidToPrompt).length === 0) {
        var agentBtn = document.querySelector('button[aria-label=""Conversa do agente""], button[aria-label=""Agent conversation""]');
        if (agentBtn) {
            agentBtn.click();
            clickedAgentBtn = true;
        }
    }

    return JSON.stringify({
        foundMessageWithCards: foundMessageWithCards,
        clickedAgentBtn: clickedAgentBtn,
        thumbUuids: thumbUuids,
        uuidToPrompt: uuidToPrompt,
        renderedOrderUuids: renderedOrderUuids,
        generatedOrderUuids: generatedOrderUuids
    });
})()";

        private async Task<GrokPostMetadata> ExtractGrokPostMetadataByUuidAsync(string sess, CancellationToken ct)
        {
            GrokPostMetadata meta = new GrokPostMetadata();
            try
            {
                for (int attempt = 0; attempt < 3; attempt++)
                {
                    ct.ThrowIfCancellationRequested();
                    Dictionary<string, object> raw = await _cdp.EvalJsonAsync(sess, JsExtractGrokPostMetadata, ct);
                    if (raw == null) break;

                    if (raw.ContainsKey("thumbUuids") && raw["thumbUuids"] is IEnumerable)
                    {
                        meta.ThumbUuids.Clear();
                        foreach (object o in (IEnumerable)raw["thumbUuids"])
                        {
                            string u = Convert.ToString(o ?? "").Trim().ToLowerInvariant();
                            if (!string.IsNullOrEmpty(u)) meta.ThumbUuids.Add(u);
                        }
                    }

                    if (raw.ContainsKey("uuidToPrompt") && raw["uuidToPrompt"] is Dictionary<string, object>)
                    {
                        Dictionary<string, object> dict = (Dictionary<string, object>)raw["uuidToPrompt"];
                        foreach (KeyValuePair<string, object> kv in dict)
                        {
                            string k = (kv.Key ?? "").Trim().ToLowerInvariant();
                            string v = Convert.ToString(kv.Value ?? "").Trim();
                            if (!string.IsNullOrEmpty(k) && !string.IsNullOrEmpty(v))
                                meta.UuidToPrompt[k] = v;
                        }
                    }

                    if (raw.ContainsKey("renderedOrderUuids") && raw["renderedOrderUuids"] is IEnumerable)
                    {
                        meta.RenderedOrderUuids.Clear();
                        foreach (object o in (IEnumerable)raw["renderedOrderUuids"])
                        {
                            string u = Convert.ToString(o ?? "").Trim().ToLowerInvariant();
                            if (!string.IsNullOrEmpty(u) && !meta.RenderedOrderUuids.Contains(u))
                                meta.RenderedOrderUuids.Add(u);
                        }
                    }

                    if (raw.ContainsKey("generatedOrderUuids") && raw["generatedOrderUuids"] is IEnumerable)
                    {
                        meta.GeneratedOrderUuids.Clear();
                        foreach (object o in (IEnumerable)raw["generatedOrderUuids"])
                        {
                            string u = Convert.ToString(o ?? "").Trim().ToLowerInvariant();
                            if (!string.IsNullOrEmpty(u) && !meta.GeneratedOrderUuids.Contains(u))
                                meta.GeneratedOrderUuids.Add(u);
                        }
                    }

                    if (meta.UuidToPrompt.Count > 0 || meta.RenderedOrderUuids.Count > 0)
                    {
                        _log(string.Format("[Grok Metadados] Extraídos {0} prompts internos (imagine_text_to_image) e {1} itens na ordem final do Agente (render_imagine_media).",
                            meta.UuidToPrompt.Count, meta.RenderedOrderUuids.Count));
                        break;
                    }

                    bool clicked = raw.ContainsKey("clickedAgentBtn") && Convert.ToBoolean(raw["clickedAgentBtn"]);
                    if (clicked || attempt == 0)
                    {
                        await Task.Delay(1200, ct);
                    }
                    else
                    {
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                _log("[Grok Metadados] Aviso ao inspecionar metadados React Fiber do post: " + ex.Message);
            }
            return meta;
        }

        private static string ExtractUuidFromGrokFileName(string filePath)
        {
            if (string.IsNullOrEmpty(filePath)) return "";
            string fn = Path.GetFileNameWithoutExtension(filePath);
            Match m = Regex.Match(fn, @"([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})");
            return m.Success ? m.Groups[1].Value.ToLowerInvariant() : "";
        }

        private static bool IsGrokPromptClearlyScenario(string promptNorm)
        {
            if (string.IsNullOrEmpty(promptNorm)) return false;
            return promptNorm.IndexOf("empty 3d environment") >= 0 ||
                   promptNorm.IndexOf("ambiente 3d vazio") >= 0 ||
                   promptNorm.IndexOf("no people no animals") >= 0 ||
                   promptNorm.IndexOf("sem pessoas sem animais") >= 0 ||
                   promptNorm.IndexOf("clean empty scene") >= 0 ||
                   promptNorm.IndexOf("no text or written signs") >= 0 ||
                   promptNorm.IndexOf("sem nenhum texto ou letreiro") >= 0;
        }

        private static bool IsGrokPromptClearlyCharacter(string promptNorm)
        {
            if (string.IsNullOrEmpty(promptNorm)) return false;
            return promptNorm.IndexOf("full body character portrait") >= 0 ||
                   promptNorm.IndexOf("pure white neutral empty background") >= 0 ||
                   promptNorm.IndexOf("fundo branco neutro puro") >= 0 ||
                   promptNorm.IndexOf("above his head") >= 0 ||
                   promptNorm.IndexOf("above her head") >= 0 ||
                   promptNorm.IndexOf("above its head") >= 0 ||
                   promptNorm.IndexOf("em cima da cabeca") >= 0 ||
                   promptNorm.IndexOf("standing full body centered") >= 0;
        }

        private static string StripGrokStyleBoilerplate(string normText)
        {
            if (string.IsNullOrEmpty(normText)) return "";
            string s = " " + normText + " ";
            string[] boilerplatePhrases = new string[]
            {
                "empty 3d environment with no people no animals and absolutely no text or written signs",
                "ambiente 3d vazio sem pessoas sem animais e sem nenhum texto ou letreiro escrito na imagem",
                "full body character portrait pure white neutral empty background",
                "uma imagem de corpo inteiro em estilo animacao 3d pixar disney cartoon vibrante",
                "em estilo animacao 3d pixar disney cartoon vibrante",
                "3d pixar disney cartoon animation style",
                "3d pixar cartoon animation style",
                "highly stylized 3d caricature of highest quality",
                "caricatura 3d cartoon estilizada de altissima qualidade",
                "vibrant saturated colors",
                "rich saturated colors",
                "cores ricas e saturadas",
                "cores vibrantes e saturadas",
                "dramatic high contrast lighting with intense warm golden and orange rim light",
                "iluminacao dramatica de alto contraste com luz de contorno quente dourada e alaranjada intensa",
                "soft skin with subsurface scattering",
                "pele macia com subsurface scattering",
                "large rounded super expressive 3d eyes",
                "large rounded expressive 3d eyes",
                "olhos grandes 3d arredondados e super expressivos",
                "zero photorealism",
                "zero fotorrealismo",
                "wide angle 9 16 view of",
                "visao grande angular em 9 16 de",
                "visao grande angular em 9 16 do",
                "visao grande angular em 9 16",
                "clean empty scene no characters",
                "sem texto na imagem proporcao 9 16",
                "fundo branco neutro puro proporcao 9 16",
                "standing full body centered",
                "in clear bold cartoon lettering the name",
                "9 16 vertical composition",
                "cinematic vibrant lighting contrasting",
                "cinematic high contrast lighting",
                "iluminacao cinematografica vibrante contrastando",
                "iluminacao cinematografica de alto contraste",
                "iluminacao de alto contraste",
                "iluminacao dramatica de alto contraste",
                "no interior do brasil",
                "in the brazilian countryside"
            };

            for (int i = 0; i < boilerplatePhrases.Length; i++)
            {
                s = s.Replace(boilerplatePhrases[i], " ");
            }
            return Regex.Replace(s, @"\s+", " ").Trim();
        }

        private static readonly string[][] GrokBilingualConceptGroups = new string[][]
        {
            // Rural & Roads & Hills
            new[] { "estrada", "estradinha", "road", "path", "caminho", "dirt road", "trail" },
            new[] { "ladeira", "subida", "ingreme", "steep", "hill road", "climbing", "encosta", "hillside", "topo do morro", "top of the hill" },
            new[] { "poeira", "dust", "dusty" },
            new[] { "mandioca", "cassava", "plantation", "lavoura", "plantacao" },
            new[] { "colina", "colinas", "hills", "sinuosa", "winding" },
            new[] { "flor", "flores", "floridas", "florido", "wildflowers", "flowers", "floral", "blooming" },
            new[] { "ipe", "yellow ipe", "ipe amarelo" },
            new[] { "grama", "capim", "grass", "golden grass", "gramado", "pasture", "pasto" },
            new[] { "cerca", "cercas", "mouroes", "fence", "fence posts", "wooden fence" },
            new[] { "porteira", "portao", "gate", "wooden gate", "half open", "entreaberta" },
            new[] { "cacto", "cactos", "cacti", "cactus", "sertao", "arid" },
            // Houses & Yards
            new[] { "taipa", "barro", "mud and clay", "adobe", "casinha", "casa de taipa", "taipa house" },
            new[] { "terreiro", "chao batido", "packed earth yard", "yard", "quintal", "backyard" },
            new[] { "telhado", "telhas", "colonial tile roof", "tile roof", "roof" },
            new[] { "varanda", "alpendre", "porch", "wooden porch", "veranda" },
            new[] { "janela", "janelas", "windows", "window", "azul turquesa", "turquoise blue", "lit windows", "janelas acesas" },
            // Forest, Wood, River & Bridge
            new[] { "mata", "floresta", "clareira", "eucalipto", "serra", "forest", "clearing", "mountain forest", "woods", "tree canopy", "copas das arvores" },
            new[] { "tora", "toras", "lenha", "recem cortadas", "empilhadas", "logs", "wooden logs", "stacked", "freshly cut" },
            new[] { "toco", "machado", "fincado", "stump", "tree stump", "axe", "stuck" },
            new[] { "pinguela", "ponte", "ponte pensil", "tabuas", "cordas", "footbridge", "hanging footbridge", "bridge", "plank", "rope", "precarious", "precaria" },
            new[] { "ribeirao", "rio", "riacho", "corredeira", "aguas agitadas", "stream", "agitated stream", "river", "creek", "water" },
            new[] { "pedra", "pedras", "rochas", "rocks", "stones", "boulders" },
            // Corral, Barn & Night Objects
            new[] { "curral", "estabulo", "celeiro", "corral", "barn", "stable", "paddock" },
            new[] { "cocho", "trough", "wooden trough", "empty wooden trough" },
            new[] { "buraco", "cova", "raso", "cavado", "hole", "shallow hole", "dug" },
            new[] { "lampiao", "lanterna", "querosene", "lantern", "kerosene lantern", "hanging lit lantern", "lantern post", "poste de lampiao" },
            // Weather & Sky & Time of Day
            new[] { "tempestade", "chuva", "gotas", "raios", "relampago", "trovao", "storm", "storm clouds", "rain", "raindrops", "lightning" },
            new[] { "noite", "noturno", "night", "night sky", "dark blue night" },
            new[] { "lua", "lua cheia", "luar", "moon", "full moon", "moonlight" },
            new[] { "crepusculo", "crepuscular", "por do sol", "entardecer", "twilight", "sunset", "dusk" },
            new[] { "tarde", "sol da tarde", "afternoon", "afternoon sun" },
            new[] { "sol forte", "strong sun", "sunbeams", "feixes de luz", "raios de sol", "sun rays" },
            // Urban & Interior Rooms (Novela / Terror)
            new[] { "cozinha", "fogao", "forno", "pia", "panela", "geladeira", "kitchen", "stove", "oven", "sink", "fridge" },
            new[] { "sala", "sofa", "poltrona", "televisao", "tapete", "living room", "couch", "armchair", "carpet", "rug" },
            new[] { "quarto", "cama", "travesseiro", "colchao", "guarda roupa", "beliche", "bedroom", "bed", "pillow", "mattress", "wardrobe", "bunk" },
            new[] { "banheiro", "chuveiro", "espelho", "bathroom", "shower", "mirror" },
            new[] { "escritorio", "construtora", "mesa executiva", "computador", "office", "desk", "executive", "computer", " skyscraper" },
            new[] { "hospital", "enfermaria", "maca", "leito", "uti", "clinica", "consultorio", "hospital room", "stretcher", "medical", "clinic" },
            new[] { "igreja", "altar", "capela", "bancos de madeira", "vitral", "church", "chapel", "pews", "stained glass" },
            new[] { "cemiterio", "tumulo", "lapide", "cova", "cemetery", "graveyard", "tombstone", "grave" },
            new[] { "restaurante", "lanchonete", "padaria", "balcao", "bar", "cafeteria", "restaurant", "diner", "bakery", "counter", "cafe" },
            new[] { "joalheria", "vitrine", "joias", "anel", "jewelry", "jewelry store", "showcase", "ring", "diamond" },
            new[] { "formatura", "auditorio", "palco", "baile", "salao de festas", "graduation", "auditorium", "stage", "ballroom", "party hall" },
            new[] { "obra", "canteiro de obras", "andaime", "cimento", "tijolos", "construction site", "scaffolding", "bricks", "cement" },
            new[] { "rua", "avenida", "calcada", "asfalto", "poste", "street", "sidewalk", "asphalt", "pavement", "alley", "beco" },
            new[] { "mansao", "luxuosa", "lustre", "marmore", "escadaria", "mansion", "luxury", "chandelier", "marble", "staircase" },
            new[] { "delegacia", "prisao", "cela", "grades", "police station", "jail", "prison", "cell", "bars" },
            new[] { "escola", "sala de aula", "lousa", "carteiras", "school", "classroom", "blackboard", "desks" },
            new[] { "feira", "mercado", "barraca", "caixotes", "frutas", "market", "stall", "crates", "fruits" },
            // Characters, Animals & Clothing
            new[] { "cavalo", "alazao", "crina", "cauda", "focinho", "cangalha", "cabresto", "patas", "horse", "farm horse", "bay coat", "mane", "tail", "muzzle", "halter", "packsaddle" },
            new[] { "cachorro", "cao", "vira lata", "focinheira", "coleira", "dog", "hound", "mutt", "puppy", "collar" },
            new[] { "boi", "vaca", "bezerr", "gado", "bull", "cow", "calf", "cattle", "ox" },
            new[] { "roceiro", "lavrador", "campones", "homem adulto", "adult man", "farmer", "peasant", "countryman" },
            new[] { "chapeu de palha", "straw hat", "wide brim straw hat" },
            new[] { "bigode", "barba", "mustache", "beard", "stubble" },
            new[] { "camisa", "amarela", "mostarda", "mustard yellow", "button shirt", "rolled sleeves" },
            new[] { "botina", "botinas", "bota", "boots", "work boots", "leather boots" },
            new[] { "esposa", "mulher adulta", "adult woman", "wife" },
            new[] { "tranca", "trancas", "braid", "braids", "two braids" },
            new[] { "vestido", "vestido florido", "floral dress", "dress" },
            new[] { "avental", "apron", "yellow apron" },
            new[] { "sandalia", "sandalias", "sandals", "leather sandals" },
            new[] { "filho", "menino", "garoto", "crianca", "7 anos", "boy", "farm boy", "child", "7 year old", "son" },
            new[] { "menina", "filha", "garota", "girl", "daughter" },
            new[] { "idoso", "idosa", "velho", "velha", "avo", "grisalho", "elderly", "old man", "old woman", "grandfather", "grandmother", "gray hair" },
            new[] { "sardas", "bochechas", "freckled", "freckles", "rosy cheeks" },
            new[] { "cacheado", "curly", "curly brown hair" },
            new[] { "macacao", "jeans", "overalls", "denim overalls" },
            new[] { "camiseta", "verde limao", "lime green", "t shirt" },
            new[] { "chinelo", "chinelos", "flip flops", "slippers" },
            new[] { "terno", "gravata", "smoking", "paleto", "suit", "tie", "tuxedo", "blazer" }
        };

        private static bool ContainsAnyTermInGroup(string normText, string[] group)
        {
            if (string.IsNullOrEmpty(normText) || group == null) return false;
            string padded = " " + normText + " ";
            for (int i = 0; i < group.Length; i++)
            {
                string term = group[i];
                if (string.IsNullOrEmpty(term)) continue;
                if (padded.IndexOf(" " + term + " ", StringComparison.Ordinal) >= 0 ||
                    (term.Length >= 5 && normText.IndexOf(term, StringComparison.Ordinal) >= 0))
                {
                    return true;
                }
            }
            return false;
        }

        private static double ComputeGrokSpecToImagePromptMatchScore(
            GrokAssetSpec spec,
            int specIndex,
            int totalSpecs,
            string imagePrompt,
            int renderedOrderIndex)
        {
            if (spec == null || string.IsNullOrWhiteSpace(imagePrompt))
                return 0.0;

            string promptNorm = EpisodeParser.NormalizeForCompare(imagePrompt);
            if (string.IsNullOrEmpty(promptNorm))
                return 0.0;

            bool isPromptScen = IsGrokPromptClearlyScenario(promptNorm);
            bool isPromptChar = IsGrokPromptClearlyCharacter(promptNorm);

            // Barreira estrita entre Personagem e Cenário
            if (spec.IsScenario && isPromptChar && !isPromptScen)
                return -1.0;
            if (!spec.IsScenario && isPromptScen && !isPromptChar)
                return -1.0;

            // 1. Verifica tag explícita [IMG_XX] ou nome do arquivo .jpg preservado no prompt
            string expectedTag1 = string.Format("img {0:00}", specIndex + 1);
            string expectedTag2 = string.Format("img {0}", specIndex + 1);
            Match mAnyTag = Regex.Match(imagePrompt, @"\[IMG_0*(\d+)\]", RegexOptions.IgnoreCase);
            if (mAnyTag.Success)
            {
                int taggedNum;
                if (int.TryParse(mAnyTag.Groups[1].Value, out taggedNum))
                {
                    return taggedNum == (specIndex + 1) ? 1.0 : 0.0;
                }
            }

            string targetStemNorm = EpisodeParser.NormalizeForCompare(Path.GetFileNameWithoutExtension(spec.TargetFileName ?? ""));
            if (!string.IsNullOrEmpty(targetStemNorm) && targetStemNorm.Length >= 6 && promptNorm.IndexOf(targetStemNorm, StringComparison.Ordinal) >= 0)
            {
                return 0.99;
            }

            // 2. Verifica se o DisplayTitle aparece literalmente entre aspas ou no prompt (ex: Above his head ... "O Roceiro")
            string titleNorm = EpisodeParser.NormalizeForCompare(spec.DisplayTitle ?? "");
            string titleNoArticle = Regex.Replace(titleNorm, @"^(o|a|os|as|um|uma)\s+", "").Trim();

            double directTitleScore = 0.0;
            if (!string.IsNullOrEmpty(titleNorm) && titleNorm.Length >= 3)
            {
                if ((" " + promptNorm + " ").IndexOf(" " + titleNorm + " ", StringComparison.Ordinal) >= 0)
                {
                    directTitleScore = 0.88;
                }
                else if (!string.IsNullOrEmpty(titleNoArticle) && titleNoArticle.Length >= 4 &&
                         (" " + promptNorm + " ").IndexOf(" " + titleNoArticle + " ", StringComparison.Ordinal) >= 0)
                {
                    directTitleScore = 0.80;
                }
            }

            // 3. Similaridade semântica bilíngue (PT <-> EN) + tokens específicos sem o boilerplate de estilo
            string specRawNorm = EpisodeParser.NormalizeForCompare((spec.DisplayTitle ?? "") + " " + (spec.RawPromptLine ?? ""));
            string cleanSpec = StripGrokStyleBoilerplate(specRawNorm);
            string cleanPrompt = StripGrokStyleBoilerplate(promptNorm);

            int titleHits = 0;
            int titleTotal = 0;
            int bodyHits = 0;
            int bodyTotal = 0;
            int mismatchPenalties = 0;

            for (int g = 0; g < GrokBilingualConceptGroups.Length; g++)
            {
                string[] grp = GrokBilingualConceptGroups[g];
                bool inTitle = ContainsAnyTermInGroup(titleNorm, grp);
                bool inSpec = inTitle || ContainsAnyTermInGroup(cleanSpec, grp);
                bool inPrompt = ContainsAnyTermInGroup(cleanPrompt, grp);

                if (inTitle)
                {
                    titleTotal++;
                    if (inPrompt) titleHits++;
                }
                if (inSpec)
                {
                    bodyTotal++;
                    if (inPrompt) bodyHits++;
                }
                else if (inPrompt)
                {
                    mismatchPenalties++;
                }
            }

            double conceptScore = 0.0;
            if (bodyTotal > 0 || titleTotal > 0)
            {
                double weightedHits = (titleHits * 2.2) + (bodyHits * 1.0);
                double weightedTotal = (titleTotal * 2.2) + (bodyTotal * 1.0);
                conceptScore = weightedHits / Math.Max(1.0, weightedTotal + (mismatchPenalties * 0.35));
            }

            // Similaridade léxica direta nos tokens limpos (caso o Grok tenha mantido palavras em português ou cognatos)
            double lexicalScore = EpisodeParser.ComputeTextSimilarity(cleanSpec, cleanPrompt);

            double combined = Math.Max(directTitleScore, (conceptScore * 0.78) + (lexicalScore * 0.22));
            if (directTitleScore > 0 && conceptScore > 0)
            {
                combined = Math.Min(0.99, directTitleScore + (conceptScore * 0.12));
            }

            // 4. Bônus de corroboração quando a posição em render_imagine_media (lista numerada final do Agente) coincide com specIndex
            if (renderedOrderIndex >= 0 && renderedOrderIndex == specIndex)
            {
                combined = Math.Min(0.99, combined + 0.12);
            }

            return combined;
        }

        private void MatchAndRenameGrokDownloadsWithOcr(
            string stagingDir,
            List<string> orderedDownloads,
            List<GrokAssetSpec> specs,
            string targetAssetsDir,
            GrokPostMetadata postMeta = null)
        {
            _log("[Grok Casamento] Cruzando prompts internos do Grok (por UUID), lista final do Agente e Windows OCR (pt-BR) para garantir 100% de precisão em Personagens e Cenários...");
            Dictionary<string, string> ocrResults = RunWindowsOcrOnFolder(stagingDir);

            if (postMeta == null)
                postMeta = new GrokPostMetadata();

            // Mapear cada arquivo baixado -> seu imageUuid, seu prompt interno no Grok e sua posição na lista render_imagine_media
            Dictionary<string, string> fileToUuid = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            Dictionary<string, string> fileToPrompt = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            Dictionary<string, int> fileToRenderedOrder = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);

            for (int i = 0; i < orderedDownloads.Count; i++)
            {
                string file = orderedDownloads[i];
                string uuid = ExtractUuidFromGrokFileName(file);
                if (string.IsNullOrEmpty(uuid) && i < postMeta.ThumbUuids.Count)
                {
                    uuid = postMeta.ThumbUuids[i];
                }

                if (!string.IsNullOrEmpty(uuid))
                {
                    fileToUuid[file] = uuid;
                    if (postMeta.UuidToPrompt.ContainsKey(uuid))
                    {
                        fileToPrompt[file] = postMeta.UuidToPrompt[uuid];
                    }
                    int rIdx = postMeta.RenderedOrderUuids.IndexOf(uuid);
                    if (rIdx >= 0)
                    {
                        fileToRenderedOrder[file] = rIdx;
                    }
                }
            }

            HashSet<int> usedSpecIndices = new HashSet<int>();
            HashSet<string> assignedFiles = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            // FASE 1: Casamento global por maior pontuação combinada (Prompt Interno do Grok + Conceitos Bilíngues PT/EN + OCR de Topo para Personagens)
            var candidatePairs = new List<Tuple<string, int, double, string>>();
            for (int fIdx = 0; fIdx < orderedDownloads.Count; fIdx++)
            {
                string file = orderedDownloads[fIdx];
                string ocrText = ocrResults.ContainsKey(file) ? (ocrResults[file] ?? "").Trim() : "";
                string imgPrompt = fileToPrompt.ContainsKey(file) ? (fileToPrompt[file] ?? "").Trim() : "";
                int renderedIdx = fileToRenderedOrder.ContainsKey(file) ? fileToRenderedOrder[file] : -1;

                string promptNorm = EpisodeParser.NormalizeForCompare(imgPrompt);
                bool fileClearlyScenario = IsGrokPromptClearlyScenario(promptNorm);
                bool fileClearlyCharacter = IsGrokPromptClearlyCharacter(promptNorm);

                for (int sIdx = 0; sIdx < specs.Count; sIdx++)
                {
                    GrokAssetSpec spec = specs[sIdx];

                    // Barreira estrita entre Personagem e Cenário
                    if (spec.IsScenario && fileClearlyCharacter && !fileClearlyScenario)
                        continue;
                    if (!spec.IsScenario && fileClearlyScenario && !fileClearlyCharacter)
                        continue;

                    double promptScore = !string.IsNullOrEmpty(imgPrompt)
                        ? ComputeGrokSpecToImagePromptMatchScore(spec, sIdx, specs.Count, imgPrompt, renderedIdx)
                        : 0.0;
                    if (promptScore < 0.0)
                        continue;

                    // OCR do topo vale APENAS para Personagens (!spec.IsScenario), pois Cenários não têm título no topo
                    double ocrScore = 0.0;
                    if (!spec.IsScenario && !fileClearlyScenario && !string.IsNullOrWhiteSpace(ocrText))
                    {
                        ocrScore = EpisodeParser.ComputeTextSimilarity(ocrText, spec.DisplayTitle);
                    }

                    double finalScore = 0.0;
                    string reason = "";

                    if (!spec.IsScenario)
                    {
                        if (promptScore >= 0.50 && ocrScore >= 0.45)
                        {
                            finalScore = Math.Max(promptScore, ocrScore) + 0.08;
                            reason = string.Format("Prompt+OCR: \"{0}\"", ocrText);
                        }
                        else if (promptScore >= ocrScore && promptScore >= 0.35)
                        {
                            finalScore = promptScore;
                            reason = "Prompt UUID Personagem";
                        }
                        else if (ocrScore >= 0.48)
                        {
                            finalScore = ocrScore;
                            reason = string.Format("OCR: \"{0}\"", ocrText);
                        }
                    }
                    else
                    {
                        if (promptScore >= 0.28)
                        {
                            finalScore = promptScore;
                            reason = "Prompt UUID Cenário";
                        }
                    }

                    if (finalScore >= 0.28)
                    {
                        candidatePairs.Add(Tuple.Create(file, sIdx, Math.Min(1.0, finalScore), reason));
                    }
                }
            }

            foreach (var pair in candidatePairs.OrderByDescending(p => p.Item3))
            {
                if (assignedFiles.Contains(pair.Item1) || usedSpecIndices.Contains(pair.Item2))
                    continue;

                GrokAssetSpec spec = specs[pair.Item2];
                string destPath = Path.Combine(targetAssetsDir, spec.TargetFileName);
                File.Copy(pair.Item1, destPath, true);
                assignedFiles.Add(pair.Item1);
                usedSpecIndices.Add(pair.Item2);

                _log(string.Format("[Grok Match] '{0}' ({1}) -> {2} (confiança {3:0}%)",
                    Path.GetFileName(pair.Item1), pair.Item4, spec.TargetFileName, pair.Item3 * 100.0));
            }

            // FASE 2: Para itens ainda não atribuídos, usar a ordem da lista final numerada do Agente (render_imagine_media), e NÃO a ordem assíncrona das miniaturas
            if (assignedFiles.Count < orderedDownloads.Count && usedSpecIndices.Count < specs.Count && postMeta.RenderedOrderUuids.Count > 0)
            {
                List<string> unassignedByAgentOrder = orderedDownloads
                    .Where(f => !assignedFiles.Contains(f))
                    .OrderBy(f => fileToRenderedOrder.ContainsKey(f) ? fileToRenderedOrder[f] : 9999)
                    .ToList();

                // 2A. Se o índice exato na lista do Agente estiver livre e for da mesma categoria (Personagem vs Cenário)
                foreach (string file in unassignedByAgentOrder.ToList())
                {
                    if (!fileToRenderedOrder.ContainsKey(file)) continue;
                    int rIdx = fileToRenderedOrder[file];
                    if (rIdx >= 0 && rIdx < specs.Count && !usedSpecIndices.Contains(rIdx))
                    {
                        GrokAssetSpec spec = specs[rIdx];
                        string pNorm = fileToPrompt.ContainsKey(file) ? EpisodeParser.NormalizeForCompare(fileToPrompt[file]) : "";
                        if (spec.IsScenario && IsGrokPromptClearlyCharacter(pNorm) && !IsGrokPromptClearlyScenario(pNorm))
                            continue;
                        if (!spec.IsScenario && IsGrokPromptClearlyScenario(pNorm) && !IsGrokPromptClearlyCharacter(pNorm))
                            continue;

                        string destPath = Path.Combine(targetAssetsDir, spec.TargetFileName);
                        File.Copy(file, destPath, true);
                        assignedFiles.Add(file);
                        usedSpecIndices.Add(rIdx);
                        _log(string.Format("[Grok Agente Ordem] '{0}' (item #{1} da resposta do Agente) -> {2}",
                            Path.GetFileName(file), rIdx + 1, spec.TargetFileName));
                    }
                }

                // 2B. Alinhar restantes na ordem relativa da resposta do Agente respeitando categoria
                List<string> remFilesAgent = orderedDownloads
                    .Where(f => !assignedFiles.Contains(f))
                    .OrderBy(f => fileToRenderedOrder.ContainsKey(f) ? fileToRenderedOrder[f] : 9999)
                    .ToList();
                List<int> remSpecsAgent = Enumerable.Range(0, specs.Count)
                    .Where(i => !usedSpecIndices.Contains(i))
                    .ToList();

                int countAgent = Math.Min(remFilesAgent.Count, remSpecsAgent.Count);
                for (int i = 0; i < countAgent; i++)
                {
                    string file = remFilesAgent[i];
                    GrokAssetSpec spec = specs[remSpecsAgent[i]];
                    string destPath = Path.Combine(targetAssetsDir, spec.TargetFileName);
                    File.Copy(file, destPath, true);
                    assignedFiles.Add(file);
                    usedSpecIndices.Add(remSpecsAgent[i]);
                    _log(string.Format("[Grok Agente Sequência] '{0}' -> {1}",
                        Path.GetFileName(file), spec.TargetFileName));
                }
            }

            // FASE 3: Fallback final para qualquer imagem restante
            List<string> remainingFiles = orderedDownloads.Where(f => !assignedFiles.Contains(f)).ToList();
            List<int> remainingSpecs = Enumerable.Range(0, specs.Count).Where(i => !usedSpecIndices.Contains(i)).ToList();

            int count = Math.Min(remainingFiles.Count, remainingSpecs.Count);
            for (int i = 0; i < count; i++)
            {
                GrokAssetSpec spec = specs[remainingSpecs[i]];
                string destPath = Path.Combine(targetAssetsDir, spec.TargetFileName);
                File.Copy(remainingFiles[i], destPath, true);
                _log(string.Format("[Grok Ordem] '{0}' -> {1} (fallback residual)",
                    Path.GetFileName(remainingFiles[i]), spec.TargetFileName));
            }
        }

    }
}
