using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace FluxoVideoStudio
{
    public partial class FlowAutomation
    {
        private class SessionCompletedImageInfo
        {
            public int ChronologicalOrder;
            public string CardKey;
            public string AsbId;
            public string ImageUrl;
            public string AltPrompt;
        }

        private class ImageSpecMatchCandidate
        {
            public int SpecIndex;
            public int CardIndex;
            public string CardKey;
            public double Score;
        }

        private static string ComputeBytesMd5Hex(byte[] data)
        {
            if (data == null || data.Length == 0) return "";
            using (var md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] hash = md5.ComputeHash(data);
                StringBuilder sb = new StringBuilder(hash.Length * 2);
                for (int i = 0; i < hash.Length; i++)
                    sb.Append(hash[i].ToString("X2"));
                return sb.ToString();
            }
        }

        private static int TryExtractExplicitImageTagIndex(string promptText, int maxCount)
        {
            if (string.IsNullOrWhiteSpace(promptText) || maxCount <= 0)
                return 0;

            MatchCollection mc = Regex.Matches(
                promptText,
                @"\[\s*IMG(?:[_\-\s]*ID)?[_\-\s]*0*(\d{1,3})\s*\]",
                RegexOptions.IgnoreCase);

            if (mc.Count == 1)
            {
                int idx;
                if (int.TryParse(mc[0].Groups[1].Value, out idx) && idx >= 1 && idx <= maxCount)
                    return idx;
            }
            else if (mc.Count > 1)
            {
                // Se a tag estiver logo nos primeiros 40 caracteres do prompt individual da imagem
                Match first = mc[0];
                if (first.Index <= 40)
                {
                    int idx;
                    if (int.TryParse(first.Groups[1].Value, out idx) && idx >= 1 && idx <= maxCount)
                        return idx;
                }
            }
            return 0;
        }

        private static string ExtractDistinctiveImageSpecBody(string rawText)
        {
            if (string.IsNullOrWhiteSpace(rawText))
                return "";

            string s = rawText;
            s = Regex.Replace(s, @"\[\s*IMG[_\-\s]*\d+\s*\]", " ", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"\b\d{2}_(?:Personagem|Cenario)_[A-Za-z0-9_]+\.jpg\b", " ", RegexOptions.IgnoreCase);

            // Remove parênteses de boilerplate de estilo 3D Pixar / CGI para comparar apenas os detalhes únicos de cada personagem/cenário
            s = Regex.Replace(s, @"\(\s*3D\s+Pixar[^)]*\)", " ", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"\(\s*sem\s+pessoas\s+e\s+sem\s+nenhum\s+texto[^)]*\)", " ", RegexOptions.IgnoreCase);

            string norm = EpisodeParser.NormalizeForCompare(s);
            if (string.IsNullOrEmpty(norm))
                return "";

            string[] boilerplatePhrases = new string[]
            {
                "uma imagem de corpo inteiro em estilo animacao 3d pixar disney cartoon vibrante",
                "ambiente 3d vazio em estilo animacao 3d pixar disney cartoon vibrante",
                "visao grande angular em 9 16 de",
                "com estrutura ossea facial adulta bem definida",
                "proporcoes corporais de mulher adulta completa",
                "proporcoes de mulher adulta completa",
                "ombros largos e estatura de homem adulto completo",
                "linhas de expressao adultas naturais",
                "sem rosto ou aparencia de crianca",
                "olhos grandes 3d arredondados e super expressivos",
                "olhos grandes castanhos",
                "iluminacao cinematografica vibrante",
                "iluminacao cinematografica de alto contraste",
                "fundo branco neutro puro proporcao 9 16",
                "sem texto na imagem proporcao 9 16",
                "em cima da cabeca",
                "escrito"
            };

            for (int i = 0; i < boilerplatePhrases.Length; i++)
            {
                norm = norm.Replace(boilerplatePhrases[i], " ");
            }

            norm = Regex.Replace(norm, @"\s+", " ").Trim();
            return norm;
        }

        private static bool PromptLooksLikeCharacterOnly(string normPrompt)
        {
            if (string.IsNullOrEmpty(normPrompt)) return false;
            bool hasChar = Regex.IsMatch(normPrompt, @"\b(corpo inteiro|fundo branco neutro puro|em cima da cabeca|full body|full length|pure white background|neutral white background|white background)\b");
            bool hasScen = Regex.IsMatch(normPrompt, @"\b(ambiente 3d vazio|sem pessoas|no people|without people|empty 3d|empty room|interior view)\b");
            return hasChar && !hasScen;
        }

        private static bool PromptLooksLikeScenarioOnly(string normPrompt)
        {
            if (string.IsNullOrEmpty(normPrompt)) return false;
            bool hasScen = Regex.IsMatch(normPrompt, @"\b(ambiente 3d vazio|sem pessoas|cenario|sala de estar|quarto antigo|sala de jantar|cozinha simples|quartinho da lavanderia|escritorio montado|empty 3d|no people|without people|living room|bedroom|dining room|kitchen|laundry room|utility room|home office)\b");
            bool hasChar = Regex.IsMatch(normPrompt, @"\b(corpo inteiro|fundo branco neutro puro|em cima da cabeca|full body|pure white background|neutral white background|white background)\b");
            return hasScen && !hasChar;
        }

        private static double ComputeBilingualConceptOverlapBonus(string normSpecRaw, string normPrompt)
        {
            if (string.IsNullOrEmpty(normSpecRaw) || string.IsNullOrEmpty(normPrompt))
                return 0.0;

            string[][] conceptGroups = new string[][]
            {
                new string[] { "quarto antigo", "croche", "novelos", "colcha de retalhos", "old bedroom", "crochet", "yarn", "wool", "patchwork quilt", "knitting" },
                new string[] { "sala de jantar", "girassois", "toalha de renda", "cristaleira", "dining room", "sunflowers", "sunflower", "lace tablecloth", "china cabinet" },
                new string[] { "cozinha simples", "fogao", "geladeira", "laranjas", "kitchen", "stove", "refrigerator", "fridge", "oranges" },
                new string[] { "quartinho da lavanderia", "lavanderia", "maquinas de lavar", "tanque de cimento", "laundry", "washing machine", "washing machines", "utility room", "detergent" },
                new string[] { "escritorio montado", "escrivaninha", "monitores", "computador", "cadeira giratoria", "office", "desk", "monitors", "dual monitor", "computer", "swivel chair" },
                new string[] { "sala de estar", "sofa", "porta retrato", "living room", "couch", "photo frame" },
                new string[] { "mae aposentada", "idosa", "cabelos brancos", "coque", "cardiga", "elderly woman", "retired mother", "white hair", "bun", "cardigan", "grandmother" },
                new string[] { "mulher vaidosa", "vestido vermelho", "vinho", "salto alto", "vain woman", "burgundy dress", "wine dress", "red dress", "high heels", "wavy hair" },
                new string[] { "mecanico", "macacao", "graxa", "mechanic", "overalls", "jumpsuit", "grease" },
                new string[] { "diarista", "avental", "uniforme", "maid", "housekeeper", "apron", "cleaning" }
            };

            int matchedGroups = 0;
            int specGroups = 0;
            for (int g = 0; g < conceptGroups.Length; g++)
            {
                string[] terms = conceptGroups[g];
                bool inSpec = false;
                bool inPrompt = false;
                for (int t = 0; t < terms.Length; t++)
                {
                    if (!inSpec && normSpecRaw.IndexOf(terms[t], StringComparison.Ordinal) >= 0)
                        inSpec = true;
                    if (!inPrompt && normPrompt.IndexOf(terms[t], StringComparison.Ordinal) >= 0)
                        inPrompt = true;
                }
                if (inSpec)
                {
                    specGroups++;
                    if (inPrompt)
                        matchedGroups++;
                }
            }

            if (specGroups == 0 || matchedGroups == 0)
                return 0.0;

            return Math.Min(0.55, matchedGroups * 0.36);
        }

        private static double ComputeImageSpecToPromptMatchScore(
            GrokAssetSpec spec,
            int specIndexOneBased,
            int totalSpecsInBatch,
            string candidatePrompt)
        {
            if (spec == null || string.IsNullOrWhiteSpace(candidatePrompt))
                return 0.0;

            int explicitIdx = TryExtractExplicitImageTagIndex(candidatePrompt, totalSpecsInBatch);
            if (explicitIdx > 0)
            {
                return explicitIdx == specIndexOneBased ? 1.0 : 0.02;
            }

            string normPrompt = EpisodeParser.NormalizeForCompare(candidatePrompt);
            if (string.IsNullOrEmpty(normPrompt))
                return 0.0;

            string fileStem = Path.GetFileNameWithoutExtension(spec.TargetFileName ?? "");
            string normStem = EpisodeParser.NormalizeForCompare(fileStem.Replace('_', ' '));
            if (!string.IsNullOrEmpty(fileStem) &&
                candidatePrompt.IndexOf(fileStem, StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return 0.98;
            }

            // Barreira estrita entre Personagem e Cenário (impede que cenário ocupe vaga de personagem e vice-versa!)
            bool promptLooksScenario = PromptLooksLikeScenarioOnly(normPrompt);
            bool promptLooksCharacter = PromptLooksLikeCharacterOnly(normPrompt);

            if (spec.IsScenario && promptLooksCharacter)
                return 0.0;
            if (!spec.IsScenario && promptLooksScenario)
                return 0.0;

            // Extrai o nome próprio do personagem/cenário (ex.: "A Mãe Aposentada", "O Mecânico Com Flores", "Quarto Antigo da Mãe")
            string cleanTitle = Regex.Replace(spec.DisplayTitle ?? "", @"^(Personagem\s*\d+|Cen[aá]rio\s*[A-Z0-9]+)\s*:\s*", "", RegexOptions.IgnoreCase).Trim();
            cleanTitle = Regex.Replace(cleanTitle, @"^em\s+cima\s+da\s+cabe[cç]a\s+", "", RegexOptions.IgnoreCase).Trim();
            string normTitle = EpisodeParser.NormalizeForCompare(cleanTitle);

            double titleBonus = 0.0;
            if (!string.IsNullOrEmpty(normTitle) && normTitle.Length >= 4)
            {
                if (Regex.IsMatch(normPrompt, @"\b" + Regex.Escape(normTitle) + @"\b"))
                {
                    titleBonus = 0.48;
                }
            }

            // Desambiguação entre variantes do mesmo personagem (ex.: "O Mecânico Com Flores" vs "O Mecânico" de mãos vazias)
            string normSpecRaw = EpisodeParser.NormalizeForCompare(spec.RawPromptLine ?? "");
            bool specHasFlowers = Regex.IsMatch(normSpecRaw, @"\b(flores|buque|rosas|ursinho)\b");
            bool promptHasFlowers = Regex.IsMatch(normPrompt, @"\b(flores|buque|rosas|ursinho|bouquet|flowers|roses|teddy)\b");
            bool specHandsEmpty = Regex.IsMatch(normSpecRaw, @"\b(maos livres|maos vazias)\b");
            bool promptHandsEmpty = Regex.IsMatch(normPrompt, @"\b(maos livres|maos vazias|empty hands|free hands)\b");

            if (specHasFlowers != promptHasFlowers && (!spec.IsScenario))
                titleBonus -= 0.42;
            if (specHandsEmpty && promptHandsEmpty)
                titleBonus += 0.25;

            double bilingualBonus = ComputeBilingualConceptOverlapBonus(normSpecRaw, normPrompt);

            string distinctWant = ExtractDistinctiveImageSpecBody(spec.RawPromptLine ?? "");
            string distinctGot = ExtractDistinctiveImageSpecBody(candidatePrompt);
            double bodySim = ComputeContentWordBigramSimilarity(distinctWant, distinctGot);

            double total = (bodySim * 0.65) + titleBonus + bilingualBonus;
            if (!string.IsNullOrEmpty(normStem) && normPrompt.IndexOf(normStem, StringComparison.Ordinal) >= 0)
                total += 0.35;

            return Math.Max(0.0, Math.Min(0.99, total));
        }

        private string BuildUnifiedFlowImagesCommand(
            List<GrokAssetSpec> specs,
            Dictionary<string, string> specToBaseRefName,
            bool soften)
        {
            if (specs == null || specs.Count == 0)
                return "";

            StringBuilder sb = new StringBuilder();
            sb.AppendLine("[INSTRUÇÃO OBRIGATÓRIA DE GERAÇÃO DE IMAGENS 9:16]:");
            sb.AppendLine("Faça cada imagem isolada da lista abaixo em proporção vertical 9:16 (retrato vertical 9:16 — NÃO gere vídeo, gere SOMENTE IMAGENS estáticas).");
            sb.AppendLine("REGRA FACIAL PARA PERSONAGENS ADULTOS: Todos os personagens adultos devem apresentar fisionomia claramente madura (faixa etária 35 a 45+ anos; idosos 60+), rosto alongado, oval-anguloso ou quadrado-esculpido (evite rosto redondo/circular, bochechas cheias ou olhos gigantes arredondados), mandíbula firme, maçãs do rosto altas e marcadas e linhas de expressão adultas nítidas.");
            sb.AppendLine("Ao enviar o prompt de cada imagem para a ferramenta de geração (tanto neste lote inicial quanto nos próximos lotes após \"continue\"), mantenha OBRIGATORIAMENTE e literalmente a tag exata [IMG_01], [IMG_02], [IMG_03], etc. e o nome do arquivo (.jpg) no início do prompt de cada imagem gerada. A tag [IMG_XX] é apenas controle interno de identificação — NÃO escreva a tag \"[IMG_XX]\" nem o nome do arquivo \".jpg\" dentro da arte da imagem:");
            sb.AppendLine();

            for (int i = 0; i < specs.Count; i++)
            {
                GrokAssetSpec spec = specs[i];
                string rawPrompt = SanitizePromptForFlowPolicy((spec.RawPromptLine ?? "").Trim(), soften);

                // Garante que cada linha peça explicitamente proporção 9:16
                if (rawPrompt.IndexOf("9:16", StringComparison.OrdinalIgnoreCase) < 0)
                {
                    rawPrompt = rawPrompt.TrimEnd('.') + ", proporção vertical 9:16.";
                }

                string baseRefName;
                if (specToBaseRefName != null &&
                    specToBaseRefName.TryGetValue(spec.TargetFileName, out baseRefName) &&
                    !string.IsNullOrEmpty(baseRefName))
                {
                    sb.AppendFormat(
                        "[IMG_{0:00}] ({1}) [Use a imagem anexada '{2}' como referência obrigatória de identidade para manter EXATAMENTE o mesmo rosto, idade e estrutura corporal, trocando apenas a roupa/figurino] - {3}",
                        i + 1,
                        spec.TargetFileName,
                        baseRefName,
                        rawPrompt);
                }
                else
                {
                    sb.AppendFormat("[IMG_{0:00}] ({1}) - {2}", i + 1, spec.TargetFileName, rawPrompt);
                }
                sb.AppendLine();
                sb.AppendLine();
            }

            return sb.ToString().Trim();
        }

        private string BuildSingleVariantFlowImageCommand(
            GrokAssetSpec varSpec,
            string baseRefName,
            bool soften)
        {
            string charTitle = !string.IsNullOrEmpty(varSpec.DisplayTitle)
                ? varSpec.DisplayTitle
                : EpisodeParser.CleanAssetStem(varSpec.TargetFileName);
            charTitle = Regex.Replace(charTitle, @"^(Personagem\s*\d+[A-Za-z]?)\s*:\s*", "", RegexOptions.IgnoreCase).Trim();
            charTitle = Regex.Replace(charTitle, @"^em\s+cima\s+da\s+cabe[cç]a\s+", "", RegexOptions.IgnoreCase).Trim();

            string rawPrompt = (varSpec.RawPromptLine ?? "").Trim();
            if (soften)
            {
                rawPrompt = SoftenPromptForSecondAttempt(rawPrompt);
            }
            if (rawPrompt.IndexOf("9:16", StringComparison.OrdinalIgnoreCase) < 0)
            {
                rawPrompt = rawPrompt.TrimEnd('.') + ", proporção vertical 9:16.";
            }

            return string.Format(
                "Gere SOMENTE 1 IMAGEM estática vertical em proporção 9:16 (NÃO gere vídeo) usando OBRIGATORIAMENTE a imagem anexada ({0}) como referência do personagem anterior para manter 100% TODAS as características físicas e visuais do original (exatamente o mesmo rosto, mesma estrutura óssea facial, mesmos olhos, mesmo tom de pele, mesma idade, mesma fisionomia, mesmas proporções corporais de corpo inteiro dos pés à cabeça e exatamente o mesmo estilo de animação 3D da imagem anexada), aplicando apenas as mudanças desta nova versão do personagem sobre FUNDO BRANCO NEUTRO PURO (#FFFFFF) com \"{1}\" escrito no topo acima da cabeça. Mantenha a tag [IMG_01] ({2}) no início do prompt interno da imagem (sem escrever \"[IMG_01]\" nem \".jpg\" na arte):\n\n[IMG_01] ({2}) - {3}",
                baseRefName,
                charTitle,
                varSpec.TargetFileName,
                rawPrompt);
        }

        private async Task<bool> GenerateSingleVariantAssetInFlowAsync(
            string sess,
            EpisodeWorkItem ep,
            GrokAssetSpec varSpec,
            string baseRefPath,
            HashSet<string> usedCardKeys,
            HashSet<string> savedMd5Hashes,
            string stagingDl,
            CancellationToken ct)
        {
            if (ep == null || varSpec == null || string.IsNullOrEmpty(baseRefPath) || !File.Exists(baseRefPath))
                return false;

            string dstPath = Path.Combine(ep.AssetsDir, varSpec.TargetFileName);
            if (File.Exists(dstPath) && new FileInfo(dstPath).Length >= 1024)
                return true;

            string baseRefName = Path.GetFileName(baseRefPath);
            string tempBaseRefPath = Path.Combine(_config.TempFlowAssetsDir, baseRefName);
            try
            {
                File.Copy(baseRefPath, tempBaseRefPath, true);
                byte[] refBytes = File.ReadAllBytes(baseRefPath);
                string refMd5 = ComputeBytesMd5Hex(refBytes);
                if (!string.IsNullOrEmpty(refMd5) && savedMd5Hashes != null)
                    savedMd5Hashes.Add(refMd5);
            }
            catch { }

            for (int attempt = 1; attempt <= 2; attempt++)
            {
                ct.ThrowIfCancellationRequested();
                bool soften = (attempt == 2);

                await EnsureAgentPanelOpenAsync(sess, ct);
                PreSessionGridBaseline preUnlockBase = await CapturePreSessionBaselineAsync(sess, ct);
                await WaitForAgentInputUnlockedAsync(sess, preUnlockBase, ct);

                await ClearAttachedPromptChipsAsync(sess, ct);
                string curTxt = await ReadCurrentFlowTextboxAsync(sess, ct);
                if (!string.IsNullOrWhiteSpace(curTxt))
                {
                    await InsertTextIntoFlowTextboxAsync(sess, "", true, ct);
                    await Task.Delay(350, ct);
                }

                List<string> singleRefList = new List<string> { baseRefName };
                HashSet<string> attachedTmp = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                await AttachIngredientsViaMenuAsync(sess, singleRefList, attachedTmp, ct);
                if (attachedTmp.Count == 0 && File.Exists(tempBaseRefPath))
                {
                    _log(string.Format("[Google Flow | Continuidade de Personagem] Enviando imagem anterior '{0}' para a biblioteca do projeto Flow e anexando...", baseRefName));
                    await UploadAssetsToFlowProjectAsync(sess, new List<string> { tempBaseRefPath }, ct);
                    await AttachIngredientsViaMenuAsync(sess, singleRefList, attachedTmp, ct);
                }
                await WaitForAttachedPromptChipsImagesLoadedAsync(sess, ct);

                // Captura o baseline DEPOIS de subir e anexar a imagem de referência para nunca confundir o card de upload com a imagem gerada!
                PreSessionGridBaseline singleBaseline = await CapturePreSessionBaselineAsync(sess, ct);
                string singleCmd = BuildSingleVariantFlowImageCommand(varSpec, baseRefName, soften);

                _log(string.Format("[Google Flow | Continuidade de Personagem] Imagem anterior '{0}' anexada -> gerando nova versão '{1}' ({2})...",
                    baseRefName, varSpec.TargetFileName, soften ? "2ª tentativa suavizada" : "1ª tentativa"));

                await InsertTextIntoFlowTextboxAsync(sess, singleCmd, false, ct);
                await WaitRandomFlowActionDelayAsync(string.Format("após colar nova versão '{0}'", varSpec.TargetFileName), ct);

                LastActionHistoryStore.RecordAction(
                    ep,
                    "Google Flow",
                    string.Format("Gerando nova versão de personagem '{0}' anexando '{1}' ({2})",
                        varSpec.TargetFileName, baseRefName, soften ? "2ª tentativa suavizada" : "1ª tentativa"),
                    _config.FlowProfile,
                    sess,
                    _config.FlowProjectUrl,
                    varSpec.TargetFileName,
                    0,
                    attempt,
                    singleCmd,
                    singleRefList,
                    "SUBMITTED");

                await ClickStartGenerationAsync(sess, ct);

                SessionPollSnapshot snap = await WaitForFlowImageBatchToFinishAsync(
                    sess,
                    singleBaseline,
                    attempt,
                    1,
                    0,
                    ct);

                await CollectAndSaveCompletedSessionImagesAsync(
                    sess,
                    singleBaseline,
                    ep,
                    new List<GrokAssetSpec> { varSpec },
                    usedCardKeys,
                    savedMd5Hashes,
                    stagingDl,
                    ct);

                if (snap.FailedCards > 0)
                {
                    await ClickFailedTileActionButtonAsync(sess, 0, Math.Max(4, snap.SessionSliceEndIndex), true, false, ct);
                    await Task.Delay(400, ct);
                }

                await ClearAttachedPromptChipsAsync(sess, ct);

                if (File.Exists(dstPath) && new FileInfo(dstPath).Length >= 1024)
                {
                    _log(string.Format("[Google Flow | Continuidade de Personagem] ✔ Nova versão '{0}' gerada com sucesso mantendo as características de '{1}'!",
                        varSpec.TargetFileName, baseRefName));
                    return true;
                }

                if (snap.AgentBlockedByUnusualActivity)
                    break;
            }

            return File.Exists(dstPath) && new FileInfo(dstPath).Length >= 1024;
        }

        public async Task GenerateMissingAssetsInFlowAsync(
            EpisodeWorkItem ep,
            List<GrokAssetSpec> specsToGenerate,
            CancellationToken ct)
        {
            if (ep == null || specsToGenerate == null || specsToGenerate.Count == 0)
                return;

            if (!Directory.Exists(ep.AssetsDir))
                Directory.CreateDirectory(ep.AssetsDir);
            if (!Directory.Exists(_config.TempFlowAssetsDir))
                Directory.CreateDirectory(_config.TempFlowAssetsDir);

            // Sincroniza primeiro eventuais assets idênticos já prontos nos episódios anteriores
            EpisodeParser.SyncRecurringAssetsFromPreviousEpisodes(ep, _log);

            // 1. Audita arquivos existentes em assets\ para remover eventuais duplicatas idênticas (MD5 repetido) e registrar hashes já salvos
            HashSet<string> savedMd5Hashes = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            try
            {
                List<string> existingFiles = Directory.GetFiles(ep.AssetsDir, "*.jpg")
                    .OrderBy(f => Path.GetFileName(f), StringComparer.OrdinalIgnoreCase)
                    .ToList();
                Dictionary<string, string> hashToFirstFile = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                for (int i = 0; i < existingFiles.Count; i++)
                {
                    string fPath = existingFiles[i];
                    FileInfo fi = new FileInfo(fPath);
                    if (fi.Length <= 1024) continue;
                    byte[] bytes = File.ReadAllBytes(fPath);
                    string md5 = ComputeBytesMd5Hex(bytes);
                    if (string.IsNullOrEmpty(md5)) continue;

                    string firstFile;
                    if (hashToFirstFile.TryGetValue(md5, out firstFile))
                    {
                        _log(string.Format("[Google Flow | Auditoria de Assets] Removendo imagem duplicada '{0}' (idêntica a '{1}') para regerar o asset correto...",
                            Path.GetFileName(fPath), Path.GetFileName(firstFile)));
                        try { File.Delete(fPath); } catch { }
                    }
                    else
                    {
                        hashToFirstFile[md5] = fPath;
                        savedMd5Hashes.Add(md5);
                    }
                }
            }
            catch { }

            List<GrokAssetSpec> pendingSpecs = specsToGenerate
                .Where(s => s != null && !string.IsNullOrEmpty(s.TargetFileName) &&
                       (!File.Exists(Path.Combine(ep.AssetsDir, s.TargetFileName)) || new FileInfo(Path.Combine(ep.AssetsDir, s.TargetFileName)).Length < 1024))
                .ToList();

            if (pendingSpecs.Count == 0)
                return;

            // Separa em:
            // (A) Personagens inéditos e Cenários (gerados em lote limpo sem chips de outros personagens anexados)
            // (B) Novas versões de personagens já existentes no EP anterior ou neste EP (geradas 1 a 1 anexando obrigatoriamente a imagem anterior!)
            List<GrokAssetSpec> baseSpecs = new List<GrokAssetSpec>();
            List<GrokAssetSpec> variantSpecs = new List<GrokAssetSpec>();
            for (int i = 0; i < pendingSpecs.Count; i++)
            {
                GrokAssetSpec spec = pendingSpecs[i];
                if (!spec.IsScenario)
                {
                    string existingBasePath = EpisodeParser.FindExistingBaseCharacterPathForVariantSpec(ep, spec);
                    GrokAssetSpec sameEpBase = EpisodeParser.FindBaseCharacterSpecInEpisode(ep, spec);
                    if (!string.IsNullOrEmpty(existingBasePath) || sameEpBase != null)
                    {
                        variantSpecs.Add(spec);
                        continue;
                    }
                }
                baseSpecs.Add(spec);
            }

            _log(string.Format("[Google Flow | Imagens 9:16] Iniciando geração de {0} imagem(ns) pendente(s) no Google Flow ({1} base/cenário(s) + {2} nova(s) versão(ões) de personagem existente)...",
                pendingSpecs.Count, baseSpecs.Count, variantSpecs.Count));

            string sess = await OpenAndPrepareFlowProjectTabAsync(ct);
            await EnsureAgentPanelOpenAsync(sess, ct);
            await ScrollAgentPanelToBottomAsync(sess, ct);

            string stagingDl = Path.Combine(Path.GetTempPath(), "fluxo_img_dl_" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(stagingDl);
            await _cdp.SetDownloadBehaviorAsync(stagingDl, ct);

            try
            {
                HashSet<string> usedCardKeys = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

                // Etapa A: Gera primeiro todos os personagens base inéditos e cenários
                if (baseSpecs.Count > 0)
                {
                    await RunFlowImageBatchesInSessionAsync(
                        sess,
                        ep,
                        baseSpecs,
                        null,
                        null,
                        false,
                        usedCardKeys,
                        savedMd5Hashes,
                        stagingDl,
                        ct);

                    List<GrokAssetSpec> failedBaseFirstPass = baseSpecs
                        .Where(s => !File.Exists(Path.Combine(ep.AssetsDir, s.TargetFileName)) || new FileInfo(Path.Combine(ep.AssetsDir, s.TargetFileName)).Length < 1024)
                        .ToList();

                    if (failedBaseFirstPass.Count > 0)
                    {
                        string failedNames = string.Join(", ", failedBaseFirstPass.Select(s => s.TargetFileName));
                        _log(string.Format("[Google Flow | Imagens 9:16] {0} imagem(ns) base/cenário não foram geradas na 1ª tentativa ({1}) -> enviando 2ª tentativa com suavização anti-bloqueio...",
                            failedBaseFirstPass.Count, failedNames));

                        await RunFlowImageBatchesInSessionAsync(
                            sess,
                            ep,
                            failedBaseFirstPass,
                            null,
                            null,
                            true,
                            usedCardKeys,
                            savedMd5Hashes,
                            stagingDl,
                            ct);
                    }
                }

                // Etapa B: Gera cada nova versão de personagem existente anexando individualmente a imagem anterior do personagem!
                if (variantSpecs.Count > 0)
                {
                    _log(string.Format("[Google Flow | Continuidade de Personagem] {0} nova(s) versão(ões) de personagem(ns) detectada(s) ({1}) -> subindo e anexando a imagem anterior de cada personagem para manter todas as características do original...",
                        variantSpecs.Count,
                        string.Join(", ", variantSpecs.Select(v => v.TargetFileName))));

                    List<string> tempBaseRefsToUpload = new List<string>();
                    Dictionary<string, string> resolvedBasePaths = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                    List<GrokAssetSpec> orphanVariantsWithoutBase = new List<GrokAssetSpec>();

                    for (int i = 0; i < variantSpecs.Count; i++)
                    {
                        GrokAssetSpec varSpec = variantSpecs[i];
                        string baseRefPath = EpisodeParser.FindExistingBaseCharacterPathForVariantSpec(ep, varSpec);
                        if (!string.IsNullOrEmpty(baseRefPath) && File.Exists(baseRefPath))
                        {
                            resolvedBasePaths[varSpec.TargetFileName] = baseRefPath;
                            string baseRefName = Path.GetFileName(baseRefPath);
                            string tempBaseRef = Path.Combine(_config.TempFlowAssetsDir, baseRefName);
                            try { File.Copy(baseRefPath, tempBaseRef, true); } catch { }
                            if (!tempBaseRefsToUpload.Contains(tempBaseRef, StringComparer.OrdinalIgnoreCase))
                                tempBaseRefsToUpload.Add(tempBaseRef);
                        }
                        else
                        {
                            orphanVariantsWithoutBase.Add(varSpec);
                        }
                    }

                    if (tempBaseRefsToUpload.Count > 0)
                    {
                        await UploadAssetsToFlowProjectAsync(sess, tempBaseRefsToUpload, ct);
                    }

                    for (int i = 0; i < variantSpecs.Count; i++)
                    {
                        ct.ThrowIfCancellationRequested();
                        GrokAssetSpec varSpec = variantSpecs[i];
                        string baseRefPath;
                        if (resolvedBasePaths.TryGetValue(varSpec.TargetFileName, out baseRefPath) &&
                            !string.IsNullOrEmpty(baseRefPath) &&
                            File.Exists(baseRefPath))
                        {
                            await GenerateSingleVariantAssetInFlowAsync(
                                sess,
                                ep,
                                varSpec,
                                baseRefPath,
                                usedCardKeys,
                                savedMd5Hashes,
                                stagingDl,
                                ct);
                        }
                    }

                    if (orphanVariantsWithoutBase.Count > 0)
                    {
                        _log(string.Format("[Google Flow | Continuidade de Personagem] Aviso: Imagem anterior não localizada em disco para {0} item(ns) ({1}); gerando via comando padrão...",
                            orphanVariantsWithoutBase.Count,
                            string.Join(", ", orphanVariantsWithoutBase.Select(o => o.TargetFileName))));

                        await RunFlowImageBatchesInSessionAsync(
                            sess,
                            ep,
                            orphanVariantsWithoutBase,
                            null,
                            null,
                            false,
                            usedCardKeys,
                            savedMd5Hashes,
                            stagingDl,
                            ct);
                    }
                }

                // Qualquer imagem que ainda não tenha sido gerada após a 2ª tentativa suavizada é registrada como pulada
                for (int i = 0; i < pendingSpecs.Count; i++)
                {
                    GrokAssetSpec spec = pendingSpecs[i];
                    string dstPath = Path.Combine(ep.AssetsDir, spec.TargetFileName);
                    if (!File.Exists(dstPath) || new FileInfo(dstPath).Length < 1024)
                    {
                        _log(string.Format("[Google Flow | Imagem Pulada] '{0}' não pôde ser gerada após 1ª tentativa e 2ª tentativa suavizada -> pulando imagem e prosseguindo!", spec.TargetFileName));
                    }
                }
            }
            finally
            {
                Task ignoredCleanup = Task.Run(async () =>
                {
                    try { await _cdp.ResetDownloadBehaviorToDefaultAsync(); } catch { }
                    try { Directory.Delete(stagingDl, true); } catch { }
                });
            }
        }

        private async Task RunFlowImageBatchesInSessionAsync(
            string sess,
            EpisodeWorkItem ep,
            List<GrokAssetSpec> specsForPass,
            Dictionary<string, string> specToBaseRefName,
            List<string> baseRefNamesToAttach,
            bool soften,
            HashSet<string> usedCardKeys,
            HashSet<string> savedMd5Hashes,
            string stagingDl,
            CancellationToken ct)
        {
            if (specsForPass == null || specsForPass.Count == 0)
                return;

            await ClearAttachedPromptChipsAsync(sess, ct);
            string curTxt = await ReadCurrentFlowTextboxAsync(sess, ct);
            if (!string.IsNullOrWhiteSpace(curTxt))
            {
                await InsertTextIntoFlowTextboxAsync(sess, "", true, ct);
                await Task.Delay(350, ct);
            }

            if (baseRefNamesToAttach != null && baseRefNamesToAttach.Count > 0)
            {
                bool anySpecNeedsBase = specsForPass.Any(s => specToBaseRefName != null && specToBaseRefName.ContainsKey(s.TargetFileName));
                if (anySpecNeedsBase)
                {
                    HashSet<string> attachedTmp = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                    await AttachIngredientsViaMenuAsync(sess, baseRefNamesToAttach, attachedTmp, ct);
                    await WaitForAttachedPromptChipsImagesLoadedAsync(sess, ct);
                }
            }

            PreSessionGridBaseline passBaseline = await CapturePreSessionBaselineAsync(sess, ct);
            string unifiedCmd = BuildUnifiedFlowImagesCommand(specsForPass, specToBaseRefName, soften);

            _log(string.Format("[Google Flow | Imagens 9:16] Enviando comando único com {0} imagem(ns) ({1})...",
                specsForPass.Count, soften ? "2ª tentativa suavizada" : "1ª tentativa"));

            await InsertTextIntoFlowTextboxAsync(sess, unifiedCmd, false, ct);
            await WaitRandomFlowActionDelayAsync("após colar comando de imagens", ct);

            LastActionHistoryStore.RecordAction(
                ep,
                "Google Flow",
                string.Format("Gerando lote de {0} imagem(ns) 9:16 ({1}) no Google Flow", specsForPass.Count, soften ? "2ª tentativa suavizada" : "1ª tentativa"),
                _config.FlowProfile,
                sess,
                _config.FlowProjectUrl,
                specsForPass[0].TargetFileName,
                0,
                soften ? 2 : 1,
                unifiedCmd,
                baseRefNamesToAttach ?? new List<string>(),
                "SUBMITTED");

            await ClickStartGenerationAsync(sess, ct);

            int batchNumber = 1;
            int maxBatches = Math.Max(2, (int)Math.Ceiling(specsForPass.Count / 3.0) + 2);
            int baselineCardsBeforeSubmit = 0;

            while (batchNumber <= maxBatches)
            {
                ct.ThrowIfCancellationRequested();

                SessionPollSnapshot snap = await WaitForFlowImageBatchToFinishAsync(
                    sess,
                    passBaseline,
                    batchNumber,
                    specsForPass.Count,
                    baselineCardsBeforeSubmit,
                    ct);

                // Coleta e salva imediatamente todas as imagens concluídas até aqui, casando 1:1 com cada GrokAssetSpec
                await CollectAndSaveCompletedSessionImagesAsync(
                    sess,
                    passBaseline,
                    ep,
                    specsForPass,
                    usedCardKeys,
                    savedMd5Hashes,
                    stagingDl,
                    ct);

                if (snap.FailedCards > 0)
                {
                    await ClickFailedTileActionButtonAsync(sess, 0, Math.Max(6, snap.SessionSliceEndIndex), true, false, ct);
                    await Task.Delay(400, ct);
                }

                // Verifica quais índices (1..N) ainda faltam salvar em disco
                List<int> missingOneBasedIndices = new List<int>();
                for (int i = 0; i < specsForPass.Count; i++)
                {
                    string p = Path.Combine(ep.AssetsDir, specsForPass[i].TargetFileName);
                    if (!File.Exists(p) || new FileInfo(p).Length < 1024)
                        missingOneBasedIndices.Add(i + 1);
                }

                if (missingOneBasedIndices.Count == 0)
                {
                    break;
                }

                if (snap.AgentBlockedByUnusualActivity)
                {
                    break;
                }

                int processedCardsTotal = snap.CompletedCards + snap.FailedCards;
                if (processedCardsTotal >= specsForPass.Count || batchNumber >= maxBatches || snap.TotalSessionCards <= baselineCardsBeforeSubmit)
                {
                    break;
                }

                batchNumber++;
                baselineCardsBeforeSubmit = Math.Max(0, snap.TotalSessionCards - snap.FailedCards);

                List<string> nextItemsDesc = new List<string>();
                for (int m = 0; m < Math.Min(5, missingOneBasedIndices.Count); m++)
                {
                    int idx1 = missingOneBasedIndices[m];
                    nextItemsDesc.Add(string.Format("[IMG_{0:00}] ({1})", idx1, specsForPass[idx1 - 1].TargetFileName));
                }

                string continueCmd = string.Format(
                    "continue gerando imediatamente o próximo lote de imagens estáticas verticais em proporção 9:16 na sequência exata da lista ({0}), mantendo obrigatoriamente a tag exata [IMG_XX] e o nome do arquivo (.jpg) no início do prompt de cada imagem gerada (NÃO gere vídeo).",
                    string.Join(", ", nextItemsDesc));

                _log(string.Format("[Google Flow | Imagens 9:16] Avançando para o Lote {0} na mesma sessão ({1}/{2} imagens concluídas)...",
                    batchNumber, specsForPass.Count - missingOneBasedIndices.Count, specsForPass.Count));

                await InsertTextIntoFlowTextboxAsync(sess, continueCmd, false, ct);
                await WaitRandomFlowActionDelayAsync("após colar comando continue", ct);
                await ClickStartGenerationAsync(sess, ct);
            }
        }

        private async Task<SessionPollSnapshot> WaitForFlowImageBatchToFinishAsync(
            string sess,
            PreSessionGridBaseline baseline,
            int batchNumber,
            int totalExpectedImages,
            int baselineCardsBeforeSubmit,
            CancellationToken ct)
        {
            string b64PreIds = Convert.ToBase64String(Encoding.UTF8.GetBytes(string.Join("|", baseline.PreExistingAsbIds.ToArray())));
            string b64PreUrls = Convert.ToBase64String(Encoding.UTF8.GetBytes(string.Join("|", baseline.PreExistingImageUrls.ToArray())));

            DateTime start = DateTime.UtcNow;
            DateTime deadline = start.AddMinutes(8.0);
            DateTime lastProgressUtc = DateTime.UtcNow;
            string lastFp = "";
            int consecutiveIdleAfterCards = 0;
            int consecutiveIdleNoCards = 0;
            int retryBtnClicks = 0;

            int initBubbles = -1;
            string initBubblesStr = await _cdp.EvalStringAsync(sess, @"
(function(){
    var panel = document.querySelector('flow-agent-panel');
    return panel ? String(panel.querySelectorAll('flow-chat-bubble').length) : '-1';
})()", ct);
            int parsedB;
            if (int.TryParse(initBubblesStr, out parsedB) && parsedB >= 0)
                initBubbles = parsedB;

            while (DateTime.UtcNow < deadline)
            {
                ct.ThrowIfCancellationRequested();
                await _cdp.WaitOrWakeOnReloadSignalAsync(4500, ct);

                string manualReloadReason;
                if (_cdp.ConsumeReloadAndResumeRequest(out manualReloadReason))
                {
                    _log(string.Format("[Recuperação Google Flow] Recarregando guia durante Lote {0} de imagens ({1})...", batchNumber, manualReloadReason));
                    await _cdp.ReloadPageAndWaitReadyAsync(sess, 30000, ct);
                    await WaitForFlowPageLoadedAsync(sess, ct);
                    await EnsureAgentPanelOpenAsync(sess, ct);
                    await Task.Delay(1500, ct);
                    lastProgressUtc = DateTime.UtcNow;
                    retryBtnClicks = 0;
                }

                Dictionary<string, object> st = await _cdp.EvalJsonAsync(sess, string.Format(@"
(function(){{
    var rawPreIds = atob('{0}');
    var preIds = new Set(rawPreIds ? rawPreIds.split('|').filter(Boolean) : []);
    var rawPreUrls = atob('{1}');
    var preUrls = new Set(rawPreUrls ? rawPreUrls.split('|').filter(Boolean) : []);

    var vp = document.querySelector('cdk-virtual-scroll-viewport.tiles-container') || document.querySelector('cdk-virtual-scroll-viewport');
    if (vp && vp.scrollTop > 8) vp.scrollTop = 0;

    var allTiles = Array.from(document.querySelectorAll('flow-image-tile, flow-video-tile, flow-asset-tile, flow-pending-tile, flow-error-tile, [data-asb-id]'));
    var seenHosts = new Set();
    var seenKeys = new Set();
    var generating = 0;
    var completed = 0;
    var failed = 0;
    var pctList = [];
    var sliceEnd = 0;

    for (var i = 0; i < allTiles.length; i++) {{
        var el = allTiles[i];
        var host = el.closest('flow-image-tile, flow-video-tile, flow-asset-tile, flow-pending-tile, flow-error-tile') || el;
        if (seenHosts.has(host)) continue;
        seenHosts.add(host);

        var hostTag = (host.tagName || '').toLowerCase();
        var isPendingTag = hostTag === 'flow-pending-tile' || !!host.querySelector('flow-pending-tile');
        var isErrorTag = hostTag === 'flow-error-tile' || !!host.querySelector('flow-error-tile');
        var vid = host.querySelector('video');
        var imgEl = host.querySelector('img.thumbnail') || host.querySelector('img');
        var imgSrc = imgEl ? (imgEl.currentSrc || imgEl.src || imgEl.getAttribute('src') || '') : '';
        var mAsb = imgSrc.match(/\/asb\/([A-Za-z0-9_\-]{{25,80}})/);
        var asb = mAsb ? mAsb[1] : (host.getAttribute('data-asb-id') || '');
        var key = asb || imgSrc || ('idx_' + i);

        if (seenKeys.has(key)) continue;
        seenKeys.add(key);

        if ((asb && preIds.has(asb)) || (imgSrc && preUrls.has(imgSrc))) {{
            break;
        }}
        sliceEnd = i + 1;

        var txt = (host.innerText || '').trim();
        var pctM = txt.match(/\b\d{{1,3}}\s*%/);
        var hasPct = !!pctM;
        var hasMore = !!host.querySelector('button[aria-label*=""Mais op""], button[aria-label*=""More""]');
        var hasErr = !hasPct && !hasMore && !imgSrc && (
            isErrorTag ||
            /violar|pol[ií]ticas|falha|erro|errado|n[aã]o\s+foi\s+poss[ií]vel|bloquead|tente\s+(?:novamente|de\s+novo)|violate|failed|error|wrong|blocked|try\s+again/i.test(txt)
        );

        if (hasPct || (isPendingTag && !hasErr && imgSrc.length <= 12)) {{
            generating++;
            if (hasPct) pctList.push(pctM[0]);
        }} else if (hasErr) {{
            failed++;
        }} else if (!vid && (imgSrc.length > 12 || hasMore)) {{
            completed++;
        }}
    }}

    var panel = document.querySelector('flow-agent-panel');
    var bubbles = panel ? panel.querySelectorAll('flow-chat-bubble').length : 0;
    var panelNewImgs = 0;
    var panelBusy = false;
    var hasUnusual = false;
    var retryBtn = null;

    if (panel) {{
        var stopBtn = !!Array.from(panel.querySelectorAll('button')).find(b => {{
            var al = (b.getAttribute('aria-label') || '');
            var t = (b.innerText || '').trim();
            return b.getBoundingClientRect().width > 10 && (al.indexOf('Parar') >= 0 || al.indexOf('Stop') >= 0 || t === 'stop' || t === 'stop_circle');
        }});
        var spinner = !!Array.from(panel.querySelectorAll('mat-progress-spinner, mat-spinner, [role=""progressbar""], .thinking-indicator, flow-chat-thinking-indicator'))
            .find(s => s.getBoundingClientRect().width > 6);
        panelBusy = stopBtn || spinner;

        var pImgs = Array.from(panel.querySelectorAll('flow-chat-bubble img, flow-image-option img, flow-a2ui-image-option img'));
        var seenP = new Set();
        pImgs.forEach(pim => {{
            if (pim.closest('flow-image-ingredient-chip')) return;
            var s = pim.currentSrc || pim.src || pim.getAttribute('src') || '';
            if (s.length <= 12 || preUrls.has(s)) return;
            var m = s.match(/\/asb\/([A-Za-z0-9_\-]{{25,80}})/);
            var a = m ? m[1] : '';
            if (a && preIds.has(a)) return;
            var k = a || s;
            if (!seenP.has(k)) {{
                seenP.add(k);
                panelNewImgs++;
            }}
        }});

        var chatBubbles = Array.from(panel.querySelectorAll('flow-chat-bubble'));
        var tailBubbles = chatBubbles.slice(Math.max(0, chatBubbles.length - 3));
        for (var bIdx = tailBubbles.length - 1; bIdx >= 0; bIdx--) {{
            var bEl = tailBubbles[bIdx];
            var bTxt = (bEl.innerText || '');
            if (bTxt.indexOf('atividade incomum') >= 0 || bTxt.indexOf('unusual activity') >= 0 || bTxt.indexOf('Tentar de novo') >= 0 || bTxt.indexOf('Try again') >= 0) {{
                var btns = Array.from(bEl.querySelectorAll('button, [role=""button""]')).filter(btn => {{
                    var r = btn.getBoundingClientRect();
                    var t = (btn.innerText || '').trim();
                    return r.width > 20 && r.height > 14 && !btn.disabled && (t.indexOf('Tentar de novo') >= 0 || t.indexOf('Try again') >= 0);
                }});
                if (btns.length > 0) {{
                    hasUnusual = true;
                    var targetBtn = btns[btns.length - 1];
                    targetBtn.scrollIntoView({{ block: 'center', inline: 'nearest' }});
                    var br = targetBtn.getBoundingClientRect();
                    retryBtn = {{ x: Math.round(br.left + br.width / 2), y: Math.round(br.top + br.height / 2) }};
                    break;
                }}
            }}
        }}
    }}

    var effCompleted = Math.max(completed, panelNewImgs);
    return JSON.stringify({{
        generating: generating,
        completed: effCompleted,
        failed: failed,
        sliceEnd: sliceEnd,
        pctSummary: pctList.join(','),
        bubbles: bubbles,
        busy: panelBusy,
        unusual: hasUnusual,
        retryBtn: retryBtn
    }});
}})()", b64PreIds, b64PreUrls), ct);

                SessionPollSnapshot snap = new SessionPollSnapshot();
                if (st == null) continue;

                snap.GeneratingCards = st.ContainsKey("generating") ? Convert.ToInt32(st["generating"]) : 0;
                snap.CompletedCards = st.ContainsKey("completed") ? Convert.ToInt32(st["completed"]) : 0;
                snap.FailedCards = st.ContainsKey("failed") ? Convert.ToInt32(st["failed"]) : 0;
                snap.SessionSliceEndIndex = st.ContainsKey("sliceEnd") ? Convert.ToInt32(st["sliceEnd"]) : 0;
                snap.PctSummary = st.ContainsKey("pctSummary") ? Convert.ToString(st["pctSummary"] ?? "") : "";
                snap.AgentChatBubblesCount = st.ContainsKey("bubbles") ? Convert.ToInt32(st["bubbles"]) : 0;
                snap.AgentBusy = st.ContainsKey("busy") && Convert.ToBoolean(st["busy"]);
                snap.AgentHasUnusualActivity = st.ContainsKey("unusual") && Convert.ToBoolean(st["unusual"]);
                Dictionary<string, object> retryBtn = st.ContainsKey("retryBtn") ? st["retryBtn"] as Dictionary<string, object> : null;
                snap.TotalSessionCards = snap.GeneratingCards + snap.CompletedCards + snap.FailedCards;

                string curFp = string.Format("{0}|{1}|{2}|{3}|{4}|{5}",
                    snap.TotalSessionCards, snap.GeneratingCards, snap.CompletedCards, snap.FailedCards, snap.PctSummary, snap.AgentChatBubblesCount);
                if (curFp != lastFp)
                {
                    lastFp = curFp;
                    lastProgressUtc = DateTime.UtcNow;
                }

                string pctInfo = !string.IsNullOrEmpty(snap.PctSummary) ? string.Format(" [{0}]", snap.PctSummary) : "";
                _log(string.Format("[Google Flow | Imagens 9:16 | Lote {0}] Cards na sessão: {1}/{2} | Em geração: {3}{4} | Concluídas (100%): {5} | Erros: {6}",
                    batchNumber, snap.TotalSessionCards, totalExpectedImages, snap.GeneratingCards, pctInfo, snap.CompletedCards, snap.FailedCards));

                bool newCardsAppeared = snap.TotalSessionCards > baselineCardsBeforeSubmit;
                if (newCardsAppeared && snap.GeneratingCards == 0 && !snap.AgentBusy)
                {
                    consecutiveIdleAfterCards++;
                    if (consecutiveIdleAfterCards >= 2)
                    {
                        return snap;
                    }
                }
                else
                {
                    consecutiveIdleAfterCards = 0;

                    if (!newCardsAppeared && snap.GeneratingCards == 0 && !snap.AgentBusy && snap.AgentHasUnusualActivity)
                    {
                        if (retryBtn != null && retryBtnClicks < 2)
                        {
                            retryBtnClicks++;
                            int rx = Convert.ToInt32(retryBtn["x"]);
                            int ry = Convert.ToInt32(retryBtn["y"]);
                            _log(string.Format("[Google Flow | Imagens 9:16 | Lote {0}] Aviso 'Notamos uma atividade incomum' detectado -> aguardando 4s e clicando em 'Tentar de novo' ({1}/2)...",
                                batchNumber, retryBtnClicks));
                            await Task.Delay(4000, ct);
                            await _cdp.ClickAtAsync(sess, rx, ry, ct);
                            await Task.Delay(3000, ct);
                            lastProgressUtc = DateTime.UtcNow;
                            continue;
                        }
                        else
                        {
                            snap.AgentBlockedByUnusualActivity = true;
                            return snap;
                        }
                    }

                    double elapsedSec = (DateTime.UtcNow - start).TotalSeconds;
                    if (!newCardsAppeared && snap.GeneratingCards == 0 && !snap.AgentBusy &&
                        initBubbles >= 0 && snap.AgentChatBubblesCount > initBubbles && elapsedSec >= 20)
                    {
                        consecutiveIdleNoCards++;
                        if (consecutiveIdleNoCards >= 2)
                            return snap;
                    }
                    else
                    {
                        consecutiveIdleNoCards = 0;
                    }
                }
            }

            return new SessionPollSnapshot();
        }

        private async Task<int> CollectAndSaveCompletedSessionImagesAsync(
            string sess,
            PreSessionGridBaseline baseline,
            EpisodeWorkItem ep,
            List<GrokAssetSpec> specsForPass,
            HashSet<string> usedCardKeys,
            HashSet<string> savedMd5Hashes,
            string stagingDl,
            CancellationToken ct)
        {
            if (specsForPass == null || specsForPass.Count == 0)
                return 0;

            await EnsureAgentPanelOpenAsync(sess, ct);

            // 1. Expande botões "Ver tudo" / "Show all" nas bolhas do painel do Agente para exibir todas as imagens do lote
            for (int expandPass = 0; expandPass < 2; expandPass++)
            {
                string clickedStr = await _cdp.EvalStringAsync(sess, @"
(function(){
    var panel = document.querySelector('flow-agent-panel');
    if (!panel) return '0';
    var btns = Array.from(panel.querySelectorAll('button')).filter(b => {
        var t = ((b.innerText || '') + ' ' + (b.getAttribute('aria-label') || '')).trim();
        if (!t || /racioc[ií]nio|thinking|menos|less/i.test(t)) return false;
        return /\b(ver tudo|ver mais|mostrar tudo|mostrar mais|view all|show all|see all)\b/i.test(t);
    });
    btns.forEach(b => { try { b.click(); } catch(e) {} });
    return String(btns.length);
})()", ct);
                int c;
                if (!int.TryParse(clickedStr, out c) || c <= 0)
                    break;
                await Task.Delay(450, ct);
            }

            string b64PreIds = Convert.ToBase64String(Encoding.UTF8.GetBytes(string.Join("|", baseline.PreExistingAsbIds.ToArray())));
            string b64PreUrls = Convert.ToBase64String(Encoding.UTF8.GetBytes(string.Join("|", baseline.PreExistingImageUrls.ToArray())));

            // 2. Coleta todas as imagens novas da grade principal (em ordem cronológica: mais antiga -> mais recente) enriquecidas pelo painel do Agente
            Dictionary<string, object> raw = await _cdp.EvalJsonAsync(sess, string.Format(@"
(function(){{
    var rawPreIds = atob('{0}');
    var preIds = new Set(rawPreIds ? rawPreIds.split('|').filter(Boolean) : []);
    var rawPreUrls = atob('{1}');
    var preUrls = new Set(rawPreUrls ? rawPreUrls.split('|').filter(Boolean) : []);

    function normUrlKey(asb, u) {{
        if (asb && asb.length > 4) return asb;
        if (!u) return '';
        var clean = u.split('#')[0].split('?')[0];
        clean = clean.replace(/=(?:w|s|h)\d+[^\/]*$/i, '');
        return clean || u;
    }}

    var preNormKeys = new Set();
    preUrls.forEach(u => {{
        var nk = normUrlKey('', u);
        if (nk) preNormKeys.add(nk);
    }});

    function cleanAltText(rawAlt) {{
        var a = (rawAlt || '').trim();
        if (!a) return '';
        if (a.length < 36 && /^(imagem|image|thumbnail|miniatura|gerada|generated|asset|recurso|foto|photo|agente|agent|painel|historico|chat)\b/i.test(a)) {{
            return '';
        }}
        return a;
    }}

    var vp = document.querySelector('cdk-virtual-scroll-viewport.tiles-container') || document.querySelector('cdk-virtual-scroll-viewport');
    if (vp && vp.scrollTop > 8) vp.scrollTop = 0;

    // A) Painel do Agente (já está em ordem cronológica: mais antiga -> mais recente)
    var panelItems = [];
    var seenPanelKeys = new Set();
    var panel = document.querySelector('flow-agent-panel');
    if (panel) {{
        var pImgs = Array.from(panel.querySelectorAll('flow-chat-bubble img, flow-image-option img, flow-a2ui-image-option img'));
        pImgs.forEach(pim => {{
            if (pim.closest('flow-image-ingredient-chip')) return;
            var r = pim.getBoundingClientRect();
            if (r.width > 0 && r.width < 45 && (pim.naturalWidth || 0) < 100) return;
            var s = pim.currentSrc || pim.src || pim.getAttribute('src') || '';
            if (s.length <= 12) return;
            var m = s.match(/\/asb\/([A-Za-z0-9_\-]{{25,80}})/);
            var a = m ? m[1] : '';
            var nk = normUrlKey(a, s);
            if ((a && preIds.has(a)) || preUrls.has(s) || (nk && preNormKeys.has(nk))) return;
            if (!nk || seenPanelKeys.has(nk)) return;
            seenPanelKeys.add(nk);

            var alt = cleanAltText(pim.getAttribute('alt') || pim.getAttribute('aria-label') || '');
            if (!alt) {{
                var hostOpt = pim.closest('flow-a2ui-image-option, flow-image-option');
                if (hostOpt) alt = cleanAltText(hostOpt.getAttribute('aria-label') || '');
            }}
            panelItems.push({{ key: nk, asb: a || '', url: s, alt: alt }});
        }});
    }}

    // B) Grade principal (está em ordem reversa: mais recente no topo -> invertemos para ordem cronológica!)
    var allTiles = Array.from(document.querySelectorAll('flow-image-tile, flow-video-tile, flow-asset-tile, [data-asb-id]'));
    var gridNewOldestFirst = [];
    var seenGridKeys = new Set();

    for (var i = 0; i < allTiles.length; i++) {{
        var el = allTiles[i];
        var host = el.closest('flow-image-tile, flow-video-tile, flow-asset-tile') || el;
        var vid = host.querySelector('video');
        if (vid) continue;
        var imgEl = host.querySelector('img.thumbnail') || host.querySelector('img');
        var imgSrc = imgEl ? (imgEl.currentSrc || imgEl.src || imgEl.getAttribute('src') || '') : '';
        var mAsb = imgSrc.match(/\/asb\/([A-Za-z0-9_\-]{{25,80}})/);
        var asb = mAsb ? mAsb[1] : (host.getAttribute('data-asb-id') || '');
        var nk = normUrlKey(asb, imgSrc);
        if (!nk) continue;
        if (seenGridKeys.has(nk)) continue;
        seenGridKeys.add(nk);

        if ((asb && preIds.has(asb)) || (imgSrc && preUrls.has(imgSrc)) || preNormKeys.has(nk)) {{
            break;
        }}

        var txt = (host.innerText || '').trim();
        if (/\b\d{{1,3}}\s*%/.test(txt)) continue;
        if (!imgSrc || imgSrc.length <= 12) continue;

        var alt = imgEl ? cleanAltText(imgEl.getAttribute('alt') || imgEl.getAttribute('aria-label') || '') : '';
        gridNewOldestFirst.push({{ key: nk, asb: asb || '', url: imgSrc, alt: alt }});
    }}

    gridNewOldestFirst.reverse();

    var finalList = [];
    if (gridNewOldestFirst.length > 0) {{
        var panelByKey = new Map();
        panelItems.forEach(p => panelByKey.set(p.key, p));
        for (var gIdx = 0; gIdx < gridNewOldestFirst.length; gIdx++) {{
            var gItem = gridNewOldestFirst[gIdx];
            if (!gItem.alt) {{
                var pMatch = panelByKey.get(gItem.key);
                if (pMatch && pMatch.alt) {{
                    gItem.alt = pMatch.alt;
                }} else if (panelItems.length === gridNewOldestFirst.length && panelItems[gIdx] && panelItems[gIdx].alt) {{
                    gItem.alt = panelItems[gIdx].alt;
                }}
            }}
            finalList.push(gItem);
        }}
    }} else {{
        finalList = panelItems;
    }}

    var items = finalList.map((it, idx) => {{
        return {{
            idx: idx,
            key: it.key,
            asb: it.asb,
            url: it.url,
            alt: it.alt || ''
        }};
    }});

    return JSON.stringify({{ items: items }});
}})()", b64PreIds, b64PreUrls), ct);

            if (raw == null || !raw.ContainsKey("items"))
                return 0;

            IEnumerable arr = raw["items"] as IEnumerable;
            if (arr == null)
                return 0;

            List<SessionCompletedImageInfo> candidates = new List<SessionCompletedImageInfo>();
            foreach (object elem in arr)
            {
                Dictionary<string, object> d = elem as Dictionary<string, object>;
                if (d == null) continue;
                string key = d.ContainsKey("key") ? Convert.ToString(d["key"] ?? "").Trim() : "";
                string url = d.ContainsKey("url") ? Convert.ToString(d["url"] ?? "").Trim() : "";
                if (string.IsNullOrEmpty(key) || string.IsNullOrEmpty(url)) continue;
                if (usedCardKeys.Contains(key) || usedCardKeys.Contains(url)) continue;

                SessionCompletedImageInfo info = new SessionCompletedImageInfo();
                info.ChronologicalOrder = d.ContainsKey("idx") ? Convert.ToInt32(d["idx"]) : candidates.Count;
                info.CardKey = key;
                info.AsbId = d.ContainsKey("asb") ? Convert.ToString(d["asb"] ?? "").Trim() : "";
                info.ImageUrl = url;
                info.AltPrompt = d.ContainsKey("alt") ? Convert.ToString(d["alt"] ?? "").Trim() : "";
                candidates.Add(info);
            }

            if (candidates.Count == 0)
            {
                _log("[Google Flow | Imagens 9:16] Aviso: Nenhum card de imagem novo foi localizado no DOM após conclusão do lote.");
                return 0;
            }

            _log(string.Format("[Google Flow | Imagens 9:16] {0} imagem(ns) concluída(s) localizada(s) na sessão para download e identificação...", candidates.Count));

            // 3. Se houver mais de 1 spec pendente e algum card não tiver tag explícita [IMG_XX], tenta ler o prompt via botão "Reutilizar comando" (↩) no card da grade!
            if (specsForPass.Count > 1)
            {
                for (int c = 0; c < candidates.Count; c++)
                {
                    ct.ThrowIfCancellationRequested();
                    SessionCompletedImageInfo card = candidates[c];
                    if (TryExtractExplicitImageTagIndex(card.AltPrompt, specsForPass.Count) > 0)
                        continue;

                    string lookupToken = !string.IsNullOrEmpty(card.AsbId) ? card.AsbId : card.ImageUrl;
                    if (string.IsNullOrEmpty(lookupToken))
                        continue;

                    try
                    {
                        Dictionary<string, object> cardCenter = await ScrollToAndLocateTileByAsbIdAsync(sess, lookupToken, ct);
                        if (cardCenter == null) continue;

                        await _cdp.HoverAsync(sess, Convert.ToInt32(cardCenter["x"]), Convert.ToInt32(cardCenter["y"]), ct);
                        await Task.Delay(340, ct);

                        string b64Token = Convert.ToBase64String(Encoding.UTF8.GetBytes(lookupToken));
                        Dictionary<string, object> reusePt = await _cdp.EvalJsonAsync(sess, string.Format(@"
(function(){{
    var want = atob('{0}');
    var tile = Array.from(document.querySelectorAll('flow-image-tile, flow-video-tile, flow-asset-tile, [data-asb-id]')).find(t => {{
        var host = t.closest('flow-image-tile, flow-video-tile, flow-asset-tile') || t;
        var img = host.querySelector('img');
        var u = (img ? ((img.currentSrc || img.src || img.getAttribute('src') || '')) : '') + ' ' + (host.getAttribute('data-asb-id') || '');
        return u.indexOf(want) >= 0;
    }});
    if (!tile) return null;
    var hostTile = tile.closest('flow-image-tile, flow-video-tile, flow-asset-tile') || tile;
    var btn = hostTile.querySelector('button[aria-label*=""Reutilizar""], button[aria-label*=""Reuse""]') ||
              Array.from(hostTile.querySelectorAll('button')).find(b => {{
                  var al = (b.getAttribute('aria-label') || '');
                  var txt = (b.innerText || '').trim();
                  return al.indexOf('Reutilizar') >= 0 || al.indexOf('Reuse') >= 0 || txt === 'undo' || txt === 'replay';
              }});
    if (!btn) return null;
    var r = btn.getBoundingClientRect();
    if (r.width < 4) {{
        btn.click();
        return JSON.stringify({{ clickedNative: true, x: 0, y: 0 }});
    }}
    return JSON.stringify({{ clickedNative: false, x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) }});
}})()", b64Token), ct);

                        if (reusePt != null)
                        {
                            bool clickedNative = reusePt.ContainsKey("clickedNative") && Convert.ToBoolean(reusePt["clickedNative"]);
                            if (!clickedNative)
                            {
                                await _cdp.ClickAtAsync(sess, Convert.ToInt32(reusePt["x"]), Convert.ToInt32(reusePt["y"]), ct);
                            }
                            await Task.Delay(650, ct);
                            string recovered = await ReadCurrentFlowTextboxAsync(sess, ct);
                            if (!string.IsNullOrWhiteSpace(recovered))
                            {
                                card.AltPrompt = recovered;
                                await InsertTextIntoFlowTextboxAsync(sess, "", true, ct);
                            }
                            await ClearAttachedPromptChipsAsync(sess, ct);
                        }
                    }
                    catch (OperationCanceledException) { throw; }
                    catch { }
                }
            }

            // 4. Casamento Global Best-First 1:1 entre os specs ainda não salvos e os cards novos desta sessão
            bool[] specAssigned = new bool[specsForPass.Count];
            for (int s = 0; s < specsForPass.Count; s++)
            {
                string p = Path.Combine(ep.AssetsDir, specsForPass[s].TargetFileName);
                if (File.Exists(p) && new FileInfo(p).Length >= 1024)
                    specAssigned[s] = true;
            }

            SessionCompletedImageInfo[] assignedCardPerSpec = new SessionCompletedImageInfo[specsForPass.Count];
            HashSet<int> usedCandidateIndices = new HashSet<int>();

            List<ImageSpecMatchCandidate> allPairs = new List<ImageSpecMatchCandidate>();
            for (int c = 0; c < candidates.Count; c++)
            {
                SessionCompletedImageInfo card = candidates[c];
                if (string.IsNullOrWhiteSpace(card.AltPrompt))
                    continue;

                for (int s = 0; s < specsForPass.Count; s++)
                {
                    if (specAssigned[s]) continue;
                    double sc = ComputeImageSpecToPromptMatchScore(specsForPass[s], s + 1, specsForPass.Count, card.AltPrompt);
                    if (sc >= 0.24)
                    {
                        ImageSpecMatchCandidate pair = new ImageSpecMatchCandidate();
                        pair.SpecIndex = s;
                        pair.CardIndex = c;
                        pair.CardKey = card.CardKey;
                        pair.Score = sc;
                        allPairs.Add(pair);
                    }
                }
            }

            allPairs.Sort(delegate(ImageSpecMatchCandidate a, ImageSpecMatchCandidate b)
            {
                int cmp = b.Score.CompareTo(a.Score);
                if (cmp != 0) return cmp;
                return a.CardIndex.CompareTo(b.CardIndex);
            });

            for (int p = 0; p < allPairs.Count; p++)
            {
                ImageSpecMatchCandidate pair = allPairs[p];
                if (specAssigned[pair.SpecIndex]) continue;
                if (usedCandidateIndices.Contains(pair.CardIndex)) continue;

                specAssigned[pair.SpecIndex] = true;
                assignedCardPerSpec[pair.SpecIndex] = candidates[pair.CardIndex];
                usedCandidateIndices.Add(pair.CardIndex);
            }

            // 4b. Fallback estritamente cronológico (mais antiga -> mais recente) para TODOS os cards ainda não utilizados
            // (mesmo quando o Agente do Flow traduziu o prompt para inglês ou usou um alt genérico!)
            for (int s = 0; s < specsForPass.Count; s++)
            {
                if (specAssigned[s]) continue;
                GrokAssetSpec spec = specsForPass[s];

                int chosenIdx = -1;
                for (int c = 0; c < candidates.Count; c++)
                {
                    if (usedCandidateIndices.Contains(c)) continue;
                    string normCardPrompt = EpisodeParser.NormalizeForCompare(candidates[c].AltPrompt ?? "");
                    if (spec.IsScenario && PromptLooksLikeCharacterOnly(normCardPrompt))
                        continue;
                    if (!spec.IsScenario && PromptLooksLikeScenarioOnly(normCardPrompt))
                        continue;
                    chosenIdx = c;
                    break;
                }

                if (chosenIdx < 0)
                {
                    for (int c = 0; c < candidates.Count; c++)
                    {
                        if (!usedCandidateIndices.Contains(c))
                        {
                            chosenIdx = c;
                            break;
                        }
                    }
                }

                if (chosenIdx >= 0)
                {
                    specAssigned[s] = true;
                    assignedCardPerSpec[s] = candidates[chosenIdx];
                    usedCandidateIndices.Add(chosenIdx);
                }
            }

            // 5. Baixa e salva cada imagem casada, validando unicidade de hash MD5 para NUNCA repetir a mesma imagem em outra vaga
            int savedNow = 0;
            for (int s = 0; s < specsForPass.Count; s++)
            {
                ct.ThrowIfCancellationRequested();
                SessionCompletedImageInfo chosenCard = assignedCardPerSpec[s];
                if (chosenCard == null) continue;

                GrokAssetSpec spec = specsForPass[s];
                string dstPath = Path.Combine(ep.AssetsDir, spec.TargetFileName);
                if (File.Exists(dstPath) && new FileInfo(dstPath).Length >= 1024)
                    continue;

                bool ok = await DownloadFlowGeneratedImageAsync(
                    sess,
                    chosenCard.ImageUrl,
                    chosenCard.AsbId,
                    dstPath,
                    stagingDl,
                    savedMd5Hashes,
                    ct);
                if (ok && File.Exists(dstPath) && new FileInfo(dstPath).Length >= 1024)
                {
                    usedCardKeys.Add(chosenCard.CardKey);
                    usedCardKeys.Add(chosenCard.ImageUrl);
                    if (!string.IsNullOrEmpty(chosenCard.AsbId))
                        usedCardKeys.Add(chosenCard.AsbId);

                    string tempCopy = Path.Combine(_config.TempFlowAssetsDir, spec.TargetFileName);
                    try { File.Copy(dstPath, tempCopy, true); } catch { }
                    savedNow++;
                    _log(string.Format("[Google Flow | Imagens 9:16] ✔ Imagem identificada e salva com sucesso ({0}/{1}): {2}",
                        s + 1, specsForPass.Count, spec.TargetFileName));
                }
            }

            if (savedNow > 0)
            {
                EpisodeParser.SyncRecurringAssetsFromPreviousEpisodes(ep, _log);
                EpisodeParser.RefreshDiskCounters(ep);
            }

            return savedNow;
        }

        private static bool TryGetImageDimensionsFromBytes(byte[] rawBytes, out int width, out int height)
        {
            width = 0;
            height = 0;
            if (rawBytes == null || rawBytes.Length < 128) return false;
            try
            {
                using (MemoryStream ms = new MemoryStream(rawBytes))
                using (System.Drawing.Image img = System.Drawing.Image.FromStream(ms, false, false))
                {
                    width = img.Width;
                    height = img.Height;
                    return width > 0 && height > 0;
                }
            }
            catch
            {
                return false;
            }
        }

        private static byte[] EnsureHighQualityJpegBytes(byte[] rawBytes, string dstPath)
        {
            if (rawBytes == null || rawBytes.Length < 128)
                return rawBytes;

            // Se já é JPEG nativo (magic bytes FF D8), preserva os bytes originais sem recompressão!
            bool isAlreadyJpeg = rawBytes.Length > 3 && rawBytes[0] == 0xFF && rawBytes[1] == 0xD8 && rawBytes[2] == 0xFF;
            if (isAlreadyJpeg)
                return rawBytes;

            if (string.IsNullOrEmpty(dstPath) || !dstPath.EndsWith(".jpg", StringComparison.OrdinalIgnoreCase))
                return rawBytes;

            try
            {
                using (MemoryStream inMs = new MemoryStream(rawBytes))
                using (System.Drawing.Image img = System.Drawing.Image.FromStream(inMs))
                using (MemoryStream outMs = new MemoryStream())
                {
                    System.Drawing.Imaging.ImageCodecInfo jpgCodec = System.Drawing.Imaging.ImageCodecInfo.GetImageEncoders()
                        .FirstOrDefault(c => c.FormatID == System.Drawing.Imaging.ImageFormat.Jpeg.Guid);
                    if (jpgCodec != null)
                    {
                        using (System.Drawing.Imaging.EncoderParameters ep = new System.Drawing.Imaging.EncoderParameters(1))
                        {
                            ep.Param[0] = new System.Drawing.Imaging.EncoderParameter(System.Drawing.Imaging.Encoder.Quality, 96L);
                            img.Save(outMs, jpgCodec, ep);
                        }
                    }
                    else
                    {
                        img.Save(outMs, System.Drawing.Imaging.ImageFormat.Jpeg);
                    }
                    byte[] encoded = outMs.ToArray();
                    if (encoded != null && encoded.Length > 1024)
                        return encoded;
                }
            }
            catch { }

            return rawBytes;
        }

        private async Task<byte[]> TryDownloadFlowImageViaNativeMenuAsync(
            string sess,
            string lookupToken,
            string stagingDl,
            bool prefer2K,
            CancellationToken ct)
        {
            if (string.IsNullOrEmpty(lookupToken) || string.IsNullOrEmpty(stagingDl))
                return null;

            try
            {
                // Fecha qualquer menu CDK aberto de passo anterior
                string openMenu = await _cdp.EvalStringAsync(sess, @"
(function(){
    var open = Array.from(document.querySelectorAll('.cdk-overlay-container [role=""menuitem""]'))
        .some(el => el.getBoundingClientRect().width > 10);
    return open ? 'OPEN' : 'CLOSED';
})()", ct);
                if (openMenu == "OPEN")
                {
                    await _cdp.PressEscapeAsync(sess, ct);
                    await Task.Delay(250, ct);
                }

                Dictionary<string, object> cardCenter = await ScrollToAndLocateTileByAsbIdAsync(sess, lookupToken, ct);
                if (cardCenter == null)
                    return null;

                await _cdp.HoverAsync(sess, Convert.ToInt32(cardCenter["x"]), Convert.ToInt32(cardCenter["y"]), ct);
                await Task.Delay(420, ct);

                string b64Tok = Convert.ToBase64String(Encoding.UTF8.GetBytes(lookupToken));
                HashSet<string> beforeFiles = new HashSet<string>(Directory.GetFiles(stagingDl), StringComparer.OrdinalIgnoreCase);

                // Tenta até 2 vezes abrir 'Mais opções' -> 'Fazer o download' (ou botão direto de download no card)
                Dictionary<string, object> dlItem = null;
                bool clickedDirectDownloadBtn = false;

                for (int openAttempt = 1; openAttempt <= 2; openAttempt++)
                {
                    Dictionary<string, object> cardActionPt = await _cdp.EvalJsonAsync(sess, string.Format(@"
(function(){{
    var want = atob('{0}');
    var tile = Array.from(document.querySelectorAll('flow-image-tile, flow-video-tile, flow-asset-tile, [data-asb-id]')).find(t => {{
        var host = t.closest('flow-image-tile, flow-video-tile, flow-asset-tile') || t;
        var img = host.querySelector('img');
        var u = (img ? ((img.currentSrc || img.src || img.getAttribute('src') || '')) : '') + ' ' + (host.getAttribute('data-asb-id') || '');
        return u.indexOf(want) >= 0;
    }});
    if (!tile) return null;
    var hostTile = tile.closest('flow-image-tile, flow-video-tile, flow-asset-tile') || tile;

    var moreBtn = hostTile.querySelector('button[aria-label*=""Mais op""], button[aria-label*=""More""]') ||
                  Array.from(hostTile.querySelectorAll('button')).find(b => (b.innerText || '').trim() === 'more_vert');
    if (moreBtn) {{
        var mr = moreBtn.getBoundingClientRect();
        if (mr.width < 4 || {1} === 2) {{
            moreBtn.click();
            return JSON.stringify({{ kind: 'more', clickedNative: true, x: 0, y: 0 }});
        }}
        return JSON.stringify({{ kind: 'more', clickedNative: false, x: Math.round(mr.left + mr.width/2), y: Math.round(mr.top + mr.height/2) }});
    }}

    var directDl = hostTile.querySelector('button[aria-label*=""Fazer o download""], button[aria-label*=""Download""], button[aria-label*=""Baixar""]') ||
                   Array.from(hostTile.querySelectorAll('button')).find(b => (b.innerText || '').trim() === 'download');
    if (directDl) {{
        var dr = directDl.getBoundingClientRect();
        if (dr.width < 4) {{
            directDl.click();
            return JSON.stringify({{ kind: 'direct', clickedNative: true, x: 0, y: 0 }});
        }}
        return JSON.stringify({{ kind: 'direct', clickedNative: false, x: Math.round(dr.left + dr.width/2), y: Math.round(dr.top + dr.height/2) }});
    }}

    return null;
}})()", b64Tok, openAttempt), ct);

                    if (cardActionPt == null)
                    {
                        await Task.Delay(320, ct);
                        continue;
                    }

                    string kind = cardActionPt.ContainsKey("kind") ? Convert.ToString(cardActionPt["kind"] ?? "") : "";
                    bool clickedNative = cardActionPt.ContainsKey("clickedNative") && Convert.ToBoolean(cardActionPt["clickedNative"]);
                    if (!clickedNative)
                    {
                        await _cdp.ClickAtAsync(sess, Convert.ToInt32(cardActionPt["x"]), Convert.ToInt32(cardActionPt["y"]), ct);
                    }

                    if (kind == "direct")
                    {
                        clickedDirectDownloadBtn = true;
                        break;
                    }

                    for (int poll = 0; poll < 5; poll++)
                    {
                        await Task.Delay(300, ct);
                        dlItem = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var items = Array.from(document.querySelectorAll('.cdk-overlay-container [role=""menuitem""], [role=""menuitem""]'))
        .filter(el => el.getBoundingClientRect().width > 10);
    var dl = items.find(el => {
        var t = ((el.innerText || '') + ' ' + (el.getAttribute('aria-label') || '')).trim();
        return /fazer o download|baixar|download/i.test(t);
    });
    if (!dl) return null;
    var r = dl.getBoundingClientRect();
    return JSON.stringify({ x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) });
})()", ct);
                        if (dlItem != null) break;
                    }

                    if (dlItem != null) break;
                }

                if (!clickedDirectDownloadBtn && dlItem == null)
                {
                    await _cdp.PressEscapeAsync(sess, ct);
                    return null;
                }

                if (!clickedDirectDownloadBtn && dlItem != null)
                {
                    await _cdp.ClickAtAsync(sess, Convert.ToInt32(dlItem["x"]), Convert.ToInt32(dlItem["y"]), ct);
                }

                // Aguarda submenu de resolução (1K / 2K / Tamanho original) OU início imediato de download em stagingDl
                string clickedTierLabel = "";
                for (int subPoll = 0; subPoll < 6; subPoll++)
                {
                    await Task.Delay(320, ct);

                    string[] nowFiles = Directory.GetFiles(stagingDl);
                    bool anyNewFileStarted = nowFiles.Any(f => !beforeFiles.Contains(f));
                    if (anyNewFileStarted)
                        break;

                    Dictionary<string, object> subItem = await _cdp.EvalJsonAsync(sess, string.Format(@"
(function(){{
    var prefer2K = {0};
    var items = Array.from(document.querySelectorAll('.cdk-overlay-container [role=""menuitem""], [role=""menuitem""]'))
        .filter(el => {{
            var r = el.getBoundingClientRect();
            if (r.width <= 10 || r.height <= 10) return false;
            var dis = el.disabled || el.getAttribute('aria-disabled') === 'true';
            if (dis) return false;
            var txt = (el.innerText || '').trim();
            if (!txt) return false;
            if (/^(fazer o download|baixar|download)$/i.test(txt)) return false;
            if (/baixa|low\b|512|miniatura|thumb|upgrade|assine/i.test(txt)) return false;
            return /\b(1k|2k|4k)\b|original|tamanho|resolu|alta|high|png|jpg|jpeg/i.test(txt);
        }});
    if (items.length === 0) return null;

    function pickByRegex(re) {{
        return items.find(el => re.test((el.innerText || '').trim()));
    }}

    var target = null;
    if (prefer2K) {{
        target = pickByRegex(/\b2k\b/i) ||
                 pickByRegex(/\b1k\b|tamanho original|\boriginal\b/i) ||
                 pickByRegex(/alta|high|png|jpg|jpeg/i) ||
                 items[0];
    }} else {{
        target = pickByRegex(/\b1k\b|tamanho original|\boriginal\b/i) ||
                 pickByRegex(/\b2k\b/i) ||
                 pickByRegex(/alta|high|png|jpg|jpeg/i) ||
                 items[0];
    }}

    if (!target) return null;
    var r = target.getBoundingClientRect();
    return JSON.stringify({{
        label: (target.innerText || '').replace(/\s+/g, ' ').trim(),
        x: Math.round(r.left + r.width/2),
        y: Math.round(r.top + r.height/2)
    }});
}})()", prefer2K ? "true" : "false"), ct);

                    if (subItem != null)
                    {
                        clickedTierLabel = subItem.ContainsKey("label") ? Convert.ToString(subItem["label"] ?? "") : "";
                        await _cdp.ClickAtAsync(sess, Convert.ToInt32(subItem["x"]), Convert.ToInt32(subItem["y"]), ct);
                        break;
                    }
                }

                // Se escolheu 2K (pode levar alguns segundos fazendo upscale no Flow), aguarda até 45s; caso contrário 25s
                int waitMs = (!string.IsNullOrEmpty(clickedTierLabel) && clickedTierLabel.IndexOf("2K", StringComparison.OrdinalIgnoreCase) >= 0)
                    ? 45000
                    : 28000;

                string downloadedPath = await _cdp.WaitForSingleDownloadAsync(stagingDl, beforeFiles, 1024, waitMs, ct);
                if (!string.IsNullOrEmpty(downloadedPath) && File.Exists(downloadedPath))
                {
                    byte[] dlBytes = File.ReadAllBytes(downloadedPath);
                    try { File.Delete(downloadedPath); } catch { }
                    if (dlBytes != null && dlBytes.Length > 1024)
                        return dlBytes;
                }

                await _cdp.PressEscapeAsync(sess, ct);
            }
            catch (OperationCanceledException) { throw; }
            catch { }

            return null;
        }

        private async Task<byte[]> TryDownloadFlowImageViaLightboxAsync(
            string sess,
            string lookupToken,
            string stagingDl,
            CancellationToken ct)
        {
            if (string.IsNullOrEmpty(lookupToken))
                return null;

            bool openedLightbox = false;
            byte[] resultBytes = null;
            try
            {
                Dictionary<string, object> cardCenter = await ScrollToAndLocateTileByAsbIdAsync(sess, lookupToken, ct);
                if (cardCenter == null)
                    return null;

                await _cdp.ClickAtAsync(sess, Convert.ToInt32(cardCenter["x"]), Convert.ToInt32(cardCenter["y"]), ct);
                openedLightbox = true;
                await Task.Delay(1200, ct);

                // 1. Verifica se abriu um lightbox com uma imagem em alta resolução (>= 800px)
                Dictionary<string, object> lbInfo = await _cdp.EvalJsonAsync(sess, @"
(async function(){
    var imgs = Array.from(document.querySelectorAll('img')).filter(im => {
        var r = im.getBoundingClientRect();
        return r.width >= 260 && r.height >= 260 && im.complete && Math.max(im.naturalWidth || 0, im.naturalHeight || 0) >= 800;
    });
    imgs.sort((a, b) => ((b.naturalWidth || 0) * (b.naturalHeight || 0)) - ((a.naturalWidth || 0) * (a.naturalHeight || 0)));
    if (imgs.length > 0) {
        var best = imgs[0];
        var src = best.currentSrc || best.src || '';
        try {
            var resp = await fetch(src, { credentials: 'include' });
            if (resp.ok) {
                var blob = await resp.blob();
                if (typeof createImageBitmap === 'function') {
                    var bmp = await createImageBitmap(blob);
                    if (bmp && Math.max(bmp.width, bmp.height) >= 800) {
                        var c = document.createElement('canvas');
                        c.width = bmp.width;
                        c.height = bmp.height;
                        c.getContext('2d').drawImage(bmp, 0, 0);
                        if (typeof bmp.close === 'function') bmp.close();
                        var b64 = (c.toDataURL('image/jpeg', 0.96) || '').split(',')[1] || '';
                        if (b64.length > 2000) return JSON.stringify({ b64: b64, w: c.width, h: c.height });
                    }
                }
            }
        } catch(e) {}
        try {
            var c2 = document.createElement('canvas');
            c2.width = best.naturalWidth;
            c2.height = best.naturalHeight;
            c2.getContext('2d').drawImage(best, 0, 0);
            var b64c = (c2.toDataURL('image/jpeg', 0.96) || '').split(',')[1] || '';
            if (b64c.length > 2000) return JSON.stringify({ b64: b64c, w: c2.width, h: c2.height });
        } catch(e2) {}
    }

    // 2. Caso contrário, procura um botão de download visível dentro do visualizador/cabeçalho
    var dlBtn = Array.from(document.querySelectorAll('.cdk-overlay-container button, [role=""dialog""] button, header button')).find(b => {
        var r = b.getBoundingClientRect();
        if (r.width < 12 || r.height < 12) return false;
        var t = ((b.innerText || '') + ' ' + (b.getAttribute('aria-label') || '')).trim();
        return /fazer o download|baixar|\bdownload\b/i.test(t);
    });
    if (dlBtn) {
        var dr = dlBtn.getBoundingClientRect();
        return JSON.stringify({ dlX: Math.round(dr.left + dr.width/2), dlY: Math.round(dr.top + dr.height/2) });
    }
    return null;
})()", ct);

                if (lbInfo != null)
                {
                    if (lbInfo.ContainsKey("b64"))
                    {
                        string lbB64 = Convert.ToString(lbInfo["b64"] ?? "");
                        if (!string.IsNullOrEmpty(lbB64))
                        {
                            byte[] lbBytes = Convert.FromBase64String(lbB64);
                            if (lbBytes != null && lbBytes.Length > 2048)
                                resultBytes = lbBytes;
                        }
                    }
                    else if (lbInfo.ContainsKey("dlX") && !string.IsNullOrEmpty(stagingDl))
                    {
                        HashSet<string> beforeFiles = new HashSet<string>(Directory.GetFiles(stagingDl), StringComparer.OrdinalIgnoreCase);
                        await _cdp.ClickAtAsync(sess, Convert.ToInt32(lbInfo["dlX"]), Convert.ToInt32(lbInfo["dlY"]), ct);
                        await Task.Delay(500, ct);

                        // Se abriu submenu de resolução no lightbox, clica na opção de alta resolução (1K/2K/Original)
                        Dictionary<string, object> subItem = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var items = Array.from(document.querySelectorAll('.cdk-overlay-container [role=""menuitem""]'))
        .filter(el => el.getBoundingClientRect().width > 10 && !el.disabled && el.getAttribute('aria-disabled') !== 'true' &&
                      /\b(1k|2k)\b|original|alta|png|jpg|jpeg/i.test(el.innerText || '') &&
                      !/baixa|low\b|512/i.test(el.innerText || ''));
    if (items.length === 0) return null;
    var target = items.find(el => /\b2k\b/i.test(el.innerText || '')) ||
                 items.find(el => /\b1k\b|original/i.test(el.innerText || '')) ||
                 items[0];
    var r = target.getBoundingClientRect();
    return JSON.stringify({ x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) });
})()", ct);
                        if (subItem != null)
                        {
                            await _cdp.ClickAtAsync(sess, Convert.ToInt32(subItem["x"]), Convert.ToInt32(subItem["y"]), ct);
                        }

                        string dlPath = await _cdp.WaitForSingleDownloadAsync(stagingDl, beforeFiles, 1024, 30000, ct);
                        if (!string.IsNullOrEmpty(dlPath) && File.Exists(dlPath))
                        {
                            byte[] dlBytes = File.ReadAllBytes(dlPath);
                            try { File.Delete(dlPath); } catch { }
                            if (dlBytes != null && dlBytes.Length > 1024)
                                resultBytes = dlBytes;
                        }
                    }
                }
            }
            catch (OperationCanceledException) { throw; }
            catch { }

            if (openedLightbox)
            {
                try
                {
                    await _cdp.PressEscapeAsync(sess, ct);
                    await Task.Delay(350, ct);
                }
                catch { }
            }

            return resultBytes;
        }

        private async Task<bool> DownloadFlowGeneratedImageAsync(
            string sess,
            string readySrc,
            string asbId,
            string dstPath,
            string stagingDl,
            HashSet<string> savedMd5Hashes,
            CancellationToken ct)
        {
            const int MinHighResLongEdge = 800;
            try
            {
                string fileNameOnly = Path.GetFileName(dstPath ?? "");
                bool isCoverImage = fileNameOnly.StartsWith("Capa_", StringComparison.OrdinalIgnoreCase);

                // =========================================================================
                // ETAPA 1: Tenta obter ALTA RESOLUÇÃO (>= 800px) direto via URL atualizada
                //          (=s0 / =s2048 / sem ?width=512 / maior entrada do srcset).
                //          Se a URL retornar apenas miniatura (ex.: 286x512), guarda só como
                //          fallback de emergência e segue para o Download Nativo (1K/2K)!
                // =========================================================================
                string b64Src = Convert.ToBase64String(Encoding.UTF8.GetBytes(readySrc ?? ""));
                Dictionary<string, object> fetchRes = await _cdp.EvalJsonAsync(sess, string.Format(@"
(async function(){{
    var targetSrc = atob('{0}');
    var minHigh = {1};

    function buildCandidateUrls(u) {{
        var out = [];
        function add(x) {{
            if (x && x.length > 10 && out.indexOf(x) < 0) out.push(x);
        }}
        if (!u) return out;

        // 1. Verifica srcset no DOM caso exista versão de maior resolução
        try {{
            var im = Array.from(document.querySelectorAll('img')).find(x => (x.currentSrc || x.src || '') === u || (x.src || '').indexOf(u) >= 0);
            if (im && im.srcset) {{
                var parts = im.srcset.split(',').map(p => p.trim().split(/\s+/));
                parts.sort((a, b) => (parseInt(b[1] || '0', 10) || 0) - (parseInt(a[1] || '0', 10) || 0));
                if (parts.length > 0 && parts[0][0]) add(parts[0][0]);
            }}
        }} catch(e) {{}}

        // 2. URLs Google CDN com sufixo =w512 / =h512 / =s512 / =w286-h512 -> tenta =s0 (original) e =s2048
        if (/=(?:w|h|s)\d+[^/?#]*/i.test(u)) {{
            add(u.replace(/=(?:w|h|s)\d+[^/?#]*/i, '=s0'));
            add(u.replace(/=(?:w|h|s)\d+[^/?#]*/i, '=s2048'));
        }}

        // 3. URLs com parâmetros de query limitando resolução (?width=512, &w=512, &sz=512, &h=512)
        if (/[?&](?:width|height|w|h|sz|size)=\d+/i.test(u)) {{
            try {{
                var uObj1 = new URL(u, location.href);
                ['width', 'height', 'w', 'h', 'sz', 'size'].forEach(k => uObj1.searchParams.delete(k));
                add(uObj1.toString());

                var uObj2 = new URL(u, location.href);
                if (uObj2.searchParams.has('width')) uObj2.searchParams.set('width', '2048');
                if (uObj2.searchParams.has('w')) uObj2.searchParams.set('w', '2048');
                if (uObj2.searchParams.has('sz')) uObj2.searchParams.set('sz', '2048');
                if (uObj2.searchParams.has('height')) uObj2.searchParams.delete('height');
                if (uObj2.searchParams.has('h')) uObj2.searchParams.delete('h');
                add(uObj2.toString());
            }} catch(e) {{}}
        }}

        // 4. Por último, a própria URL original (pode já ser alta resolução ou miniatura 286x512)
        add(u);
        return out;
    }}

    async function decodeBlob(b) {{
        if (!b || b.size <= 1024) return null;
        try {{
            if (typeof createImageBitmap === 'function') {{
                var bmp = await createImageBitmap(b);
                if (bmp && bmp.width > 64 && bmp.height > 64) {{
                    var w = bmp.width;
                    var h = bmp.height;
                    var c = document.createElement('canvas');
                    c.width = w;
                    c.height = h;
                    c.getContext('2d').drawImage(bmp, 0, 0);
                    if (typeof bmp.close === 'function') bmp.close();
                    var jpegUrl = c.toDataURL('image/jpeg', 0.96);
                    var jpegB64 = (jpegUrl || '').split(',')[1] || '';
                    if (jpegB64.length > 1400) return {{ b64: jpegB64, w: w, h: h }};
                }}
            }}
        }} catch(e) {{}}
        return null;
    }}

    async function tryFetchUrl(url) {{
        var modes = [null, {{ credentials: 'include' }}];
        for (var m = 0; m < modes.length; m++) {{
            try {{
                var r = modes[m] ? await fetch(url, modes[m]) : await fetch(url);
                if (r && r.ok) {{
                    var b = await r.blob();
                    var dec = await decodeBlob(b);
                    if (dec) return dec;
                }}
            }} catch(e) {{}}
        }}
        return null;
    }}

    var candidates = buildCandidateUrls(targetSrc);
    var best = null;
    for (var i = 0; i < candidates.length; i++) {{
        var res = await tryFetchUrl(candidates[i]);
        if (!res) continue;
        if (!best || (res.w * res.h) > (best.w * best.h)) {{
            best = res;
        }}
        if (Math.max(res.w, res.h) >= minHigh) {{
            return JSON.stringify({{ b64: res.b64, w: res.w, h: res.h, highRes: true }});
        }}
    }}

    if (best) {{
        return JSON.stringify({{ b64: best.b64, w: best.w, h: best.h, highRes: false }});
    }}

    // Fallback via canvas direto da tag <img> no DOM
    try {{
        var im = Array.from(document.querySelectorAll('img')).find(x => (x.currentSrc || x.src || '') === targetSrc || (x.src || '').indexOf(targetSrc) >= 0);
        if (im && im.naturalWidth > 64 && im.naturalHeight > 64) {{
            var c2 = document.createElement('canvas');
            c2.width = im.naturalWidth;
            c2.height = im.naturalHeight;
            c2.getContext('2d').drawImage(im, 0, 0);
            var b64c = (c2.toDataURL('image/jpeg', 0.96) || '').split(',')[1] || '';
            if (b64c.length > 1400) {{
                return JSON.stringify({{ b64: b64c, w: im.naturalWidth, h: im.naturalHeight, highRes: Math.max(im.naturalWidth, im.naturalHeight) >= minHigh }});
            }}
        }}
    }} catch(e3) {{}}

    return null;
}})()", b64Src, MinHighResLongEdge), ct);

                byte[] highResBytes = null;
                byte[] lowResFallbackBytes = null;
                int bestW = 0;
                int bestH = 0;

                if (fetchRes != null && fetchRes.ContainsKey("b64"))
                {
                    string b64 = Convert.ToString(fetchRes["b64"] ?? "");
                    int fw = fetchRes.ContainsKey("w") ? Convert.ToInt32(fetchRes["w"]) : 0;
                    int fh = fetchRes.ContainsKey("h") ? Convert.ToInt32(fetchRes["h"]) : 0;
                    bool isHigh = fetchRes.ContainsKey("highRes") && Convert.ToBoolean(fetchRes["highRes"]);
                    if (!string.IsNullOrEmpty(b64))
                    {
                        byte[] decoded = Convert.FromBase64String(b64);
                        if (decoded != null && decoded.Length > 1024)
                        {
                            if (isHigh && Math.Max(fw, fh) >= MinHighResLongEdge)
                            {
                                highResBytes = decoded;
                                bestW = fw;
                                bestH = fh;
                            }
                            else
                            {
                                lowResFallbackBytes = decoded;
                                bestW = fw;
                                bestH = fh;
                            }
                        }
                    }
                }

                // =========================================================================
                // ETAPA 2: Se a URL do card só devolveu miniatura (ex.: 286x512), baixa
                //          em ALTA RESOLUÇÃO pelo menu nativo do Google Flow
                //          ("Mais opções" -> "Fazer o download" -> 2K / 1K / Original)!
                // =========================================================================
                string lookupToken = !string.IsNullOrEmpty(asbId) ? asbId : readySrc;
                if (highResBytes == null && !string.IsNullOrEmpty(stagingDl) && !string.IsNullOrEmpty(lookupToken))
                {
                    byte[] nativeDlBytes = await TryDownloadFlowImageViaNativeMenuAsync(sess, lookupToken, stagingDl, isCoverImage, ct);
                    // Se era Capa tentando 2K e não baixou (ex.: 2K bloqueado/timeout), tenta imediatamente 1K / Original!
                    if (nativeDlBytes == null && isCoverImage)
                    {
                        nativeDlBytes = await TryDownloadFlowImageViaNativeMenuAsync(sess, lookupToken, stagingDl, false, ct);
                    }

                    if (nativeDlBytes != null && nativeDlBytes.Length > 1024)
                    {
                        byte[] jpgBytes = EnsureHighQualityJpegBytes(nativeDlBytes, dstPath);
                        int nw, nh;
                        if (TryGetImageDimensionsFromBytes(jpgBytes, out nw, out nh))
                        {
                            if (Math.Max(nw, nh) >= MinHighResLongEdge || (nw * nh) > (bestW * bestH))
                            {
                                highResBytes = jpgBytes;
                                bestW = nw;
                                bestH = nh;
                            }
                        }
                        else
                        {
                            // Ex.: WebP de alta resolução baixado pelo Flow (GDI+ não lê WebP, mas o arquivo nativo é full-res)
                            highResBytes = nativeDlBytes;
                        }
                    }
                }

                // =========================================================================
                // ETAPA 3: Fallback via Lightbox em tela cheia (caso o menu do card não tenha
                //          conseguido baixar em alta resolução)
                // =========================================================================
                if (highResBytes == null && !string.IsNullOrEmpty(lookupToken))
                {
                    byte[] lbBytes = await TryDownloadFlowImageViaLightboxAsync(sess, lookupToken, stagingDl, ct);
                    if (lbBytes != null && lbBytes.Length > 1024)
                    {
                        byte[] jpgBytes = EnsureHighQualityJpegBytes(lbBytes, dstPath);
                        int lw, lh;
                        if (TryGetImageDimensionsFromBytes(jpgBytes, out lw, out lh))
                        {
                            if (Math.Max(lw, lh) >= MinHighResLongEdge || (lw * lh) > (bestW * bestH))
                            {
                                highResBytes = jpgBytes;
                                bestW = lw;
                                bestH = lh;
                            }
                        }
                        else
                        {
                            highResBytes = lbBytes;
                        }
                    }
                }

                // =========================================================================
                // ETAPA 4: Fallback final (WebClient / miniatura) apenas se todas as rotas
                //          de alta resolução falharem
                // =========================================================================
                byte[] finalBytes = highResBytes;
                bool usedLowResFallback = false;
                if (finalBytes == null && lowResFallbackBytes != null)
                {
                    finalBytes = lowResFallbackBytes;
                    usedLowResFallback = true;
                }

                if (finalBytes == null && !string.IsNullOrEmpty(readySrc) && readySrc.StartsWith("http", StringComparison.OrdinalIgnoreCase))
                {
                    try
                    {
                        using (System.Net.WebClient wc = new System.Net.WebClient())
                        {
                            byte[] data = wc.DownloadData(readySrc);
                            if (data != null && data.Length > 1024)
                            {
                                finalBytes = EnsureHighQualityJpegBytes(data, dstPath);
                                TryGetImageDimensionsFromBytes(finalBytes, out bestW, out bestH);
                                usedLowResFallback = Math.Max(bestW, bestH) < MinHighResLongEdge;
                            }
                        }
                    }
                    catch { }
                }

                if (finalBytes != null && finalBytes.Length > 1024)
                {
                    string md5 = ComputeBytesMd5Hex(finalBytes);
                    if (savedMd5Hashes != null && !string.IsNullOrEmpty(md5))
                    {
                        if (savedMd5Hashes.Contains(md5))
                        {
                            _log(string.Format("[Google Flow | Imagens 9:16] Aviso: Imagem ignorada para '{0}' pois possui o mesmo conteúdo (MD5 {1}) de outra imagem já salva.",
                                fileNameOnly, md5.Substring(0, Math.Min(8, md5.Length))));
                            return false;
                        }
                        savedMd5Hashes.Add(md5);
                    }

                    File.WriteAllBytes(dstPath, finalBytes);
                    int kb = Math.Max(1, finalBytes.Length / 1024);
                    if (usedLowResFallback)
                    {
                        _log(string.Format("[Google Flow | Imagens 9:16] Aviso: Não foi possível baixar versão HD (1K/2K) de '{0}'; salva miniatura ({1}x{2} | {3} KB).",
                            fileNameOnly, bestW, bestH, kb));
                    }
                    else if (bestW > 0 && bestH > 0)
                    {
                        _log(string.Format("[Google Flow | Imagens 9:16] ✔ '{0}' salva em alta resolução ({1}x{2} | {3} KB).",
                            fileNameOnly, bestW, bestH, kb));
                    }
                    return true;
                }
                else
                {
                    _log(string.Format("[Google Flow | Imagens 9:16] Aviso: Não foi possível extrair os bytes da imagem para '{0}'.", fileNameOnly));
                }
            }
            catch (OperationCanceledException)
            {
                throw;
            }
            catch (Exception ex)
            {
                _log(string.Format("[Google Flow | Imagens 9:16] Erro ao baixar '{0}': {1}", Path.GetFileName(dstPath), ex.Message));
            }
            return false;
        }

    }
}
