using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace FluxoVideoStudio
{
    public class CapCutWebVoiceAutomation
    {
        private readonly CdpController _cdp;
        private readonly PipelineConfig _config;
        private readonly Action<string> _log;

        public CapCutWebVoiceAutomation(CdpController cdp, PipelineConfig config, Action<string> logger)
        {
            _cdp = cdp;
            _config = config;
            _log = logger ?? delegate { };
        }

        private List<string> GetEffectiveProfiles()
        {
            List<string> list = new List<string>();
            if (_config.CapCutWebProfiles != null)
            {
                for (int i = 0; i < _config.CapCutWebProfiles.Count; i++)
                {
                    string p = (_config.CapCutWebProfiles[i] ?? "").Trim();
                    if (!string.IsNullOrEmpty(p) && !list.Contains(p, StringComparer.OrdinalIgnoreCase))
                        list.Add(p);
                }
            }
            if (list.Count == 0)
                list.Add("Default");
            return list;
        }

        private string GetTargetTtsUrl()
        {
            string u = (_config.CapCutWebTtsUrl ?? "").Trim();
            if (string.IsNullOrEmpty(u))
                return "https://www.capcut.com/magic-tools/text-to-speech";
            return u;
        }

        public async Task<bool> RunAsync(EpisodeWorkItem ep, CancellationToken ct)
        {
            if (ep == null || string.IsNullOrWhiteSpace(ep.UnifiedNarratorText))
            {
                _log("[CapCut Voz] Este episódio não possui falas de 'O Narrador:' (100% diálogo de personagens). Pulando síntese de voz!");
                return false;
            }

            if (!Directory.Exists(ep.TakesDir))
                Directory.CreateDirectory(ep.TakesDir);

            string narTxtOut = Path.Combine(ep.EpisodePath, "narrador_unificado.txt");
            File.WriteAllText(narTxtOut, ep.UnifiedNarratorText, new UTF8Encoding(false));

            string voiceName = _config.GetCapCutVoiceForEpisode(ep);
            _log(string.Format("[CapCut Voz] Categoria: {0} | Voz CapCut configurada: '{1}' ({2} caracteres)...",
                ep.GenreLabel, voiceName, ep.UnifiedNarratorText.Length));

            string rawMp3Dest = Path.Combine(ep.EpisodePath, "Narrador_Completo.mp3");
            List<string> profiles = GetEffectiveProfiles();
            bool generated = false;
            Exception lastErr = null;

            for (int pIdx = 0; pIdx < profiles.Count; pIdx++)
            {
                ct.ThrowIfCancellationRequested();
                string profile = profiles[pIdx];
                bool isLastProfile = (pIdx == profiles.Count - 1);

                try
                {
                    _log(string.Format("[CapCut Voz] Abrindo Conversão de Texto em Fala do CapCut no perfil '{0}'...", profile));
                    bool tryNextProfile = await TrySynthesizeEpisodeWithProfileAsync(
                        ep,
                        profile,
                        voiceName,
                        ep.UnifiedNarratorText,
                        rawMp3Dest,
                        isLastProfile,
                        ct);

                    if (tryNextProfile && !isLastProfile)
                    {
                        _log(string.Format("[CapCut Voz] Alternando automaticamente do perfil '{0}' para o próximo perfil configurado...", profile));
                        continue;
                    }

                    if (!tryNextProfile && File.Exists(rawMp3Dest) && new FileInfo(rawMp3Dest).Length > 2048)
                    {
                        generated = true;
                        break;
                    }
                }
                catch (OperationCanceledException)
                {
                    throw;
                }
                catch (Exception ex)
                {
                    lastErr = ex;
                    _log(string.Format("[CapCut Voz] Aviso no perfil '{0}': {1}", profile, ex.Message));
                }
            }

            if (!generated || !File.Exists(rawMp3Dest) || new FileInfo(rawMp3Dest).Length <= 2048)
            {
                throw new InvalidOperationException(
                    string.Format("Não foi possível gerar o áudio da voz '{0}' ({1}) no CapCut Web.", voiceName, ep.GenreLabel) +
                    (lastErr != null ? " Detalhe: " + lastErr.Message : ""));
            }

            // Remove eventuais áudios antigos do Narrador na pasta takes\ para não duplicar faixa no CapCut Desktop
            try
            {
                string[] oldAudios = Directory.GetFiles(ep.TakesDir)
                    .Where(f => Regex.IsMatch(Path.GetExtension(f), @"^\.(wav|mp3|m4a)$", RegexOptions.IgnoreCase))
                    .ToArray();
                for (int i = 0; i < oldAudios.Length; i++)
                {
                    try { File.Delete(oldAudios[i]); } catch { }
                }
            }
            catch { }

            string wavInTakes = Path.Combine(ep.TakesDir, "Narrador_Take_01.wav");
            string wavInEpRoot = Path.Combine(ep.EpisodePath, "Narrador_Completo.wav");
            ElevenLabsAutomation.RunSilenceTruncationToWav(_config, _log, rawMp3Dest, wavInTakes);
            File.Copy(wavInTakes, wavInEpRoot, true);

            EpisodeParser.RefreshDiskCounters(ep);
            _log(string.Format("[CapCut Voz + FFmpeg] ✔ Voz '{0}' ({1}) finalizada e silêncio truncado (-40dB / 0,3s): '{2}'",
                voiceName, ep.GenreLabel, wavInTakes));
            return true;
        }

        public async Task<List<string>> DiscoverVoicesFromCapCutWebAsync(CancellationToken ct)
        {
            await _cdp.EnsureConnectedAsync(ct);
            List<string> profiles = GetEffectiveProfiles();
            string chosenProfile = profiles[0];
            string sess = null;

            for (int i = 0; i < profiles.Count; i++)
            {
                chosenProfile = profiles[i];
                bool isLast = (i == profiles.Count - 1);
                sess = await _cdp.OpenOrAttachProfileTabAsync(
                    chosenProfile,
                    GetTargetTtsUrl(),
                    "capcut.com",
                    false,
                    ct);

                await WaitForCapCutPageHydratedAsync(sess, ct);
                await DismissCapCutTooltipsAndModalsAsync(sess, ct);

                if (await IsCapCutLoginWallVisibleAsync(sess, ct))
                {
                    if (!isLast)
                        continue;

                    _log(string.Format("[CapCut Voz | Login] Faça login na sua conta do CapCut na janela do Chrome aberta (perfil '{0}') — aguardando até 90s...", chosenProfile));
                    bool loggedIn = await WaitForUserLoginIfNeededAsync(sess, 90, ct);
                    if (!loggedIn)
                        throw new InvalidOperationException("Login no CapCut Web não concluído dentro do tempo limite. Faça login no Chrome e clique novamente.");
                }
                break;
            }

            await DismissCapCutTooltipsAndModalsAsync(sess, ct);
            List<string> discovered = new List<string>();
            HashSet<string> seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            // 1. Coleta PRIMEIRO todas as vozes de "Favoritos" (colocando-as no topo da lista!)
            if (await TryOpenFavoritesFilterOrTabAsync(sess, ct))
            {
                await Task.Delay(850, ct);
                List<string> favVoices = new List<string>();
                await CollectVoicesInCurrentGridAsync(sess, favVoices, seen, 25, ct);
                for (int i = 0; i < favVoices.Count; i++)
                    discovered.Add(favVoices[i]);

                if (favVoices.Count > 0)
                    _log(string.Format("[CapCut Voz] ★ {0} voz(es) encontrada(s) em Favoritos: {1}", favVoices.Count, string.Join(", ", favVoices)));
            }

            // 2. Verifica "Minhas vozes" / "Personalizadas" caso haja vozes clonadas
            if (await TryClickVoiceHeaderTabAsync(sess, new[] { "minhas vozes", "my voices", "personaliz", "custom" }, ct))
            {
                await Task.Delay(700, ct);
                await CollectVoicesInCurrentGridAsync(sess, discovered, seen, 15, ct);
                await TryClickVoiceHeaderTabAsync(sess, new[] { "biblioteca", "library" }, ct);
                await Task.Delay(600, ct);
            }

            // 3. Filtra por "Português" na Biblioteca (mesmo quando a pílula está fora da tela no carrossel horizontal!)
            if (await TryClickFilterTagAsync(sess, new[] { "português", "portugues", "portuguese" }, ct))
            {
                await Task.Delay(900, ct);
                await CollectVoicesInCurrentGridAsync(sess, discovered, seen, 60, ct);
            }

            // 4. Complementa com o topo de "Tudo" caso queira vozes multilíngues populares
            if (await TryClickFilterTagAsync(sess, new[] { "tudo", "all" }, ct))
            {
                await Task.Delay(750, ct);
                await CollectVoicesInCurrentGridAsync(sess, discovered, seen, 15, ct);
            }

            if (discovered.Count > 0)
            {
                _config.DiscoveredCapCutVoices = discovered;
                _config.SaveUserSettings();
            }

            return discovered;
        }

        private async Task CollectVoicesInCurrentGridAsync(
            string sess,
            List<string> outVoices,
            HashSet<string> seen,
            int maxScrollSteps,
            CancellationToken ct)
        {
            await ResetVoiceGridScrollTopAsync(sess, ct);

            for (int step = 0; step < maxScrollSteps; step++)
            {
                ct.ThrowIfCancellationRequested();
                string csv = await _cdp.EvalStringAsync(sess, @"
(function(){
    var cards = Array.from(document.querySelectorAll('[class*=""toneItem-""]')).filter(function(el){
        return el.className.indexOf('toneItem__') < 0 && el.getBoundingClientRect().width > 30;
    });
    var names = [];
    for (var i = 0; i < cards.length; i++) {
        var nmEl = cards[i].querySelector('[class*=""toneItem__name""]');
        var imgEl = cards[i].querySelector('img[alt]');
        var nm = nmEl ? (nmEl.innerText || '').trim() : (imgEl ? (imgEl.getAttribute('alt') || '').trim() : '');
        nm = nm.split(/\r?\n/)[0].trim();
        if (nm.length > 0) names.push(nm);
    }
    return names.join('|');
})()", ct);

                if (!string.IsNullOrEmpty(csv))
                {
                    string[] parts = csv.Split(new[] { '|' }, StringSplitOptions.RemoveEmptyEntries);
                    for (int i = 0; i < parts.Length; i++)
                    {
                        string v = parts[i].Trim();
                        if (!string.IsNullOrEmpty(v) && seen.Add(v))
                            outVoices.Add(v);
                    }
                }

                bool moved = await StepVoiceGridScrollAsync(sess, 0, ct);
                if (!moved)
                    break;
                await Task.Delay(145, ct);
            }

            await ResetVoiceGridScrollTopAsync(sess, ct);
        }

        private async Task<bool> TrySynthesizeEpisodeWithProfileAsync(
            EpisodeWorkItem ep,
            string profile,
            string voiceName,
            string unifiedText,
            string destMp3Path,
            bool waitIfLoginNeeded,
            CancellationToken ct)
        {
            string url = GetTargetTtsUrl();
            string sess = await _cdp.OpenOrAttachProfileTabAsync(
                profile,
                url,
                "capcut.com",
                true,
                ct);

            await WaitForCapCutPageHydratedAsync(sess, ct);
            await DismissCapCutTooltipsAndModalsAsync(sess, ct);

            if (await IsCapCutLoginWallVisibleAsync(sess, ct))
            {
                if (!waitIfLoginNeeded)
                {
                    _log(string.Format("[CapCut Voz] Perfil '{0}' não está logado no CapCut Web.", profile));
                    return true;
                }

                _log(string.Format("[CapCut Voz | Login Necessário] A janela 'Boas-vindas ao CapCut' apareceu no perfil '{0}'. Faça login uma única vez na janela aberta do Chrome (ex: 'Continuar com Google' ou TikTok) — aguardando até 90s automaticamente...", profile));
                bool signedIn = await WaitForUserLoginIfNeededAsync(sess, 90, ct);
                if (!signedIn)
                    throw new InvalidOperationException(string.Format("O perfil '{0}' precisa estar logado em capcut.com. Faça login na janela do Chrome e execute novamente.", profile));

                await Task.Delay(1500, ct);
                await DismissCapCutTooltipsAndModalsAsync(sess, ct);
            }

            await WaitForCapCutTtsEditorReadyAsync(sess, ct);
            await DismissCapCutTooltipsAndModalsAsync(sess, ct);

            // 1. Selecionar a voz configurada para o tipo de vídeo
            string matchedVoice = await SelectCapCutVoiceByNameAsync(sess, voiceName, ct);
            _log(string.Format("[CapCut Voz] ✔ Voz selecionada no CapCut Web: '{0}'", matchedVoice));

            // 2. Verificar limite de caracteres do editor e dividir em partes apenas se necessário
            int detectedMaxChars = await DetectEditorMaxCharactersAsync(sess, ct);
            List<string> chunks = SplitNarratorTextIntoSafeChunks(unifiedText, detectedMaxChars);

            string tempWorkDir = Path.Combine(ep.TakesDir, "_capcut_tts_" + DateTime.Now.ToString("HHmmss"));
            Directory.CreateDirectory(tempWorkDir);
            List<string> chunkAudioFiles = new List<string>();

            try
            {
                for (int cIdx = 0; cIdx < chunks.Count; cIdx++)
                {
                    ct.ThrowIfCancellationRequested();
                    string chunkText = chunks[cIdx];

                    LastActionHistoryStore.RecordAction(
                        ep,
                        "CapCut Voz",
                        string.Format("Gerando voz '{0}' ({1}) no CapCut Web (parte {2}/{3})", matchedVoice, ep.GenreLabel, cIdx + 1, chunks.Count),
                        profile,
                        sess,
                        url,
                        "Narrador_Completo.mp3",
                        cIdx + 1,
                        chunks.Count,
                        chunkText,
                        null,
                        "EmExecucao");

                    if (chunks.Count > 1)
                        _log(string.Format("[CapCut Voz] Inserindo parte {0}/{1} do texto do Narrador ({2} caracteres)...", cIdx + 1, chunks.Count, chunkText.Length));
                    else
                        _log(string.Format("[CapCut Voz] Inserindo texto do Narrador ({0} caracteres)...", chunkText.Length));

                    int acceptedChars = await InsertTextIntoSlateEditorAsync(sess, chunkText, ct);
                    if (acceptedChars <= 0)
                        throw new InvalidOperationException("Não foi possível inserir o texto do Narrador na caixa de texto do CapCut Web.");

                    // Se o CapCut truncou um texto grande em um limite menor não exibido (ex: 500 ou 1500 chars), redivide automaticamente!
                    if (chunks.Count == 1 && chunkText.Length > 350 && acceptedChars > 100 && acceptedChars < chunkText.Length - 35)
                    {
                        int safeCap = Math.Max(250, acceptedChars - 35);
                        _log(string.Format("[CapCut Voz] Limite por envio detectado no editor ({0} caracteres) -> dividindo locução automaticamente em partes de até {1} caracteres...",
                            acceptedChars, safeCap));
                        chunks = SplitNarratorTextIntoSafeChunks(unifiedText, safeCap);
                        cIdx = -1;
                        chunkAudioFiles.Clear();
                        continue;
                    }

                    await Task.Delay(650, ct);
                    string chunkOut = Path.Combine(tempWorkDir, string.Format("chunk_{0:00}.mp3", cIdx + 1));
                    bool blockedOrQuota = await GenerateAndCaptureAudioChunkAsync(
                        ep,
                        sess,
                        matchedVoice,
                        chunkText,
                        tempWorkDir,
                        chunkOut,
                        ct);

                    if (blockedOrQuota)
                        return true;

                    chunkAudioFiles.Add(chunkOut);
                }

                if (chunkAudioFiles.Count == 1)
                {
                    File.Copy(chunkAudioFiles[0], destMp3Path, true);
                }
                else
                {
                    ConcatenateAudioChunksWithFfmpeg(chunkAudioFiles, destMp3Path);
                }
            }
            finally
            {
                string cleanupDir = tempWorkDir;
                Task ignoredCleanup = Task.Run(async () =>
                {
                    try { await _cdp.ResetDownloadBehaviorToDefaultAsync(); } catch { }
                    try { Directory.Delete(cleanupDir, true); } catch { }
                });
            }

            return false;
        }

        private async Task WaitForCapCutPageHydratedAsync(string sess, CancellationToken ct)
        {
            DateTime deadline = DateTime.UtcNow.AddSeconds(28);
            while (DateTime.UtcNow < deadline)
            {
                ct.ThrowIfCancellationRequested();
                string st = await _cdp.EvalStringAsync(sess, @"
(function(){
    var login = document.querySelector('.lv_sign_in_panel_wide_base_page');
    if (login && login.getBoundingClientRect().width > 80) return 'LOGIN';
    var ed = document.querySelector('[data-slate-editor=""true""], [contenteditable=""true""], textarea');
    var tones = document.querySelectorAll('[class*=""toneItem-""]');
    if (ed && tones.length > 0) return 'READY';
    if (ed) return 'EDITOR_ONLY';
    return 'WAIT';
})()", ct);
                if (st == "READY" || st == "LOGIN")
                {
                    await Task.Delay(900, ct);
                    return;
                }
                await Task.Delay(500, ct);
            }
        }

        private async Task WaitForCapCutTtsEditorReadyAsync(string sess, CancellationToken ct)
        {
            DateTime deadline = DateTime.UtcNow.AddSeconds(25);
            while (DateTime.UtcNow < deadline)
            {
                ct.ThrowIfCancellationRequested();
                string st = await _cdp.EvalStringAsync(sess, @"
(function(){
    var ed = Array.from(document.querySelectorAll('[data-slate-editor=""true""], div[contenteditable=""true""], textarea')).find(function(el){
        var r = el.getBoundingClientRect();
        return r.width > 140 && r.height > 40;
    });
    var genBtn = Array.from(document.querySelectorAll('button[class*=""generateButton""], button')).find(function(b){
        var txt = (b.innerText || '').trim().toLowerCase();
        var r = b.getBoundingClientRect();
        return r.width > 40 && r.height > 20 &&
               (b.className.indexOf('generateButton') >= 0 || txt === 'gerar' || txt === 'generate' || txt.indexOf('gerar') === 0);
    });
    return (ed && genBtn) ? 'READY' : 'WAIT';
})()", ct);
                if (st == "READY")
                {
                    await Task.Delay(700, ct);
                    return;
                }
                await Task.Delay(450, ct);
            }
        }

        private async Task<bool> IsCapCutLoginWallVisibleAsync(string sess, CancellationToken ct)
        {
            string res = await _cdp.EvalStringAsync(sess, @"
(function(){
    var modal = document.querySelector('.lv_sign_in_panel_wide_base_page, .lv_sign_in_panel_wide-right-wrapper');
    if (modal && modal.getBoundingClientRect().width > 80 && modal.getBoundingClientRect().height > 80)
        return 'LOGIN';
    var h2s = Array.from(document.querySelectorAll('h1, h2, h3, div')).filter(function(el){
        var t = (el.innerText || '').trim();
        return (t === 'Boas-vindas ao CapCut' || t === 'Welcome to CapCut') && el.getBoundingClientRect().width > 60;
    });
    return h2s.length > 0 ? 'LOGIN' : 'OK';
})()", ct);
            return res == "LOGIN";
        }

        private async Task<bool> WaitForUserLoginIfNeededAsync(string sess, int maxSeconds, CancellationToken ct)
        {
            DateTime deadline = DateTime.UtcNow.AddSeconds(maxSeconds);
            while (DateTime.UtcNow < deadline)
            {
                ct.ThrowIfCancellationRequested();
                await Task.Delay(1500, ct);
                if (!await IsCapCutLoginWallVisibleAsync(sess, ct))
                    return true;
            }
            return !await IsCapCutLoginWallVisibleAsync(sess, ct);
        }

        private async Task DismissCapCutTooltipsAndModalsAsync(string sess, CancellationToken ct)
        {
            await _cdp.EvalStringAsync(sess, @"
(function(){
    var btns = Array.from(document.querySelectorAll('button, [role=""button""]'));
    for (var i = 0; i < btns.length; i++) {
        var b = btns[i];
        if (b.closest('.lv_sign_in_panel_wide_base_page, .lv_sign_in_panel_wide-right-wrapper')) continue;
        var txt = (b.innerText || '').trim().toLowerCase();
        var al = (b.getAttribute('aria-label') || '').trim().toLowerCase();
        var r = b.getBoundingClientRect();
        if (r.width < 8 || r.height < 8) continue;
        if (txt === 'ignorar' || txt === 'skip' || txt === 'entendi' || txt === 'got it' || txt === 'agora não' || txt === 'not now') {
            try { b.click(); } catch(e) {}
            continue;
        }
        if ((al === 'close' || al === 'fechar') && b.closest('[role=""dialog""], .lv-modal, [class*=""guide""], [class*=""tooltip""]')) {
            try { b.click(); } catch(e) {}
        }
    }
    return 'OK';
})()", ct);
        }

        private async Task<bool> TryOpenFavoritesFilterOrTabAsync(string sess, CancellationToken ct)
        {
            Dictionary<string, object> favInfo = await _cdp.EvalJsonAsync(sess, @"
(function(){
    function norm(s) {
        return (s || '').trim().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/\(\s*\d+\s*\)/g, '').trim();
    }
    var favWords = ['favoritos', 'favorito', 'favorites', 'favorite', 'salvos', 'salvo', 'saved', 'colecao', 'colecoes', 'collected', 'starred', 'vozes salvas'];

    // 1. Pílula ou aba com texto explícito de Favoritos / Salvos / Coleção (dentro ou fora da viewport horizontal)
    var allRight = Array.from(document.querySelectorAll('[class*=""tagItem-""], .lv-tabs-header-title, [role=""tab""], button, div, span, li')).filter(function(el){
        if (el.closest('[class*=""toneItem-""]')) return false;
        if (el.children.length > 3) return false;
        var r = el.getBoundingClientRect();
        return r.height >= 14 && r.height <= 56 && r.top >= 55 && r.top <= 460 && (r.left > 300 || el.className.indexOf('tagItem') >= 0);
    });

    var target = allRight.find(function(el){
        var t = norm(el.innerText || '');
        if (!t) return false;
        return favWords.indexOf(t) >= 0;
    });

    // 2. Botão/aba/pílula por aria-label, title ou className (ex.: ícone de estrela/marcador no cabeçalho ou barra de filtros)
    if (!target) {
        target = Array.from(document.querySelectorAll('[class*=""tagItem-""], [role=""tab""], button, div, span')).find(function(el){
            if (el.closest('[class*=""toneItem-""]')) return false;
            if (el.children.length > 4) return false;
            var r = el.getBoundingClientRect();
            if (r.width < 12 || r.width > 180 || r.height < 14 || r.height > 56 || r.top < 55 || r.top > 450 || r.left < 300) return false;
            var meta = ((el.getAttribute('aria-label') || '') + ' ' + (el.getAttribute('title') || '') + ' ' + (typeof el.className === 'string' ? el.className : '')).toLowerCase();
            return /favorit|collect|bookmark|starred|saved/.test(meta);
        });
    }

    // 3. Pílula somente-ícone (estrela/favorito sem texto) imediatamente ao lado de 'Tudo' na barra sliding-container
    if (!target) {
        var tagItems = Array.from(document.querySelectorAll('[class*=""sliding-container""] [class*=""tagItem-""], [class*=""tagItem-""]'));
        target = tagItems.find(function(el){
            var txt = (el.innerText || '').trim();
            return txt === '' && !!el.querySelector('svg') && el.getBoundingClientRect().height >= 14;
        });
    }

    if (!target) return null;

    var r = target.getBoundingClientRect();
    var onScreen = r.width >= 10 && r.left >= 0 && r.right <= window.innerWidth && r.top >= 0 && r.bottom <= window.innerHeight;
    if (!onScreen) {
        try { target.click(); } catch(e) {}
        return JSON.stringify({ clickedDom: true, x: 0, y: 0 });
    }
    return JSON.stringify({
        clickedDom: false,
        x: Math.round(r.left + r.width / 2),
        y: Math.round(r.top + r.height / 2)
    });
})()", ct);

            if (favInfo == null)
                return false;

            if (!Convert.ToBoolean(favInfo["clickedDom"]))
            {
                await _cdp.ClickAtAsync(sess, Convert.ToInt32(favInfo["x"]), Convert.ToInt32(favInfo["y"]), ct);
            }
            return true;
        }

        private async Task<bool> TryClickVoiceHeaderTabAsync(string sess, string[] tabKeywords, CancellationToken ct)
        {
            string b64Kw = Convert.ToBase64String(Encoding.UTF8.GetBytes(string.Join("|", tabKeywords)));
            Dictionary<string, object> pt = await _cdp.EvalJsonAsync(sess, string.Format(@"
(function(){{
    var kws = new TextDecoder('utf-8').decode(Uint8Array.from(atob('{0}'), function(c){{ return c.charCodeAt(0); }})).toLowerCase().split('|');
    function norm(s) {{
        return (s || '').trim().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    }}
    var tabs = Array.from(document.querySelectorAll('.lv-tabs-header-title, [role=""tab""], [class*=""tab""], div, span')).filter(function(el){{
        if (el.closest('[class*=""toneItem-""]')) return false;
        if (el.children.length > 2) return false;
        var r = el.getBoundingClientRect();
        return r.width > 25 && r.height > 14 && r.height < 56 && r.left > 320 && r.top > 55 && r.top < 420;
    }});
    for (var i = 0; i < tabs.length; i++) {{
        var txt = norm(tabs[i].innerText || '');
        if (!txt || txt.length > 35) continue;
        for (var k = 0; k < kws.length; k++) {{
            var kw = norm(kws[k]);
            if (kw.length > 0 && (txt === kw || txt.indexOf(kw + ' (') === 0 || txt.indexOf(kw + '(') === 0)) {{
                var r = tabs[i].getBoundingClientRect();
                return JSON.stringify({{ x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) }});
            }}
        }}
    }}
    return null;
}})()", b64Kw), ct);

            if (pt == null) return false;
            await _cdp.ClickAtAsync(sess, Convert.ToInt32(pt["x"]), Convert.ToInt32(pt["y"]), ct);
            return true;
        }

        private async Task<bool> TryClickFilterTagAsync(string sess, string[] tagLabels, CancellationToken ct)
        {
            string b64Tags = Convert.ToBase64String(Encoding.UTF8.GetBytes(string.Join("|", tagLabels)));
            Dictionary<string, object> pt = await _cdp.EvalJsonAsync(sess, string.Format(@"
(function(){{
    var want = new TextDecoder('utf-8').decode(Uint8Array.from(atob('{0}'), function(c){{ return c.charCodeAt(0); }})).toLowerCase().split('|');
    function norm(s) {{
        return (s || '').trim().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/\(\s*\d+\s*\)/g, '').trim();
    }}
    var wantNorm = want.map(norm);
    var pills = Array.from(document.querySelectorAll('[class*=""tagItem-""], [class*=""sliding-container""] div')).filter(function(el){{
        return el.children.length <= 3 && el.getBoundingClientRect().height > 14 && el.getBoundingClientRect().height < 52;
    }});
    var target = pills.find(function(el){{
        var t = norm(el.innerText || '');
        return wantNorm.indexOf(t) >= 0;
    }});
    if (!target) return null;

    var r = target.getBoundingClientRect();
    var onScreen = r.width >= 10 && r.left >= 0 && r.right <= window.innerWidth - 4;
    if (!onScreen) {{
        // Quando a pílula (ex.: 'Português') está deslocada fora da janela pelo transform: translateX do carrossel, aciona o onClick React direto!
        try {{ target.click(); }} catch(e) {{}}
        return JSON.stringify({{ clickedDom: true, x: 0, y: 0 }});
    }}
    return JSON.stringify({{ clickedDom: false, x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) }});
}})()", b64Tags), ct);

            if (pt == null) return false;
            if (!Convert.ToBoolean(pt["clickedDom"]))
            {
                await Task.Delay(120, ct);
                await _cdp.ClickAtAsync(sess, Convert.ToInt32(pt["x"]), Convert.ToInt32(pt["y"]), ct);
            }
            return true;
        }

        private async Task ResetVoiceGridScrollTopAsync(string sess, CancellationToken ct)
        {
            await _cdp.EvalStringAsync(sess, @"
(function(){
    var grid = document.querySelector('.ReactVirtualized__Collection[role=""grid""]') ||
               document.querySelector('.ReactVirtualized__Collection') ||
               Array.from(document.querySelectorAll('div')).find(function(d){
                   return d.scrollHeight > d.clientHeight + 40 && d.querySelector('[class*=""toneItem-""]');
               });
    if (grid && grid.scrollTop > 0) grid.scrollTop = 0;
    return 'OK';
})()", ct);
            await Task.Delay(150, ct);
        }

        private async Task<bool> StepVoiceGridScrollAsync(string sess, int deltaPx, CancellationToken ct)
        {
            string res = await _cdp.EvalStringAsync(sess, string.Format(@"
(function(){{
    var grid = document.querySelector('.ReactVirtualized__Collection[role=""grid""]') ||
               document.querySelector('.ReactVirtualized__Collection') ||
               Array.from(document.querySelectorAll('div')).find(function(d){{
                   return d.scrollHeight > d.clientHeight + 40 && d.querySelector('[class*=""toneItem-""]');
               }});
    if (!grid) return 'NO_GRID';
    if (grid.scrollTop + grid.clientHeight >= grid.scrollHeight - 4) return 'END';
    var step = {0} > 0 ? {0} : Math.max(240, Math.floor(grid.clientHeight * 0.80));
    var nextTop = Math.min(grid.scrollHeight - grid.clientHeight, grid.scrollTop + step);
    if (nextTop <= grid.scrollTop + 2) return 'END';
    grid.scrollTop = nextTop;
    return 'MOVED';
}})()", deltaPx), ct);
            return res == "MOVED";
        }

        private async Task<bool> TryJumpVoiceGridViaReactFiberAsync(string sess, string wantedVoiceName, CancellationToken ct)
        {
            string b64Want = Convert.ToBase64String(Encoding.UTF8.GetBytes(wantedVoiceName ?? ""));
            string res = await _cdp.EvalStringAsync(sess, string.Format(@"
(function(){{
    var rawWant = new TextDecoder('utf-8').decode(Uint8Array.from(atob('{0}'), function(c){{ return c.charCodeAt(0); }})).trim();
    function normAlnum(s) {{
        return (s || '').trim().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9\s]/g, '').replace(/\s+/g, ' ').trim();
    }}
    var wantKey = normAlnum(rawWant);
    if (!wantKey) return 'NONE';

    var grid = document.querySelector('.ReactVirtualized__Collection[role=""grid""]') ||
               document.querySelector('.ReactVirtualized__Collection');
    if (!grid) return 'NO_GRID';

    var fiberKey = Object.keys(grid).find(function(k){{ return k.indexOf('__reactFiber$') === 0 || k.indexOf('__reactInternalInstance$') === 0; }});
    if (!fiberKey) return 'NO_FIBER';

    function extractItemName(obj) {{
        if (!obj || typeof obj !== 'object') return '';
        return String(obj.name || obj.title || obj.tone_name || obj.toneName || obj.display_name || obj.displayName || obj.speaker_name || '');
    }}

    function findVoiceArray(rootObj, depth) {{
        if (!rootObj || typeof rootObj !== 'object' || depth > 4) return null;
        if (Array.isArray(rootObj) && rootObj.length >= 2 && typeof rootObj[0] === 'object' && extractItemName(rootObj[0]).length > 0) {{
            return rootObj;
        }}
        var keys = Object.keys(rootObj);
        for (var i = 0; i < Math.min(keys.length, 35); i++) {{
            var k = keys[i];
            if (k === 'children' || k === 'return' || k === 'stateNode' || k === 'sibling' || k === '_owner') continue;
            try {{
                var v = rootObj[k];
                if (Array.isArray(v) && v.length >= 2 && typeof v[0] === 'object' && extractItemName(v[0]).length > 0) {{
                    return v;
                }}
                if (v && typeof v === 'object' && !Array.isArray(v) && depth < 2) {{
                    var sub = findVoiceArray(v, depth + 1);
                    if (sub) return sub;
                }}
            }} catch(e) {{}}
        }}
        return null;
    }}

    var cur = grid[fiberKey];
    var voiceArr = null;
    for (var up = 0; up < 16 && cur; up++) {{
        voiceArr = findVoiceArray(cur.memoizedProps, 0) || findVoiceArray(cur.memoizedState, 0);
        if (voiceArr) break;
        cur = cur.return;
    }}
    if (!voiceArr || voiceArr.length === 0) return 'NO_ARRAY';

    var foundIdx = -1;
    for (var idx = 0; idx < voiceArr.length; idx++) {{
        var nm = normAlnum(extractItemName(voiceArr[idx]));
        if (nm === wantKey) {{ foundIdx = idx; break; }}
    }}
    if (foundIdx < 0) {{
        for (var idx2 = 0; idx2 < voiceArr.length; idx2++) {{
            var nm2 = normAlnum(extractItemName(voiceArr[idx2]));
            if (nm2.length > 0 && (nm2.indexOf(wantKey) >= 0 || (wantKey.length >= 4 && wantKey.indexOf(nm2) >= 0))) {{
                foundIdx = idx2;
                break;
            }}
        }}
    }}
    if (foundIdx < 0) return 'NOT_IN_ARRAY';

    var totalRows = Math.max(1, Math.ceil(voiceArr.length / 2));
    var estRowHeight = grid.scrollHeight / totalRows;
    var targetRow = Math.floor(foundIdx / 2);
    var targetScroll = Math.max(0, Math.min(grid.scrollHeight - grid.clientHeight, Math.round(targetRow * estRowHeight - grid.clientHeight * 0.25)));
    grid.scrollTop = targetScroll;
    return 'JUMPED:' + foundIdx;
}})()", b64Want), ct);

            if (!string.IsNullOrEmpty(res) && res.StartsWith("JUMPED:", StringComparison.Ordinal))
            {
                await Task.Delay(280, ct);
                return true;
            }
            return false;
        }

        private async Task<Dictionary<string, object>> FindMountedVoiceCardPointAsync(
            string sess,
            string wantedVoiceName,
            bool allowSubstringMatch,
            CancellationToken ct)
        {
            string b64Want = Convert.ToBase64String(Encoding.UTF8.GetBytes(wantedVoiceName ?? ""));
            return await _cdp.EvalJsonAsync(sess, string.Format(@"
(function(){{
    var rawWant = new TextDecoder('utf-8').decode(Uint8Array.from(atob('{0}'), function(c){{ return c.charCodeAt(0); }})).trim();
    function norm(s) {{
        return (s || '').trim().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/\s+/g, ' ').trim();
    }}
    function normAlnum(s) {{
        return norm(s).replace(/[^a-z0-9\s]/g, '').replace(/\s+/g, ' ').trim();
    }}
    var wantNorm = norm(rawWant);
    var wantAlnum = normAlnum(rawWant);
    if (!wantNorm && !wantAlnum) return null;

    var grid = document.querySelector('.ReactVirtualized__Collection[role=""grid""]') ||
               document.querySelector('.ReactVirtualized__Collection');
    var gridRect = grid ? grid.getBoundingClientRect() : null;

    var cards = Array.from(document.querySelectorAll('[class*=""toneItem-""]')).filter(function(el){{
        return el.className.indexOf('toneItem__') < 0 && el.getBoundingClientRect().width > 30 && el.getBoundingClientRect().height > 20;
    }});
    if (cards.length === 0) return null;

    function getCardName(el) {{
        var nmEl = el.querySelector('[class*=""toneItem__name""]');
        var imgEl = el.querySelector('img[alt]');
        var nm = nmEl ? (nmEl.innerText || '').trim() : (imgEl ? (imgEl.getAttribute('alt') || '').trim() : (el.innerText || '').trim());
        return nm.split(/\r?\n/)[0].trim();
    }}

    var chosen = cards.find(function(el){{
        var raw = getCardName(el);
        var cn = norm(raw);
        var ca = normAlnum(raw);
        return (wantNorm.length > 0 && cn === wantNorm) || (wantAlnum.length >= 2 && ca === wantAlnum);
    }});

    if (!chosen && {1}) {{
        chosen = cards.find(function(el){{
            var ca = normAlnum(getCardName(el));
            return ca.length > 0 && wantAlnum.length >= 3 && (ca.indexOf(wantAlnum) >= 0 || (wantAlnum.length >= 4 && wantAlnum.indexOf(ca) >= 0));
        }});
    }}

    if (!chosen) return null;

    var r = chosen.getBoundingClientRect();
    if (grid && gridRect) {{
        if (r.top < gridRect.top + 6 || r.bottom > gridRect.bottom - 6) {{
            var targetTop = Math.max(0, grid.scrollTop + (r.top - (gridRect.top + gridRect.height / 2 - r.height / 2)));
            grid.scrollTop = targetTop;
            r = chosen.getBoundingClientRect();
        }}
    }}

    // Clica exatamente em cima do nome da voz (evitando o botão Play do avatar à esquerda e a estrela de Favoritar na borda direita!)
    var nmTarget = chosen.querySelector('[class*=""toneItem__name""]');
    var nr = nmTarget ? nmTarget.getBoundingClientRect() : null;
    var clickX = (nr && nr.width > 8)
        ? Math.round(nr.left + Math.min(28, nr.width / 2))
        : Math.round(r.left + Math.min(82, r.width * 0.48));
    var clickY = (nr && nr.height > 6)
        ? Math.round(nr.top + nr.height / 2)
        : Math.round(r.top + r.height / 2);

    // Garante ativação do handler React onClick caso um overlay intercepte o hover
    try {{ chosen.click(); }} catch(e) {{}}

    return JSON.stringify({{
        name: getCardName(chosen),
        x: clickX,
        y: clickY
    }});
}})()", b64Want, allowSubstringMatch ? "true" : "false"), ct);
        }

        private async Task<Dictionary<string, object>> SweepCurrentFilterForVoiceAsync(
            string sess,
            string wantedVoiceName,
            int maxSteps,
            bool allowSubstringOnSecondPass,
            CancellationToken ct)
        {
            // Tenta primeiro salto instantâneo via React Fiber quando a lista tem dezenas/centenas de vozes
            if (await TryJumpVoiceGridViaReactFiberAsync(sess, wantedVoiceName, ct))
            {
                Dictionary<string, object> jumpedMatch = await FindMountedVoiceCardPointAsync(sess, wantedVoiceName, allowSubstringOnSecondPass, ct);
                if (jumpedMatch != null)
                    return jumpedMatch;
            }

            await ResetVoiceGridScrollTopAsync(sess, ct);

            for (int step = 0; step < maxSteps; step++)
            {
                ct.ThrowIfCancellationRequested();
                Dictionary<string, object> exactPt = await FindMountedVoiceCardPointAsync(sess, wantedVoiceName, false, ct);
                if (exactPt != null)
                    return exactPt;

                bool moved = await StepVoiceGridScrollAsync(sess, 0, ct);
                if (!moved)
                    break;
                await Task.Delay(140, ct);
            }

            if (allowSubstringOnSecondPass)
            {
                await ResetVoiceGridScrollTopAsync(sess, ct);
                for (int step = 0; step < maxSteps; step++)
                {
                    ct.ThrowIfCancellationRequested();
                    Dictionary<string, object> subPt = await FindMountedVoiceCardPointAsync(sess, wantedVoiceName, true, ct);
                    if (subPt != null)
                        return subPt;

                    bool moved = await StepVoiceGridScrollAsync(sess, 0, ct);
                    if (!moved)
                        break;
                    await Task.Delay(140, ct);
                }
            }

            return null;
        }

        private async Task<string> SelectCapCutVoiceByNameAsync(string sess, string wantedVoiceName, CancellationToken ct)
        {
            string target = string.IsNullOrWhiteSpace(wantedVoiceName) ? "Contador" : wantedVoiceName.Trim();

            // 1. Verifica primeiro se já está montada na visualização atual
            Dictionary<string, object> found = await FindMountedVoiceCardPointAsync(sess, target, false, ct);

            // 2. PRIORIDADE MÁXIMA: Abre "Favoritos" primeiro (onde o usuário salva suas vozes preferidas!)
            if (found == null)
            {
                if (await TryOpenFavoritesFilterOrTabAsync(sess, ct))
                {
                    _log(string.Format("[CapCut Voz] Procurando voz '{0}' em 'Favoritos'...", target));
                    await Task.Delay(850, ct);
                    found = await SweepCurrentFilterForVoiceAsync(sess, target, 35, true, ct);
                }
            }

            // 3. Verifica "Minhas vozes" / "Personalizadas" caso seja voz clonada
            if (found == null)
            {
                if (await TryClickVoiceHeaderTabAsync(sess, new[] { "minhas vozes", "my voices", "personaliz", "custom" }, ct))
                {
                    await Task.Delay(750, ct);
                    found = await SweepCurrentFilterForVoiceAsync(sess, target, 20, true, ct);
                    if (found == null)
                    {
                        await TryClickVoiceHeaderTabAsync(sess, new[] { "biblioteca", "library" }, ct);
                        await Task.Delay(650, ct);
                    }
                }
            }

            // 4. Filtra por "Português" (funciona mesmo quando a pílula está fora da janela no carrossel!) e varre toda a lista
            if (found == null)
            {
                if (await TryClickFilterTagAsync(sess, new[] { "português", "portugues", "portuguese" }, ct))
                {
                    await Task.Delay(850, ct);
                    found = await SweepCurrentFilterForVoiceAsync(sess, target, 80, false, ct);
                }
            }

            // 5. Varre a Biblioteca completa em "Tudo" (todas as 359+ vozes do início ao fim, usando React Fiber + scroll completo!)
            if (found == null)
            {
                if (await TryClickFilterTagAsync(sess, new[] { "tudo", "all" }, ct))
                    await Task.Delay(850, ct);
                found = await SweepCurrentFilterForVoiceAsync(sess, target, 95, true, ct);
            }

            if (found == null)
            {
                List<string> sample = new List<string>();
                HashSet<string> seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                await CollectVoicesInCurrentGridAsync(sess, sample, seen, 6, ct);
                string hint = sample.Count > 0
                    ? " Exemplos visíveis: " + string.Join(", ", sample.Take(10))
                    : "";
                throw new InvalidOperationException(string.Format("A voz '{0}' não foi localizada em Favoritos nem na Biblioteca do CapCut Web.{1}", target, hint));
            }

            await Task.Delay(150, ct);
            await _cdp.ClickAtAsync(sess, Convert.ToInt32(found["x"]), Convert.ToInt32(found["y"]), ct);
            await Task.Delay(650, ct);

            // Pausa eventual prévia sonora automática ao clicar no card da voz
            await PauseAllPageAudioAsync(sess, ct);
            return Convert.ToString(found["name"] ?? target);
        }

        private async Task<int> DetectEditorMaxCharactersAsync(string sess, CancellationToken ct)
        {
            string rawMax = await _cdp.EvalStringAsync(sess, @"
(function(){
    var panel = document.querySelector('.lv-tabs-content-item-active') || document.body;
    var txt = (panel && panel.innerText) ? panel.innerText : '';
    var m = txt.match(/\b\d+\s*\/\s*(\d{3,5})\b/);
    if (m && m[1]) return m[1];
    return '';
})()", ct);

            int parsed;
            if (!string.IsNullOrEmpty(rawMax) && int.TryParse(rawMax.Trim(), out parsed) && parsed >= 300)
                return Math.Max(250, parsed - 35);

            return 4500;
        }

        private static List<string> SplitNarratorTextIntoSafeChunks(string fullText, int maxCharsPerChunk)
        {
            List<string> chunks = new List<string>();
            string cleaned = (fullText ?? "").Trim();
            if (string.IsNullOrEmpty(cleaned))
                return chunks;

            if (cleaned.Length <= maxCharsPerChunk)
            {
                chunks.Add(cleaned);
                return chunks;
            }

            string[] paragraphs = Regex.Split(cleaned, @"(\r?\n)+")
                .Select(p => p.Trim())
                .Where(p => p.Length > 0)
                .ToArray();

            StringBuilder cur = new StringBuilder();
            for (int i = 0; i < paragraphs.Length; i++)
            {
                string para = paragraphs[i];
                if (para.Length > maxCharsPerChunk)
                {
                    if (cur.Length > 0)
                    {
                        chunks.Add(cur.ToString().Trim());
                        cur.Clear();
                    }

                    string[] sentences = Regex.Split(para, @"(?<=[\.\!\?\;])\s+");
                    for (int s = 0; s < sentences.Length; s++)
                    {
                        string sent = sentences[s].Trim();
                        if (sent.Length == 0) continue;
                        if (cur.Length > 0 && cur.Length + 1 + sent.Length > maxCharsPerChunk)
                        {
                            chunks.Add(cur.ToString().Trim());
                            cur.Clear();
                        }
                        if (cur.Length > 0) cur.Append(" ");
                        cur.Append(sent);
                    }
                    continue;
                }

                if (cur.Length > 0 && cur.Length + 2 + para.Length > maxCharsPerChunk)
                {
                    chunks.Add(cur.ToString().Trim());
                    cur.Clear();
                }

                if (cur.Length > 0)
                    cur.Append("\n\n");
                cur.Append(para);
            }

            if (cur.Length > 0)
                chunks.Add(cur.ToString().Trim());

            return chunks;
        }

        private async Task<int> InsertTextIntoSlateEditorAsync(string sess, string text, CancellationToken ct)
        {
            Dictionary<string, object> edPt = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var ed = Array.from(document.querySelectorAll('[data-slate-editor=""true""], div[contenteditable=""true""], textarea')).find(function(el){
        var r = el.getBoundingClientRect();
        return r.width > 140 && r.height > 40;
    });
    if (!ed) return null;
    var r = ed.getBoundingClientRect();
    return JSON.stringify({
        isTextarea: ed.tagName === 'TEXTAREA',
        x: Math.round(r.left + Math.min(120, r.width / 2)),
        y: Math.round(r.top + Math.min(60, r.height / 2))
    });
})()", ct);

            if (edPt == null)
                return 0;

            await _cdp.ClickAtAsync(sess, Convert.ToInt32(edPt["x"]), Convert.ToInt32(edPt["y"]), ct);
            await Task.Delay(180, ct);

            for (int clr = 0; clr < 2; clr++)
            {
                await _cdp.SelectAllAndBackspaceAsync(sess, ct);
                await Task.Delay(160, ct);
                int remLen = await ReadEditorCleanTextLengthAsync(sess, ct);
                if (remLen == 0)
                    break;
            }

            await _cdp.InsertTextAsync(sess, text, ct);
            await Task.Delay(450, ct);

            int afterLen = await ReadEditorCleanTextLengthAsync(sess, ct);
            if (afterLen < Math.Min(10, text.Length))
            {
                // Fallback via evento de colagem (ClipboardEvent paste) suportado nativamente pelo Slate.js
                string b64 = Convert.ToBase64String(Encoding.UTF8.GetBytes(text));
                await _cdp.EvalStringAsync(sess, string.Format(@"
(function(){{
    var txt = new TextDecoder('utf-8').decode(Uint8Array.from(atob('{0}'), function(c){{ return c.charCodeAt(0); }}));
    var ed = Array.from(document.querySelectorAll('[data-slate-editor=""true""], div[contenteditable=""true""], textarea')).find(function(el){{
        var r = el.getBoundingClientRect();
        return r.width > 140 && r.height > 40;
    }});
    if (!ed) return 'NO_ED';
    ed.focus();
    if (ed.tagName === 'TEXTAREA') {{
        var setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value').set;
        setter.call(ed, txt);
        ed.dispatchEvent(new Event('input', {{ bubbles: true }}));
        return 'OK';
    }}
    try {{
        var dt = new DataTransfer();
        dt.setData('text/plain', txt);
        var pasteEvt = new ClipboardEvent('paste', {{ bubbles: true, cancelable: true, clipboardData: dt }});
        ed.dispatchEvent(pasteEvt);
    }} catch(e) {{
        document.execCommand('insertText', false, txt);
    }}
    return 'OK';
}})()", b64), ct);
                await Task.Delay(450, ct);
                afterLen = await ReadEditorCleanTextLengthAsync(sess, ct);
            }

            return afterLen;
        }

        private async Task<int> ReadEditorCleanTextLengthAsync(string sess, CancellationToken ct)
        {
            string s = await _cdp.EvalStringAsync(sess, @"
(function(){
    var ed = Array.from(document.querySelectorAll('[data-slate-editor=""true""], div[contenteditable=""true""], textarea')).find(function(el){
        var r = el.getBoundingClientRect();
        return r.width > 140 && r.height > 40;
    });
    if (!ed) return '0';
    if (ed.tagName === 'TEXTAREA') return String((ed.value || '').trim().length);
    var clone = ed.cloneNode(true);
    Array.from(clone.querySelectorAll('[contenteditable=""false""], [class*=""placeholder""]')).forEach(function(n){
        if (n.parentNode) n.parentNode.removeChild(n);
    });
    var raw = (clone.innerText || '').replace(/\uFEFF/g, '').trim();
    return String(raw.length);
})()", ct);

            int len;
            return int.TryParse(s, out len) ? len : 0;
        }

        private async Task<bool> GenerateAndCaptureAudioChunkAsync(
            EpisodeWorkItem ep,
            string sess,
            string matchedVoice,
            string chunkText,
            string workDir,
            string destChunkMp3Path,
            CancellationToken ct)
        {
            Dictionary<string, object> preGen = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var genBtn = Array.from(document.querySelectorAll('button[class*=""generateButton""], button')).find(function(b){
        var txt = (b.innerText || '').trim().toLowerCase();
        var r = b.getBoundingClientRect();
        return r.width > 40 && r.height > 20 &&
               (b.className.indexOf('generateButton') >= 0 || txt === 'gerar' || txt === 'generate' || txt.indexOf('gerar') === 0);
    });
    if (!genBtn) return null;
    var disabled = !!genBtn.disabled || genBtn.getAttribute('data-disabled') === '1' || genBtn.className.indexOf('lv-btn-disabled') >= 0;
    var r = genBtn.getBoundingClientRect();

    var audUrls = Array.from(document.querySelectorAll('audio, video')).map(function(a){
        return a.currentSrc || a.src || '';
    }).filter(function(u){ return u.length > 0; });

    var resCount = (window.performance && performance.getEntriesByType) ? performance.getEntriesByType('resource').length : 0;

    return JSON.stringify({
        disabled: disabled,
        x: Math.round(r.left + r.width / 2),
        y: Math.round(r.top + r.height / 2),
        prevAudioCsv: audUrls.join('||'),
        prevResCount: resCount
    });
})()", ct);

            if (preGen == null)
                throw new InvalidOperationException("Botão 'Gerar' não encontrado na página do CapCut Web.");

            if (Convert.ToBoolean(preGen["disabled"]))
            {
                await Task.Delay(900, ct);
                // Reavalia se habilitou após hidratação da voz/texto
                preGen = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var genBtn = Array.from(document.querySelectorAll('button[class*=""generateButton""], button')).find(function(b){
        var txt = (b.innerText || '').trim().toLowerCase();
        var r = b.getBoundingClientRect();
        return r.width > 40 && r.height > 20 &&
               (b.className.indexOf('generateButton') >= 0 || txt === 'gerar' || txt === 'generate' || txt.indexOf('gerar') === 0);
    });
    if (!genBtn) return null;
    var disabled = !!genBtn.disabled || genBtn.getAttribute('data-disabled') === '1' || genBtn.className.indexOf('lv-btn-disabled') >= 0;
    var r = genBtn.getBoundingClientRect();
    var audUrls = Array.from(document.querySelectorAll('audio, video')).map(function(a){ return a.currentSrc || a.src || ''; }).filter(function(u){ return u.length > 0; });
    var resCount = (window.performance && performance.getEntriesByType) ? performance.getEntriesByType('resource').length : 0;
    return JSON.stringify({ disabled: disabled, x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2), prevAudioCsv: audUrls.join('||'), prevResCount: resCount });
})()", ct);

                if (preGen == null || Convert.ToBoolean(preGen["disabled"]))
                    throw new InvalidOperationException("O botão 'Gerar' permaneceu desabilitado no CapCut Web (verifique se a voz foi selecionada e se há texto).");
            }

            string prevAudioCsv = preGen.ContainsKey("prevAudioCsv") ? Convert.ToString(preGen["prevAudioCsv"] ?? "") : "";
            int prevResCount = preGen.ContainsKey("prevResCount") ? Convert.ToInt32(preGen["prevResCount"]) : 0;
            HashSet<string> prevAudioSet = new HashSet<string>(
                prevAudioCsv.Split(new[] { "||" }, StringSplitOptions.RemoveEmptyEntries),
                StringComparer.Ordinal);

            string dlStageDir = Path.Combine(workDir, "dl_" + Guid.NewGuid().ToString("N").Substring(0, 6));
            Directory.CreateDirectory(dlStageDir);
            HashSet<string> beforeFiles = new HashSet<string>(Directory.GetFiles(dlStageDir), StringComparer.OrdinalIgnoreCase);
            await _cdp.SetDownloadBehaviorAsync(dlStageDir, ct);

            // Instala rastreador leve de blobs/URLs de áudio criados após clicar em 'Gerar'
            await _cdp.EvalStringAsync(sess, @"
(function(){
    window.__fvsCapturedAudioUrls = [];
    if (!window.__fvsAudioHookInstalled) {
        window.__fvsAudioHookInstalled = true;
        var origCreateObj = URL.createObjectURL;
        URL.createObjectURL = function(obj) {
            var res = origCreateObj.apply(this, arguments);
            try {
                if (obj && (!obj.type || obj.type.indexOf('audio') >= 0 || obj.type.indexOf('mpeg') >= 0 || obj.type.indexOf('wav') >= 0 || obj.type.indexOf('mp4') >= 0 || obj.type.indexOf('octet') >= 0) && (obj.size || 0) > 2048) {
                    if (window.__fvsCapturedAudioUrls) window.__fvsCapturedAudioUrls.push(res);
                }
            } catch(e) {}
            return res;
        };
        var origPlay = HTMLMediaElement.prototype.play;
        HTMLMediaElement.prototype.play = function() {
            try {
                var u = this.currentSrc || this.src || '';
                if (u && window.__fvsCapturedAudioUrls) window.__fvsCapturedAudioUrls.push(u);
            } catch(e) {}
            return origPlay.apply(this, arguments);
        };
    }
    return 'OK';
})()", ct);

            _log(string.Format("[CapCut Voz] Clicando em 'Gerar' com a voz '{0}' e aguardando síntese...", matchedVoice));
            DateTime clickUtc = DateTime.UtcNow;
            await _cdp.ClickAtAsync(sess, Convert.ToInt32(preGen["x"]), Convert.ToInt32(preGen["y"]), ct);

            DateTime deadline = DateTime.UtcNow.AddSeconds(95);
            Dictionary<string, object> dlBtnPt = null;
            string capturedMediaUrl = "";
            int reloadRetries = 0;

            await Task.Delay(1400, ct);

            while (DateTime.UtcNow < deadline)
            {
                ct.ThrowIfCancellationRequested();
                bool manualReload = await _cdp.WaitOrWakeOnReloadSignalAsync(450, ct);

                Dictionary<string, object> st = await _cdp.EvalJsonAsync(sess, string.Format(@"
(function(){{
    var genBtn = Array.from(document.querySelectorAll('button[class*=""generateButton""], button')).find(function(b){{
        var txt = (b.innerText || '').trim().toLowerCase();
        var r = b.getBoundingClientRect();
        return r.width > 40 && r.height > 20 &&
               (b.className.indexOf('generateButton') >= 0 || txt === 'gerar' || txt === 'generate' || txt.indexOf('gerar') === 0 || txt.indexOf('gerando') >= 0 || txt.indexOf('generating') >= 0);
    }});

    var btnLoading = !!genBtn && (
        genBtn.className.indexOf('loading') >= 0 ||
        genBtn.getAttribute('aria-busy') === 'true' ||
        !!genBtn.querySelector('svg[class*=""spin""], [class*=""loading""]') ||
        (genBtn.innerText || '').toLowerCase().indexOf('gerando') >= 0 ||
        (genBtn.innerText || '').toLowerCase().indexOf('generating') >= 0
    );

    var bodyTxt = (document.body && document.body.innerText) ? document.body.innerText : '';
    var quotaBlocked = /sem cr[eé]ditos|insufficient credits|limite atingido|upgrade to pro to download/i.test(bodyTxt);

    var dlCandidates = Array.from(document.querySelectorAll('button, a[download], [role=""button""], [class*=""download"" i], [class*=""export"" i]')).filter(function(el){{
        var r = el.getBoundingClientRect();
        if (r.width < 16 || r.height < 16 || r.top < 62) return false;
        if (el.disabled || el.getAttribute('aria-disabled') === 'true') return false;
        if (el.children.length > 4) return false;
        var txt = (el.innerText || '').trim().toLowerCase();
        var al = (el.getAttribute('aria-label') || '').trim().toLowerCase();
        var ttl = (el.getAttribute('title') || '').trim().toLowerCase();
        var cls = (el.className && typeof el.className === 'string') ? el.className.toLowerCase() : '';
        return txt === 'baixar' || txt === 'download' || txt === 'exportar' || txt === 'export' ||
               txt.indexOf('baixar') >= 0 || txt.indexOf('download') >= 0 ||
               al.indexOf('baixar') >= 0 || al.indexOf('download') >= 0 ||
               ttl.indexOf('baixar') >= 0 || ttl.indexOf('download') >= 0 ||
               cls.indexOf('download') >= 0 || cls.indexOf('export') >= 0;
    }});

    var dlBtn = dlCandidates.length > 0 ? dlCandidates[dlCandidates.length - 1] : null;
    var dlRect = dlBtn ? dlBtn.getBoundingClientRect() : null;

    var domAudios = Array.from(document.querySelectorAll('audio, video')).map(function(a){{
        return a.currentSrc || a.src || '';
    }}).filter(function(u){{ return u.length > 8; }});

    if (window.__fvsCapturedAudioUrls && window.__fvsCapturedAudioUrls.length > 0) {{
        for (var hi = 0; hi < window.__fvsCapturedAudioUrls.length; hi++) {{
            domAudios.push(window.__fvsCapturedAudioUrls[hi]);
        }}
    }}

    var perfMedia = [];
    if (window.performance && performance.getEntriesByType) {{
        var entries = performance.getEntriesByType('resource').slice({0});
        for (var i = 0; i < entries.length; i++) {{
            var u = entries[i].name || '';
            var it = (entries[i].initiatorType || '').toLowerCase();
            if (it === 'audio' || it === 'media' || /\.(mp3|wav|m4a|aac|ogg)(\?|$)/i.test(u) || /^https?:.*(tts|speech|sami|audio|tos-|tiktokcdn|ibytedtos)/i.test(u)) {{
                if (!/\.(js|css|png|jpg|jpeg|webp|svg|woff2?|json)(\?|$)/i.test(u) && u.indexOf('/api/') < 0 && u.indexOf('mon.byteoversea') < 0 && u.indexOf('mcs.') < 0) {{
                    perfMedia.push(u);
                }}
            }}
        }}
    }}

    return JSON.stringify({{
        loading: btnLoading,
        quotaBlocked: quotaBlocked,
        hasDl: !!dlBtn,
        dlX: dlRect ? Math.round(dlRect.left + dlRect.width / 2) : 0,
        dlY: dlRect ? Math.round(dlRect.top + dlRect.height / 2) : 0,
        domAudiosCsv: domAudios.join('||'),
        perfMediaCsv: perfMedia.join('||')
    }});
}})()", prevResCount), ct);

                if (st != null)
                {
                    if (Convert.ToBoolean(st["quotaBlocked"]))
                        return true;

                    bool loading = Convert.ToBoolean(st["loading"]);
                    bool hasDl = Convert.ToBoolean(st["hasDl"]);
                    double elapsedSec = (DateTime.UtcNow - clickUtc).TotalSeconds;

                    string domCsv = st.ContainsKey("domAudiosCsv") ? Convert.ToString(st["domAudiosCsv"] ?? "") : "";
                    if (!string.IsNullOrEmpty(domCsv))
                    {
                        string[] parts = domCsv.Split(new[] { "||" }, StringSplitOptions.RemoveEmptyEntries);
                        for (int i = parts.Length - 1; i >= 0; i--)
                        {
                            if (!prevAudioSet.Contains(parts[i]))
                            {
                                capturedMediaUrl = parts[i];
                                break;
                            }
                        }
                    }

                    if (string.IsNullOrEmpty(capturedMediaUrl))
                    {
                        string perfCsv = st.ContainsKey("perfMediaCsv") ? Convert.ToString(st["perfMediaCsv"] ?? "") : "";
                        if (!string.IsNullOrEmpty(perfCsv))
                        {
                            string[] pParts = perfCsv.Split(new[] { "||" }, StringSplitOptions.RemoveEmptyEntries);
                            if (pParts.Length > 0)
                                capturedMediaUrl = pParts[pParts.Length - 1];
                        }
                    }

                    if (!loading && elapsedSec >= 2.0 && (hasDl || !string.IsNullOrEmpty(capturedMediaUrl)))
                    {
                        if (hasDl)
                        {
                            dlBtnPt = new Dictionary<string, object>
                            {
                                { "x", Convert.ToInt32(st["dlX"]) },
                                { "y", Convert.ToInt32(st["dlY"]) }
                            };
                        }
                        break;
                    }
                }

                string manualReason;
                bool reloadRequested = manualReload || _cdp.ConsumeReloadAndResumeRequest(out manualReason);
                double waitedSec = (DateTime.UtcNow - clickUtc).TotalSeconds;
                if ((reloadRequested || waitedSec >= 55.0) && reloadRetries < 1)
                {
                    reloadRetries++;
                    _log("[CapCut Voz | Recuperação] Recarregando página do CapCut Web e retomando síntese...");
                    await _cdp.ReloadPageAndWaitReadyAsync(sess, 28000, ct);
                    await WaitForCapCutTtsEditorReadyAsync(sess, ct);
                    await DismissCapCutTooltipsAndModalsAsync(sess, ct);
                    await SelectCapCutVoiceByNameAsync(sess, matchedVoice, ct);
                    await InsertTextIntoSlateEditorAsync(sess, chunkText, ct);
                    await _cdp.SetDownloadBehaviorAsync(dlStageDir, ct);
                    await Task.Delay(700, ct);

                    Dictionary<string, object> reGen = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var b = Array.from(document.querySelectorAll('button[class*=""generateButton""], button')).find(function(el){
        var txt = (el.innerText || '').trim().toLowerCase();
        return el.getBoundingClientRect().width > 40 && (el.className.indexOf('generateButton') >= 0 || txt === 'gerar' || txt === 'generate');
    });
    if (!b) return null;
    var r = b.getBoundingClientRect();
    return JSON.stringify({ x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) });
})()", ct);
                    if (reGen != null)
                    {
                        clickUtc = DateTime.UtcNow;
                        deadline = DateTime.UtcNow.AddSeconds(75);
                        await _cdp.ClickAtAsync(sess, Convert.ToInt32(reGen["x"]), Convert.ToInt32(reGen["y"]), ct);
                        await Task.Delay(1200, ct);
                    }
                }
            }

            string downloadedFile = null;

            // Método A: Clicar no botão Baixar / Download (e em "Somente áudio" / "MP3" / "WAV" se abrir submenu)
            if (dlBtnPt != null)
            {
                _log("[CapCut Voz] Síntese concluída! Clicando em 'Baixar'...");
                await _cdp.ClickAtAsync(sess, Convert.ToInt32(dlBtnPt["x"]), Convert.ToInt32(dlBtnPt["y"]), ct);
                await Task.Delay(700, ct);

                Dictionary<string, object> subOptionPt = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var items = Array.from(document.querySelectorAll('.lv-dropdown-menu-item, .lv-popover-content button, .lv-popover-content div, [role=""menuitem""], [role=""option""]')).filter(function(el){
        var r = el.getBoundingClientRect();
        if (r.width < 25 || r.height < 16 || r.height > 70 || el.children.length > 4) return false;
        var t = (el.innerText || '').trim().toLowerCase();
        return t === 'somente áudio' || t === 'apenas áudio' || t === 'áudio' || t === 'audio only' ||
               t === 'mp3' || t === 'wav' || t.indexOf('somente áudio') >= 0 || t.indexOf('audio only') >= 0 ||
               (t.indexOf('mp3') >= 0 && t.indexOf('legenda') < 0);
    });
    if (items.length === 0) return null;
    var r = items[0].getBoundingClientRect();
    return JSON.stringify({ x: Math.round(r.left + r.width / 2), y: Math.round(r.top + r.height / 2) });
})()", ct);

                if (subOptionPt != null)
                {
                    await _cdp.ClickAtAsync(sess, Convert.ToInt32(subOptionPt["x"]), Convert.ToInt32(subOptionPt["y"]), ct);
                }

                downloadedFile = await _cdp.WaitForSingleDownloadAsync(dlStageDir, beforeFiles, 2 * 1024, 16000, ct);
            }

            // Método B (Fallback Direto): Se o botão não iniciou download de arquivo, extrai os bytes direto do <audio> / URL gerada!
            if (string.IsNullOrEmpty(downloadedFile) || !File.Exists(downloadedFile))
            {
                if (string.IsNullOrEmpty(capturedMediaUrl))
                {
                    capturedMediaUrl = await _cdp.EvalStringAsync(sess, @"
(function(){
    var auds = Array.from(document.querySelectorAll('audio, video')).map(function(a){ return a.currentSrc || a.src || ''; }).filter(function(u){ return u.length > 8; });
    return auds.length > 0 ? auds[auds.length - 1] : '';
})()", ct);
                }

                if (!string.IsNullOrEmpty(capturedMediaUrl))
                {
                    _log("[CapCut Voz] Extraindo fluxo de áudio gerado diretamente da sessão do CapCut Web...");
                    string b64Url = Convert.ToBase64String(Encoding.UTF8.GetBytes(capturedMediaUrl));
                    string audioBase64 = await _cdp.EvalStringAsync(sess, string.Format(@"
(async function(){{
    try {{
        var u = new TextDecoder('utf-8').decode(Uint8Array.from(atob('{0}'), function(c){{ return c.charCodeAt(0); }}));
        var resp = await fetch(u, {{ credentials: 'include' }});
        if (!resp.ok) return '';
        var buf = await resp.arrayBuffer();
        var bytes = new Uint8Array(buf);
        var chunkSize = 0x8000;
        var parts = [];
        for (var i = 0; i < bytes.length; i += chunkSize) {{
            parts.push(String.fromCharCode.apply(null, bytes.subarray(i, i + chunkSize)));
        }}
        return btoa(parts.join(''));
    }} catch(e) {{
        return '';
    }}
}})()", b64Url), ct, 30000);

                    if (!string.IsNullOrEmpty(audioBase64) && audioBase64.Length > 1024)
                    {
                        byte[] rawBytes = Convert.FromBase64String(audioBase64);
                        downloadedFile = Path.Combine(dlStageDir, "capcut_direct_audio.mp3");
                        File.WriteAllBytes(downloadedFile, rawBytes);
                    }
                }
            }

            await PauseAllPageAudioAsync(sess, ct);
            await _cdp.ResetDownloadBehaviorToDefaultAsync();

            if (string.IsNullOrEmpty(downloadedFile) || !File.Exists(downloadedFile) || new FileInfo(downloadedFile).Length <= 1024)
                throw new IOException("Não foi possível baixar o áudio gerado pelo CapCut Web.");

            File.Copy(downloadedFile, destChunkMp3Path, true);
            return false;
        }

        private async Task PauseAllPageAudioAsync(string sess, CancellationToken ct)
        {
            await _cdp.EvalStringAsync(sess, @"
(function(){
    Array.from(document.querySelectorAll('audio, video')).forEach(function(a){
        if (!a.paused) { try { a.pause(); } catch(e) {} }
    });
    return 'OK';
})()", ct);
        }

        private void ConcatenateAudioChunksWithFfmpeg(List<string> chunkPaths, string outputMp3Path)
        {
            string ffmpegExe = FindFfmpegExecutable();
            if (string.IsNullOrEmpty(ffmpegExe))
                throw new FileNotFoundException("FFmpeg não encontrado para unir partes do áudio do Narrador.");

            string listFile = Path.Combine(Path.GetDirectoryName(chunkPaths[0]), "concat_list.txt");
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < chunkPaths.Count; i++)
            {
                string escaped = chunkPaths[i].Replace("\\", "/").Replace("'", "'\\''");
                sb.AppendLine("file '" + escaped + "'");
            }
            File.WriteAllText(listFile, sb.ToString(), new UTF8Encoding(false));

            ProcessStartInfo psi = new ProcessStartInfo
            {
                FileName = ffmpegExe,
                Arguments = string.Format("-y -f concat -safe 0 -i \"{0}\" -vn -ar 44100 -ac 2 -b:a 192k \"{1}\"", listFile, outputMp3Path),
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                CreateNoWindow = true
            };

            using (Process p = Process.Start(psi))
            {
                p.StandardOutput.ReadToEnd();
                string err = p.StandardError.ReadToEnd();
                p.WaitForExit();
                if (p.ExitCode != 0 || !File.Exists(outputMp3Path))
                    throw new InvalidOperationException("Falha ao unir partes de áudio no FFmpeg: " + err);
            }
        }

        private static string FindFfmpegExecutable()
        {
            try
            {
                string capcutApps = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    @"CapCut\Apps");
                if (Directory.Exists(capcutApps))
                {
                    string found = Directory.GetFiles(capcutApps, "ffmpeg.exe", SearchOption.AllDirectories)
                        .OrderByDescending(f => File.GetLastWriteTimeUtc(f))
                        .FirstOrDefault();
                    if (!string.IsNullOrEmpty(found))
                        return found;
                }
            }
            catch { }
            return "ffmpeg.exe";
        }
    }
}
