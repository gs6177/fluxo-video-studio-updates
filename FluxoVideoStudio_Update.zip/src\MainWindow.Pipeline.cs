using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Microsoft.Win32;

namespace FluxoVideoStudio
{
    public partial class MainWindow : Window
    {
        private async void OnMainWindowLoaded(object sender, RoutedEventArgs e)
        {
            AppendLog("=== Fluxo Vídeo IA Studio iniciado ===");
            AppendLog(string.Format("Pronto para executar: [1] Grok Imagine -> [2] Google Flow -> [3] {0} (WAV -40dB) -> [4] CapCut Desktop.",
                _config.IsCapCutVoiceEngine() ? "Voz CapCut Web" : "ElevenLabs"));
            RefreshGrokProfileBadges();
            RefreshElevenVoicePresetCombos();
            RefreshCapCutVoiceCombos();
            RefreshVoiceEngineUiVisibility();
            RefreshStoriesList();

            if (!PipelineConfig.IsMasterDeveloperPc())
            {
                var unused = MonitorAndPromptRemoteUpdateOnOtherPcAsync();
            }

            if (!string.IsNullOrWhiteSpace(_startupEpisodePath) && Directory.Exists(_startupEpisodePath))
            {
                LoadCustomPathDirectly(_startupEpisodePath);
                if (_startupAutoRun && _selectedEpisode != null)
                {
                    await Task.Delay(600);
                    await ExecuteSelectedStagesAsync(true, true, true, true);
                }
            }
        }

        private void RefreshStoriesList()
        {
            _allStories = EpisodeParser.DiscoverAllStories();
            ApplyStoryFilter();
            AppendLog(string.Format("[Explorador] {0} histórias encontradas nas pastas de Novela/Reflexão e Terror.", _allStories.Count));
        }

        private void ApplyStoryFilter()
        {
            if (_lstStories == null) return;
            int filterIdx = _cmbGenreFilter != null ? _cmbGenreFilter.SelectedIndex : 0;
            string q = (_txtSearch != null ? _txtSearch.Text : "").Trim();

            IEnumerable<StoryProject> filtered = _allStories;
            if (filterIdx == 1) filtered = filtered.Where(s => s.Genre == GenreType.NovelaReflexao);
            else if (filterIdx == 2) filtered = filtered.Where(s => s.Genre == GenreType.NovelaMistica);
            else if (filterIdx == 3) filtered = filtered.Where(s => s.Genre == GenreType.Terror);

            if (!string.IsNullOrEmpty(q))
            {
                filtered = filtered.Where(s => s.Name.IndexOf(q, StringComparison.OrdinalIgnoreCase) >= 0);
            }

            List<StoryProject> finalList = filtered.ToList();
            _lstStories.Items.Clear();

            foreach (StoryProject sp in finalList)
            {
                Border itemBorder = new Border
                {
                    Background = BgCard,
                    BorderBrush = BorderSubtle,
                    BorderThickness = new Thickness(1),
                    CornerRadius = new CornerRadius(6),
                    Padding = new Thickness(9, 7, 9, 7),
                    Margin = new Thickness(0, 2, 0, 2),
                    Width = 292
                };

                StackPanel st = new StackPanel();
                st.Children.Add(new TextBlock
                {
                    Text = sp.Name,
                    FontWeight = FontWeights.Bold,
                    FontSize = 12.5,
                    Foreground = TextPrimary,
                    TextTrimming = TextTrimming.CharacterEllipsis
                });
                Brush badgeColor = sp.Genre == GenreType.Terror
                    ? BrushFromHex("#FCA5A5")
                    : (sp.Genre == GenreType.NovelaMistica ? BrushFromHex("#D8B4FE") : BrushFromHex("#93C5FD"));
                st.Children.Add(new TextBlock
                {
                    Text = string.Format("{0}  •  {1} ep(s)  •  {2:dd/MM HH:mm}",
                        sp.GenreBadge, sp.Episodes.Count, sp.LastModified),
                    FontSize = 11,
                    Foreground = badgeColor,
                    Margin = new Thickness(0, 2, 0, 0)
                });

                itemBorder.Child = st;
                ListBoxItem lbi = new ListBoxItem { Content = itemBorder, Tag = sp, Padding = new Thickness(0) };
                _lstStories.Items.Add(lbi);
            }

            if (_lstStories.Items.Count > 0 && _lstStories.SelectedIndex < 0)
            {
                _lstStories.SelectedIndex = 0;
            }
        }

        private void OnStorySelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ListBoxItem lbi = _lstStories.SelectedItem as ListBoxItem;
            if (lbi == null) return;
            StoryProject story = lbi.Tag as StoryProject;
            if (story == null) return;

            _selectedStory = story;
            RebuildEpisodeButtons(story);
            if (story.Episodes.Count > 0)
            {
                SelectEpisode(story.Episodes[0]);
            }
        }

        private void RebuildEpisodeButtons(StoryProject story)
        {
            _pnlEpisodeButtons.Children.Clear();
            foreach (EpisodeWorkItem ep in story.Episodes)
            {
                EpisodeParser.RefreshDiskCounters(ep);
                EpisodeWorkItem captured = ep;
                Button b = CreateStyledButton(
                    ep.SummaryLine,
                    _selectedEpisode == ep ? AccentPrimary : BgInput,
                    TextPrimary,
                    new Thickness(8, 6, 8, 6));
                b.HorizontalContentAlignment = HorizontalAlignment.Left;
                b.Margin = new Thickness(0, 2, 0, 2);
                b.FontSize = 11.5;
                b.Click += (s, ev) =>
                {
                    SelectEpisode(captured);
                    RebuildEpisodeButtons(story);
                };
                _pnlEpisodeButtons.Children.Add(b);
            }
        }

        private void SelectEpisode(EpisodeWorkItem ep)
        {
            if (ep == null) return;
            // Re-parse fresh from disk in case Antigravity just wrote new prompts
            EpisodeWorkItem refreshed = EpisodeParser.ParseEpisodeFolder(ep.EpisodePath, ep.StoryName, ep.Genre, ep.StoryRootPath);
            if (refreshed != null && _selectedStory != null)
            {
                int idx = _selectedStory.Episodes.IndexOf(ep);
                if (idx >= 0) _selectedStory.Episodes[idx] = refreshed;
                ep = refreshed;
            }

            _selectedEpisode = ep;
            _lblSelectedContext.Text = string.Format("📂 {0}  ➔  {1}   [{2}]   ({3})",
                ep.StoryName, ep.EpisodeName, ep.GenreLabel, ep.SummaryLine);

            _txtCapCutProjName.Text = ep.CapCutProjectName;
            _txtGrokPrompt.Text = ep.GrokPromptText ?? "";
            _txtFlowPrompt.Text = ep.FlowPromptText ?? "";
            _txtNarratorPrompt.Text = ep.UnifiedNarratorText ?? "";

            SyncQuickEpisodeCategoryAndVoiceUi(ep);
            ResetStageBadges();
            RefreshAssetsGallery(null);
            RefreshTakesManagerList();
        }

        private void ResetStageBadges()
        {
            SetStageBadge(_badgeGrok, StageState.Idle, "AGUARDANDO");
            SetStageBadge(_badgeFlow, StageState.Idle, "AGUARDANDO");
            SetStageBadge(_badgeEleven, StageState.Idle,
                (_selectedEpisode != null && string.IsNullOrWhiteSpace(_selectedEpisode.UnifiedNarratorText))
                    ? "SEM NARRADOR"
                    : "AGUARDANDO");
            SetStageBadge(_badgeCapCut, StageState.Idle, "AGUARDANDO");
        }

        private void SetStageBadge(TextBlock badge, StageState state, string text)
        {
            Action act = () =>
            {
                if (badge == null) return;
                badge.Text = text;
                switch (state)
                {
                    case StageState.Running: badge.Foreground = AccentAmber; break;
                    case StageState.Success: badge.Foreground = AccentGreen; break;
                    case StageState.Skipped: badge.Foreground = AccentBlue; break;
                    case StageState.PausedReview: badge.Foreground = AccentAmber; break;
                    case StageState.Failed: badge.Foreground = AccentRed; break;
                    default: badge.Foreground = TextSecondary; break;
                }
            };
            if (Dispatcher.CheckAccess()) act();
            else Dispatcher.BeginInvoke(act);
        }


        private void SyncSettingsFromUi()
        {
            _config.PreserveExistingAssets = _chkPreserveAssets.IsChecked == true;
            _config.ArchiveOldTakesBeforeRemake = _chkArchiveOldTakes.IsChecked == true;
            _config.PauseAfterGrokForVisualReview = _chkPauseAfterGrok.IsChecked == true;
            _config.ReuseEp1HookTake01 = _chkReuseHook.IsChecked == true;
            _config.LaunchCapCutDesktop = _chkLaunchCapCut.IsChecked == true;

            List<string> grokProfs = _txtGrokProfiles.Text
                .Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(s => s.Trim()).Where(s => s.Length > 0).ToList();
            if (grokProfs.Count > 0) _config.GrokProfiles = grokProfs;

            if (!string.IsNullOrWhiteSpace(_txtFlowProfile.Text))
                _config.FlowProfile = _txtFlowProfile.Text.Trim();
            if (!string.IsNullOrWhiteSpace(_txtFlowUrl.Text))
                _config.FlowProjectUrl = _txtFlowUrl.Text.Trim();
            ApplyManualFlowDelayFromUi(false);

            if (_rbVoiceEngineCapCut != null && _rbVoiceEngineEleven != null)
            {
                _config.VoiceEngine = _rbVoiceEngineEleven.IsChecked == true ? "ElevenLabs" : "CapCutWeb";
            }

            if (_cmbCapCutVoiceNovela != null && !string.IsNullOrWhiteSpace(_cmbCapCutVoiceNovela.Text))
                _config.SetCapCutVoiceForGenre(GenreType.NovelaReflexao, _cmbCapCutVoiceNovela.Text);
            if (_cmbCapCutVoiceMistica != null && !string.IsNullOrWhiteSpace(_cmbCapCutVoiceMistica.Text))
                _config.SetCapCutVoiceForGenre(GenreType.NovelaMistica, _cmbCapCutVoiceMistica.Text);
            if (_cmbCapCutVoiceTerror != null && !string.IsNullOrWhiteSpace(_cmbCapCutVoiceTerror.Text))
                _config.SetCapCutVoiceForGenre(GenreType.Terror, _cmbCapCutVoiceTerror.Text);

            if (_txtCapCutWebProfiles != null)
            {
                List<string> ccProfs = _txtCapCutWebProfiles.Text
                    .Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries)
                    .Select(s => s.Trim()).Where(s => s.Length > 0).ToList();
                if (ccProfs.Count > 0) _config.CapCutWebProfiles = ccProfs;
            }

            List<string> elProfs = _txtElevenProfiles.Text
                .Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(s => s.Trim()).Where(s => s.Length > 0).ToList();
            if (elProfs.Count > 0) _config.ElevenLabsProfiles = elProfs;

            if (!string.IsNullOrWhiteSpace(_txtElevenUrl.Text))
                _config.ElevenLabsUrl = _txtElevenUrl.Text.Trim();

            if (_txtNovelaRootDir != null)
            {
                _config.NovelaRootDir = (_txtNovelaRootDir.Text ?? "").Trim();
                EpisodeParser.CustomNovelaRoot = _config.NovelaRootDir;
            }

            if (_txtTerrorRootDir != null)
            {
                _config.TerrorRootDir = (_txtTerrorRootDir.Text ?? "").Trim();
                EpisodeParser.CustomTerrorRoot = _config.TerrorRootDir;
            }
        }

        private void ApplyManualFlowDelayFromUi(bool logAndSave)
        {
            if (_txtFlowDelayMin == null || _txtFlowDelayMax == null)
                return;

            int minSec;
            if (!int.TryParse((_txtFlowDelayMin.Text ?? "").Trim(), out minSec) || minSec < 0)
                minSec = 15;

            int maxSec;
            if (!int.TryParse((_txtFlowDelayMax.Text ?? "").Trim(), out maxSec) || maxSec < 0)
                maxSec = 30;

            if (maxSec < minSec)
            {
                int tmp = minSec;
                minSec = maxSec;
                maxSec = tmp;
            }

            if (maxSec > 600) maxSec = 600;
            if (minSec > 600) minSec = 600;

            _config.FlowActionDelayMinSeconds = minSec;
            _config.FlowActionDelayMaxSeconds = maxSec;
            _txtFlowDelayMin.Text = minSec.ToString();
            _txtFlowDelayMax.Text = maxSec.ToString();

            if (_lblFlowDelayActiveBadge != null)
            {
                _lblFlowDelayActiveBadge.Text = maxSec <= 0
                    ? "Ativo: Desativado (0s)"
                    : string.Format("Ativo: {0}–{1}s", minSec, maxSec);
            }

            if (logAndSave)
            {
                _config.SaveUserSettings();
                AppendLog(maxSec <= 0
                    ? "[Configurações | Google Flow] Delay entre ações do Flow desativado (0s) e salvo!"
                    : string.Format("[Configurações | Google Flow] Delay aleatório entre ações do Flow atualizado manualmente para {0}–{1}s e salvo!", minSec, maxSec));
            }
        }

        private void SyncEditedPromptsToEpisodeMemory()
        {
            if (_selectedEpisode == null) return;
            _selectedEpisode.GrokPromptText = _txtGrokPrompt.Text ?? "";
            _selectedEpisode.FlowPromptText = _txtFlowPrompt.Text ?? "";
            _selectedEpisode.UnifiedNarratorText = (_txtNarratorPrompt.Text ?? "").Trim();

            Dictionary<string, string> titleMap = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            EpisodeParser.ParseFlowTakes(_selectedEpisode.FlowPromptText, _selectedEpisode.FlowTakes, _selectedEpisode.AllRequiredFlowIngredients, titleMap);
            EpisodeParser.ParseGrokSpecs(_selectedEpisode.GrokPromptText, titleMap, _selectedEpisode.AllRequiredFlowIngredients, _selectedEpisode.GrokSpecs);
            EpisodeParser.LoadEpisodeCustomTakesConfig(_selectedEpisode);
        }

        private void OnSavePromptsClick(object sender, RoutedEventArgs e)
        {
            if (_selectedEpisode == null) return;
            try
            {
                UTF8Encoding utf8NoBom = new UTF8Encoding(false);
                string grokFile = string.IsNullOrEmpty(_selectedEpisode.GrokPromptPath)
                    ? Path.Combine(_selectedEpisode.EpisodePath, "prompt_grok_passo1_e_2.txt")
                    : _selectedEpisode.GrokPromptPath;
                string flowFile = string.IsNullOrEmpty(_selectedEpisode.FlowPromptPath)
                    ? Path.Combine(_selectedEpisode.EpisodePath, "prompt_flow_passo3.txt")
                    : _selectedEpisode.FlowPromptPath;
                string narFile = Path.Combine(_selectedEpisode.EpisodePath, "narrador_unificado.txt");

                File.WriteAllText(grokFile, _txtGrokPrompt.Text ?? "", utf8NoBom);
                File.WriteAllText(flowFile, _txtFlowPrompt.Text ?? "", utf8NoBom);
                if (!string.IsNullOrWhiteSpace(_txtNarratorPrompt.Text))
                    File.WriteAllText(narFile, _txtNarratorPrompt.Text.Trim(), utf8NoBom);

                _selectedEpisode.GrokPromptPath = grokFile;
                _selectedEpisode.FlowPromptPath = flowFile;
                _selectedEpisode.NarradorTxtPath = narFile;
                SyncEditedPromptsToEpisodeMemory();
                RefreshAssetsGallery(null);

                AppendLog("[Arquivos] Prompts e texto do Narrador salvos em UTF-8 sem BOM com sucesso!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao salvar arquivos: " + ex.Message, "Erro", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private async Task TestChromeCdpConnectionAsync()
        {
            try
            {
                _lblCdpStatus.Text = "● Chrome CDP: Conectando...";
                _lblCdpStatus.Foreground = AccentAmber;
                using (CancellationTokenSource cts = new CancellationTokenSource(30000))
                {
                    await _cdp.EnsureConnectedAsync(cts.Token);
                    var targets = await _cdp.GetTargetsAsync(cts.Token);
                    int pages = targets.Count(t => t.Type == "page");
                    _lblCdpStatus.Text = string.Format("● Chrome CDP: Conectado ({0} abas)", pages);
                    _lblCdpStatus.Foreground = AccentGreen;
                }
            }
            catch (Exception ex)
            {
                _lblCdpStatus.Text = "● Chrome CDP: Erro na conexão";
                _lblCdpStatus.Foreground = AccentRed;
                AppendLog("[CDP Erro] " + ex.Message);
            }
        }

        private void PreOpenAuthorizedChromeProfiles()
        {
            SyncSettingsFromUi();
            AppendLog("[WMI] Pré-abrindo janelas autorizadas do Grok Imagine e Google Flow no Chrome...");
            foreach (string prof in _config.GrokProfiles)
            {
                _cdp.LaunchChromeProfileWindow(prof, _config.GrokUrl);
            }
            _cdp.LaunchChromeProfileWindow(_config.FlowProfile, _config.FlowProjectUrl);
            AppendLog("[WMI] Comandos de abertura enviados para os perfis autorizados!");
        }

        private async Task ExecuteFullStoryQueueAsync()
        {
            if (_isRunning || _selectedStory == null || _selectedStory.Episodes.Count == 0) return;

            SyncSettingsFromUi();
            SetRunningUiState(true);
            _runCts = new CancellationTokenSource();

            try
            {
                AppendLog(string.Format("========== INICIANDO FILA COMPLETA DA HISTÓRIA: {0} ({1} episódios) ==========",
                    _selectedStory.Name, _selectedStory.Episodes.Count));

                for (int i = 0; i < _selectedStory.Episodes.Count; i++)
                {
                    _runCts.Token.ThrowIfCancellationRequested();
                    EpisodeWorkItem ep = _selectedStory.Episodes[i];
                    SelectEpisode(ep);
                    RebuildEpisodeButtons(_selectedStory);

                    bool isLastEp = (i == _selectedStory.Episodes.Count - 1);
                    bool doG = _chkStageGrok.IsChecked == true;
                    bool doF = _chkStageFlow.IsChecked == true;
                    bool doE = _chkStageEleven.IsChecked == true;
                    bool doC = _chkStageCapCut.IsChecked == true;
                    bool launchC = isLastEp && _config.LaunchCapCutDesktop;
                    CancellationToken token = _runCts.Token;

                    await Task.Run(async () =>
                    {
                        await RunEpisodePipelineCoreAsync(ep, doG, doF, doE, doC, launchC, token);
                    });
                }

                UpdateProgress(100, "Fila completa (EP.1 ➔ EP.3) finalizada com sucesso!");
                AppendLog("========== FILA COMPLETA CONCLUÍDA COM SUCESSO! ==========");
            }
            catch (OperationCanceledException)
            {
                UpdateProgress(0, "Execução interrompida pelo usuário.");
                AppendLog("[Sistema] Fila interrompida pelo usuário.");
            }
            catch (Exception ex)
            {
                UpdateProgress(0, "Erro na fila: " + ex.Message);
                AppendLog("[ERRO CRÍTICO] " + ex.ToString());
                MessageBox.Show(ex.Message, "Erro na Esteira", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                SetRunningUiState(false);
            }
        }

        private async Task ExecuteSelectedStagesAsync(bool doGrok, bool doFlow, bool doEleven, bool doCapCut)
        {
            if (_isRunning) return;
            if (_selectedEpisode == null)
            {
                MessageBox.Show("Selecione primeiro uma história e um episódio na coluna esquerda.", "Aviso", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            SyncSettingsFromUi();
            SyncEditedPromptsToEpisodeMemory();
            SetRunningUiState(true);
            _runCts = new CancellationTokenSource();
            EpisodeWorkItem ep = _selectedEpisode;
            bool launchC = _config.LaunchCapCutDesktop;
            CancellationToken token = _runCts.Token;

            try
            {
                await Task.Run(async () =>
                {
                    await RunEpisodePipelineCoreAsync(
                        ep,
                        doGrok,
                        doFlow,
                        doEleven,
                        doCapCut,
                        launchC,
                        token);
                });

                UpdateProgress(100, string.Format("{0} ({1}) concluído com sucesso!", _selectedEpisode.StoryName, _selectedEpisode.EpisodeName));
            }
            catch (OperationCanceledException)
            {
                UpdateProgress(0, "Execução cancelada pelo usuário.");
                AppendLog("[Sistema] Execução cancelada.");
            }
            catch (Exception ex)
            {
                UpdateProgress(0, "Erro: " + ex.Message);
                AppendLog("[ERRO] " + ex.ToString());
                MessageBox.Show(ex.Message, "Erro na Execução", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                if (_selectedStory != null) RebuildEpisodeButtons(_selectedStory);
                RefreshAssetsGallery(null);
                SetRunningUiState(false);
            }
        }

        private async Task RunEpisodePipelineCoreAsync(
            EpisodeWorkItem ep,
            bool doGrok,
            bool doFlow,
            bool doEleven,
            bool doCapCut,
            bool launchCapCutAtEnd,
            CancellationToken ct)
        {
            AppendLog(string.Format("----- Iniciando {0} | {1} -----", ep.StoryName, ep.EpisodeName));

            if (doGrok || doFlow || (doEleven && !string.IsNullOrWhiteSpace(ep.UnifiedNarratorText)))
            {
                UpdateProgress(5, "Conectando ao Google Chrome via CDP WebSocket...");
                await _cdp.EnsureConnectedAsync(ct);
                var op1 = Dispatcher.BeginInvoke(new Action(() =>
                {
                    _lblCdpStatus.Text = "● Chrome CDP: Conectado (Sessão Persistente)";
                    _lblCdpStatus.Foreground = AccentGreen;
                }));
            }

            // ETAPA 1: GROK IMAGINE
            if (doGrok)
            {
                SetStageBadge(_badgeGrok, StageState.Running, "EXECUTANDO...");
                UpdateProgress(15, "Etapa 1/4: Gerando e baixando Personagens + Cenários no Grok Imagine...");
                try
                {
                    await _grok.RunAsync(ep, ct);
                    SetStageBadge(_badgeGrok, StageState.Success, "CONCLUÍDO");
                    var op2 = Dispatcher.BeginInvoke(new Action(() => RefreshAssetsGallery(null)));

                    if (_config.PauseAfterGrokForVisualReview && doFlow)
                    {
                        SetStageBadge(_badgeGrok, StageState.PausedReview, "AGUARDANDO REVISÃO");
                        UpdateProgress(32, "Pausado para conferência visual dos Assets. Clique em 'CONFIRMAR ASSETS E IR P/ FLOW'.");
                        AppendLog("[Revisão Visual] Confira as miniaturas na aba 'Conferência Visual de Assets' e clique no botão amarelo 'CONFIRMAR ASSETS E IR P/ FLOW' para continuar.");

                        _reviewContinueTcs = new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
                        var op3 = Dispatcher.BeginInvoke(new Action(() => _btnContinueReview.Visibility = Visibility.Visible));
                        try
                        {
                            await _reviewContinueTcs.Task;
                        }
                        finally
                        {
                            var op4 = Dispatcher.BeginInvoke(new Action(() => _btnContinueReview.Visibility = Visibility.Collapsed));
                            _reviewContinueTcs = null;
                        }
                        SetStageBadge(_badgeGrok, StageState.Success, "CONFIRMADO");
                    }
                }
                catch
                {
                    SetStageBadge(_badgeGrok, StageState.Failed, "ERRO");
                    throw;
                }
            }
            else
            {
                SetStageBadge(_badgeGrok, StageState.Skipped, "PULADO");
            }

            // ETAPA 2: GOOGLE FLOW
            if (doFlow)
            {
                SetStageBadge(_badgeFlow, StageState.Running, "EXECUTANDO...");
                UpdateProgress(45, "Etapa 2/4: Gerando Takes em lotes de 5 no Google Flow e baixando em 720p...");
                try
                {
                    await _flow.RunAsync(ep, ct);
                    SetStageBadge(_badgeFlow, StageState.Success, "CONCLUÍDO");
                }
                catch
                {
                    SetStageBadge(_badgeFlow, StageState.Failed, "ERRO");
                    throw;
                }
            }
            else
            {
                SetStageBadge(_badgeFlow, StageState.Skipped, "PULADO");
            }

            // ETAPA 3: VOZ DO NARRADOR (CAPCUT WEB OU ELEVENLABS) + TRAVAR SILÊNCIO (-40dB / 0,3s WAV)
            if (doEleven)
            {
                if (string.IsNullOrWhiteSpace(ep.UnifiedNarratorText))
                {
                    SetStageBadge(_badgeEleven, StageState.Skipped, "SEM NARRADOR");
                    AppendLog("[Voz Narrador] Episódio sem falas do Narrador — pulando síntese de voz.");
                }
                else
                {
                    SetStageBadge(_badgeEleven, StageState.Running, "EXECUTANDO...");
                    bool useCapCutVoice = _config.IsCapCutVoiceEngine();
                    if (useCapCutVoice)
                    {
                        string targetVoice = _config.GetCapCutVoiceForEpisode(ep);
                        UpdateProgress(75, string.Format("Etapa 3/4: Gerando voz '{0}' ({1}) no CapCut Web e aplicando Travar Silêncio (-40dB / 0,3s)...", targetVoice, ep.GenreLabel));
                    }
                    else
                    {
                        UpdateProgress(75, "Etapa 3/4: Gerando locução no ElevenLabs e aplicando Travar Silêncio (-40dB / 0,3s WAV)...");
                    }

                    try
                    {
                        if (useCapCutVoice)
                            await _capcutVoice.RunAsync(ep, ct);
                        else
                            await _eleven.RunAsync(ep, ct);

                        SetStageBadge(_badgeEleven, StageState.Success, "WAV PRONTO");
                    }
                    catch
                    {
                        SetStageBadge(_badgeEleven, StageState.Failed, "ERRO");
                        throw;
                    }
                }
            }
            else
            {
                SetStageBadge(_badgeEleven, StageState.Skipped, "PULADO");
            }

            // ETAPA 4: CAPCUT DESKTOP TIMELINE
            if (doCapCut)
            {
                SetStageBadge(_badgeCapCut, StageState.Running, "MONTANDO...");
                UpdateProgress(90, "Etapa 4/4: Montando takes e áudio do Narrador na Timeline do CapCut Desktop...");
                try
                {
                    string projName = ep.CapCutProjectName;
                    await _capcut.RunAsync(ep, projName, launchCapCutAtEnd, ct);
                    SetStageBadge(_badgeCapCut, StageState.Success, "TIMELINE OK");
                }
                catch
                {
                    SetStageBadge(_badgeCapCut, StageState.Failed, "ERRO");
                    throw;
                }
            }
            else
            {
                SetStageBadge(_badgeCapCut, StageState.Skipped, "PULADO");
            }
        }

        private void SetRunningUiState(bool running)
        {
            _isRunning = running;
            if (_cdp != null)
            {
                _cdp.ClearReloadAndResumeRequest();
            }
            if (!running && _cdp != null)
            {
                Task.Run(async () =>
                {
                    try { await _cdp.ResetDownloadBehaviorToDefaultAsync(); } catch { }
                });
            }
            Action act = () =>
            {
                if (_btnRunAllEpisodes != null) _btnRunAllEpisodes.IsEnabled = !running;
                if (_btnReloadResume != null) _btnReloadResume.Visibility = running ? Visibility.Visible : Visibility.Collapsed;
                if (_btnStop != null)
                {
                    _btnStop.IsEnabled = true;
                    _btnStop.Content = running ? "⏹ PARAR AGORA" : "▶ INICIAR";
                    _btnStop.Background = running ? AccentRed : AccentGreen;
                    _btnStop.Foreground = Brushes.White;
                }
                if (!running && _btnContinueReview != null) _btnContinueReview.Visibility = Visibility.Collapsed;
            };
            if (Dispatcher.CheckAccess()) act();
            else Dispatcher.BeginInvoke(act);
        }

        private void OnImportCastFromAnotherStoryClick(object sender, RoutedEventArgs e)
        {
            if (_selectedEpisode == null || _selectedStory == null)
            {
                MessageBox.Show("Selecione primeiro a história/episódio de destino na coluna esquerda.", "Importar Personagens", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            List<StoryProject> storiesWithAssets = _allStories.Where(s =>
                s.Episodes.Any(ep => Directory.Exists(ep.AssetsDir) && Directory.GetFiles(ep.AssetsDir, "*.jpg").Length > 0))
                .ToList();

            if (storiesWithAssets.Count == 0)
            {
                MessageBox.Show("Nenhuma história pronta com imagens .jpg em assets\\ foi encontrada.", "Importar Personagens", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            Window dlg = new Window
            {
                Title = "👥 Importar Elenco (Personagens / Cenários) de Outra História Pronta",
                Width = 560,
                Height = 360,
                WindowStartupLocation = WindowStartupLocation.CenterOwner,
                Owner = this,
                Background = BgPanel,
                Foreground = TextPrimary,
                ResizeMode = ResizeMode.NoResize
            };

            StackPanel sp = new StackPanel { Margin = new Thickness(18) };
            sp.Children.Add(new TextBlock
            {
                Text = "Escolha a história pronta da qual deseja copiar os personagens:",
                FontWeight = FontWeights.Bold,
                FontSize = 13,
                Foreground = TextPrimary,
                Margin = new Thickness(0, 0, 0, 8)
            });

            ComboBox cmbSourceStory = new ComboBox { Padding = new Thickness(8, 6, 8, 6), Margin = new Thickness(0, 0, 0, 14), FontSize = 12.5 };
            foreach (StoryProject s in storiesWithAssets)
            {
                cmbSourceStory.Items.Add(new ComboBoxItem { Content = s.DisplayHeader, Tag = s });
            }
            cmbSourceStory.SelectedIndex = 0;
            sp.Children.Add(cmbSourceStory);

            CheckBox chkOnlyChars = new CheckBox
            {
                IsChecked = true,
                Content = new TextBlock { Text = "Importar SOMENTE os Personagens (ignorar arquivos de Cenário)", Foreground = TextPrimary },
                Margin = new Thickness(0, 0, 0, 8)
            };
            sp.Children.Add(chkOnlyChars);

            CheckBox chkApplyAllEps = new CheckBox
            {
                IsChecked = true,
                Content = new TextBlock { Text = "Copiar elenco para todos os episódios desta história (EP.1, EP.2 e EP.3)", Foreground = TextPrimary },
                Margin = new Thickness(0, 0, 0, 18)
            };
            sp.Children.Add(chkApplyAllEps);

            sp.Children.Add(new TextBlock
            {
                Text = "Dica: Após importar, você pode usar o menu '⇄ Trocar nome com...' abaixo de cada miniatura caso o novo roteiro use outro arquétipo para o mesmo personagem.",
                FontSize = 11.5,
                Foreground = TextSecondary,
                TextWrapping = TextWrapping.Wrap,
                Margin = new Thickness(0, 0, 0, 16)
            });

            StackPanel btnRow = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };
            Button btnCancel = CreateStyledButton("Cancelar", BgCard, TextPrimary, new Thickness(14, 7, 14, 7));
            btnCancel.Margin = new Thickness(0, 0, 10, 0);
            btnCancel.Click += (s2, e2) => dlg.DialogResult = false;
            btnRow.Children.Add(btnCancel);

            Button btnConfirm = CreateStyledButton("👥 Importar Personagens Agora", AccentPrimary, Brushes.White, new Thickness(14, 7, 14, 7));
            btnConfirm.FontWeight = FontWeights.Bold;
            btnConfirm.Click += (s2, e2) => dlg.DialogResult = true;
            btnRow.Children.Add(btnConfirm);

            sp.Children.Add(btnRow);
            dlg.Content = sp;

            if (dlg.ShowDialog() == true)
            {
                ComboBoxItem selItem = cmbSourceStory.SelectedItem as ComboBoxItem;
                StoryProject srcStory = selItem != null ? selItem.Tag as StoryProject : null;
                if (srcStory == null) return;

                bool onlyChars = chkOnlyChars.IsChecked == true;
                bool allEps = chkApplyAllEps.IsChecked == true;

                Dictionary<string, string> uniqueAssets = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                foreach (EpisodeWorkItem srcEp in srcStory.Episodes)
                {
                    if (!Directory.Exists(srcEp.AssetsDir)) continue;
                    foreach (string f in Directory.GetFiles(srcEp.AssetsDir, "*.jpg"))
                    {
                        string fn = Path.GetFileName(f);
                        bool isScen = fn.IndexOf("Cenario", StringComparison.OrdinalIgnoreCase) >= 0 ||
                                      fn.IndexOf("Quarto_", StringComparison.OrdinalIgnoreCase) >= 0 ||
                                      fn.IndexOf("Sala_", StringComparison.OrdinalIgnoreCase) >= 0 ||
                                      fn.IndexOf("Cozinha_", StringComparison.OrdinalIgnoreCase) >= 0 ||
                                      fn.IndexOf("Rua_", StringComparison.OrdinalIgnoreCase) >= 0 ||
                                      fn.IndexOf("Casa_", StringComparison.OrdinalIgnoreCase) >= 0;
                        if (onlyChars && isScen) continue;
                        if (!uniqueAssets.ContainsKey(fn))
                            uniqueAssets[fn] = f;
                    }
                }

                List<EpisodeWorkItem> targetEps = allEps ? _selectedStory.Episodes : new List<EpisodeWorkItem> { _selectedEpisode };
                int copiedTotal = 0;
                foreach (EpisodeWorkItem dstEp in targetEps)
                {
                    if (!Directory.Exists(dstEp.AssetsDir))
                        Directory.CreateDirectory(dstEp.AssetsDir);

                    foreach (KeyValuePair<string, string> kv in uniqueAssets)
                    {
                        string dstFile = Path.Combine(dstEp.AssetsDir, kv.Key);
                        File.Copy(kv.Value, dstFile, true);
                        copiedTotal++;
                    }
                    EpisodeParser.RefreshDiskCounters(dstEp);
                }

                _grok.MirrorAssetsToTempFlow(_selectedEpisode.AssetsDir);
                RebuildEpisodeButtons(_selectedStory);
                RefreshAssetsGallery(null);
                AppendLog(string.Format("[Elenco Importado] {0} imagens copiadas de '{1}' para '{2}' e espelhadas em Temp\\flow_assets!",
                    uniqueAssets.Count, srcStory.Name, _selectedStory.Name));
            }
        }

        private void UpdateProgress(double value, string label)
        {
            Action act = () =>
            {
                if (_progressBar != null) _progressBar.Value = value;
                if (_lblProgressStep != null) _lblProgressStep.Text = label;
            };
            if (Dispatcher.CheckAccess()) act();
            else Dispatcher.BeginInvoke(act);
        }

        private readonly object _fileLogLock = new object();

        private void AppendLog(string message)
        {
            string line = string.Format("[{0:HH:mm:ss}] {1}", DateTime.Now, message);
            try
            {
                lock (_fileLogLock)
                {
                    string logFile = Path.Combine(PipelineConfig.GetAppRootDir(), "studio_runtime.log");
                    File.AppendAllText(logFile, line + Environment.NewLine, Encoding.UTF8);
                }
            }
            catch { }

            Dispatcher.BeginInvoke(new Action(() =>
            {
                if (_txtLog == null) return;
                _txtLog.AppendText(line + Environment.NewLine);
                _txtLog.ScrollToEnd();
            }));
        }

        private void OpenDirectoryInExplorer(string dir)
        {
            if (string.IsNullOrWhiteSpace(dir)) return;
            if (!Directory.Exists(dir)) Directory.CreateDirectory(dir);
            try { Process.Start(new ProcessStartInfo("explorer.exe", "\"" + dir + "\"") { UseShellExecute = true }); } catch { }
        }

        private void OnBrowseCustomEpisodeFolder(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog
            {
                Title = "Selecione qualquer arquivo .txt (ex: prompt_flow_passo3.txt ou roteiro.txt) dentro da pasta do Episódio/História",
                Filter = "Arquivos da História (*.txt)|*.txt|Todos os arquivos (*.*)|*.*",
                InitialDirectory = Directory.Exists(EpisodeParser.GetNovelaRoot())
                    ? EpisodeParser.GetNovelaRoot()
                    : Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory)
            };

            if (dlg.ShowDialog() == true)
            {
                string folder = Path.GetDirectoryName(dlg.FileName);
                LoadCustomPathDirectly(folder);
            }
        }

        private void LoadCustomPathDirectly(string folder)
        {
            if (string.IsNullOrEmpty(folder) || !Directory.Exists(folder)) return;

            string dirName = Path.GetFileName(folder);
            string storyFolder = folder;
            string targetEpName = "";

            if (dirName.StartsWith("EP.", StringComparison.OrdinalIgnoreCase) ||
                dirName.StartsWith("EP", StringComparison.OrdinalIgnoreCase))
            {
                storyFolder = Directory.GetParent(folder).FullName;
                targetEpName = dirName;
            }

            GenreType g = folder.IndexOf("_Videos terror", StringComparison.OrdinalIgnoreCase) >= 0
                ? GenreType.Terror
                : (folder.IndexOf("_videos de reflex", StringComparison.OrdinalIgnoreCase) >= 0 ? GenreType.NovelaReflexao : GenreType.Custom);

            StoryProject existing = _allStories.FirstOrDefault(s => string.Equals(s.FolderPath, storyFolder, StringComparison.OrdinalIgnoreCase));
            if (existing == null)
            {
                existing = EpisodeParser.LoadStoryFolder(storyFolder, g);
                if (existing != null && existing.Episodes.Count > 0)
                {
                    _allStories.Insert(0, existing);
                    ApplyStoryFilter();
                }
            }

            if (existing != null)
            {
                foreach (ListBoxItem item in _lstStories.Items)
                {
                    if (item.Tag == existing)
                    {
                        _lstStories.SelectedItem = item;
                        break;
                    }
                }

                if (!string.IsNullOrEmpty(targetEpName))
                {
                    EpisodeWorkItem matchEp = existing.Episodes.FirstOrDefault(ep =>
                        string.Equals(ep.EpisodeName, targetEpName, StringComparison.OrdinalIgnoreCase));
                    if (matchEp != null)
                    {
                        SelectEpisode(matchEp);
                        RebuildEpisodeButtons(existing);
                    }
                }
            }
        }

        private void OnManualSilenceProcessClick(object sender, RoutedEventArgs e)
        {
            if (_selectedEpisode == null)
            {
                MessageBox.Show("Selecione um episódio primeiro.", "Aviso", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            OpenFileDialog dlg = new OpenFileDialog
            {
                Title = "Selecione o arquivo .mp3 ou .wav do Narrador para aplicar Travar Silêncio (-40dB / 0,3s)",
                Filter = "Áudio (*.mp3;*.wav;*.m4a)|*.mp3;*.wav;*.m4a",
                InitialDirectory = Directory.Exists(_selectedEpisode.EpisodePath)
                    ? _selectedEpisode.EpisodePath
                    : Environment.GetFolderPath(Environment.SpecialFolder.UserProfile) + "\\Downloads"
            };

            if (dlg.ShowDialog() == true)
            {
                try
                {
                    if (!Directory.Exists(_selectedEpisode.TakesDir))
                        Directory.CreateDirectory(_selectedEpisode.TakesDir);

                    string outTakesWav = Path.Combine(_selectedEpisode.TakesDir, "Narrador_Take_01.wav");
                    string outRootWav = Path.Combine(_selectedEpisode.EpisodePath, "Narrador_Completo.wav");
                    _eleven.RunSilenceTruncationToWav(dlg.FileName, outTakesWav);
                    File.Copy(outTakesWav, outRootWav, true);
                    EpisodeParser.RefreshDiskCounters(_selectedEpisode);
                    if (_selectedStory != null) RebuildEpisodeButtons(_selectedStory);
                    MessageBox.Show("Áudio processado e salvo em:\n" + outTakesWav, "Travar Silêncio Concluído", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao processar áudio: " + ex.Message, "Erro", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

    }
}
