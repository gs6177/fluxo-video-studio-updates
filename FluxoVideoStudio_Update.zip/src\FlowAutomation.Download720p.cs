using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace FluxoVideoStudio
{
    public partial class FlowAutomation
    {
        private sealed class TakeVideoMatchCandidate
        {
            public int TakeIndex;
            public int VideoIndex;
            public string AsbId;
            public double RawScore;
            public int ScoreBucket;
        }

        private static readonly HashSet<string> PtStopWords = new HashSet<string>(StringComparer.Ordinal)
        {
            "de", "da", "do", "das", "dos", "em", "no", "na", "nos", "nas",
            "um", "uma", "uns", "umas", "com", "por", "pro", "pra", "para",
            "que", "ao", "aos", "as", "os", "se", "ou", "mas", "seu", "sua",
            "seus", "suas", "ele", "ela", "eles", "elas", "sob", "ate", "sem",
            "esta", "estao", "homem", "mulher", "adulto", "adulta", "idoso", "idosa"
        };

        private static string ExtractDistinctiveTakeBody(string rawPrompt)
        {
            if (string.IsNullOrWhiteSpace(rawPrompt)) return "";
            string s = rawPrompt.Trim();
            s = Regex.Replace(s, @"^(?:\[\s*(?:TAKE(?:[_\-\s]*ID)?[_\-\s]*\d{1,3}|(?:Dura[cç][aã]o\s*:\s*)?\d+(?:[\.,]\d+)?\s*(?:s|seg|segundos))\s*\]\s*)+", "", RegexOptions.IgnoreCase).Trim();
            s = Regex.Replace(s, @"^Prompt\s+de\s+V[ií]deo\s*:\s*", "", RegexOptions.IgnoreCase).Trim();
            s = Regex.Replace(s, @"^(?:\[\s*(?:TAKE(?:[_\-\s]*ID)?[_\-\s]*\d{1,3}|(?:Dura[cç][aã]o\s*:\s*)?\d+(?:[\.,]\d+)?\s*(?:s|seg|segundos))\s*\]\s*)+", "", RegexOptions.IgnoreCase).Trim();
            s = Regex.Replace(s, @"(\r?\n)*---\s*$", "").Trim();

            // 1. Novela: remove tudo até o fechamento de "[Ação...]"
            Match actionTag = Regex.Match(s, @"\[A[cç][aã]o[^\]]*\]\s*", RegexOptions.IgnoreCase);
            if (actionTag.Success)
            {
                s = s.Substring(actionTag.Index + actionTag.Length).Trim();
            }
            else
            {
                // 2. Terror / variantes sem "[Ação...]": remove cabeçalho "[Estilo Visual]... Apenas som ambiente... ."
                string stripped = Regex.Replace(
                    s,
                    @"^\[Estilo\s+Visual\][\s\S]*?(?:Apenas\s+som\s+ambiente[^\.\r\n]*\.|\(sem\s+m[uú]sica\)\.|sem\s+voz\s+em\s+off\.|e\s+vozes\.)\s*",
                    "",
                    RegexOptions.IgnoreCase).Trim();

                if (stripped.Length > 20 && stripped.Length < s.Length)
                {
                    s = stripped;
                }
                else
                {
                    s = Regex.Replace(s, @"^\[Estilo\s+Visual\][^\.\r\n]*\.\s*", "", RegexOptions.IgnoreCase).Trim();
                }
            }

            // 3. Remove conectores de template repetidos em todos os takes para isolar 100% a ação exclusiva da cena
            s = Regex.Replace(
                s,
                @"IMEDIATAMENTE\s+(?:ele|ela)\s+fala\s+em\s+portugu[eê]s,\s*mesclando\s+o\s+movimento\s+do\s+corpo\s+com\s+a\s+fala\s+para\s+n[aã]o\s+perder\s+tempo\s+de\s+tela\s*:",
                " ",
                RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"IMEDIATAMENTE\s+o\s+[aá]udio\s+entra\s*:", " ", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"Em\s+total\s+sil[eê]ncio\s+e\s+de\s+boca\s+fechada\s*,?", " ", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"\[C[aâ]mera\s+e\s+Detalhes\]", " ", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"A\s+atua[cç][aã]o\s+facial\s+[eé]\s+[^\.]{3,70}?com\s+lip-sync\s+preciso\.", " ", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"Lip-sync\s+preciso\.", " ", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"\bSEM\s+DIALOGO\b", " ", RegexOptions.IgnoreCase);

            return s.Trim();
        }

        private static string ExtractFoleyClause(string rawPrompt)
        {
            if (string.IsNullOrWhiteSpace(rawPrompt)) return "";
            Match m = Regex.Match(rawPrompt, @"Foley\s*:\s*([^\r\n]+)", RegexOptions.IgnoreCase);
            return m.Success ? m.Groups[1].Value.Trim() : "";
        }

        private static HashSet<string> ExtractEmbeddedAssetNames(string rawPrompt)
        {
            HashSet<string> set = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            if (string.IsNullOrWhiteSpace(rawPrompt)) return set;
            MatchCollection matches = Regex.Matches(rawPrompt, @"\b([A-Za-z0-9_\-]{3,80}\.(?:jpg|jpeg|png|webp))\b", RegexOptions.IgnoreCase);
            foreach (Match m in matches)
            {
                string fn = m.Groups[1].Value.Trim();
                if (!string.IsNullOrEmpty(fn))
                    set.Add(fn);
            }
            return set;
        }

        private static string ExtractFirstQuotedDialogue(string rawPrompt)
        {
            if (string.IsNullOrWhiteSpace(rawPrompt)) return "";
            MatchCollection matches = Regex.Matches(rawPrompt, @"""([^""]{12,})""");
            string longest = "";
            foreach (Match m in matches)
            {
                string val = m.Groups[1].Value.Trim();
                if (val.Length > longest.Length)
                    longest = val;
            }
            return longest;
        }

        private static double ComputeContentWordBigramSimilarity(string textA, string textB)
        {
            string na = EpisodeParser.NormalizeForCompare(textA);
            string nb = EpisodeParser.NormalizeForCompare(textB);
            if (string.IsNullOrEmpty(na) || string.IsNullOrEmpty(nb)) return 0.0;
            if (na == nb) return 1.0;

            string[] rawA = na.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            string[] rawB = nb.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

            List<string> seqA = new List<string>(rawA.Length);
            HashSet<string> setA = new HashSet<string>(StringComparer.Ordinal);
            for (int i = 0; i < rawA.Length; i++)
            {
                string w = rawA[i];
                if (w.Length >= 3 && !PtStopWords.Contains(w))
                {
                    seqA.Add(w);
                    setA.Add(w);
                }
            }

            List<string> seqB = new List<string>(rawB.Length);
            HashSet<string> setB = new HashSet<string>(StringComparer.Ordinal);
            for (int i = 0; i < rawB.Length; i++)
            {
                string w = rawB[i];
                if (w.Length >= 3 && !PtStopWords.Contains(w))
                {
                    seqB.Add(w);
                    setB.Add(w);
                }
            }

            if (setA.Count == 0 || setB.Count == 0) return 0.0;

            int uniInter = 0;
            foreach (string w in setA)
            {
                if (setB.Contains(w)) uniInter++;
            }
            double uniDice = (2.0 * uniInter) / (setA.Count + setB.Count);

            if (seqA.Count < 2 || seqB.Count < 2)
                return uniDice;

            HashSet<string> biA = new HashSet<string>(StringComparer.Ordinal);
            for (int i = 0; i < seqA.Count - 1; i++)
                biA.Add(seqA[i] + "_" + seqA[i + 1]);

            HashSet<string> biB = new HashSet<string>(StringComparer.Ordinal);
            for (int i = 0; i < seqB.Count - 1; i++)
                biB.Add(seqB[i] + "_" + seqB[i + 1]);

            int biInter = 0;
            foreach (string bg in biA)
            {
                if (biB.Contains(bg)) biInter++;
            }
            double biDice = (biA.Count + biB.Count) > 0
                ? (2.0 * biInter) / (biA.Count + biB.Count)
                : uniDice;

            return (0.45 * uniDice) + (0.55 * biDice);
        }

        private static double ComputeTakeToVideoMatchScore(FlowTakeSpec spec, string candidatePrompt)
        {
            if (spec == null || string.IsNullOrWhiteSpace(spec.RawPromptBody) || string.IsNullOrWhiteSpace(candidatePrompt))
                return 0.0;

            int explicitTag = TryExtractExplicitTakeTagNumber(candidatePrompt);
            if (explicitTag > 0)
            {
                return explicitTag == spec.TakeNumber ? 1.0 : 0.0;
            }

            string wantBody = ExtractDistinctiveTakeBody(spec.RawPromptBody);
            string gotBody = ExtractDistinctiveTakeBody(candidatePrompt);
            double bodySim = ComputeContentWordBigramSimilarity(wantBody, gotBody);

            string wantFoley = ExtractFoleyClause(spec.RawPromptBody);
            string gotFoley = ExtractFoleyClause(candidatePrompt);
            double actionAndFoleySim = (!string.IsNullOrEmpty(wantFoley) && !string.IsNullOrEmpty(gotFoley))
                ? (0.72 * bodySim) + (0.28 * ComputeContentWordBigramSimilarity(wantFoley, gotFoley))
                : bodySim;

            string wantQuote = ExtractFirstQuotedDialogue(spec.RawPromptBody);
            string gotQuote = ExtractFirstQuotedDialogue(candidatePrompt);
            string normWantQuote = EpisodeParser.NormalizeForCompare(wantQuote);
            string normGotQuote = EpisodeParser.NormalizeForCompare(gotQuote);
            string normCandidateFull = EpisodeParser.NormalizeForCompare(candidatePrompt);

            double score = actionAndFoleySim;

            bool wantHasQuote = normWantQuote.Length >= 12;
            bool gotHasQuote = normGotQuote.Length >= 12;

            if (wantHasQuote && normCandidateFull.IndexOf(normWantQuote, StringComparison.Ordinal) >= 0)
            {
                score = Math.Max(actionAndFoleySim, 0.72 + (0.28 * actionAndFoleySim));
                if (actionAndFoleySim >= 0.72)
                    score = Math.Max(score, 0.94 + (0.06 * actionAndFoleySim));
            }
            else if (wantHasQuote && gotHasQuote)
            {
                double quoteSim = ComputeContentWordBigramSimilarity(normWantQuote, normGotQuote);
                if (quoteSim >= 0.78)
                {
                    score = (0.52 * quoteSim) + (0.48 * actionAndFoleySim);
                }
                else if (quoteSim < 0.35)
                {
                    score = actionAndFoleySim * 0.28;
                }
                else
                {
                    score = (0.50 * quoteSim) + (0.50 * actionAndFoleySim);
                }
            }
            else if (wantHasQuote != gotHasQuote)
            {
                score = actionAndFoleySim * 0.32;
            }

            HashSet<string> wantAssets = ExtractEmbeddedAssetNames(spec.RawPromptBody);
            if (wantAssets.Count == 0 && spec.Ingredients != null)
            {
                for (int i = 0; i < spec.Ingredients.Count; i++)
                {
                    if (!string.IsNullOrWhiteSpace(spec.Ingredients[i]))
                        wantAssets.Add(spec.Ingredients[i].Trim());
                }
            }

            HashSet<string> gotAssets = ExtractEmbeddedAssetNames(candidatePrompt);
            if (wantAssets.Count > 0 && gotAssets.Count > 0)
            {
                int inter = 0;
                HashSet<string> union = new HashSet<string>(wantAssets, StringComparer.OrdinalIgnoreCase);
                foreach (string ga in gotAssets)
                {
                    if (wantAssets.Contains(ga)) inter++;
                    union.Add(ga);
                }
                double assetJaccard = union.Count > 0 ? ((double)inter / union.Count) : 1.0;
                score = score * (0.65 + (0.35 * assetJaccard));
            }

            return Math.Max(0.0, Math.Min(1.0, score));
        }

        private static int IdentifyTakeNumberFromPrompt(string promptText, List<FlowTakeSpec> targetTakes)
        {
            if (string.IsNullOrWhiteSpace(promptText) || targetTakes == null || targetTakes.Count == 0)
                return 0;

            int bestTakeNum = 0;
            double bestScore = 0.0;

            for (int i = 0; i < targetTakes.Count; i++)
            {
                FlowTakeSpec spec = targetTakes[i];
                double score = ComputeTakeToVideoMatchScore(spec, promptText);
                if (score > bestScore)
                {
                    bestScore = score;
                    bestTakeNum = spec.TakeNumber;
                }
            }

            return bestScore >= 0.62 ? bestTakeNum : 0;
        }

        private async Task<List<SessionCompletedVideoInfo>> CollectSessionVideosFromAgentPanelAsync(
            string sess,
            PreSessionGridBaseline baseline,
            CancellationToken ct)
        {
            List<SessionCompletedVideoInfo> result = new List<SessionCompletedVideoInfo>();
            int preBubbles = baseline != null ? baseline.PreExistingChatBubblesCount : 0;

            // Garante que o painel lateral do Agente esteja visível para ler 100% das opções de vídeo desta execução na sessão aberta
            await EnsureAgentPanelOpenAsync(sess, ct);

            // CRÍTICO: Em lotes de 5 vídeos, o Google Flow exibe apenas 4 cards (2x2) por bolha e oculta o 5º vídeo atrás do botão "Ver tudo"!
            // Quando reutilizamos uma sessão já aberta, expandimos e coletamos apenas os itens posteriores a preBubbles.
            for (int expandPass = 0; expandPass < 3; expandPass++)
            {
                ct.ThrowIfCancellationRequested();
                string expandRes = await _cdp.EvalStringAsync(sess, string.Format(@"
(function(){{
    var panel = document.querySelector('flow-agent-panel');
    if (!panel) return '0';
    var preB = {0};
    var bubbles = Array.from(panel.querySelectorAll('flow-chat-bubble'));
    var anchorBubble = (preB > 0 && bubbles.length >= preB) ? bubbles[preB - 1] : null;
    var scroller = panel.querySelector('.scroll-viewport') ||
                   Array.from(panel.querySelectorAll('div')).find(el => el.scrollHeight > el.clientHeight + 40);
    var clickedNodes = [];
    function isAfterAnchor(node) {{
        if (!anchorBubble) return true;
        if (anchorBubble === node || anchorBubble.contains(node)) return false;
        return (anchorBubble.compareDocumentPosition(node) & Node.DOCUMENT_POSITION_FOLLOWING) !== 0;
    }}
    function clickExpandButtons() {{
        var btns = Array.from(panel.querySelectorAll('button')).filter(b => {{
            if (clickedNodes.indexOf(b) >= 0) return false;
            if (!isAfterAnchor(b)) return false;
            var t = ((b.innerText || '') + ' ' + (b.getAttribute('aria-label') || '')).trim();
            if (!t) return false;
            if (/racioc[ií]nio|thinking|menos|less/i.test(t)) return false;
            return /\b(ver tudo|ver mais|mostrar tudo|mostrar mais|view all|show all|see all)\b/i.test(t);
        }});
        btns.forEach(b => {{
            clickedNodes.push(b);
            try {{ b.click(); }} catch(e) {{}}
        }});
    }}
    clickExpandButtons();
    if (scroller && scroller.scrollHeight > scroller.clientHeight + 40) {{
        var startPos = anchorBubble ? Math.max(0, anchorBubble.offsetTop - 100) : 0;
        for (var pos = startPos; pos <= scroller.scrollHeight; pos += Math.max(800, scroller.clientHeight * 2)) {{
            scroller.scrollTop = pos;
            clickExpandButtons();
        }}
        scroller.scrollTop = scroller.scrollHeight;
        clickExpandButtons();
    }}
    return String(clickedNodes.length);
}})()", preBubbles), ct);

                int clickedCount;
                if (!int.TryParse(expandRes, out clickedCount) || clickedCount <= 0)
                    break;

                await Task.Delay(550, ct);
            }

            Dictionary<string, object> raw = null;
            for (int poll = 0; poll < 6; poll++)
            {
                ct.ThrowIfCancellationRequested();
                raw = await _cdp.EvalJsonAsync(sess, string.Format(@"
(function(){{
    var panel = document.querySelector('flow-agent-panel');
    if (!panel) return JSON.stringify({{ opts: [], missingAsb: 0 }});
    var preB = {0};
    var bubbles = Array.from(panel.querySelectorAll('flow-chat-bubble'));
    var anchorBubble = (preB > 0 && bubbles.length >= preB) ? bubbles[preB - 1] : null;
    var hintMap = new Map();
    var lastSingleTakeNum = 0;
    bubbles.forEach(b => {{
        if (anchorBubble && (anchorBubble === b || anchorBubble.contains(b) || (anchorBubble.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING) === 0)) {{
            return;
        }}
        var vos = Array.from(b.querySelectorAll('flow-a2ui-video-option'));
        if (vos.length === 0) {{
            var txt = (b.innerText || '');
            var nums = [];
            var reTag = /\[\s*TAKE(?:[_\-\s]*ID)?[_\-\s]*0*(\d{{1,3}})\s*\]/gi;
            var mTag;
            while ((mTag = reTag.exec(txt)) !== null) {{
                var n1 = parseInt(mTag[1], 10);
                if (n1 > 0 && nums.indexOf(n1) < 0) nums.push(n1);
            }}
            if (nums.length === 0) {{
                var reWord = /\btake[\s_]+0*(\d{{1,3}})\b/gi;
                var mWord;
                while ((mWord = reWord.exec(txt)) !== null) {{
                    var n2 = parseInt(mWord[1], 10);
                    if (n2 > 0 && nums.indexOf(n2) < 0) nums.push(n2);
                }}
            }}
            if (nums.length === 1) lastSingleTakeNum = nums[0];
            else if (nums.length > 1) lastSingleTakeNum = 0;
        }} else if (lastSingleTakeNum > 0 && vos.length <= 2) {{
            vos.forEach(vo => {{
                hintMap.set(vo, lastSingleTakeNum);
            }});
        }}
    }});
    var nodes = Array.from(panel.querySelectorAll('flow-a2ui-video-option')).filter(vo => {{
        if (!anchorBubble) return true;
        if (anchorBubble.contains(vo)) return false;
        return (anchorBubble.compareDocumentPosition(vo) & Node.DOCUMENT_POSITION_FOLLOWING) !== 0;
    }});
    var missingAsb = 0;
    var opts = nodes.map((vo, idx) => {{
        var img = vo.querySelector('img');
        var vid = vo.querySelector('video');
        var mediaUrl = (img ? (img.getAttribute('src') || '') : '') + ' ' +
                       (vid ? ((vid.getAttribute('poster') || '') + ' ' + (vid.getAttribute('src') || '')) : '');
        var m = mediaUrl.match(/\/asb\/([A-Za-z0-9_\-]{{25,80}})/);
        if (!m) {{
            missingAsb++;
            try {{ vo.scrollIntoView({{ block: 'center', inline: 'nearest' }}); }} catch(e) {{}}
        }}
        var alt = img ? (img.getAttribute('alt') || '') : '';
        if (!alt && vid) alt = (vid.getAttribute('aria-label') || '');
        var hintTake = hintMap.has(vo) ? hintMap.get(vo) : 0;
        return {{
            idx: idx,
            asb: m ? m[1] : '',
            alt: alt,
            hintTake: hintTake
        }};
    }});
    return JSON.stringify({{ opts: opts, missingAsb: missingAsb }});
}})()", preBubbles), ct);

                if (raw == null) break;
                int missingAsb = raw.ContainsKey("missingAsb") ? Convert.ToInt32(raw["missingAsb"]) : 0;
                if (missingAsb == 0) break;
                await Task.Delay(350, ct);
            }

            if (raw == null || !raw.ContainsKey("opts")) return result;
            IEnumerable arr = raw["opts"] as IEnumerable;
            if (arr == null) return result;

            foreach (object elem in arr)
            {
                Dictionary<string, object> d = elem as Dictionary<string, object>;
                if (d == null) continue;
                string asb = d.ContainsKey("asb") ? Convert.ToString(d["asb"] ?? "").Trim() : "";
                if (string.IsNullOrEmpty(asb)) continue;
                if (baseline != null && baseline.PreExistingAsbIds.Contains(asb)) continue;

                SessionCompletedVideoInfo info = new SessionCompletedVideoInfo();
                info.ChronologicalOrder = d.ContainsKey("idx") ? Convert.ToInt32(d["idx"]) : result.Count;
                info.AsbId = asb;
                info.AltPrompt = d.ContainsKey("alt") ? Convert.ToString(d["alt"] ?? "") : "";
                int hintTake = d.ContainsKey("hintTake") ? Convert.ToInt32(d["hintTake"]) : 0;
                if (hintTake > 0 && TryExtractExplicitTakeTagNumber(info.AltPrompt) == 0)
                {
                    info.AltPrompt = string.Format("[TAKE_{0:00}] {1}", hintTake, info.AltPrompt ?? "").Trim();
                }
                result.Add(info);
            }
            return result;
        }

        private async Task<List<string>> CollectSessionGridAsbIdsOldestFirstAsync(
            string sess,
            PreSessionGridBaseline baseline,
            CancellationToken ct)
        {
            List<string> newestFirst = new List<string>();
            HashSet<string> seen = new HashSet<string>(StringComparer.Ordinal);

            for (int page = 0; page <= 20; page++)
            {
                string scrollStatus = await _cdp.EvalStringAsync(sess, string.Format(@"
(function(){{
    var vp = document.querySelector('cdk-virtual-scroll-viewport.tiles-container') || document.querySelector('cdk-virtual-scroll-viewport');
    if (!vp) return 'NO_VP';
    var maxScroll = Math.max(0, vp.scrollHeight - vp.clientHeight);
    var nextTop = Math.min(maxScroll, {0});
    vp.scrollTop = nextTop;
    return (nextTop >= maxScroll && {0} > 0) ? 'AT_END' : 'OK';
}})()", page * 480), ct);
                await Task.Delay(320, ct);

                Dictionary<string, object> raw = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var list = Array.from(document.querySelectorAll('flow-video-tile')).map(t => {
        var vid = t.querySelector('video');
        var img = t.querySelector('img.thumbnail') || t.querySelector('img');
        var mediaUrl = (img ? (img.getAttribute('src') || '') : '') + ' ' +
                       (vid ? ((vid.getAttribute('poster') || '') + ' ' + (vid.getAttribute('src') || '')) : '');
        var m = mediaUrl.match(/\/asb\/([A-Za-z0-9_\-]{25,80})/);
        var txt = (t.innerText || '');
        var ok = !/\b\d{1,2}%\b/.test(txt) && (!!vid || !!img || !!t.querySelector('button[aria-label*=""Mais op""]'));
        return { asb: m ? m[1] : '', ok: ok };
    });
    return JSON.stringify({ list: list });
})()", ct);

                if (raw == null || !raw.ContainsKey("list")) break;
                IEnumerable arr = raw["list"] as IEnumerable;
                if (arr == null) break;

                bool hitPreExistingAnchor = false;
                int countInPage = 0;
                foreach (object elem in arr)
                {
                    countInPage++;
                    Dictionary<string, object> d = elem as Dictionary<string, object>;
                    if (d == null) continue;
                    string asb = d.ContainsKey("asb") ? Convert.ToString(d["asb"] ?? "").Trim() : "";
                    bool ok = d.ContainsKey("ok") && Convert.ToBoolean(d["ok"]);
                    if (string.IsNullOrEmpty(asb)) continue;

                    if (baseline != null && baseline.PreExistingAsbIds.Contains(asb))
                    {
                        hitPreExistingAnchor = true;
                        break;
                    }
                    if (ok && seen.Add(asb))
                        newestFirst.Add(asb);
                }

                if (hitPreExistingAnchor || scrollStatus == "AT_END" || scrollStatus == "NO_VP" ||
                    ((baseline == null || baseline.PreExistingAsbIds.Count == 0) && countInPage < 30 && scrollStatus == "AT_END"))
                    break;
            }

            await _cdp.EvalStringAsync(sess, @"
(function(){
    var vp = document.querySelector('cdk-virtual-scroll-viewport.tiles-container') || document.querySelector('cdk-virtual-scroll-viewport');
    if (vp) vp.scrollTop = 0;
    return 'OK';
})()", ct);
            await Task.Delay(250, ct);

            newestFirst.Reverse();
            return newestFirst;
        }

        private List<Tuple<FlowTakeSpec, string>> BuildChronologicalDownloadPlan(
            List<FlowTakeSpec> targetTakes,
            List<SessionCompletedVideoInfo> agentVideos,
            List<string> gridAsbIdsOldestFirst)
        {
            HashSet<string> validInGrid = new HashSet<string>(gridAsbIdsOldestFirst ?? new List<string>(), StringComparer.Ordinal);
            List<SessionCompletedVideoInfo> candidates = new List<SessionCompletedVideoInfo>();
            HashSet<string> knownAgentAsbs = new HashSet<string>(StringComparer.Ordinal);

            if (agentVideos != null)
            {
                for (int i = 0; i < agentVideos.Count; i++)
                {
                    SessionCompletedVideoInfo av = agentVideos[i];
                    if (av == null || string.IsNullOrEmpty(av.AsbId)) continue;
                    knownAgentAsbs.Add(av.AsbId);
                    if (validInGrid.Count == 0 || validInGrid.Contains(av.AsbId))
                        candidates.Add(av);
                }
            }

            string[] assignedAsbPerTake = new string[targetTakes.Count];
            HashSet<string> usedAsbIds = new HashSet<string>(StringComparer.Ordinal);

            // Passo 1: Casamento Global Best-First (1:1 por maior pontuação decrescente entre todos os pares Take x Vídeo).
            double[,] scoreMatrix = new double[targetTakes.Count, candidates.Count];
            int[] bestTakeForVideo = new int[candidates.Count];
            double[] bestScoreForVideo = new double[candidates.Count];

            List<TakeVideoMatchCandidate> highConfidencePairs = new List<TakeVideoMatchCandidate>();

            for (int v = 0; v < candidates.Count; v++)
            {
                bestTakeForVideo[v] = -1;
                bestScoreForVideo[v] = 0.0;
                SessionCompletedVideoInfo vid = candidates[v];
                if (string.IsNullOrWhiteSpace(vid.AltPrompt))
                    continue;

                for (int k = 0; k < targetTakes.Count; k++)
                {
                    double s = ComputeTakeToVideoMatchScore(targetTakes[k], vid.AltPrompt);
                    scoreMatrix[k, v] = s;
                    if (s > bestScoreForVideo[v])
                    {
                        bestScoreForVideo[v] = s;
                        bestTakeForVideo[v] = k;
                    }

                    if (s >= 0.62)
                    {
                        TakeVideoMatchCandidate pair = new TakeVideoMatchCandidate();
                        pair.TakeIndex = k;
                        pair.VideoIndex = v;
                        pair.AsbId = vid.AsbId;
                        pair.RawScore = s;
                        pair.ScoreBucket = s >= 0.93 ? 50 : (int)Math.Round(s * 50.0);
                        highConfidencePairs.Add(pair);
                    }
                }
            }

            highConfidencePairs.Sort(delegate(TakeVideoMatchCandidate a, TakeVideoMatchCandidate b)
            {
                int cmpBucket = b.ScoreBucket.CompareTo(a.ScoreBucket);
                if (cmpBucket != 0) return cmpBucket;
                int cmpVid = b.VideoIndex.CompareTo(a.VideoIndex);
                if (cmpVid != 0) return cmpVid;
                int cmpRaw = b.RawScore.CompareTo(a.RawScore);
                if (cmpRaw != 0) return cmpRaw;
                return a.TakeIndex.CompareTo(b.TakeIndex);
            });

            for (int p = 0; p < highConfidencePairs.Count; p++)
            {
                TakeVideoMatchCandidate pair = highConfidencePairs[p];
                if (!string.IsNullOrEmpty(assignedAsbPerTake[pair.TakeIndex]))
                    continue;
                if (usedAsbIds.Contains(pair.AsbId))
                    continue;

                assignedAsbPerTake[pair.TakeIndex] = pair.AsbId;
                usedAsbIds.Add(pair.AsbId);
            }

            // Passo 1.5: Descarta duplicatas antigas de takes já atribuídos e permite casamento secundário (>= 0.42)
            // SOMENTE se o melhor take daquele vídeo em TODO o episódio for justamente um take ainda não atribuído!
            List<TakeVideoMatchCandidate> secondaryPairs = new List<TakeVideoMatchCandidate>();
            for (int v = 0; v < candidates.Count; v++)
            {
                SessionCompletedVideoInfo vid = candidates[v];
                if (usedAsbIds.Contains(vid.AsbId) || string.IsNullOrWhiteSpace(vid.AltPrompt))
                    continue;

                int topTakeIdx = bestTakeForVideo[v];
                double topScore = bestScoreForVideo[v];
                if (topTakeIdx < 0) continue;

                if (!string.IsNullOrEmpty(assignedAsbPerTake[topTakeIdx]) && topScore >= 0.55)
                {
                    usedAsbIds.Add(vid.AsbId);
                    continue;
                }

                if (string.IsNullOrEmpty(assignedAsbPerTake[topTakeIdx]) && topScore >= 0.42)
                {
                    TakeVideoMatchCandidate sec = new TakeVideoMatchCandidate();
                    sec.TakeIndex = topTakeIdx;
                    sec.VideoIndex = v;
                    sec.AsbId = vid.AsbId;
                    sec.RawScore = topScore;
                    sec.ScoreBucket = (int)Math.Round(topScore * 50.0);
                    secondaryPairs.Add(sec);
                }
            }

            secondaryPairs.Sort(delegate(TakeVideoMatchCandidate a, TakeVideoMatchCandidate b)
            {
                int cmpRaw = b.RawScore.CompareTo(a.RawScore);
                if (cmpRaw != 0) return cmpRaw;
                return b.VideoIndex.CompareTo(a.VideoIndex);
            });

            for (int p = 0; p < secondaryPairs.Count; p++)
            {
                TakeVideoMatchCandidate sec = secondaryPairs[p];
                if (string.IsNullOrEmpty(assignedAsbPerTake[sec.TakeIndex]) && !usedAsbIds.Contains(sec.AsbId))
                {
                    assignedAsbPerTake[sec.TakeIndex] = sec.AsbId;
                    usedAsbIds.Add(sec.AsbId);
                }
            }

            // Passo 2: Fallback estritamente cronológico APENAS para vídeos sem prompt (alt vazio ou ausente no painel do Agente)
            List<string> unknownPromptChronologicalPool = new List<string>();
            for (int v = 0; v < candidates.Count; v++)
            {
                SessionCompletedVideoInfo av = candidates[v];
                if (!usedAsbIds.Contains(av.AsbId) && string.IsNullOrWhiteSpace(av.AltPrompt) &&
                    !unknownPromptChronologicalPool.Contains(av.AsbId))
                {
                    unknownPromptChronologicalPool.Add(av.AsbId);
                }
            }

            if (gridAsbIdsOldestFirst != null)
            {
                for (int g = 0; g < gridAsbIdsOldestFirst.Count; g++)
                {
                    string gAsb = gridAsbIdsOldestFirst[g];
                    if (!usedAsbIds.Contains(gAsb) && !knownAgentAsbs.Contains(gAsb) &&
                        !unknownPromptChronologicalPool.Contains(gAsb))
                    {
                        unknownPromptChronologicalPool.Add(gAsb);
                    }
                }
            }

            int poolCursor = 0;
            for (int k = 0; k < targetTakes.Count; k++)
            {
                if (string.IsNullOrEmpty(assignedAsbPerTake[k]) && poolCursor < unknownPromptChronologicalPool.Count)
                {
                    string fallbackAsb = unknownPromptChronologicalPool[poolCursor++];
                    assignedAsbPerTake[k] = fallbackAsb;
                    usedAsbIds.Add(fallbackAsb);
                }
            }

            Dictionary<string, string> promptByAsb = new Dictionary<string, string>(StringComparer.Ordinal);
            for (int v = 0; v < candidates.Count; v++)
            {
                if (!string.IsNullOrEmpty(candidates[v].AsbId) && !string.IsNullOrWhiteSpace(candidates[v].AltPrompt))
                    promptByAsb[candidates[v].AsbId] = candidates[v].AltPrompt;
            }

            int exactTagCount = 0;
            List<Tuple<FlowTakeSpec, string>> plan = new List<Tuple<FlowTakeSpec, string>>();
            for (int k = 0; k < targetTakes.Count; k++)
            {
                if (!string.IsNullOrEmpty(assignedAsbPerTake[k]))
                {
                    string chosenAsb = assignedAsbPerTake[k];
                    plan.Add(Tuple.Create(targetTakes[k], chosenAsb));
                    string matchedPrompt;
                    if (promptByAsb.TryGetValue(chosenAsb, out matchedPrompt) &&
                        TryExtractExplicitTakeTagNumber(matchedPrompt) == targetTakes[k].TakeNumber)
                    {
                        exactTagCount++;
                    }
                }
                else
                {
                    _log(string.Format("[Google Flow -> Grok] Take_{0:00} não gerou vídeo concluído no Google Flow -> será gerado no Grok Vídeo.", targetTakes[k].TakeNumber));
                }
            }

            if (plan.Count > 0)
            {
                _log(string.Format("[Google Flow] Identificação de takes: {0}/{1} confirmados por tag exata [TAKE_XX] ({2} por reserva de conteúdo).",
                    exactTagCount, plan.Count, plan.Count - exactTagCount));
            }

            return plan;
        }

        private async Task EnrichMissingVideoPromptsFromGridTilesAsync(
            string sess,
            List<SessionCompletedVideoInfo> agentVideos,
            List<string> gridAsbIdsOldestFirst,
            CancellationToken ct)
        {
            if (agentVideos == null || gridAsbIdsOldestFirst == null || gridAsbIdsOldestFirst.Count == 0)
                return;

            Dictionary<string, SessionCompletedVideoInfo> byAsb = new Dictionary<string, SessionCompletedVideoInfo>(StringComparer.Ordinal);
            for (int i = 0; i < agentVideos.Count; i++)
            {
                SessionCompletedVideoInfo info = agentVideos[i];
                if (info != null && !string.IsNullOrEmpty(info.AsbId))
                    byAsb[info.AsbId] = info;
            }

            List<string> missingAsbs = new List<string>();
            for (int g = 0; g < gridAsbIdsOldestFirst.Count; g++)
            {
                string gAsb = gridAsbIdsOldestFirst[g];
                if (string.IsNullOrEmpty(gAsb)) continue;
                SessionCompletedVideoInfo existing;
                if (!byAsb.TryGetValue(gAsb, out existing) || string.IsNullOrWhiteSpace(existing.AltPrompt))
                {
                    if (!missingAsbs.Contains(gAsb))
                        missingAsbs.Add(gAsb);
                }
            }

            if (missingAsbs.Count == 0)
                return;

            for (int m = 0; m < missingAsbs.Count; m++)
            {
                ct.ThrowIfCancellationRequested();
                string gAsb = missingAsbs[m];
                try
                {
                    Dictionary<string, object> cardCenter = await ScrollToAndLocateTileByAsbIdAsync(sess, gAsb, ct);
                    if (cardCenter == null) continue;

                    await _cdp.HoverAsync(sess, Convert.ToInt32(cardCenter["x"]), Convert.ToInt32(cardCenter["y"]), ct);
                    await Task.Delay(380, ct);

                    string b64Asb = Convert.ToBase64String(Encoding.UTF8.GetBytes(gAsb));
                    Dictionary<string, object> reusePt = await _cdp.EvalJsonAsync(sess, string.Format(@"
(function(){{
    var want = atob('{0}');
    var tile = Array.from(document.querySelectorAll('flow-video-tile')).find(t => {{
        var vid = t.querySelector('video');
        var img = t.querySelector('img');
        var u = (vid ? ((vid.getAttribute('src') || '') + ' ' + (vid.getAttribute('poster') || '')) : '') + ' ' +
                (img ? (img.getAttribute('src') || '') : '');
        return u.indexOf(want) >= 0;
    }});
    if (!tile) return null;
    var btn = tile.querySelector('button[aria-label*=""Reutilizar""], button[aria-label*=""Reuse""]') ||
              Array.from(tile.querySelectorAll('button')).find(b => {{
                  var al = (b.getAttribute('aria-label') || '');
                  var txt = (b.innerText || '').trim();
                  return al.indexOf('Reutilizar') >= 0 || al.indexOf('Reuse') >= 0 || txt === 'undo' || txt === 'replay';
              }});
    if (!btn) return null;
    var r = btn.getBoundingClientRect();
    if (r.width < 4) {{
        btn.click();
        return JSON.stringify({{ clickedNative: true, x: 0, y: 0 }});
    }}
    return JSON.stringify({{ clickedNative: false, x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) }});
}})()", b64Asb), ct);

                    if (reusePt == null) continue;
                    bool clickedNative = reusePt.ContainsKey("clickedNative") && Convert.ToBoolean(reusePt["clickedNative"]);
                    if (!clickedNative)
                    {
                        await _cdp.ClickAtAsync(sess, Convert.ToInt32(reusePt["x"]), Convert.ToInt32(reusePt["y"]), ct);
                    }

                    await Task.Delay(850, ct);
                    string recoveredPrompt = await ReadCurrentFlowTextboxAsync(sess, ct);
                    await InsertTextIntoFlowTextboxAsync(sess, "", true, ct);
                    await ClearAttachedPromptChipsAsync(sess, ct);

                    if (!string.IsNullOrWhiteSpace(recoveredPrompt))
                    {
                        SessionCompletedVideoInfo existing;
                        if (byAsb.TryGetValue(gAsb, out existing))
                        {
                            existing.AltPrompt = recoveredPrompt;
                        }
                        else
                        {
                            SessionCompletedVideoInfo added = new SessionCompletedVideoInfo();
                            added.AsbId = gAsb;
                            added.AltPrompt = recoveredPrompt;
                            agentVideos.Add(added);
                            byAsb[gAsb] = added;
                        }
                    }
                }
                catch (OperationCanceledException)
                {
                    throw;
                }
                catch
                {
                }
            }
        }

        private async Task<Dictionary<string, object>> ScrollToAndLocateTileByAsbIdAsync(
            string sess,
            string targetAsbId,
            CancellationToken ct)
        {
            string b64Asb = Convert.ToBase64String(Encoding.UTF8.GetBytes(targetAsbId));

            string locateAndCenterJs = string.Format(@"
(function(){{
    var want = atob('{0}');
    function findTile() {{
        return Array.from(document.querySelectorAll('flow-video-tile, flow-image-tile, flow-asset-tile, [data-asb-id]')).find(t => {{
            var host = t.closest('flow-video-tile, flow-image-tile, flow-asset-tile') || t;
            var vid = host.querySelector('video');
            var img = host.querySelector('img');
            var u = (vid ? ((vid.getAttribute('src') || '') + ' ' + (vid.getAttribute('poster') || '')) : '') + ' ' +
                    (img ? ((img.currentSrc || img.src || img.getAttribute('src') || '')) : '') + ' ' +
                    (host.getAttribute('data-asb-id') || '');
            return u.indexOf(want) >= 0;
        }});
    }}
    var tile = findTile();
    if (!tile) return null;
    tile.scrollIntoView({{ block: 'center', inline: 'nearest' }});
    var r = tile.getBoundingClientRect();
    return JSON.stringify({{ found: true, x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) }});
}})()", b64Asb);

            Dictionary<string, object> found = await _cdp.EvalJsonAsync(sess, locateAndCenterJs, ct);
            if (found == null)
            {
                // Varre o cdk-virtual-scroll-viewport desde scrollTop = 0 até montar o card com este targetAsbId
                for (int step = 0; step <= 20; step++)
                {
                    ct.ThrowIfCancellationRequested();
                    string stepRes = await _cdp.EvalStringAsync(sess, string.Format(@"
(function(){{
    var vp = document.querySelector('cdk-virtual-scroll-viewport.tiles-container') || document.querySelector('cdk-virtual-scroll-viewport');
    if (!vp) return 'NO_VP';
    var maxScroll = Math.max(0, vp.scrollHeight - vp.clientHeight);
    var nextTop = Math.min(maxScroll, {0});
    vp.scrollTop = nextTop;
    return nextTop >= maxScroll && {0} > 0 ? 'AT_END' : 'OK';
}})()", step * 420), ct);

                    await Task.Delay(340, ct);
                    found = await _cdp.EvalJsonAsync(sess, locateAndCenterJs, ct);
                    if (found != null) break;
                    if (stepRes == "AT_END" || stepRes == "NO_VP") break;
                }
            }

            if (found == null) return null;

            // Aguarda o virtual scroll estabilizar após scrollIntoView e RE-LOCALIZA pelo mesmo targetAsbId (imune a troca de índice DOM!)
            await Task.Delay(480, ct);

            Dictionary<string, object> settled = await _cdp.EvalJsonAsync(sess, string.Format(@"
(function(){{
    var want = atob('{0}');
    var tile = Array.from(document.querySelectorAll('flow-video-tile, flow-image-tile, flow-asset-tile, [data-asb-id]')).find(t => {{
        var host = t.closest('flow-video-tile, flow-image-tile, flow-asset-tile') || t;
        var vid = host.querySelector('video');
        var img = host.querySelector('img');
        var u = (vid ? ((vid.getAttribute('src') || '') + ' ' + (vid.getAttribute('poster') || '')) : '') + ' ' +
                (img ? ((img.currentSrc || img.src || img.getAttribute('src') || '')) : '') + ' ' +
                (host.getAttribute('data-asb-id') || '');
        return u.indexOf(want) >= 0;
    }});
    if (!tile) return null;
    var r = tile.getBoundingClientRect();
    if (r.top < 25 || r.bottom > window.innerHeight - 15) {{
        var vp = document.querySelector('cdk-virtual-scroll-viewport.tiles-container') || document.querySelector('cdk-virtual-scroll-viewport');
        if (vp) {{
            vp.scrollTop += (r.top + r.height/2) - (window.innerHeight / 2);
        }}
        r = tile.getBoundingClientRect();
    }}
    return JSON.stringify({{
        x: Math.round(r.left + r.width/2),
        y: Math.round(r.top + r.height/2),
        w: Math.round(r.width),
        h: Math.round(r.height)
    }});
}})()", b64Asb), ct);

            return settled ?? found;
        }

        private static bool HasActivePartialDownloadInDirs(string stagingDl)
        {
            try
            {
                if (!string.IsNullOrEmpty(stagingDl) && Directory.Exists(stagingDl))
                {
                    string[] stFiles = Directory.GetFiles(stagingDl);
                    for (int i = 0; i < stFiles.Length; i++)
                    {
                        if (stFiles[i].EndsWith(".crdownload", StringComparison.OrdinalIgnoreCase) ||
                            stFiles[i].EndsWith(".tmp", StringComparison.OrdinalIgnoreCase))
                            return true;
                    }
                }
            }
            catch { }

            try
            {
                string userDl = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads");
                if (Directory.Exists(userDl))
                {
                    DateTime recentCutoff = DateTime.UtcNow.AddSeconds(-35);
                    string[] uFiles = Directory.GetFiles(userDl);
                    for (int i = 0; i < uFiles.Length; i++)
                    {
                        if ((uFiles[i].EndsWith(".crdownload", StringComparison.OrdinalIgnoreCase) ||
                             uFiles[i].EndsWith(".tmp", StringComparison.OrdinalIgnoreCase)) &&
                            File.GetLastWriteTimeUtc(uFiles[i]) >= recentCutoff)
                        {
                            return true;
                        }
                    }
                }
            }
            catch { }

            return false;
        }

        private async Task DownloadSingleTileByAsbIdAsync(
            string sess,
            string targetAsbId,
            int targetTakeNumber,
            int progressIdx,
            int progressTotal,
            string stagingDl,
            string finalTakePath,
            CancellationToken ct)
        {
            _log(string.Format("[Google Flow] Baixando cena {0}/{1} -> Take_{2:00}.mp4 (720p)...",
                progressIdx, progressTotal, targetTakeNumber));

            string b64Asb = Convert.ToBase64String(Encoding.UTF8.GetBytes(targetAsbId));
            string downloadedMp4 = "";

            for (int dlAttempt = 1; dlAttempt <= 2; dlAttempt++)
            {
                ct.ThrowIfCancellationRequested();
                Dictionary<string, object> dlMenuPt = null;

                for (int menuAttempt = 1; menuAttempt <= 3; menuAttempt++)
                {
                    ct.ThrowIfCancellationRequested();

                    // Fecha eventual menu anterior residual
                    string hasOpenMenu = await _cdp.EvalStringAsync(sess, @"
(function(){
    var open = Array.from(document.querySelectorAll('.cdk-overlay-container [role=""menuitem""]'))
        .some(el => el.getBoundingClientRect().width > 10);
    return open ? 'OPEN' : 'CLOSED';
})()", ct);
                    if (hasOpenMenu == "OPEN")
                    {
                        await _cdp.PressEscapeAsync(sess, ct);
                        await Task.Delay(260, ct);
                    }

                    Dictionary<string, object> cardCenter = await ScrollToAndLocateTileByAsbIdAsync(sess, targetAsbId, ct);
                    if (cardCenter == null)
                        throw new InvalidOperationException(string.Format("Card de vídeo (ID {0}) do Take_{1:00} não foi localizado no grid do Google Flow.",
                            targetAsbId.Substring(0, Math.Min(12, targetAsbId.Length)), targetTakeNumber));

                    await _cdp.HoverAsync(sess, Convert.ToInt32(cardCenter["x"]), Convert.ToInt32(cardCenter["y"]), ct);
                    await Task.Delay(420, ct);

                    // Re-localiza o botão 'Mais opções' (⋮) diretamente dentro do card com este targetAsbId
                    Dictionary<string, object> morePt = await _cdp.EvalJsonAsync(sess, string.Format(@"
(function(){{
    var want = atob('{0}');
    var tile = Array.from(document.querySelectorAll('flow-video-tile')).find(t => {{
        var vid = t.querySelector('video');
        var img = t.querySelector('img');
        var u = (vid ? ((vid.getAttribute('src') || '') + ' ' + (vid.getAttribute('poster') || '')) : '') + ' ' +
                (img ? (img.getAttribute('src') || '') : '');
        return u.indexOf(want) >= 0;
    }});
    if (!tile) return null;
    var btn = tile.querySelector('button[aria-label*=""Mais op""], button[aria-label*=""More""]') ||
              Array.from(tile.querySelectorAll('button')).find(b => (b.innerText || '').trim() === 'more_vert');
    if (!btn) return null;
    var r = btn.getBoundingClientRect();
    if (r.width < 4) return null;
    return JSON.stringify({{ x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) }});
}})()", b64Asb), ct);

                    if (morePt == null)
                    {
                        if (menuAttempt < 3)
                        {
                            await Task.Delay(350, ct);
                            continue;
                        }
                        throw new InvalidOperationException(string.Format("Botão 'Mais opções' (⋮) não encontrado no card do Take_{0:00}.", targetTakeNumber));
                    }

                    if (menuAttempt == 3)
                    {
                        // Fallback na 3ª tentativa: aciona .click() nativo direto no botão Mais opções do tile específico
                        await _cdp.EvalStringAsync(sess, string.Format(@"
(function(){{
    var want = atob('{0}');
    var tile = Array.from(document.querySelectorAll('flow-video-tile')).find(t => {{
        var vid = t.querySelector('video');
        var img = t.querySelector('img');
        var u = (vid ? ((vid.getAttribute('src') || '') + ' ' + (vid.getAttribute('poster') || '')) : '') + ' ' +
                (img ? (img.getAttribute('src') || '') : '');
        return u.indexOf(want) >= 0;
    }});
    if (!tile) return 'NO_TILE';
    var btn = tile.querySelector('button[aria-label*=""Mais op""], button[aria-label*=""More""]');
    if (btn) btn.click();
    return 'CLICKED';
}})()", b64Asb), ct);
                    }
                    else
                    {
                        await _cdp.ClickAtAsync(sess, Convert.ToInt32(morePt["x"]), Convert.ToInt32(morePt["y"]), ct);
                    }

                    for (int poll = 0; poll < 4; poll++)
                    {
                        await Task.Delay(320, ct);
                        dlMenuPt = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var items = Array.from(document.querySelectorAll('.cdk-overlay-container [role=""menuitem""], [role=""menuitem""]'))
        .filter(el => el.getBoundingClientRect().width > 10);
    var m = items.find(el => {
        var t = (el.innerText || '');
        return t.indexOf('Fazer o download') >= 0 || t.indexOf('Baixar') >= 0 || t.indexOf('Download') >= 0;
    });
    if (!m) return null;
    var r = m.getBoundingClientRect();
    return JSON.stringify({ x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) });
})()", ct);
                        if (dlMenuPt != null) break;
                    }

                    if (dlMenuPt != null) break;
                }

                if (dlMenuPt == null)
                    throw new InvalidOperationException(string.Format("Opção 'Fazer o download' não apareceu no menu do card do Take_{0:00} no Google Flow.", targetTakeNumber));

                HashSet<string> beforeFiles = new HashSet<string>(Directory.GetFiles(stagingDl), StringComparer.OrdinalIgnoreCase);
                await _cdp.ClickAtAsync(sess, Convert.ToInt32(dlMenuPt["x"]), Convert.ToInt32(dlMenuPt["y"]), ct);

                // Aguarda submenu de resolução ("720p" / "Resolução original") abrir e clica
                Dictionary<string, object> res720Pt = null;
                for (int poll = 0; poll < 8; poll++)
                {
                    await Task.Delay(300, ct);
                    res720Pt = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var items = Array.from(document.querySelectorAll('.cdk-overlay-container [role=""menuitem""], [role=""menuitem""], .cdk-overlay-container button'))
        .filter(el => el.getBoundingClientRect().width > 10);
    var m = items.find(el => {
        var t = (el.innerText || '');
        return t.indexOf('720p') >= 0 || t.indexOf('original') >= 0 || t.indexOf('Original') >= 0;
    });
    if (!m) return null;
    var r = m.getBoundingClientRect();
    return JSON.stringify({ x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) });
})()", ct);
                    if (res720Pt != null) break;
                }

                if (res720Pt != null)
                {
                    await _cdp.ClickAtAsync(sess, Convert.ToInt32(res720Pt["x"]), Convert.ToInt32(res720Pt["y"]), ct);
                }
                else
                {
                    // Se o submenu 720p não abriu, confere por 3,5s se houve download direto antes de tentar reabrir o menu (nunca trava 90s à toa!)
                    downloadedMp4 = await _cdp.WaitForSingleDownloadAsync(stagingDl, beforeFiles, 80 * 1024, 3500, ct);
                    if (!string.IsNullOrEmpty(downloadedMp4))
                        break;

                    if (HasActivePartialDownloadInDirs(stagingDl))
                    {
                        downloadedMp4 = await _cdp.WaitForSingleDownloadAsync(stagingDl, beforeFiles, 80 * 1024, 70000, ct);
                        if (!string.IsNullOrEmpty(downloadedMp4))
                            break;
                    }

                    if (dlAttempt < 2)
                    {
                        _log(string.Format("[Google Flow | Download] Submenu '720p' não abriu para Take_{0:00} -> tentando abrir o menu novamente...", targetTakeNumber));
                        await _cdp.PressEscapeAsync(sess, ct);
                        await Task.Delay(400, ct);
                        continue;
                    }
                    break;
                }

                // Regra 11: Aguardar 1:1 o término completo deste .mp4 antes de clicar no próximo card
                if (dlAttempt == 1)
                {
                    downloadedMp4 = await _cdp.WaitForSingleDownloadAsync(stagingDl, beforeFiles, 80 * 1024, 22000, ct);
                    if (!string.IsNullOrEmpty(downloadedMp4))
                        break;

                    if (HasActivePartialDownloadInDirs(stagingDl))
                    {
                        // Download já está em andamento (rede mais lenta) -> aguarda completar sem interromper
                        downloadedMp4 = await _cdp.WaitForSingleDownloadAsync(stagingDl, beforeFiles, 80 * 1024, 70000, ct);
                        if (!string.IsNullOrEmpty(downloadedMp4))
                            break;
                    }
                    else
                    {
                        _log(string.Format("[Google Flow | Download] Download de Take_{0:00} não iniciou em 22s -> repetindo clique em 'Fazer o download (720p)'...", targetTakeNumber));
                        await _cdp.PressEscapeAsync(sess, ct);
                        await Task.Delay(450, ct);
                        continue;
                    }
                }
                else
                {
                    downloadedMp4 = await _cdp.WaitForSingleDownloadAsync(stagingDl, beforeFiles, 80 * 1024, 65000, ct);
                    if (!string.IsNullOrEmpty(downloadedMp4))
                        break;
                }
            }

            if (string.IsNullOrEmpty(downloadedMp4))
                throw new IOException(string.Format("Timeout aguardando download 720p do Take_{0:00}.mp4 no Google Flow.", targetTakeNumber));

            if (File.Exists(finalTakePath))
                File.Delete(finalTakePath);
            File.Move(downloadedMp4, finalTakePath);

            _log(string.Format("[Google Flow] Salvo Take_{0:00}.mp4 ({1:0.0} MB).",
                targetTakeNumber, new FileInfo(finalTakePath).Length / (1024.0 * 1024.0)));
        }

        private async Task DownloadAllCompletedTakesIn720pAsync(
            string sess,
            PreSessionGridBaseline baseline,
            EpisodeWorkItem ep,
            List<FlowTakeSpec> targetTakes,
            CancellationToken ct)
        {
            // Regra 28 e 32: Mapear exclusivamente os vídeos gerados nesta Nova sessão em ordem cronológica (Take_01..Take_N) e baixar em 720p
            string stagingDl = Path.Combine(ep.TakesDir, "_flow_dl_" + DateTime.Now.ToString("HHmmss"));
            Directory.CreateDirectory(stagingDl);
            await _cdp.SetDownloadBehaviorAsync(stagingDl, ct);

            try
            {
                List<SessionCompletedVideoInfo> agentVideos = await CollectSessionVideosFromAgentPanelAsync(sess, baseline, ct);
                List<string> gridAsbIdsOldestFirst = await CollectSessionGridAsbIdsOldestFirstAsync(sess, baseline, ct);
                await EnrichMissingVideoPromptsFromGridTilesAsync(sess, agentVideos, gridAsbIdsOldestFirst, ct);

                List<Tuple<FlowTakeSpec, string>> downloadPlan = BuildChronologicalDownloadPlan(targetTakes, agentVideos, gridAsbIdsOldestFirst);

                _log(string.Format("[Google Flow] Passo 7: Iniciando download cronológico em 720p de {0}/{1} takes desta sessão...",
                    downloadPlan.Count, targetTakes.Count));

                for (int i = 0; i < downloadPlan.Count; i++)
                {
                    ct.ThrowIfCancellationRequested();
                    FlowTakeSpec takeSpec = downloadPlan[i].Item1;
                    string targetAsbId = downloadPlan[i].Item2;
                    string finalTakePath = Path.Combine(ep.TakesDir, string.Format("Take_{0:00}.mp4", takeSpec.TakeNumber));

                    try
                    {
                        await DownloadSingleTileByAsbIdAsync(
                            sess,
                            targetAsbId,
                            takeSpec.TakeNumber,
                            i + 1,
                            downloadPlan.Count,
                            stagingDl,
                            finalTakePath,
                            ct);
                    }
                    catch (OperationCanceledException)
                    {
                        throw;
                    }
                    catch (Exception ex)
                    {
                        string nextStepHint = _config.AreAllGrokProfilesMarkedExhausted()
                            ? "Poderá ser recuperado na inspeção do projeto."
                            : "Será gerado via fallback no Grok Vídeo...";
                        _log(string.Format("[Google Flow | Aviso] Falha ao baixar Take_{0:00}.mp4 no Flow ({1}). {2}",
                            takeSpec.TakeNumber, ex.Message, nextStepHint));
                    }
                }
            }
            finally
            {
                string cleanupDir = stagingDl;
                Task ignoredCleanup = Task.Run(async () =>
                {
                    try { await _cdp.ResetDownloadBehaviorToDefaultAsync(); } catch { }
                    try { Directory.Delete(cleanupDir, true); } catch { }
                });
            }
        }
    }
}
