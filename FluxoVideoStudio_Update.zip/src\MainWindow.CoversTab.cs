using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Microsoft.Win32;

namespace FluxoVideoStudio
{
    public partial class MainWindow : Window
    {
        private CheckBox _chkStageCovers;
        private TextBlock _badgeCovers;

        private TextBox _txtCoverTitle;
        private ComboBox _cmbCoverStyle;
        private ComboBox _cmbCoverOptionsCount;
        private WrapPanel _wrapCoverCharChecks;
        private StackPanel _pnlCoverRefModels;
        private TextBox _txtCoversPromptPreview;
        private TextBlock _lblCoversSummary;
        private WrapPanel _wrapGeneratedCovers;

        private StoryCoverConfig _currentCoverConfig = new StoryCoverConfig();
        private bool _suppressCoverUiEvents;

        private TabItem BuildCoversTab()
        {
            TabItem tab = new TabItem { Header = "  🎨 Capas (9:16)  " };
            Grid root = new Grid { Margin = new Thickness(6) };
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto }); // Action buttons
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto }); // Title + Character selector
            root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) }); // Split body

            // Row 0: Top action bar
            WrapPanel bar = new WrapPanel { Margin = new Thickness(0, 0, 0, 8) };

            Button btnPickRefs = CreateStyledButton("📂 Selecionar Referências do PC...", AccentPrimary, Brushes.White, new Thickness(11, 6, 11, 6));
            btnPickRefs.FontWeight = FontWeights.Bold;
            btnPickRefs.Margin = new Thickness(0, 0, 6, 4);
            btnPickRefs.ToolTip = "Escolher manualmente no PC quais imagens de capa servirão de modelo de estilo/tipografia para esta história";
            btnPickRefs.Click += (s, e) =>
            {
                if (_selectedEpisode == null)
                {
                    MessageBox.Show("Selecione primeiro uma história na coluna esquerda.", "Capas 9:16", MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }
                PromptSelectCoverReferenceImagesForStory(_selectedEpisode, false, false);
            };
            bar.Children.Add(btnPickRefs);

            Button btnAddMoreRefs = CreateStyledButton("➕ Adicionar Mais", BgCard, TextPrimary, new Thickness(10, 6, 10, 6));
            btnAddMoreRefs.Margin = new Thickness(0, 0, 6, 4);
            btnAddMoreRefs.Click += (s, e) =>
            {
                if (_selectedEpisode == null) return;
                PromptSelectCoverReferenceImagesForStory(_selectedEpisode, true, false);
            };
            bar.Children.Add(btnAddMoreRefs);

            Button btnUseStylePresets = CreateStyledButton("✨ 3 Modelos do Estilo", AccentBlue, Brushes.White, new Thickness(10, 6, 10, 6));
            btnUseStylePresets.FontWeight = FontWeights.SemiBold;
            btnUseStylePresets.Margin = new Thickness(0, 0, 6, 4);
            btnUseStylePresets.ToolTip = "Carregar automaticamente os 3 modelos prontos do estilo ativo (Novela Mística, Novela / Reflexão ou Terror) sem precisar selecionar imagens do PC";
            btnUseStylePresets.Click += (s, e) =>
            {
                if (_selectedEpisode == null)
                {
                    MessageBox.Show("Selecione primeiro uma história na coluna esquerda.", "Capas 9:16", MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }
                if (_currentCoverConfig == null)
                    _currentCoverConfig = CoverGenerator.LoadOrCreateStoryCoverConfig(_selectedStory, _selectedEpisode);
                SaveCurrentCoverConfigFromUi();
                EpisodeWorkItem ep1Preset = CoverGenerator.ResolveEp1Episode(_selectedStory, _selectedEpisode);
                GenreType effGenre = CoverGenerator.ResolveEffectiveCoverGenre(ep1Preset, _currentCoverConfig);
                _currentCoverConfig.ReferenceModels = CoverGenerator.BuildPresetModelsForGenre(effGenre);
                CoverGenerator.SaveStoryCoverConfigAndPrompts(ep1Preset, _currentCoverConfig);
                RefreshCoversTabUi();
                AppendLog(string.Format("[Capas 9:16] 3 modelos prontos do estilo '{0}' carregados para '{1}'!",
                    CoverGenerator.GetGenreDisplayLabel(effGenre), _selectedEpisode.StoryName));
            };
            bar.Children.Add(btnUseStylePresets);

            Button btnClearRefs = CreateStyledButton("🗑 Limpar Modelos", BgCard, TextSecondary, new Thickness(10, 6, 10, 6));
            btnClearRefs.Margin = new Thickness(0, 0, 10, 4);
            btnClearRefs.Click += (s, e) =>
            {
                if (_selectedEpisode == null || _currentCoverConfig == null) return;
                _currentCoverConfig.ReferenceModels.Clear();
                SaveCurrentCoverConfigFromUi();
                RefreshCoversTabUi();
            };
            bar.Children.Add(btnClearRefs);

            Button btnCopyAll = CreateStyledButton("📋 Copiar Comando Geral", AccentAmber, Brushes.Black, new Thickness(11, 6, 11, 6));
            btnCopyAll.FontWeight = FontWeights.Bold;
            btnCopyAll.Margin = new Thickness(0, 0, 6, 4);
            btnCopyAll.Click += (s, e) =>
            {
                SaveCurrentCoverConfigFromUi();
                string cmd = _txtCoversPromptPreview != null ? (_txtCoversPromptPreview.Text ?? "") : "";
                if (!string.IsNullOrWhiteSpace(cmd))
                {
                    Clipboard.SetText(cmd);
                    AppendLog("[Capas 9:16] Comando completo copiado para a área de transferência!");
                }
            };
            bar.Children.Add(btnCopyAll);

            Button btnGenMissing = CreateStyledButton("🎨 Gerar e Baixar Capas", AccentGreen, Brushes.White, new Thickness(12, 6, 12, 6));
            btnGenMissing.FontWeight = FontWeights.Bold;
            btnGenMissing.Margin = new Thickness(0, 0, 6, 4);
            btnGenMissing.ToolTip = "Anexa apenas os personagens selecionados de EP.1\\assets e gera automaticamente as capas pendentes em 9:16 no Grok/Flow";
            btnGenMissing.Click += async (s, e) => await ExecuteStandaloneCoversActionAsync(false, null);
            bar.Children.Add(btnGenMissing);

            Button btnRemakeAll = CreateStyledButton("🔄 Refazer Todas", BgCard, TextPrimary, new Thickness(10, 6, 10, 6));
            btnRemakeAll.Margin = new Thickness(0, 0, 6, 4);
            btnRemakeAll.Click += async (s, e) => await ExecuteStandaloneCoversActionAsync(true, null);
            bar.Children.Add(btnRemakeAll);

            Button btnSalvageFlow = CreateStyledButton("📥 Resgatar do Flow", AccentBlue, Brushes.White, new Thickness(10, 6, 10, 6));
            btnSalvageFlow.FontWeight = FontWeights.SemiBold;
            btnSalvageFlow.Margin = new Thickness(0, 0, 6, 4);
            btnSalvageFlow.ToolTip = "Baixar imediatamente da grade atual do projeto Google Flow as capas 9:16 já geradas na tela (sem regerar)";
            btnSalvageFlow.Click += async (s, e) => await ExecuteSalvageFlowCoversClickAsync();
            bar.Children.Add(btnSalvageFlow);

            Button btnOpenFolder = CreateStyledButton("📂 Abrir Pasta capas\\", BgCard, TextPrimary, new Thickness(10, 6, 10, 6));
            btnOpenFolder.Margin = new Thickness(0, 0, 0, 4);
            btnOpenFolder.Click += (s, e) =>
            {
                if (_selectedEpisode == null) return;
                string dir = CoverGenerator.GetStoryCoversDir(_selectedEpisode);
                if (!string.IsNullOrEmpty(dir))
                {
                    Directory.CreateDirectory(dir);
                    try { Process.Start(new ProcessStartInfo(dir) { UseShellExecute = true }); } catch { }
                }
            };
            bar.Children.Add(btnOpenFolder);

            Grid.SetRow(bar, 0);
            root.Children.Add(bar);

            // Row 1: Story Cover Title + Options count + EP.1 Character Checkboxes
            Border cfgBox = new Border
            {
                Background = BgCard,
                BorderBrush = BorderSubtle,
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(8),
                Padding = new Thickness(10, 8, 10, 8),
                Margin = new Thickness(0, 0, 0, 8)
            };
            StackPanel cfgStack = new StackPanel();

            Grid titleRow = new Grid { Margin = new Thickness(0, 0, 0, 6) };
            titleRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto }); // 0: label Título
            titleRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) }); // 1: txt título
            titleRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto }); // 2: btn Título Curto
            titleRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto }); // 3: label Estilo
            titleRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto }); // 4: cmb Estilo
            titleRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto }); // 5: label Opções
            titleRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto }); // 6: cmb Opções
            titleRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto }); // 7: btn Atualizar

            titleRow.Children.Add(new TextBlock
            {
                Text = "Título na Capa:",
                FontSize = 12,
                FontWeight = FontWeights.Bold,
                Foreground = TextSecondary,
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(0, 0, 8, 0)
            });

            _txtCoverTitle = CreateStyledTextBox("TÍTULO DA HISTÓRIA");
            _txtCoverTitle.FontWeight = FontWeights.Bold;
            _txtCoverTitle.Margin = new Thickness(0, 0, 6, 0);
            Grid.SetColumn(_txtCoverTitle, 1);
            titleRow.Children.Add(_txtCoverTitle);

            Button btnShortenTitle = CreateStyledButton("✂ Título Curto", BgPanel, AccentAmber, new Thickness(8, 5, 8, 5));
            btnShortenTitle.ToolTip = "Encurtar automaticamente para 2 a 4 palavras de impacto (deixa as letras gigantes e idênticas ao modelo)";
            btnShortenTitle.Margin = new Thickness(0, 0, 10, 0);
            btnShortenTitle.Click += (s, e) =>
            {
                if (_txtCoverTitle == null) return;
                _txtCoverTitle.Text = CoverGenerator.ShortenToImpactPosterTitle(_txtCoverTitle.Text);
                SaveCurrentCoverConfigFromUi();
                RefreshCoversTabUi();
            };
            Grid.SetColumn(btnShortenTitle, 2);
            titleRow.Children.Add(btnShortenTitle);

            TextBlock lblStyle = new TextBlock
            {
                Text = "Estilo:",
                FontSize = 12,
                FontWeight = FontWeights.Bold,
                Foreground = TextSecondary,
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(0, 0, 6, 0)
            };
            Grid.SetColumn(lblStyle, 3);
            titleRow.Children.Add(lblStyle);

            _cmbCoverStyle = new ComboBox
            {
                Width = 195,
                Padding = new Thickness(6, 4, 6, 4),
                Margin = new Thickness(0, 0, 10, 0),
                VerticalAlignment = VerticalAlignment.Center,
                ToolTip = "Define o estilo visual e tipográfico da capa (Automático usa o gênero detectado da história: Novela Mística, Novela / Reflexão ou Terror)"
            };
            _cmbCoverStyle.Items.Add(new ComboBoxItem { Content = "Automático (Gênero)", Tag = "Auto" });
            _cmbCoverStyle.Items.Add(new ComboBoxItem { Content = "🔮 Novela Mística", Tag = "NovelaMistica" });
            _cmbCoverStyle.Items.Add(new ComboBoxItem { Content = "🎬 Novela / Reflexão", Tag = "NovelaReflexao" });
            _cmbCoverStyle.Items.Add(new ComboBoxItem { Content = "👻 Terror", Tag = "Terror" });
            _cmbCoverStyle.SelectedIndex = 0;
            _cmbCoverStyle.SelectionChanged += (s, e) =>
            {
                if (_suppressCoverUiEvents || _selectedEpisode == null || _currentCoverConfig == null) return;
                ComboBoxItem sel = _cmbCoverStyle.SelectedItem as ComboBoxItem;
                string newStyle = sel != null && sel.Tag is string ? (string)sel.Tag : "Auto";
                _currentCoverConfig.CoverStyle = newStyle;
                EpisodeWorkItem ep1Sty = CoverGenerator.ResolveEp1Episode(_selectedStory, _selectedEpisode);
                CoverGenerator.ReanalyzeModelsForGenre(ep1Sty, _currentCoverConfig);
                SaveCurrentCoverConfigFromUi();
                RefreshCoversTabUi();
                GenreType eff = CoverGenerator.ResolveEffectiveCoverGenre(ep1Sty, _currentCoverConfig);
                AppendLog(string.Format("[Capas 9:16] Estilo de capa atualizado para '{0}' -> modelos e prompts reajustados!",
                    CoverGenerator.GetGenreDisplayLabel(eff)));
            };
            Grid.SetColumn(_cmbCoverStyle, 4);
            titleRow.Children.Add(_cmbCoverStyle);

            TextBlock lblOpt = new TextBlock
            {
                Text = "Opções:",
                FontSize = 12,
                Foreground = TextSecondary,
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(0, 0, 6, 0)
            };
            Grid.SetColumn(lblOpt, 5);
            titleRow.Children.Add(lblOpt);

            _cmbCoverOptionsCount = new ComboBox
            {
                Width = 58,
                Padding = new Thickness(6, 4, 6, 4),
                Margin = new Thickness(0, 0, 10, 0),
                VerticalAlignment = VerticalAlignment.Center
            };
            _cmbCoverOptionsCount.Items.Add("1");
            _cmbCoverOptionsCount.Items.Add("2");
            _cmbCoverOptionsCount.Items.Add("3");
            _cmbCoverOptionsCount.SelectedIndex = 2;
            _cmbCoverOptionsCount.SelectionChanged += (s, e) =>
            {
                if (_suppressCoverUiEvents) return;
                SaveCurrentCoverConfigFromUi();
                RefreshCoversTabUi();
            };
            Grid.SetColumn(_cmbCoverOptionsCount, 6);
            titleRow.Children.Add(_cmbCoverOptionsCount);

            Button btnApplyTitle = CreateStyledButton("💾 Atualizar Prompts", BgPanel, TextPrimary, new Thickness(10, 5, 10, 5));
            btnApplyTitle.Click += (s, e) =>
            {
                SaveCurrentCoverConfigFromUi();
                RefreshCoversTabUi();
                AppendLog("[Capas 9:16] Título, estilo e seleção de personagens atualizados em 'prompts_capas.txt'.");
            };
            Grid.SetColumn(btnApplyTitle, 7);
            titleRow.Children.Add(btnApplyTitle);

            cfgStack.Children.Add(titleRow);

            StackPanel charHeaderRow = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 2, 0, 4) };
            charHeaderRow.Children.Add(new TextBlock
            {
                Text = "Personagens de EP.1\\assets enviados na geração (mantém o mesmo rosto sem enviar a imagem de referência):",
                FontSize = 11.5,
                FontWeight = FontWeights.SemiBold,
                Foreground = TextSecondary
            });
            cfgStack.Children.Add(charHeaderRow);

            _wrapCoverCharChecks = new WrapPanel();
            cfgStack.Children.Add(_wrapCoverCharChecks);

            cfgBox.Child = cfgStack;
            Grid.SetRow(cfgBox, 1);
            root.Children.Add(cfgBox);

            // Row 2: Two columns — Left: Selected Reference Models + Prompt Box | Right: Generated 9:16 Covers Gallery
            Grid split = new Grid();
            split.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(410) });
            split.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

            // Left column
            Border leftBox = new Border
            {
                Background = BgCard,
                BorderBrush = BorderSubtle,
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(8),
                Padding = new Thickness(10),
                Margin = new Thickness(0, 0, 6, 0)
            };
            Grid leftGrid = new Grid();
            leftGrid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            leftGrid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(165) });
            leftGrid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            leftGrid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });

            leftGrid.Children.Add(new TextBlock
            {
                Text = "MODELOS DE REFERÊNCIA SELECIONADOS DO PC:",
                FontSize = 11.5,
                FontWeight = FontWeights.Bold,
                Foreground = TextSecondary,
                Margin = new Thickness(0, 0, 0, 4)
            });

            ScrollViewer svRefs = new ScrollViewer
            {
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                Background = BgInput,
                Padding = new Thickness(4),
                Margin = new Thickness(0, 0, 0, 8)
            };
            _pnlCoverRefModels = new StackPanel();
            svRefs.Content = _pnlCoverRefModels;
            Grid.SetRow(svRefs, 1);
            leftGrid.Children.Add(svRefs);

            TextBlock lblPromptBox = new TextBlock
            {
                Text = "COMANDO MONTADO (ESTILO DOS MODELOS + TÍTULO DA HISTÓRIA):",
                FontSize = 11.5,
                FontWeight = FontWeights.Bold,
                Foreground = TextSecondary,
                Margin = new Thickness(0, 0, 0, 4)
            };
            Grid.SetRow(lblPromptBox, 2);
            leftGrid.Children.Add(lblPromptBox);

            _txtCoversPromptPreview = new TextBox
            {
                Background = BgInput,
                Foreground = TextPrimary,
                BorderBrush = BorderSubtle,
                BorderThickness = new Thickness(1),
                Padding = new Thickness(8),
                FontSize = 12,
                TextWrapping = TextWrapping.Wrap,
                AcceptsReturn = true,
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                IsReadOnly = false
            };
            Grid.SetRow(_txtCoversPromptPreview, 3);
            leftGrid.Children.Add(_txtCoversPromptPreview);

            leftBox.Child = leftGrid;
            Grid.SetColumn(leftBox, 0);
            split.Children.Add(leftBox);

            // Right column: Gallery of Generated 9:16 Covers
            Border rightBox = new Border
            {
                Background = BgCard,
                BorderBrush = BorderSubtle,
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(8),
                Padding = new Thickness(10)
            };
            Grid rightGrid = new Grid();
            rightGrid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            rightGrid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });

            _lblCoversSummary = new TextBlock
            {
                Text = "Selecione as imagens de referência de capa para visualizar e gerar as opções 9:16.",
                FontSize = 12,
                FontWeight = FontWeights.SemiBold,
                Foreground = TextPrimary,
                Margin = new Thickness(0, 0, 0, 6)
            };
            rightGrid.Children.Add(_lblCoversSummary);

            ScrollViewer svCovers = new ScrollViewer
            {
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                Background = BgInput,
                Padding = new Thickness(6)
            };
            _wrapGeneratedCovers = new WrapPanel();
            svCovers.Content = _wrapGeneratedCovers;
            Grid.SetRow(svCovers, 1);
            rightGrid.Children.Add(svCovers);

            rightBox.Child = rightGrid;
            Grid.SetColumn(rightBox, 1);
            split.Children.Add(rightBox);

            Grid.SetRow(split, 2);
            root.Children.Add(split);

            tab.Content = root;
            return tab;
        }

        private void LoadCoversStateForSelectedStory()
        {
            if (_selectedEpisode == null) return;
            _currentCoverConfig = CoverGenerator.LoadOrCreateStoryCoverConfig(_selectedStory, _selectedEpisode);
            RefreshCoversTabUi();
        }

        private void SaveCurrentCoverConfigFromUi()
        {
            if (_selectedEpisode == null || _currentCoverConfig == null) return;

            if (_txtCoverTitle != null && !string.IsNullOrWhiteSpace(_txtCoverTitle.Text))
            {
                _currentCoverConfig.CoverTitle = _txtCoverTitle.Text.Trim().ToUpperInvariant();
            }

            if (_cmbCoverStyle != null && _cmbCoverStyle.SelectedItem is ComboBoxItem)
            {
                ComboBoxItem styleItem = (ComboBoxItem)_cmbCoverStyle.SelectedItem;
                string styleTag = styleItem.Tag as string;
                if (!string.IsNullOrWhiteSpace(styleTag))
                    _currentCoverConfig.CoverStyle = styleTag;
            }

            if (_cmbCoverOptionsCount != null && _cmbCoverOptionsCount.SelectedItem != null)
            {
                int optCount;
                if (int.TryParse(_cmbCoverOptionsCount.SelectedItem.ToString(), out optCount) && optCount >= 1 && optCount <= 5)
                    _currentCoverConfig.OptionsPerModel = optCount;
            }

            if (_wrapCoverCharChecks != null && _wrapCoverCharChecks.Children.Count > 0)
            {
                List<string> checkedChars = new List<string>();
                foreach (object child in _wrapCoverCharChecks.Children)
                {
                    CheckBox cb = child as CheckBox;
                    if (cb != null && cb.IsChecked == true && cb.Tag is string)
                    {
                        checkedChars.Add((string)cb.Tag);
                    }
                }
                if (checkedChars.Count > 0)
                    _currentCoverConfig.SelectedCharacterFiles = checkedChars;
            }

            EpisodeWorkItem ep1 = CoverGenerator.ResolveEp1Episode(_selectedStory, _selectedEpisode);
            CoverGenerator.SaveStoryCoverConfigAndPrompts(ep1, _currentCoverConfig);
        }

        private void RefreshCoversTabUi()
        {
            if (_txtCoverTitle == null || _selectedEpisode == null) return;

            _suppressCoverUiEvents = true;
            try
            {
                EpisodeWorkItem ep1 = CoverGenerator.ResolveEp1Episode(_selectedStory, _selectedEpisode);
                if (_currentCoverConfig == null)
                    _currentCoverConfig = CoverGenerator.LoadOrCreateStoryCoverConfig(_selectedStory, _selectedEpisode);

                _txtCoverTitle.Text = _currentCoverConfig.CoverTitle ?? "";

                if (_cmbCoverStyle != null)
                {
                    GenreType storyDetectedGenre = ep1 != null ? ep1.Genre : GenreType.NovelaReflexao;
                    ComboBoxItem autoItem = _cmbCoverStyle.Items.Count > 0 ? (_cmbCoverStyle.Items[0] as ComboBoxItem) : null;
                    if (autoItem != null)
                    {
                        autoItem.Content = string.Format("Automático ({0})", CoverGenerator.GetGenreDisplayLabel(storyDetectedGenre));
                    }

                    string savedStyle = string.IsNullOrWhiteSpace(_currentCoverConfig.CoverStyle) ? "Auto" : _currentCoverConfig.CoverStyle.Trim();
                    int matchStyleIdx = 0;
                    for (int si = 0; si < _cmbCoverStyle.Items.Count; si++)
                    {
                        ComboBoxItem ci = _cmbCoverStyle.Items[si] as ComboBoxItem;
                        if (ci != null && ci.Tag is string && string.Equals((string)ci.Tag, savedStyle, StringComparison.OrdinalIgnoreCase))
                        {
                            matchStyleIdx = si;
                            break;
                        }
                    }
                    _cmbCoverStyle.SelectedIndex = matchStyleIdx;
                }

                int targetIdx = Math.Max(0, Math.Min(2, (_currentCoverConfig.OptionsPerModel <= 0 ? 3 : _currentCoverConfig.OptionsPerModel) - 1));
                _cmbCoverOptionsCount.SelectedIndex = targetIdx;

                // 1. Checkboxes de personagens de EP.1\assets
                _wrapCoverCharChecks.Children.Clear();
                List<GrokAssetSpec> allChars = CoverGenerator.DiscoverAvailableEp1Characters(ep1);
                foreach (GrokAssetSpec ch in allChars)
                {
                    bool isChecked = _currentCoverConfig.SelectedCharacterFiles != null &&
                                     _currentCoverConfig.SelectedCharacterFiles.Contains(ch.TargetFileName, StringComparer.OrdinalIgnoreCase);

                    string cleanTitle = (ch.DisplayTitle ?? ch.TargetFileName)
                        .Replace("em cima da cabeça ", "")
                        .Trim();

                    CheckBox cb = new CheckBox
                    {
                        IsChecked = isChecked,
                        Tag = ch.TargetFileName,
                        Margin = new Thickness(0, 2, 14, 2),
                        VerticalAlignment = VerticalAlignment.Center,
                        ToolTip = ch.TargetFileName,
                        Content = new TextBlock
                        {
                            Text = string.Format("{0} ({1})", cleanTitle, ch.TargetFileName),
                            Foreground = TextPrimary,
                            FontSize = 11.5
                        }
                    };
                    cb.Checked += (s, e) =>
                    {
                        if (_suppressCoverUiEvents) return;
                        SaveCurrentCoverConfigFromUi();
                        RefreshCoversPromptAndGalleryOnly(ep1);
                    };
                    cb.Unchecked += (s, e) =>
                    {
                        if (_suppressCoverUiEvents) return;
                        SaveCurrentCoverConfigFromUi();
                        RefreshCoversPromptAndGalleryOnly(ep1);
                    };
                    _wrapCoverCharChecks.Children.Add(cb);
                }

                // 2. Lista de Modelos de Referência selecionados
                _pnlCoverRefModels.Children.Clear();
                if (_currentCoverConfig.ReferenceModels == null || _currentCoverConfig.ReferenceModels.Count == 0)
                {
                    _pnlCoverRefModels.Children.Add(new TextBlock
                    {
                        Text = "Nenhum modelo selecionado ainda.\nClique em '✨ 3 Modelos do Estilo' para usar os 3 estilos prontos (Novela Mística, Novela / Reflexão ou Terror) ou em '📂 Selecionar Referências do PC...' para escolher suas próprias imagens.",
                        Foreground = TextSecondary,
                        FontSize = 11.5,
                        TextWrapping = TextWrapping.Wrap,
                        Margin = new Thickness(6)
                    });
                }
                else
                {
                    for (int i = 0; i < _currentCoverConfig.ReferenceModels.Count; i++)
                    {
                        CoverReferenceModelSpec m = _currentCoverConfig.ReferenceModels[i];
                        m.ModelIndex = i + 1;
                        _pnlCoverRefModels.Children.Add(BuildReferenceModelRowCard(ep1, m, i));
                    }
                }

                RefreshCoversPromptAndGalleryOnly(ep1);
            }
            finally
            {
                _suppressCoverUiEvents = false;
            }
        }

        private void RefreshCoversPromptAndGalleryOnly(EpisodeWorkItem ep1)
        {
            if (ep1 == null || _currentCoverConfig == null) return;

            if (_txtCoversPromptPreview != null)
            {
                _txtCoversPromptPreview.Text = CoverGenerator.BuildUnifiedCopyableCommand(ep1, _currentCoverConfig);
            }

            if (_wrapGeneratedCovers == null) return;
            _wrapGeneratedCovers.Children.Clear();

            string coversDir = CoverGenerator.GetStoryCoversDir(ep1);
            List<CoverGenerationItem> items = CoverGenerator.BuildCoverGenerationItems(ep1, _currentCoverConfig);

            int ready = 0;
            foreach (CoverGenerationItem item in items)
            {
                string fullPath = Path.Combine(coversDir, item.TargetFileName);
                bool exists = File.Exists(fullPath) && new FileInfo(fullPath).Length >= 10 * 1024;
                if (exists) ready++;
                _wrapGeneratedCovers.Children.Add(BuildGeneratedCoverCard(item, fullPath, exists));
            }

            if (_lblCoversSummary != null)
            {
                GenreType effGenre = CoverGenerator.ResolveEffectiveCoverGenre(ep1, _currentCoverConfig);
                string genreTxt = CoverGenerator.GetGenreDisplayLabel(effGenre);
                _lblCoversSummary.Text = items.Count == 0
                    ? string.Format("Estilo ativo: {0} • Pasta: '{1}' (0 modelos selecionados)", genreTxt, coversDir)
                    : string.Format("Estilo: {0} • \"{1}\": {2}/{3} prontas em '{4}'",
                        genreTxt, _currentCoverConfig.CoverTitle, ready, items.Count, coversDir);
            }
        }

        private UIElement BuildReferenceModelRowCard(EpisodeWorkItem ep1, CoverReferenceModelSpec model, int zeroBasedIdx)
        {
            Border b = new Border
            {
                Background = BgCard,
                BorderBrush = BorderSubtle,
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(6),
                Padding = new Thickness(6),
                Margin = new Thickness(2, 2, 2, 4)
            };

            Grid g = new Grid();
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(46) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            Border thumbBox = new Border
            {
                Width = 40,
                Height = 62,
                Background = BgInput,
                CornerRadius = new CornerRadius(4),
                ClipToBounds = true,
                Margin = new Thickness(0, 0, 6, 0)
            };
            if (!string.IsNullOrEmpty(model.SourceImagePath) && File.Exists(model.SourceImagePath))
            {
                try
                {
                    BitmapImage bmp = new BitmapImage();
                    using (FileStream fs = new FileStream(model.SourceImagePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                    {
                        bmp.BeginInit();
                        bmp.CacheOption = BitmapCacheOption.OnLoad;
                        bmp.DecodePixelWidth = 90;
                        bmp.StreamSource = fs;
                        bmp.EndInit();
                    }
                    bmp.Freeze();
                    thumbBox.Child = new Image { Source = bmp, Stretch = Stretch.UniformToFill };
                }
                catch { }
            }
            else
            {
                string styleIcon = string.Equals(model.StyleGenre, "Terror", StringComparison.OrdinalIgnoreCase)
                    ? "👻"
                    : (string.Equals(model.StyleGenre, "NovelaMistica", StringComparison.OrdinalIgnoreCase) ? "🔮" : "🎬");
                thumbBox.Child = new TextBlock
                {
                    Text = styleIcon,
                    FontSize = 20,
                    HorizontalAlignment = HorizontalAlignment.Center,
                    VerticalAlignment = VerticalAlignment.Center
                };
            }
            Grid.SetColumn(thumbBox, 0);
            g.Children.Add(thumbBox);

            StackPanel info = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
            info.Children.Add(new TextBlock
            {
                Text = string.Format("Modelo {0}: {1}", model.ModelIndex, model.StyleBadge),
                FontSize = 11.5,
                FontWeight = FontWeights.Bold,
                Foreground = TextPrimary,
                TextTrimming = TextTrimming.CharacterEllipsis
            });
            info.Children.Add(new TextBlock
            {
                Text = model.SourceFileName,
                FontSize = 10.5,
                Foreground = TextSecondary,
                TextTrimming = TextTrimming.CharacterEllipsis
            });
            Grid.SetColumn(info, 1);
            g.Children.Add(info);

            StackPanel actions = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };

            CoverReferenceModelSpec capturedModel = model;
            Button btnCopyOne = CreateStyledButton("📋", BgPanel, TextPrimary, new Thickness(6, 3, 6, 3));
            btnCopyOne.ToolTip = "Copiar prompt das opções apenas deste Modelo " + model.ModelIndex;
            btnCopyOne.Margin = new Thickness(4, 0, 4, 0);
            btnCopyOne.Click += (s, e) =>
            {
                List<CoverGenerationItem> all = CoverGenerator.BuildCoverGenerationItems(ep1, _currentCoverConfig);
                List<CoverGenerationItem> mine = all.Where(x => x.ModelIndex == capturedModel.ModelIndex).ToList();
                if (mine.Count > 0)
                {
                    Clipboard.SetText(mine[0].FullPrompt);
                    AppendLog(string.Format("[Capas 9:16] Prompt do Modelo {0} copiado!", capturedModel.ModelIndex));
                }
            };
            actions.Children.Add(btnCopyOne);

            int removeIdx = zeroBasedIdx;
            Button btnRem = CreateStyledButton("✕", BgPanel, AccentRed, new Thickness(6, 3, 6, 3));
            btnRem.ToolTip = "Remover esta imagem de referência";
            btnRem.Click += (s, e) =>
            {
                if (_currentCoverConfig != null && removeIdx >= 0 && removeIdx < _currentCoverConfig.ReferenceModels.Count)
                {
                    _currentCoverConfig.ReferenceModels.RemoveAt(removeIdx);
                    SaveCurrentCoverConfigFromUi();
                    RefreshCoversTabUi();
                }
            };
            actions.Children.Add(btnRem);

            Grid.SetColumn(actions, 2);
            g.Children.Add(actions);

            b.Child = g;
            return b;
        }

        private UIElement BuildGeneratedCoverCard(CoverGenerationItem item, string fullPath, bool exists)
        {
            Border card = new Border
            {
                Width = 178,
                Background = BgCard,
                BorderBrush = exists ? BrushFromHex("#065F46") : BorderSubtle,
                BorderThickness = new Thickness(1.5),
                CornerRadius = new CornerRadius(8),
                Padding = new Thickness(7),
                Margin = new Thickness(5)
            };

            StackPanel sp = new StackPanel();

            Border imgBox = new Border
            {
                Height = 245,
                Background = BgInput,
                CornerRadius = new CornerRadius(5),
                ClipToBounds = true
            };

            if (exists)
            {
                try
                {
                    BitmapImage bmp = new BitmapImage();
                    using (FileStream fs = new FileStream(fullPath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                    {
                        bmp.BeginInit();
                        bmp.CacheOption = BitmapCacheOption.OnLoad;
                        bmp.DecodePixelWidth = 260;
                        bmp.StreamSource = fs;
                        bmp.EndInit();
                    }
                    bmp.Freeze();

                    Image img = new Image { Source = bmp, Stretch = Stretch.Uniform };
                    img.Cursor = Cursors.Hand;
                    img.ToolTip = "Clique para abrir a capa em tamanho real";
                    string openPath = fullPath;
                    img.MouseLeftButtonUp += (s, e) =>
                    {
                        try { Process.Start(new ProcessStartInfo(openPath) { UseShellExecute = true }); } catch { }
                    };
                    imgBox.Child = img;
                }
                catch
                {
                    imgBox.Child = new TextBlock
                    {
                        Text = "Erro ao abrir",
                        Foreground = AccentRed,
                        HorizontalAlignment = HorizontalAlignment.Center,
                        VerticalAlignment = VerticalAlignment.Center
                    };
                }
            }
            else
            {
                imgBox.Child = new TextBlock
                {
                    Text = "PENDENTE\n(9:16)",
                    Foreground = TextSecondary,
                    FontSize = 11.5,
                    TextAlignment = TextAlignment.Center,
                    HorizontalAlignment = HorizontalAlignment.Center,
                    VerticalAlignment = VerticalAlignment.Center
                };
            }

            sp.Children.Add(imgBox);

            sp.Children.Add(new TextBlock
            {
                Text = item.DisplayLabel,
                FontWeight = FontWeights.Bold,
                FontSize = 11.5,
                Foreground = TextPrimary,
                Margin = new Thickness(0, 6, 0, 1)
            });

            long kb = exists ? Math.Max(1, new FileInfo(fullPath).Length / 1024) : 0;
            sp.Children.Add(new TextBlock
            {
                Text = exists ? string.Format("OK ({0} KB) • {1}", kb, item.TargetFileName) : item.TargetFileName,
                FontSize = 10.5,
                Foreground = exists ? AccentGreen : TextSecondary,
                TextTrimming = TextTrimming.CharacterEllipsis,
                Margin = new Thickness(0, 0, 0, 5)
            });

            Grid btnRow = new Grid();
            btnRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            btnRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

            CoverGenerationItem capturedItem = item;
            Button btnCopy = CreateStyledButton("📋 Prompt", BgPanel, TextPrimary, new Thickness(4, 4, 4, 4));
            btnCopy.FontSize = 10.5;
            btnCopy.Margin = new Thickness(0, 0, 3, 0);
            btnCopy.Click += (s, e) =>
            {
                Clipboard.SetText(capturedItem.FullPrompt ?? "");
                AppendLog(string.Format("[Capas 9:16] Prompt de '{0}' copiado!", capturedItem.TargetFileName));
            };
            Grid.SetColumn(btnCopy, 0);
            btnRow.Children.Add(btnCopy);

            Button btnRegen = CreateStyledButton("🔄 Gerar", BgPanel, AccentAmber, new Thickness(4, 4, 4, 4));
            btnRegen.FontSize = 10.5;
            btnRegen.Margin = new Thickness(3, 0, 0, 0);
            btnRegen.Click += async (s, e) => await ExecuteStandaloneCoversActionAsync(true, capturedItem);
            Grid.SetColumn(btnRegen, 1);
            btnRow.Children.Add(btnRegen);

            sp.Children.Add(btnRow);
            card.Child = sp;
            return card;
        }

        private bool PromptSelectCoverReferenceImagesForStory(EpisodeWorkItem ep, bool appendMode, bool invokedFromPipelineStart)
        {
            if (ep == null) return false;

            EpisodeWorkItem ep1 = CoverGenerator.ResolveEp1Episode(_selectedStory, ep);
            StoryCoverConfig cfg = (_selectedEpisode == ep && _currentCoverConfig != null)
                ? _currentCoverConfig
                : CoverGenerator.LoadOrCreateStoryCoverConfig(_selectedStory, ep);

            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Title = invokedFromPipelineStart
                ? string.Format("🎨 Selecione as Imagens de Referência de Capa para '{0}' ({1} opções de cada) — ou Cancele p/ pular Capas", ep.StoryName, cfg.OptionsPerModel)
                : string.Format("🎨 Selecionar Imagens de Referência de Capa para '{0}'", ep.StoryName);
            dlg.Filter = "Imagens (*.jpg;*.jpeg;*.png;*.webp;*.bmp)|*.jpg;*.jpeg;*.png;*.webp;*.bmp|Todos os arquivos (*.*)|*.*";
            dlg.Multiselect = true;

            if (!string.IsNullOrWhiteSpace(_config.LastCoverReferencesDir) && Directory.Exists(_config.LastCoverReferencesDir))
            {
                dlg.InitialDirectory = _config.LastCoverReferencesDir;
            }
            else
            {
                string dl = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads");
                if (Directory.Exists(dl)) dlg.InitialDirectory = dl;
            }

            bool? res = dlg.ShowDialog(this);
            if (res != true || dlg.FileNames == null || dlg.FileNames.Length == 0)
                return false;

            string chosenDir = Path.GetDirectoryName(dlg.FileNames[0]);
            if (!string.IsNullOrEmpty(chosenDir) && Directory.Exists(chosenDir))
            {
                _config.LastCoverReferencesDir = chosenDir;
                _config.SaveUserSettings();
            }

            if (!appendMode)
            {
                cfg.ReferenceModels.Clear();
            }

            GenreType effectiveGenre = CoverGenerator.ResolveEffectiveCoverGenre(ep1, cfg);
            foreach (string f in dlg.FileNames)
            {
                if (string.IsNullOrEmpty(f) || !File.Exists(f)) continue;
                int nextIdx = cfg.ReferenceModels.Count + 1;
                CoverReferenceModelSpec analyzed = CoverGenerator.AnalyzeReferenceCoverImage(f, nextIdx, effectiveGenre);
                cfg.ReferenceModels.Add(analyzed);
            }

            if (cfg.SelectedCharacterFiles == null || cfg.SelectedCharacterFiles.Count == 0)
            {
                cfg.SelectedCharacterFiles = CoverGenerator.AutoSelectFocalCharacterFileNames(ep1);
            }

            CoverGenerator.SaveStoryCoverConfigAndPrompts(ep1, cfg);
            _currentCoverConfig = cfg;
            RefreshCoversTabUi();

            AppendLog(string.Format(
                "[Capas 9:16] {0} imagem(ns) de referência selecionada(s) para '{1}' -> {2} opções de capa preparadas em 'prompts_capas.txt'!",
                cfg.ReferenceModels.Count,
                ep.StoryName,
                cfg.ReferenceModels.Count * cfg.OptionsPerModel));

            return cfg.ReferenceModels.Count > 0;
        }

        private bool PrepareStoryCoversBeforePipelineOnUiThread(EpisodeWorkItem ep, bool forcePromptIfEmpty)
        {
            if (ep == null) return false;
            SaveCurrentCoverConfigFromUi();

            EpisodeWorkItem ep1 = CoverGenerator.ResolveEp1Episode(_selectedStory, ep);
            StoryCoverConfig cfg = CoverGenerator.LoadOrCreateStoryCoverConfig(_selectedStory, ep);
            _currentCoverConfig = cfg;

            if (cfg.ReferenceModels != null && cfg.ReferenceModels.Count > 0)
            {
                RefreshCoversTabUi();
                return true;
            }

            if (!forcePromptIfEmpty)
                return false;

            return PromptSelectCoverReferenceImagesForStory(ep, false, true);
        }

        private async Task ExecuteStandaloneCoversActionAsync(bool remakeAll, CoverGenerationItem singleItemOnly)
        {
            if (_isRunning) return;
            if (_selectedEpisode == null)
            {
                MessageBox.Show("Selecione primeiro uma história e episódio na coluna esquerda.", "Capas 9:16", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            SyncSettingsFromUi();
            SaveCurrentCoverConfigFromUi();

            if (_currentCoverConfig == null || _currentCoverConfig.ReferenceModels == null || _currentCoverConfig.ReferenceModels.Count == 0)
            {
                bool picked = PromptSelectCoverReferenceImagesForStory(_selectedEpisode, false, false);
                if (!picked) return;
            }

            EpisodeWorkItem ep = _selectedEpisode;
            StoryProject story = _selectedStory;
            StoryCoverConfig cfgSnapshot = _currentCoverConfig;

            SetRunningUiState(true);
            _runCts = new CancellationTokenSource();
            CancellationToken token = _runCts.Token;

            try
            {
                SetStageBadge(_badgeCovers, StageState.Running, "GERANDO...");
                UpdateProgress(20, "Conectando ao Chrome CDP e gerando Capas 9:16 da história...");

                await Task.Run(async () =>
                {
                    await _cdp.EnsureConnectedAsync(token);

                    EpisodeWorkItem ep1 = CoverGenerator.ResolveEp1Episode(story, ep);
                    List<string> charPaths = CoverGenerator.ResolveSelectedCharacterPathsOnDisk(ep1, ep, cfgSnapshot.SelectedCharacterFiles);
                    if (charPaths.Count == 0 && ep1 != null && ep1.GrokSpecs != null && ep1.GrokSpecs.Count > 0)
                    {
                        AppendLog("[Capas 9:16] Personagens de EP.1\\assets ainda não existem em disco -> gerando assets base primeiro no Grok...");
                        await _grok.RunAsync(ep1, token);
                    }

                    await _grok.GenerateStoryCoversAsync(
                        story,
                        ep,
                        cfgSnapshot,
                        remakeAll,
                        singleItemOnly,
                        () => Dispatcher.BeginInvoke(new Action(() => RefreshCoversTabUi())),
                        token);
                });

                RefreshCoversTabUi();
                int totalExp;
                EpisodeWorkItem ep1Done = CoverGenerator.ResolveEp1Episode(story, ep);
                int doneCount = CoverGenerator.CountExistingGeneratedCovers(ep1Done, cfgSnapshot, out totalExp);
                SetStageBadge(_badgeCovers, StageState.Success, string.Format("PRONTAS ({0}/{1})", doneCount, totalExp));
                UpdateProgress(100, string.Format("Capas 9:16 concluídas ({0}/{1} salvas na pasta capas\\)!", doneCount, totalExp));
            }
            catch (OperationCanceledException)
            {
                SetStageBadge(_badgeCovers, StageState.Idle, "CANCELADO");
                UpdateProgress(0, "Geração de capas interrompida pelo usuário.");
                AppendLog("[Capas 9:16] Geração interrompida pelo usuário.");
            }
            catch (Exception ex)
            {
                SetStageBadge(_badgeCovers, StageState.Failed, "ERRO");
                UpdateProgress(0, "Erro ao gerar capas: " + ex.Message);
                AppendLog("[Capas 9:16 | ERRO] " + ex.ToString());
                MessageBox.Show(ex.Message, "Erro ao Gerar Capas", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                RefreshCoversTabUi();
                SetRunningUiState(false);
            }
        }

        private async Task ExecuteSalvageFlowCoversClickAsync()
        {
            if (_isRunning || _selectedEpisode == null) return;
            SyncSettingsFromUi();
            SaveCurrentCoverConfigFromUi();

            EpisodeWorkItem ep = _selectedEpisode;
            StoryProject story = _selectedStory;
            StoryCoverConfig cfgSnapshot = _currentCoverConfig;

            SetRunningUiState(true);
            _runCts = new CancellationTokenSource();
            CancellationToken token = _runCts.Token;

            try
            {
                SetStageBadge(_badgeCovers, StageState.Running, "BAIXANDO...");
                UpdateProgress(35, "Resgatando e baixando as capas já geradas na grade do Google Flow...");
                int count = 0;

                await Task.Run(async () =>
                {
                    await _cdp.EnsureConnectedAsync(token);
                    EpisodeWorkItem ep1 = CoverGenerator.ResolveEp1Episode(story, ep);
                    count = await _flow.SalvageLatestCoversFromFlowGridAsync(
                        ep1,
                        cfgSnapshot,
                        () => Dispatcher.BeginInvoke(new Action(() => RefreshCoversTabUi())),
                        token);
                });

                RefreshCoversTabUi();
                SetStageBadge(_badgeCovers, count > 0 ? StageState.Success : StageState.Idle,
                    count > 0 ? string.Format("BAIXADAS ({0})", count) : "0 NOVAS");
                UpdateProgress(100, string.Format("{0} capa(s) resgatada(s) da tela do Google Flow!", count));
            }
            catch (OperationCanceledException)
            {
                UpdateProgress(0, "Resgate cancelado.");
            }
            catch (Exception ex)
            {
                SetStageBadge(_badgeCovers, StageState.Failed, "ERRO");
                AppendLog("[Capas 9:16 | Resgatar Erro] " + ex.Message);
            }
            finally
            {
                RefreshCoversTabUi();
                SetRunningUiState(false);
            }
        }
    }
}
