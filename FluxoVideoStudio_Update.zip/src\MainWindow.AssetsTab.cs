using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Microsoft.Win32;

namespace FluxoVideoStudio
{
    public partial class MainWindow : Window
    {
        private void RefreshAssetsGallery(Dictionary<string, string> ocrLookup)
        {
            _wrapAssets.Children.Clear();
            if (_selectedEpisode == null) return;

            List<string> expectedNames = _selectedEpisode.AllRequiredFlowIngredients.Count > 0
                ? new List<string>(_selectedEpisode.AllRequiredFlowIngredients)
                : _selectedEpisode.GrokSpecs.Select(s => s.TargetFileName).ToList();

            if (Directory.Exists(_selectedEpisode.AssetsDir))
            {
                foreach (string f in Directory.GetFiles(_selectedEpisode.AssetsDir))
                {
                    if (! f.EndsWith(".jpg", StringComparison.OrdinalIgnoreCase) &&
                        ! f.EndsWith(".jpeg", StringComparison.OrdinalIgnoreCase) &&
                        ! f.EndsWith(".png", StringComparison.OrdinalIgnoreCase))
                        continue;

                    string fn = Path.GetFileName(f);
                    if (!expectedNames.Contains(fn, StringComparer.OrdinalIgnoreCase))
                        expectedNames.Add(fn);
                }
            }

            int readyCount = 0;
            foreach (string fileName in expectedNames)
            {
                string fullPath = Path.Combine(_selectedEpisode.AssetsDir, fileName);
                bool exists = File.Exists(fullPath) && new FileInfo(fullPath).Length > 1024;
                if (exists) readyCount++;

                GrokAssetSpec spec = _selectedEpisode.GrokSpecs.FirstOrDefault(s =>
                    string.Equals(s.TargetFileName, fileName, StringComparison.OrdinalIgnoreCase));

                string ocrText = (ocrLookup != null && ocrLookup.ContainsKey(fullPath)) ? ocrLookup[fullPath] : "";
                _wrapAssets.Children.Add(BuildAssetThumbnailCard(fileName, fullPath, exists, spec != null ? spec.DisplayTitle : "", ocrText, expectedNames));
            }

            _lblAssetsSummary.Text = string.Format("Assets do episódio {0}: {1}/{2} arquivos prontos em '{3}'",
                _selectedEpisode.EpisodeName, readyCount, expectedNames.Count, _selectedEpisode.AssetsDir);
        }

        private UIElement BuildAssetThumbnailCard(
            string fileName,
            string fullPath,
            bool exists,
            string expectedTitle,
            string ocrText,
            List<string> allNames)
        {
            Border card = new Border
            {
                Width = 205,
                Background = BgCard,
                BorderBrush = exists ? BrushFromHex("#065F46") : BorderSubtle,
                BorderThickness = new Thickness(1.5),
                CornerRadius = new CornerRadius(8),
                Padding = new Thickness(8),
                Margin = new Thickness(5)
            };

            StackPanel sp = new StackPanel();

            Border imgBox = new Border
            {
                Height = 250,
                Background = BgInput,
                CornerRadius = new CornerRadius(5),
                ClipToBounds = true
            };

            if (exists)
            {
                try
                {
                    BitmapImage bmp = new BitmapImage();
                    using (FileStream fs = new FileStream(fullPath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                    {
                        bmp.BeginInit();
                        bmp.CacheOption = BitmapCacheOption.OnLoad;
                        bmp.DecodePixelWidth = 260;
                        bmp.StreamSource = fs;
                        bmp.EndInit();
                    }
                    bmp.Freeze();

                    Image img = new Image { Source = bmp, Stretch = Stretch.Uniform };
                    img.Cursor = Cursors.Hand;
                    img.ToolTip = "Clique para abrir a imagem em tamanho real";
                    img.MouseLeftButtonUp += (s, e) =>
                    {
                        try { Process.Start(new ProcessStartInfo(fullPath) { UseShellExecute = true }); } catch { }
                    };
                    imgBox.Child = img;
                }
                catch
                {
                    imgBox.Child = new TextBlock { Text = "Erro ao ler imagem", Foreground = AccentRed, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
                }
            }
            else
            {
                imgBox.Child = new TextBlock
                {
                    Text = "⏳ PENDENTE\n(Grok Imagine)",
                    Foreground = TextSecondary,
                    TextAlignment = TextAlignment.Center,
                    HorizontalAlignment = HorizontalAlignment.Center,
                    VerticalAlignment = VerticalAlignment.Center
                };
            }
            sp.Children.Add(imgBox);

            sp.Children.Add(new TextBlock
            {
                Text = fileName,
                FontSize = 11.5,
                FontWeight = FontWeights.Bold,
                Foreground = TextPrimary,
                TextWrapping = TextWrapping.Wrap,
                Margin = new Thickness(0, 6, 0, 2)
            });

            if (!string.IsNullOrEmpty(expectedTitle))
            {
                sp.Children.Add(new TextBlock
                {
                    Text = "Esperado: " + expectedTitle,
                    FontSize = 10.5,
                    Foreground = TextSecondary,
                    TextTrimming = TextTrimming.CharacterEllipsis
                });
            }

            if (!string.IsNullOrEmpty(ocrText))
            {
                sp.Children.Add(new TextBlock
                {
                    Text = "OCR Topo: \"" + ocrText + "\"",
                    FontSize = 10.5,
                    FontWeight = FontWeights.SemiBold,
                    Foreground = AccentGreen,
                    TextWrapping = TextWrapping.Wrap
                });
            }

            if (exists && allNames.Count > 1)
            {
                ComboBox cmbSwap = new ComboBox { FontSize = 10.5, Margin = new Thickness(0, 5, 0, 0) };
                cmbSwap.Items.Add("⇄ Trocar nome com...");
                foreach (string other in allNames)
                {
                    if (!string.Equals(other, fileName, StringComparison.OrdinalIgnoreCase))
                        cmbSwap.Items.Add(other);
                }
                cmbSwap.SelectedIndex = 0;
                cmbSwap.SelectionChanged += (s, e) =>
                {
                    if (cmbSwap.SelectedIndex <= 0) return;
                    string targetOther = Convert.ToString(cmbSwap.SelectedItem);
                    SwapTwoAssetFiles(fullPath, Path.Combine(_selectedEpisode.AssetsDir, targetOther));
                };
                sp.Children.Add(cmbSwap);
            }

            StackPanel actionRow = new StackPanel { Orientation = Orientation.Vertical, Margin = new Thickness(0, 6, 0, 0) };
            Button btnRegenAsset = CreateStyledButton("🔄 Regerar só este Asset", BgPanel, TextPrimary, new Thickness(6, 4, 6, 4));
            btnRegenAsset.FontSize = 10.5;
            btnRegenAsset.Click += (s, e) => ShowRegenerateSingleAssetDialog(fileName);
            actionRow.Children.Add(btnRegenAsset);

            sp.Children.Add(actionRow);

            card.Child = sp;
            return card;
        }

        private void SwapTwoAssetFiles(string pathA, string pathB)
        {
            try
            {
                if (!File.Exists(pathA)) return;
                if (File.Exists(pathB))
                {
                    string tmp = pathA + ".swap_tmp";
                    File.Move(pathA, tmp);
                    File.Move(pathB, pathA);
                    File.Move(tmp, pathB);
                    AppendLog(string.Format("[Assets] Nomes trocados com sucesso: '{0}' <-> '{1}'",
                        Path.GetFileName(pathA), Path.GetFileName(pathB)));
                }
                else
                {
                    File.Move(pathA, pathB);
                    AppendLog(string.Format("[Assets] Arquivo renomeado: '{0}' -> '{1}'",
                        Path.GetFileName(pathA), Path.GetFileName(pathB)));
                }
                _grok.MirrorAssetsToTempFlow(_selectedEpisode.AssetsDir);
                EpisodeParser.RefreshDiskCounters(_selectedEpisode);
                RefreshAssetsGallery(null);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao trocar nomes: " + ex.Message, "Assets", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private async Task InspectCurrentAssetsWithOcrAsync()
        {
            if (_selectedEpisode == null || !Directory.Exists(_selectedEpisode.AssetsDir)) return;
            AppendLog("[OCR] Lendo títulos no topo dos arquivos .jpg em assets via Windows OCR (pt-BR)...");
            string dir = _selectedEpisode.AssetsDir;
            Dictionary<string, string> res = await Task.Run(() => _grok.RunWindowsOcrOnFolder(dir));
            AppendLog(string.Format("[OCR] Leitura concluída para {0} imagens.", res.Count));
            RefreshAssetsGallery(res);
        }


        // =================================================================================================
        // SUGESTÃO A: REGERAR 1 ÚNICO PERSONAGEM OU CENÁRIO (.JPG) NA ABA DE ASSETS
        // =================================================================================================

        private void ShowRegenerateSingleAssetDialog(string fileName)
        {
            if (_selectedEpisode == null || string.IsNullOrEmpty(fileName)) return;

            GrokAssetSpec spec = _selectedEpisode.GrokSpecs.FirstOrDefault(s =>
                string.Equals(s.TargetFileName, fileName, StringComparison.OrdinalIgnoreCase));

            string initialPrompt = spec != null && !string.IsNullOrWhiteSpace(spec.RawPromptLine)
                ? spec.RawPromptLine
                : string.Format("- {0}: Animação 3D estilizada semi-realista (CGI), proporções 9:16 verticais, corpo inteiro sobre fundo branco neutro puro (#FFFFFF), escrito \"{0}\" no topo.",
                    EpisodeParser.CleanAssetStem(fileName));

            Window dlg = new Window
            {
                Title = "🔄 Regerar Asset Individual no Grok Imagine — " + fileName,
                Width = 640,
                Height = 340,
                WindowStartupLocation = WindowStartupLocation.CenterOwner,
                Owner = this,
                Background = BgPanel,
                Foreground = TextPrimary,
                ResizeMode = ResizeMode.NoResize
            };

            StackPanel sp = new StackPanel { Margin = new Thickness(18) };
            sp.Children.Add(new TextBlock
            {
                Text = "Arquivo alvo: " + fileName,
                FontWeight = FontWeights.Bold,
                FontSize = 13,
                Foreground = TextPrimary,
                Margin = new Thickness(0, 0, 0, 6)
            });
            sp.Children.Add(new TextBlock
            {
                Text = "Você pode ajustar a descrição abaixo antes de enviar para o Grok Imagine (somente esta imagem será regerada):",
                FontSize = 11.5,
                Foreground = TextSecondary,
                Margin = new Thickness(0, 0, 0, 8)
            });

            TextBox txtPrompt = new TextBox
            {
                Text = initialPrompt,
                Background = BgInput,
                Foreground = TextPrimary,
                BorderBrush = BorderSubtle,
                BorderThickness = new Thickness(1),
                FontFamily = new FontFamily("Consolas"),
                FontSize = 11.5,
                TextWrapping = TextWrapping.Wrap,
                AcceptsReturn = true,
                Height = 140,
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                Padding = new Thickness(8),
                Margin = new Thickness(0, 0, 0, 14)
            };
            sp.Children.Add(txtPrompt);

            StackPanel btns = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };
            Button btnCancel = CreateStyledButton("Cancelar", BgCard, TextPrimary, new Thickness(14, 7, 14, 7));
            btnCancel.Margin = new Thickness(0, 0, 10, 0);
            btnCancel.Click += (s, e) => dlg.DialogResult = false;
            btns.Children.Add(btnCancel);

            Button btnConfirm = CreateStyledButton("🚀 Regerar Somente Este Asset no Grok", AccentPrimary, Brushes.White, new Thickness(14, 7, 14, 7));
            btnConfirm.FontWeight = FontWeights.Bold;
            btnConfirm.Click += (s, e) => dlg.DialogResult = true;
            btns.Children.Add(btnConfirm);

            sp.Children.Add(btns);
            dlg.Content = sp;

            if (dlg.ShowDialog() == true)
            {
                string customLine = (txtPrompt.Text ?? "").Trim();
                var _ = RunSingleAssetRegenerationFromUiAsync(fileName, customLine);
            }
        }

        private async Task RunSingleAssetRegenerationFromUiAsync(string fileName, string customPromptLine)
        {
            if (_isRunning || _selectedEpisode == null) return;
            SyncSettingsFromUi();
            SetRunningUiState(true);
            _runCts = new CancellationTokenSource();

            EpisodeWorkItem ep = _selectedEpisode;
            CancellationToken token = _runCts.Token;

            try
            {
                SetStageBadge(_badgeGrok, StageState.Running, "REGERANDO 1...");
                UpdateProgress(25, "Regerando asset individual no Grok Imagine: " + fileName);
                await Task.Run(async () =>
                {
                    await _grok.RegenerateSingleAssetAsync(ep, fileName, customPromptLine, token);
                });
                SetStageBadge(_badgeGrok, StageState.Success, "CONCLUÍDO");
                UpdateProgress(100, "Asset regerado com sucesso: " + fileName);
            }
            catch (OperationCanceledException)
            {
                UpdateProgress(0, "Regeração de asset cancelada pelo usuário.");
                AppendLog("[Sistema] Regeração de asset cancelada.");
            }
            catch (Exception ex)
            {
                SetStageBadge(_badgeGrok, StageState.Failed, "ERRO");
                AppendLog("[Erro Asset Individual] " + ex.Message);
                MessageBox.Show(ex.Message, "Erro ao Regerar Asset", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                if (_selectedStory != null) RebuildEpisodeButtons(_selectedStory);
                RefreshAssetsGallery(null);
                RefreshTakesManagerList();
                SetRunningUiState(false);
            }
        }

    }
}
