---
name: "gem 3D Pixar/Disney"
description: >-
  Gera localmente (sem precisar abrir o Gemini no navegador) os prompts completos no estilo Animação 3D Pixar/Disney Cartoon Vibrante (zero fotorrealismo, caricaturas 3D estilizadas com olhos grandes expressivos, cores saturadas e iluminação de alto contraste laranja-dourado quente vs. azul-elétrico):
  (1) PASSO 1: Pré-definição de Personagens (corpo inteiro, nome em cima da cabeça, fundo branco neutro puro, silhueta cartoon 3D exagerada do arquétipo em 9:16);
  (2) PASSO 2: Pré-definição de Cenários (ambiente 3D cartoon vazio, cores vivas e saturadas, contraste quente dourado vs. azul noturno/tempestade em 9:16);
  (3) PASSO 3: Roteiro Decupado em Takes cronológicos (9:16), aplicando a Fórmula Obrigatória de 1 Frase por Personagem com Posição Espacial Exata + Quem Fala por Último com "e fala", Regra do Narrador (100% sem fala) e Suavização Anti-Bloqueio.
---

# Skill: gem 3D Pixar/Disney (Decupagem Local em Estilo Animação 3D Pixar/Disney Cartoon)

Use esta skill sempre que o usuário pedir para gerar os prompts de **Personagens (`PASSO 1`)**, **Cenários (`PASSO 2`)** e **Takes de Vídeo (`PASSO 3`)** no estilo **Animação 3D Pixar/Disney Cartoon** (como validado na história *Carona na Serra*), sem precisar abrir o navegador!

---

## 🎨 1. Estética Visual Inegociável (`3D Pixar/Disney Cartoon` — Zero Fotorrealismo)

> **[!IMPORTANT] PROIBIDO USAR TERMOS QUE GEREM HUMANOS REALISTAS**:
> - **NUNCA** use termos como *"semi-realista"*, *"proporções corporais realistas"* ou *"anatomia realista"*, pois eles fazem o Grok Imagine e o Google Flow gerarem pessoas quase reais.
> - Use **SEMPRE** a assinatura estética abaixo em todos os prompts:
>   - **Tag de Estilo Obrigatória**: `Animação 3D Pixar/Disney Cartoon vibrante (3D Pixar cartoon animation style, caricatura 3D cartoon estilizada de altíssima qualidade, olhos grandes 3D arredondados e super expressivos, cores vibrantes e saturadas, iluminação de ALTO CONTRASTE com luzes quentes laranja-douradas intensas contra sombras/chuva azul-escura e raios elétricos, pele macia com subsurface scattering, zero fotorrealismo)`

### Paleta de Cores e Iluminação (Alto Contraste Pixar/Disney):
- **Luzes Internas / Focos Principais**: Brilho super quente, **laranja-fogo, âmbar e dourado intenso** (abajures, luminárias pendentes, faróis de carros, lampiões, luz de janelas refletindo no piso).
- **Ambiente Externo / Sombras / Clima**: Azul-escuro profundo, chuva com gotas grandes brilhantes e **raios azuis-elétricos** cortando o fundo, criando contraste dramático entre o quente alaranjado e o frio azulado.
- **Roupas e Objetos**: Cores vivas, puras e altamente saturadas que destacam imediatamente cada personagem no vídeo (ex.: camiseta amarela viva, vestido florido colorido, camisa xadrez vermelha vibrante, toalha de mesa xadrez vermelha e branca).

### Design de Personagens (Silhuetas Cartoon 3D Exageradas por Arquétipo):
Cada personagem deve ter uma **silhueta 3D cartoon inconfundível e exagerada**:
- **Jovem / Protagonista**: Olhos grandes 3D arredondados e super expressivos (cor de mel, verdes ou azuis), sardas nas bochechas coradas, sobrancelhas arqueadas expressivas, cabelos volumosos esculpidos em cachos ou mechas vibrantes, roupas modernas contrastantes.
- **Mãe / Senhora Bondosa**: Baixinha, bem gordinha e rechonchuda, rosto super redondo com bochechas grandes e rosadas, olhos grandes meigos, sorriso maternal ingênuo, cabelo curto volumoso esculpido, vestido florido colorido com avental.
- **Antagonista / Figura Misteriosa ou Sinistra**: Caricatura 3D cartoon exagerada — postura bem corcunda, nariz grande pontudo e adunco, queixo largo proeminente, olhos grandes esbugalhados super expressivos, sorriso largo de orelha a orelha, braços compridos com dedos longos.
- **Policial / Xerife / Autoridade**: Proporção cartoon 3D hiper-musculosa (tronco largo com peitoral gigante e bíceps enormes, queixo quadrado largo, bigode/barba esculpidos) ou investigador alto, magro e anguloso de sobretudo.

---

## 📐 2. Fórmula Obrigatória do `PASSO 3` (Posição Espacial + Frases Independentes + Lip-Sync)

Para garantir que o **Google Flow** nunca troque os personagens de lugar (ex.: colocar o passageiro no volante ou o carona no banco errado) e nunca mova a boca do personagem errado, siga **100% esta estrutura em todos os Takes**:

1. **PROIBIDO Sujeito Composto na Mesma Frase**:
   - **NUNCA** escreva *"Personagem A, Personagem B e Personagem C estão no Cenário X"*. Juntar vários personagens na mesma frase confunde o modelo de vídeo.
2. **Uma Frase Curta e Independente por Personagem + Posição Espacial Exata**:
   - Cada personagem presente no Take deve ter **sua própria frase separada**, iniciando ou indicando claramente sua **posição espacial exata** (ex.: *"No banco dianteiro do motorista à esquerda..."*, *"No banco do passageiro à direita..."*, *"Sentado no banco de trás do carro ao centro..."*, *"Ao fundo à direita..."*, *"Em primeiro plano à esquerda..."*, *"Sentada na cadeira à direita da mesa..."*).
3. **Ordem Estrita para Travar o Lip-Sync (Quem Não Fala Primeiro -> Quem Fala por Último com `"e fala"`)**:
   - **Primeira(s) frase(s)**: Descreva primeiro o cenário (`[Arquivo_Cenario.jpg]`) e a posição + ação silenciosa do(s) personagem(ns) que **NÃO fala(m)** naquele Take.
   - **Última frase (colada em `IMEDIATAMENTE o áudio entra:`)**: Posicione **SEMPRE por último** a frase do **personagem que fala no Take**, descrevendo sua posição exata, sua reação visual e terminando obrigatoriamente com **`"e fala..."`** imediatamente antes de `IMEDIATAMENTE o áudio entra: "[Fala]"`.
4. **Reforço Obrigatório em `[Câmera e Detalhes]`**:
   - Repita a posição de quem está em segundo plano/apoio e especifique a palavra **`"falando"`** no personagem que tem a fala do Take:
     - Exemplo: `Câmera: Plano médio mostrando [Personagem A] em [posição], enquanto enquadra em primeiro plano [Personagem B] falando em [posição]. Lip-sync preciso. Foley: [Sons ambientes].`

---

## 🛡️ 3. Regras de Áudio, Narrador, Figurinos e Suavização Anti-Bloqueio

1. **Regra do Narrador (`100% Sem Fala` / `SEM DIALOGO`)**:
   - **NUNCA** crie personagem para `"O Narrador"` no `PASSO 1`.
   - Quando o roteiro tiver fala do Narrador, marque o Take como `100% Sem Fala`, remova qualquer texto falado e descreva apenas a ação visual silenciosa dos personagens físicos (`em total silêncio e de boca fechada`), terminando com `SEM DIALOGO`.
2. **Proibição de Música**:
   - Apenas som ambiente rústico/Foley e vozes dos personagens em tela (sem música de fundo).
3. **Numeração Contínua de `.jpg` e Múltiplos Figurinos (`PASSO 1` e `PASSO 3`)**:
   - Numere todos os arquivos `.jpg` sequencialmente com 2 dígitos (`01_Personagem_1_...jpg`, `05_Cenario_A_...jpg`, continuando a numeração nos inéditos de `EP.2` e `EP.3`).
   - Se um personagem trocar de roupa na história, crie um asset `.jpg` separado no `PASSO 1` mantendo 100% o mesmo rosto/corpo cartoon 3D e mudando apenas a roupa.
4. **Suavização Preventiva Anti-Bloqueio para o Google Flow**:
   - Em cenas tensas (ex.: personagem preso num porão ou encurralado), **NUNCA** descreva cordas amarradas nos pulsos, agressão física ou choro de súplica extrema, e prefixe os personagens como **`"a mulher adulta cartoon 3D"`** e **`"o homem adulto cartoon 3D"`** para evitar falso-positivo nos filtros do gerador de vídeo.

---

## 📋 4. Estrutura Obrigatória de Saída e Gabarito Validado

Gere sempre os prompts em **Português Brasileiro (PT-BR)** seguindo exatamente o modelo validado abaixo:

```text
Faça cada imagem isolada e em 9:16, nome em cima da cabeça:

📦 PASSO 1: PRÉ-DEFINIÇÃO DE PERSONAGENS (ASSETS BASE)

- Personagem 1: em cima da cabeça [Nome do Arquétipo] ([01_Personagem_1_Nome_Do_Arquetipo.jpg]) - Uma imagem de corpo inteiro em estilo Animação 3D Pixar/Disney Cartoon vibrante (3D Pixar cartoon animation style, caricatura 3D cartoon estilizada de altíssima qualidade, cores vibrantes e saturadas, iluminação dramática de alto contraste com luz de contorno quente dourada e alaranjada intensa, pele macia com subsurface scattering, olhos grandes 3D arredondados e super expressivos, zero fotorrealismo) de [se adulto: homem adulto / mulher adulta com traços faciais e corporais maduros bem definidos, sem rosto ou aparência de criança; se criança: proporções infantis reais de sua faixa etária; descrição física caricata 3D do arquétipo, rosto, olhos grandes expressivos, cabelo esculpido e roupas de cores vibrantes]. Escrito "[Nome do Arquétipo]" em cima da cabeça. FUNDO BRANCO NEUTRO PURO, proporção 9:16.

🏠 PASSO 2: PRÉ-DEFINIÇÃO DE CENÁRIOS (ASSETS DE AMBIENTE)

- Cenário A: [Nome do Cenário] ([05_Cenario_A_Nome_Do_Cenario.jpg]) - Ambiente 3D VAZIO (sem pessoas) em estilo Animação 3D Pixar/Disney Cartoon vibrante (3D Pixar cartoon animation style, cores ricas e saturadas, zero fotorrealismo), visão grande angular em 9:16 de [descrição detalhada do ambiente estilizado]. Iluminação cinematográfica vibrante contrastando [sombras/noite/chuva azul-escura e azul-elétrico] com o brilho super quente, dourado e laranja-fogo de [lâmpadas/faróis/abajures/janelas]. Escrito "[Nome do Cenário]" no topo. Proporção 9:16.

🎬 PASSO 3: ROTEIRO DECUPADO (TAKES EM ORDEM CRONOLÓGICA)

🎥 Take 1 | Cenário: [Nome do Cenário] | Ingredientes Obrigatórios: [01_Personagem_1.jpg] + [02_Personagem_2.jpg] + [03_Personagem_3.jpg] + [05_Cenario_A.jpg] | Duração: 10s | Proporção: 9:16 | Com Fala
Prompt de Vídeo:
[Estilo Visual] Gere um vídeo em estilo Animação 3D Pixar/Disney Cartoon vibrante (3D Pixar cartoon animation style, caricatura 3D cartoon estilizada com olhos grandes expressivos, cores vibrantes e saturadas, iluminação de ALTO CONTRASTE com luzes quentes laranja-douradas intensas contra chuva azul-escura e raios elétricos, zero fotorrealismo). Apenas som ambiente rústico e vozes. O personagem cartoon 3D [Personagem que não fala 1] ([03_Personagem_3.jpg]) está [posição espacial exata e ação] em [Nome do Cenário] ([05_Cenario_A.jpg]). Na [posição espacial exata], o(a) personagem cartoon 3D [Personagem que não fala 2] ([02_Personagem_2.jpg]) realiza [ação silenciosa]. Na [posição espacial exata de quem fala], o(a) personagem cartoon 3D [Personagem que fala] ([01_Personagem_1.jpg]) realiza [reação visual] e fala. IMEDIATAMENTE o áudio entra: "[Fala exata do roteiro entre 145 e 150 caracteres]".
[Câmera e Detalhes] Câmera: [Plano e movimento mostrando os demais personagens em suas posições, enquanto enquadra o Personagem que fala falando em sua posição exata]. Lip-sync preciso. Foley: [Sons ambientes detalhados].
```

### Exemplo Real Validado de Take em Movimento (`Take 01` — *Carona na Serra*):
```text
🎥 Take 1 | Cenário: Estrada de Barro da Serra | Ingredientes Obrigatórios: [01_Personagem_1_A_Filha_Jovem.jpg] + [02_Personagem_2_A_Mae_Costureira.jpg] + [03_Personagem_3_O_Andarilho_Sinistro.jpg] + [05_Cenario_A_Estrada_de_Barro_da_Serra.jpg] | Duração: 10s | Proporção: 9:16 | Com Fala
Prompt de Vídeo:
[Estilo Visual] Gere um vídeo em estilo Animação 3D Pixar/Disney Cartoon vibrante (3D Pixar cartoon animation style, caricatura 3D cartoon estilizada com olhos grandes expressivos, cores vibrantes e saturadas, iluminação de ALTO CONTRASTE com luzes quentes laranja-douradas intensas contra chuva azul-escura e raios elétricos, zero fotorrealismo). Apenas som ambiente rústico e vozes. O personagem caricato 3D O Andarilho Sinistro (03_Personagem_3_O_Andarilho_Sinistro.jpg) está caminhando na chuva forte da Estrada de Barro da Serra (05_Cenario_A_Estrada_de_Barro_da_Serra.jpg) do lado de fora. O carro antigo dirigido pela mãe cartoon 3D A Mãe Costureira (02_Personagem_2_A_Mae_Costureira.jpg) passa devagar ao lado dele. No banco do passageiro à direita, a jovem cartoon 3D A Filha Jovem (01_Personagem_1_A_Filha_Jovem.jpg) olha assustada pela janela para o homem caminhando na chuva e fala puxando a mãe. IMEDIATAMENTE o áudio entra: "Mãe, pelo amor de Deus, trava essa porta e acelera! Esse homem parado na chuva não tira esse sorriso estranho do rosto e está encarando só pra mim!".
[Câmera e Detalhes] Câmera: Plano lateral acompanhando o carro passando devagar ao lado do Andarilho Sinistro caminhando na chuva à direita, enquanto enquadra A Filha Jovem falando no banco do passageiro e A Mãe Costureira ao volante à esquerda. Lip-sync preciso. Foley: Chuva torrencial, poças de barro espirrando e motor do carro antigo.
```
