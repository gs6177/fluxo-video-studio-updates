using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace FluxoVideoStudio
{
    public class GrokAutomation
    {
        private readonly CdpController _cdp;
        private readonly PipelineConfig _config;
        private readonly Action<string> _log;

        public GrokAutomation(CdpController cdp, PipelineConfig config, Action<string> logger)
        {
            _cdp = cdp;
            _config = config;
            _log = logger ?? delegate { };
        }

        public async Task RunAsync(EpisodeWorkItem ep, CancellationToken ct)
        {
            if (!Directory.Exists(ep.AssetsDir))
                Directory.CreateDirectory(ep.AssetsDir);

            // 1. Regra 14: Sincronizar assets recorrentes de episódios anteriores (EP.1 / EP.2) e subpastas locais
            EpisodeParser.SyncRecurringAssetsFromPreviousEpisodes(ep, _log);
            if (_config.PreserveExistingAssets)
            {
                EpisodeParser.AutoAlignImportedAssetsOnDisk(ep, _log);
            }

            // 2. Regra 15 + Trava de Elenco: Conferir detalhadamente quais assets já existem em disco e preservar personagens prontos!
            List<string> requiredFiles = ep.AllRequiredFlowIngredients.Count > 0
                ? ep.AllRequiredFlowIngredients
                : ep.GrokSpecs.Select(s => s.TargetFileName).ToList();

            bool allExist = requiredFiles.Count > 0 && requiredFiles.All(req =>
            {
                string p = Path.Combine(ep.AssetsDir, req);
                return File.Exists(p) && new FileInfo(p).Length > 20 * 1024;
            });

            List<GrokAssetSpec> specsToGenerate = ep.GrokSpecs;
            if (_config.PreserveExistingAssets && ep.GrokSpecs.Count > 0)
            {
                List<GrokAssetSpec> existingSpecs = new List<GrokAssetSpec>();
                List<GrokAssetSpec> missingOnly = new List<GrokAssetSpec>();

                foreach (GrokAssetSpec s in ep.GrokSpecs)
                {
                    string p = Path.Combine(ep.AssetsDir, s.TargetFileName);
                    if (File.Exists(p) && new FileInfo(p).Length > 20 * 1024)
                        existingSpecs.Add(s);
                    else
                        missingOnly.Add(s);
                }

                if (existingSpecs.Count > 0)
                {
                    _log(string.Format("[Grok Imagine | Conferência de Elenco] {0} personagens/cenários já existentes conferidos em assets\\: {1}",
                        existingSpecs.Count,
                        string.Join(", ", existingSpecs.Select(x => x.TargetFileName))));
                }

                if (existingSpecs.Count > 0 && missingOnly.Count > 0)
                {
                    _log(string.Format("[Grok Imagine | Trava de Elenco] Preservando os {0} itens já existentes e gerando SOMENTE os {1} itens ausentes: {2}",
                        existingSpecs.Count,
                        missingOnly.Count,
                        string.Join(", ", missingOnly.Select(x => x.TargetFileName))));
                }
                specsToGenerate = missingOnly;
            }

            if (allExist || string.IsNullOrWhiteSpace(ep.GrokPromptText) || specsToGenerate.Count == 0)
            {
                if (allExist || (ep.GrokSpecs.Count > 0 && specsToGenerate.Count == 0))
                {
                    _log(string.Format("[Grok Imagine] 100% dos personagens e cenários necessários já estão prontos em '{0}'. Mantendo elenco original!",
                        ep.AssetsDir));
                }
                else
                {
                    _log("[Grok Imagine] Nenhum novo personagem/cenário solicitado em prompt_grok_passo1_e_2.txt.");
                }
                MirrorAssetsToTempFlow(ep.AssetsDir);
                EpisodeParser.RefreshDiskCounters(ep);
                return;
            }

            // 3. Separar os itens ausentes em:
            //    (A) Personagens Base e Cenários inéditos (gerados no Modo Agente sem anexo)
            //    (B) Novos Figurinos de Personagens Já Existentes (gerados anexando a foto do personagem base para manter 100% o mesmo rosto!)
            List<GrokAssetSpec> baseSpecsToGenerate = new List<GrokAssetSpec>();
            List<GrokAssetSpec> variantSpecsToGenerate = new List<GrokAssetSpec>();

            foreach (GrokAssetSpec ms in specsToGenerate)
            {
                string existingBaseCharPath = EpisodeParser.FindExistingBaseCharacterPathForVariantSpec(ep, ms);
                GrokAssetSpec episodeBaseCharSpec = EpisodeParser.FindBaseCharacterSpecInEpisode(ep, ms);

                if (!ms.IsScenario && (!string.IsNullOrEmpty(existingBaseCharPath) || episodeBaseCharSpec != null))
                {
                    variantSpecsToGenerate.Add(ms);
                }
                else
                {
                    baseSpecsToGenerate.Add(ms);
                }
            }

            // 3A. Se houver personagens base ou cenários inéditos ausentes, gera-os primeiro
            if (baseSpecsToGenerate.Count > 0)
            {
                await GenerateBaseSpecsBatchInAgentModeAsync(ep, baseSpecsToGenerate, ct);
            }

            // 3B. Se houver pré-definições de novos figurinos de personagens existentes, anexa o personagem base correspondente para gerar cada figurino mantendo o mesmo rosto
            if (variantSpecsToGenerate.Count > 0)
            {
                _log(string.Format("[Grok Imagine | Novos Figurinos] {0} pré-definição(ões) de figurino detectada(s) ({1}). Anexando a imagem do personagem base existente para manter 100% o mesmo rosto...",
                    variantSpecsToGenerate.Count,
                    string.Join(", ", variantSpecsToGenerate.Select(v => v.TargetFileName))));

                foreach (GrokAssetSpec varSpec in variantSpecsToGenerate)
                {
                    ct.ThrowIfCancellationRequested();
                    string baseCharPath = EpisodeParser.FindExistingBaseCharacterPathForVariantSpec(ep, varSpec);
                    if (string.IsNullOrEmpty(baseCharPath) || !File.Exists(baseCharPath))
                    {
                        _log(string.Format("[Grok Imagine | Novo Figurino] Aviso: Personagem base para '{0}' não encontrado em disco; gerando via Agente...", varSpec.TargetFileName));
                        await GenerateBaseSpecsBatchInAgentModeAsync(ep, new List<GrokAssetSpec> { varSpec }, ct);
                    }
                    else
                    {
                        _log(string.Format("[Grok Imagine | Novo Figurino] Conferido personagem existente '{0}' -> Anexando no Grok para gerar '{1}' ({2})...",
                            Path.GetFileName(baseCharPath), varSpec.TargetFileName, varSpec.DisplayTitle));
                        await GenerateVariantSpecWithBaseCharacterAsync(ep, varSpec, baseCharPath, ct);
                    }
                }
            }

            MirrorAssetsToTempFlow(ep.AssetsDir);
            EpisodeParser.RefreshDiskCounters(ep);
            _log(string.Format("[Grok Imagine] Etapa concluída com sucesso! Assets prontos em '{0}' e espelhados em Temp\\flow_assets.", ep.AssetsDir));
        }

        private async Task GenerateBaseSpecsBatchInAgentModeAsync(
            EpisodeWorkItem ep,
            List<GrokAssetSpec> specsToGenerate,
            CancellationToken ct)
        {
            string promptToSend;
            if (specsToGenerate.Count < ep.GrokSpecs.Count)
            {
                StringBuilder sbFiltered = new StringBuilder();
                sbFiltered.AppendLine("Faça cada imagem isolada e em 9:16, nome em cima da cabeça:");
                sbFiltered.AppendLine();
                foreach (GrokAssetSpec ms in specsToGenerate)
                {
                    sbFiltered.AppendLine(ms.RawPromptLine);
                    sbFiltered.AppendLine();
                }
                promptToSend = sbFiltered.ToString().Trim();
            }
            else
            {
                promptToSend = ep.GrokPromptText.Trim();
                if (promptToSend.IndexOf("Faça cada imagem isolada", StringComparison.OrdinalIgnoreCase) < 0)
                {
                    promptToSend = "Faça cada imagem isolada e em 9:16, nome em cima da cabeça:\n\n" + promptToSend;
                }
            }

            int expectedCount = specsToGenerate.Count;
            _log(string.Format("[Grok Imagine] Iniciando geração de {0} imagens base em 9:16 para {1} ({2})...",
                expectedCount, ep.StoryName, ep.EpisodeName));

            Exception lastErr = null;
            List<string> activeProfiles = _config.GetAvailableGrokProfiles(_log);
            foreach (string profile in activeProfiles)
            {
                ct.ThrowIfCancellationRequested();
                try
                {
                    _log(string.Format("[Grok Imagine] Tentando perfil autorizado '{0}'...", profile));
                    bool quotaExhausted = await TryGenerateAndDownloadWithProfileAsync(profile, promptToSend, ep, specsToGenerate, ct);
                    if (quotaExhausted)
                    {
                        _config.SetProfileStatus(profile, "LIMITE ATINGIDO");
                        _log(string.Format("[Grok Imagine] Limite semanal atingido no perfil '{0}'. Alternando automaticamente para o próximo perfil autorizado...", profile));
                        continue;
                    }

                    _config.SetProfileStatus(profile, "DISPONÍVEL");
                    return;
                }
                catch (OperationCanceledException)
                {
                    throw;
                }
                catch (Exception ex)
                {
                    lastErr = ex;
                    _log(string.Format("[Grok Imagine] Aviso no perfil '{0}': {1}. Tentando próximo perfil...", profile, ex.Message));
                }
            }

            throw new InvalidOperationException(
                "Não foi possível concluir a geração no Grok Imagine em nenhum dos perfis autorizados." +
                (lastErr != null ? " Último erro: " + lastErr.Message : ""));
        }

        private async Task WaitForGrokInteractiveReadyAsync(string sess, CancellationToken ct)
        {
            DateTime deadline = DateTime.UtcNow.AddSeconds(25);
            while (DateTime.UtcNow < deadline)
            {
                ct.ThrowIfCancellationRequested();
                string st = await _cdp.EvalStringAsync(sess, @"
(function(){
    var hasBox = !!Array.from(document.querySelectorAll('textarea, div[contenteditable=""true""], [role=""textbox""]')).find(el => {
        var r = el.getBoundingClientRect();
        return r.width > 100 && r.height > 20;
    });
    var hasModeBtn = !!Array.from(document.querySelectorAll('button, [role=""button""], [role=""radio""], [role=""tab""]')).find(el => {
        var t = (el.innerText || '').trim();
        var al = (el.getAttribute('aria-label') || '').trim();
        var r = el.getBoundingClientRect();
        return r.width > 12 && r.height > 12 &&
               (t === 'Agente' || t === 'Agent' || t === 'Imagem' || t === 'Image' || t === 'Vídeo' || t === 'Video' ||
                al === 'Agente' || al === 'Agent' || al === 'Imagem' || al === 'Image' || al === 'Vídeo' || al === 'Video');
    });
    return (hasBox && hasModeBtn) ? 'READY' : (hasBox ? 'BOX_ONLY' : 'WAIT');
})()", ct);
                if (st == "READY")
                {
                    await Task.Delay(1600, ct);
                    return;
                }
                await Task.Delay(500, ct);
            }
            await Task.Delay(1500, ct);
        }

        private async Task EnsureGrokImageModeAnd9x16Async(string sess, CancellationToken ct)
        {
            // 1. Remover anexos anteriores primeiro para que o seletor 'Aspecto de proporção' fique visível na barra
            await _cdp.EvalStringAsync(sess, @"
(function(){
    Array.from(document.querySelectorAll('button[aria-label*=""Remover imagem""], button[aria-label*=""Remove image""]')).forEach(b => b.click());
    return 'OK';
})()", ct);
            await Task.Delay(400, ct);

            // 2. Clicar no botão 'Imagem' (sem usar btn.innerText.length > 0 que sempre avaliava true!)
            Dictionary<string, object> imgModeBtn = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var els = Array.from(document.querySelectorAll('button, [role=""button""], [role=""radio""], [role=""tab""]'));
    var btn = els.find(el => {
        var t = (el.innerText || '').trim();
        var al = (el.getAttribute('aria-label') || '').trim();
        var r = el.getBoundingClientRect();
        return r.width > 12 && r.height > 12 && (al === 'Imagem' || al === 'Image' || t === 'Imagem' || t === 'Image');
    });
    if (!btn) return null;
    var r = btn.getBoundingClientRect();
    return JSON.stringify({ x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) });
})()", ct);
            if (imgModeBtn != null)
            {
                await _cdp.ClickAtAsync(sess, Convert.ToInt32(imgModeBtn["x"]), Convert.ToInt32(imgModeBtn["y"]), ct);
                await Task.Delay(800, ct);
            }

            // 3. Selecionar obrigatoriamente a proporção 9:16 ANTES de anexar imagens ou alternar para Agente
            await EnsureGrokDropdownOptionAsync(sess, "Aspecto de proporção", "Aspect ratio", "9:16", ct);
            await Task.Delay(450, ct);
        }

        private async Task EnsureCleanGrokImagineHomeAsync(string sess, string profile, CancellationToken ct)
        {
            string curUrl = await _cdp.EvalStringAsync(sess, "location.href || ''", ct);
            bool isInsidePostOrChat = curUrl.IndexOf("/imagine/post/", StringComparison.OrdinalIgnoreCase) >= 0 ||
                                      curUrl.IndexOf("conversation=", StringComparison.OrdinalIgnoreCase) >= 0 ||
                                      curUrl.IndexOf("/imagine", StringComparison.OrdinalIgnoreCase) < 0;

            if (isInsidePostOrChat)
            {
                await _cdp.SendCommandAsync("Page.navigate", new Dictionary<string, object> { { "url", "https://grok.com/imagine" } }, sess, 20000, ct);
                await _cdp.WaitForDocumentReadyAsync(sess, 25000, ct);
                await WaitForGrokInteractiveReadyAsync(sess, ct);
            }
            else
            {
                await WaitForGrokInteractiveReadyAsync(sess, ct);
            }

            // Remover quaisquer imagens anexadas anteriormente na caixa de prompt
            await _cdp.EvalStringAsync(sess, @"
(function(){
    Array.from(document.querySelectorAll('button[aria-label*=""Remover imagem""], button[aria-label*=""Remove image""]')).forEach(b => b.click());
    return 'OK';
})()", ct);
            await Task.Delay(450, ct);
        }

        private async Task GenerateVariantSpecWithBaseCharacterAsync(
            EpisodeWorkItem ep,
            GrokAssetSpec varSpec,
            string baseCharPath,
            CancellationToken ct)
        {
            if (ep == null || varSpec == null || string.IsNullOrEmpty(baseCharPath) || !File.Exists(baseCharPath))
                throw new FileNotFoundException("Arquivo do personagem base não encontrado para gerar o novo figurino.");

            string targetFullPath = Path.Combine(ep.AssetsDir, varSpec.TargetFileName);
            string charTitle = !string.IsNullOrEmpty(varSpec.DisplayTitle)
                ? varSpec.DisplayTitle
                : EpisodeParser.CleanAssetStem(varSpec.TargetFileName);

            string prompt = string.Format(
                "Crie uma imagem 9:16 vertical isolada em animação 3D estilizada semi-realista (CGI) mantendo EXATAMENTE o mesmo personagem da imagem de referência anexada (mesmo rosto, mesma idade, mesma fisionomia, mesmo cabelo/penteado, mesma expressão, mesmo corpo inteiro dos pés à cabeça, em pé, de frente, sobre FUNDO BRANCO NEUTRO PURO #FFFFFF, com o nome \"{0}\" escrito no topo acima da cabeça), trocando COMPLETAMENTE a roupa/figurino e os objetos das mãos conforme a pré-definição abaixo:\n\n{1}",
                charTitle,
                varSpec.RawPromptLine);

            Exception lastErr = null;
            List<string> activeProfiles = _config.GetAvailableGrokProfiles(_log);
            foreach (string profile in activeProfiles)
            {
                ct.ThrowIfCancellationRequested();
                try
                {
                    _log(string.Format("[Grok Imagine | Novo Figurino] Abrindo perfil '{0}' para anexar '{1}' e gerar '{2}'...",
                        profile, Path.GetFileName(baseCharPath), varSpec.TargetFileName));

                    string sess = await _cdp.OpenOrAttachProfileTabAsync(profile, _config.GrokUrl, "grok.com", false, ct);
                    await WaitForGrokInteractiveReadyAsync(sess, ct);

                    if (await HasQuotaExhaustedBannerAsync(sess, ct))
                    {
                        _config.SetProfileStatus(profile, "LIMITE ATINGIDO");
                        _log(string.Format("[Grok Imagine | Novo Figurino] Limite atingido no perfil '{0}'. Alternando para o próximo perfil...", profile));
                        continue;
                    }

                    await EnsureCleanGrokImagineHomeAsync(sess, profile, ct);

                    if (await HasQuotaExhaustedBannerAsync(sess, ct))
                    {
                        _config.SetProfileStatus(profile, "LIMITE ATINGIDO");
                        _log(string.Format("[Grok Imagine | Novo Figurino] Limite atingido no perfil '{0}'. Alternando para o próximo perfil...", profile));
                        continue;
                    }

                    // 1. Garantir modo 'Imagem' ativo e proporção 9:16 ANTES de anexar a imagem do personagem base!
                    await EnsureGrokImageModeAnd9x16Async(sess, ct);

                    // 2. Anexar a imagem do personagem base existente (com verificação e retentativa caso a página ainda estivesse hidratando)
                    _log(string.Format("[Grok Imagine | Novo Figurino] Anexando personagem base '{0}' na caixa do Grok...",
                        Path.GetFileName(baseCharPath)));

                    List<string> refFiles = new List<string> { baseCharPath };
                    bool attached = await _cdp.SetFileInputFilesByObjectIdAsync(
                        sess,
                        "document.querySelector('input[type=\"file\"][multiple]') || document.querySelector('input[type=\"file\"]')",
                        refFiles,
                        ct);

                    await Task.Delay(1400, ct);
                    string attachCountStr = await _cdp.EvalStringAsync(sess, @"
(function(){
    return Array.from(document.querySelectorAll('button[aria-label*=""Remover imagem""], button[aria-label*=""Remove image""]')).length.toString();
})()", ct);

                    if (!attached || attachCountStr == "0")
                    {
                        await _cdp.UploadFilesViaFileChooserAsync(
                            sess,
                            async () =>
                            {
                                Dictionary<string, object> trPt = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var b = Array.from(document.querySelectorAll('button')).find(el => {
        var al = (el.getAttribute('aria-label') || '');
        return el.getBoundingClientRect().width > 10 &&
               (al.indexOf('Transferir') >= 0 || al.indexOf('Upload') >= 0 || al.indexOf('Anexar') >= 0 || al.indexOf('Attach') >= 0);
    });
    if (!b) return null;
    var r = b.getBoundingClientRect();
    return JSON.stringify({ x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) });
})()", ct);
                                if (trPt != null)
                                    await _cdp.ClickAtAsync(sess, Convert.ToInt32(trPt["x"]), Convert.ToInt32(trPt["y"]), ct);
                            },
                            refFiles,
                            ct);
                        await Task.Delay(1800, ct);
                        attachCountStr = await _cdp.EvalStringAsync(sess, @"
(function(){
    return Array.from(document.querySelectorAll('button[aria-label*=""Remover imagem""], button[aria-label*=""Remove image""]')).length.toString();
})()", ct);
                    }

                    // Confirmar que o anexo apareceu e reafirmar proporção 9:16
                    _log(string.Format("[Grok Imagine | Novo Figurino] Personagem base anexado ({0} imagem(ns) na caixa). Confirmando 9:16 e enviando prompt de '{1}'...",
                        attachCountStr, varSpec.TargetFileName));

                    await EnsureGrokDropdownOptionAsync(sess, "Aspecto de proporção", "Aspect ratio", "9:16", ct);

                    // 3. Registrar URLs de imagens geradas existentes antes de submeter
                    await _cdp.EvalStringAsync(sess, @"
(function(){
    window.__fvsBaselineGenUrls = Array.from(document.querySelectorAll('img'))
        .map(i => i.currentSrc || i.src || '')
        .filter(Boolean);
    return 'OK';
})()", ct);

                    bool inserted = await InjectPromptIntoGrokBoxAsync(sess, prompt, ct);
                    if (!inserted)
                        throw new InvalidOperationException("Caixa de prompt não encontrada no Grok Imagine.");

                    await Task.Delay(600, ct);
                    await SubmitGrokPromptAsync(sess, ct);

                    // 4. Aguardar a nova imagem com o figurino terminar de gerar
                    DateTime deadline = DateTime.UtcNow.AddMinutes(4);
                    int stable = 0;
                    string generatedImgUrl = "";

                    while (DateTime.UtcNow < deadline)
                    {
                        ct.ThrowIfCancellationRequested();
                        await Task.Delay(3500, ct);

                        if (await HasQuotaExhaustedBannerAsync(sess, ct))
                        {
                            _config.SetProfileStatus(profile, "LIMITE ATINGIDO");
                            throw new InvalidOperationException("QUOTA_EXHAUSTED");
                        }

                        Dictionary<string, object> st = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var baseList = window.__fvsBaselineGenUrls || [];
    var body = (document.body && document.body.innerText) ? document.body.innerText : '';
    var genImgs = Array.from(document.querySelectorAll('img')).filter(img => {
        var s = (img.currentSrc || img.src || '');
        var r = img.getBoundingClientRect();
        if (r.width < 120 || r.height < 160 || !img.complete || img.naturalWidth < 300) return false;
        if (s.indexOf('media.x.ai') >= 0 || s.indexOf('agent-skills') >= 0 || s.indexOf('grok-web') >= 0 || s.indexOf('/website/') >= 0) return false;
        if (baseList.indexOf(s) >= 0) return false;
        return s.indexOf('/generated/') >= 0 || s.indexOf('assets.grok.com/users/') >= 0;
    });
    var spinners = Array.from(document.querySelectorAll('[role=""progressbar""], .animate-spin, svg.animate-spin')).filter(el => {
        var r = el.getBoundingClientRect();
        return r.width > 4 && r.height > 4;
    }).length;
    var hasPct = /\b\d{1,2}%\b/.test(body);
    var genText = hasPct || /\b(Generating|Imaginando|Criando imagens|Gerando)\b/i.test(body);
    var latestSrc = genImgs.length > 0 ? (genImgs[genImgs.length - 1].currentSrc || genImgs[genImgs.length - 1].src || '') : '';
    return JSON.stringify({ count: genImgs.length, spinners: spinners, genText: genText, latestSrc: latestSrc });
})()", ct);

                        if (st == null) continue;
                        int count = Convert.ToInt32(st["count"]);
                        int spinners = Convert.ToInt32(st["spinners"]);
                        bool genText = Convert.ToBoolean(st["genText"]);
                        string latestSrc = Convert.ToString(st["latestSrc"] ?? "");

                        _log(string.Format("[Grok Imagine | Novo Figurino] Aguardando '{0}': {1}/1 imagem gerada (spinners: {2})...",
                            varSpec.TargetFileName, count > 0 ? 1 : 0, spinners));

                        if (count > 0 && spinners == 0 && !genText)
                        {
                            generatedImgUrl = latestSrc;
                            stable++;
                            if (stable >= 2) break;
                        }
                        else
                        {
                            stable = 0;
                        }
                    }

                    if (string.IsNullOrEmpty(generatedImgUrl))
                        throw new TimeoutException(string.Format("Timeout aguardando geração do novo figurino '{0}' no Grok Imagine.", varSpec.TargetFileName));

                    // 5. Garantir que a miniatura recém-gerada (Thumbnail 2 / src com '/generated/') esteja selecionada (e não a Thumbnail 1 da imagem base anexada)
                    Dictionary<string, object> genThumbPt = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var thumbBtns = Array.from(document.querySelectorAll('button[aria-label^=""Thumbnail ""]')).filter(b => b.getBoundingClientRect().width > 10);
    if (thumbBtns.length <= 1) return null;
    var genBtn = thumbBtns.find(b => {
        var img = b.querySelector('img');
        var s = img ? (img.currentSrc || img.src || '') : '';
        return s.indexOf('/generated/') >= 0 || s.indexOf('assets.grok.com/users/') >= 0;
    }) || thumbBtns[thumbBtns.length - 1];
    if (!genBtn) return null;
    var r = genBtn.getBoundingClientRect();
    return JSON.stringify({ x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) });
})()", ct);

                    if (genThumbPt != null)
                    {
                        await _cdp.ClickAtAsync(sess, Convert.ToInt32(genThumbPt["x"]), Convert.ToInt32(genThumbPt["y"]), ct);
                        await Task.Delay(650, ct);
                    }

                    // 6. Baixar a imagem gerada via botão 'Baixar' (↓)
                    string stagingDir = Path.Combine(ep.AssetsDir, "_grok_var_" + DateTime.Now.ToString("HHmmss"));
                    Directory.CreateDirectory(stagingDir);
                    await _cdp.SetDownloadBehaviorAsync(stagingDir, ct);

                    Dictionary<string, object> dlPt = await FindGrokDownloadButtonPointAsync(sess, ct);
                    if (dlPt == null)
                    {
                        await EnsureThumbnailViewerOpenAsync(sess, 1, ct);
                        dlPt = await FindGrokDownloadButtonPointAsync(sess, ct);
                    }

                    HashSet<string> beforeFiles = new HashSet<string>(Directory.GetFiles(stagingDir), StringComparer.OrdinalIgnoreCase);
                    string savedFile = "";

                    if (dlPt != null)
                    {
                        await _cdp.ClickAtAsync(sess, Convert.ToInt32(dlPt["x"]), Convert.ToInt32(dlPt["y"]), ct);
                        savedFile = await _cdp.WaitForSingleDownloadAsync(stagingDir, beforeFiles, 30 * 1024, 35000, ct);
                    }

                    if (string.IsNullOrEmpty(savedFile) && !string.IsNullOrEmpty(generatedImgUrl))
                    {
                        beforeFiles = new HashSet<string>(Directory.GetFiles(stagingDir), StringComparer.OrdinalIgnoreCase);
                        string b64Url = Convert.ToBase64String(Encoding.UTF8.GetBytes(generatedImgUrl));
                        await _cdp.EvalStringAsync(sess, string.Format(@"
(function(){{
    var u = atob('{0}');
    fetch(u, {{ credentials: 'include' }})
        .then(r => r.blob())
        .then(b => {{
            var burl = URL.createObjectURL(b);
            var a = document.createElement('a');
            a.href = burl;
            a.download = '{1}';
            document.body.appendChild(a);
            a.click();
            setTimeout(() => {{ a.remove(); URL.revokeObjectURL(burl); }}, 4000);
        }});
    return 'FETCH_IMG';
}})()", b64Url, varSpec.TargetFileName), ct);
                        savedFile = await _cdp.WaitForSingleDownloadAsync(stagingDir, beforeFiles, 30 * 1024, 35000, ct);
                    }

                    if (string.IsNullOrEmpty(savedFile))
                    {
                        await _cdp.ResetDownloadBehaviorToDefaultAsync();
                        try { Directory.Delete(stagingDir, true); } catch { }
                        throw new IOException(string.Format("Timeout aguardando download da imagem '{0}' no Grok Imagine.", varSpec.TargetFileName));
                    }

                    await _cdp.ResetDownloadBehaviorToDefaultAsync();
                    File.Copy(savedFile, targetFullPath, true);
                    try { Directory.Delete(stagingDir, true); } catch { }

                    // Sincronizar automaticamente com os demais episódios (EP.1, EP.2, EP.3) da mesma história que usem este figurino
                    if (!string.IsNullOrEmpty(ep.StoryRootPath) && Directory.Exists(ep.StoryRootPath))
                    {
                        foreach (string sub in Directory.GetDirectories(ep.StoryRootPath))
                        {
                            if (Regex.IsMatch(Path.GetFileName(sub), @"^EP\.?\s*\d+$", RegexOptions.IgnoreCase))
                            {
                                string subAssets = Path.Combine(sub, "assets");
                                if (!Directory.Exists(subAssets)) Directory.CreateDirectory(subAssets);
                                string dstSub = Path.Combine(subAssets, varSpec.TargetFileName);
                                if (!string.Equals(dstSub, targetFullPath, StringComparison.OrdinalIgnoreCase))
                                {
                                    try { File.Copy(targetFullPath, dstSub, true); } catch { }
                                }
                            }
                        }
                    }

                    _config.SetProfileStatus(profile, "DISPONÍVEL");
                    _log(string.Format("[Grok Imagine | Novo Figurino] '{0}' salvo com sucesso ({1} KB) mantendo o mesmo rosto de '{2}'!",
                        varSpec.TargetFileName, new FileInfo(targetFullPath).Length / 1024, Path.GetFileName(baseCharPath)));
                    return;
                }
                catch (OperationCanceledException)
                {
                    throw;
                }
                catch (Exception ex)
                {
                    lastErr = ex;
                    if (ex.Message == "QUOTA_EXHAUSTED")
                    {
                        _log(string.Format("[Grok Imagine | Novo Figurino] Limite atingido no perfil '{0}'. Alternando para o próximo perfil...", profile));
                        continue;
                    }
                    _log(string.Format("[Grok Imagine | Novo Figurino] Aviso no perfil '{0}': {1}. Tentando próximo perfil...", profile, ex.Message));
                }
            }

            throw new InvalidOperationException(
                string.Format("Não foi possível gerar o novo figurino '{0}' em nenhum dos perfis autorizados do Grok.", varSpec.TargetFileName) +
                (lastErr != null ? " Último erro: " + lastErr.Message : ""));
        }

        private async Task<bool> TryGenerateAndDownloadWithProfileAsync(
            string profile,
            string fullPrompt,
            EpisodeWorkItem ep,
            List<GrokAssetSpec> activeSpecs,
            CancellationToken ct)
        {
            string sess = await _cdp.OpenOrAttachProfileTabAsync(profile, _config.GrokUrl, "grok.com", false, ct);
            await WaitForGrokInteractiveReadyAsync(sess, ct);

            // Verifica cota antes de enviar
            if (await HasQuotaExhaustedBannerAsync(sess, ct))
                return true;

            await EnsureCleanGrokImagineHomeAsync(sess, profile, ct);

            if (await HasQuotaExhaustedBannerAsync(sess, ct))
                return true;

            // PASSO 1 OBRIGATÓRIO: Travar proporção 9:16 no modo Imagem e depois marcar o botão "Agente"
            _log("[Grok Imagine] Passo 1: Configurando proporção 9:16 e ativando função 'Agente'...");
            await EnsureGrokImageModeAnd9x16Async(sess, ct);
            await EnsureAgenteModeSelectedAsync(sess, ct);
            await EnsureGrokDropdownOptionAsync(sess, "Aspecto de proporção", "Aspect ratio", "9:16", ct);

            // Registrar URLs de imagens geradas preexistentes na página (ignorando templates estáticos do Grok)
            await _cdp.EvalStringAsync(sess, @"
(function(){
    window.__fvsBaselineBatchUrls = Array.from(document.querySelectorAll('img'))
        .map(i => i.currentSrc || i.src || '')
        .filter(Boolean);
    return 'OK';
})()", ct);

            // PASSO 2 OBRIGATÓRIO: Inserir texto completo e enviar
            _log("[Grok Imagine] Passo 2: Enviando comando completo (Personagens + Cenários em 9:16)...");
            bool inserted = await InjectPromptIntoGrokBoxAsync(sess, fullPrompt, ct);
            if (!inserted)
                throw new InvalidOperationException("Campo 'O que você gostaria de criar?' não encontrado na tela do Grok Imagine.");

            await Task.Delay(600, ct);
            await SubmitGrokPromptAsync(sess, ct);

            // Aguardar geração de todas as imagens solicitadas
            int expectedCount = activeSpecs.Count;
            _log(string.Format("[Grok Imagine] Aguardando geração completa das {0} imagens...", expectedCount));

            DateTime startWait = DateTime.UtcNow;
            DateTime maxDeadline = startWait.AddMinutes(9);
            int stableReadyPolls = 0;

            while (DateTime.UtcNow < maxDeadline)
            {
                ct.ThrowIfCancellationRequested();
                await Task.Delay(4000, ct);

                if (await HasQuotaExhaustedBannerAsync(sess, ct))
                    return true;

                Dictionary<string, object> st = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var baseList = window.__fvsBaselineBatchUrls || [];
    var body = (document.body.innerText || '');
    var thumbs = Array.from(document.querySelectorAll('button[aria-label^=""Thumbnail ""]')).filter(b => b.getBoundingClientRect().width > 10).length;
    var grokImgs = Array.from(document.querySelectorAll('img')).filter(img => {
        var s = (img.currentSrc || img.src || '');
        var r = img.getBoundingClientRect();
        if (r.width < 90 || r.height < 120 || !img.complete || img.naturalWidth < 200) return false;
        if (s.indexOf('media.x.ai') >= 0 || s.indexOf('agent-skills') >= 0 || s.indexOf('grok-web') >= 0 || s.indexOf('/website/') >= 0) return false;
        if (baseList.indexOf(s) >= 0) return false;
        return s.indexOf('/generated/') >= 0 || s.indexOf('assets.grok.com/users/') >= 0 || s.indexOf('blob:') >= 0;
    }).length;
    var spinners = Array.from(document.querySelectorAll('[role=""progressbar""], .animate-spin, svg.animate-spin')).filter(el => {
        var r = el.getBoundingClientRect();
        return r.width > 4 && r.height > 4;
    }).length;
    var hasPct = /\b\d{1,2}%\b/.test(body);
    var genText = hasPct || /\b(Generating|Imaginando|Criando imagens|Gerando)\b/i.test(body);
    return JSON.stringify({ thumbs: thumbs, imgs: grokImgs, spinners: spinners, genText: genText });
})()", ct);

                if (st == null) continue;

                int thumbs = Convert.ToInt32(st["thumbs"]);
                int imgs = Convert.ToInt32(st["imgs"]);
                int spinners = Convert.ToInt32(st["spinners"]);
                bool genText = Convert.ToBoolean(st["genText"]);
                int effectiveCount = Math.Max(thumbs, imgs);

                _log(string.Format("[Grok Imagine] Progresso: {0}/{1} imagens detectadas (miniaturas: {2}, spinners: {3})...",
                    effectiveCount, expectedCount, thumbs, spinners));

                if (effectiveCount >= expectedCount && spinners == 0 && !genText)
                {
                    stableReadyPolls++;
                    if (stableReadyPolls >= 2)
                        break;
                }
                else
                {
                    stableReadyPolls = 0;
                }
            }

            // PASSO 3 OBRIGATÓRIO: Abrir visualização com coluna de miniaturas à esquerda (se ainda estiver na grade)
            await EnsureThumbnailViewerOpenAsync(sess, expectedCount, ct);

            int totalThumbs = await GetVisibleThumbnailCountAsync(sess, ct);
            string stagingDir = Path.Combine(ep.AssetsDir, "_grok_staging_" + DateTime.Now.ToString("HHmmss"));
            Directory.CreateDirectory(stagingDir);
            await _cdp.SetDownloadBehaviorAsync(stagingDir, ct);

            List<string> downloadedRawPaths = new List<string>();

            if (totalThumbs <= 0)
            {
                // Quando expectedCount == 1, o Grok abre o visualizador do post sem coluna lateral de miniaturas e exibe o botão 'Baixar' diretamente
                Dictionary<string, object> singleDlPt = await FindGrokDownloadButtonPointAsync(sess, ct);
                if (singleDlPt == null)
                {
                    try { Directory.Delete(stagingDir, true); } catch { }
                    throw new InvalidOperationException("Coluna de miniaturas ('Thumbnail 1..N') ou botão 'Baixar' não apareceu após a geração no Grok Imagine.");
                }

                HashSet<string> beforeSingle = new HashSet<string>(Directory.GetFiles(stagingDir), StringComparer.OrdinalIgnoreCase);
                await _cdp.ClickAtAsync(sess, Convert.ToInt32(singleDlPt["x"]), Convert.ToInt32(singleDlPt["y"]), ct);
                string singleSaved = await _cdp.WaitForSingleDownloadAsync(stagingDir, beforeSingle, 50 * 1024, 35000, ct);
                if (string.IsNullOrEmpty(singleSaved))
                    throw new IOException("Timeout aguardando download da imagem única no Grok Imagine.");

                downloadedRawPaths.Add(singleSaved);
                _log(string.Format("[Grok Imagine] Imagem 1/1 salva ({0} KB).", new FileInfo(singleSaved).Length / 1024));
            }
            else
            {
                // Para CADA miniatura na coluna esquerda -> Clicar na miniatura -> Clicar no botão Baixar (↓)
                for (int idx = 1; idx <= totalThumbs; idx++)
                {
                    ct.ThrowIfCancellationRequested();
                    _log(string.Format("[Grok Imagine] Baixando imagem {0}/{1}: clicando em 'Thumbnail {0}' e depois no botão 'Baixar' (↓)...",
                        idx, totalThumbs));

                    Dictionary<string, object> thumbPt = await _cdp.EvalJsonAsync(sess, string.Format(@"
(function(){{
    var btns = Array.from(document.querySelectorAll('button[aria-label=""Thumbnail {0}""]'));
    var b = btns.find(x => x.getBoundingClientRect().width > 10) || btns[0];
    if (!b) return null;
    b.scrollIntoView({{ block: 'center' }});
    var r = b.getBoundingClientRect();
    return JSON.stringify({{ x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) }});
}})()", idx), ct);

                    if (thumbPt == null)
                    {
                        _log(string.Format("[Grok Imagine] Aviso: 'Thumbnail {0}' não encontrada na coluna esquerda.", idx));
                        continue;
                    }

                    await _cdp.ClickAtAsync(sess, Convert.ToInt32(thumbPt["x"]), Convert.ToInt32(thumbPt["y"]), ct);
                    await Task.Delay(750, ct);

                    Dictionary<string, object> dlPt = await FindGrokDownloadButtonPointAsync(sess, ct);
                    if (dlPt == null)
                        throw new InvalidOperationException("Botão 'Baixar' (↓) visível não foi encontrado na visualização do Grok Imagine.");

                    HashSet<string> beforeFiles = new HashSet<string>(Directory.GetFiles(stagingDir), StringComparer.OrdinalIgnoreCase);
                    await _cdp.ClickAtAsync(sess, Convert.ToInt32(dlPt["x"]), Convert.ToInt32(dlPt["y"]), ct);

                    // Regra 13: Aguardar download individual concluir e validar tamanho > 50 KB antes da próxima miniatura
                    string savedFile = await _cdp.WaitForSingleDownloadAsync(stagingDir, beforeFiles, 50 * 1024, 35000, ct);
                    if (string.IsNullOrEmpty(savedFile))
                    {
                        _log(string.Format("[Grok Imagine] Retentando clique no botão 'Baixar' para Thumbnail {0}...", idx));
                        await _cdp.ClickAtAsync(sess, Convert.ToInt32(dlPt["x"]), Convert.ToInt32(dlPt["y"]), ct);
                        savedFile = await _cdp.WaitForSingleDownloadAsync(stagingDir, beforeFiles, 50 * 1024, 35000, ct);
                    }

                    if (string.IsNullOrEmpty(savedFile))
                        throw new IOException(string.Format("Timeout aguardando download da imagem Thumbnail {0} no Grok Imagine.", idx));

                    downloadedRawPaths.Add(savedFile);
                    _log(string.Format("[Grok Imagine] Imagem {0}/{1} salva ({2} KB).",
                        idx, totalThumbs, new FileInfo(savedFile).Length / 1024));
                }
            }

            // PASSO 4 OBRIGATÓRIO (Regra 20): Conferência automática do título no topo via Windows OCR pt-BR e renomeação exata
            await _cdp.ResetDownloadBehaviorToDefaultAsync();
            MatchAndRenameGrokDownloadsWithOcr(stagingDir, downloadedRawPaths, activeSpecs, ep.AssetsDir);

            try { Directory.Delete(stagingDir, true); } catch { }
            return false;
        }

        private async Task<bool> HasQuotaExhaustedBannerAsync(string sess, CancellationToken ct)
        {
            string res = await _cdp.EvalStringAsync(sess, @"
(function(){
    var t = (document.body && document.body.innerText) ? document.body.innerText : '';
    if (/You've used up your media generation credits/i.test(t) ||
        /limite de uso atingido/i.test(t) ||
        /adicione cr[eé]ditos/i.test(t) ||
        /atingiu seu limite/i.test(t) ||
        /atingiu o limite/i.test(t) ||
        /usage limit reached/i.test(t) ||
        /rate limit reached/i.test(t) ||
        /out of credits/i.test(t) ||
        /usagePoolExhausted/i.test(t)) {
        return 'EXHAUSTED';
    }
    return 'OK';
})()", ct);
            return res == "EXHAUSTED";
        }

        private async Task EnsureAgenteModeSelectedAsync(string sess, CancellationToken ct)
        {
            Dictionary<string, object> info = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var els = Array.from(document.querySelectorAll('button, [role=""button""], [role=""radio""], [role=""tab""]'));
    var btn = els.find(el => {
        var t = (el.innerText || '').trim();
        var al = (el.getAttribute('aria-label') || '').trim();
        var r = el.getBoundingClientRect();
        return r.width > 15 && r.height > 15 &&
               (t === 'Agente' || t === 'Agent' || al === 'Agente' || al === 'Agent');
    });
    if (!btn) return JSON.stringify({ found: false });

    var r = btn.getBoundingClientRect();
    var txt = (btn.innerText || '').trim();
    var pressed = btn.getAttribute('aria-pressed') === 'true' ||
                  btn.getAttribute('aria-checked') === 'true' ||
                  btn.getAttribute('aria-selected') === 'true' ||
                  btn.getAttribute('data-state') === 'active' ||
                  btn.getAttribute('data-active') === 'true' ||
                  txt === 'Agente' ||
                  txt === 'Agent' ||
                  r.width >= 65 ||
                  location.pathname.indexOf('/imagine/agent') >= 0;

    return JSON.stringify({
        found: true,
        active: pressed,
        x: Math.round(r.left + r.width/2),
        y: Math.round(r.top + r.height/2)
    });
})()", ct);

            if (info != null && Convert.ToBoolean(info["found"]))
            {
                bool active = Convert.ToBoolean(info["active"]);
                if (!active)
                {
                    await _cdp.ClickAtAsync(sess, Convert.ToInt32(info["x"]), Convert.ToInt32(info["y"]), ct);
                    await Task.Delay(800, ct);
                    _log("[Grok Imagine] Botão 'Agente' ativado com sucesso.");
                }
                else
                {
                    _log("[Grok Imagine] Função 'Agente' já está ativa.");
                }
            }
            else
            {
                // Navega diretamente para /imagine/agent caso o chip esteja oculto
                await _cdp.SendCommandAsync("Page.navigate", new Dictionary<string, object> { { "url", "https://grok.com/imagine/agent" } }, sess, 20000, ct);
                await _cdp.WaitForDocumentReadyAsync(sess, 20000, ct);
                await Task.Delay(1200, ct);
            }
        }

        private async Task<int> CountThumbnailsOrGeneratedImagesAsync(string sess, CancellationToken ct)
        {
            string s = await _cdp.EvalStringAsync(sess, @"
(function(){
    return Array.from(document.querySelectorAll('img')).filter(img => {
        var src = (img.currentSrc || img.src || '');
        if (src.indexOf('media.x.ai') >= 0 || src.indexOf('agent-skills') >= 0 || src.indexOf('grok-web') >= 0 || src.indexOf('/website/') >= 0) return false;
        var r = img.getBoundingClientRect();
        return r.width >= 90 && r.height >= 120 && img.complete && img.naturalWidth >= 200 &&
               (src.indexOf('/generated/') >= 0 || src.indexOf('assets.grok.com/users/') >= 0);
    }).length;
})()", ct);
            int n;
            return int.TryParse(s, out n) ? n : 0;
        }

        private async Task<bool> InjectPromptIntoGrokBoxAsync(string sess, string promptText, CancellationToken ct)
        {
            string b64 = Convert.ToBase64String(Encoding.UTF8.GetBytes(promptText));
            string res = await _cdp.EvalStringAsync(sess, string.Format(@"
(function(){{
    var bytes = Uint8Array.from(atob('{0}'), c => c.charCodeAt(0));
    var text = new TextDecoder('utf-8').decode(bytes);

    var ta = Array.from(document.querySelectorAll('textarea')).find(el => {{
        var r = el.getBoundingClientRect();
        return r.width > 100 && r.height > 20;
    }});
    if (ta) {{
        ta.focus();
        var nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value').set;
        nativeSetter.call(ta, text);
        ta.dispatchEvent(new Event('input', {{ bubbles: true }}));
        ta.dispatchEvent(new Event('change', {{ bubbles: true }}));
        return 'TEXTAREA:' + ta.value.length;
    }}

    var ce = Array.from(document.querySelectorAll('div[contenteditable=""true""], [role=""textbox""]')).find(el => {{
        var r = el.getBoundingClientRect();
        return r.width > 100 && r.height > 20;
    }});
    if (ce) {{
        ce.focus();
        document.execCommand('selectAll', false, null);
        document.execCommand('insertText', false, text);
        return 'CE:' + (ce.innerText || '').length;
    }}
    return '';
}})()", b64), ct);

            return !string.IsNullOrEmpty(res);
        }

        private async Task SubmitGrokPromptAsync(string sess, CancellationToken ct)
        {
            Dictionary<string, object> btnPt = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var btns = Array.from(document.querySelectorAll('button[type=""submit""], button[aria-label*=""submeter"" i], button[aria-label*=""Enviar"" i], button[aria-label*=""Submit"" i], button[aria-label*=""Send"" i]'))
        .filter(b => !b.disabled && b.getBoundingClientRect().width > 15);
    if (btns.length > 0) {
        var b = btns[btns.length - 1];
        var r = b.getBoundingClientRect();
        return JSON.stringify({ x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) });
    }
    return null;
})()", ct);

            if (btnPt != null)
            {
                await _cdp.ClickAtAsync(sess, Convert.ToInt32(btnPt["x"]), Convert.ToInt32(btnPt["y"]), ct);
            }
            else
            {
                await _cdp.PressEnterAsync(sess, ct);
            }
        }

        private async Task EnhanceGrokVideoPromptAsync(string sess, int takeNumber, string originalPrompt, CancellationToken ct)
        {
            string initialNorm = (originalPrompt ?? "").Trim();
            int initialLen = initialNorm.Length;

            Dictionary<string, object> wandBtn = null;
            for (int attempt = 0; attempt < 5; attempt++)
            {
                wandBtn = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var ce = Array.from(document.querySelectorAll('div[contenteditable=""true""], [role=""textbox""], textarea')).find(el => {
        var r = el.getBoundingClientRect();
        return r.width > 100 && r.height > 20;
    });
    var currentTxt = ce ? (ce.value !== undefined ? ce.value : (ce.innerText || '')).trim() : '';

    var b = Array.from(document.querySelectorAll('button, [role=""button""]')).find(el => {
        var r = el.getBoundingClientRect();
        if (r.width <= 10 || r.height <= 10 || el.disabled) return false;
        var al = (el.getAttribute('aria-label') || '').toLowerCase();
        var title = (el.getAttribute('title') || '').toLowerCase();
        var hasEnhanceIcon = !!el.querySelector('g[id=""name=enhance""], svg[id*=""enhance""], g[id*=""magic""], g[id*=""wand""]');
        return al.indexOf('aprimorar') >= 0 ||
               al.indexOf('enhance') >= 0 ||
               al.indexOf('melhorar') >= 0 ||
               title.indexOf('aprimorar') >= 0 ||
               title.indexOf('enhance') >= 0 ||
               hasEnhanceIcon;
    });
    if (!b) return JSON.stringify({ found: false, currentTxt: currentTxt });
    var br = b.getBoundingClientRect();
    b.click();
    return JSON.stringify({
        found: true,
        x: Math.round(br.left + br.width / 2),
        y: Math.round(br.top + br.height / 2),
        currentTxt: currentTxt
    });
})()", ct);

                if (wandBtn != null && wandBtn.ContainsKey("found") && Convert.ToBoolean(wandBtn["found"]))
                {
                    if (wandBtn.ContainsKey("currentTxt"))
                    {
                        string domTxt = Convert.ToString(wandBtn["currentTxt"] ?? "").Trim();
                        if (!string.IsNullOrEmpty(domTxt))
                        {
                            initialNorm = domTxt;
                            initialLen = domTxt.Length;
                        }
                    }
                    break;
                }

                await Task.Delay(400, ct);
            }

            if (wandBtn == null || !wandBtn.ContainsKey("found") || !Convert.ToBoolean(wandBtn["found"]))
            {
                _log(string.Format("[Grok Vídeo] Botão 'Aprimorar o prompt' não localizado para o Take_{0:00}; enviando prompt original.", takeNumber));
                return;
            }

            _log(string.Format("[Grok Vídeo] Acionando 'Aprimorar o prompt' (varinha mágica) para deixar o Take_{0:00} no padrão Grok...", takeNumber));

            DateTime enhanceDeadline = DateTime.UtcNow.AddSeconds(25);
            string lastTxt = initialNorm;
            int stableChangedPolls = 0;
            bool fallbackClickedCoords = false;
            DateTime startWait = DateTime.UtcNow;

            while (DateTime.UtcNow < enhanceDeadline)
            {
                ct.ThrowIfCancellationRequested();
                await Task.Delay(600, ct);

                Dictionary<string, object> poll = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var ce = Array.from(document.querySelectorAll('div[contenteditable=""true""], [role=""textbox""], textarea')).find(el => {
        var r = el.getBoundingClientRect();
        return r.width > 100 && r.height > 20;
    });
    var txt = ce ? (ce.value !== undefined ? ce.value : (ce.innerText || '')).trim() : '';
    var wandStillThere = !!Array.from(document.querySelectorAll('button, [role=""button""]')).find(el => {
        var r = el.getBoundingClientRect();
        if (r.width <= 10 || r.height <= 10) return false;
        var al = (el.getAttribute('aria-label') || '').toLowerCase();
        var hasEnhanceIcon = !!el.querySelector('g[id=""name=enhance""], svg[id*=""enhance""]');
        return al.indexOf('aprimorar') >= 0 || al.indexOf('enhance') >= 0 || hasEnhanceIcon;
    });
    return JSON.stringify({ txt: txt, wandStillThere: wandStillThere });
})()", ct);

                if (poll == null)
                    continue;

                string curTxt = poll.ContainsKey("txt") ? Convert.ToString(poll["txt"] ?? "").Trim() : "";
                bool wandStillThere = poll.ContainsKey("wandStillThere") && Convert.ToBoolean(poll["wandStillThere"]);

                if (!fallbackClickedCoords && wandStillThere && string.Equals(curTxt, initialNorm, StringComparison.Ordinal) &&
                    (DateTime.UtcNow - startWait).TotalMilliseconds >= 1600)
                {
                    fallbackClickedCoords = true;
                    await _cdp.ClickAtAsync(sess, Convert.ToInt32(wandBtn["x"]), Convert.ToInt32(wandBtn["y"]), ct);
                    continue;
                }

                if (!string.IsNullOrEmpty(curTxt) && !string.Equals(curTxt, initialNorm, StringComparison.Ordinal) && curTxt.Length >= 25)
                {
                    if (string.Equals(curTxt, lastTxt, StringComparison.Ordinal))
                    {
                        stableChangedPolls++;
                        if (stableChangedPolls >= 3)
                        {
                            _log(string.Format("[Grok Vídeo] Prompt do Take_{0:00} aprimorado com sucesso para o padrão Grok ({1} -> {2} caracteres).",
                                takeNumber, initialLen, curTxt.Length));
                            return;
                        }
                    }
                    else
                    {
                        stableChangedPolls = 0;
                    }
                }

                lastTxt = curTxt;
            }

            _log(string.Format("[Grok Vídeo] Tempo limite aguardando aprimoramento do prompt do Take_{0:00}; prosseguindo com o texto atual da caixa.", takeNumber));
        }

        private async Task EnsureThumbnailViewerOpenAsync(string sess, int expectedCount, CancellationToken ct)
        {
            int visibleThumbs = await GetVisibleThumbnailCountAsync(sess, ct);
            if (visibleThumbs > 0) return;

            _log("[Grok Imagine] Abrindo visualização detalhada do post para exibir coluna de miniaturas à esquerda...");
            Dictionary<string, object> firstImgPt = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var imgs = Array.from(document.querySelectorAll('img')).filter(img => {
        var r = img.getBoundingClientRect();
        return r.width >= 90 && r.height >= 120 && img.complete && img.naturalWidth >= 200;
    });
    if (imgs.length === 0) return null;
    // Pega a primeira imagem do lote recém-gerado
    var startIdx = Math.max(0, imgs.length - " + expectedCount + @");
    var target = imgs[startIdx];
    target.scrollIntoView({ block: 'center' });
    var r = target.getBoundingClientRect();
    return JSON.stringify({ x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) });
})()", ct);

            if (firstImgPt != null)
            {
                await _cdp.ClickAtAsync(sess, Convert.ToInt32(firstImgPt["x"]), Convert.ToInt32(firstImgPt["y"]), ct);
                await Task.Delay(1500, ct);
            }
        }

        private async Task<int> GetVisibleThumbnailCountAsync(string sess, CancellationToken ct)
        {
            string s = await _cdp.EvalStringAsync(sess, @"
(function(){
    return Array.from(document.querySelectorAll('button[aria-label^=""Thumbnail ""]'))
        .filter(b => b.getBoundingClientRect().width > 10).length;
})()", ct);
            int n;
            return int.TryParse(s, out n) ? n : 0;
        }

        public Dictionary<string, string> RunWindowsOcrOnFolder(string folderPath)
        {
            Dictionary<string, string> map = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            string ocrScript = Path.Combine(_config.StudioScriptsDir, "ocr_grok_headers.ps1");
            if (!File.Exists(ocrScript) || !Directory.Exists(folderPath)) return map;

            try
            {
                ProcessStartInfo psi = new ProcessStartInfo
                {
                    FileName = "powershell.exe",
                    Arguments = string.Format("-NoProfile -ExecutionPolicy Bypass -File \"{0}\" -FolderPath \"{1}\"", ocrScript, folderPath),
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    CreateNoWindow = true,
                    StandardOutputEncoding = Encoding.UTF8
                };

                using (Process p = Process.Start(psi))
                {
                    string stdout = p.StandardOutput.ReadToEnd();
                    p.WaitForExit(30000);

                    if (!string.IsNullOrWhiteSpace(stdout))
                    {
                        JavaScriptSerializer ser = new JavaScriptSerializer();
                        IEnumerable arr = ser.DeserializeObject(stdout.Trim()) as IEnumerable;
                        if (arr != null)
                        {
                            foreach (object item in arr)
                            {
                                Dictionary<string, object> d = item as Dictionary<string, object>;
                                if (d == null) continue;
                                string fullPath = d.ContainsKey("FullPath") ? Convert.ToString(d["FullPath"]) : "";
                                string ocrText = d.ContainsKey("OcrText") ? Convert.ToString(d["OcrText"]) : "";
                                if (!string.IsNullOrEmpty(fullPath))
                                {
                                    map[fullPath] = ocrText;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _log("[OCR] Aviso ao executar OCR local: " + ex.Message);
            }
            return map;
        }

        private void MatchAndRenameGrokDownloadsWithOcr(
            string stagingDir,
            List<string> orderedDownloads,
            List<GrokAssetSpec> specs,
            string targetAssetsDir)
        {
            _log("[Grok OCR] Inspecionando título escrito no topo de cada imagem via Windows OCR (pt-BR) para evitar troca de nomes (Regra 20)...");
            Dictionary<string, string> ocrResults = RunWindowsOcrOnFolder(stagingDir);

            HashSet<int> usedSpecIndices = new HashSet<int>();
            HashSet<string> assignedFiles = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            // Monta todos os pares (file, specIdx, score) e escolhe os melhores casamentos inequívocos primeiro
            var candidatePairs = new List<Tuple<string, int, double, string>>();
            foreach (string file in orderedDownloads)
            {
                string ocrText = ocrResults.ContainsKey(file) ? ocrResults[file] : "";
                if (string.IsNullOrWhiteSpace(ocrText)) continue;

                for (int sIdx = 0; sIdx < specs.Count; sIdx++)
                {
                    double score = EpisodeParser.ComputeTextSimilarity(ocrText, specs[sIdx].DisplayTitle);
                    candidatePairs.Add(Tuple.Create(file, sIdx, score, ocrText));
                }
            }

            foreach (var pair in candidatePairs.OrderByDescending(p => p.Item3))
            {
                if (pair.Item3 < 0.48) break;
                if (assignedFiles.Contains(pair.Item1) || usedSpecIndices.Contains(pair.Item2)) continue;

                GrokAssetSpec spec = specs[pair.Item2];
                string destPath = Path.Combine(targetAssetsDir, spec.TargetFileName);
                File.Copy(pair.Item1, destPath, true);
                assignedFiles.Add(pair.Item1);
                usedSpecIndices.Add(pair.Item2);

                _log(string.Format("[Grok OCR] '{0}' (OCR: \"{1}\") -> {2} (confiança {3:0}%)",
                    Path.GetFileName(pair.Item1), pair.Item4, spec.TargetFileName, pair.Item3 * 100.0));
            }

            // Fallback na ordem exata das miniaturas para qualquer imagem sem texto OCR legível
            List<string> remainingFiles = orderedDownloads.Where(f => !assignedFiles.Contains(f)).ToList();
            List<int> remainingSpecs = Enumerable.Range(0, specs.Count).Where(i => !usedSpecIndices.Contains(i)).ToList();

            int count = Math.Min(remainingFiles.Count, remainingSpecs.Count);
            for (int i = 0; i < count; i++)
            {
                GrokAssetSpec spec = specs[remainingSpecs[i]];
                string destPath = Path.Combine(targetAssetsDir, spec.TargetFileName);
                File.Copy(remainingFiles[i], destPath, true);
                _log(string.Format("[Grok Ordem] '{0}' -> {1} (ordem da miniatura)",
                    Path.GetFileName(remainingFiles[i]), spec.TargetFileName));
            }
        }

        public void MirrorAssetsToTempFlow(string assetsDir)
        {
            if (!Directory.Exists(assetsDir)) return;
            if (!Directory.Exists(_config.TempFlowAssetsDir))
                Directory.CreateDirectory(_config.TempFlowAssetsDir);

            foreach (string f in Directory.GetFiles(assetsDir))
            {
                string ext = Path.GetExtension(f);
                if (string.Equals(ext, ".jpg", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(ext, ".jpeg", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(ext, ".png", StringComparison.OrdinalIgnoreCase))
                {
                    string dst = Path.Combine(_config.TempFlowAssetsDir, Path.GetFileName(f));
                    File.Copy(f, dst, true);
                }
            }
        }

        public async Task GenerateVideoTakesAsync(
            EpisodeWorkItem ep,
            List<FlowTakeSpec> takesToGenerate,
            Dictionary<string, string> ingredientToResolvedName,
            CancellationToken ct)
        {
            if (takesToGenerate == null || takesToGenerate.Count == 0)
                return;

            if (!Directory.Exists(ep.TakesDir))
                Directory.CreateDirectory(ep.TakesDir);

            List<FlowTakeSpec> orderedTakes = takesToGenerate
                .OrderBy(t => t.TakeNumber)
                .ToList();

            _log(string.Format("[Grok Vídeo] Iniciando geração em vídeo (9:16 | 10s | 720p | com áudio) de {0} take(s) no Grok Imagine...",
                orderedTakes.Count));

            List<string> activeProfiles = _config.GetAvailableGrokProfiles(_log);
            int currentProfileIdx = 0;

            for (int tIdx = 0; tIdx < orderedTakes.Count; tIdx++)
            {
                ct.ThrowIfCancellationRequested();
                FlowTakeSpec take = orderedTakes[tIdx];
                string finalTakePath = Path.Combine(ep.TakesDir, string.Format("Take_{0:00}.mp4", take.TakeNumber));
                List<string> ingredientFiles = ResolveIngredientFilePathsForTake(ep, take, ingredientToResolvedName);

                bool takeDone = false;
                Exception lastErr = null;

                while (currentProfileIdx < activeProfiles.Count)
                {
                    ct.ThrowIfCancellationRequested();
                    string profile = activeProfiles[currentProfileIdx];
                    try
                    {
                        _log(string.Format("[Grok Vídeo] Gerando Take_{0:00}.mp4 ({1}/{2}) no perfil '{3}' com {4} imagem(ns) de referência...",
                            take.TakeNumber, tIdx + 1, orderedTakes.Count, profile, ingredientFiles.Count));

                        bool quotaExhausted = await TryGenerateSingleVideoTakeWithProfileAsync(
                            profile,
                            ep,
                            take,
                            ingredientFiles,
                            finalTakePath,
                            ct);

                        if (quotaExhausted)
                        {
                            _config.SetProfileStatus(profile, "LIMITE ATINGIDO");
                            _log(string.Format("[Grok Vídeo] Limite atingido no perfil '{0}'. Alternando para o próximo perfil autorizado...", profile));
                            currentProfileIdx++;
                            continue;
                        }

                        _config.SetProfileStatus(profile, "DISPONÍVEL");
                        takeDone = true;
                        break;
                    }
                    catch (OperationCanceledException)
                    {
                        throw;
                    }
                    catch (Exception ex)
                    {
                        lastErr = ex;
                        _log(string.Format("[Grok Vídeo] Aviso ao gerar Take_{0:00} no perfil '{1}': {2}. Tentando próximo perfil...",
                            take.TakeNumber, profile, ex.Message));
                        currentProfileIdx++;
                    }
                }

                if (!takeDone)
                {
                    throw new InvalidOperationException(
                        string.Format("Não foi possível concluir a geração do vídeo Take_{0:00}.mp4 no Grok Imagine em nenhum dos perfis autorizados.", take.TakeNumber) +
                        (lastErr != null ? " Último erro: " + lastErr.Message : ""));
                }
            }
        }

        private List<string> ResolveIngredientFilePathsForTake(
            EpisodeWorkItem ep,
            FlowTakeSpec take,
            Dictionary<string, string> ingredientToResolvedName)
        {
            List<string> resolvedPaths = new List<string>();
            HashSet<string> seenNames = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            List<string> diskAssets = new List<string>();
            if (Directory.Exists(ep.AssetsDir))
            {
                diskAssets = Directory.GetFiles(ep.AssetsDir)
                    .Where(f => Regex.IsMatch(Path.GetExtension(f), @"^\.(jpg|jpeg|png)$", RegexOptions.IgnoreCase) && new FileInfo(f).Length > 1024)
                    .ToList();
            }

            foreach (string rawIng in take.Ingredients)
            {
                string targetName = rawIng;
                if (ingredientToResolvedName != null)
                {
                    string mapped;
                    if (ingredientToResolvedName.TryGetValue(rawIng, out mapped) && !string.IsNullOrEmpty(mapped))
                        targetName = mapped;
                }

                string candidateTemp = Path.Combine(_config.TempFlowAssetsDir, targetName);
                string candidateRawTemp = Path.Combine(_config.TempFlowAssetsDir, rawIng);
                string candidateAssets = Path.Combine(ep.AssetsDir, targetName);

                string chosen = "";
                if (File.Exists(candidateTemp) && new FileInfo(candidateTemp).Length > 1024)
                    chosen = candidateTemp;
                else if (File.Exists(candidateRawTemp) && new FileInfo(candidateRawTemp).Length > 1024)
                    chosen = candidateRawTemp;
                else if (File.Exists(candidateAssets) && new FileInfo(candidateAssets).Length > 1024)
                    chosen = candidateAssets;
                else
                    chosen = EpisodeParser.FindMatchingDiskAssetFile(rawIng, diskAssets);

                if (!string.IsNullOrEmpty(chosen) && File.Exists(chosen) && seenNames.Add(Path.GetFileName(chosen)))
                {
                    resolvedPaths.Add(chosen);
                }
            }

            return resolvedPaths;
        }

        private static string CleanTakePromptForGrokVideo(FlowTakeSpec take)
        {
            string body = (take.RawPromptBody ?? "").Trim();
            body = Regex.Replace(body, @"^Prompt\s+de\s+V[ií]deo\s*:\s*", "", RegexOptions.IgnoreCase).Trim();
            body = Regex.Replace(body, @"(\r?\n)*---\s*$", "").Trim();
            return body;
        }

        private async Task<bool> TryGenerateSingleVideoTakeWithProfileAsync(
            string profile,
            EpisodeWorkItem ep,
            FlowTakeSpec take,
            List<string> ingredientFiles,
            string finalTakePath,
            CancellationToken ct)
        {
            string sess = await _cdp.OpenOrAttachProfileTabAsync(profile, _config.GrokUrl, "grok.com", false, ct);
            await WaitForGrokInteractiveReadyAsync(sess, ct);

            // Se a aba já estiver na tela de 'Limite de uso atingido' / 'Adicione créditos', alterna de conta imediatamente
            if (await HasQuotaExhaustedBannerAsync(sess, ct))
                return true;

            string navUrl = _config.GrokUrl.Contains("#")
                ? _config.GrokUrl
                : (_config.GrokUrl + "#fvs_" + profile.Replace(" ", "_"));
            await _cdp.SendCommandAsync("Page.navigate", new Dictionary<string, object> { { "url", navUrl } }, sess, 20000, ct);
            await _cdp.WaitForDocumentReadyAsync(sess, 30000, ct);
            await WaitForGrokInteractiveReadyAsync(sess, ct);

            if (await HasQuotaExhaustedBannerAsync(sess, ct))
                return true;

            // 1. Configurar modo Vídeo + Áudio ligado + 720p + 10s + 9:16
            await EnsureGrokVideoModeAndOptionsAsync(sess, take.DurationText, ct);

            // 2. Limpar eventuais miniaturas anexadas anteriormente e anexar os personagens + cenário deste take
            await _cdp.EvalStringAsync(sess, @"
(function(){
    Array.from(document.querySelectorAll('button[aria-label*=""Remover imagem""], button[aria-label*=""Remove image""]')).forEach(b => b.click());
    return 'OK';
})()", ct);
            await Task.Delay(350, ct);

            if (ingredientFiles != null && ingredientFiles.Count > 0)
            {
                bool attached = await _cdp.SetFileInputFilesByObjectIdAsync(
                    sess,
                    "document.querySelector('input[type=\"file\"][multiple]') || document.querySelector('input[type=\"file\"]')",
                    ingredientFiles,
                    ct);

                if (!attached)
                {
                    // Fallback via interceptação de FileChooser clicando em 'Transferir'
                    await _cdp.UploadFilesViaFileChooserAsync(
                        sess,
                        async () =>
                        {
                            Dictionary<string, object> trPt = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var b = Array.from(document.querySelectorAll('button')).find(el => {
        var al = (el.getAttribute('aria-label') || '');
        return el.getBoundingClientRect().width > 10 &&
               (al.indexOf('Transferir') >= 0 || al.indexOf('Upload') >= 0 || al.indexOf('Anexar') >= 0 || al.indexOf('Attach') >= 0);
    });
    if (!b) return null;
    var r = b.getBoundingClientRect();
    return JSON.stringify({ x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) });
})()", ct);
                            if (trPt != null)
                                await _cdp.ClickAtAsync(sess, Convert.ToInt32(trPt["x"]), Convert.ToInt32(trPt["y"]), ct);
                        },
                        ingredientFiles,
                        ct);
                }

                await Task.Delay(1800, ct);
            }

            // 3. Capturar vídeos estáticos preexistentes na tela inicial do /imagine para ignorá-los
            HashSet<string> preExistingVideoUrls = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            Dictionary<string, object> preVidsObj = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var urls = Array.from(document.querySelectorAll('video')).map(v => {
        var s = v.currentSrc || v.src || '';
        if (!s) {
            var srcEl = v.querySelector('source');
            if (srcEl) s = srcEl.src || '';
        }
        return s;
    }).filter(s => s.length > 0);
    return JSON.stringify({ urls: urls });
})()", ct);

            if (preVidsObj != null && preVidsObj.ContainsKey("urls"))
            {
                IEnumerable uList = preVidsObj["urls"] as IEnumerable;
                if (uList != null)
                {
                    foreach (object u in uList)
                    {
                        string us = Convert.ToString(u ?? "").Trim();
                        if (!string.IsNullOrEmpty(us))
                            preExistingVideoUrls.Add(us);
                    }
                }
            }

            // 4. Inserir prompt completo do take, aprimorar para o padrão Grok (varinha mágica) e enviar geração
            string takePrompt = CleanTakePromptForGrokVideo(take);
            bool inserted = await InjectPromptIntoGrokBoxAsync(sess, takePrompt, ct);
            if (!inserted)
                throw new InvalidOperationException("Campo de texto do Grok Imagine não encontrado no modo Vídeo.");

            await Task.Delay(750, ct);
            await EnhanceGrokVideoPromptAsync(sess, take.TakeNumber, takePrompt, ct);
            await Task.Delay(400, ct);
            await SubmitGrokPromptAsync(sess, ct);

            // 5. Aguardar geração completa do vídeo .mp4
            DateTime deadline = DateTime.UtcNow.AddMinutes(7);
            int stableReadyPolls = 0;
            string generatedVideoUrl = "";

            while (DateTime.UtcNow < deadline)
            {
                ct.ThrowIfCancellationRequested();
                await Task.Delay(4500, ct);

                if (await HasQuotaExhaustedBannerAsync(sess, ct))
                    return true;

                Dictionary<string, object> st = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var body = (document.body && document.body.innerText) ? document.body.innerText : '';
    var vids = Array.from(document.querySelectorAll('video')).map(v => {
        var s = v.currentSrc || v.src || '';
        if (!s) {
            var srcEl = v.querySelector('source');
            if (srcEl) s = srcEl.src || '';
        }
        var r = v.getBoundingClientRect();
        return {
            src: s,
            w: Math.round(r.width),
            h: Math.round(r.height),
            x: Math.round(r.left + r.width/2),
            y: Math.round(r.top + r.height/2),
            ready: v.readyState || 0
        };
    }).filter(v => v.w >= 110 && v.h >= 140 &&
                   v.src.indexOf('/v1/grok-web/') < 0 &&
                   v.src.indexOf('/v1/website/') < 0);

    var spinners = Array.from(document.querySelectorAll('[role=""progressbar""], .animate-spin, svg.animate-spin')).filter(el => {
        var r = el.getBoundingClientRect();
        return r.width > 4 && r.height > 4;
    }).length;

    var hasPct = /\b\d{1,2}%\b/.test(body);
    var genText = hasPct || /\b(Generating|Imaginando|Criando|Gerando v[ií]deo|Gerando)\b/i.test(body);
    var dlBtn = Array.from(document.querySelectorAll('button[aria-label=""Baixar""], button[aria-label=""Download""]'))
        .some(b => b.getBoundingClientRect().width > 10);

    return JSON.stringify({ vids: vids, spinners: spinners, genText: genText, hasDlBtn: dlBtn });
})()", ct);

                if (st == null) continue;

                int spinners = Convert.ToInt32(st["spinners"]);
                bool genText = Convert.ToBoolean(st["genText"]);
                string candidateUrl = "";

                IEnumerable vidArr = st.ContainsKey("vids") ? st["vids"] as IEnumerable : null;
                if (vidArr != null)
                {
                    foreach (object item in vidArr)
                    {
                        Dictionary<string, object> vd = item as Dictionary<string, object>;
                        if (vd == null) continue;
                        string vSrc = vd.ContainsKey("src") ? Convert.ToString(vd["src"] ?? "").Trim() : "";
                        if (!string.IsNullOrEmpty(vSrc) && !preExistingVideoUrls.Contains(vSrc))
                        {
                            candidateUrl = vSrc;
                        }
                    }
                }

                if (!string.IsNullOrEmpty(candidateUrl) && spinners == 0 && !genText)
                {
                    generatedVideoUrl = candidateUrl;
                    stableReadyPolls++;
                    if (stableReadyPolls >= 2)
                        break;
                }
                else
                {
                    stableReadyPolls = 0;
                }
            }

            if (string.IsNullOrEmpty(generatedVideoUrl))
            {
                throw new TimeoutException(string.Format("Timeout aguardando geração do vídeo Take_{0:00} no Grok Imagine.", take.TakeNumber));
            }

            // 6. Baixar o vídeo gerado via botão 'Baixar' (↓) ou download direto autenticado do stream .mp4
            string stagingDir = Path.Combine(ep.TakesDir, "_grok_vid_" + DateTime.Now.ToString("HHmmss"));
            Directory.CreateDirectory(stagingDir);
            await _cdp.SetDownloadBehaviorAsync(stagingDir, ct);

            Dictionary<string, object> dlPt = await FindGrokDownloadButtonPointAsync(sess, ct);
            if (dlPt == null)
            {
                // Clica no card de vídeo recém-gerado para abrir o visualizador detalhado onde fica o botão 'Baixar'
                string b64VidUrl = Convert.ToBase64String(Encoding.UTF8.GetBytes(generatedVideoUrl));
                Dictionary<string, object> vidCardPt = await _cdp.EvalJsonAsync(sess, string.Format(@"
(function(){{
    var want = atob('{0}');
    var v = Array.from(document.querySelectorAll('video')).find(el => {{
        var s = el.currentSrc || el.src || '';
        if (!s) {{ var se = el.querySelector('source'); if (se) s = se.src || ''; }}
        return s === want || (want.length > 20 && s.indexOf(want.substring(0, 20)) >= 0);
    }});
    if (!v) return null;
    v.scrollIntoView({{ block: 'center' }});
    var r = v.getBoundingClientRect();
    return JSON.stringify({{ x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) }});
}})()", b64VidUrl), ct);

                if (vidCardPt != null)
                {
                    await _cdp.ClickAtAsync(sess, Convert.ToInt32(vidCardPt["x"]), Convert.ToInt32(vidCardPt["y"]), ct);
                    await Task.Delay(1400, ct);
                    dlPt = await FindGrokDownloadButtonPointAsync(sess, ct);
                }
            }

            HashSet<string> beforeFiles = new HashSet<string>(Directory.GetFiles(stagingDir), StringComparer.OrdinalIgnoreCase);
            string downloadedFile = "";

            if (dlPt != null)
            {
                await _cdp.ClickAtAsync(sess, Convert.ToInt32(dlPt["x"]), Convert.ToInt32(dlPt["y"]), ct);
                downloadedFile = await _cdp.WaitForSingleDownloadAsync(stagingDir, beforeFiles, 80 * 1024, 35000, ct);
            }

            // Fallback: se o botão Baixar não disparou arquivo .mp4, baixa diretamente via fetch autenticado do <video src>
            if (string.IsNullOrEmpty(downloadedFile) ||
                (!downloadedFile.EndsWith(".mp4", StringComparison.OrdinalIgnoreCase) && !downloadedFile.EndsWith(".mov", StringComparison.OrdinalIgnoreCase)))
            {
                beforeFiles = new HashSet<string>(Directory.GetFiles(stagingDir), StringComparer.OrdinalIgnoreCase);
                string b64Url = Convert.ToBase64String(Encoding.UTF8.GetBytes(generatedVideoUrl));
                string targetFn = string.Format("Take_{0:00}.mp4", take.TakeNumber);

                await _cdp.EvalStringAsync(sess, string.Format(@"
(function(){{
    var u = atob('{0}');
    fetch(u, {{ credentials: 'include' }})
        .then(r => r.blob())
        .then(b => {{
            var burl = URL.createObjectURL(b);
            var a = document.createElement('a');
            a.href = burl;
            a.download = '{1}';
            document.body.appendChild(a);
            a.click();
            setTimeout(() => {{ a.remove(); URL.revokeObjectURL(burl); }}, 4000);
        }});
    return 'FETCH_TRIGGERED';
}})()", b64Url, targetFn), ct);

                downloadedFile = await _cdp.WaitForSingleDownloadAsync(stagingDir, beforeFiles, 80 * 1024, 45000, ct);
            }

            await _cdp.ResetDownloadBehaviorToDefaultAsync();
            if (string.IsNullOrEmpty(downloadedFile))
            {
                try { Directory.Delete(stagingDir, true); } catch { }
                throw new IOException(string.Format("Timeout aguardando download do vídeo Take_{0:00}.mp4 gerado no Grok Imagine.", take.TakeNumber));
            }

            if (File.Exists(finalTakePath))
                File.Delete(finalTakePath);
            File.Move(downloadedFile, finalTakePath);

            try { Directory.Delete(stagingDir, true); } catch { }

            _log(string.Format("[Grok Vídeo] Salvo Take_{0:00}.mp4 ({1:0.0} MB).",
                take.TakeNumber, new FileInfo(finalTakePath).Length / (1024.0 * 1024.0)));

            return false;
        }

        private async Task<Dictionary<string, object>> FindGrokDownloadButtonPointAsync(string sess, CancellationToken ct)
        {
            return await _cdp.EvalJsonAsync(sess, @"
(function(){
    var candidates = Array.from(document.querySelectorAll('button[aria-label=""Baixar""], button[aria-label=""Download""], a[download]'))
        .filter(b => {
            var txt = (b.innerText || '').trim().toLowerCase();
            if (txt.includes('tudo') || txt.includes('all') || txt.includes('segment')) return false;
            var r = b.getBoundingClientRect();
            return r.width > 10 && r.height > 10;
        });
    if (candidates.length === 0) return null;
    var b = candidates[candidates.length - 1];
    var r = b.getBoundingClientRect();
    return JSON.stringify({ x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) });
})()", ct);
        }

        private async Task EnsureGrokVideoModeAndOptionsAsync(string sess, string wantedDuration, CancellationToken ct)
        {
            // 1. Ativar modo 'Vídeo' (e garantir que não esteja preso em 'Imagem' ou 'Agente')
            Dictionary<string, object> vidBtn = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var els = Array.from(document.querySelectorAll('button, [role=""button""], [role=""radio""], [role=""tab""]'));
    var btn = els.find(el => {
        var t = (el.innerText || '').trim();
        var al = (el.getAttribute('aria-label') || '').trim();
        var r = el.getBoundingClientRect();
        return r.width > 12 && r.height > 12 &&
               (al === 'Vídeo' || al === 'Video' || t === 'Vídeo' || t === 'Video');
    });
    if (!btn) return null;
    var active = btn.getAttribute('aria-pressed') === 'true' ||
                 btn.getAttribute('aria-checked') === 'true' ||
                 btn.getAttribute('aria-selected') === 'true' ||
                 btn.getAttribute('data-state') === 'active' ||
                 btn.getAttribute('data-active') === 'true';
    var r = btn.getBoundingClientRect();
    return JSON.stringify({ active: active, x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) });
})()", ct);

            if (vidBtn != null && !Convert.ToBoolean(vidBtn["active"]))
            {
                await _cdp.ClickAtAsync(sess, Convert.ToInt32(vidBtn["x"]), Convert.ToInt32(vidBtn["y"]), ct);
                await Task.Delay(800, ct);
            }

            // 2. Garantir 'Áudio do vídeo' ativado
            Dictionary<string, object> audBtn = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var b = Array.from(document.querySelectorAll('button')).find(el => {
        var al = (el.getAttribute('aria-label') || '');
        return el.getBoundingClientRect().width > 10 && (al.indexOf('Áudio do vídeo') >= 0 || al.indexOf('Video audio') >= 0);
    });
    if (!b) return null;
    var state = (b.getAttribute('aria-pressed') || b.getAttribute('aria-checked') || b.getAttribute('data-state') || '');
    var isOn = (state === 'true' || state === 'active' || state === 'checked');
    var r = b.getBoundingClientRect();
    return JSON.stringify({ isOn: isOn, state: state, x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) });
})()", ct);

            if (audBtn != null && Convert.ToString(audBtn["state"] ?? "") == "false")
            {
                await _cdp.ClickAtAsync(sess, Convert.ToInt32(audBtn["x"]), Convert.ToInt32(audBtn["y"]), ct);
                await Task.Delay(350, ct);
            }

            // 3. Garantir Resolução '720p', Duração ('10s') e Proporção ('9:16')
            await EnsureGrokDropdownOptionAsync(sess, "Resolução do vídeo", "Video resolution", "720p", ct);
            string dur = string.IsNullOrWhiteSpace(wantedDuration) ? "10s" : wantedDuration.Trim();
            if (!dur.EndsWith("s", StringComparison.OrdinalIgnoreCase)) dur = "10s";
            await EnsureGrokDropdownOptionAsync(sess, "Duração do vídeo", "Video duration", dur, ct);
            await EnsureGrokDropdownOptionAsync(sess, "Aspecto de proporção", "Aspect ratio", "9:16", ct);
        }

        private async Task EnsureGrokDropdownOptionAsync(
            string sess,
            string ariaLabelPt,
            string ariaLabelEn,
            string wantedValue,
            CancellationToken ct)
        {
            bool isRatio = string.Equals(wantedValue, "9:16", StringComparison.OrdinalIgnoreCase);
            Dictionary<string, object> trigger = await _cdp.EvalJsonAsync(sess, string.Format(@"
(function(){{
    var isRatio = {2};
    var btns = Array.from(document.querySelectorAll('button')).filter(el => el.getBoundingClientRect().width > 10);
    var b = btns.find(el => {{
        var al = (el.getAttribute('aria-label') || '');
        return al.indexOf('{0}') >= 0 || al.indexOf('{1}') >= 0 ||
               (isRatio && (al.toLowerCase().indexOf('propor') >= 0 || al.toLowerCase().indexOf('ratio') >= 0));
    }});
    if (!b && isRatio) {{
        b = btns.find(el => /^(1:1|16:9|9:16|3:2|2:3|4:3|3:4)$/.test((el.innerText || '').trim()));
    }}
    if (!b) return null;
    var txt = (b.innerText || '').trim();
    var r = b.getBoundingClientRect();
    return JSON.stringify({{ current: txt, x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) }});
}})()", ariaLabelPt, ariaLabelEn, isRatio ? "true" : "false"), ct);

            if (trigger == null) return;
            string current = Convert.ToString(trigger["current"] ?? "");
            if (current.IndexOf(wantedValue, StringComparison.OrdinalIgnoreCase) >= 0)
                return;

            await _cdp.ClickAtAsync(sess, Convert.ToInt32(trigger["x"]), Convert.ToInt32(trigger["y"]), ct);
            await Task.Delay(550, ct);

            Dictionary<string, object> optPt = await _cdp.EvalJsonAsync(sess, string.Format(@"
(function(){{
    var items = Array.from(document.querySelectorAll('[role=""menuitem""], [role=""option""], [role=""menuitemradio""], [data-radix-popper-content-wrapper] button, [data-radix-popper-content-wrapper] div'))
        .filter(el => el.getBoundingClientRect().width > 10 && el.children.length <= 4);
    var m = items.find(el => (el.innerText || '').trim().toLowerCase() === '{0}'.toLowerCase()) ||
            items.find(el => (el.innerText || '').toLowerCase().indexOf('{0}'.toLowerCase()) >= 0);
    if (!m) return null;
    var r = m.getBoundingClientRect();
    return JSON.stringify({{ x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) }});
}})()", wantedValue), ct);

            if (optPt != null)
            {
                await _cdp.ClickAtAsync(sess, Convert.ToInt32(optPt["x"]), Convert.ToInt32(optPt["y"]), ct);
                await Task.Delay(450, ct);
            }
            else
            {
                await _cdp.PressEscapeAsync(sess, ct);
            }
        }

        public async Task CheckAllGrokProfilesStatusAsync(CancellationToken ct)
        {
            await _cdp.EnsureConnectedAsync(ct);
            foreach (string profile in _config.GrokProfiles.ToList())
            {
                ct.ThrowIfCancellationRequested();
                try
                {
                    string sess = await _cdp.OpenOrAttachProfileTabAsync(profile, _config.GrokUrl, "grok.com", false, ct);
                    await WaitForGrokInteractiveReadyAsync(sess, ct);
                    bool exhausted = await HasQuotaExhaustedBannerAsync(sess, ct);

                    string acctName = await _cdp.EvalStringAsync(sess, @"
(function(){
    var b = Array.from(document.querySelectorAll('button')).find(el => {
        var al = (el.getAttribute('aria-label') || '');
        return al.indexOf('Menu da conta') >= 0 || al.indexOf('Account') >= 0;
    });
    if (!b) return '';
    var al = b.getAttribute('aria-label') || '';
    return al.replace(/^Menu da conta,\s*/i, '').replace(/^Account menu,\s*/i, '').trim();
})()", ct);

                    string statusText = exhausted
                        ? ("LIMITE ATINGIDO" + (!string.IsNullOrEmpty(acctName) ? " (" + acctName + ")" : ""))
                        : ("DISPONÍVEL" + (!string.IsNullOrEmpty(acctName) ? " (" + acctName + ")" : ""));

                    _config.SetProfileStatus(profile, statusText);
                    _log(string.Format("[Contas Grok] {0} -> {1}", profile, statusText));
                }
                catch (Exception ex)
                {
                    _config.SetProfileStatus(profile, "ERRO AO VERIFICAR");
                    _log(string.Format("[Contas Grok] Aviso ao verificar '{0}': {1}", profile, ex.Message));
                }
            }
        }

        public async Task RegenerateSingleAssetAsync(
            EpisodeWorkItem ep,
            string targetFileName,
            string customPromptLine,
            CancellationToken ct)
        {
            if (ep == null || string.IsNullOrWhiteSpace(targetFileName))
                throw new ArgumentException("Episódio ou nome do arquivo de asset inválido.");

            if (!Directory.Exists(ep.AssetsDir))
                Directory.CreateDirectory(ep.AssetsDir);

            await _cdp.EnsureConnectedAsync(ct);

            GrokAssetSpec spec = ep.GrokSpecs.FirstOrDefault(s =>
                string.Equals(s.TargetFileName, targetFileName, StringComparison.OrdinalIgnoreCase));

            string displayTitle = spec != null && !string.IsNullOrEmpty(spec.DisplayTitle)
                ? spec.DisplayTitle
                : EpisodeParser.CleanAssetStem(targetFileName);

            string rawLine = !string.IsNullOrWhiteSpace(customPromptLine)
                ? customPromptLine.Trim()
                : (spec != null && !string.IsNullOrWhiteSpace(spec.RawPromptLine)
                    ? spec.RawPromptLine.Trim()
                    : string.Format("- {0}: Animação 3D estilizada semi-realista (CGI), proporções 9:16 verticais, nome \"{0}\" escrito no topo.", displayTitle));

            GrokAssetSpec singleSpec = new GrokAssetSpec
            {
                OrderIndex = 1,
                IsScenario = EpisodeParser.IsScenarioAssetName(targetFileName),
                LabelPrefix = EpisodeParser.IsScenarioAssetName(targetFileName) ? "Cenário" : "Personagem",
                DisplayTitle = displayTitle,
                TargetFileName = targetFileName,
                RawPromptLine = rawLine
            };

            string fullPrompt = "Faça esta única imagem isolada e em 9:16, nome em cima da cabeça:\n\n" + rawLine;
            string destPath = Path.Combine(ep.AssetsDir, targetFileName);
            if (File.Exists(destPath))
            {
                string backupDir = Path.Combine(ep.AssetsDir, "_old_assets");
                Directory.CreateDirectory(backupDir);
                string bakPath = Path.Combine(backupDir, Path.GetFileNameWithoutExtension(targetFileName) + "_" + DateTime.Now.ToString("HHmmss") + Path.GetExtension(targetFileName));
                File.Copy(destPath, bakPath, true);
                File.Delete(destPath);
            }

            // Se for um novo figurino de um personagem base que já existe em disco, anexa o personagem base como referência!
            string baseCharPath = EpisodeParser.FindExistingBaseCharacterPathForVariantSpec(ep, singleSpec);
            if (!singleSpec.IsScenario && !string.IsNullOrEmpty(baseCharPath) && File.Exists(baseCharPath))
            {
                _log(string.Format("[Grok Asset Individual] Conferido personagem base '{0}' -> anexando no Grok para regerar o figurino '{1}' mantendo o mesmo rosto...",
                    Path.GetFileName(baseCharPath), targetFileName));
                await GenerateVariantSpecWithBaseCharacterAsync(ep, singleSpec, baseCharPath, ct);
                MirrorAssetsToTempFlow(ep.AssetsDir);
                EpisodeParser.RefreshDiskCounters(ep);
                _log(string.Format("[Grok Asset Individual] '{0}' regerado com sucesso e espelhado para Temp\\flow_assets!", targetFileName));
                return;
            }

            List<GrokAssetSpec> oneList = new List<GrokAssetSpec> { singleSpec };
            Exception lastErr = null;
            List<string> activeProfiles = _config.GetAvailableGrokProfiles(_log);
            foreach (string profile in activeProfiles)
            {
                ct.ThrowIfCancellationRequested();
                try
                {
                    _log(string.Format("[Grok Asset Individual] Regerando '{0}' no perfil '{1}'...", targetFileName, profile));
                    bool exhausted = await TryGenerateAndDownloadWithProfileAsync(profile, fullPrompt, ep, oneList, ct);
                    if (exhausted)
                    {
                        _config.SetProfileStatus(profile, "LIMITE ATINGIDO");
                        _log(string.Format("[Grok Asset Individual] Limite atingido em '{0}'. Alternando perfil...", profile));
                        continue;
                    }

                    _config.SetProfileStatus(profile, "DISPONÍVEL");
                    MirrorAssetsToTempFlow(ep.AssetsDir);
                    EpisodeParser.RefreshDiskCounters(ep);
                    _log(string.Format("[Grok Asset Individual] '{0}' regerado com sucesso e espelhado para Temp\\flow_assets!", targetFileName));
                    return;
                }
                catch (OperationCanceledException)
                {
                    throw;
                }
                catch (Exception ex)
                {
                    lastErr = ex;
                    _log(string.Format("[Grok Asset Individual] Aviso no perfil '{0}': {1}. Tentando próximo...", profile, ex.Message));
                }
            }

            throw new InvalidOperationException(
                string.Format("Não foi possível regerar o asset '{0}' em nenhum perfil autorizado.", targetFileName) +
                (lastErr != null ? " Último erro: " + lastErr.Message : ""));
        }

        public async Task<string> GenerateCharacterOutfitVariantAsync(
            EpisodeWorkItem ep,
            string baseCharFileName,
            string occasionLabel,
            string outfitDescription,
            bool copyToAllEpisodes,
            CancellationToken ct)
        {
            if (ep == null || string.IsNullOrWhiteSpace(baseCharFileName) || string.IsNullOrWhiteSpace(occasionLabel))
                throw new ArgumentException("Selecione o personagem base e informe a ocasião da roupa.");

            if (!Directory.Exists(ep.AssetsDir))
                Directory.CreateDirectory(ep.AssetsDir);

            await _cdp.EnsureConnectedAsync(ct);

            string cleanBaseName = EpisodeParser.GetBaseCharacterFileName(baseCharFileName);
            string baseImagePath = Path.Combine(ep.AssetsDir, cleanBaseName);
            if (!File.Exists(baseImagePath))
            {
                string matched = EpisodeParser.FindMatchingDiskAssetFile(cleanBaseName, Directory.GetFiles(ep.AssetsDir));
                if (!string.IsNullOrEmpty(matched))
                    baseImagePath = matched;
            }

            if (!File.Exists(baseImagePath))
                throw new FileNotFoundException(string.Format("Imagem base do personagem '{0}' não encontrada em '{1}'.", cleanBaseName, ep.AssetsDir));

            string variantFileName = EpisodeParser.BuildOutfitVariantFileName(cleanBaseName, occasionLabel);
            string variantFullPath = Path.Combine(ep.AssetsDir, variantFileName);

            GrokAssetSpec baseSpec = ep.GrokSpecs.FirstOrDefault(s =>
                string.Equals(s.TargetFileName, cleanBaseName, StringComparison.OrdinalIgnoreCase));
            string charTitle = (baseSpec != null && !string.IsNullOrEmpty(baseSpec.DisplayTitle))
                ? baseSpec.DisplayTitle
                : EpisodeParser.CleanAssetStem(cleanBaseName);

            string resolvedOutfitDesc = string.IsNullOrWhiteSpace(outfitDescription)
                ? EpisodeParser.GetStandardWardrobePresetDescription(ep, cleanBaseName, occasionLabel)
                : outfitDescription.Trim();

            string prompt = string.Format(
                "Crie uma imagem 9:16 vertical em animação 3D estilizada semi-realista (CGI) mantendo EXATAMENTE o mesmo personagem da imagem de referência anexada (mesmo rosto, mesma idade, mesma fisionomia, mesmo cabelo/penteado, mesma barba/expressão, mesmo corpo inteiro dos pés à cabeça, em pé, de frente, sobre fundo branco neutro puro #FFFFFF, com o texto \"{0}\" escrito no topo acima da cabeça), porém trocando COMPLETAMENTE a roupa anterior dele para '{1}' seguindo fielmente o contexto da história e da cena: {2} IMPORTANTE: Remova qualquer objeto segurado nas mãos na imagem original (sem canudo de diploma, sem pastas, sem caixas, deixando as duas mãos livres e vazias ao lado do corpo), remova becas ou aventais da roupa anterior (exceto se pedidos na nova roupa) e NÃO adicione óculos nem acessórios faciais que não existam no rosto original.",
                charTitle,
                EpisodeParser.FormatOutfitDisplayLabel(occasionLabel.Trim()),
                resolvedOutfitDesc);

            Exception lastErr = null;
            List<string> activeProfiles = _config.GetAvailableGrokProfiles(_log);
            foreach (string profile in activeProfiles)
            {
                ct.ThrowIfCancellationRequested();
                try
                {
                    _log(string.Format("[Grok Figurino] Gerando roupa '{0}' para '{1}' (mantendo o mesmo rosto via imagem de referência) no perfil '{2}'...",
                        occasionLabel, cleanBaseName, profile));

                    string sess = await _cdp.OpenOrAttachProfileTabAsync(profile, _config.GrokUrl, "grok.com", false, ct);
                    await WaitForGrokInteractiveReadyAsync(sess, ct);

                    if (await HasQuotaExhaustedBannerAsync(sess, ct))
                    {
                        _config.SetProfileStatus(profile, "LIMITE ATINGIDO");
                        continue;
                    }

                    string navUrl = _config.GrokUrl.Contains("#")
                        ? _config.GrokUrl
                        : (_config.GrokUrl + "#fvs_" + profile.Replace(" ", "_"));
                    await _cdp.SendCommandAsync("Page.navigate", new Dictionary<string, object> { { "url", navUrl } }, sess, 20000, ct);
                    await _cdp.WaitForDocumentReadyAsync(sess, 30000, ct);
                    await WaitForGrokInteractiveReadyAsync(sess, ct);

                    if (await HasQuotaExhaustedBannerAsync(sess, ct))
                    {
                        _config.SetProfileStatus(profile, "LIMITE ATINGIDO");
                        continue;
                    }

                    // Selecionar modo 'Imagem' e proporção '9:16' ANTES de anexar a imagem de referência
                    await EnsureGrokImageModeAnd9x16Async(sess, ct);

                    List<string> refFiles = new List<string> { baseImagePath };
                    bool attached = await _cdp.SetFileInputFilesByObjectIdAsync(
                        sess,
                        "document.querySelector('input[type=\"file\"][multiple]') || document.querySelector('input[type=\"file\"]')",
                        refFiles,
                        ct);

                    if (!attached)
                    {
                        await _cdp.UploadFilesViaFileChooserAsync(
                            sess,
                            async () =>
                            {
                                Dictionary<string, object> trPt = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var b = Array.from(document.querySelectorAll('button')).find(el => {
        var al = (el.getAttribute('aria-label') || '');
        return el.getBoundingClientRect().width > 10 &&
               (al.indexOf('Transferir') >= 0 || al.indexOf('Upload') >= 0 || al.indexOf('Anexar') >= 0 || al.indexOf('Attach') >= 0);
    });
    if (!b) return null;
    var r = b.getBoundingClientRect();
    return JSON.stringify({ x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) });
})()", ct);
                                if (trPt != null)
                                    await _cdp.ClickAtAsync(sess, Convert.ToInt32(trPt["x"]), Convert.ToInt32(trPt["y"]), ct);
                            },
                            refFiles,
                            ct);
                    }
                    await Task.Delay(2200, ct);

                    await _cdp.EvalStringAsync(sess, @"
(function(){
    window.__fvsBaselineOutfitImgs = Array.from(document.querySelectorAll('img'))
        .map(i => i.currentSrc || i.src || '')
        .filter(Boolean);
    return 'OK';
})()", ct);

                    int baselineImgs = await CountThumbnailsOrGeneratedImagesAsync(sess, ct);
                    bool inserted = await InjectPromptIntoGrokBoxAsync(sess, prompt, ct);
                    if (!inserted)
                        throw new InvalidOperationException("Caixa de prompt não encontrada no Grok Imagine.");

                    await Task.Delay(600, ct);
                    await SubmitGrokPromptAsync(sess, ct);

                    DateTime deadline = DateTime.UtcNow.AddMinutes(4);
                    int stable = 0;
                    while (DateTime.UtcNow < deadline)
                    {
                        ct.ThrowIfCancellationRequested();
                        await Task.Delay(3000, ct);

                        if (await HasQuotaExhaustedBannerAsync(sess, ct))
                        {
                            _config.SetProfileStatus(profile, "LIMITE ATINGIDO");
                            throw new InvalidOperationException("QUOTA_EXHAUSTED");
                        }

                        Dictionary<string, object> st = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var baseList = window.__fvsBaselineOutfitImgs || [];
    var candImgs = Array.from(document.querySelectorAll('img')).filter(img => {
        var s = (img.currentSrc || img.src || '');
        var r = img.getBoundingClientRect();
        return r.width >= 90 && r.height >= 120 && img.complete && img.naturalWidth >= 200 &&
               (s.indexOf('grok') >= 0 || s.indexOf('blob:') >= 0 || s.indexOf('assets') >= 0 || s.indexOf('imagine') >= 0);
    });
    var imgs = candImgs.length;
    var newImgs = candImgs.filter(img => baseList.indexOf(img.currentSrc || img.src || '') < 0).length;
    var spinners = Array.from(document.querySelectorAll('[role=""progressbar""], .animate-spin, svg.animate-spin')).filter(el => {
        var r = el.getBoundingClientRect();
        return r.width > 4 && r.height > 4;
    }).length;
    return JSON.stringify({ imgs: imgs, newImgs: newImgs, spinners: spinners });
})()", ct);

                        if (st == null) continue;
                        int imgs = Convert.ToInt32(st["imgs"]);
                        int newImgs = Convert.ToInt32(st["newImgs"]);
                        int spinners = Convert.ToInt32(st["spinners"]);

                        if ((newImgs > 0 || imgs > baselineImgs) && spinners == 0)
                        {
                            stable++;
                            if (stable >= 2) break;
                        }
                        else
                        {
                            stable = 0;
                        }
                    }

                    string stagingDir = Path.Combine(ep.AssetsDir, "_grok_outfit_" + DateTime.Now.ToString("HHmmss"));
                    Directory.CreateDirectory(stagingDir);
                    await _cdp.SetDownloadBehaviorAsync(stagingDir, ct);

                    Dictionary<string, object> dlPt = await FindGrokDownloadButtonPointAsync(sess, ct);
                    if (dlPt == null)
                    {
                        await EnsureThumbnailViewerOpenAsync(sess, 1, ct);
                        dlPt = await FindGrokDownloadButtonPointAsync(sess, ct);
                    }

                    if (dlPt == null)
                    {
                        try { Directory.Delete(stagingDir, true); } catch { }
                        throw new InvalidOperationException("Botão 'Baixar' não encontrado após gerar a nova roupa no Grok.");
                    }

                    HashSet<string> beforeFiles = new HashSet<string>(Directory.GetFiles(stagingDir), StringComparer.OrdinalIgnoreCase);
                    await _cdp.ClickAtAsync(sess, Convert.ToInt32(dlPt["x"]), Convert.ToInt32(dlPt["y"]), ct);
                    string savedFile = await _cdp.WaitForSingleDownloadAsync(stagingDir, beforeFiles, 30 * 1024, 35000, ct);
                    await _cdp.ResetDownloadBehaviorToDefaultAsync();

                    if (string.IsNullOrEmpty(savedFile))
                    {
                        try { Directory.Delete(stagingDir, true); } catch { }
                        throw new IOException("Timeout aguardando download da imagem da nova roupa no Grok.");
                    }

                    File.Copy(savedFile, variantFullPath, true);
                    try { Directory.Delete(stagingDir, true); } catch { }

                    if (copyToAllEpisodes && !string.IsNullOrEmpty(ep.StoryRootPath) && Directory.Exists(ep.StoryRootPath))
                    {
                        foreach (string sub in Directory.GetDirectories(ep.StoryRootPath))
                        {
                            if (Regex.IsMatch(Path.GetFileName(sub), @"^EP\.?\s*\d+$", RegexOptions.IgnoreCase))
                            {
                                string subAssets = Path.Combine(sub, "assets");
                                if (!Directory.Exists(subAssets)) Directory.CreateDirectory(subAssets);
                                string dstSub = Path.Combine(subAssets, variantFileName);
                                if (!string.Equals(dstSub, variantFullPath, StringComparison.OrdinalIgnoreCase))
                                {
                                    File.Copy(variantFullPath, dstSub, true);
                                }
                            }
                        }
                    }

                    _config.SetProfileStatus(profile, "DISPONÍVEL");
                    MirrorAssetsToTempFlow(ep.AssetsDir);
                    EpisodeParser.RefreshDiskCounters(ep);
                    _log(string.Format("[Grok Figurino] Nova roupa salva com sucesso: '{0}' e espelhada para Temp\\flow_assets!", variantFileName));
                    return variantFileName;
                }
                catch (OperationCanceledException)
                {
                    throw;
                }
                catch (Exception ex)
                {
                    lastErr = ex;
                    if (ex.Message == "QUOTA_EXHAUSTED")
                    {
                        _log(string.Format("[Grok Figurino] Limite atingido no perfil '{0}'. Alternando para o próximo perfil...", profile));
                        continue;
                    }
                    _log(string.Format("[Grok Figurino] Aviso no perfil '{0}': {1}. Tentando próximo perfil...", profile, ex.Message));
                }
            }

            throw new InvalidOperationException(
                "Não foi possível gerar a variante de roupa em nenhum dos perfis autorizados do Grok." +
                (lastErr != null ? " Último erro: " + lastErr.Message : ""));
        }

        public async Task<int> EnsureAutoDetectedCharacterOutfitsAsync(EpisodeWorkItem ep, CancellationToken ct)
        {
            if (ep == null || string.IsNullOrEmpty(ep.AssetsDir))
                return 0;

            List<CharacterWardrobeSpec> requiredSpecs = EpisodeParser.DetectRequiredCharacterOutfitsFromText(ep);
            if (requiredSpecs.Count == 0)
            {
                _log("[Grok Figurino Automático] O texto dos takes usa apenas a Roupa Padrão original dos personagens. Nenhuma roupa extra necessária.");
                return 0;
            }

            List<CharacterWardrobeSpec> missingSpecs = new List<CharacterWardrobeSpec>();
            foreach (CharacterWardrobeSpec req in requiredSpecs)
            {
                // Sincroniza se já existir em outro episódio da história
                EpisodeParser.GetCharacterOutfitVariantsOnDisk(ep, req.BaseCharacterFileName);

                string fullVarPath = Path.Combine(ep.AssetsDir, req.VariantFileName);
                bool existsOnDisk = File.Exists(fullVarPath) && new FileInfo(fullVarPath).Length > 10 * 1024;
                if (existsOnDisk)
                {
                    _log(string.Format("[Grok Figurino Automático] ✔ {0} ({1}) já pronta em disco -> {2}",
                        req.DisplayLabel, req.CharacterDisplayName, req.VariantFileName));
                    continue;
                }

                string baseCharPath = Path.Combine(ep.AssetsDir, req.BaseCharacterFileName);
                if (!File.Exists(baseCharPath) || new FileInfo(baseCharPath).Length <= 10 * 1024)
                {
                    _log(string.Format("[Grok Figurino Automático] Aviso: Personagem base '{0}' ainda não existe em assets\\; pulando geração de {1}.",
                        req.BaseCharacterFileName, req.DisplayLabel));
                    continue;
                }

                missingSpecs.Add(req);
            }

            if (missingSpecs.Count == 0)
            {
                _log(string.Format("[Grok Figurino Automático] Todas as {0} opções de roupa exigidas pelo texto já estão prontas!", requiredSpecs.Count));
                return 0;
            }

            _log(string.Format("[Grok Figurino Automático] Detectadas {0} opções de roupas necessárias de acordo com o texto ({1}). Gerando automaticamente no Grok mantendo o mesmo rosto...",
                missingSpecs.Count,
                string.Join(", ", missingSpecs.Select(m => m.CharacterDisplayName + ": " + m.DisplayLabel))));

            int generatedCount = 0;
            foreach (CharacterWardrobeSpec req in missingSpecs)
            {
                ct.ThrowIfCancellationRequested();
                _log(string.Format("[Grok Figurino Automático] Gerando {0} para '{1}' ({2})...",
                    req.DisplayLabel, req.CharacterDisplayName, req.ReasonFromText));

                await GenerateCharacterOutfitVariantAsync(
                    ep,
                    req.BaseCharacterFileName,
                    req.CategoryKey,
                    req.OutfitPromptDescription,
                    true,
                    ct);
                generatedCount++;
            }

            MirrorAssetsToTempFlow(ep.AssetsDir);
            EpisodeParser.RefreshDiskCounters(ep);
            _log(string.Format("[Grok Figurino Automático] Concluído! {0} novas opções de roupas geradas de acordo com o texto.", generatedCount));
            return generatedCount;
        }

        public async Task<int> EnsureOutfitsForTakesAsync(
            EpisodeWorkItem ep,
            List<int> targetTakeNumbers,
            CancellationToken ct)
        {
            if (ep == null || string.IsNullOrEmpty(ep.AssetsDir) || ep.FlowTakes == null)
                return 0;

            int totalGenerated = 0;

            // 1. Se for execução do episódio inteiro (sem filtro de take), garante todas as roupas padrão detectadas pelo texto da história
            if (targetTakeNumbers == null || targetTakeNumbers.Count == 0)
            {
                totalGenerated += await EnsureAutoDetectedCharacterOutfitsAsync(ep, ct);
            }

            // 2. Verifica especificamente os Takes que vão ser gerados/regerados (tanto no modo Automático pelo texto quanto escolhidos manualmente pelo usuário)
            HashSet<int> filterSet = (targetTakeNumbers != null && targetTakeNumbers.Count > 0)
                ? new HashSet<int>(targetTakeNumbers)
                : null;

            foreach (FlowTakeSpec take in ep.FlowTakes)
            {
                if (filterSet != null && !filterSet.Contains(take.TakeNumber))
                    continue;
                if (take.Ingredients == null)
                    continue;

                foreach (string rawIng in take.Ingredients)
                {
                    if (EpisodeParser.IsScenarioAssetName(rawIng))
                        continue;

                    string baseCharFile = EpisodeParser.GetBaseCharacterFileName(rawIng);
                    string effectiveOutfitFile = EpisodeParser.ResolveEffectiveIngredientForTake(ep, take, rawIng);

                    if (string.IsNullOrEmpty(effectiveOutfitFile) ||
                        string.Equals(effectiveOutfitFile, baseCharFile, StringComparison.OrdinalIgnoreCase) ||
                        effectiveOutfitFile.IndexOf("__Roupa_", StringComparison.OrdinalIgnoreCase) < 0)
                    {
                        continue;
                    }

                    // Sincroniza se já existir em outro episódio da mesma história
                    EpisodeParser.GetCharacterOutfitVariantsOnDisk(ep, baseCharFile);

                    string fullOutfitPath = Path.Combine(ep.AssetsDir, effectiveOutfitFile);
                    if (File.Exists(fullOutfitPath) && new FileInfo(fullOutfitPath).Length > 10 * 1024)
                    {
                        continue;
                    }

                    string baseCharPath = Path.Combine(ep.AssetsDir, baseCharFile);
                    if (!File.Exists(baseCharPath) || new FileInfo(baseCharPath).Length <= 10 * 1024)
                    {
                        _log(string.Format("[Grok Figurino] Aviso: Personagem base '{0}' não encontrado em assets\\; não foi possível gerar '{1}'.",
                            baseCharFile, effectiveOutfitFile));
                        continue;
                    }

                    string occKey = EpisodeParser.ExtractOutfitOccasionLabel(effectiveOutfitFile);
                    string stdCat = EpisodeParser.NormalizeStandardWardrobeCategory(occKey);
                    string dispLbl = EpisodeParser.FormatOutfitDisplayLabel(effectiveOutfitFile);
                    string desc = EpisodeParser.GetStandardWardrobePresetDescription(ep, baseCharFile, stdCat);

                    _log(string.Format("[Grok Figurino] Gerando primeiro '{0}' ({1}) para usar no Take_{2:00}...",
                        dispLbl, effectiveOutfitFile, take.TakeNumber));

                    await GenerateCharacterOutfitVariantAsync(ep, baseCharFile, stdCat, desc, true, ct);
                    totalGenerated++;
                }
            }

            MirrorAssetsToTempFlow(ep.AssetsDir);
            EpisodeParser.RefreshDiskCounters(ep);
            return totalGenerated;
        }
    }
}
