param(
    [string]$RepoOrUrl = "",
    [string]$Token = "",
    [int]$WaitPid = 0,
    [switch]$RestartApp
)

$ErrorActionPreference = "Stop"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
Add-Type -AssemblyName System.Web.Extensions

$studioDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$settingsFile = Join-Path $studioDir "studio_user_settings.json"
$remoteCfgFile = Join-Path $studioDir "remote_update_config.json"
$ser = New-Object System.Web.Script.Serialization.JavaScriptSerializer
$ser.MaxJsonLength = [int]::MaxValue

if ([string]::IsNullOrWhiteSpace($RepoOrUrl) -and (Test-Path $settingsFile)) {
    try {
        $st = $ser.DeserializeObject([System.IO.File]::ReadAllText($settingsFile, [System.Text.Encoding]::UTF8))
        if ($st.ContainsKey("RemoteUpdateRepo")) { $RepoOrUrl = ("" + $st["RemoteUpdateRepo"]).Trim() }
        if ([string]::IsNullOrWhiteSpace($Token) -and $st.ContainsKey("RemoteUpdateToken")) { $Token = ("" + $st["RemoteUpdateToken"]).Trim() }
    } catch {}
}
if ([string]::IsNullOrWhiteSpace($RepoOrUrl) -and (Test-Path $remoteCfgFile)) {
    try {
        $rc = $ser.DeserializeObject([System.IO.File]::ReadAllText($remoteCfgFile, [System.Text.Encoding]::UTF8))
        if ($rc.ContainsKey("RemoteUpdateRepo")) { $RepoOrUrl = ("" + $rc["RemoteUpdateRepo"]).Trim() }
    } catch {}
}

if ([string]::IsNullOrWhiteSpace($RepoOrUrl)) {
    throw "Nenhum repositório ou link de atualização remota configurado."
}

$downloadUrl = $RepoOrUrl
if ($RepoOrUrl -notmatch "^https?://") {
    $cleanRepo = $RepoOrUrl -replace "^https?://github\.com/", "" -replace "\.git$", ""
    $downloadUrl = "https://raw.githubusercontent.com/$cleanRepo/main/FluxoVideoStudio_Update.zip?t=$([DateTimeOffset]::UtcNow.ToUnixTimeSeconds())"
} elseif ($RepoOrUrl -match "^https?://github\.com/([^/]+/[^/]+?)(?:\.git)?/?$") {
    $cleanRepo = $Matches[1]
    $downloadUrl = "https://raw.githubusercontent.com/$cleanRepo/main/FluxoVideoStudio_Update.zip?t=$([DateTimeOffset]::UtcNow.ToUnixTimeSeconds())"
}

Write-Host "[Atualizador Remoto] Baixando atualização de: $downloadUrl ..." -ForegroundColor Cyan
$tmpZip = Join-Path $env:TEMP "fvs_remote_update_dl.zip"
$extractDir = Join-Path $env:TEMP "fvs_remote_update_extracted"
if (Test-Path $tmpZip) { Remove-Item $tmpZip -Force }
if (Test-Path $extractDir) { Remove-Item $extractDir -Recurse -Force }

$wc = New-Object System.Net.WebClient
$wc.Headers.Add("User-Agent", "FluxoVideoStudio-Updater")
if (-not [string]::IsNullOrWhiteSpace($Token)) {
    $wc.Headers.Add("Authorization", "token $Token")
}
$wc.DownloadFile($downloadUrl, $tmpZip)
Unblock-File $tmpZip -ErrorAction SilentlyContinue

Expand-Archive -Path $tmpZip -DestinationPath $extractDir -Force
Get-ChildItem -Path $extractDir -Recurse -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue

# Se o processo principal pediu para aguardar seu fechamento antes de sobrescrever o .exe:
if ($WaitPid -gt 0) {
    try {
        $p = Get-Process -Id $WaitPid -ErrorAction SilentlyContinue
        if ($p) { $p.WaitForExit(8000) | Out-Null }
    } catch {}
}

$srcRoot = $extractDir
if (Test-Path (Join-Path $extractDir "FluxoVideoStudio\src")) {
    $srcRoot = Join-Path $extractDir "FluxoVideoStudio"
}

Write-Host "[Atualizador Remoto] Atualizando arquivos do FluxoVideoStudio em $studioDir (preservando suas contas e pastas)..." -ForegroundColor Yellow
foreach ($item in Get-ChildItem -Path $srcRoot) {
    if ($item.Name -eq "Skills" -or $item.Name -eq "studio_user_settings.json") { continue }
    Copy-Item -Path $item.FullName -Destination $studioDir -Recurse -Force
}

# Atualizar as 5 Skills em ~/.gemini/config/skills adaptando caminhos para a Área de Trabalho real deste PC
$skillsExtracted = Join-Path $srcRoot "Skills"
if (Test-Path $skillsExtracted) {
    $realDesktop = [Environment]::GetFolderPath("DesktopDirectory")
    if ([string]::IsNullOrWhiteSpace($realDesktop) -or -not (Test-Path $realDesktop)) {
        $od = Join-Path $env:USERPROFILE "OneDrive\Desktop"
        $realDesktop = if (Test-Path $od) { $od } else { Join-Path $env:USERPROFILE "Desktop" }
    }
    $skillsTargetRoot = Join-Path $env:USERPROFILE ".gemini\config\skills"
    New-Item -ItemType Directory -Path $skillsTargetRoot -Force | Out-Null
    Copy-Item -Path (Join-Path $skillsExtracted "*") -Destination $skillsTargetRoot -Recurse -Force

    $skillFiles = Get-ChildItem -Path $skillsTargetRoot -Recurse -Include "*.md", "*.ps1" -ErrorAction SilentlyContinue
    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    foreach ($sf in $skillFiles) {
        try {
            $raw = [System.IO.File]::ReadAllText($sf.FullName, [System.Text.Encoding]::UTF8)
            $upd = $raw.Replace("C:\Users\Best Option Notebook\Desktop", $realDesktop).Replace("C:\Users\Best Option Notebook", $env:USERPROFILE)
            if ($upd -ne $raw) {
                [System.IO.File]::WriteAllText($sf.FullName, $upd, $utf8NoBom)
            }
        } catch {}
    }
    Write-Host "[Atualizador Remoto] 5 Skills atualizadas com sucesso em $skillsTargetRoot !" -ForegroundColor Green
}

# Recompilar localmente o executável neste PC
$buildPs1 = Join-Path $studioDir "build.ps1"
if (Test-Path $buildPs1) {
    try {
        & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $buildPs1 | Out-Null
    } catch {}
}

Get-ChildItem -Path $studioDir -Recurse -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue
Write-Host "ATUALIZADO_OK" -ForegroundColor Green

if ($RestartApp) {
    $launcher = Join-Path $studioDir "Iniciar_FluxoVideoStudio.bat"
    if (Test-Path $launcher) {
        Start-Process -FilePath $launcher -WorkingDirectory $studioDir
    }
}
