@echo off
chcp 65001 >nul
title Instalador Completo 1-Clique - Fluxo Video Studio + Skills
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Instalar_Tudo_Outro_PC.ps1"
pause
