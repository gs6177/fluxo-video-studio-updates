param(
    [Parameter(Mandatory=$true)]
    [string]$InputAudioPath,

    [Parameter(Mandatory=$true)]
    [string]$OutputAudioPath,

    [double]$ThresholdDb = -40,
    [double]$MinSilenceDurationSec = 0.3,
    [double]$TruncateToSec = 0.3
)

$ErrorActionPreference = "Stop"
$inv = [System.Globalization.CultureInfo]::InvariantCulture

if (-not (Test-Path $InputAudioPath)) {
    throw "Arquivo de áudio de entrada não encontrado: $InputAudioPath"
}

$capcutAppsDir = Join-Path $env:LOCALAPPDATA "CapCut\Apps"
$ffmpegItem = Get-ChildItem -Path $capcutAppsDir -Filter "ffmpeg.exe" -Recurse -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1
if (-not $ffmpegItem) {
    $cmdFfmpeg = Get-Command ffmpeg -ErrorAction SilentlyContinue
    if ($cmdFfmpeg) {
        $ffmpegExe = $cmdFfmpeg.Source
    } else {
        throw "ffmpeg.exe não encontrado no sistema nem na instalação do CapCut."
    }
} else {
    $ffmpegExe = $ffmpegItem.FullName
}

$outDir = Split-Path -Parent $OutputAudioPath
if ($outDir -and -not (Test-Path $outDir)) {
    New-Item -ItemType Directory -Force -Path $outDir | Out-Null
}

$threshStr = "$($ThresholdDb)dB"
$minDurStr = $MinSilenceDurationSec.ToString($inv)

# Passo 1: Analisar os intervalos exatos de silêncio puro (< -40dB por >= 0.3s) usando silencedetect (detecção de pico idêntica ao Audacity)
$ErrorActionPreference = "Continue"
$detectOut = (& $ffmpegExe -hide_banner -i $InputAudioPath -af "silencedetect=noise=${threshStr}:d=${minDurStr}" -f null - 2>&1) -join "`n"
$ErrorActionPreference = "Stop"

$totalDuration = 0.0
if ($detectOut -match "Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)") {
    $totalDuration = ([double]$matches[1] * 3600.0) + ([double]$matches[2] * 60.0) + [double]::Parse($matches[3], $inv)
}

# Extrair pares [silence_start, silence_end]
$silences = @()
$currentStart = $null
foreach ($line in ($detectOut -split "`r?`n")) {
    if ($line -match "silence_start:\s*([0-9\.]+)") {
        $currentStart = [double]::Parse($matches[1], $inv)
    } elseif ($line -match "silence_start:\s*invalid") {
        $currentStart = 0.0
    } elseif ($line -match "silence_end:\s*([0-9\.]+)") {
        $sEnd = [double]::Parse($matches[1], $inv)
        $sStart = if ($null -ne $currentStart) { $currentStart } else { 0.0 }
        if (($sEnd - $sStart) -ge $MinSilenceDurationSec) {
            $silences += [PSCustomObject]@{ Start = $sStart; End = $sEnd }
        }
        $currentStart = $null
    }
}

# Passo 2: Construir os segmentos de áudio a manter (Keep Segments), preservando 100% da fala
# Em cada pausa interna > 0.3s, mantemos metade do TruncateToSec (0.15s) após o fim da palavra anterior
# e metade (0.15s) antes do início da próxima palavra (totalizando exatos 0.3s de pausa),
# e no final do arquivo mantemos 0.3s de cauda para NUNCA cortar o final da última palavra!
$keepSegments = @()
$cursor = 0.0
$halfKeep = $TruncateToSec / 2.0

foreach ($sil in $silences) {
    $isAtStart = ($sil.Start -le 0.05)
    $isAtEnd   = ($totalDuration -gt 0 -and $sil.End -ge ($totalDuration - 0.05))

    if ($isAtStart) {
        # Silêncio no início: manter pequena margem segura de 0.05s antes da primeira palavra
        $cutUntil = [Math]::Max(0.0, $sil.End - 0.05)
        $cursor = $cutUntil
    } elseif ($isAtEnd) {
        # Silêncio no final: manter toda a fala + TruncateToSec (0.3s) de cauda segura no final
        $segEnd = [Math]::Min($sil.End, $sil.Start + $TruncateToSec)
        if ($segEnd -gt $cursor) {
            $keepSegments += [PSCustomObject]@{ Start = $cursor; End = $segEnd }
        }
        $cursor = $sil.End
    } else {
        # Silêncio no meio: manter [cursor .. sil.Start + 0.15s] e retomar em [sil.End - 0.15s]
        $segEnd = $sil.Start + $halfKeep
        $nextCursor = $sil.End - $halfKeep
        if ($segEnd -gt $cursor) {
            $keepSegments += [PSCustomObject]@{ Start = $cursor; End = $segEnd }
        }
        $cursor = $nextCursor
    }
}

if ($totalDuration -gt $cursor) {
    $keepSegments += [PSCustomObject]@{ Start = $cursor; End = $totalDuration }
}

if ($keepSegments.Count -eq 0) {
    Copy-Item -Path $InputAudioPath -Destination $OutputAudioPath -Force
} else {
    $betweenParts = $keepSegments | ForEach-Object {
        $a = $_.Start.ToString("0.0000", $inv)
        $b = $_.End.ToString("0.0000", $inv)
        "between(t,$a,$b)"
    }
    $selectExpr = $betweenParts -join "+"
    $filter = "aselect='$selectExpr',asetpts=N/SR/TB"

    $ErrorActionPreference = "Continue"
    & $ffmpegExe -y -hide_banner -loglevel error -i $InputAudioPath -af $filter $OutputAudioPath
    $exitCode = $LASTEXITCODE
    $ErrorActionPreference = "Stop"

    if ($exitCode -ne 0 -or -not (Test-Path $OutputAudioPath)) {
        throw "Falha ao processar truncamento de silêncio com FFmpeg (ExitCode: $exitCode)."
    }
}

$ErrorActionPreference = "Continue"
$outInfo = (& $ffmpegExe -i $OutputAudioPath 2>&1) -join "`n"
$ErrorActionPreference = "Stop"

$inDurStr  = [Math]::Round($totalDuration, 2).ToString($inv)
$outDurStr = if ($outInfo -match "Duration:\s*(\d+:\d+:\d+\.\d+)") { $matches[1] } else { "?" }

Write-Host "Áudio processado sem cortar nenhuma palavra (Travar Silêncio: ${ThresholdDb}dB / ${MinSilenceDurationSec}s -> ${TruncateToSec}s | $($silences.Count) pausas reduzidas): $OutputAudioPath (Antes: ${inDurStr}s -> Depois: $outDurStr)"
