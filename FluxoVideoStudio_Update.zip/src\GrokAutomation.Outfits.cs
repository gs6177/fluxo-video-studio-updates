using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace FluxoVideoStudio
{
    public partial class GrokAutomation
    {
        private async Task GenerateVariantSpecWithBaseCharacterAsync(
            EpisodeWorkItem ep,
            GrokAssetSpec varSpec,
            string baseCharPath,
            CancellationToken ct)
        {
            if (ep == null || varSpec == null || string.IsNullOrEmpty(baseCharPath) || !File.Exists(baseCharPath))
                throw new FileNotFoundException("Arquivo do personagem base não encontrado para gerar o novo figurino.");

            string targetFullPath = Path.Combine(ep.AssetsDir, varSpec.TargetFileName);
            string charTitle = !string.IsNullOrEmpty(varSpec.DisplayTitle)
                ? varSpec.DisplayTitle
                : EpisodeParser.CleanAssetStem(varSpec.TargetFileName);
            charTitle = Regex.Replace(charTitle, @"^(Personagem\s*\d+[A-Za-z]?)\s*:\s*", "", RegexOptions.IgnoreCase).Trim();
            charTitle = Regex.Replace(charTitle, @"^em\s+cima\s+da\s+cabe[cç]a\s+", "", RegexOptions.IgnoreCase).Trim();

            string prompt = string.Format(
                "Crie uma imagem 9:16 vertical isolada mantendo EXATAMENTE o mesmo estilo de animação 3D e 100% TODAS as características originais do personagem da imagem de referência anexada (mesmo rosto, mesma estrutura óssea facial, mesmos olhos, mesmo tom de pele, mesma idade, mesma fisionomia e mesmas proporções corporais de corpo inteiro dos pés à cabeça, em pé, de frente, sobre FUNDO BRANCO NEUTRO PURO #FFFFFF, com o nome \"{0}\" escrito no topo acima da cabeça), aplicando apenas as mudanças desta nova versão do personagem conforme a descrição abaixo:\n\n{1}",
                charTitle,
                varSpec.RawPromptLine);

            Exception lastErr = null;
            List<string> activeProfiles = _config.GetAvailableGrokProfiles(_log);
            foreach (string profile in activeProfiles)
            {
                ct.ThrowIfCancellationRequested();
                try
                {
                    _log(string.Format("[Grok Imagine | Novo Figurino] Abrindo perfil '{0}' para anexar '{1}' e gerar '{2}'...",
                        profile, Path.GetFileName(baseCharPath), varSpec.TargetFileName));

                    string sess = await _cdp.OpenOrAttachProfileTabAsync(profile, _config.GrokUrl, "grok.com", false, ct);
                    await WaitForGrokInteractiveReadyAsync(sess, ct);

                    if (await HasQuotaExhaustedBannerAsync(sess, ct))
                    {
                        _config.SetProfileStatus(profile, "LIMITE ATINGIDO");
                        _log(string.Format("[Grok Imagine | Novo Figurino] Limite atingido no perfil '{0}'. Alternando para o próximo perfil...", profile));
                        continue;
                    }

                    await EnsureCleanGrokImagineHomeAsync(sess, profile, ct);

                    if (await HasQuotaExhaustedBannerAsync(sess, ct))
                    {
                        _config.SetProfileStatus(profile, "LIMITE ATINGIDO");
                        _log(string.Format("[Grok Imagine | Novo Figurino] Limite atingido no perfil '{0}'. Alternando para o próximo perfil...", profile));
                        continue;
                    }

                    // 1. Garantir modo 'Imagem' ativo e proporção 9:16 ANTES de anexar a imagem do personagem base!
                    await EnsureGrokImageModeAnd9x16Async(sess, ct);

                    // 2. Anexar a imagem do personagem base existente (com verificação e retentativa caso a página ainda estivesse hidratando)
                    _log(string.Format("[Grok Imagine | Novo Figurino] Anexando personagem base '{0}' na caixa do Grok...",
                        Path.GetFileName(baseCharPath)));

                    List<string> refFiles = new List<string> { baseCharPath };
                    bool attached = await _cdp.SetFileInputFilesByObjectIdAsync(
                        sess,
                        "document.querySelector('input[type=\"file\"][multiple]') || document.querySelector('input[type=\"file\"]')",
                        refFiles,
                        ct);

                    await Task.Delay(1400, ct);
                    string attachCountStr = await _cdp.EvalStringAsync(sess, @"
(function(){
    return Array.from(document.querySelectorAll('button[aria-label*=""Remover imagem""], button[aria-label*=""Remove image""]')).length.toString();
})()", ct);

                    if (!attached || attachCountStr == "0")
                    {
                        await _cdp.UploadFilesViaFileChooserAsync(
                            sess,
                            async () =>
                            {
                                Dictionary<string, object> trPt = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var b = Array.from(document.querySelectorAll('button')).find(el => {
        var al = (el.getAttribute('aria-label') || '');
        var r = el.getBoundingClientRect();
        return r.left > 245 && !el.closest('[data-sidebar], nav, aside') && r.width > 10 &&
               (al.indexOf('Transferir') >= 0 || al.indexOf('Upload') >= 0 || al.indexOf('Anexar') >= 0 || al.indexOf('Attach') >= 0);
    });
    if (!b) return null;
    var r = b.getBoundingClientRect();
    return JSON.stringify({ x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) });
})()", ct);
                                if (trPt != null)
                                    await _cdp.ClickAtAsync(sess, Convert.ToInt32(trPt["x"]), Convert.ToInt32(trPt["y"]), ct);
                            },
                            refFiles,
                            ct);
                        await Task.Delay(1800, ct);
                        attachCountStr = await _cdp.EvalStringAsync(sess, @"
(function(){
    return Array.from(document.querySelectorAll('button[aria-label*=""Remover imagem""], button[aria-label*=""Remove image""], button[aria-label*=""Remover anexo""], button[aria-label*=""Remove attachment""]')).length.toString();
})()", ct);
                    }

                    // Confirmar que o anexo apareceu e reafirmar proporção 9:16
                    _log(string.Format("[Grok Imagine | Novo Figurino] Personagem base anexado ({0} imagem(ns) na caixa). Confirmando 9:16 e enviando prompt de '{1}'...",
                        attachCountStr, varSpec.TargetFileName));

                    await EnsureGrokDropdownOptionAsync(sess, "Aspecto de proporção", "Aspect ratio", "9:16", ct);

                    // 3. Registrar URLs de imagens geradas existentes antes de submeter
                    await _cdp.EvalStringAsync(sess, @"
(function(){
    window.__fvsBaselineGenUrls = Array.from(document.querySelectorAll('img'))
        .map(i => i.currentSrc || i.src || '')
        .filter(Boolean);
    return 'OK';
})()", ct);

                    bool inserted = await InjectPromptIntoGrokBoxAsync(sess, prompt, ct);
                    if (!inserted)
                        throw new InvalidOperationException("Caixa de prompt não encontrada no Grok Imagine.");

                    await Task.Delay(600, ct);
                    string curPageUrl = await _cdp.EvalStringAsync(sess, "location.href || ''", ct);
                    LastActionHistoryStore.RecordAction(
                        ep,
                        "Grok Figurino",
                        string.Format("Gerando novo figurino '{0}' anexando '{1}'", varSpec.TargetFileName, Path.GetFileName(baseCharPath)),
                        profile,
                        sess,
                        curPageUrl,
                        varSpec.TargetFileName,
                        0,
                        1,
                        prompt,
                        refFiles,
                        "SUBMITTED");

                    await SubmitGrokPromptAsync(sess, ct);

                    // 4. Aguardar a nova imagem com o figurino terminar de gerar (com Watchdog de Recarregamento + Retomada pelo Histórico)
                    DateTime deadline = DateTime.UtcNow.AddMinutes(5);
                    DateTime lastProgressUtc = DateTime.UtcNow;
                    string lastFingerprint = "";
                    int reloadAttempts = 0;
                    int stable = 0;
                    string generatedImgUrl = "";

                    while (DateTime.UtcNow < deadline)
                    {
                        ct.ThrowIfCancellationRequested();
                        await _cdp.WaitOrWakeOnReloadSignalAsync(3500, ct);

                        if (await HasQuotaExhaustedBannerAsync(sess, ct))
                        {
                            _config.SetProfileStatus(profile, "LIMITE ATINGIDO");
                            throw new InvalidOperationException("QUOTA_EXHAUSTED");
                        }

                        Dictionary<string, object> st = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var baseList = window.__fvsBaselineGenUrls || [];
    var body = (document.body && document.body.innerText) ? document.body.innerText : '';
    var genImgs = Array.from(document.querySelectorAll('img')).filter(img => {
        var s = (img.currentSrc || img.src || '');
        var r = img.getBoundingClientRect();
        if (r.width < 120 || r.height < 160 || !img.complete || img.naturalWidth < 300) return false;
        if (s.indexOf('media.x.ai') >= 0 || s.indexOf('agent-skills') >= 0 || s.indexOf('grok-web') >= 0 || s.indexOf('/website/') >= 0) return false;
        if (baseList.indexOf(s) >= 0) return false;
        return s.indexOf('/generated/') >= 0 || s.indexOf('assets.grok.com/users/') >= 0;
    });
    var spinners = Array.from(document.querySelectorAll('[role=""progressbar""], .animate-spin, svg.animate-spin')).filter(el => {
        var r = el.getBoundingClientRect();
        return r.width > 4 && r.height > 4;
    }).length;
    var pctMatch = body.match(/\b\d{1,2}%\b/);
    var pctStr = pctMatch ? pctMatch[0] : '';
    var hasPct = !!pctMatch;
    var genText = hasPct || /\b(Generating|Imaginando|Criando imagens|Gerando)\b/i.test(body);
    var latestSrc = genImgs.length > 0 ? (genImgs[genImgs.length - 1].currentSrc || genImgs[genImgs.length - 1].src || '') : '';
    return JSON.stringify({ count: genImgs.length, spinners: spinners, genText: genText, pctStr: pctStr, latestSrc: latestSrc });
})()", ct);

                        if (st != null)
                        {
                            int count = Convert.ToInt32(st["count"]);
                            int spinners = Convert.ToInt32(st["spinners"]);
                            bool genText = Convert.ToBoolean(st["genText"]);
                            string pctStr = st.ContainsKey("pctStr") ? Convert.ToString(st["pctStr"] ?? "") : "";
                            string latestSrc = Convert.ToString(st["latestSrc"] ?? "");

                            string fp = string.Format("{0}|{1}|{2}", count, pctStr, latestSrc);
                            if (fp != lastFingerprint)
                            {
                                lastFingerprint = fp;
                                lastProgressUtc = DateTime.UtcNow;
                            }

                            _log(string.Format("[Grok Imagine | Novo Figurino] Aguardando '{0}': {1}/1 imagem gerada{2} (spinners: {3})...",
                                varSpec.TargetFileName, count > 0 ? 1 : 0, !string.IsNullOrEmpty(pctStr) ? (" [" + pctStr + "]") : "", spinners));

                            if (count > 0 && spinners == 0 && !genText)
                            {
                                generatedImgUrl = latestSrc;
                                stable++;
                                if (stable >= 2) break;
                            }
                            else
                            {
                                stable = 0;
                            }
                        }

                        string manualReason;
                        bool manualReload = _cdp.ConsumeReloadAndResumeRequest(out manualReason);
                        double stalledSec = (DateTime.UtcNow - lastProgressUtc).TotalSeconds;

                        if (manualReload || (stalledSec >= 85 && reloadAttempts < 2))
                        {
                            reloadAttempts++;
                            string why = manualReload
                                ? manualReason
                                : string.Format("sem progresso por {0:0}s", stalledSec);
                            _log(string.Format("[Recuperação | Histórico] Travamento detectado em '{0}' ({1}). Recarregando a página e retomando a partir da última ação (tentativa {2}/2)...",
                                varSpec.TargetFileName, why, reloadAttempts));

                            await _cdp.ReloadPageAndWaitReadyAsync(sess, 25000, ct);
                            await WaitForGrokInteractiveReadyAsync(sess, ct);

                            Dictionary<string, object> afterReload = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var baseList = window.__fvsBaselineGenUrls || [];
    var genImgs = Array.from(document.querySelectorAll('img')).filter(img => {
        var s = (img.currentSrc || img.src || '');
        var r = img.getBoundingClientRect();
        if (r.width < 120 || r.height < 160 || !img.complete || img.naturalWidth < 300) return false;
        if (s.indexOf('media.x.ai') >= 0 || s.indexOf('agent-skills') >= 0 || s.indexOf('grok-web') >= 0 || s.indexOf('/website/') >= 0) return false;
        if (baseList.indexOf(s) >= 0) return false;
        return s.indexOf('/generated/') >= 0 || s.indexOf('assets.grok.com/users/') >= 0;
    });
    var latestSrc = genImgs.length > 0 ? (genImgs[genImgs.length - 1].currentSrc || genImgs[genImgs.length - 1].src || '') : '';
    return JSON.stringify({ count: genImgs.length, latestSrc: latestSrc });
})()", ct);

                            if (afterReload != null && Convert.ToInt32(afterReload["count"]) > 0)
                            {
                                generatedImgUrl = Convert.ToString(afterReload["latestSrc"] ?? "");
                                _log(string.Format("[Recuperação | Histórico] Imagem '{0}' já constava concluída após recarregar a página -> baixando imediatamente!",
                                    varSpec.TargetFileName));
                                break;
                            }

                            _log(string.Format("[Recuperação | Histórico] Reenviando '{0}' a partir do histórico da última ação...", varSpec.TargetFileName));
                            await EnsureCleanGrokImagineHomeAsync(sess, profile, ct);
                            await EnsureGrokImageModeAnd9x16Async(sess, ct);
                            await _cdp.SetFileInputFilesByObjectIdAsync(
                                sess,
                                "document.querySelector('input[type=\"file\"][multiple]') || document.querySelector('input[type=\"file\"]')",
                                refFiles,
                                ct);
                            await Task.Delay(1400, ct);
                            await EnsureGrokDropdownOptionAsync(sess, "Aspecto de proporção", "Aspect ratio", "9:16", ct);
                            await InjectPromptIntoGrokBoxAsync(sess, prompt, ct);
                            await Task.Delay(500, ct);
                            await SubmitGrokPromptAsync(sess, ct);
                            lastProgressUtc = DateTime.UtcNow;
                            lastFingerprint = "";
                        }
                    }

                    if (string.IsNullOrEmpty(generatedImgUrl))
                        throw new TimeoutException(string.Format("Timeout aguardando geração do novo figurino '{0}' no Grok Imagine.", varSpec.TargetFileName));

                    // 5. Garantir que a miniatura recém-gerada (Thumbnail 2 / src com '/generated/') esteja selecionada (e não a Thumbnail 1 da imagem base anexada)
                    Dictionary<string, object> genThumbPt = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var thumbBtns = Array.from(document.querySelectorAll('button[aria-label^=""Thumbnail ""]')).filter(b => b.getBoundingClientRect().width > 10);
    if (thumbBtns.length <= 1) return null;
    var genBtn = thumbBtns.find(b => {
        var img = b.querySelector('img');
        var s = img ? (img.currentSrc || img.src || '') : '';
        return s.indexOf('/generated/') >= 0 || s.indexOf('assets.grok.com/users/') >= 0;
    }) || thumbBtns[thumbBtns.length - 1];
    if (!genBtn) return null;
    var r = genBtn.getBoundingClientRect();
    return JSON.stringify({ x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) });
})()", ct);

                    if (genThumbPt != null)
                    {
                        await _cdp.ClickAtAsync(sess, Convert.ToInt32(genThumbPt["x"]), Convert.ToInt32(genThumbPt["y"]), ct);
                        await Task.Delay(650, ct);
                    }

                    // 6. Baixar a imagem gerada via botão 'Baixar' (↓)
                    string stagingDir = Path.Combine(ep.AssetsDir, "_grok_var_" + DateTime.Now.ToString("HHmmss"));
                    Directory.CreateDirectory(stagingDir);
                    await _cdp.SetDownloadBehaviorAsync(stagingDir, ct);

                    Dictionary<string, object> dlPt = await FindGrokDownloadButtonPointAsync(sess, ct);
                    if (dlPt == null)
                    {
                        await EnsureThumbnailViewerOpenAsync(sess, 1, ct);
                        dlPt = await FindGrokDownloadButtonPointAsync(sess, ct);
                    }

                    HashSet<string> beforeFiles = new HashSet<string>(Directory.GetFiles(stagingDir), StringComparer.OrdinalIgnoreCase);
                    string savedFile = "";

                    if (dlPt != null)
                    {
                        await _cdp.ClickAtAsync(sess, Convert.ToInt32(dlPt["x"]), Convert.ToInt32(dlPt["y"]), ct);
                        savedFile = await _cdp.WaitForSingleDownloadAsync(stagingDir, beforeFiles, 30 * 1024, 35000, ct);
                    }

                    if (string.IsNullOrEmpty(savedFile) && !string.IsNullOrEmpty(generatedImgUrl))
                    {
                        beforeFiles = new HashSet<string>(Directory.GetFiles(stagingDir), StringComparer.OrdinalIgnoreCase);
                        string b64Url = Convert.ToBase64String(Encoding.UTF8.GetBytes(generatedImgUrl));
                        await _cdp.EvalStringAsync(sess, string.Format(@"
(function(){{
    var u = atob('{0}');
    fetch(u, {{ credentials: 'include' }})
        .then(r => r.blob())
        .then(b => {{
            var burl = URL.createObjectURL(b);
            var a = document.createElement('a');
            a.href = burl;
            a.download = '{1}';
            document.body.appendChild(a);
            a.click();
            setTimeout(() => {{ a.remove(); URL.revokeObjectURL(burl); }}, 4000);
        }});
    return 'FETCH_IMG';
}})()", b64Url, varSpec.TargetFileName), ct);
                        savedFile = await _cdp.WaitForSingleDownloadAsync(stagingDir, beforeFiles, 30 * 1024, 35000, ct);
                    }

                    if (string.IsNullOrEmpty(savedFile))
                    {
                        await _cdp.ResetDownloadBehaviorToDefaultAsync();
                        try { Directory.Delete(stagingDir, true); } catch { }
                        throw new IOException(string.Format("Timeout aguardando download da imagem '{0}' no Grok Imagine.", varSpec.TargetFileName));
                    }

                    await _cdp.ResetDownloadBehaviorToDefaultAsync();
                    File.Copy(savedFile, targetFullPath, true);
                    try { Directory.Delete(stagingDir, true); } catch { }

                    // Sincronizar automaticamente apenas com episódios posteriores (ex.: EP.1 -> EP.2/EP.3) caso reutilizem esta versão
                    if (!string.IsNullOrEmpty(ep.StoryRootPath) && Directory.Exists(ep.StoryRootPath))
                    {
                        foreach (string sub in Directory.GetDirectories(ep.StoryRootPath))
                        {
                            Match mSub = Regex.Match(Path.GetFileName(sub), @"^EP\.?\s*0*(\d+)$", RegexOptions.IgnoreCase);
                            int subEpNum;
                            if (mSub.Success && int.TryParse(mSub.Groups[1].Value, out subEpNum) && subEpNum > ep.EpisodeNumber)
                            {
                                string subAssets = Path.Combine(sub, "assets");
                                if (Directory.Exists(subAssets))
                                {
                                    string dstSub = Path.Combine(subAssets, varSpec.TargetFileName);
                                    if (!string.Equals(dstSub, targetFullPath, StringComparison.OrdinalIgnoreCase) && File.Exists(dstSub))
                                    {
                                        try { File.Copy(targetFullPath, dstSub, true); } catch { }
                                    }
                                }
                            }
                        }
                    }

                    _config.SetProfileStatus(profile, "DISPONÍVEL");
                    _log(string.Format("[Grok Imagine | Novo Figurino] '{0}' salvo com sucesso ({1} KB) mantendo o mesmo rosto de '{2}'!",
                        varSpec.TargetFileName, new FileInfo(targetFullPath).Length / 1024, Path.GetFileName(baseCharPath)));
                    return;
                }
                catch (OperationCanceledException)
                {
                    throw;
                }
                catch (Exception ex)
                {
                    lastErr = ex;
                    if (ex.Message == "QUOTA_EXHAUSTED")
                    {
                        _log(string.Format("[Grok Imagine | Novo Figurino] Limite atingido no perfil '{0}'. Alternando para o próximo perfil...", profile));
                        continue;
                    }
                    _log(string.Format("[Grok Imagine | Novo Figurino] Aviso no perfil '{0}': {1}. Tentando próximo perfil...", profile, ex.Message));
                }
            }

            if (_flowFallback != null && _config.AreAllGrokProfilesMarkedExhausted())
            {
                _log(string.Format("[Grok -> Google Flow | Sem Créditos] Todas as contas do Grok estão sem créditos -> gerando figurino '{0}' (anexando '{1}') no Google Flow!",
                    varSpec.TargetFileName, Path.GetFileName(baseCharPath)));
                await _flowFallback.GenerateMissingAssetsInFlowAsync(ep, new List<GrokAssetSpec> { varSpec }, ct);
                return;
            }

            throw new InvalidOperationException(
                string.Format("Não foi possível gerar o novo figurino '{0}' em nenhum dos perfis autorizados do Grok.", varSpec.TargetFileName) +
                (lastErr != null ? " Último erro: " + lastErr.Message : ""));
        }


        public async Task RegenerateSingleAssetAsync(
            EpisodeWorkItem ep,
            string targetFileName,
            string customPromptLine,
            CancellationToken ct)
        {
            if (ep == null || string.IsNullOrWhiteSpace(targetFileName))
                throw new ArgumentException("Episódio ou nome do arquivo de asset inválido.");

            if (!Directory.Exists(ep.AssetsDir))
                Directory.CreateDirectory(ep.AssetsDir);

            await _cdp.EnsureConnectedAsync(ct);

            GrokAssetSpec spec = ep.GrokSpecs.FirstOrDefault(s =>
                string.Equals(s.TargetFileName, targetFileName, StringComparison.OrdinalIgnoreCase));

            string displayTitle = spec != null && !string.IsNullOrEmpty(spec.DisplayTitle)
                ? spec.DisplayTitle
                : EpisodeParser.CleanAssetStem(targetFileName);

            string rawLine = !string.IsNullOrWhiteSpace(customPromptLine)
                ? customPromptLine.Trim()
                : (spec != null && !string.IsNullOrWhiteSpace(spec.RawPromptLine)
                    ? spec.RawPromptLine.Trim()
                    : string.Format("- {0}: Animação 3D estilizada semi-realista (CGI), proporções 9:16 verticais, nome \"{0}\" escrito no topo.", displayTitle));

            GrokAssetSpec singleSpec = new GrokAssetSpec
            {
                OrderIndex = spec != null && spec.OrderIndex > 0 ? spec.OrderIndex : 999,
                IsScenario = EpisodeParser.IsScenarioAssetName(targetFileName),
                LabelPrefix = spec != null && !string.IsNullOrEmpty(spec.LabelPrefix)
                    ? spec.LabelPrefix
                    : (EpisodeParser.IsScenarioAssetName(targetFileName) ? "Cenário" : "Personagem"),
                DisplayTitle = displayTitle,
                TargetFileName = targetFileName,
                RawPromptLine = rawLine
            };

            string fullPrompt = "Faça esta única imagem isolada e em 9:16, nome em cima da cabeça:\n\n" + rawLine;
            string destPath = Path.Combine(ep.AssetsDir, targetFileName);
            if (File.Exists(destPath))
            {
                string backupDir = Path.Combine(ep.AssetsDir, "_old_assets");
                Directory.CreateDirectory(backupDir);
                string bakPath = Path.Combine(backupDir, Path.GetFileNameWithoutExtension(targetFileName) + "_" + DateTime.Now.ToString("HHmmss") + Path.GetExtension(targetFileName));
                File.Copy(destPath, bakPath, true);
                File.Delete(destPath);
            }

            // Se for um novo figurino de um personagem base que já existe em disco, anexa o personagem base como referência!
            string baseCharPath = EpisodeParser.FindExistingBaseCharacterPathForVariantSpec(ep, singleSpec);
            if (!singleSpec.IsScenario && !string.IsNullOrEmpty(baseCharPath) && File.Exists(baseCharPath))
            {
                _log(string.Format("[Grok Asset Individual] Conferido personagem base '{0}' -> anexando no Grok para regerar o figurino '{1}' mantendo o mesmo rosto...",
                    Path.GetFileName(baseCharPath), targetFileName));
                await GenerateVariantSpecWithBaseCharacterAsync(ep, singleSpec, baseCharPath, ct);
                MirrorAssetsToTempFlow(ep.AssetsDir);
                EpisodeParser.RefreshDiskCounters(ep);
                _log(string.Format("[Grok Asset Individual] '{0}' regerado com sucesso e espelhado para Temp\\flow_assets!", targetFileName));
                return;
            }

            List<GrokAssetSpec> oneList = new List<GrokAssetSpec> { singleSpec };
            Exception lastErr = null;
            List<string> activeProfiles = _config.GetAvailableGrokProfiles(_log);
            foreach (string profile in activeProfiles)
            {
                ct.ThrowIfCancellationRequested();
                try
                {
                    _log(string.Format("[Grok Asset Individual] Regerando '{0}' no perfil '{1}'...", targetFileName, profile));
                    bool exhausted = await TryGenerateAndDownloadWithProfileAsync(profile, fullPrompt, ep, oneList, ct);
                    if (exhausted)
                    {
                        _config.SetProfileStatus(profile, "LIMITE ATINGIDO");
                        _log(string.Format("[Grok Asset Individual] Limite atingido em '{0}'. Alternando perfil...", profile));
                        continue;
                    }

                    _config.SetProfileStatus(profile, "DISPONÍVEL");
                    MirrorAssetsToTempFlow(ep.AssetsDir);
                    EpisodeParser.RefreshDiskCounters(ep);
                    _log(string.Format("[Grok Asset Individual] '{0}' regerado com sucesso e espelhado para Temp\\flow_assets!", targetFileName));
                    return;
                }
                catch (OperationCanceledException)
                {
                    throw;
                }
                catch (Exception ex)
                {
                    lastErr = ex;
                    _log(string.Format("[Grok Asset Individual] Aviso no perfil '{0}': {1}. Tentando próximo...", profile, ex.Message));
                }
            }

            if (_flowFallback != null && _config.AreAllGrokProfilesMarkedExhausted())
            {
                _log(string.Format("[Grok -> Google Flow | Sem Créditos] Todas as contas do Grok estão sem créditos -> regerando '{0}' em 9:16 no Google Flow!", targetFileName));
                await _flowFallback.GenerateMissingAssetsInFlowAsync(ep, oneList, ct);
                MirrorAssetsToTempFlow(ep.AssetsDir);
                EpisodeParser.RefreshDiskCounters(ep);
                return;
            }

            throw new InvalidOperationException(
                string.Format("Não foi possível regerar o asset '{0}' em nenhum perfil autorizado.", targetFileName) +
                (lastErr != null ? " Último erro: " + lastErr.Message : ""));
        }

        public async Task<string> GenerateCharacterOutfitVariantAsync(
            EpisodeWorkItem ep,
            string baseCharFileName,
            string occasionLabel,
            string outfitDescription,
            bool copyToAllEpisodes,
            CancellationToken ct)
        {
            if (ep == null || string.IsNullOrWhiteSpace(baseCharFileName) || string.IsNullOrWhiteSpace(occasionLabel))
                throw new ArgumentException("Selecione o personagem base e informe a ocasião da roupa.");

            if (!Directory.Exists(ep.AssetsDir))
                Directory.CreateDirectory(ep.AssetsDir);

            await _cdp.EnsureConnectedAsync(ct);

            string cleanBaseName = EpisodeParser.GetBaseCharacterFileName(baseCharFileName);
            string baseImagePath = Path.Combine(ep.AssetsDir, cleanBaseName);
            if (!File.Exists(baseImagePath))
            {
                string matched = EpisodeParser.FindMatchingDiskAssetFile(cleanBaseName, Directory.GetFiles(ep.AssetsDir));
                if (!string.IsNullOrEmpty(matched))
                    baseImagePath = matched;
            }
            if (!File.Exists(baseImagePath))
            {
                string fromPrevEp = EpisodeParser.FindExistingBaseCharacterPathByNameInStory(ep, cleanBaseName);
                if (!string.IsNullOrEmpty(fromPrevEp) && File.Exists(fromPrevEp))
                    baseImagePath = fromPrevEp;
            }

            if (!File.Exists(baseImagePath))
                throw new FileNotFoundException(string.Format("Imagem base do personagem '{0}' não encontrada em '{1}'.", cleanBaseName, ep.AssetsDir));

            string variantFileName = EpisodeParser.BuildOutfitVariantFileName(cleanBaseName, occasionLabel);
            string variantFullPath = Path.Combine(ep.AssetsDir, variantFileName);

            GrokAssetSpec baseSpec = ep.GrokSpecs.FirstOrDefault(s =>
                string.Equals(s.TargetFileName, cleanBaseName, StringComparison.OrdinalIgnoreCase));
            string charTitle = (baseSpec != null && !string.IsNullOrEmpty(baseSpec.DisplayTitle))
                ? baseSpec.DisplayTitle
                : EpisodeParser.CleanAssetStem(cleanBaseName);

            string resolvedOutfitDesc = string.IsNullOrWhiteSpace(outfitDescription)
                ? EpisodeParser.GetStandardWardrobePresetDescription(ep, cleanBaseName, occasionLabel)
                : outfitDescription.Trim();

            string prompt = string.Format(
                "Crie uma imagem 9:16 vertical em animação 3D estilizada semi-realista (CGI) mantendo EXATAMENTE o mesmo personagem da imagem de referência anexada (mesmo rosto, mesma idade, mesma fisionomia, mesmo cabelo/penteado, mesma barba/expressão, mesmo corpo inteiro dos pés à cabeça, em pé, de frente, sobre fundo branco neutro puro #FFFFFF, com o texto \"{0}\" escrito no topo acima da cabeça), porém trocando COMPLETAMENTE a roupa anterior dele para '{1}' seguindo fielmente o contexto da história e da cena: {2} IMPORTANTE: Remova qualquer objeto segurado nas mãos na imagem original (sem canudo de diploma, sem pastas, sem caixas, deixando as duas mãos livres e vazias ao lado do corpo), remova becas ou aventais da roupa anterior (exceto se pedidos na nova roupa) e NÃO adicione óculos nem acessórios faciais que não existam no rosto original.",
                charTitle,
                EpisodeParser.FormatOutfitDisplayLabel(occasionLabel.Trim()),
                resolvedOutfitDesc);

            Exception lastErr = null;
            List<string> activeProfiles = _config.GetAvailableGrokProfiles(_log);
            foreach (string profile in activeProfiles)
            {
                ct.ThrowIfCancellationRequested();
                try
                {
                    _log(string.Format("[Grok Figurino] Gerando roupa '{0}' para '{1}' (mantendo o mesmo rosto via imagem de referência) no perfil '{2}'...",
                        occasionLabel, cleanBaseName, profile));

                    string sess = await _cdp.OpenOrAttachProfileTabAsync(profile, _config.GrokUrl, "grok.com", false, ct);
                    await WaitForGrokInteractiveReadyAsync(sess, ct);

                    if (await HasQuotaExhaustedBannerAsync(sess, ct))
                    {
                        _config.SetProfileStatus(profile, "LIMITE ATINGIDO");
                        continue;
                    }

                    string navUrl = _config.GrokUrl.Contains("#")
                        ? _config.GrokUrl
                        : (_config.GrokUrl + "#fvs_" + profile.Replace(" ", "_"));
                    await _cdp.SendCommandAsync("Page.navigate", new Dictionary<string, object> { { "url", navUrl } }, sess, 20000, ct);
                    await _cdp.WaitForDocumentReadyAsync(sess, 30000, ct);
                    await WaitForGrokInteractiveReadyAsync(sess, ct);

                    if (await HasQuotaExhaustedBannerAsync(sess, ct))
                    {
                        _config.SetProfileStatus(profile, "LIMITE ATINGIDO");
                        continue;
                    }

                    // Selecionar modo 'Imagem' e proporção '9:16' ANTES de anexar a imagem de referência
                    await EnsureGrokImageModeAnd9x16Async(sess, ct);

                    List<string> refFiles = new List<string> { baseImagePath };
                    bool attached = await _cdp.SetFileInputFilesByObjectIdAsync(
                        sess,
                        "document.querySelector('input[type=\"file\"][multiple]') || document.querySelector('input[type=\"file\"]')",
                        refFiles,
                        ct);

                    if (!attached)
                    {
                        await _cdp.UploadFilesViaFileChooserAsync(
                            sess,
                            async () =>
                            {
                                Dictionary<string, object> trPt = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var b = Array.from(document.querySelectorAll('button')).find(el => {
        var al = (el.getAttribute('aria-label') || '');
        return el.getBoundingClientRect().width > 10 &&
               (al.indexOf('Transferir') >= 0 || al.indexOf('Upload') >= 0 || al.indexOf('Anexar') >= 0 || al.indexOf('Attach') >= 0);
    });
    if (!b) return null;
    var r = b.getBoundingClientRect();
    return JSON.stringify({ x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) });
})()", ct);
                                if (trPt != null)
                                    await _cdp.ClickAtAsync(sess, Convert.ToInt32(trPt["x"]), Convert.ToInt32(trPt["y"]), ct);
                            },
                            refFiles,
                            ct);
                    }
                    await Task.Delay(2200, ct);

                    await _cdp.EvalStringAsync(sess, @"
(function(){
    window.__fvsBaselineOutfitImgs = Array.from(document.querySelectorAll('img'))
        .map(i => i.currentSrc || i.src || '')
        .filter(Boolean);
    return 'OK';
})()", ct);

                    int baselineImgs = await CountThumbnailsOrGeneratedImagesAsync(sess, ct);
                    bool inserted = await InjectPromptIntoGrokBoxAsync(sess, prompt, ct);
                    if (!inserted)
                        throw new InvalidOperationException("Caixa de prompt não encontrada no Grok Imagine.");

                    await Task.Delay(600, ct);
                    await SubmitGrokPromptAsync(sess, ct);

                    DateTime deadline = DateTime.UtcNow.AddMinutes(4);
                    int stable = 0;
                    while (DateTime.UtcNow < deadline)
                    {
                        ct.ThrowIfCancellationRequested();
                        await Task.Delay(3000, ct);

                        if (await HasQuotaExhaustedBannerAsync(sess, ct))
                        {
                            _config.SetProfileStatus(profile, "LIMITE ATINGIDO");
                            throw new InvalidOperationException("QUOTA_EXHAUSTED");
                        }

                        Dictionary<string, object> st = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var baseList = window.__fvsBaselineOutfitImgs || [];
    var candImgs = Array.from(document.querySelectorAll('img')).filter(img => {
        var s = (img.currentSrc || img.src || '');
        var r = img.getBoundingClientRect();
        return r.width >= 90 && r.height >= 120 && img.complete && img.naturalWidth >= 200 &&
               (s.indexOf('grok') >= 0 || s.indexOf('blob:') >= 0 || s.indexOf('assets') >= 0 || s.indexOf('imagine') >= 0);
    });
    var imgs = candImgs.length;
    var newImgs = candImgs.filter(img => baseList.indexOf(img.currentSrc || img.src || '') < 0).length;
    var spinners = Array.from(document.querySelectorAll('[role=""progressbar""], .animate-spin, svg.animate-spin')).filter(el => {
        var r = el.getBoundingClientRect();
        return r.width > 4 && r.height > 4;
    }).length;
    return JSON.stringify({ imgs: imgs, newImgs: newImgs, spinners: spinners });
})()", ct);

                        if (st == null) continue;
                        int imgs = Convert.ToInt32(st["imgs"]);
                        int newImgs = Convert.ToInt32(st["newImgs"]);
                        int spinners = Convert.ToInt32(st["spinners"]);

                        if ((newImgs > 0 || imgs > baselineImgs) && spinners == 0)
                        {
                            stable++;
                            if (stable >= 2) break;
                        }
                        else
                        {
                            stable = 0;
                        }
                    }

                    string stagingDir = Path.Combine(ep.AssetsDir, "_grok_outfit_" + DateTime.Now.ToString("HHmmss"));
                    Directory.CreateDirectory(stagingDir);
                    await _cdp.SetDownloadBehaviorAsync(stagingDir, ct);

                    Dictionary<string, object> dlPt = await FindGrokDownloadButtonPointAsync(sess, ct);
                    if (dlPt == null)
                    {
                        await EnsureThumbnailViewerOpenAsync(sess, 1, ct);
                        dlPt = await FindGrokDownloadButtonPointAsync(sess, ct);
                    }

                    if (dlPt == null)
                    {
                        try { Directory.Delete(stagingDir, true); } catch { }
                        throw new InvalidOperationException("Botão 'Baixar' não encontrado após gerar a nova roupa no Grok.");
                    }

                    HashSet<string> beforeFiles = new HashSet<string>(Directory.GetFiles(stagingDir), StringComparer.OrdinalIgnoreCase);
                    await _cdp.ClickAtAsync(sess, Convert.ToInt32(dlPt["x"]), Convert.ToInt32(dlPt["y"]), ct);
                    string savedFile = await _cdp.WaitForSingleDownloadAsync(stagingDir, beforeFiles, 30 * 1024, 35000, ct);
                    await _cdp.ResetDownloadBehaviorToDefaultAsync();

                    if (string.IsNullOrEmpty(savedFile))
                    {
                        try { Directory.Delete(stagingDir, true); } catch { }
                        throw new IOException("Timeout aguardando download da imagem da nova roupa no Grok.");
                    }

                    File.Copy(savedFile, variantFullPath, true);
                    try { Directory.Delete(stagingDir, true); } catch { }

                    if (copyToAllEpisodes && !string.IsNullOrEmpty(ep.StoryRootPath) && Directory.Exists(ep.StoryRootPath))
                    {
                        foreach (string sub in Directory.GetDirectories(ep.StoryRootPath))
                        {
                            if (Regex.IsMatch(Path.GetFileName(sub), @"^EP\.?\s*\d+$", RegexOptions.IgnoreCase))
                            {
                                string subAssets = Path.Combine(sub, "assets");
                                if (!Directory.Exists(subAssets)) Directory.CreateDirectory(subAssets);
                                string dstSub = Path.Combine(subAssets, variantFileName);
                                if (!string.Equals(dstSub, variantFullPath, StringComparison.OrdinalIgnoreCase))
                                {
                                    File.Copy(variantFullPath, dstSub, true);
                                }
                            }
                        }
                    }

                    _config.SetProfileStatus(profile, "DISPONÍVEL");
                    MirrorAssetsToTempFlow(ep.AssetsDir);
                    EpisodeParser.RefreshDiskCounters(ep);
                    _log(string.Format("[Grok Figurino] Nova roupa salva com sucesso: '{0}' e espelhada para Temp\\flow_assets!", variantFileName));
                    return variantFileName;
                }
                catch (OperationCanceledException)
                {
                    throw;
                }
                catch (Exception ex)
                {
                    lastErr = ex;
                    if (ex.Message == "QUOTA_EXHAUSTED")
                    {
                        _log(string.Format("[Grok Figurino] Limite atingido no perfil '{0}'. Alternando para o próximo perfil...", profile));
                        continue;
                    }
                    _log(string.Format("[Grok Figurino] Aviso no perfil '{0}': {1}. Tentando próximo perfil...", profile, ex.Message));
                }
            }

            if (_flowFallback != null && _config.AreAllGrokProfilesMarkedExhausted())
            {
                _log(string.Format("[Grok -> Google Flow | Sem Créditos] Todas as contas do Grok estão sem créditos -> gerando roupa '{0}' ('{1}') no Google Flow!",
                    occasionLabel, variantFileName));
                GrokAssetSpec outfitSpec = new GrokAssetSpec
                {
                    OrderIndex = 1,
                    IsScenario = false,
                    LabelPrefix = "Personagem",
                    DisplayTitle = charTitle,
                    TargetFileName = variantFileName,
                    RawPromptLine = prompt
                };
                await _flowFallback.GenerateMissingAssetsInFlowAsync(ep, new List<GrokAssetSpec> { outfitSpec }, ct);
                MirrorAssetsToTempFlow(ep.AssetsDir);
                EpisodeParser.RefreshDiskCounters(ep);
                return variantFileName;
            }

            throw new InvalidOperationException(
                "Não foi possível gerar a variante de roupa em nenhum dos perfis autorizados do Grok." +
                (lastErr != null ? " Último erro: " + lastErr.Message : ""));
        }

        public async Task<int> EnsureAutoDetectedCharacterOutfitsAsync(EpisodeWorkItem ep, CancellationToken ct)
        {
            if (ep == null || string.IsNullOrEmpty(ep.AssetsDir))
                return 0;

            List<CharacterWardrobeSpec> requiredSpecs = EpisodeParser.DetectRequiredCharacterOutfitsFromText(ep);
            if (requiredSpecs.Count == 0)
            {
                _log("[Grok Figurino Automático] O texto dos takes usa apenas a Roupa Padrão original dos personagens. Nenhuma roupa extra necessária.");
                return 0;
            }

            List<CharacterWardrobeSpec> missingSpecs = new List<CharacterWardrobeSpec>();
            foreach (CharacterWardrobeSpec req in requiredSpecs)
            {
                // Sincroniza se já existir em outro episódio da história
                EpisodeParser.GetCharacterOutfitVariantsOnDisk(ep, req.BaseCharacterFileName);

                string fullVarPath = Path.Combine(ep.AssetsDir, req.VariantFileName);
                bool existsOnDisk = File.Exists(fullVarPath) && new FileInfo(fullVarPath).Length > 10 * 1024;
                if (existsOnDisk)
                {
                    _log(string.Format("[Grok Figurino Automático] ✔ {0} ({1}) já pronta em disco -> {2}",
                        req.DisplayLabel, req.CharacterDisplayName, req.VariantFileName));
                    continue;
                }

                string baseCharPath = Path.Combine(ep.AssetsDir, req.BaseCharacterFileName);
                if (!File.Exists(baseCharPath) || new FileInfo(baseCharPath).Length <= 10 * 1024)
                {
                    _log(string.Format("[Grok Figurino Automático] Aviso: Personagem base '{0}' ainda não existe em assets\\; pulando geração de {1}.",
                        req.BaseCharacterFileName, req.DisplayLabel));
                    continue;
                }

                missingSpecs.Add(req);
            }

            if (missingSpecs.Count == 0)
            {
                _log(string.Format("[Grok Figurino Automático] Todas as {0} opções de roupa exigidas pelo texto já estão prontas!", requiredSpecs.Count));
                return 0;
            }

            _log(string.Format("[Grok Figurino Automático] Detectadas {0} opções de roupas necessárias de acordo com o texto ({1}). Gerando automaticamente no Grok mantendo o mesmo rosto...",
                missingSpecs.Count,
                string.Join(", ", missingSpecs.Select(m => m.CharacterDisplayName + ": " + m.DisplayLabel))));

            int generatedCount = 0;
            foreach (CharacterWardrobeSpec req in missingSpecs)
            {
                ct.ThrowIfCancellationRequested();
                _log(string.Format("[Grok Figurino Automático] Gerando {0} para '{1}' ({2})...",
                    req.DisplayLabel, req.CharacterDisplayName, req.ReasonFromText));

                await GenerateCharacterOutfitVariantAsync(
                    ep,
                    req.BaseCharacterFileName,
                    req.CategoryKey,
                    req.OutfitPromptDescription,
                    true,
                    ct);
                generatedCount++;
            }

            MirrorAssetsToTempFlow(ep.AssetsDir);
            EpisodeParser.RefreshDiskCounters(ep);
            _log(string.Format("[Grok Figurino Automático] Concluído! {0} novas opções de roupas geradas de acordo com o texto.", generatedCount));
            return generatedCount;
        }

        public async Task<int> EnsureOutfitsForTakesAsync(
            EpisodeWorkItem ep,
            List<int> targetTakeNumbers,
            CancellationToken ct)
        {
            if (ep == null || string.IsNullOrEmpty(ep.AssetsDir) || ep.FlowTakes == null)
                return 0;

            int totalGenerated = 0;

            // 1. Se for execução do episódio inteiro (sem filtro de take), garante todas as roupas padrão detectadas pelo texto da história
            if (targetTakeNumbers == null || targetTakeNumbers.Count == 0)
            {
                totalGenerated += await EnsureAutoDetectedCharacterOutfitsAsync(ep, ct);
            }

            // 2. Verifica especificamente os Takes que vão ser gerados/regerados (tanto no modo Automático pelo texto quanto escolhidos manualmente pelo usuário)
            HashSet<int> filterSet = (targetTakeNumbers != null && targetTakeNumbers.Count > 0)
                ? new HashSet<int>(targetTakeNumbers)
                : null;

            foreach (FlowTakeSpec take in ep.FlowTakes)
            {
                if (filterSet != null && !filterSet.Contains(take.TakeNumber))
                    continue;
                if (take.Ingredients == null)
                    continue;

                foreach (string rawIng in take.Ingredients)
                {
                    if (EpisodeParser.IsScenarioAssetName(rawIng))
                        continue;

                    string baseCharFile = EpisodeParser.GetBaseCharacterFileName(rawIng);
                    string effectiveOutfitFile = EpisodeParser.ResolveEffectiveIngredientForTake(ep, take, rawIng);

                    if (string.IsNullOrEmpty(effectiveOutfitFile) ||
                        string.Equals(effectiveOutfitFile, baseCharFile, StringComparison.OrdinalIgnoreCase) ||
                        effectiveOutfitFile.IndexOf("__Roupa_", StringComparison.OrdinalIgnoreCase) < 0)
                    {
                        continue;
                    }

                    // Sincroniza se já existir em outro episódio da mesma história
                    EpisodeParser.GetCharacterOutfitVariantsOnDisk(ep, baseCharFile);

                    string fullOutfitPath = Path.Combine(ep.AssetsDir, effectiveOutfitFile);
                    if (File.Exists(fullOutfitPath) && new FileInfo(fullOutfitPath).Length > 10 * 1024)
                    {
                        continue;
                    }

                    string baseCharPath = Path.Combine(ep.AssetsDir, baseCharFile);
                    if (!File.Exists(baseCharPath) || new FileInfo(baseCharPath).Length <= 10 * 1024)
                    {
                        _log(string.Format("[Grok Figurino] Aviso: Personagem base '{0}' não encontrado em assets\\; não foi possível gerar '{1}'.",
                            baseCharFile, effectiveOutfitFile));
                        continue;
                    }

                    string occKey = EpisodeParser.ExtractOutfitOccasionLabel(effectiveOutfitFile);
                    string stdCat = EpisodeParser.NormalizeStandardWardrobeCategory(occKey);
                    string dispLbl = EpisodeParser.FormatOutfitDisplayLabel(effectiveOutfitFile);
                    string desc = EpisodeParser.GetStandardWardrobePresetDescription(ep, baseCharFile, stdCat);

                    _log(string.Format("[Grok Figurino] Gerando primeiro '{0}' ({1}) para usar no Take_{2:00}...",
                        dispLbl, effectiveOutfitFile, take.TakeNumber));

                    await GenerateCharacterOutfitVariantAsync(ep, baseCharFile, stdCat, desc, true, ct);
                    totalGenerated++;
                }
            }

            MirrorAssetsToTempFlow(ep.AssetsDir);
            EpisodeParser.RefreshDiskCounters(ep);
            return totalGenerated;
        }
    }
}
