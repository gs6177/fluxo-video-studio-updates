using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace FluxoVideoStudio
{
    public class CapCutAutomation
    {
        private readonly PipelineConfig _config;
        private readonly Action<string> _log;

        public CapCutAutomation(PipelineConfig config, Action<string> logger)
        {
            _config = config;
            _log = logger ?? delegate { };
        }

        private void EnsureNarratorAudioInTakesDir(EpisodeWorkItem ep)
        {
            if (ep == null || !Directory.Exists(ep.TakesDir)) return;

            string[] existingAudioInTakes = Directory.GetFiles(ep.TakesDir)
                .Where(f => Regex.IsMatch(Path.GetExtension(f), @"^\.(wav|mp3|m4a)$", RegexOptions.IgnoreCase) && new FileInfo(f).Length > 1024)
                .ToArray();

            if (existingAudioInTakes.Length > 0)
            {
                return;
            }

            string targetWavInTakes = Path.Combine(ep.TakesDir, "Narrador_Take_01.wav");

            // 1. Verifica Narrador_Completo.wav (ou qualquer *narrador*.wav) na raiz do episódio (EP.X\)
            if (!string.IsNullOrEmpty(ep.EpisodePath) && Directory.Exists(ep.EpisodePath))
            {
                string rootWav = Path.Combine(ep.EpisodePath, "Narrador_Completo.wav");
                if (!File.Exists(rootWav) || new FileInfo(rootWav).Length <= 1024)
                {
                    rootWav = Directory.GetFiles(ep.EpisodePath, "*.wav", SearchOption.TopDirectoryOnly)
                        .FirstOrDefault(f => Path.GetFileName(f).IndexOf("narrador", StringComparison.OrdinalIgnoreCase) >= 0 && new FileInfo(f).Length > 1024);
                }

                if (!string.IsNullOrEmpty(rootWav) && File.Exists(rootWav))
                {
                    File.Copy(rootWav, targetWavInTakes, true);
                    _log(string.Format("[CapCut | Áudio] Restaurado '{0}' para a pasta takes\\ a partir de '{1}'!",
                        Path.GetFileName(targetWavInTakes), Path.GetFileName(rootWav)));
                    return;
                }

                // 2. Se houver apenas Narrador_Completo.mp3 na raiz do episódio, processa automaticamente o Travar Silêncio (-40dB / 0,3s) para .wav
                string rootMp3 = Path.Combine(ep.EpisodePath, "Narrador_Completo.mp3");
                if (!File.Exists(rootMp3) || new FileInfo(rootMp3).Length <= 1024)
                {
                    rootMp3 = Directory.GetFiles(ep.EpisodePath, "*.mp3", SearchOption.TopDirectoryOnly)
                        .FirstOrDefault(f => Path.GetFileName(f).IndexOf("narrador", StringComparison.OrdinalIgnoreCase) >= 0 && new FileInfo(f).Length > 1024);
                }

                if (!string.IsNullOrEmpty(rootMp3) && File.Exists(rootMp3))
                {
                    _log(string.Format("[CapCut | Áudio] Encontrado '{0}' na pasta do episódio -> gerando 'Narrador_Take_01.wav' (-40dB / 0,3s) para a Timeline...",
                        Path.GetFileName(rootMp3)));
                    ElevenLabsAutomation.RunSilenceTruncationToWav(_config, _log, rootMp3, targetWavInTakes);
                    string wavBackupRoot = Path.Combine(ep.EpisodePath, "Narrador_Completo.wav");
                    File.Copy(targetWavInTakes, wavBackupRoot, true);
                    return;
                }
            }

            // 3. Verifica subpastas _backup_* dentro de takes\ (caso um Modo Refazer anterior tenha movido o áudio)
            string[] backupDirs = Directory.GetDirectories(ep.TakesDir, "_backup_*", SearchOption.TopDirectoryOnly)
                .OrderByDescending(d => d)
                .ToArray();

            foreach (string bDir in backupDirs)
            {
                string backupAudio = Directory.GetFiles(bDir)
                    .FirstOrDefault(f => Regex.IsMatch(Path.GetExtension(f), @"^\.(wav|mp3|m4a)$", RegexOptions.IgnoreCase) && new FileInfo(f).Length > 1024);
                if (!string.IsNullOrEmpty(backupAudio))
                {
                    string destPath = Path.Combine(ep.TakesDir, Path.GetFileName(backupAudio));
                    File.Copy(backupAudio, destPath, true);
                    _log(string.Format("[CapCut | Áudio] Restaurado '{0}' de '{1}' para a Timeline!",
                        Path.GetFileName(backupAudio), Path.GetFileName(bDir)));
                    return;
                }
            }
        }

        public Task RunAsync(EpisodeWorkItem ep, string customProjectName, bool launchCapCut, CancellationToken ct)
        {
            return Task.Run(() =>
            {
                ct.ThrowIfCancellationRequested();

                if (!Directory.Exists(ep.TakesDir))
                    throw new DirectoryNotFoundException("Pasta takes não encontrada: " + ep.TakesDir);

                string[] videos = Directory.GetFiles(ep.TakesDir, "*.mp4", SearchOption.TopDirectoryOnly);
                if (videos.Length == 0)
                    throw new InvalidOperationException("Nenhum vídeo .mp4 encontrado em: " + ep.TakesDir);

                // Garante que o áudio do Narrador esteja presente em ep.TakesDir antes de montar o projeto CapCut
                EnsureNarratorAudioInTakesDir(ep);
                EpisodeParser.RefreshDiskCounters(ep);

                string[] audiosInTakes = Directory.GetFiles(ep.TakesDir)
                    .Where(f => Regex.IsMatch(Path.GetExtension(f), @"^\.(wav|mp3|m4a)$", RegexOptions.IgnoreCase) && new FileInfo(f).Length > 1024)
                    .OrderBy(f => Path.GetFileName(f))
                    .ToArray();

                if (!string.IsNullOrWhiteSpace(ep.UnifiedNarratorText) && audiosInTakes.Length == 0)
                {
                    _log("[CapCut | Aviso] Este episódio possui falas de Narrador no roteiro, mas o áudio ainda não foi gerado no ElevenLabs (Etapa 3).");
                }
                else if (audiosInTakes.Length > 0)
                {
                    _log(string.Format("[CapCut Desktop] Áudio(s) do Narrador confirmado(s) para a Faixa 2: {0}",
                        string.Join(", ", audiosInTakes.Select(Path.GetFileName))));
                }

                string scriptPath = Path.Combine(_config.SkillScriptsDir, "importar_para_capcut.ps1");
                if (!File.Exists(scriptPath))
                    throw new FileNotFoundException("Script importar_para_capcut.ps1 não encontrado.", scriptPath);

                string projName = string.IsNullOrWhiteSpace(customProjectName) ? ep.CapCutProjectName : customProjectName.Trim();
                string noLaunchSwitch = launchCapCut ? "" : " -NoLaunchCapCut";

                _log(string.Format("[CapCut Desktop] Montando projeto '{0}' com {1} takes de vídeo e {2} áudio(s) na Timeline (9:16)...",
                    projName, videos.Length, audiosInTakes.Length));

                ProcessStartInfo psi = new ProcessStartInfo
                {
                    FileName = "powershell.exe",
                    Arguments = string.Format(
                        "-NoProfile -ExecutionPolicy Bypass -File \"{0}\" -TakesFolder \"{1}\" -ProjectName \"{2}\"{3}",
                        scriptPath, ep.TakesDir, projName, noLaunchSwitch),
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    CreateNoWindow = true
                };

                using (Process p = Process.Start(psi))
                {
                    string stdout = p.StandardOutput.ReadToEnd();
                    string stderr = p.StandardError.ReadToEnd();
                    p.WaitForExit();

                    if (!string.IsNullOrWhiteSpace(stdout))
                        _log("[CapCut] " + stdout.Trim());

                    if (p.ExitCode != 0)
                    {
                        throw new InvalidOperationException(
                            string.Format("Erro ao montar projeto no CapCut Desktop (ExitCode {0}): {1}", p.ExitCode, stderr));
                    }
                }

                if (audiosInTakes.Length > 0)
                {
                    _log(string.Format("[CapCut Desktop] Projeto '{0}' montado com sucesso na Timeline (Faixa 1: {1} Vídeos | Faixa 2: {2} Áudio(s) do Narrador)!",
                        projName, videos.Length, audiosInTakes.Length));
                }
                else
                {
                    _log(string.Format("[CapCut Desktop] Projeto '{0}' montado com sucesso na Timeline (Faixa 1: {1} Vídeos | Sem Narrador)!",
                        projName, videos.Length));
                }
            }, ct);
        }
    }
}
