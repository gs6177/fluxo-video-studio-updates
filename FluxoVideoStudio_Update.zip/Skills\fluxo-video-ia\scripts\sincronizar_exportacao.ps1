param(
    [string]$SkillDir = (Join-Path $env:USERPROFILE ".gemini\config\skills\fluxo-video-ia"),
    [string]$SkillsRoot = (Join-Path $env:USERPROFILE ".gemini\config\skills"),
    [string]$ExportRoot = (Join-Path $env:USERPROFILE "Desktop\MEU TRABALHO")
)

$ErrorActionPreference = "Stop"
$Utf8NoBom = New-Object System.Text.UTF8Encoding($false)

if (-not (Test-Path $ExportRoot)) {
    New-Item -ItemType Directory -Path $ExportRoot -Force | Out-Null
}

$PackageDir = Join-Path $ExportRoot "Pacote_Skill_Fluxo_Video_IA"
$TargetSkillDir = Join-Path $PackageDir "fluxo-video-ia"
$CamaleaoFolderName = "Camale$([char]0x00E3)o part 1,2 e 3"
$TargetCamaleaoDir = Join-Path $PackageDir $CamaleaoFolderName
$TargetGemNovelaDir = Join-Path $PackageDir "gem-novela"
$TargetGemTerrorDir = Join-Path $PackageDir "gem-terror"
$ZipPath = Join-Path $ExportRoot "Pacote_Skill_Fluxo_Video_IA.zip"
$PromptTxtPath = Join-Path $ExportRoot "PROMPT_ATUALIZAR_OUTRO_AGENTE.txt"

# Limpa pasta antiga com nome corrompido se existir
Get-ChildItem -Path $PackageDir -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -like "Camale*" -and $_.Name -ne $CamaleaoFolderName } | Remove-Item -Recurse -Force

# 1. Sincroniza arquivos das 4 skills (fluxo-video-ia, camaleao, gem-novela e gem-terror) para a pasta do pacote
New-Item -ItemType Directory -Path (Join-Path $TargetSkillDir "scripts") -Force | Out-Null
Copy-Item -Path (Join-Path $SkillDir "SKILL.md") -Destination (Join-Path $TargetSkillDir "SKILL.md") -Force
Get-ChildItem -Path (Join-Path $SkillDir "scripts") -Filter "*.ps1" | ForEach-Object {
    Copy-Item -Path $_.FullName -Destination (Join-Path $TargetSkillDir "scripts\$($_.Name)") -Force
}

$CamaleaoDirObj = Get-ChildItem -Path $SkillsRoot -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -like "Camale*1,2 e 3" } | Select-Object -First 1
$CamaleaoSrc = if ($CamaleaoDirObj) { Join-Path $CamaleaoDirObj.FullName "SKILL.md" } else { Join-Path $SkillsRoot "$CamaleaoFolderName\SKILL.md" }
if (Test-Path $CamaleaoSrc) {
    New-Item -ItemType Directory -Path $TargetCamaleaoDir -Force | Out-Null
    Copy-Item -Path $CamaleaoSrc -Destination (Join-Path $TargetCamaleaoDir "SKILL.md") -Force
}

$GemNovelaSrc = Join-Path $SkillsRoot "gem-novela\SKILL.md"
if (Test-Path $GemNovelaSrc) {
    New-Item -ItemType Directory -Path $TargetGemNovelaDir -Force | Out-Null
    Copy-Item -Path $GemNovelaSrc -Destination (Join-Path $TargetGemNovelaDir "SKILL.md") -Force
}

$GemTerrorSrc = Join-Path $SkillsRoot "gem-terror\SKILL.md"
if (Test-Path $GemTerrorSrc) {
    New-Item -ItemType Directory -Path $TargetGemTerrorDir -Force | Out-Null
    Copy-Item -Path $GemTerrorSrc -Destination (Join-Path $TargetGemTerrorDir "SKILL.md") -Force
}

# 2. Atualiza o arquivo .ZIP de exportacao com nomes de arquivo em UTF-8 puro
if (Test-Path $ZipPath) {
    Remove-Item -Path $ZipPath -Force
}
Add-Type -AssemblyName System.IO.Compression.FileSystem
[System.IO.Compression.ZipFile]::CreateFromDirectory(
    $PackageDir,
    $ZipPath,
    [System.IO.Compression.CompressionLevel]::Optimal,
    $false,
    [System.Text.Encoding]::UTF8
)

# 3. Gera o arquivo PROMPT_ATUALIZAR_OUTRO_AGENTE.txt sempre atualizado
$SkillMdContent   = [System.IO.File]::ReadAllText((Join-Path $SkillDir "SKILL.md"), [System.Text.Encoding]::UTF8)
$CamaleaoContent  = if (Test-Path $CamaleaoSrc) { [System.IO.File]::ReadAllText($CamaleaoSrc, [System.Text.Encoding]::UTF8) } else { "" }
$GemNovelaContent = if (Test-Path $GemNovelaSrc) { [System.IO.File]::ReadAllText($GemNovelaSrc, [System.Text.Encoding]::UTF8) } else { "" }
$GemTerrorContent = if (Test-Path $GemTerrorSrc) { [System.IO.File]::ReadAllText($GemTerrorSrc, [System.Text.Encoding]::UTF8) } else { "" }
$AutoAllowContent = [System.IO.File]::ReadAllText((Join-Path $SkillDir "scripts\auto_allow_chrome.ps1"), [System.Text.Encoding]::UTF8)
$CapCutContent    = [System.IO.File]::ReadAllText((Join-Path $SkillDir "scripts\importar_para_capcut.ps1"), [System.Text.Encoding]::UTF8)
$ProcAudioContent = [System.IO.File]::ReadAllText((Join-Path $SkillDir "scripts\processar_audio_narrador.ps1"), [System.Text.Encoding]::UTF8)
$CdpHelperContent = if (Test-Path (Join-Path $SkillDir "scripts\cdp_helper.ps1")) { [System.IO.File]::ReadAllText((Join-Path $SkillDir "scripts\cdp_helper.ps1"), [System.Text.Encoding]::UTF8) } else { "" }
$SyncContent      = [System.IO.File]::ReadAllText((Join-Path $SkillDir "scripts\sincronizar_exportacao.ps1"), [System.Text.Encoding]::UTF8)

$PromptBuilder = @"
Por favor, crie ou atualize as minhas skills globais `fluxo-video-ia`, `$CamaleaoFolderName`, `gem-novela` e `gem-terror` na pasta `\$env:USERPROFILE\.gemini\config\skills\` com todas as instrucoes, memoria de autoaprendizagem e scripts abaixo.

Se este computador tiver nomes ou numeros de perfis do Chrome (`Profile X`) diferentes para o Grok Imagine, Google Flow ou ElevenLabs, verifique em `\$env:LOCALAPPDATA\Google\Chrome\User Data\Local State` quais sao os perfis deste PC ou me pergunte para ajustarmos no `SKILL.md`.

Crie/sobrescreva exatamente estes 9 arquivos:

====================================================================
ARQUIVO 1: `$env:USERPROFILE\.gemini\config\skills\fluxo-video-ia\SKILL.md
====================================================================
$SkillMdContent

====================================================================
ARQUIVO 2: `$env:USERPROFILE\.gemini\config\skills\$CamaleaoFolderName\SKILL.md
====================================================================
$CamaleaoContent

====================================================================
ARQUIVO 3: `$env:USERPROFILE\.gemini\config\skills\gem-novela\SKILL.md
====================================================================
$GemNovelaContent

====================================================================
ARQUIVO 4: `$env:USERPROFILE\.gemini\config\skills\gem-terror\SKILL.md
====================================================================
$GemTerrorContent

====================================================================
ARQUIVO 5: `$env:USERPROFILE\.gemini\config\skills\fluxo-video-ia\scripts\auto_allow_chrome.ps1
====================================================================
$AutoAllowContent

====================================================================
ARQUIVO 6: `$env:USERPROFILE\.gemini\config\skills\fluxo-video-ia\scripts\importar_para_capcut.ps1
====================================================================
$CapCutContent

====================================================================
ARQUIVO 7: `$env:USERPROFILE\.gemini\config\skills\fluxo-video-ia\scripts\processar_audio_narrador.ps1
====================================================================
$ProcAudioContent

====================================================================
ARQUIVO 8: `$env:USERPROFILE\.gemini\config\skills\fluxo-video-ia\scripts\cdp_helper.ps1
====================================================================
$CdpHelperContent

====================================================================
ARQUIVO 9: `$env:USERPROFILE\.gemini\config\skills\fluxo-video-ia\scripts\sincronizar_exportacao.ps1
====================================================================
$SyncContent
"@

[System.IO.File]::WriteAllText($PromptTxtPath, $PromptBuilder, $Utf8NoBom)

Write-Host "=====================================================" -ForegroundColor Green
Write-Host "PACOTE DE EXPORTACAO E TEXTO ATUALIZADOS COM SUCESSO!" -ForegroundColor Green
Write-Host "Pasta : $PackageDir" -ForegroundColor Cyan
Write-Host "ZIP   : $ZipPath" -ForegroundColor Cyan
Write-Host "Texto : $PromptTxtPath" -ForegroundColor Cyan
Write-Host "=====================================================" -ForegroundColor Green
