using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Web.Script.Serialization;

namespace FluxoVideoStudio
{
    public static partial class EpisodeParser
    {
        public static void ParseFlowTakes(
            string flowText,
            List<FlowTakeSpec> takesOut,
            List<string> uniqueIngredientsOut,
            Dictionary<string, string> titleToFileOut)
        {
            takesOut.Clear();
            uniqueIngredientsOut.Clear();
            titleToFileOut.Clear();

            if (string.IsNullOrWhiteSpace(flowText)) return;

            // Map inline patterns like: O Vaqueiro Pobre (01_Personagem_1_O_Vaqueiro_Pobre.jpg) OR A Esposa ([A_Esposa.jpg])
            MatchCollection inlineRefs = Regex.Matches(flowText, @"([A-ZÀ-Úa-zà-ú0-9][A-ZÀ-Úa-zà-ú0-9\s'\-]{1,48}?)\s*\(\[?([A-Za-z0-9_\-\.]+\.(?:jpg|jpeg|png))\]?\)", RegexOptions.CultureInvariant);
            foreach (Match m in inlineRefs)
            {
                string rawTitle = CleanArchetypeTitle(m.Groups[1].Value);
                string fname = m.Groups[2].Value.Trim();
                if (!string.IsNullOrEmpty(rawTitle) && !titleToFileOut.ContainsKey(rawTitle))
                {
                    titleToFileOut[rawTitle] = fname;
                }
            }

            string[] lines = flowText.Split(new[] { "\r\n", "\n" }, StringSplitOptions.None);
            FlowTakeSpec current = null;
            StringBuilder bodyBuilder = new StringBuilder();
            HashSet<string> seenIng = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            for (int i = 0; i < lines.Length; i++)
            {
                string line = lines[i];
                Match headerMatch = Regex.Match(line, @"Take\s*0*(\d+)\s*\|", RegexOptions.IgnoreCase);
                if (headerMatch.Success)
                {
                    if (current != null)
                    {
                        current.RawPromptBody = bodyBuilder.ToString().Trim();
                        takesOut.Add(current);
                    }

                    current = new FlowTakeSpec();
                    int tNum;
                    int.TryParse(headerMatch.Groups[1].Value, out tNum);
                    current.TakeNumber = tNum;
                    current.RawHeader = line.Trim();
                    current.HasSpeech = line.IndexOf("Sem Fala", StringComparison.OrdinalIgnoreCase) < 0;
                    bodyBuilder.Clear();

                    Match scenMatch = Regex.Match(line, @"Cen[aá]rio:\s*([^|]+)", RegexOptions.IgnoreCase);
                    if (scenMatch.Success) current.ScenarioName = scenMatch.Groups[1].Value.Trim();

                    Match ingMatch = Regex.Match(line, @"Ingredientes\s*Obrigat[oó]rios:\s*([^|]+)", RegexOptions.IgnoreCase);
                    if (ingMatch.Success)
                    {
                        MatchCollection files = Regex.Matches(ingMatch.Groups[1].Value, @"[A-Za-z0-9_\-\.]+\.(?:jpg|jpeg|png)", RegexOptions.IgnoreCase);
                        foreach (Match fm in files)
                        {
                            string fn = fm.Value.Trim();
                            if (!current.Ingredients.Contains(fn, StringComparer.OrdinalIgnoreCase))
                                current.Ingredients.Add(fn);
                            if (seenIng.Add(fn))
                                uniqueIngredientsOut.Add(fn);
                        }

                        // Map ScenarioName -> last ingredient file (usually scenario)
                        if (!string.IsNullOrEmpty(current.ScenarioName) && current.Ingredients.Count > 0)
                        {
                            string lastIng = current.Ingredients[current.Ingredients.Count - 1];
                            if (!titleToFileOut.ContainsKey(current.ScenarioName))
                                titleToFileOut[current.ScenarioName] = lastIng;
                        }
                    }
                }
                else if (current != null)
                {
                    bodyBuilder.AppendLine(line);
                }
            }

            if (current != null)
            {
                current.RawPromptBody = bodyBuilder.ToString().Trim();
                takesOut.Add(current);
            }
        }

        private static string CleanArchetypeTitle(string raw)
        {
            if (string.IsNullOrWhiteSpace(raw)) return "";
            string s = raw.Trim();
            string[] prefixes = new[]
            {
                "O homem adulto ", "o homem adulto ",
                "A mulher adulta ", "a mulher adulta ",
                "estão na ", "estão no ", "está na ", "está no ",
                "caminham pela ", "caminham pelo ", "em ", "na ", "no ", "e "
            };
            bool changed = true;
            while (changed)
            {
                changed = false;
                foreach (string p in prefixes)
                {
                    if (s.StartsWith(p, StringComparison.OrdinalIgnoreCase) && s.Length > p.Length + 2)
                    {
                        s = s.Substring(p.Length).Trim();
                        changed = true;
                    }
                }
            }
            return s;
        }

        public static void ParseGrokSpecs(
            string grokText,
            Dictionary<string, string> flowTitleMap,
            List<string> requiredFlowIngredients,
            List<GrokAssetSpec> specsOut)
        {
            specsOut.Clear();
            if (string.IsNullOrWhiteSpace(grokText)) return;

            string[] lines = grokText.Split(new[] { "\r\n", "\n" }, StringSplitOptions.RemoveEmptyEntries);
            int idx = 0;

            foreach (string rawLine in lines)
            {
                string line = rawLine.Trim();
                Match itemMatch = Regex.Match(line, @"^-\s*(Personagem\s*\d+[A-Za-z]?|Cen[aá]rio\s*[A-Z0-9]+)\s*:\s*(.+)$", RegexOptions.IgnoreCase);
                if (!itemMatch.Success) continue;

                idx++;
                GrokAssetSpec spec = new GrokAssetSpec();
                spec.OrderIndex = idx;
                spec.LabelPrefix = itemMatch.Groups[1].Value.Trim();
                spec.IsScenario = spec.LabelPrefix.StartsWith("Cen", StringComparison.OrdinalIgnoreCase);
                spec.RawPromptLine = line;

                string rest = itemMatch.Groups[2].Value.Trim();

                // 1. Check explicit filename in parentheses/brackets e.g. O Marido (O_Marido.jpg) or ([O_Marido.jpg])
                string explicitFile = "";
                Match fileParenMatch = Regex.Match(rest, @"[\(\[]+([A-Za-z0-9_\-\.]+\.(?:jpg|jpeg|png))[\)\]]+", RegexOptions.IgnoreCase);
                if (fileParenMatch.Success)
                {
                    explicitFile = fileParenMatch.Groups[1].Value.Trim();
                }

                // 2. Extract DisplayTitle written on top of image
                string displayTitle = "";
                Match quotedTitle = Regex.Match(line, @"(?:Escrito|Nome)\s+""([^""]+)""", RegexOptions.IgnoreCase);
                if (quotedTitle.Success)
                {
                    displayTitle = quotedTitle.Groups[1].Value.Trim();
                }
                else
                {
                    int dashIdx = rest.IndexOf(" - ");
                    string beforeDash = dashIdx > 0 ? rest.Substring(0, dashIdx).Trim() : rest;
                    beforeDash = Regex.Replace(beforeDash, @"[\(\[]+[A-Za-z0-9_\-\.]+\.(?:jpg|jpeg|png)[\)\]]+", "", RegexOptions.IgnoreCase).Trim();
                    beforeDash = Regex.Replace(beforeDash, @"^em\s+cima\s+da\s+cabe[cç]a\s+", "", RegexOptions.IgnoreCase).Trim();
                    displayTitle = beforeDash;
                }
                spec.DisplayTitle = displayTitle;

                // 3. Resolve TargetFileName
                if (!string.IsNullOrEmpty(explicitFile))
                {
                    spec.TargetFileName = explicitFile;
                }
                else
                {
                    string mapped = FindBestMappedFilename(displayTitle, spec.IsScenario, flowTitleMap, requiredFlowIngredients);
                    if (!string.IsNullOrEmpty(mapped))
                    {
                        spec.TargetFileName = mapped;
                    }
                    else
                    {
                        string prefixSlug = Slugify(spec.LabelPrefix);
                        string titleSlug = Slugify(displayTitle);
                        spec.TargetFileName = string.Format("{0:00}_{1}_{2}.jpg", idx, prefixSlug, titleSlug);
                    }
                }

                specsOut.Add(spec);
            }
        }

        private static string FindBestMappedFilename(
            string displayTitle,
            bool isScenario,
            Dictionary<string, string> flowTitleMap,
            List<string> requiredFlowIngredients)
        {
            if (string.IsNullOrWhiteSpace(displayTitle)) return "";

            if (flowTitleMap != null && flowTitleMap.Count > 0)
            {
                string exact;
                if (flowTitleMap.TryGetValue(displayTitle, out exact)) return exact;
            }

            string normTarget = NormalizeForCompare(displayTitle);
            string bestFile = "";
            double bestScore = 0.0;

            if (flowTitleMap != null)
            {
                foreach (KeyValuePair<string, string> kv in flowTitleMap)
                {
                    double score = ComputeTextSimilarity(normTarget, NormalizeForCompare(kv.Key));
                    double fileScore = ComputeTextSimilarity(normTarget, NormalizeForCompare(Path.GetFileNameWithoutExtension(kv.Value).Replace("_", " ")));
                    double max = Math.Max(score, fileScore);
                    if (max > bestScore)
                    {
                        bestScore = max;
                        bestFile = kv.Value;
                    }
                }
            }

            if (requiredFlowIngredients != null)
            {
                foreach (string ingFile in requiredFlowIngredients)
                {
                    string cleanedStem = CleanAssetStem(ingFile);
                    double score = ComputeTextSimilarity(normTarget, NormalizeForCompare(cleanedStem));
                    bool typeMatches = isScenario
                        ? ingFile.IndexOf("Cenario", StringComparison.OrdinalIgnoreCase) >= 0 || bestScore < 0.5
                        : ingFile.IndexOf("Cenario", StringComparison.OrdinalIgnoreCase) < 0;
                    if (typeMatches && score > bestScore)
                    {
                        bestScore = score;
                        bestFile = ingFile;
                    }
                }
            }

            return bestScore >= 0.52 ? bestFile : "";
        }

        public static string ExtractNarratorFromRoteiro(string roteiroText, out int segmentCount)
        {
            segmentCount = 0;
            if (string.IsNullOrWhiteSpace(roteiroText)) return "";

            List<string> paragraphs = new List<string>();
            string[] lines = roteiroText.Split(new[] { "\r\n", "\n" }, StringSplitOptions.RemoveEmptyEntries);

            foreach (string rawLine in lines)
            {
                string line = rawLine.Trim();
                Match narMatch = Regex.Match(line, @"(?:O\s+Narrador|Narrador)\s*:\s*(.+)$", RegexOptions.IgnoreCase);
                if (!narMatch.Success) continue;

                string speechPart = narMatch.Groups[1].Value.Trim();

                // Extract quoted speech if enclosed in quotes
                Match quoted = Regex.Match(speechPart, @"""([^""]+)""");
                string cleanSpeech;
                if (quoted.Success)
                {
                    cleanSpeech = quoted.Groups[1].Value.Trim();
                }
                else
                {
                    // Remove trailing (ação) and {148 caracteres}
                    cleanSpeech = Regex.Replace(speechPart, @"\{\s*\d+\s*caracteres[^}]*\}", "", RegexOptions.IgnoreCase);
                    cleanSpeech = Regex.Replace(cleanSpeech, @"\([^)]*\)\s*$", "").Trim();
                    cleanSpeech = cleanSpeech.Trim('"');
                }

                if (!string.IsNullOrWhiteSpace(cleanSpeech))
                {
                    paragraphs.Add(cleanSpeech);
                }
            }

            segmentCount = paragraphs.Count;
            return string.Join("\n\n", paragraphs);
        }

        public static string NormalizeForCompare(string input)
        {
            if (string.IsNullOrWhiteSpace(input)) return "";
            string formD = input.Normalize(NormalizationForm.FormD);
            StringBuilder sb = new StringBuilder();
            foreach (char ch in formD)
            {
                UnicodeCategory uc = CharUnicodeInfo.GetUnicodeCategory(ch);
                if (uc != UnicodeCategory.NonSpacingMark)
                {
                    if (char.IsLetterOrDigit(ch))
                        sb.Append(char.ToLowerInvariant(ch));
                    else
                        sb.Append(' ');
                }
            }
            return Regex.Replace(sb.ToString(), @"\s+", " ").Trim();
        }

        public static double ComputeTextSimilarity(string a, string b)
        {
            string na = NormalizeForCompare(a);
            string nb = NormalizeForCompare(b);
            if (string.IsNullOrEmpty(na) || string.IsNullOrEmpty(nb)) return 0.0;
            if (na == nb) return 1.0;
            if (na.Contains(nb) || nb.Contains(na))
            {
                int minLen = Math.Min(na.Length, nb.Length);
                int maxLen = Math.Max(na.Length, nb.Length);
                return 0.75 + (0.25 * minLen / Math.Max(1, maxLen));
            }

            string[] tokA = na.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries).Where(t => t.Length > 1).ToArray();
            string[] tokB = nb.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries).Where(t => t.Length > 1).ToArray();
            double tokenScore = 0.0;
            if (tokA.Length > 0 && tokB.Length > 0)
            {
                int matches = tokA.Count(ta => tokB.Any(tb => tb == ta || (ta.Length >= 4 && tb.StartsWith(ta.Substring(0, 4)))));
                tokenScore = (2.0 * matches) / (tokA.Length + tokB.Length);
            }

            int dist = LevenshteinDistance(na, nb);
            double editScore = 1.0 - ((double)dist / Math.Max(na.Length, nb.Length));
            return Math.Max(tokenScore, editScore);
        }

        private static int LevenshteinDistance(string s, string t)
        {
            int n = s.Length;
            int m = t.Length;
            int[,] d = new int[n + 1, m + 1];
            for (int i = 0; i <= n; i++) d[i, 0] = i;
            for (int j = 0; j <= m; j++) d[0, j] = j;
            for (int i = 1; i <= n; i++)
            {
                for (int j = 1; j <= m; j++)
                {
                    int cost = (t[j - 1] == s[i - 1]) ? 0 : 1;
                    d[i, j] = Math.Min(
                        Math.Min(d[i - 1, j] + 1, d[i, j - 1] + 1),
                        d[i - 1, j - 1] + cost);
                }
            }
            return d[n, m];
        }

        public static string Slugify(string text)
        {
            string norm = NormalizeForCompare(text);
            if (string.IsNullOrEmpty(norm)) return "Item";
            string[] parts = norm.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            for (int i = 0; i < parts.Length; i++)
            {
                if (parts[i].Length > 1)
                    parts[i] = char.ToUpperInvariant(parts[i][0]) + parts[i].Substring(1);
                else
                    parts[i] = parts[i].ToUpperInvariant();
            }
            return string.Join("_", parts);
        }

    }
}
