using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Web.Script.Serialization;

namespace FluxoVideoStudio
{
    public static partial class EpisodeParser
    {
        public static string CustomNovelaRoot { get; set; }
        public static string CustomTerrorRoot { get; set; }

        private static List<string> GetCandidateDesktopFolders()
        {
            List<string> dirs = new List<string>();
            string d1 = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
            if (!string.IsNullOrEmpty(d1)) dirs.Add(d1);

            string userProf = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
            if (!string.IsNullOrEmpty(userProf))
            {
                string d2 = Path.Combine(userProf, "Desktop");
                string d3 = Path.Combine(userProf, @"OneDrive\Desktop");
                if (!dirs.Contains(d2, StringComparer.OrdinalIgnoreCase)) dirs.Add(d2);
                if (!dirs.Contains(d3, StringComparer.OrdinalIgnoreCase)) dirs.Add(d3);
            }

            try
            {
                string appDir = PipelineConfig.GetAppRootDir();
                DirectoryInfo cur = new DirectoryInfo(appDir);
                for (int i = 0; i < 4 && cur != null; i++)
                {
                    if (!dirs.Contains(cur.FullName, StringComparer.OrdinalIgnoreCase))
                        dirs.Add(cur.FullName);
                    cur = cur.Parent;
                }
            }
            catch { }

            return dirs;
        }

        public static string GetNovelaRoot()
        {
            if (!string.IsNullOrWhiteSpace(CustomNovelaRoot))
                return CustomNovelaRoot.Trim();

            foreach (string d in GetCandidateDesktopFolders())
            {
                string p = Path.Combine(d, @"MEU TRABALHO\_videos de reflexão");
                if (Directory.Exists(p)) return p;
                string pDirect = Path.Combine(d, "_videos de reflexão");
                if (Directory.Exists(pDirect)) return pDirect;
            }
            string desktop = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
            return Path.Combine(desktop, @"MEU TRABALHO\_videos de reflexão");
        }

        public static string GetTerrorRoot()
        {
            if (!string.IsNullOrWhiteSpace(CustomTerrorRoot))
                return CustomTerrorRoot.Trim();

            foreach (string d in GetCandidateDesktopFolders())
            {
                string p = Path.Combine(d, @"MEU TRABALHO\_Videos terror");
                if (Directory.Exists(p)) return p;
                string pDirect = Path.Combine(d, "_Videos terror");
                if (Directory.Exists(pDirect)) return pDirect;
            }
            string desktop = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
            return Path.Combine(desktop, @"MEU TRABALHO\_Videos terror");
        }

        public static List<StoryProject> DiscoverAllStories()
        {
            List<StoryProject> list = new List<StoryProject>();
            ScanGenreRoot(GetNovelaRoot(), GenreType.NovelaReflexao, list);
            ScanGenreRoot(GetTerrorRoot(), GenreType.Terror, list);
            return list.OrderByDescending(s => s.LastModified).ToList();
        }

        private static void ScanGenreRoot(string rootDir, GenreType genre, List<StoryProject> output)
        {
            if (!Directory.Exists(rootDir)) return;
            foreach (string dir in Directory.GetDirectories(rootDir))
            {
                StoryProject proj = LoadStoryFolder(dir, genre);
                if (proj != null && proj.Episodes.Count > 0)
                {
                    output.Add(proj);
                }
            }
        }

        public static StoryProject LoadStoryFolder(string storyFolder, GenreType genre)
        {
            if (!Directory.Exists(storyFolder)) return null;
            DirectoryInfo di = new DirectoryInfo(storyFolder);

            StoryProject proj = new StoryProject();
            proj.Name = di.Name;
            proj.Genre = genre;
            proj.FolderPath = di.FullName;
            proj.LastModified = di.LastWriteTime;

            string[] subDirs = Directory.GetDirectories(storyFolder);
            List<string> epDirs = subDirs
                .Where(d => Regex.IsMatch(Path.GetFileName(d), @"^EP\.?\s*\d+$", RegexOptions.IgnoreCase))
                .OrderBy(d => Path.GetFileName(d))
                .ToList();

            if (epDirs.Count > 0)
            {
                foreach (string epDir in epDirs)
                {
                    EpisodeWorkItem ep = ParseEpisodeFolder(epDir, proj.Name, genre, storyFolder);
                    if (ep != null)
                    {
                        proj.Episodes.Add(ep);
                        DateTime lw = Directory.GetLastWriteTime(epDir);
                        if (lw > proj.LastModified) proj.LastModified = lw;
                    }
                }
            }
            else
            {
                // Caso seja uma pasta única direta com prompt_flow / prompt_grok
                bool hasPrompt = Directory.GetFiles(storyFolder, "*.txt", SearchOption.TopDirectoryOnly)
                    .Any(f => Path.GetFileName(f).IndexOf("prompt_", StringComparison.OrdinalIgnoreCase) >= 0 ||
                              Path.GetFileName(f).IndexOf("passo3", StringComparison.OrdinalIgnoreCase) >= 0);
                if (hasPrompt)
                {
                    EpisodeWorkItem ep = ParseEpisodeFolder(storyFolder, proj.Name, genre, storyFolder);
                    if (ep != null)
                    {
                        ep.EpisodeName = "EP.1";
                        proj.Episodes.Add(ep);
                    }
                }
            }

            if (proj.Episodes.Any(e => e.Genre == GenreType.Terror))
            {
                proj.Genre = GenreType.Terror;
                foreach (EpisodeWorkItem ep in proj.Episodes) ep.Genre = GenreType.Terror;
            }
            else if (proj.Episodes.Any(e => e.Genre == GenreType.NovelaMistica))
            {
                proj.Genre = GenreType.NovelaMistica;
                foreach (EpisodeWorkItem ep in proj.Episodes) ep.Genre = GenreType.NovelaMistica;
            }

            return proj;
        }

        private static GenreType DetectRefinedEpisodeGenre(
            GenreType baseGenre,
            string[] epTxtFiles,
            string storyName,
            string grokPromptText,
            string roteiroText)
        {
            if (baseGenre == GenreType.Terror)
                return GenreType.Terror;

            bool hasGemTerror = false;
            bool hasGemMistica = false;
            bool hasPlainGemNovela = false;

            if (epTxtFiles != null)
            {
                for (int i = 0; i < epTxtFiles.Length; i++)
                {
                    string fn = Path.GetFileName(epTxtFiles[i] ?? "").ToLowerInvariant();
                    if (fn.IndexOf("gem_terror") >= 0)
                        hasGemTerror = true;
                    else if (fn.IndexOf("novela_mistica") >= 0 || fn.IndexOf("novela_afro") >= 0 || fn.IndexOf("mistica") >= 0)
                        hasGemMistica = true;
                    else if (fn == "prompts_gem_novela.txt")
                        hasPlainGemNovela = true;
                }
            }

            if (hasGemTerror)
                return GenreType.Terror;
            if (hasGemMistica)
                return GenreType.NovelaMistica;
            if (hasPlainGemNovela)
                return GenreType.NovelaReflexao;

            string combined = string.Format("{0}\n{1}\n{2}", storyName ?? "", grokPromptText ?? "", roteiroText ?? "");
            if (Regex.IsMatch(
                combined,
                @"(M[ãa]e\s+de\s+Santo|Mae_de_Santo|Casa_da_Mae_de_Santo|Novela\s+M[ií]stica|trabalho\s+espiritual|\bterreiro\b)",
                RegexOptions.IgnoreCase))
            {
                return GenreType.NovelaMistica;
            }

            return baseGenre == GenreType.Custom ? GenreType.NovelaReflexao : baseGenre;
        }

        public static EpisodeWorkItem ParseEpisodeFolder(string epDir, string storyName, GenreType genre, string storyRoot)
        {
            if (!Directory.Exists(epDir)) return null;

            EpisodeWorkItem item = new EpisodeWorkItem();
            item.StoryName = storyName;
            item.Genre = genre;
            item.StoryRootPath = storyRoot;
            item.EpisodePath = epDir;
            item.EpisodeName = Path.GetFileName(epDir);

            Match epNumMatch = Regex.Match(item.EpisodeName, @"(\d+)");
            int epNum;
            if (epNumMatch.Success && int.TryParse(epNumMatch.Groups[1].Value, out epNum))
            {
                item.EpisodeNumber = epNum;
            }

            item.AssetsDir = Path.Combine(epDir, "assets");
            item.TakesDir = Path.Combine(epDir, "takes");

            string[] txtFiles = Directory.GetFiles(epDir, "*.txt", SearchOption.TopDirectoryOnly);

            item.GrokPromptPath = FindBestFile(txtFiles, new[] { "prompt_grok_passo1_e_2.txt", "prompt_grok", "comandos_gemini_completos" });
            item.FlowPromptPath = FindBestFile(txtFiles, new[] { "prompt_flow_passo3.txt", "prompt_flow", "passo3_takes" });
            item.NarradorTxtPath = FindBestFile(txtFiles, new[] { "narrador_unificado", "narrador" });
            item.RoteiroPath = FindBestFile(txtFiles, new[] { "roteiro.txt", "roteiro_camaleao", "roteiro_parte", "roteiro" },
                excludeSubstrings: new[] { "decupado", "gem_" });

            if (!string.IsNullOrEmpty(item.GrokPromptPath) && File.Exists(item.GrokPromptPath))
                item.GrokPromptText = ReadUtf8(item.GrokPromptPath);

            if (!string.IsNullOrEmpty(item.FlowPromptPath) && File.Exists(item.FlowPromptPath))
                item.FlowPromptText = ReadUtf8(item.FlowPromptPath);

            if (!string.IsNullOrEmpty(item.RoteiroPath) && File.Exists(item.RoteiroPath))
                item.RoteiroText = ReadUtf8(item.RoteiroPath);

            item.Genre = DetectRefinedEpisodeGenre(genre, txtFiles, storyName, item.GrokPromptText, item.RoteiroText);

            // 1. Parse Flow Takes + Title->Filename map
            Dictionary<string, string> titleToFilenameMap = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            ParseFlowTakes(item.FlowPromptText, item.FlowTakes, item.AllRequiredFlowIngredients, titleToFilenameMap);

            // 2. Parse Grok Specs (correlating with Flow Title->Filename map & required ingredient filenames)
            ParseGrokSpecs(item.GrokPromptText, titleToFilenameMap, item.AllRequiredFlowIngredients, item.GrokSpecs);

            // 3. Parse Narrator Speech
            if (!string.IsNullOrEmpty(item.NarradorTxtPath) && File.Exists(item.NarradorTxtPath))
            {
                string rawNar = ReadUtf8(item.NarradorTxtPath).Trim();
                item.UnifiedNarratorText = rawNar;
                item.NarratorSegmentsCount = string.IsNullOrWhiteSpace(rawNar)
                    ? 0
                    : Regex.Split(rawNar, @"(\r?\n){2,}").Count(p => !string.IsNullOrWhiteSpace(p));
            }
            else
            {
                int segCount;
                item.UnifiedNarratorText = ExtractNarratorFromRoteiro(item.RoteiroText, out segCount);
                item.NarratorSegmentsCount = segCount;
            }

            LoadEpisodeCustomTakesConfig(item);
            RefreshDiskCounters(item);
            return item;
        }

        public static bool IsScenarioAssetName(string fileName)
        {
            if (string.IsNullOrEmpty(fileName)) return false;
            return Regex.IsMatch(
                fileName,
                @"(^|_)(Cenario|Quarto|Sala|Cozinha|Rua|Casa|Sitio|Curral|Feira|Cabana|Encruzilhada|Casarao|Estabulo|Barraca|Calcada|Lanchonete|Deposito|Fazenda|Praca|Igreja|Hospital|Escritorio|Obra|Quintal)(_|\.)",
                RegexOptions.IgnoreCase);
        }

        public static string CleanAssetStem(string fileName)
        {
            if (string.IsNullOrEmpty(fileName)) return "";
            string stem = Path.GetFileNameWithoutExtension(fileName);
            stem = Regex.Replace(stem, @"^(\d+_)?(Personagem_\d+_|Cenario_(?:[A-Za-z]|\d{1,2})_|Cenario_)", "", RegexOptions.IgnoreCase);
            return stem.Replace("_", " ").Trim();
        }

        public static int SyncLocalSubfolderAssets(EpisodeWorkItem item, Action<string> log)
        {
            if (item == null || string.IsNullOrEmpty(item.EpisodePath) || !Directory.Exists(item.EpisodePath))
                return 0;

            int copied = 0;
            string[] legacySubfolders = new[] { "personagens", "cenarios" };
            foreach (string sub in legacySubfolders)
            {
                string subDir = Path.Combine(item.EpisodePath, sub);
                if (!Directory.Exists(subDir)) continue;

                foreach (string src in Directory.GetFiles(subDir))
                {
                    if (!Regex.IsMatch(Path.GetExtension(src), @"^\.(jpg|jpeg|png)$", RegexOptions.IgnoreCase))
                        continue;
                    if (new FileInfo(src).Length <= 10 * 1024) continue;

                    if (!Directory.Exists(item.AssetsDir))
                        Directory.CreateDirectory(item.AssetsDir);

                    string fn = Path.GetFileName(src);
                    string dst = Path.Combine(item.AssetsDir, fn);
                    if (!File.Exists(dst))
                    {
                        File.Copy(src, dst, false);
                        copied++;
                        if (log != null)
                            log(string.Format("[Assets] Imagem recuperada de '{0}\\': {1}", sub, fn));
                    }
                }
            }
            return copied;
        }

        public static string FindMatchingDiskAssetFile(string wantedFileName, IEnumerable<string> diskFilePaths)
        {
            if (string.IsNullOrEmpty(wantedFileName) || diskFilePaths == null) return "";
            List<string> files = diskFilePaths.ToList();

            // 1. Exact case-insensitive filename match
            string exact = files.FirstOrDefault(f =>
                string.Equals(Path.GetFileName(f), wantedFileName, StringComparison.OrdinalIgnoreCase));
            if (!string.IsNullOrEmpty(exact)) return exact;

            // 2. Fuzzy stem match respecting Character vs Scenario category
            bool wantedIsScen = IsScenarioAssetName(wantedFileName);
            string wantedStem = CleanAssetStem(wantedFileName);
            string normWantedStem = NormalizeForCompare(wantedStem);
            string wantedCharNum = "";
            if (!wantedIsScen)
            {
                Match mWantChar = Regex.Match(wantedFileName, @"(?:^|_)Personagem_0*(\d+[A-Za-z]?)(?:_|\.)", RegexOptions.IgnoreCase);
                if (mWantChar.Success) wantedCharNum = mWantChar.Groups[1].Value.ToLowerInvariant();
            }

            string bestPath = "";
            double bestScore = 0.0;

            foreach (string f in files)
            {
                string fn = Path.GetFileName(f);
                bool candIsScen = IsScenarioAssetName(fn);
                if (wantedIsScen != candIsScen) continue;

                if (!wantedIsScen)
                {
                    // Nunca confundir variante __Roupa_ com personagem base ou vice-versa no mapeamento difuso
                    bool wantIsAutoOutfit = wantedFileName.IndexOf("__Roupa_", StringComparison.OrdinalIgnoreCase) >= 0;
                    bool candIsAutoOutfit = fn.IndexOf("__Roupa_", StringComparison.OrdinalIgnoreCase) >= 0;
                    if (wantIsAutoOutfit != candIsAutoOutfit) continue;

                    string normCandStem = NormalizeForCompare(CleanAssetStem(fn));
                    Match mCandChar = Regex.Match(fn, @"(?:^|_)Personagem_0*(\d+[A-Za-z]?)(?:_|\.)", RegexOptions.IgnoreCase);
                    string candCharNum = mCandChar.Success ? mCandChar.Groups[1].Value.ToLowerInvariant() : "";

                    // Se ambos possuem índice explícito de Personagem diferente (ex: Personagem_5_A_Vendedora vs Personagem_11_A_Vendedora_Gerente),
                    // nunca mapear um sobre o outro caso o nome/versão tenha mudado!
                    if (!string.IsNullOrEmpty(wantedCharNum) && !string.IsNullOrEmpty(candCharNum) &&
                        !string.Equals(wantedCharNum, candCharNum, StringComparison.OrdinalIgnoreCase) &&
                        !string.Equals(normWantedStem, normCandStem, StringComparison.OrdinalIgnoreCase))
                    {
                        continue;
                    }
                }

                double score = ComputeTextSimilarity(wantedStem, CleanAssetStem(fn));
                if (score > bestScore)
                {
                    bestScore = score;
                    bestPath = f;
                }
            }

            double minThreshold = wantedIsScen ? 0.50 : 0.72;
            return bestScore >= minThreshold ? bestPath : "";
        }

        public static int AutoAlignImportedAssetsOnDisk(EpisodeWorkItem item, Action<string> log)
        {
            if (item == null || !Directory.Exists(item.AssetsDir)) return 0;

            List<string> diskFiles = Directory.GetFiles(item.AssetsDir)
                .Where(f => Regex.IsMatch(Path.GetExtension(f), @"^\.(jpg|jpeg|png)$", RegexOptions.IgnoreCase) && new FileInfo(f).Length > 10 * 1024)
                .ToList();
            if (diskFiles.Count == 0) return 0;

            HashSet<string> allTargets = new HashSet<string>(item.AllRequiredFlowIngredients, StringComparer.OrdinalIgnoreCase);
            foreach (GrokAssetSpec gs in item.GrokSpecs)
            {
                if (!string.IsNullOrEmpty(gs.TargetFileName))
                    allTargets.Add(gs.TargetFileName);
            }

            // Alinha em disco somente Personagens importados com prefixo diferente (ex: 01_Personagem_1_O_Marido.jpg -> O_Marido.jpg)
            // Cenários equivalentes são mapeados exclusivamente em Temp\flow_assets para manter a pasta EP.X\assets\ limpa.
            HashSet<string> usedSources = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            int aligned = 0;
            foreach (string targetName in allTargets)
            {
                if (IsScenarioAssetName(targetName)) continue;

                string exactPath = Path.Combine(item.AssetsDir, targetName);
                if (File.Exists(exactPath) && new FileInfo(exactPath).Length > 10 * 1024)
                    continue;

                // Se este target for uma nova versão de um personagem já existente, nunca copiar a imagem antiga por cima:
                // ela deve ser gerada anexando a imagem anterior como referência!
                GrokAssetSpec targetSpec = item.GrokSpecs != null
                    ? item.GrokSpecs.FirstOrDefault(gs => string.Equals(gs.TargetFileName, targetName, StringComparison.OrdinalIgnoreCase))
                    : null;
                if (targetSpec != null &&
                    (!string.IsNullOrEmpty(FindExistingBaseCharacterPathForVariantSpec(item, targetSpec)) ||
                     FindBaseCharacterSpecInEpisode(item, targetSpec) != null))
                {
                    continue;
                }

                List<string> availableChars = diskFiles
                    .Where(f => !usedSources.Contains(f) && !IsScenarioAssetName(Path.GetFileName(f)) && !allTargets.Contains(Path.GetFileName(f)))
                    .ToList();

                string bestMatch = "";
                double bestScore = 0.0;
                string wantStem = CleanAssetStem(targetName);
                foreach (string cand in availableChars)
                {
                    double sc = ComputeTextSimilarity(wantStem, CleanAssetStem(Path.GetFileName(cand)));
                    if (sc > bestScore)
                    {
                        bestScore = sc;
                        bestMatch = cand;
                    }
                }

                if (bestScore >= 0.80 && !string.IsNullOrEmpty(bestMatch) && File.Exists(bestMatch))
                {
                    File.Copy(bestMatch, exactPath, false);
                    usedSources.Add(bestMatch);
                    diskFiles.Add(exactPath);
                    aligned++;
                    if (log != null)
                    {
                        log(string.Format("[Assets] Personagem importado alinhado: '{0}' -> '{1}'",
                            Path.GetFileName(bestMatch), targetName));
                    }
                }
            }
            return aligned;
        }

        public static void RefreshDiskCounters(EpisodeWorkItem item)
        {
            if (Directory.Exists(item.AssetsDir))
            {
                string[] assetFiles = Directory.GetFiles(item.AssetsDir)
                    .Where(f => Regex.IsMatch(Path.GetExtension(f), @"^\.(jpg|jpeg|png)$", RegexOptions.IgnoreCase) && new FileInfo(f).Length > 1024)
                    .ToArray();

                if (item.AllRequiredFlowIngredients.Count > 0)
                {
                    int matched = 0;
                    foreach (string req in item.AllRequiredFlowIngredients)
                    {
                        if (!string.IsNullOrEmpty(FindMatchingDiskAssetFile(req, assetFiles)))
                            matched++;
                    }
                    item.ExistingAssetsCount = matched;
                }
                else
                {
                    item.ExistingAssetsCount = assetFiles.Length;
                }
            }
            else
            {
                item.ExistingAssetsCount = 0;
            }

            if (Directory.Exists(item.TakesDir))
            {
                item.ExistingTakesCount = Directory.GetFiles(item.TakesDir, "Take_*.mp4", SearchOption.TopDirectoryOnly)
                    .Count(f => new FileInfo(f).Length > 20 * 1024);
                string wavPath = Path.Combine(item.TakesDir, "Narrador_Take_01.wav");
                item.HasProcessedNarratorWav = File.Exists(wavPath) && new FileInfo(wavPath).Length > 1024;
            }
            else
            {
                item.ExistingTakesCount = 0;
                item.HasProcessedNarratorWav = false;
            }
        }

        public static int SyncRecurringAssetsFromPreviousEpisodes(EpisodeWorkItem item, Action<string> log)
        {
            if (item == null) return 0;
            int copied = SyncLocalSubfolderAssets(item, log);

            if (item.EpisodeNumber <= 1 || string.IsNullOrEmpty(item.StoryRootPath))
            {
                RefreshDiskCounters(item);
                return copied;
            }

            if (!Directory.Exists(item.AssetsDir)) Directory.CreateDirectory(item.AssetsDir);

            List<string> prevEpisodeNames = new List<string>();
            for (int i = 1; i < item.EpisodeNumber; i++)
            {
                prevEpisodeNames.Add("EP." + i);
                prevEpisodeNames.Add("EP" + i);
            }

            List<string> candidateAssetDirs = new List<string>();
            foreach (string epName in prevEpisodeNames)
            {
                string d = Path.Combine(item.StoryRootPath, epName, "assets");
                if (Directory.Exists(d)) candidateAssetDirs.Add(d);
            }

            HashSet<string> wanted = new HashSet<string>(item.AllRequiredFlowIngredients, StringComparer.OrdinalIgnoreCase);
            foreach (GrokAssetSpec gs in item.GrokSpecs)
            {
                if (!string.IsNullOrEmpty(gs.TargetFileName))
                    wanted.Add(gs.TargetFileName);
            }

            foreach (string reqFile in wanted)
            {
                string dest = Path.Combine(item.AssetsDir, reqFile);
                if (File.Exists(dest) && new FileInfo(dest).Length > 10 * 1024) continue;

                foreach (string srcDir in candidateAssetDirs)
                {
                    string[] prevFiles = Directory.GetFiles(srcDir)
                        .Where(f => Regex.IsMatch(Path.GetExtension(f), @"^\.(jpg|jpeg|png)$", RegexOptions.IgnoreCase))
                        .ToArray();

                    string candidate = prevFiles.FirstOrDefault(f => string.Equals(Path.GetFileName(f), reqFile, StringComparison.OrdinalIgnoreCase));
                    if (!string.IsNullOrEmpty(candidate) && new FileInfo(candidate).Length > 10 * 1024)
                    {
                        File.Copy(candidate, dest, true);
                        copied++;
                        if (log != null) log(string.Format("[Continuidade] Asset recorrente reaproveitado para {0}: {1}", item.EpisodeName, reqFile));
                        break;
                    }
                }
            }

            // Sincronizar também todas as variantes de figurino (*__Roupa_*.jpg) entre os episódios da história
            foreach (string srcDir in candidateAssetDirs)
            {
                foreach (string f in Directory.GetFiles(srcDir))
                {
                    string fn = Path.GetFileName(f);
                    if (fn.IndexOf("__Roupa_", StringComparison.OrdinalIgnoreCase) < 0)
                        continue;
                    if (!Regex.IsMatch(Path.GetExtension(f), @"^\.(jpg|jpeg|png)$", RegexOptions.IgnoreCase))
                        continue;
                    if (new FileInfo(f).Length <= 5 * 1024)
                        continue;

                    string dst = Path.Combine(item.AssetsDir, fn);
                    if (!File.Exists(dst))
                    {
                        File.Copy(f, dst, true);
                        copied++;
                        if (log != null) log(string.Format("[Continuidade] Variante de roupa sincronizada para {0}: {1}", item.EpisodeName, fn));
                    }
                }
            }

            RefreshDiskCounters(item);
            return copied;
        }

        private static string FindBestFile(string[] files, string[] patterns, string[] excludeSubstrings = null)
        {
            foreach (string pat in patterns)
            {
                foreach (string f in files)
                {
                    string name = Path.GetFileName(f);
                    if (excludeSubstrings != null && excludeSubstrings.Any(ex => name.IndexOf(ex, StringComparison.OrdinalIgnoreCase) >= 0))
                        continue;

                    if (string.Equals(name, pat, StringComparison.OrdinalIgnoreCase) ||
                        name.IndexOf(pat, StringComparison.OrdinalIgnoreCase) >= 0)
                    {
                        return f;
                    }
                }
            }
            return "";
        }

        private static string ReadUtf8(string path)
        {
            return File.ReadAllText(path, Encoding.UTF8);
        }

    }
}
