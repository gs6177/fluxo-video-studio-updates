using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace FluxoVideoStudio
{
    public partial class FlowAutomation
    {
        private class SingleSceneDispatchOutcome
        {
            public bool StartedCard;
            public bool RefusedWithoutCard;
            public bool BlockedByUnusualActivity;
            public bool PageReloaded;
        }

        private string BuildSingleSceneConversationPrompt(string originalPromptText, FlowTakeSpec spec, bool isSoftenedRetry)
        {
            string body = InjectTakeTagIntoPromptBody(spec.RawPromptBody, spec.TakeNumber);
            if (isSoftenedRetry)
            {
                body = SoftenPromptForSecondAttempt(body);
                body = InjectTakeTagIntoPromptBody(body, spec.TakeNumber);
            }

            // Remove prefixo redundante "Prompt de Vídeo:" caso venha no corpo e normaliza quebras de linha para \n
            body = Regex.Replace(body ?? "", @"^\s*Prompt\s+de\s+V[ií]deo\s*:\s*", "", RegexOptions.IgnoreCase).Trim();
            body = InjectTakeTagIntoPromptBody(body, spec.TakeNumber);

            StringBuilder sb = new StringBuilder();
            if (isSoftenedRetry)
            {
                sb.AppendFormat(
                    "A cena anterior deu erro. Por favor, suavize qualquer termo sensível ou dramático desta cena mantendo os elementos anexados, o sentido, a fala e o estilo visual 3D, e gere este vídeo em proporção 9:16 (mantenha a tag [TAKE_{0:00}] no início do prompt do vídeo, sem escrever texto na imagem):\n\n",
                    spec.TakeNumber);
            }
            else
            {
                sb.AppendFormat(
                    "Gere em vídeo 9:16 esta cena usando os elementos anexados (mantenha a tag [TAKE_{0:00}] no início do prompt do vídeo, sem escrever texto na imagem):\n\n",
                    spec.TakeNumber);
            }

            sb.Append(body);
            return sb.ToString().Replace("\r\n", "\n").Replace("\r", "\n").Trim();
        }

        private async Task WaitForAgentInputUnlockedAsync(string sess, PreSessionGridBaseline baseline, CancellationToken ct)
        {
            DateTime deadline = DateTime.UtcNow.AddSeconds(45);
            while (DateTime.UtcNow < deadline)
            {
                ct.ThrowIfCancellationRequested();
                SessionPollSnapshot snap = await InspectCurrentSessionStateAsync(sess, baseline, ct);
                if (!snap.AgentBusy)
                    return;
                await Task.Delay(900, ct);
            }
        }

        private async Task<SingleSceneDispatchOutcome> WaitForSingleSceneGenerationStartedAsync(
            string sess,
            PreSessionGridBaseline baseline,
            int cardsBefore,
            int vidOptsBefore,
            int bubblesBefore,
            int unusualCountBefore,
            bool hadUnusualAtBottomBefore,
            int takeNumber,
            int sceneIdxOneBased,
            int totalScenes,
            CancellationToken ct)
        {
            SingleSceneDispatchOutcome outcome = new SingleSceneDispatchOutcome();
            DateTime start = DateTime.UtcNow;
            DateTime deadline = start.AddSeconds(110);
            int retryBtnClicks = 0;
            int textOnlyIdlePolls = 0;

            // Aguarda o envio disparar o estado de processamento do Agente antes da 1ª leitura
            await Task.Delay(1800, ct);

            while (DateTime.UtcNow < deadline)
            {
                ct.ThrowIfCancellationRequested();

                string manualReason;
                if (_cdp.ConsumeReloadAndResumeRequest(out manualReason))
                {
                    _log(string.Format("[Recuperação | Histórico] Botão 'Recarregar e Continuar' acionado durante envio do Take_{0:00} ({1}). Recarregando página...",
                        takeNumber, manualReason));
                    await _cdp.ReloadPageAndWaitReadyAsync(sess, 30000, ct);
                    await WaitForFlowPageLoadedAsync(sess, ct);
                    outcome.PageReloaded = true;
                    return outcome;
                }

                SessionPollSnapshot snap = await InspectCurrentSessionStateAsync(sess, baseline, ct);

                bool newCardCreated = (snap.TotalSessionCards > cardsBefore) || (snap.AgentVideoOptionsCount > vidOptsBefore);
                if (newCardCreated && !snap.AgentBusy)
                {
                    outcome.StartedCard = true;
                    _log(string.Format("[Google Flow | Cena {0}/{1}] ▶ Take_{2:00} começou a ser gerada! Passando imediatamente para a próxima cena...",
                        sceneIdxOneBased, totalScenes, takeNumber));
                    return outcome;
                }

                bool freshUnusualTurn = !hadUnusualAtBottomBefore ||
                                        retryBtnClicks > 0 ||
                                        snap.AgentChatBubblesCount > bubblesBefore ||
                                        snap.UnusualActivityCount > unusualCountBefore;

                if (!newCardCreated && !snap.AgentBusy && freshUnusualTurn && (snap.AgentHasRetryButton || snap.AgentHasUnusualActivity))
                {
                    if (snap.AgentHasUnusualActivity)
                    {
                        if (snap.AgentHasRetryButton && retryBtnClicks < 2 && snap.RetryButtonX > 0 && snap.RetryButtonY > 0)
                        {
                            retryBtnClicks++;
                            _log(string.Format("[Google Flow | Cena {0}/{1}] Aviso de 'atividade incomum' no Take_{2:00} -> clicando em 'Tentar de novo' ({3}/2)...",
                                sceneIdxOneBased, totalScenes, takeNumber, retryBtnClicks));
                            await Task.Delay(3500, ct);
                            await _cdp.ClickAtAsync(sess, snap.RetryButtonX, snap.RetryButtonY, ct);
                            await Task.Delay(2200, ct);
                            continue;
                        }

                        outcome.BlockedByUnusualActivity = true;
                        _log("[Google Flow -> Grok] Painel do Agente permaneceu com aviso de 'atividade incomum' -> transferindo cenas restantes para o Grok Vídeo!");
                        return outcome;
                    }
                    else
                    {
                        if (snap.AgentHasRetryButton && retryBtnClicks < 1 && snap.RetryButtonX > 0 && snap.RetryButtonY > 0)
                        {
                            retryBtnClicks++;
                            _log(string.Format("[Google Flow | Cena {0}/{1}] Aviso 'Algo deu errado. Tente de novo.' no Take_{2:00} -> aguardando 4s e clicando em 'Tentar de novo'...",
                                sceneIdxOneBased, totalScenes, takeNumber));
                            await Task.Delay(4000, ct);
                            await _cdp.ClickAtAsync(sess, snap.RetryButtonX, snap.RetryButtonY, ct);
                            await Task.Delay(2500, ct);
                            continue;
                        }

                        outcome.RefusedWithoutCard = true;
                        _log(string.Format("[Google Flow | Cena {0}/{1}] Aviso: Take_{2:00} retornou 'Algo deu errado' nesta tentativa -> será reenviada suavizada na verificação final.",
                            sceneIdxOneBased, totalScenes, takeNumber));
                        return outcome;
                    }
                }

                double elapsedSec = (DateTime.UtcNow - start).TotalSeconds;
                if (!newCardCreated && !snap.AgentBusy && snap.AgentChatBubblesCount > bubblesBefore && elapsedSec >= 6.0)
                {
                    textOnlyIdlePolls++;
                    if (textOnlyIdlePolls >= 3)
                    {
                        outcome.RefusedWithoutCard = true;
                        _log(string.Format("[Google Flow | Cena {0}/{1}] Aviso: Take_{2:00} não iniciou card nesta tentativa -> será suavizada na verificação final da conversa.",
                            sceneIdxOneBased, totalScenes, takeNumber));
                        return outcome;
                    }
                }
                else
                {
                    textOnlyIdlePolls = 0;
                }

                if (!newCardCreated && !snap.AgentBusy && elapsedSec >= 32.0)
                {
                    outcome.RefusedWithoutCard = true;
                    _log(string.Format("[Google Flow | Cena {0}/{1}] Aviso: Take_{2:00} não gerou card após {3:0}s -> será tratada na verificação de erros.",
                        sceneIdxOneBased, totalScenes, takeNumber, elapsedSec));
                    return outcome;
                }

                await _cdp.WaitOrWakeOnReloadSignalAsync(1200, ct);
            }

            outcome.RefusedWithoutCard = true;
            return outcome;
        }

        private async Task<SessionPollSnapshot> WaitForAllDispatchedScenesToSettleAsync(
            string sess,
            PreSessionGridBaseline baseline,
            string stageLabel,
            CancellationToken ct)
        {
            DateTime start = DateTime.UtcNow;
            DateTime deadline = start.AddMinutes(16);
            DateTime lastProgressUtc = DateTime.UtcNow;
            string lastFp = "";
            int consecutiveIdle = 0;
            int retryBtnClicks = 0;

            while (DateTime.UtcNow < deadline)
            {
                ct.ThrowIfCancellationRequested();
                await _cdp.WaitOrWakeOnReloadSignalAsync(5000, ct);

                string manualReason;
                bool manualReload = _cdp.ConsumeReloadAndResumeRequest(out manualReason);

                SessionPollSnapshot snap = await InspectCurrentSessionStateAsync(sess, baseline, ct);

                string fp = string.Format("{0}|{1}|{2}|{3}|{4}|{5}",
                    snap.TotalSessionCards,
                    snap.GeneratingCards,
                    snap.CompletedCards,
                    snap.FailedCards,
                    snap.PctSummary ?? "",
                    snap.AgentBusy);
                if (fp != lastFp)
                {
                    lastFp = fp;
                    lastProgressUtc = DateTime.UtcNow;
                }

                string pctInfo = !string.IsNullOrEmpty(snap.PctSummary) ? string.Format(" [{0}]", snap.PctSummary) : "";
                _log(string.Format("[Google Flow | {0}] Cards na sessão: {1} | Em geração: {2}{3} | Concluídos (100%): {4} | Erros: {5}",
                    stageLabel, snap.TotalSessionCards, snap.GeneratingCards, pctInfo, snap.CompletedCards, snap.FailedCards));

                if (snap.GeneratingCards == 0 && !snap.AgentBusy)
                {
                    if (snap.AgentHasRetryButton && retryBtnClicks < 2 && snap.RetryButtonX > 0 && snap.RetryButtonY > 0)
                    {
                        retryBtnClicks++;
                        await Task.Delay(3500, ct);
                        await _cdp.ClickAtAsync(sess, snap.RetryButtonX, snap.RetryButtonY, ct);
                        await Task.Delay(2200, ct);
                        consecutiveIdle = 0;
                        lastProgressUtc = DateTime.UtcNow;
                        continue;
                    }

                    consecutiveIdle++;
                    if (consecutiveIdle >= 2)
                        return snap;
                }
                else
                {
                    consecutiveIdle = 0;
                }

                double stalledSec = (DateTime.UtcNow - lastProgressUtc).TotalSeconds;
                if (manualReload || stalledSec >= 135)
                {
                    string why = manualReload ? manualReason : string.Format("sem avanço por {0:0}s", stalledSec);
                    _log(string.Format("[Recuperação | Histórico] Travamento detectado em '{0}' ({1}). Recarregando página do Flow...", stageLabel, why));
                    await _cdp.ReloadPageAndWaitReadyAsync(sess, 30000, ct);
                    await WaitForFlowPageLoadedAsync(sess, ct);
                    SessionPollSnapshot reloaded = await InspectCurrentSessionStateAsync(sess, baseline, ct);
                    reloaded.PageReloadedDuringWait = true;
                    return reloaded;
                }
            }

            return await InspectCurrentSessionStateAsync(sess, baseline, ct);
        }

        private async Task<HashSet<int>> InspectAndRemoveSessionErrorCardsAsync(
            string sess,
            PreSessionGridBaseline baseline,
            List<FlowTakeSpec> candidateTakes,
            CancellationToken ct)
        {
            HashSet<int> errorTakeNums = new HashSet<int>();
            int safetyMax = Math.Max(6, (candidateTakes != null ? candidateTakes.Count : 6) + 4);

            for (int iter = 0; iter < safetyMax; iter++)
            {
                ct.ThrowIfCancellationRequested();
                SessionPollSnapshot snap = await InspectCurrentSessionStateAsync(sess, baseline, ct);
                if (snap.FailedCards <= 0 || snap.FailedMountedIndices.Count == 0)
                    break;

                int errIdx = snap.FailedMountedIndices[0];
                int sliceLimit = Math.Max(4, snap.SessionSliceEndIndex);

                bool clickedReuse = await ClickFailedTileActionButtonAsync(sess, errIdx, sliceLimit, false, false, ct);
                if (clickedReuse)
                {
                    await Task.Delay(750, ct);
                    string reusedPrompt = await ReadCurrentFlowTextboxAsync(sess, ct);
                    if (!string.IsNullOrWhiteSpace(reusedPrompt))
                    {
                        int explicitNum = TryExtractExplicitTakeTagNumber(reusedPrompt);
                        int matchedNum = explicitNum > 0
                            ? explicitNum
                            : IdentifyTakeNumberFromPrompt(reusedPrompt, candidateTakes);
                        if (matchedNum > 0)
                            errorTakeNums.Add(matchedNum);
                    }

                    await InsertTextIntoFlowTextboxAsync(sess, "", true, ct);
                    await ClearAttachedPromptChipsAsync(sess, ct);
                }

                bool deleted = await ClickFailedTileActionButtonAsync(sess, errIdx, sliceLimit, true, false, ct);
                await Task.Delay(450, ct);
                if (!deleted && !clickedReuse)
                    break;
            }

            return errorTakeNums;
        }

        private async Task<HashSet<int>> FindUncompletedTakeNumbersInSessionAsync(
            string sess,
            PreSessionGridBaseline baseline,
            List<FlowTakeSpec> targetTakes,
            HashSet<int> knownFailedTakeNums,
            CancellationToken ct)
        {
            HashSet<int> uncompleted = new HashSet<int>();
            if (knownFailedTakeNums != null)
            {
                foreach (int fn in knownFailedTakeNums)
                    uncompleted.Add(fn);
            }

            List<FlowTakeSpec> remainingCandidates = targetTakes
                .Where(t => !uncompleted.Contains(t.TakeNumber))
                .ToList();
            if (remainingCandidates.Count == 0)
                return uncompleted;

            List<SessionCompletedVideoInfo> agentVideos = await CollectSessionVideosFromAgentPanelAsync(sess, baseline, ct);
            List<string> gridAsbIdsOldestFirst = await CollectSessionGridAsbIdsOldestFirstAsync(sess, baseline, ct);
            await EnrichMissingVideoPromptsFromGridTilesAsync(sess, agentVideos, gridAsbIdsOldestFirst, ct);

            List<Tuple<FlowTakeSpec, string>> matchedPlan = BuildChronologicalDownloadPlan(remainingCandidates, agentVideos, gridAsbIdsOldestFirst);
            HashSet<int> matchedTakeNums = new HashSet<int>();
            for (int i = 0; i < matchedPlan.Count; i++)
            {
                if (!string.IsNullOrEmpty(matchedPlan[i].Item2))
                    matchedTakeNums.Add(matchedPlan[i].Item1.TakeNumber);
            }

            for (int i = 0; i < remainingCandidates.Count; i++)
            {
                int tn = remainingCandidates[i].TakeNumber;
                if (!matchedTakeNums.Contains(tn))
                    uncompleted.Add(tn);
            }

            return uncompleted;
        }

        private async Task ExecuteOneByOneSceneConversationInFlowAsync(
            string sess,
            EpisodeWorkItem ep,
            List<FlowTakeSpec> initialTargetTakes,
            List<string> allAssetFiles,
            Dictionary<string, string> ingredientToResolvedName,
            HashSet<int> skippedAfterFlowRetriesOut,
            CancellationToken ct)
        {
            List<FlowTakeSpec> currentTakes = new List<FlowTakeSpec>(initialTargetTakes);
            int reloadRecoveries = 0;

            while (currentTakes.Count > 0 && reloadRecoveries <= 2)
            {
                ct.ThrowIfCancellationRequested();

                await EnsureAgentPanelOpenAsync(sess, ct);
                _log("[Google Flow] Passo 2: Usando a sessão já aberta no painel do Agente...");
                await ScrollAgentPanelToBottomAsync(sess, ct);
                await ClearAttachedPromptChipsAsync(sess, ct);
                string initLeftoverTxt = await ReadCurrentFlowTextboxAsync(sess, ct);
                if (!string.IsNullOrWhiteSpace(initLeftoverTxt))
                {
                    await InsertTextIntoFlowTextboxAsync(sess, "", true, ct);
                    await Task.Delay(250, ct);
                }

                PreSessionGridBaseline gridBaseline = await CapturePreSessionBaselineAsync(sess, ct);

                if (allAssetFiles != null && allAssetFiles.Count > 0)
                {
                    List<string> assetsForTakes = FilterAssetFilesForTakes(allAssetFiles, currentTakes, ingredientToResolvedName);
                    if (assetsForTakes.Count == 0)
                        assetsForTakes = allAssetFiles;

                    _log(string.Format("[Google Flow] Passo 3: Verificando/enviando {0} imagens de personagens e cenários necessárias na biblioteca do Flow...", assetsForTakes.Count));
                    await UploadAssetsToFlowProjectAsync(sess, assetsForTakes, ct);
                }

                HashSet<int> noCardCreatedInPass1 = new HashSet<int>();
                bool pageReloaded = false;
                bool blockedByUnusualActivity = false;

                _log(string.Format("[Google Flow] Passo 4: Iniciando envio sequencial cena a cena ({0} cena(s)) na mesma conversa...", currentTakes.Count));

                for (int i = 0; i < currentTakes.Count; i++)
                {
                    ct.ThrowIfCancellationRequested();
                    FlowTakeSpec spec = currentTakes[i];

                    await WaitForAgentInputUnlockedAsync(sess, gridBaseline, ct);
                    await ClearAttachedPromptChipsAsync(sess, ct);

                    string leftoverTxt = await ReadCurrentFlowTextboxAsync(sess, ct);
                    if (!string.IsNullOrWhiteSpace(leftoverTxt))
                    {
                        await InsertTextIntoFlowTextboxAsync(sess, "", true, ct);
                        await Task.Delay(250, ct);
                    }

                    SessionPollSnapshot preSnap = await InspectCurrentSessionStateAsync(sess, gridBaseline, ct);
                    int cardsBefore = preSnap.TotalSessionCards;
                    int vidOptsBefore = preSnap.AgentVideoOptionsCount;
                    int bubblesBefore = preSnap.AgentChatBubblesCount;
                    int unusualBefore = preSnap.UnusualActivityCount;
                    bool hadUnusualAtBottomBefore = preSnap.AgentHasRetryButton || preSnap.AgentHasUnusualActivity;

                    List<string> sceneIngredients = ResolveStrictIngredientsForSingleTake(spec, allAssetFiles, ingredientToResolvedName);
                    HashSet<string> attachedForScene = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                    if (sceneIngredients.Count > 0)
                    {
                        _log(string.Format("[Google Flow | Cena {0}/{1}] Vinculando os {2} elemento(s) do Take_{3:00}: {4}",
                            i + 1, currentTakes.Count, sceneIngredients.Count, spec.TakeNumber, string.Join(", ", sceneIngredients)));
                        await AttachIngredientsViaMenuAsync(sess, sceneIngredients, attachedForScene, ct);
                        await WaitForAttachedPromptChipsImagesLoadedAsync(sess, ct);
                    }

                    string scenePrompt = BuildSingleSceneConversationPrompt(ep.FlowPromptText, spec, false);
                    await InsertTextIntoFlowTextboxAsync(sess, scenePrompt, false, ct);
                    await Task.Delay(1500, ct);
                    await WaitRandomFlowActionDelayAsync(string.Format("após colar comando do Take_{0:00}", spec.TakeNumber), ct);

                    LastActionHistoryStore.RecordAction(
                        ep,
                        "Google Flow",
                        string.Format("Enviando Cena {0}/{1} (Take_{2:00}) no Google Flow", i + 1, currentTakes.Count, spec.TakeNumber),
                        _config.FlowProfile,
                        sess,
                        _config.FlowProjectUrl,
                        string.Format("Take_{0:00}", spec.TakeNumber),
                        spec.TakeNumber,
                        i + 1,
                        scenePrompt,
                        attachedForScene,
                        "SUBMITTED_SINGLE_SCENE");

                    await ClickStartGenerationAsync(sess, ct);

                    SingleSceneDispatchOutcome dispatchRes = await WaitForSingleSceneGenerationStartedAsync(
                        sess,
                        gridBaseline,
                        cardsBefore,
                        vidOptsBefore,
                        bubblesBefore,
                        unusualBefore,
                        hadUnusualAtBottomBefore,
                        spec.TakeNumber,
                        i + 1,
                        currentTakes.Count,
                        ct);

                    if (dispatchRes.PageReloaded)
                    {
                        pageReloaded = true;
                        break;
                    }
                    if (dispatchRes.BlockedByUnusualActivity)
                    {
                        blockedByUnusualActivity = true;
                        break;
                    }
                    if (dispatchRes.RefusedWithoutCard)
                    {
                        noCardCreatedInPass1.Add(spec.TakeNumber);
                    }
                }

                if (!pageReloaded)
                {
                    _log(string.Format("[Google Flow] Passo 5: Todas as cenas foram enviadas! Aguardando término da renderização para verificar se houve algum erro..."));
                    SessionPollSnapshot settleSnap = await WaitForAllDispatchedScenesToSettleAsync(sess, gridBaseline, "Aguardando Cenas", ct);
                    if (settleSnap.PageReloadedDuringWait)
                        pageReloaded = true;
                }

                if (pageReloaded)
                {
                    await DownloadAllCompletedTakesIn720pAsync(sess, gridBaseline, ep, currentTakes, ct);
                    HashSet<int> diskReady = new HashSet<int>();
                    for (int k = 0; k < currentTakes.Count; k++)
                    {
                        string pMp4 = Path.Combine(ep.TakesDir, string.Format("Take_{0:00}.mp4", currentTakes[k].TakeNumber));
                        if (File.Exists(pMp4) && new FileInfo(pMp4).Length >= 50 * 1024)
                            diskReady.Add(currentTakes[k].TakeNumber);
                    }
                    await TrySalvageCompletedTakesFromCurrentFlowScreenAsync(sess, ep, currentTakes, diskReady, ct);

                    currentTakes = currentTakes.Where(t =>
                    {
                        string pMp4 = Path.Combine(ep.TakesDir, string.Format("Take_{0:00}.mp4", t.TakeNumber));
                        return !File.Exists(pMp4) || new FileInfo(pMp4).Length < 50 * 1024;
                    }).ToList();

                    reloadRecoveries++;
                    continue;
                }

                HashSet<int> stillFailedAfterSoftening = new HashSet<int>();

                if (!blockedByUnusualActivity)
                {
                    // Passo 6: Verificar se houve algum erro e, na MESMA conversa, pedir para suavizar as cenas com erro e tentar novamente
                    HashSet<int> pass1ErrorCardNums = await InspectAndRemoveSessionErrorCardsAsync(sess, gridBaseline, currentTakes, ct);
                    foreach (int n in noCardCreatedInPass1)
                        pass1ErrorCardNums.Add(n);

                    HashSet<int> allFailedInPass1 = await FindUncompletedTakeNumbersInSessionAsync(
                        sess,
                        gridBaseline,
                        currentTakes,
                        pass1ErrorCardNums,
                        ct);

                    List<FlowTakeSpec> failedSpecs = currentTakes
                        .Where(t => allFailedInPass1.Contains(t.TakeNumber))
                        .OrderBy(t => t.TakeNumber)
                        .ToList();

                    if (failedSpecs.Count == 0)
                    {
                        _log("[Google Flow] Passo 6: Verificação concluída — nenhum erro encontrado nas cenas geradas!");
                    }
                    else
                    {
                        string failedLabels = string.Join(", ", failedSpecs.Select(t => string.Format("Take_{0:00}", t.TakeNumber)));
                        _log(string.Format("[Google Flow] Passo 6: Detectada(s) {0} cena(s) com erro ({1}) -> pedindo na conversa para suavizar e tentar novamente...",
                            failedSpecs.Count, failedLabels));

                        for (int f = 0; f < failedSpecs.Count; f++)
                        {
                            ct.ThrowIfCancellationRequested();
                            FlowTakeSpec failedSpec = failedSpecs[f];

                            await WaitForAgentInputUnlockedAsync(sess, gridBaseline, ct);
                            await ClearAttachedPromptChipsAsync(sess, ct);

                            string remTxt = await ReadCurrentFlowTextboxAsync(sess, ct);
                            if (!string.IsNullOrWhiteSpace(remTxt))
                            {
                                await InsertTextIntoFlowTextboxAsync(sess, "", true, ct);
                                await Task.Delay(250, ct);
                            }

                            SessionPollSnapshot retryPreSnap = await InspectCurrentSessionStateAsync(sess, gridBaseline, ct);
                            int cardsBeforeRetry = retryPreSnap.TotalSessionCards;
                            int vidOptsBeforeRetry = retryPreSnap.AgentVideoOptionsCount;
                            int bubblesBeforeRetry = retryPreSnap.AgentChatBubblesCount;
                            int unusualBeforeRetry = retryPreSnap.UnusualActivityCount;
                            bool hadUnusualBeforeRetry = retryPreSnap.AgentHasRetryButton || retryPreSnap.AgentHasUnusualActivity;

                            List<string> retryIngredients = ResolveStrictIngredientsForSingleTake(failedSpec, allAssetFiles, ingredientToResolvedName);
                            HashSet<string> attachedRetry = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                            if (retryIngredients.Count > 0)
                            {
                                _log(string.Format("[Google Flow | Suavizar {0}/{1}] Vinculando os {2} elemento(s) do Take_{3:00}: {4}",
                                    f + 1, failedSpecs.Count, retryIngredients.Count, failedSpec.TakeNumber, string.Join(", ", retryIngredients)));
                                await AttachIngredientsViaMenuAsync(sess, retryIngredients, attachedRetry, ct);
                                await WaitForAttachedPromptChipsImagesLoadedAsync(sess, ct);
                            }

                            string softenPrompt = BuildSingleSceneConversationPrompt(ep.FlowPromptText, failedSpec, true);
                            await InsertTextIntoFlowTextboxAsync(sess, softenPrompt, false, ct);
                            await Task.Delay(1500, ct);
                            await WaitRandomFlowActionDelayAsync(string.Format("após colar comando suavizado do Take_{0:00}", failedSpec.TakeNumber), ct);

                            await ClickStartGenerationAsync(sess, ct);

                            SingleSceneDispatchOutcome retryDispatch = await WaitForSingleSceneGenerationStartedAsync(
                                sess,
                                gridBaseline,
                                cardsBeforeRetry,
                                vidOptsBeforeRetry,
                                bubblesBeforeRetry,
                                unusualBeforeRetry,
                                hadUnusualBeforeRetry,
                                failedSpec.TakeNumber,
                                f + 1,
                                failedSpecs.Count,
                                ct);

                            if (retryDispatch.PageReloaded || retryDispatch.BlockedByUnusualActivity)
                                break;

                            if (retryDispatch.RefusedWithoutCard)
                                stillFailedAfterSoftening.Add(failedSpec.TakeNumber);
                        }

                        await WaitForAllDispatchedScenesToSettleAsync(sess, gridBaseline, "Aguardando Cenas Suavizadas", ct);
                        HashSet<int> pass2ErrorCardNums = await InspectAndRemoveSessionErrorCardsAsync(sess, gridBaseline, failedSpecs, ct);
                        foreach (int errN in pass2ErrorCardNums)
                            stillFailedAfterSoftening.Add(errN);
                    }
                }

                // Passo 7: Baixar em 720p todas as cenas concluídas nesta conversa do Google Flow
                List<FlowTakeSpec> takesCompletedInFlow = currentTakes
                    .Where(t => !stillFailedAfterSoftening.Contains(t.TakeNumber))
                    .ToList();

                if (takesCompletedInFlow.Count > 0)
                {
                    await DownloadAllCompletedTakesIn720pAsync(sess, gridBaseline, ep, takesCompletedInFlow, ct);
                }

                if (skippedAfterFlowRetriesOut != null && _config.AreAllGrokProfilesMarkedExhausted())
                {
                    foreach (int fn in stillFailedAfterSoftening)
                        skippedAfterFlowRetriesOut.Add(fn);
                }

                break;
            }
        }

        private async Task RegenerateSpecificTakesInFlowAsync(
            EpisodeWorkItem ep,
            List<FlowTakeSpec> targetTakes,
            List<string> allAssetFiles,
            Dictionary<string, string> ingredientToResolvedName,
            CancellationToken ct)
        {
            if (targetTakes == null || targetTakes.Count == 0)
                return;

            string sess = await OpenAndPrepareFlowProjectTabAsync(ct);
            await EnsureAgentPanelOpenAsync(sess, ct);
            await Task.Delay(600, ct);

            HashSet<int> skippedTmp = new HashSet<int>();
            await ExecuteOneByOneSceneConversationInFlowAsync(
                sess,
                ep,
                targetTakes,
                allAssetFiles,
                ingredientToResolvedName,
                skippedTmp,
                ct);

            List<FlowTakeSpec> failedAfterFlow = targetTakes.Where(t =>
            {
                string dstMp4 = Path.Combine(ep.TakesDir, string.Format("Take_{0:00}.mp4", t.TakeNumber));
                return !File.Exists(dstMp4) || new FileInfo(dstMp4).Length < 50 * 1024;
            }).ToList();

            if (failedAfterFlow.Count > 0)
            {
                if (!_config.AreAllGrokProfilesMarkedExhausted())
                {
                    string remLabels = string.Join(", ", failedAfterFlow.Select(t => string.Format("Take_{0:00}", t.TakeNumber)));
                    _log(string.Format("[Regerar Cena | Fallback -> Grok] {0} cena(s) continuaram com erro mesmo após pedir suavização na conversa do Flow ({1}) -> regerando no Grok Vídeo!",
                        failedAfterFlow.Count, remLabels));
                    await _grok.GenerateVideoTakesAsync(ep, failedAfterFlow, ingredientToResolvedName, ct);
                }
                else
                {
                    string remLabels = string.Join(", ", failedAfterFlow.Select(t => string.Format("Take_{0:00}", t.TakeNumber)));
                    _log(string.Format("[Regerar Cena | Aviso] {0} cena(s) não puderam ser geradas após suavizar na conversa do Flow ({1}) e o Grok está sem créditos.",
                        failedAfterFlow.Count, remLabels));
                }
            }

            EpisodeParser.RefreshDiskCounters(ep);
        }

        private async Task<string> OpenAndPrepareFlowProjectTabAsync(CancellationToken ct)
        {
            _log(string.Format("[Google Flow] Conectando ao projeto fixo no perfil '{0}'...", _config.FlowProfile));
            string sess = await _cdp.OpenOrAttachProfileTabAsync(_config.FlowProfile, _config.FlowProjectUrl, "flow.google.com", false, ct);

            string targetProjectUuid = "9b576f1d-9b0f-4103-ac8e-123edb00a1f0";
            if (!string.IsNullOrWhiteSpace(_config.FlowProjectUrl))
            {
                Match mUuid = Regex.Match(_config.FlowProjectUrl, @"/project/([a-f0-9\-]+)", RegexOptions.IgnoreCase);
                if (mUuid.Success)
                    targetProjectUuid = mUuid.Groups[1].Value;
            }

            string currentUrl = await _cdp.EvalStringAsync(sess, "location.href || ''", ct);
            if (currentUrl.IndexOf(targetProjectUuid, StringComparison.OrdinalIgnoreCase) < 0)
            {
                _log("[Google Flow] Navegando para o projeto configurado...");
                await _cdp.SendCommandAsync(
                    "Page.navigate",
                    new Dictionary<string, object> { { "url", _config.FlowProjectUrl } },
                    sess,
                    25000,
                    ct);
                await _cdp.WaitForDocumentReadyAsync(sess, 25000, ct);
                await Task.Delay(3500, ct);
            }

            await WaitForFlowPageLoadedAsync(sess, ct);
            return sess;
        }

    }
}
