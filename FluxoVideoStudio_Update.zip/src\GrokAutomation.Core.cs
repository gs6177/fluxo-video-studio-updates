using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace FluxoVideoStudio
{
    public partial class GrokAutomation
    {
        private readonly CdpController _cdp;
        private readonly PipelineConfig _config;
        private readonly Action<string> _log;
        private FlowAutomation _flowFallback;

        public GrokAutomation(CdpController cdp, PipelineConfig config, Action<string> logger)
        {
            _cdp = cdp;
            _config = config;
            _log = logger ?? delegate { };
        }

        public void SetFlowFallback(FlowAutomation flowFallback)
        {
            _flowFallback = flowFallback;
        }

        public async Task RunAsync(EpisodeWorkItem ep, CancellationToken ct)
        {
            if (!Directory.Exists(ep.AssetsDir))
                Directory.CreateDirectory(ep.AssetsDir);

            // 1. Regra 14: Sincronizar assets recorrentes de episódios anteriores (EP.1 / EP.2) e subpastas locais
            EpisodeParser.SyncRecurringAssetsFromPreviousEpisodes(ep, _log);
            if (_config.PreserveExistingAssets)
            {
                EpisodeParser.AutoAlignImportedAssetsOnDisk(ep, _log);
            }

            // 2. Regra 15 + Trava de Elenco: Conferir detalhadamente quais assets já existem em disco e preservar personagens prontos!
            List<string> requiredFiles = ep.AllRequiredFlowIngredients.Count > 0
                ? ep.AllRequiredFlowIngredients
                : ep.GrokSpecs.Select(s => s.TargetFileName).ToList();

            bool allRequiredExist = requiredFiles.Count > 0 && requiredFiles.All(req =>
            {
                string p = Path.Combine(ep.AssetsDir, req);
                return File.Exists(p) && new FileInfo(p).Length >= 4 * 1024;
            });

            List<GrokAssetSpec> specsToGenerate = ep.GrokSpecs;
            if (_config.PreserveExistingAssets && ep.GrokSpecs.Count > 0)
            {
                List<GrokAssetSpec> existingSpecs = new List<GrokAssetSpec>();
                List<GrokAssetSpec> missingOnly = new List<GrokAssetSpec>();

                foreach (GrokAssetSpec s in ep.GrokSpecs)
                {
                    string p = Path.Combine(ep.AssetsDir, s.TargetFileName);
                    if (File.Exists(p) && new FileInfo(p).Length >= 4 * 1024)
                        existingSpecs.Add(s);
                    else
                        missingOnly.Add(s);
                }

                if (existingSpecs.Count > 0)
                {
                    _log(string.Format("[Grok Imagine | Conferência de Elenco] {0} personagens/cenários já existentes conferidos em assets\\: {1}",
                        existingSpecs.Count,
                        string.Join(", ", existingSpecs.Select(x => x.TargetFileName))));
                }

                if (existingSpecs.Count > 0 && missingOnly.Count > 0)
                {
                    _log(string.Format("[Grok Imagine | Trava de Elenco] Preservando os {0} itens já existentes e gerando SOMENTE os {1} itens ausentes: {2}",
                        existingSpecs.Count,
                        missingOnly.Count,
                        string.Join(", ", missingOnly.Select(x => x.TargetFileName))));
                }
                specsToGenerate = missingOnly;
            }

            bool allExist = allRequiredExist && (ep.GrokSpecs.Count == 0 || specsToGenerate.Count == 0);

            if (allExist || string.IsNullOrWhiteSpace(ep.GrokPromptText) || specsToGenerate.Count == 0)
            {
                if (allExist || (ep.GrokSpecs.Count > 0 && specsToGenerate.Count == 0))
                {
                    _log(string.Format("[Grok Imagine] 100% dos personagens e cenários necessários já estão prontos em '{0}'. Mantendo elenco original!",
                        ep.AssetsDir));
                }
                else
                {
                    _log("[Grok Imagine] Nenhum novo personagem/cenário solicitado em prompt_grok_passo1_e_2.txt.");
                }
                MirrorAssetsToTempFlow(ep.AssetsDir);
                EpisodeParser.RefreshDiskCounters(ep);
                return;
            }

            // Se todas as contas do Grok já estiverem sem créditos, gera todas as imagens faltantes diretamente no Google Flow!
            if (_config.AreAllGrokProfilesMarkedExhausted() && _flowFallback != null)
            {
                _log(string.Format("[Grok -> Google Flow | Sem Créditos] Todas as contas do Grok estão sem créditos -> gerando {0} imagem(ns) faltante(s) em 9:16 diretamente no Google Flow!",
                    specsToGenerate.Count));
                await _flowFallback.GenerateMissingAssetsInFlowAsync(ep, specsToGenerate, ct);
                MirrorAssetsToTempFlow(ep.AssetsDir);
                EpisodeParser.RefreshDiskCounters(ep);
                return;
            }

            // 3. Separar os itens ausentes em:
            //    (A) Personagens Base e Cenários inéditos (gerados no Modo Agente sem anexo)
            //    (B) Novos Figurinos de Personagens Já Existentes (gerados anexando a foto do personagem base para manter 100% o mesmo rosto!)
            List<GrokAssetSpec> baseSpecsToGenerate = new List<GrokAssetSpec>();
            List<GrokAssetSpec> variantSpecsToGenerate = new List<GrokAssetSpec>();

            foreach (GrokAssetSpec ms in specsToGenerate)
            {
                string existingBaseCharPath = EpisodeParser.FindExistingBaseCharacterPathForVariantSpec(ep, ms);
                GrokAssetSpec episodeBaseCharSpec = EpisodeParser.FindBaseCharacterSpecInEpisode(ep, ms);

                if (!ms.IsScenario && (!string.IsNullOrEmpty(existingBaseCharPath) || episodeBaseCharSpec != null))
                {
                    variantSpecsToGenerate.Add(ms);
                }
                else
                {
                    baseSpecsToGenerate.Add(ms);
                }
            }

            // 3A. Se houver personagens base ou cenários inéditos ausentes, gera-os primeiro
            if (baseSpecsToGenerate.Count > 0)
            {
                await GenerateBaseSpecsBatchInAgentModeAsync(ep, baseSpecsToGenerate, ct);
            }

            // 3B. Se houver novas versões/figurinos de personagens existentes (do EP anterior ou deste EP), anexa a imagem anterior para manter 100% das características do original
            if (variantSpecsToGenerate.Count > 0)
            {
                if (_config.AreAllGrokProfilesMarkedExhausted() && _flowFallback != null)
                {
                    _log(string.Format("[Grok -> Google Flow | Sem Créditos] Contas do Grok sem créditos -> gerando {0} nova(s) versão(ões) de personagem(ns) no Google Flow anexando a imagem anterior!",
                        variantSpecsToGenerate.Count));
                    await _flowFallback.GenerateMissingAssetsInFlowAsync(ep, variantSpecsToGenerate, ct);
                }
                else
                {
                    _log(string.Format("[Grok Imagine | Continuidade de Personagem] {0} nova(s) versão(ões) de personagem(ns) existente(s) detectada(s) ({1}). Anexando a imagem anterior de cada personagem para manter 100% das características do original...",
                        variantSpecsToGenerate.Count,
                        string.Join(", ", variantSpecsToGenerate.Select(v => v.TargetFileName))));

                    foreach (GrokAssetSpec varSpec in variantSpecsToGenerate)
                    {
                        ct.ThrowIfCancellationRequested();
                        string baseCharPath = EpisodeParser.FindExistingBaseCharacterPathForVariantSpec(ep, varSpec);
                        if (string.IsNullOrEmpty(baseCharPath) || !File.Exists(baseCharPath))
                        {
                            _log(string.Format("[Grok Imagine | Continuidade de Personagem] Aviso: Imagem anterior para '{0}' não encontrada em disco; gerando via Agente...", varSpec.TargetFileName));
                            await GenerateBaseSpecsBatchInAgentModeAsync(ep, new List<GrokAssetSpec> { varSpec }, ct);
                        }
                        else
                        {
                            _log(string.Format("[Grok Imagine | Continuidade de Personagem] Conferida imagem anterior '{0}' -> Anexando no Grok para gerar '{1}' ({2})...",
                                Path.GetFileName(baseCharPath), varSpec.TargetFileName, varSpec.DisplayTitle));
                            await GenerateVariantSpecWithBaseCharacterAsync(ep, varSpec, baseCharPath, ct);
                        }
                    }
                }
            }

            MirrorAssetsToTempFlow(ep.AssetsDir);
            EpisodeParser.RefreshDiskCounters(ep);
            _log(string.Format("[Grok Imagine] Etapa concluída com sucesso! Assets prontos em '{0}' e espelhados em Temp\\flow_assets.", ep.AssetsDir));
        }


        private async Task WaitForGrokInteractiveReadyAsync(string sess, CancellationToken ct)
        {
            DateTime deadline = DateTime.UtcNow.AddSeconds(25);
            while (DateTime.UtcNow < deadline)
            {
                ct.ThrowIfCancellationRequested();
                string st = await _cdp.EvalStringAsync(sess, @"
(function(){
    var hasBox = !!Array.from(document.querySelectorAll('textarea, div[contenteditable=""true""], [role=""textbox""]')).find(el => {
        var r = el.getBoundingClientRect();
        return r.width > 100 && r.height > 20;
    });
    var hasModeBtn = !!Array.from(document.querySelectorAll('button, [role=""button""], [role=""radio""], [role=""tab""]')).find(el => {
        var t = (el.innerText || '').trim();
        var al = (el.getAttribute('aria-label') || '').trim();
        var r = el.getBoundingClientRect();
        return r.width > 12 && r.height > 12 &&
               (t === 'Agente' || t === 'Agent' || t === 'Imagem' || t === 'Image' || t === 'Vídeo' || t === 'Video' ||
                al === 'Agente' || al === 'Agent' || al === 'Imagem' || al === 'Image' || al === 'Vídeo' || al === 'Video');
    });
    return (hasBox && hasModeBtn) ? 'READY' : (hasBox ? 'BOX_ONLY' : 'WAIT');
})()", ct);
                if (st == "READY")
                {
                    await Task.Delay(1600, ct);
                    return;
                }
                await Task.Delay(500, ct);
            }
            await Task.Delay(1500, ct);
        }

        private async Task EnsureGrokImageModeAnd9x16Async(string sess, CancellationToken ct)
        {
            // 1. Remover anexos anteriores primeiro para que o seletor 'Aspecto de proporção' fique visível na barra
            await _cdp.EvalStringAsync(sess, @"
(function(){
    Array.from(document.querySelectorAll('button[aria-label*=""Remover imagem""], button[aria-label*=""Remove image""]')).forEach(b => b.click());
    return 'OK';
})()", ct);
            await Task.Delay(400, ct);

            // 2. Clicar no botão 'Imagem' (sem usar btn.innerText.length > 0 que sempre avaliava true!)
            Dictionary<string, object> imgModeBtn = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var els = Array.from(document.querySelectorAll('button, [role=""button""], [role=""radio""], [role=""tab""]'));
    var btn = els.find(el => {
        var t = (el.innerText || '').trim();
        var al = (el.getAttribute('aria-label') || '').trim();
        var r = el.getBoundingClientRect();
        return r.left > 245 && !el.closest('[data-sidebar], nav, aside') &&
               r.width > 12 && r.height > 12 &&
               (al === 'Imagem' || al === 'Image' || t === 'Imagem' || t === 'Image');
    });
    if (!btn) return null;
    var r = btn.getBoundingClientRect();
    return JSON.stringify({ x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) });
})()", ct);
            if (imgModeBtn != null)
            {
                await _cdp.ClickAtAsync(sess, Convert.ToInt32(imgModeBtn["x"]), Convert.ToInt32(imgModeBtn["y"]), ct);
                await Task.Delay(800, ct);
            }

            // 3. Selecionar obrigatoriamente a proporção 9:16 ANTES de anexar imagens ou alternar para Agente
            await EnsureGrokDropdownOptionAsync(sess, "Aspecto de proporção", "Aspect ratio", "9:16", ct);
            await Task.Delay(450, ct);
        }

        private async Task EnsureCleanGrokImagineHomeAsync(string sess, string profile, CancellationToken ct)
        {
            string curUrl = await _cdp.EvalStringAsync(sess, "location.href || ''", ct);
            bool isInsidePostOrChat = curUrl.IndexOf("/imagine/post/", StringComparison.OrdinalIgnoreCase) >= 0 ||
                                      curUrl.IndexOf("conversation=", StringComparison.OrdinalIgnoreCase) >= 0 ||
                                      curUrl.IndexOf("/imagine", StringComparison.OrdinalIgnoreCase) < 0;

            if (isInsidePostOrChat)
            {
                await _cdp.SendCommandAsync("Page.navigate", new Dictionary<string, object> { { "url", "https://grok.com/imagine" } }, sess, 20000, ct);
                await _cdp.WaitForDocumentReadyAsync(sess, 25000, ct);
                await WaitForGrokInteractiveReadyAsync(sess, ct);
            }
            else
            {
                await WaitForGrokInteractiveReadyAsync(sess, ct);
            }

            // Remover quaisquer imagens anexadas anteriormente na caixa de prompt
            await _cdp.EvalStringAsync(sess, @"
(function(){
    Array.from(document.querySelectorAll('button[aria-label*=""Remover imagem""], button[aria-label*=""Remove image""]')).forEach(b => b.click());
    return 'OK';
})()", ct);
            await Task.Delay(450, ct);
        }


        private async Task<bool> HasQuotaExhaustedBannerAsync(string sess, CancellationToken ct)
        {
            string res = await _cdp.EvalStringAsync(sess, @"
(function(){
    var t = (document.body && document.body.innerText) ? document.body.innerText : '';
    if (/You've used up your media generation credits/i.test(t) ||
        /limite de uso atingido/i.test(t) ||
        /adicione cr[eé]ditos/i.test(t) ||
        /atingiu seu limite/i.test(t) ||
        /atingiu o limite/i.test(t) ||
        /usage limit reached/i.test(t) ||
        /rate limit reached/i.test(t) ||
        /out of credits/i.test(t) ||
        /usagePoolExhausted/i.test(t)) {
        return 'EXHAUSTED';
    }
    return 'OK';
})()", ct);
            return res == "EXHAUSTED";
        }

        private async Task EnsureAgenteModeSelectedAsync(string sess, CancellationToken ct)
        {
            Dictionary<string, object> info = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var els = Array.from(document.querySelectorAll('button, [role=""button""], [role=""radio""], [role=""tab""]'));
    var btn = els.find(el => {
        var t = (el.innerText || '').trim();
        var al = (el.getAttribute('aria-label') || '').trim();
        var r = el.getBoundingClientRect();
        return r.left > 245 && !el.closest('[data-sidebar], nav, aside') &&
               r.width > 15 && r.height > 15 &&
               (t === 'Agente' || t === 'Agent' || al === 'Agente' || al === 'Agent');
    });
    if (!btn) return JSON.stringify({ found: false });

    var r = btn.getBoundingClientRect();
    var txt = (btn.innerText || '').trim();
    var pressed = btn.getAttribute('aria-pressed') === 'true' ||
                  btn.getAttribute('aria-checked') === 'true' ||
                  btn.getAttribute('aria-selected') === 'true' ||
                  btn.getAttribute('data-state') === 'active' ||
                  btn.getAttribute('data-active') === 'true' ||
                  txt === 'Agente' ||
                  txt === 'Agent' ||
                  r.width >= 65 ||
                  location.pathname.indexOf('/imagine/agent') >= 0;

    return JSON.stringify({
        found: true,
        active: pressed,
        x: Math.round(r.left + r.width/2),
        y: Math.round(r.top + r.height/2)
    });
})()", ct);

            if (info != null && Convert.ToBoolean(info["found"]))
            {
                bool active = Convert.ToBoolean(info["active"]);
                if (!active)
                {
                    await _cdp.ClickAtAsync(sess, Convert.ToInt32(info["x"]), Convert.ToInt32(info["y"]), ct);
                    await Task.Delay(800, ct);
                    _log("[Grok Imagine] Botão 'Agente' ativado com sucesso.");
                }
                else
                {
                    _log("[Grok Imagine] Função 'Agente' já está ativa.");
                }
            }
            else
            {
                // Navega diretamente para /imagine/agent caso o chip esteja oculto
                await _cdp.SendCommandAsync("Page.navigate", new Dictionary<string, object> { { "url", "https://grok.com/imagine/agent" } }, sess, 20000, ct);
                await _cdp.WaitForDocumentReadyAsync(sess, 20000, ct);
                await Task.Delay(1200, ct);
            }
        }

        private async Task<int> CountThumbnailsOrGeneratedImagesAsync(string sess, CancellationToken ct)
        {
            string s = await _cdp.EvalStringAsync(sess, @"
(function(){
    return Array.from(document.querySelectorAll('img')).filter(img => {
        var src = (img.currentSrc || img.src || '');
        if (src.indexOf('media.x.ai') >= 0 || src.indexOf('agent-skills') >= 0 || src.indexOf('grok-web') >= 0 || src.indexOf('/website/') >= 0) return false;
        var r = img.getBoundingClientRect();
        return r.width >= 90 && r.height >= 120 && img.complete && img.naturalWidth >= 200 &&
               (src.indexOf('/generated/') >= 0 || src.indexOf('assets.grok.com/users/') >= 0);
    }).length;
})()", ct);
            int n;
            return int.TryParse(s, out n) ? n : 0;
        }

        private async Task<bool> InjectPromptIntoGrokBoxAsync(string sess, string promptText, CancellationToken ct)
        {
            string b64 = Convert.ToBase64String(Encoding.UTF8.GetBytes(promptText));
            string res = await _cdp.EvalStringAsync(sess, string.Format(@"
(function(){{
    var bytes = Uint8Array.from(atob('{0}'), c => c.charCodeAt(0));
    var text = new TextDecoder('utf-8').decode(bytes);

    var ta = Array.from(document.querySelectorAll('textarea')).find(el => {{
        var r = el.getBoundingClientRect();
        return r.left > 245 && r.width > 100 && r.height > 20;
    }});
    if (ta) {{
        ta.focus();
        var nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value').set;
        nativeSetter.call(ta, text);
        ta.dispatchEvent(new Event('input', {{ bubbles: true }}));
        ta.dispatchEvent(new Event('change', {{ bubbles: true }}));
        return 'TEXTAREA:' + ta.value.length;
    }}

    var ce = Array.from(document.querySelectorAll('div[contenteditable=""true""], [role=""textbox""]')).find(el => {{
        var r = el.getBoundingClientRect();
        return r.left > 245 && r.width > 100 && r.height > 20;
    }});
    if (ce) {{
        ce.focus();
        document.execCommand('selectAll', false, null);
        document.execCommand('insertText', false, text);
        return 'CE:' + (ce.innerText || '').length;
    }}
    return '';
}})()", b64), ct);

            return !string.IsNullOrEmpty(res);
        }

        private async Task SubmitGrokPromptAsync(string sess, CancellationToken ct)
        {
            Dictionary<string, object> btnPt = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var btns = Array.from(document.querySelectorAll('button[type=""submit""], button[aria-label*=""submeter"" i], button[aria-label*=""Enviar"" i], button[aria-label*=""Submit"" i], button[aria-label*=""Send"" i]'))
        .filter(b => {
            var r = b.getBoundingClientRect();
            return !b.disabled && r.width > 15 && r.left > 245 && !b.closest('[data-sidebar], nav, aside');
        });
    if (btns.length > 0) {
        var b = btns[btns.length - 1];
        var r = b.getBoundingClientRect();
        return JSON.stringify({ x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) });
    }
    return null;
})()", ct);

            if (btnPt != null)
            {
                await _cdp.ClickAtAsync(sess, Convert.ToInt32(btnPt["x"]), Convert.ToInt32(btnPt["y"]), ct);
            }
            else
            {
                await _cdp.PressEnterAsync(sess, ct);
            }
        }


        private async Task<string> ReadGrokBoxTextAsync(string sess, CancellationToken ct)
        {
            string s = await _cdp.EvalStringAsync(sess, @"
(function(){
    var ce = Array.from(document.querySelectorAll('div[contenteditable=""true""], [role=""textbox""], textarea')).find(el => {
        var r = el.getBoundingClientRect();
        return r.width > 100 && r.height > 20;
    });
    return ce ? (ce.value !== undefined ? ce.value : (ce.innerText || '')).trim() : '';
})()", ct);
            return (s ?? "").Trim();
        }

        private async Task EnsureThumbnailViewerOpenAsync(string sess, int expectedCount, CancellationToken ct)
        {
            int visibleThumbs = await GetVisibleThumbnailCountAsync(sess, ct);
            if (visibleThumbs > 0) return;

            _log("[Grok Imagine] Abrindo visualização detalhada do post para exibir coluna de miniaturas à esquerda...");
            Dictionary<string, object> firstImgPt = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var imgs = Array.from(document.querySelectorAll('img')).filter(img => {
        var r = img.getBoundingClientRect();
        return r.width >= 90 && r.height >= 120 && img.complete && img.naturalWidth >= 200;
    });
    if (imgs.length === 0) return null;
    // Pega a primeira imagem do lote recém-gerado
    var startIdx = Math.max(0, imgs.length - " + expectedCount + @");
    var target = imgs[startIdx];
    target.scrollIntoView({ block: 'center' });
    var r = target.getBoundingClientRect();
    return JSON.stringify({ x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) });
})()", ct);

            if (firstImgPt != null)
            {
                await _cdp.ClickAtAsync(sess, Convert.ToInt32(firstImgPt["x"]), Convert.ToInt32(firstImgPt["y"]), ct);
                await Task.Delay(1500, ct);
            }
        }

        private async Task<int> GetVisibleThumbnailCountAsync(string sess, CancellationToken ct)
        {
            string s = await _cdp.EvalStringAsync(sess, @"
(function(){
    return Array.from(document.querySelectorAll('button[aria-label^=""Thumbnail ""]'))
        .filter(b => b.getBoundingClientRect().width > 10).length;
})()", ct);
            int n;
            return int.TryParse(s, out n) ? n : 0;
        }


        public void MirrorAssetsToTempFlow(string assetsDir)
        {
            if (!Directory.Exists(assetsDir)) return;
            if (!Directory.Exists(_config.TempFlowAssetsDir))
                Directory.CreateDirectory(_config.TempFlowAssetsDir);

            foreach (string f in Directory.GetFiles(assetsDir))
            {
                string ext = Path.GetExtension(f);
                if (string.Equals(ext, ".jpg", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(ext, ".jpeg", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(ext, ".png", StringComparison.OrdinalIgnoreCase))
                {
                    string dst = Path.Combine(_config.TempFlowAssetsDir, Path.GetFileName(f));
                    File.Copy(f, dst, true);
                }
            }
        }


        private async Task<Dictionary<string, object>> FindGrokDownloadButtonPointAsync(string sess, CancellationToken ct)
        {
            return await _cdp.EvalJsonAsync(sess, @"
(function(){
    var candidates = Array.from(document.querySelectorAll('button[aria-label=""Baixar""], button[aria-label=""Download""], a[download]'))
        .filter(b => {
            var txt = (b.innerText || '').trim().toLowerCase();
            if (txt.includes('tudo') || txt.includes('all') || txt.includes('segment')) return false;
            var r = b.getBoundingClientRect();
            return r.width > 10 && r.height > 10;
        });
    if (candidates.length === 0) return null;
    var b = candidates[candidates.length - 1];
    var r = b.getBoundingClientRect();
    return JSON.stringify({ x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) });
})()", ct);
        }


        private async Task EnsureGrokDropdownOptionAsync(
            string sess,
            string ariaLabelPt,
            string ariaLabelEn,
            string wantedValue,
            CancellationToken ct)
        {
            bool isRatio = string.Equals(wantedValue, "9:16", StringComparison.OrdinalIgnoreCase);
            string findTriggerJs = string.Format(@"
(function(){{
    var isRatio = {2};
    var btns = Array.from(document.querySelectorAll('button')).filter(el => {{
        var r = el.getBoundingClientRect();
        return r.left > 245 && r.width > 10 && !el.closest('[data-sidebar], nav, aside');
    }});
    var b = btns.find(el => {{
        var al = (el.getAttribute('aria-label') || '');
        var alLow = al.toLowerCase();
        return al.indexOf('{0}') >= 0 || al.indexOf('{1}') >= 0 ||
               (isRatio && (alLow.indexOf('aspect ratio') >= 0 || alLow.indexOf('aspecto de propor') >= 0 || alLow.indexOf('proporção') >= 0 || alLow.indexOf('proporcao') >= 0));
    }});
    if (!b && isRatio) {{
        b = btns.find(el => /^(1:1|16:9|9:16|3:2|2:3|4:3|3:4|Autom[aá]tico|Auto)$/i.test((el.innerText || '').trim()));
    }}
    if (!b) return null;
    var txt = (b.innerText || '').trim();
    var r = b.getBoundingClientRect();
    return JSON.stringify({{ current: txt, x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) }});
}})()", ariaLabelPt, ariaLabelEn, isRatio ? "true" : "false");

            for (int attempt = 0; attempt < 2; attempt++)
            {
                Dictionary<string, object> trigger = await _cdp.EvalJsonAsync(sess, findTriggerJs, ct);
                if (trigger == null) return;

                string current = Convert.ToString(trigger["current"] ?? "");
                if (current.IndexOf(wantedValue, StringComparison.OrdinalIgnoreCase) >= 0)
                    return;

                await _cdp.ClickAtAsync(sess, Convert.ToInt32(trigger["x"]), Convert.ToInt32(trigger["y"]), ct);
                await Task.Delay(550, ct);

                // NUNCA incluir '[data-radix-popper-content-wrapper] div' genérico, pois o container pai do menu tem children <= 4 e seu centro cai sobre '1:1 Quadrado'!
                Dictionary<string, object> optPt = await _cdp.EvalJsonAsync(sess, string.Format(@"
(function(){{
    var want = '{0}'.toLowerCase();
    var items = Array.from(document.querySelectorAll('[role=""menuitemradio""], [role=""option""], [role=""menuitem""], [data-radix-popper-content-wrapper] button'))
        .filter(el => {{
            var r = el.getBoundingClientRect();
            if (r.width <= 10 || r.height <= 10) return false;
            if (el.querySelector('[role=""menuitemradio""], [role=""option""], [role=""menuitem""]')) return false;
            return true;
        }});
    var m = items.find(el => {{
        var raw = (el.innerText || '').trim().toLowerCase();
        var firstLine = raw.split(/\r?\n/)[0].trim();
        var hasExactSpan = Array.from(el.querySelectorAll('span')).some(s => (s.innerText || '').trim().toLowerCase() === want);
        return raw === want || firstLine === want || hasExactSpan;
    }}) || items.find(el => (el.innerText || '').trim().toLowerCase().indexOf(want) === 0);
    if (!m) return null;
    var r = m.getBoundingClientRect();
    return JSON.stringify({{ x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) }});
}})()", wantedValue), ct);

                if (optPt != null)
                {
                    await _cdp.ClickAtAsync(sess, Convert.ToInt32(optPt["x"]), Convert.ToInt32(optPt["y"]), ct);
                    await Task.Delay(450, ct);
                }
                else
                {
                    await _cdp.PressEscapeAsync(sess, ct);
                    await Task.Delay(250, ct);
                }
            }
        }

        public async Task CheckAllGrokProfilesStatusAsync(CancellationToken ct)
        {
            await _cdp.EnsureConnectedAsync(ct);
            foreach (string profile in _config.GrokProfiles.ToList())
            {
                ct.ThrowIfCancellationRequested();
                try
                {
                    string sess = await _cdp.OpenOrAttachProfileTabAsync(profile, _config.GrokUrl, "grok.com", false, ct);
                    await WaitForGrokInteractiveReadyAsync(sess, ct);
                    bool exhausted = await HasQuotaExhaustedBannerAsync(sess, ct);

                    string acctName = await _cdp.EvalStringAsync(sess, @"
(function(){
    var b = Array.from(document.querySelectorAll('button')).find(el => {
        var al = (el.getAttribute('aria-label') || '');
        return al.indexOf('Menu da conta') >= 0 || al.indexOf('Account') >= 0;
    });
    if (!b) return '';
    var al = b.getAttribute('aria-label') || '';
    return al.replace(/^Menu da conta,\s*/i, '').replace(/^Account menu,\s*/i, '').trim();
})()", ct);

                    string statusText = exhausted
                        ? ("LIMITE ATINGIDO" + (!string.IsNullOrEmpty(acctName) ? " (" + acctName + ")" : ""))
                        : ("DISPONÍVEL" + (!string.IsNullOrEmpty(acctName) ? " (" + acctName + ")" : ""));

                    _config.SetProfileStatus(profile, statusText);
                    _log(string.Format("[Contas Grok] {0} -> {1}", profile, statusText));
                }
                catch (Exception ex)
                {
                    _config.SetProfileStatus(profile, "ERRO AO VERIFICAR");
                    _log(string.Format("[Contas Grok] Aviso ao verificar '{0}': {1}", profile, ex.Message));
                }
            }
        }

    }
}
