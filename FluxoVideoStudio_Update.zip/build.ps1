$ErrorActionPreference = "Stop"

$projectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$srcDir = Join-Path $projectRoot "src"
$outExe = Join-Path $projectRoot "FluxoVideoStudio.exe"

$csc = "C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if (-not (Test-Path $csc)) {
    throw "Compilador nativo C# (csc.exe) não encontrado em: $csc"
}

$fwDir = "C:\Windows\Microsoft.NET\Framework64\v4.0.30319"
$wpfDir = Join-Path $fwDir "WPF"

$refs = @(
    (Join-Path $fwDir "System.dll"),
    (Join-Path $fwDir "System.Core.dll"),
    (Join-Path $fwDir "System.Drawing.dll"),
    (Join-Path $fwDir "System.Management.dll"),
    (Join-Path $fwDir "System.Net.Http.dll"),
    (Join-Path $fwDir "System.Web.Extensions.dll"),
    (Join-Path $fwDir "System.Xaml.dll"),
    (Join-Path $wpfDir "WindowsBase.dll"),
    (Join-Path $wpfDir "PresentationCore.dll"),
    (Join-Path $wpfDir "PresentationFramework.dll"),
    (Join-Path $wpfDir "UIAutomationClient.dll"),
    (Join-Path $wpfDir "UIAutomationTypes.dll")
)

$refArgs = $refs | ForEach-Object { "/r:`"$_`"" }
$srcFiles = Get-ChildItem -Path $srcDir -Filter "*.cs" | ForEach-Object { "`"$($_.FullName)`"" }

# Encerra instância anterior caso esteja aberta durante recompilação
Get-Process -Name "FluxoVideoStudio" -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
Start-Sleep -Milliseconds 300

$allArgs = @(
    "/nologo",
    "/target:winexe",
    "/optimize+",
    "/utf8output",
    "/out:`"$outExe`""
) + $refArgs + $srcFiles

Write-Host "Compilando aplicativo nativo Windows: $outExe ..." -ForegroundColor Cyan
$proc = Start-Process -FilePath $csc -ArgumentList ($allArgs -join " ") -NoNewWindow -Wait -PassThru

if ($proc.ExitCode -ne 0 -or -not (Test-Path $outExe)) {
    throw "Falha na compilação (ExitCode: $($proc.ExitCode))."
}

$sizeKb = [Math]::Round((Get-Item $outExe).Length / 1KB, 1)
Write-Host "COMPILADO COM SUCESSO! Executável nativo pronto: $outExe ($sizeKb KB)" -ForegroundColor Green
