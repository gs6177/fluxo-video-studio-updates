using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace FluxoVideoStudio
{
    public partial class FlowAutomation
    {
        public async Task GenerateCoversInFlowAsync(
            EpisodeWorkItem ep1,
            string coversDir,
            List<CoverGenerationItem> pendingCovers,
            List<string> cleanCharPaths,
            Dictionary<int, string> modelBannerByIdx,
            Action onEachCoverSavedUiRefresh,
            CancellationToken ct)
        {
            if (ep1 == null || string.IsNullOrEmpty(coversDir) || pendingCovers == null || pendingCovers.Count == 0)
                return;

            Directory.CreateDirectory(coversDir);

            // Garantia extra: nenhum destino em pendingCovers pode existir em disco antes do CollectAndSaveCompletedSessionImagesAsync!
            foreach (CoverGenerationItem ci in pendingCovers)
            {
                string dst = Path.Combine(coversDir, ci.TargetFileName);
                if (File.Exists(dst))
                {
                    try { File.Delete(dst); } catch { }
                }
            }

            string sess = await OpenAndPrepareFlowProjectTabAsync(ct);
            await EnsureAgentPanelOpenAsync(sess, ct);

            List<string> tempRefsToUpload = new List<string>();
            List<string> cleanCharFileNames = new List<string>();
            Dictionary<int, string> bannerFileNameByModel = new Dictionary<int, string>();
            HashSet<string> savedMd5Hashes = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            Directory.CreateDirectory(_config.TempFlowAssetsDir);

            if (cleanCharPaths != null)
            {
                foreach (string charPath in cleanCharPaths)
                {
                    if (string.IsNullOrEmpty(charPath) || !File.Exists(charPath)) continue;
                    string fn = Path.GetFileName(charPath);
                    string tmpCopy = Path.Combine(_config.TempFlowAssetsDir, fn);
                    try
                    {
                        File.Copy(charPath, tmpCopy, true);
                        string md5 = ComputeBytesMd5Hex(File.ReadAllBytes(charPath));
                        if (!string.IsNullOrEmpty(md5)) savedMd5Hashes.Add(md5);
                    }
                    catch { }
                    if (!tempRefsToUpload.Contains(tmpCopy, StringComparer.OrdinalIgnoreCase))
                        tempRefsToUpload.Add(tmpCopy);
                    if (!cleanCharFileNames.Contains(fn, StringComparer.OrdinalIgnoreCase))
                        cleanCharFileNames.Add(fn);
                }
            }

            if (modelBannerByIdx != null)
            {
                foreach (KeyValuePair<int, string> kv in modelBannerByIdx)
                {
                    if (string.IsNullOrEmpty(kv.Value) || !File.Exists(kv.Value)) continue;
                    string fn = Path.GetFileName(kv.Value);
                    string tmpCopy = Path.Combine(_config.TempFlowAssetsDir, fn);
                    try
                    {
                        File.Copy(kv.Value, tmpCopy, true);
                        string md5 = ComputeBytesMd5Hex(File.ReadAllBytes(kv.Value));
                        if (!string.IsNullOrEmpty(md5)) savedMd5Hashes.Add(md5);
                    }
                    catch { }
                    if (!tempRefsToUpload.Contains(tmpCopy, StringComparer.OrdinalIgnoreCase))
                        tempRefsToUpload.Add(tmpCopy);
                    bannerFileNameByModel[kv.Key] = fn;
                }
            }

            if (tempRefsToUpload.Count > 0)
            {
                await UploadAssetsToFlowProjectAsync(sess, tempRefsToUpload, ct);
            }

            string stagingDl = Path.Combine(Path.GetTempPath(), "fluxo_flow_cov_" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(stagingDl);
            await _cdp.SetDownloadBehaviorAsync(stagingDl, ct);

            try
            {
                EpisodeWorkItem coverTargetEp = new EpisodeWorkItem();
                coverTargetEp.StoryName = ep1.StoryName;
                coverTargetEp.Genre = ep1.Genre;
                coverTargetEp.EpisodeName = ep1.EpisodeName;
                coverTargetEp.EpisodeNumber = ep1.EpisodeNumber;
                coverTargetEp.StoryRootPath = ep1.StoryRootPath;
                coverTargetEp.EpisodePath = ep1.EpisodePath;
                coverTargetEp.AssetsDir = coversDir;
                coverTargetEp.TakesDir = ep1.TakesDir;

                HashSet<string> usedCardKeys = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

                IEnumerable<IGrouping<int, CoverGenerationItem>> groups = pendingCovers.GroupBy(x => x.ModelIndex);
                foreach (IGrouping<int, CoverGenerationItem> grp in groups)
                {
                    ct.ThrowIfCancellationRequested();
                    await ToggleAddElementsMenuAsync(sess, false, ct);
                    await EnsureAgentPanelOpenAsync(sess, ct);
                    await ScrollAgentPanelToBottomAsync(sess, ct);
                    await ClearAttachedPromptChipsAsync(sess, ct);
                    string leftoverCoverTxt = await ReadCurrentFlowTextboxAsync(sess, ct);
                    if (!string.IsNullOrWhiteSpace(leftoverCoverTxt))
                    {
                        await InsertTextIntoFlowTextboxAsync(sess, "", true, ct);
                        await Task.Delay(250, ct);
                    }

                    List<string> refsForThisModel = new List<string>(cleanCharFileNames);
                    string bannerFn;
                    if (bannerFileNameByModel.TryGetValue(grp.Key, out bannerFn) && !string.IsNullOrEmpty(bannerFn))
                        refsForThisModel.Add(bannerFn);

                    List<GrokAssetSpec> flowCoverSpecs = new List<GrokAssetSpec>();
                    Dictionary<string, string> specToBaseRefName = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

                    int localIdx = 1;
                    foreach (CoverGenerationItem ci in grp)
                    {
                        GrokAssetSpec gs = new GrokAssetSpec();
                        gs.OrderIndex = localIdx++;
                        gs.IsScenario = false;
                        gs.LabelPrefix = "Capa " + gs.OrderIndex;
                        gs.DisplayTitle = ci.DisplayLabel;
                        gs.TargetFileName = ci.TargetFileName;
                        gs.RawPromptLine = ci.FullPrompt;
                        flowCoverSpecs.Add(gs);

                        if (refsForThisModel.Count > 0)
                        {
                            specToBaseRefName[ci.TargetFileName] = string.Join(" + ", refsForThisModel);
                        }
                    }

                    await RunFlowImageBatchesInSessionAsync(
                        sess,
                        coverTargetEp,
                        flowCoverSpecs,
                        refsForThisModel.Count > 0 ? specToBaseRefName : null,
                        refsForThisModel,
                        false,
                        usedCardKeys,
                        savedMd5Hashes,
                        stagingDl,
                        ct);

                    int savedInGroup = 0;
                    foreach (GrokAssetSpec gs in flowCoverSpecs)
                    {
                        string checkPath = Path.Combine(coversDir, gs.TargetFileName);
                        if (File.Exists(checkPath) && new FileInfo(checkPath).Length >= 1024)
                            savedInGroup++;
                    }
                    _log(string.Format("[Google Flow | Capas 9:16] Modelo {0}: {1}/{2} capa(s) baixada(s) em '{3}'.",
                        grp.Key, savedInGroup, flowCoverSpecs.Count, coversDir));

                    if (onEachCoverSavedUiRefresh != null)
                    {
                        try { onEachCoverSavedUiRefresh(); } catch { }
                    }
                }
            }
            finally
            {
                Task ignoredCleanup = Task.Run(async () =>
                {
                    try { await _cdp.ResetDownloadBehaviorToDefaultAsync(); } catch { }
                    try { Directory.Delete(stagingDl, true); } catch { }
                });
            }
        }

        /// <summary>
        /// Resgata e baixa diretamente da grade atual do projeto Google Flow as capas 9:16 já geradas,
        /// sem precisar regerar nem gastar créditos!
        /// </summary>
        public async Task<int> SalvageLatestCoversFromFlowGridAsync(
            EpisodeWorkItem ep1,
            StoryCoverConfig coverCfg,
            Action onUiRefresh,
            CancellationToken ct)
        {
            if (ep1 == null || coverCfg == null)
                return 0;

            List<CoverGenerationItem> items = CoverGenerator.BuildCoverGenerationItems(ep1, coverCfg);
            if (items.Count == 0)
                return 0;

            string coversDir = CoverGenerator.GetStoryCoversDir(ep1);
            Directory.CreateDirectory(coversDir);

            string sess = await OpenAndPrepareFlowProjectTabAsync(ct);

            string stagingDl = Path.Combine(Path.GetTempPath(), "fluxo_salvage_cov_" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(stagingDl);
            await _cdp.SetDownloadBehaviorAsync(stagingDl, ct);

            int downloadedCount = 0;
            try
            {
                // Varre o topo da grade principal (mais recentes primeiro) buscando tiles de imagem geradas (excluindo uploads de char_limpo / modelo_escrita)
                Dictionary<string, object> raw = await _cdp.EvalJsonAsync(sess, @"
(function(){
    var vp = document.querySelector('cdk-virtual-scroll-viewport.tiles-container') || document.querySelector('cdk-virtual-scroll-viewport');
    if (vp && vp.scrollTop > 8) vp.scrollTop = 0;

    var allTiles = Array.from(document.querySelectorAll('flow-image-tile, flow-asset-tile, [data-asb-id]'));
    var out = [];
    var seen = new Set();

    for (var i = 0; i < allTiles.length && out.length < 25; i++) {
        var el = allTiles[i];
        var host = el.closest('flow-image-tile, flow-video-tile, flow-asset-tile') || el;
        if (host.querySelector('video')) continue;
        var img = host.querySelector('img.thumbnail') || host.querySelector('img');
        if (!img) continue;
        var src = img.currentSrc || img.src || img.getAttribute('src') || '';
        if (!src || src.length < 12) continue;
        var mAsb = src.match(/\/asb\/([A-Za-z0-9_\-]{25,80})/);
        var asb = mAsb ? mAsb[1] : (host.getAttribute('data-asb-id') || '');
        var key = asb || src;
        if (seen.has(key)) continue;
        seen.add(key);

        var alt = ((img.getAttribute('alt') || '') + ' ' + (img.getAttribute('aria-label') || '') + ' ' + (host.innerText || '')).trim();
        if (/char_limpo_|modelo_escrita_|^\d{2}_(?:Personagem|Cenario)_/i.test(alt)) continue;

        var nw = img.naturalWidth || 0;
        var nh = img.naturalHeight || 0;
        // Ignora faixas horizontais de modelo_escrita (largura > altura)
        if (nw > 50 && nh > 50 && nw > nh) continue;

        out.push({ asb: asb, url: src, alt: alt });
    }
    return JSON.stringify({ items: out });
})()", ct);

                if (raw == null || !raw.ContainsKey("items") || !(raw["items"] is IEnumerable))
                    return 0;

                List<SessionCompletedImageInfo> recentCards = new List<SessionCompletedImageInfo>();
                foreach (object o in (IEnumerable)raw["items"])
                {
                    Dictionary<string, object> d = o as Dictionary<string, object>;
                    if (d == null) continue;
                    SessionCompletedImageInfo inf = new SessionCompletedImageInfo();
                    inf.AsbId = d.ContainsKey("asb") ? Convert.ToString(d["asb"] ?? "") : "";
                    inf.ImageUrl = d.ContainsKey("url") ? Convert.ToString(d["url"] ?? "") : "";
                    inf.AltPrompt = d.ContainsKey("alt") ? Convert.ToString(d["alt"] ?? "") : "";
                    if (!string.IsNullOrEmpty(inf.ImageUrl))
                        recentCards.Add(inf);
                }

                if (recentCards.Count == 0)
                {
                    _log("[Google Flow | Resgatar Capas] Nenhuma imagem de capa encontrada no topo da grade do projeto Flow.");
                    return 0;
                }

                // Se algum card não tiver o nome Capa_ModeloX_OpcaoY no alt, tenta ler via 'Reutilizar comando' nos N cards mais recentes
                int inspectLimit = Math.Min(recentCards.Count, items.Count + 3);
                for (int c = 0; c < inspectLimit; c++)
                {
                    SessionCompletedImageInfo card = recentCards[c];
                    if (card.AltPrompt.IndexOf("Capa_Modelo", StringComparison.OrdinalIgnoreCase) >= 0)
                        continue;

                    string lookupTok = !string.IsNullOrEmpty(card.AsbId) ? card.AsbId : card.ImageUrl;
                    if (string.IsNullOrEmpty(lookupTok)) continue;

                    try
                    {
                        Dictionary<string, object> center = await ScrollToAndLocateTileByAsbIdAsync(sess, lookupTok, ct);
                        if (center == null) continue;
                        await _cdp.HoverAsync(sess, Convert.ToInt32(center["x"]), Convert.ToInt32(center["y"]), ct);
                        await Task.Delay(320, ct);

                        string b64Tok = Convert.ToBase64String(Encoding.UTF8.GetBytes(lookupTok));
                        Dictionary<string, object> reusePt = await _cdp.EvalJsonAsync(sess, string.Format(@"
(function(){{
    var want = atob('{0}');
    var tile = Array.from(document.querySelectorAll('flow-image-tile, flow-asset-tile, [data-asb-id]')).find(t => {{
        var host = t.closest('flow-image-tile, flow-asset-tile') || t;
        var img = host.querySelector('img');
        var u = (img ? ((img.currentSrc || img.src || img.getAttribute('src') || '')) : '') + ' ' + (host.getAttribute('data-asb-id') || '');
        return u.indexOf(want) >= 0;
    }});
    if (!tile) return null;
    var hostTile = tile.closest('flow-image-tile, flow-asset-tile') || tile;
    var btn = Array.from(hostTile.querySelectorAll('button')).find(b => /reutilizar|reuse/i.test((b.getAttribute('aria-label') || '') + ' ' + (b.innerText || '')));
    if (!btn) return null;
    var r = btn.getBoundingClientRect();
    if (r.width < 4) {{ btn.click(); return JSON.stringify({{ clicked: true, x: 0, y: 0 }}); }}
    return JSON.stringify({{ clicked: false, x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2) }});
}})()", b64Tok), ct);

                        if (reusePt != null)
                        {
                            bool alreadyClicked = reusePt.ContainsKey("clicked") && Convert.ToBoolean(reusePt["clicked"]);
                            if (!alreadyClicked)
                                await _cdp.ClickAtAsync(sess, Convert.ToInt32(reusePt["x"]), Convert.ToInt32(reusePt["y"]), ct);
                            await Task.Delay(420, ct);
                            string boxTxt = await ReadCurrentFlowTextboxAsync(sess, ct);
                            if (!string.IsNullOrWhiteSpace(boxTxt))
                            {
                                card.AltPrompt = boxTxt;
                                await InsertTextIntoFlowTextboxAsync(sess, "", true, ct);
                            }
                            await ClearAttachedPromptChipsAsync(sess, ct);
                        }
                    }
                    catch { }
                }

                // Faz o casamento de cada CoverGenerationItem com o card MAIS RECENTE correspondente (recentCards[0] = mais recente!)
                string oldBackupDir = Path.Combine(coversDir, "_historico_antigas");
                HashSet<int> usedCardIdx = new HashSet<int>();
                HashSet<string> savedHashes = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

                for (int i = 0; i < items.Count; i++)
                {
                    CoverGenerationItem want = items[i];
                    int matchCardIdx = -1;

                    // 1º: Busca menção exata ao nome Capa_ModeloX_OpcaoY
                    string stem = Path.GetFileNameWithoutExtension(want.TargetFileName);
                    for (int c = 0; c < recentCards.Count; c++)
                    {
                        if (usedCardIdx.Contains(c)) continue;
                        if ((recentCards[c].AltPrompt ?? "").IndexOf(stem, StringComparison.OrdinalIgnoreCase) >= 0)
                        {
                            matchCardIdx = c;
                            break;
                        }
                    }

                    // 2º: Busca palavras-chave exclusivas do estilo do modelo
                    if (matchCardIdx < 0)
                    {
                        for (int c = 0; c < Math.Min(recentCards.Count, items.Count + 2); c++)
                        {
                            if (usedCardIdx.Contains(c)) continue;
                            string ap = recentCards[c].AltPrompt ?? "";
                            if (string.IsNullOrWhiteSpace(ap)) continue;
                            string coverTitleKey = !string.IsNullOrWhiteSpace(coverCfg.CoverTitle)
                                ? coverCfg.CoverTitle
                                : CoverGenerator.ExtractDefaultCoverTitle(ep1);
                            if ((string.IsNullOrWhiteSpace(coverTitleKey) || ap.IndexOf(coverTitleKey, StringComparison.OrdinalIgnoreCase) < 0) &&
                                ap.IndexOf("poster", StringComparison.OrdinalIgnoreCase) < 0 &&
                                ap.IndexOf("pôster", StringComparison.OrdinalIgnoreCase) < 0)
                                continue;
                            matchCardIdx = c;
                            break;
                        }
                    }

                    if (matchCardIdx < 0) continue;

                    SessionCompletedImageInfo chosen = recentCards[matchCardIdx];
                    string dst = Path.Combine(coversDir, want.TargetFileName);
                    if (File.Exists(dst))
                    {
                        try
                        {
                            Directory.CreateDirectory(oldBackupDir);
                            File.Copy(dst, Path.Combine(oldBackupDir, DateTime.Now.ToString("yyyyMMdd_HHmmss_") + want.TargetFileName), true);
                            File.Delete(dst);
                        }
                        catch { }
                    }

                    bool ok = await DownloadFlowGeneratedImageAsync(sess, chosen.ImageUrl, chosen.AsbId, dst, stagingDl, savedHashes, ct);
                    if (ok && File.Exists(dst) && new FileInfo(dst).Length >= 1024)
                    {
                        usedCardIdx.Add(matchCardIdx);
                        downloadedCount++;
                        _log(string.Format("[Google Flow | Resgatar Capas] ✔ Capa resgatada e salva com sucesso: {0}", want.TargetFileName));
                        if (onUiRefresh != null)
                        {
                            try { onUiRefresh(); } catch { }
                        }
                    }
                }
            }
            finally
            {
                Task ignoredCleanup = Task.Run(async () =>
                {
                    try { await _cdp.ResetDownloadBehaviorToDefaultAsync(); } catch { }
                    try { Directory.Delete(stagingDl, true); } catch { }
                });
            }

            return downloadedCount;
        }
    }
}
